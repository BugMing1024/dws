#!/bin/bash

# 参数配置
declare -a init_type
# douc地址
douc_http_url=http://10.0.16.104:18241
douc_dubbo_url=http://10.0.16.104:18246
app_code_url=http://
# dic_type字典类型， dic_data字典数据， ext_user用户扩展， ext_group用户组扩展， role角色， group用户组
init_type=("dic_type" "dic_data" "ext_user" "ext_group" "role_group" "role" "group" "group_cust")
# 公共参数
dic_type_param='[{"accountId":110,"type":"LOB","code":"lob"},{"accountId":110,"type":"Country","code":"country"},{"accountId":110,"type":"Group Type","code":"groupType"},{"accountId":110,"type":"Bool","code":"bool"}]'
dic_data_param='[{"accountId":110,"typeCode":"lob","code":"CBGT","name":"CBGT","sortCode":1,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"CE","name":"CE","sortCode":2,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"CES","name":"CES","sortCode":3,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"CT.DATA","name":"CT.DATA","sortCode":4,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"EASRE","name":"EASRE","sortCode":5,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"FR.IBGT","name":"FR.IBGT","sortCode":6,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"ISS","name":"ISS","sortCode":7,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"ITT","name":"ITT","sortCode":8,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"MOT","name":"MOT","sortCode":9,"isEnable":true},{"accountId":110,"typeCode":"lob","code":"TS","name":"TS","sortCode":10,"isEnable":true},{"accountId":110,"typeCode":"country","code":"SG","name":"SG","sortCode":1,"isEnable":true},{"accountId":110,"typeCode":"country","code":"HK","name":"HK","sortCode":2,"isEnable":true},{"accountId":110,"typeCode":"country","code":"ID","name":"ID","sortCode":3,"isEnable":true},{"accountId":110,"typeCode":"country","code":"IN","name":"IN","sortCode":4,"isEnable":true},{"accountId":110,"typeCode":"country","code":"CN","name":"CN","sortCode":5,"isEnable":true},{"accountId":110,"typeCode":"country","code":"TW","name":"TW","sortCode":6,"isEnable":true},{"accountId":110,"typeCode":"groupType","code":"implementerGroup","name":"Implementer Group","sortCode":1,"isEnable":true},{"accountId":110,"typeCode":"groupType","code":"applicationApproverGroup","name":"Application Approver Group","sortCode":2,"isEnable":true},{"accountId":110,"typeCode":"groupType","code":"mdApproverGroup","name":"MD Approver Group","sortCode":3,"isEnable":true},{"accountId":110,"typeCode":"groupType","code":"releaseGroup","name":"Release Group","sortCode":4,"isEnable":true},{"accountId":110,"typeCode":"groupType","code":"changeGroup","name":"Change Group","sortCode":5,"isEnable":true},{"accountId":110,"typeCode":"groupType","code":"topGroup","name":"Top Group","sortCode":6,"isEnable":true},{"accountId":110,"typeCode":"bool","code":"true","name":"true","sortCode":1,"isEnable":true},{"accountId":110,"typeCode":"bool","code":"false","name":"false","sortCode":1,"isEnable":true}]'
ext_user_param='[{"name":"1Bank Id","alias":"1bankId","dataType":"string","isMust":false,"isUnique":false,"type":"1"},{"name":"TSO Id","alias":"tsoid","dataType":"string","isMust":false,"isUnique":false,"type":"1"},{"name":"Exceptional Email","alias":"exEmail","dataType":"string","isMust":false,"isUnique":false,"type":"1"},{"name":"Rank","alias":"rank","dataType":"string","isMust":false,"isUnique":false,"type":"1"},{"name":"MD Approver Group Rank","alias":"mdGroupRank","dataType":"string","isMust":false,"isUnique":false,"type":"1"}]'
ext_group_param="[{\"name\":\"LOB\",\"alias\":\"lob\",\"dataType\":\"selected\",\"isMust\":false,\"isUnique\":false,\"selectedId\":\"#{lob}\",\"isInner\":1,\"type\":\"3\"},{\"name\":\"Country\",\"alias\":\"country\",\"dataType\":\"selected\",\"isMust\":false,\"isUnique\":false,\"selectedId\":\"#{country}\",\"isInner\":1,\"type\":\"3\"},{\"name\":\"Appcode\",\"alias\":\"appCode\",\"dataType\":\"selected\",\"isMust\":false,\"isUnique\":false,\"isInner\":0,\"apiPath\":\"$app_code_url\",\"displayField\":\"$.name\",\"uniqueField\":\"$.id\",\"arrayField\":\"$.data\",\"type\":\"3\"},{\"name\":\"Group Type\",\"alias\":\"groupType\",\"dataType\":\"selected\",\"isMust\":false,\"isUnique\":false,\"selectedId\":\"#{groupType}\",\"isInner\":1,\"type\":\"3\"},{\"name\":\"allRank\",\"alias\":\"allRank\",\"dataType\":\"string\",\"isMust\":false,\"isUnique\":false,\"type\":\"3\"},{\"name\":\"hasLOBContryMapping\",\"alias\":\"hasLOBCountryMapping\",\"dataType\":\"selected\",\"isMust\":false,\"isUnique\":false,\"selectedId\":\"#{bool}\",\"isInner\":1,\"type\":\"3\"}]"
role_group_param='[{"accountId":110,"name":"Security Group","code":"securityGroup"}]'
role_param='[{"accountId":110,"name":"Implementer","code":"implementer","roleGroupCode":"securityGroup"},{"accountId":110,"name":"Approver","code":"approver","roleGroupCode":"securityGroup","tag":"[\"docp_subscribe\"]"}]'
group_param='[{"accountId":110,"name":"Application Implementer Groups","code":"implementerGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"Application Approver Groups","code":"applicationApproverGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"MD Approver Groups","code":"mdApproverGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"SVP & Above","code":"svpAbove"},{"accountId":110,"name":"HR Employee List","code":"hrEmployList"},{"accountId":110,"name":"L1.5 Release Manager Group","code":"releaseGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"L1.5 Change Management Team","code":"changeTeam","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"L1 Change Manager Groups","code":"changeGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"L1 Risk Manager Groups","code":"riskGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"ARC Approver Groups","code":"ARCApproverGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"CTO Approver Groups","code":"CTOApproverGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"Signoff Groups","code":"signoffGroup","extend":{"groupType":"topGroup"}},{"accountId":110,"name":"Notification Groups","code":"notificationGroup","extend":{"groupType":"topGroup"}}]'
group_cust_param="[{\"groupId\":\"#{svpAbove}\",\"ruleList\":[{\"ruleGroupList\":[{\"fieldIdent\":\"rank\",\"operator\":\"Eq\",\"isExtend\":1,\"type\":\"JsonString\",\"fieldValue\":\"SVP\",\"relation\":0},{\"fieldIdent\":\"rank\",\"operator\":\"Eq\",\"isExtend\":1,\"type\":\"JsonString\",\"fieldValue\":\"ED\",\"relation\":0},{\"fieldIdent\":\"rank\",\"operator\":\"Eq\",\"isExtend\":1,\"type\":\"JsonString\",\"fieldValue\":\"MD\"}]}]}]"
group_search_param='{"accountId":110,"userId":1,"codes":["svpAbove"]}'
rela_group_dic_type_param=("lob" "country" "groupType" "bool")
rela_group_cust_code_param=("svpAbove")
echo "init start..."
# 执行代码
for item in "${init_type[@]}"; do
    echo "initializing 【$item】"
    if [ "$item" == "dic_type" ]; then
        curl -s --location "$douc_dubbo_url/douc/dubbo/baseInfoV2/addOrUpdateDicType" \
        --header 'content-type: application/json' \
        --header 'rest-service-group: DOUC_RPC_DUBBO' \
        --header 'rest-service-version: 1.0.0' \
        --data "$dic_type_param"
        echo
    fi
    if [ "$item" == "dic_data" ]; then
        curl -s --location "$douc_dubbo_url/douc/dubbo/baseInfoV2/addOrUpdateDic" \
        --header 'content-type: application/json' \
        --header 'rest-service-group: DOUC_RPC_DUBBO' \
        --header 'rest-service-version: 1.0.0' \
        --data "$dic_data_param"
        echo
    fi
    if [ "$item" == "ext_user" ] || [ "$item" == "ext_group" ]; then
        response=$(curl -s --location "${douc_http_url}/douc/api/v1/dic/typeList" \
        --header 'userid: 1' \
        --header 'accountid: 110' \
        --header 'username: admin')
        
        if [ "$item" == "ext_user" ]; then
            param=$ext_user_param
        fi
        if [ "$item" == "ext_group" ]; then
            param=$ext_group_param
        fi

        for target_code in "${rela_group_dic_type_param[@]}"; do
            id_value=$(echo "$response" | jq -r --arg code "$target_code" '.data[] | select(.code == $code) |.id')
            if [ -n "$id_value" ]; then
                new_ext_group_param=$(echo "$param" | sed "s/#{$target_code}/$id_value/g")
                param="$new_ext_group_param"
            else
                echo "No matching dic_type found : $target_code"
            fi
        done
        
        echo "$param" | jq -c '.[]' | while read -r object; do
            curl -s --location "$douc_http_url/douc/api/v1/extend/addExtendConf" \
            --header 'Content-Type: application/json' \
            --header 'userid: 1' \
            --header 'accountid: 110' \
            --header 'username: admin' \
            --data "$object"
            echo
        done
        
    fi
    if [ "$item" == "role_group" ]; then
        curl -s --location "$douc_dubbo_url/douc/dubbo/roleV3/addOrUpdateRoleGroup" \
        --header 'content-type: application/json' \
        --header 'rest-service-group: DOUC_RPC_DUBBO' \
        --header 'rest-service-version: 1.0.0' \
        --data "$role_group_param"
        echo
    fi
    if [ "$item" == "role" ]; then
        curl -s --location "$douc_dubbo_url/douc/dubbo/roleV3/addOrUpdateRole" \
        --header 'content-type: application/json' \
        --header 'rest-service-group: DOUC_RPC_DUBBO' \
        --header 'rest-service-version: 1.0.0' \
        --data "$role_param"
        echo
    fi
    if [ "$item" == "group" ]; then
        curl -s --location "$douc_dubbo_url/douc/dubbo/groupV3/addOrUpdateUserGroup" \
        --header 'content-type: application/json' \
        --header 'rest-service-group: DOUC_RPC_DUBBO' \
        --header 'rest-service-version: 1.0.0' \
        --data "$group_param"
        echo
    fi
    if [ "$item" == "group_cust" ]; then
        response=$(curl -s --location "$douc_dubbo_url/douc/dubbo/groupV3/getGroupByCondition" \
        --header 'content-type: application/json' \
        --header 'rest-service-group: DOUC_RPC_DUBBO' \
        --header 'rest-service-version: 1.0.0' \
        --data "$group_search_param"
        echo)

        param=$group_cust_param
        for target_code in "${rela_group_cust_code_param[@]}"; do
            id_value=$(echo "$response" | jq -r --arg code "$target_code" '.data.records[] | select(.code == $code) |.id')
            if [ -n "$id_value" ]; then
                new_ext_group_param=$(echo "$param" | sed "s/#{$target_code}/$id_value/g")
                param="$new_ext_group_param"
            else
                echo "No matching group found : $target_code"
            fi
        done
    
        echo "$param" | jq -c '.[]' | while read -r object; do
            curl -s --location "$douc_http_url/douc/api/v1/group/saveOrUpdateGroupCustomConditionInfo" \
            --header 'Content-Type: application/json' \
            --header 'userid: 1' \
            --header 'accountid: 110' \
            --header 'username: admin' \
            --data "$object"
            echo
        done
    fi

     #echo "initializing 【$item】$result"
done
echo "init end."