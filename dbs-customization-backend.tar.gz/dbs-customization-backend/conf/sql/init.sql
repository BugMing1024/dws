
-- 消息发送记录表
create table if not exists  dosm_custom_message_record
(
    id               varchar(32)      not null comment '班次分组id'
    primary key,
    created_by       varchar(50)      null comment '创建用户id',
    is_del           bigint default 0 null comment '是否删除',
    created_time     timestamp(6)     null comment '创建时间',
    updated_time     timestamp(6)     null comment '更新时间',
    top_account_id   varchar(32)      null comment '顶级租户ID',
    account_id       varchar(50)      null comment '租户id',
    updated_by       varchar(50)      null comment '更新用户id',
    revision         bigint default 0 not null comment '乐观锁',
    message_id       varchar(64)      null comment '消息id',
    work_order_id    varchar(64)      null comment '工单id',
    node_id          varchar(64)      null comment '节点id',
    status           int              null comment '消息发送状态',
    notify_scene     varchar(64)      null comment '通知场景',
    message_request  text             null comment '消息发送参数',
    message_response text             null comment '发送消息返回结果',
    retry            int    default 0 null comment '重试次数'
    )
    comment '定制化消息推送记录表';

--消息读取记录表
create table if not exists  dosm_custom_message_read_record
(
    id           varchar(32)  not null comment '消息读取记录id'
    primary key,
    message_id   varchar(256) null comment '消息id',
    title        text         null comment '消息标题',
    status       int          null comment '消息读取状态。0-未读,1-已读',
    content      text         null comment '消息内容',
    created_time timestamp(6) null comment '创建时间'
    )
    comment '定制化消息读取记录表';

-- idx_email_message_id索引
create index idx_email_message_id
    on dosm_custom_message_read_record (message_id)
    comment '消息id索引';

-- 定制化延迟消息推送记录表
create table if not exists  dosm_custom_delay_message_record
(
    id             varchar(32)      not null comment '班次分组id'
    primary key,
    created_by     varchar(50)      null comment '创建用户id',
    is_del         bigint default 0 null comment '是否删除',
    created_time   timestamp(6)     null comment '创建时间',
    start_time     timestamp(6)     null comment '开始时间',
    end_time       timestamp(6)     null comment '结束时间',
    updated_time   timestamp(6)     null comment '更新时间',
    top_account_id varchar(32)      null comment '顶级租户ID',
    account_id     varchar(50)      null comment '租户id',
    updated_by     varchar(50)      null comment '更新用户id',
    revision       bigint default 0 not null comment '乐观锁',
    work_order_id  varchar(64)      null comment '工单id',
    node_id        varchar(64)      null comment '节点id',
    status         int              null comment '0 -未开始,1-成功 2-失效',
    notify_content text             null comment '通知内容',
    retry          int    default 0 null comment '重试次数',
    exec_at        timestamp(6)     null comment '期望执行时间'
    )
    comment '定制化延迟消息推送记录表';

-- idx_dcder_exec_at索引
create index idx_dcder_exec_at
    on dosm_custom_delay_message_record (exec_at)
    comment '期望执行时间索引';

create index idx_dcdmr_workId_nodeId
    on dosm_custom_delay_message_record (work_order_id, node_id)
    comment '工单id和节点id索引';

ALTER TABLE dosm_custom_message_record ADD COLUMN notify_way VARCHAR(64) NULL COMMENT '通知类型';

ALTER TABLE dosm_custom_message_read_record ADD COLUMN other text null comment '其他信息';


CREATE TABLE sign_off_manager (
                                  id INT AUTO_INCREMENT PRIMARY KEY,
                                  created_time timestamp default CURRENT_TIMESTAMP,
                                  updated_time timestamp default CURRENT_TIMESTAMP,
                                  status VARCHAR(255),
                                  top_account_id VARCHAR(255),
                                  account_id VARCHAR(255),
                                  sign_off_type VARCHAR(512),
                                  sign_off_group VARCHAR(512),
                                  sign_off_user_group VARCHAR(512),
                                  sign_off_user VARCHAR(512),
                                  artifact text,
                                  work_order_id VARCHAR(255)
);
