package com.cloudwise.douc.customization.biz.service.crdailybulkreminder;

import com.cloudwise.douc.customization.DataConnectivityService;
import com.cloudwise.douc.customization.biz.model.crdailybulkreminder.RptCrTodoDailyData;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@Slf4j
@SpringBootTest(classes = DataConnectivityService.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CrDailyBulkReminderServiceTest {
    @Autowired
    private CrDailyBulkReminderService crDailyBulkReminderService;

    @Test
    @Order(1)
    void doBulkReminderDatas() {
        crDailyBulkReminderService.doRebuildBulkReminderDatas();
    }

    @Test
    @Order(3)
    void doSendBulkReminderEmails() {
        crDailyBulkReminderService.doSendBulkReminderEmails();
    }
}