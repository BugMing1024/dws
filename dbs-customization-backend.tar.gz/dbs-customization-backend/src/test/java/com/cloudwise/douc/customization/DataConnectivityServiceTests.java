package com.cloudwise.douc.customization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataConnectivityServiceTests {
    
    @Test
    void contextLoads() {
    }
    
}
