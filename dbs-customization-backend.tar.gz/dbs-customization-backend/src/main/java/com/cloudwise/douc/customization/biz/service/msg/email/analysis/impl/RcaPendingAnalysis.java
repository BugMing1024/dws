package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * @Author hekongtao
 * @Date 2025/2/5
 */
@Slf4j
public class RcaPendingAnalysis extends AbstractBaseAnalysis {

    public final static RcaPendingAnalysis INSTANCE = new RcaPendingAnalysis();


    private static final String TITLE_TEMPLATE = "RCA Pending for CR Number: ${bizKey}";


    @Override
    public String getTitleTemplate() {
        return TITLE_TEMPLATE;
    }

    @Override
    public void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap) {

    }

    /**
     * requestor
     */
    @Override
    protected List<UserInfo> getReceivers(MessageContext context) {
        UserInfo requestor = getRequestor(context);
        return requestor == null? null: Lists.newArrayList(requestor);
    }


    /**
     * PXX_DBSAPP_CHANGEFOCAL_YYYY  (XX =Country of Origin / YYYY=LOB)
     */
    @Override
    protected List<UserInfo> getSendCopys(MessageContext context) {
        return getUserByGroupCode(context, getDosmConfig().getEmailConfig().getRcaApprovalCCGroupName());
    }

}
