package com.cloudwise.douc.customization.biz.model.signoff;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TriggerNode {

    private String workOrderId;


    private Map<String, String> triggerParamMap;



}
