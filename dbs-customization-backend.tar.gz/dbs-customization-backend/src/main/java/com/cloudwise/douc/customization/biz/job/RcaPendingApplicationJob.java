package com.cloudwise.douc.customization.biz.job;


import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.dao.DbsRcaApplicationPendingMapper;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController()
@RequestMapping("/rca")
@Component
@SyncEndpoint(name = Constants.SYNC_RCA_APPLICATION_PENDING_JOB, cron = Constants.SYNC_RCA_APPLICATION_PENDING_JOB_CRON)
@Conditional(value = SyncCheckCondition.class)
public class RcaPendingApplicationJob {
    
    
    @Resource
    private DbsRcaApplicationPendingMapper dbsRcaApplicationPendingMapper;
    
    
    @GetMapping("/rcaPendingApplicationJob")
    @XxlJob(Constants.SYNC_RCA_APPLICATION_PENDING_JOB)
    public void jobRun() {
        // 通过创建时间 超过7个工作日的工单 ,设置is_pending为true
        dbsRcaApplicationPendingMapper.updateRcaPendingApplication();
    }
    
    
}
