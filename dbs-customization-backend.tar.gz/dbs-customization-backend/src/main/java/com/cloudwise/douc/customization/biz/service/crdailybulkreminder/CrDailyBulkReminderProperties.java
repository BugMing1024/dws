package com.cloudwise.douc.customization.biz.service.crdailybulkreminder;


import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "dosm.cr-daily-bulk-reminder.workflow")
@Data
@NoArgsConstructor
@RefreshScope
public class CrDailyBulkReminderProperties {
    private String processName;
    private List<Map<String, String>> nodes;
    private String changeScheduleStartdateFullpath;
}
