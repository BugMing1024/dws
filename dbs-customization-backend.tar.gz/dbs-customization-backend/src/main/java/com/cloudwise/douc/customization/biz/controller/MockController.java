package com.cloudwise.douc.customization.biz.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cloudwise.cache.utils.RedisUtils;
import com.cloudwise.douc.customization.biz.config.DataInitConfig;
import com.cloudwise.douc.customization.biz.config.MessageHolder;
import com.cloudwise.douc.customization.biz.constant.ExecutorType;
import com.cloudwise.douc.customization.biz.dao.AppcodeLobCountryMapper;
import com.cloudwise.douc.customization.biz.model.appcode.SimpleAppCode;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsRespCommonGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.ImplementerGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.MdApproveGroup;
import com.cloudwise.douc.customization.biz.service.groupuser.reader.Reader;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.model.DbsResp;
import com.cloudwise.douc.customization.common.model.SingleMergeGroupInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created on 2022-12-28.
 *
 * @author skiya
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class MockController {
    
    private final ThreadPoolTaskExecutor datasyncTaskExecutor;
    
    private final Reader<DbsGroupInfo> doucGroupReader;
    
    private final Reader<DbsUserInfo> doucUserReader;
    
    private final DbsProperties dbsProperties;
    
    @Autowired(required = false)
    private MessageHolder messageHolder;
    
    @Autowired(required = false)
    private RedisUtils redisUtils;
    
    @Autowired
    private AppcodeLobCountryMapper appcodeLobCountryMapper;
    
    @Autowired
    private DataInitConfig dataInitConfig;
    
    @GetMapping("/data/init")
    public void dataInit() {
        dataInitConfig.init();
    }
    
    @GetMapping("/biz/appCode/list")
    public DbsResp<List> appCodeList() {
        String mockList = dbsProperties.getMockAppCode().getList();
        if (StrUtil.isNotBlank(mockList)) {
            return DbsResp.ok(JSONUtil.toList(mockList, JSONObject.class));
        }
        List<SimpleAppCode> select = appcodeLobCountryMapper.select();
        // todo正常逻辑
        return DbsResp.ok(select);
    }
    
    
    @PostMapping("/dcs/mock2/{type}")
    public Object appCodeList2(@PathVariable String type) {
        Object result = null;
        switch (type) {
            case "mockauthenticate":
                result = JSONUtil.toBean(dbsProperties.getMockauthenticate().getList(), JSONObject.class);
                break;
            case "mockHrData":
                result = JSONUtil.toBean(dbsProperties.getMockHrData().getList(), JSONObject.class);
                break;
            case "mockGroupDetail":
                result = JSONUtil.toBean(dbsProperties.getMockGroupDetail().getList(), JSONObject.class);
                break;
            case "mockReleaseGroups":
                result = JSONUtil.toBean(dbsProperties.getMockReleaseGroups().getList(), JSONObject.class);
                break;
            case "mockChangeGroups":
                result = JSONUtil.toBean(dbsProperties.getMockChangeGroups().getList(), JSONObject.class);
                break;
            default:
                break;
        }
        return result;
    }
    
    @GetMapping("/dcs/mock/{type}")
    public Object appCodeList(@PathVariable String type) {
        Object result = null;
        switch (type) {
            case "mockApproveGroups":
                result = JSONUtil.toBean(dbsProperties.getMockApproveGroups().getList(), JSONObject.class);
                break;
            case "mockImplementerGroups":
                result = JSONUtil.toBean(dbsProperties.getMockImplementerGroups().getList(), JSONObject.class);
                break;
            case "mockHmdApproverData":
                result = JSONUtil.toBean(dbsProperties.getMockHmdApproverData().getList(), JSONObject.class);
                break;
            case "mockHtsoidData":
                result = JSONUtil.toBean(dbsProperties.getMockHtsoidData().getList(), JSONObject.class);
                break;
            default:
                break;
        }
        return result;
    }
    
    
    @PostMapping("/sync/group/{MD}/user")
    public DbsResp<Void> syncGroup(@PathVariable String MD, List<SingleMergeGroupInfo> groups) {
        log.info("sync group req, MD:{}, groups:{}", MD, groups);
        if (CollUtil.isEmpty(groups)) {
            return DbsResp.ok();
        }
        try {
            List<DbsGroupInfo> groupInfos = new ArrayList<>();
            List<DbsUserInfo> userInfos = new ArrayList<>();
            switch (MD.toLowerCase()) {
                case "approver":
                    groupInfos = doucGroupReader.read(getType(), BeanUtil.copyToList(groups, DbsRespCommonGroup.class));
                    userInfos = doucUserReader.read(getType(), BeanUtil.copyToList(groups, DbsRespCommonGroup.class));
                    break;
                case "implementation":
                    List<ImplementerGroup> implementerGroups = groups.stream().map(singleMergeGroupInfo -> {
                        ImplementerGroup implementerGroup = new ImplementerGroup();
                        implementerGroup.setGroup(singleMergeGroupInfo.getGroup());
                        implementerGroup.setGroupCountry(singleMergeGroupInfo.getGroupCountry());
                        implementerGroup.setGroupLOB(singleMergeGroupInfo.getGroupLOB());
                        implementerGroup.setMemberLogin(singleMergeGroupInfo.getMember1bankId());
                        implementerGroup.setMemberEmail(singleMergeGroupInfo.getMemberEmail());
                        implementerGroup.setMemberName(singleMergeGroupInfo.getMemberName());
                        implementerGroup.setMemberMobile(singleMergeGroupInfo.getMemberMobile());
                        return implementerGroup;
                    }).collect(Collectors.toList());
                    groupInfos = doucGroupReader.read(getType(), null, implementerGroups);
                    userInfos = doucUserReader.read(getType(), null, implementerGroups);
                    break;
                case "mdapprover":
                    List<MdApproveGroup> mdApproveGroups = groups.stream().map(singleMergeGroupInfo -> {
                        MdApproveGroup mdApproveGroup = new MdApproveGroup();
                        mdApproveGroup.setGroupName(singleMergeGroupInfo.getGroup());
                        mdApproveGroup.setCountry(singleMergeGroupInfo.getGroupCountry());
                        mdApproveGroup.setLOB(singleMergeGroupInfo.getGroupLOB());
                        mdApproveGroup.setLogin(singleMergeGroupInfo.getMember1bankId());
                        mdApproveGroup.setRank(singleMergeGroupInfo.getGroupRank());
                        return mdApproveGroup;
                    }).collect(Collectors.toList());
                    groupInfos = doucGroupReader.read(getType(), null, null, mdApproveGroups);
                    userInfos = doucUserReader.read(getType(), null, null, mdApproveGroups);
                    break;
                default:
                    break;
            }
            if (CollUtil.isNotEmpty(groupInfos)) {
                boolean b = messageHolder.getMessageBean().sendMessage(dbsProperties.getGroup().getSyncTopic(), "", JSONUtil.toJsonStr(groupInfos));
                if (!b) {
                    log.error("sync {} group error, req={}", MD, groups);
                }
            }
            if (CollUtil.isNotEmpty(userInfos)) {
                boolean b = messageHolder.getMessageBean().sendMessage(dbsProperties.getUser().getSyncTopic(), "", JSONUtil.toJsonStr(groupInfos));
                if (!b) {
                    log.error("sync {} user error, req={}", MD, userInfos);
                }
            }
        } catch (Exception e) {
            log.error("sync {} group error, req={}", MD, groups, e);
            return DbsResp.fail(e);
        }
        return DbsResp.ok();
    }
    
    
    public ExecutorType getType() {
        return ExecutorType.REST;
    }
    
}
