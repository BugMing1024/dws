package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * @Author hekongtao
 * @Date 2025/2/5
 */
@Slf4j
public class EmailAcknowledgementApprovedAnalysis extends AbstractBaseAnalysis {

    public final static EmailAcknowledgementApprovedAnalysis INSTANCE = new EmailAcknowledgementApprovedAnalysis();

    @Override
    public String getTitleTemplate() {
        return null;
    }

    @Override
    public void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap) {
    }

    /**
     * XXX <XXX@dbs.com>Requester
     */
    @Override
    protected List<UserInfo> getSendCopys(MessageContext context) {
        UserInfo userInfo = getRequestor(context);
        return userInfo == null? null: Lists.newArrayList(userInfo);
    }
}
