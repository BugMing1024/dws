package com.cloudwise.douc.customization.common.util;

import cn.hutool.core.util.RuntimeUtil;
import com.cloudwise.concurrent.MdcThreadPoolTaskExecutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
public class AsyncTaskPool {
    
    public static ScheduledExecutorService scheduledExecutorService = new ScheduledThreadPoolExecutor(5, (runnable) -> {
        Thread t = new Thread(runnable, "global-thread");
        return t;
    }, new ThreadPoolExecutor.CallerRunsPolicy());
    
    /**
     * 核心线程数 默认是 64
     */
    private static int corePoolSize;
    
    /**
     * 最大线程数 默认 1000
     */
    private static int maximumPoolSize;
    
    /**
     * 阻塞队列数 默认最大 10000
     */
    private static int blockingQueueCapacity;
    
    private static int keepAliveSeconds;
    
    private static int getIoDefaultProcessors() {
        return 2 * RuntimeUtil.getProcessorCount() + 1;
    }
    
    public static TaskExecutor getTaskExecutor() {
        
        return TaskExecutorHolder.executor;
    }
    
    @Value("${server.douc.corePoolSize:64}")
    public void setCorePoolSize(Integer corePoolSize) {
        AsyncTaskPool.corePoolSize = corePoolSize != null ? corePoolSize : 64;
    }
    
    @Value("${server.douc.maximumPoolSize:1000}")
    public void setMaximumPoolSize(Integer maximumPoolSize) {
        AsyncTaskPool.maximumPoolSize = maximumPoolSize != null ? maximumPoolSize : 1000;
    }
    
    @Value("${server.douc.blockingQueueCapacity:10000}")
    public void setBlockingQueueCapacity(Integer blockingQueueCapacity) {
        AsyncTaskPool.blockingQueueCapacity = blockingQueueCapacity != null ? blockingQueueCapacity : 10000;
    }
    
    @Value("${server.douc.keepAliveSeconds:60}")
    public void setKeepAliveSeconds(Integer keepAliveSeconds) {
        AsyncTaskPool.keepAliveSeconds = keepAliveSeconds != null ? keepAliveSeconds : 60;
    }
    
    private static class TaskExecutorHolder {
        
        public static ThreadPoolTaskExecutor executor;
        
        static {
            // 设置核心线程数
            if (corePoolSize <= 0) {
                corePoolSize = (Math.max(getIoDefaultProcessors(), 64));
            }
            executor = MdcThreadPoolTaskExecutor.newMdcThreadPoolTaskExecutor(corePoolSize, maximumPoolSize, blockingQueueCapacity, keepAliveSeconds,
                    "douc-api-pool", new ThreadPoolExecutor.CallerRunsPolicy());
            // 等待所有任务结束后再关闭线程池
            executor.setWaitForTasksToCompleteOnShutdown(true);
            executor.initialize();
        }
    }
}