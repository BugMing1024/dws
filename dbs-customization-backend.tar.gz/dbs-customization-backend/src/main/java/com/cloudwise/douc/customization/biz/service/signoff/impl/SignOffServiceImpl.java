package com.cloudwise.douc.customization.biz.service.signoff.impl;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.utils.JsonUtils;
import com.cloudwise.dosm.facewall.extension.core.exception.BaseException;
import com.cloudwise.douc.customization.biz.dao.MdlInstanceMapper;
import com.cloudwise.douc.customization.biz.dao.SignOffMapper;
import com.cloudwise.douc.customization.biz.enums.SignOffStatusEnum;
import com.cloudwise.douc.customization.biz.enums.SignoffConstants;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.NotifyVo;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import com.cloudwise.douc.customization.biz.model.signoff.TriggerNode;
import com.cloudwise.douc.customization.biz.model.user.UserInfo;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.signoff.SignOffService;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.biz.util.DosmHttpUtil;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.model.DbsResp;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author abell.wu
 */
@Slf4j
@Service
public class SignOffServiceImpl implements SignOffService {


    @Lazy
    @Resource
    private DosmCustomService dosmCustomService;

    @Resource
    private SignOffMapper signOffMapper;

    @Resource
    private MdlInstanceMapper mdlInstanceMapper;

    @Value("${rest.http.dosm:10.0.16.105:18271}")
    private String dosmUrl;

    @Autowired
    private DosmConfig dosmConfig;

    @Autowired
    DosmHttpUtil dosmHttpUtil;

    @Autowired
    private DosmWorkOrderService dosmWorkOrderService;

    @Override
    public Long insert(SignOffEntity signOff) {
        signOff.setCreatedTime(new Date());
        signOffMapper.insert(signOff);
        return signOff.getId();
    }


    @Override
    public void insert(List<SignOffEntity> signOffList) {
        for (SignOffEntity signOffEntity : signOffList) {
            signOffEntity.setCreatedTime(new Date());
        }
        signOffMapper.insert(signOffList);
    }


    @Override
    public Long update(SignOffEntity signOff) {
        if (signOff.getId() == null) {
            throw new BaseException("Missing update ID");
        }
        SignOffEntity signOffById = getSignOffById(signOff.getId());
        signOff.setCreatedTime(signOffById.getCreatedTime());
        signOff.setUpdatedTime(new Date());
        signOffMapper.updateById(signOff);
        return signOff.getId();
    }

    @Override
    public boolean sendEmail(Long signOffId, String operateUserId) {
        SignOffEntity signoffEntity = this.getSignOffById(signOffId);

        // 发送邮件
        MessageContext messageContext = new MessageContext();
        messageContext.setWorkOrderId(signoffEntity.getWorkOrderId());
        messageContext.setUserId(operateUserId);
        messageContext.setCreatedBy(operateUserId);
        messageContext.setTopAccountId(dosmConfig.getTopAccountId());
        messageContext.setAccountId(dosmConfig.getAccountId());

        NotifyVo emailNotify = new NotifyVo();
        messageContext.setNotify(emailNotify);
        HashMap<String, String> publicFields = new HashMap<>();
        messageContext.setPublicFields(publicFields);

        WorkOrderDetail workOrderDetail = dosmHttpUtil.getWorkOrderDetail(signoffEntity.getWorkOrderId(), operateUserId);
        if(workOrderDetail != null) {
            messageContext.setNodeId(workOrderDetail.getCurrentNodeId());
            Map<String, FieldInfo> formData = dosmWorkOrderService.getFormData(workOrderDetail.getFormId(), JsonUtils.parseJsonNode(workOrderDetail.getFormData()));
            messageContext.setFormData(formData);
        }

        EmailAnalysisUtil.buildSignoffMsgContext(signoffEntity, workOrderDetail, emailNotify, publicFields, null);

        boolean b = dosmCustomService.sendMessage(messageContext);

        if (b) {
            //修改状态 Pending Approval
            SignOffEntity entity = new SignOffEntity();
            entity.setId(signOffId);
            entity.setStatus(SignOffStatusEnum.PENDING.name());
            signOffMapper.updateById(entity);
            return true;
        }
        throw new BaseException("Failed to send an approval email");
    }


    @Override
    public void status(Long signOffId, String status) {
        SignOffEntity entity = new SignOffEntity();
        entity.setId(signOffId);
        entity.setStatus(status);
        signOffMapper.updateById(entity);
    }

    @Override
    public void rejected(Long signOffId, String operateUserId) {
        SignOffEntity signOffById = check(signOffId, operateUserId);
        SignOffEntity entity = new SignOffEntity();
        entity.setId(signOffId);
        entity.setStatus(SignOffStatusEnum.REJECTED.name());
        signOffMapper.updateById(entity);
        calculate(signOffById.getWorkOrderId(), operateUserId);

    }

    @Override
    public void approved(Long signOffId, String operateUserId) {
        SignOffEntity signOffById = check(signOffId, operateUserId);
        SignOffEntity entity = new SignOffEntity();
        entity.setId(signOffId);
        entity.setStatus(SignOffStatusEnum.APPROVED.name());
        signOffMapper.updateById(entity);

        // 重新计算
        calculate(signOffById.getWorkOrderId(), operateUserId);

    }

    private @NotNull SignOffEntity check(Long signOffId, String operateUserId) {
        SignOffEntity signOffById = this.getSignOffById(signOffId);

        String signOffUser = signOffById.getSignOffUser();

        List<UserInfo> userInfos = JsonUtils.convertList(signOffUser, UserInfo.class);

        UserInfo userInfo = userInfos.get(0);

        if (!StringUtils.equals(userInfo.getUserId(), operateUserId)) {
            throw new BaseException("signOff users are inconsistent");
        }
        return signOffById;
    }

    @Override
    public List<SignOffEntity> getSignOffListByWorkOrderId(String workOrderId, String signOffGroup) {
        return signOffMapper.selectList(Wrappers.lambdaQuery(SignOffEntity.class).eq(SignOffEntity::getWorkOrderId, workOrderId).eq(SignOffEntity::getSignOffGroup, signOffGroup).orderByDesc(SignOffEntity::getCreatedTime));
    }

    @Override
    public SignOffEntity getSignOffById(Long signOffId) {
        SignOffEntity signOffEntity = signOffMapper.selectById(signOffId);
        return signOffEntity;
    }

    @Override
    public Boolean calculateSignOffResult(String workOrderId) {
        List<SignOffEntity> signOffEntities = signOffMapper.selectList(Wrappers.lambdaQuery(SignOffEntity.class).eq(SignOffEntity::getWorkOrderId, workOrderId).orderByDesc(SignOffEntity::getCreatedTime));

        Map<String, List<SignOffEntity>> signOffGroupMap
                = signOffEntities.stream().collect(Collectors.groupingBy(SignOffEntity::getSignOffGroup));

        List<Boolean> resultNoPass = Lists.newArrayList();
        signOffGroupMap.forEach((signOffGroup, signOffEntityList) -> {
            signOffEntityList.forEach(signOffEntity -> {
                String signOffType = signOffEntity.getSignOffType();

                List<String> signOffTypeList = JsonUtils.convertList(signOffType, String.class);

                for (String signOff : signOffTypeList) {
                    SignoffConstants.SignoffItem signoffItem = SignoffConstants.SignoffItem.fromString(signOffEntity.getSignOffGroup(), signOff);
                    if (signoffItem.getAffectStatus() && !SignOffStatusEnum.APPROVED.name().equals(signOffEntity.getStatus())) {
                        resultNoPass.add(false);
                    }

                }


            });
        });

        return resultNoPass.size() > 0;
    }


    private void calculate(String workOrderId, String userId) {

        List<SignOffEntity> signOffEntities = signOffMapper.selectList(Wrappers.lambdaQuery(SignOffEntity.class).eq(SignOffEntity::getWorkOrderId, workOrderId).orderByDesc(SignOffEntity::getCreatedTime));

        SignOffEntity signOffEntity = signOffEntities.get(0);

        // 计算project convert 以外的是否通过   Readytosubmit
        Boolean Readytosubmit = this.calculateSignOffResult(workOrderId);

        // 计算approved                       Readytoapprove
        boolean Readytoapprove = calculateReadytoapprove(signOffEntities);


        // 计算closed                         Readytoclose
        boolean Readytoclose = calculateReadytoclose(signOffEntities);


        // 更新表单数据
        mdlInstanceMapper.updateFormDataByFieldKey(workOrderId, "Readytosubmit", String.valueOf(Readytosubmit));
        mdlInstanceMapper.updateFormDataByFieldKey(workOrderId, "Readytoapprove", String.valueOf(Readytoapprove));
        mdlInstanceMapper.updateFormDataByFieldKey(workOrderId, "Readytoclose", String.valueOf(Readytoclose));

        Map<String, String> formDataMap = Maps.newHashMap();
        formDataMap.put("Readytoapprove", String.valueOf(Readytoapprove));
        formDataMap.put("Readytoclose", String.valueOf(Readytoclose));

        if (Readytoapprove || Readytoclose) {
            triggerServiceNode(workOrderId, signOffEntity.getTopAccountId(), signOffEntity.getAccountId(), userId, formDataMap);
        }

    }


    private boolean calculateReadytoapprove(List<SignOffEntity> signOffEntities) {
        List<String> toapproveFlag = Lists.newArrayList(SignoffConstants.SignoffItem.LV_SIGNOFF.getName(), SignoffConstants.SignoffItem.IMPLEMENTATION_CHECKER_SIGNOFF.getName());

        return signOffEntities.stream()
                .allMatch(v -> {
                    List<String> signOffTypes = JsonUtils.convertList(v.getSignOffType(), String.class);
                    return signOffTypes.stream().allMatch(signOffType -> !toapproveFlag.contains(signOffType) || SignOffStatusEnum.APPROVED.name().equals(v.getStatus()));
                });
    }

    private boolean calculateReadytoclose(List<SignOffEntity> signOffEntities) {

        List<String> closeFlag = Lists.newArrayList(SignoffConstants.SignoffItem.LV_SIGNOFF.getName(), SignoffConstants.SignoffItem.IMPLEMENTATION_CHECKER_SIGNOFF.getName());

        return signOffEntities.stream()
                .allMatch(v -> {
                    List<String> signOffTypes = JsonUtils.convertList(v.getSignOffType(), String.class);
                    return signOffTypes.stream()
                            .allMatch(signOffType -> !closeFlag.contains(signOffType) || SignOffStatusEnum.APPROVED.name().equals(v.getStatus()));
                });

    }


    private void triggerServiceNode(String workOrderId, String topAccountId, String accountId, String userId, Map<String, String> formMap) {

        HttpRequest post = HttpUtil.createPost(dosmUrl + "/api/v2/open/form/callback");
        post.header("accountId", topAccountId);
        post.header("topAccountId", accountId);
        //TODO
        post.header("userId", userId);
        post.contentType("application/json");


        TriggerNode triggerNode = new TriggerNode(workOrderId, formMap);

        String jsonValueString = com.cloudwise.douc.customization.common.util.JsonUtils.toJsonValueString(triggerNode);
        post.body(jsonValueString);
        try (HttpResponse execute = post.execute()) {
            log.info("triggerServiceNode:workOrderId:{},body:{}", workOrderId, jsonValueString);
        } catch (Exception e) {
            log.error("triggerServiceNode error:{}", e.getMessage(), e);
        }


    }


    @Value("${heighten.apiurl:https://itsm.cmwf.ocp.uat.dbs.com}")
    private String apiUrl;


    @Value("${dbs.check.idr.result.url:/common-server/invensys/IdrResult}")
    private String idrCheckCaseIdUrl;

    @Autowired
    private DbsProperties dbsProperties;


    @Override
    public Object idrCaseIdValid(@RequestParam String caseId) {

//        String testData = "{\"code\":\"200\",\"message\":\"SUCCESS\",\"data\":[{\"CASEID\":\"20170524_APL\",\"PROJECTNAME\":\"UEBA\",\"APPCODE\":\"UEBA\",\"LOBT\":\"TS\",\"COUNTRY\":\"SG\",\"EOCL\":\"NA\",\"ITM\":\"OK\",\"TSM\":\"OK\",\"SSL\":\"OK\",\"ID_MANAGEMENT\":\"OK\",\"ISCD\":\"OK\",\"VA\":\"OK\",\"PENTEST\":\"NA\",\"FAILOVER\":\"NA\",\"CUS\":\"NA\",\"STARTDATE\":\"2021-04-22\",\"COMPLETIONDATE\":\"2021-04-26\",\"STARTEDIDRBY\":\"Matthew Heng Kah ANG\"},{\"CASEID\":\"20233308\",\"PROJECTNAME\":\"Marketplace_Cart52925_anantg\",\"APPCODE\":\"HDPE\",\"LOBT\":\"CES\",\"COUNTRY\":\"SG\",\"EOCL\":\"OK\",\"ITM\":\"NA\",\"TSM\":\"NA\",\"SSL\":\"NA\",\"ID_MANAGEMENT\":\"WARN\",\"ISCD\":\"NOTOK\",\"VA\":\"WARN\",\"PENTEST\":\"NA\",\"FAILOVER\":\"NA\",\"CUS\":\"NA\",\"STARTDATE\":null,\"COMPLETIONDATE\":null,\"STARTEDIDRBY\":null}],\"success\":true}";
//        return JsonUtils.parseJsonNode(testData);

        HttpRequest appCode = HttpUtil.createPost(apiUrl + idrCheckCaseIdUrl).contentType("application/json").header("appCode", dbsProperties.getAppCode());
        HttpResponse response = appCode.header("appKey", dbsProperties.getAppKey()).timeout(20000).execute();
        if (response.isOk()) {
            String body = response.body();
            DbsResp<Object> tdosmApiVo = com.cloudwise.douc.customization.common.util.JsonUtils.toBean(body, DbsResp.class);
            return tdosmApiVo;
        }
        return null;


    }


}
