package com.cloudwise.douc.customization.biz.service.groupuser.mapping;

import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.MappingHook;

import java.util.Collection;
import java.util.List;

/**
 * Created on 2022-4-2.
 *
 * @author skiya
 */
public class MapperFactory {
    
    public static <S, T> Mapper<S, T> getMapper(Class<S> sourceClass, Class<T> targetClass, Collection<MappingHook<S, T>> hooks) {
        return new Mapper<>(sourceClass, targetClass, hooks);
    }
    
    public static <S, T> Mapper<S, T> getMapper(Class<S> sourceClass, Class<T> targetClass, List<ResultMap> mappings,
            Collection<MappingHook<S, T>> hooks) {
        return new Mapper<>(sourceClass, targetClass, mappings, hooks);
    }
    
}
