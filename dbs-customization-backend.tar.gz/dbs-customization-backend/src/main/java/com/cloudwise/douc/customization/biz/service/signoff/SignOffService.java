package com.cloudwise.douc.customization.biz.service.signoff;

import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author abell.wu
 */
public interface SignOffService {



    Long insert(SignOffEntity signOff);


    void insert(List<SignOffEntity> signOffList);

    Long update(SignOffEntity signOff);


    /**
     * 发送邮件
     */
    boolean sendEmail(Long signOffId, String userId);


    /**
     * 修改状态
     */
    void status(Long signOffId ,String status);

    /**
     * 驳回
     */
    void rejected(Long signOffId,String operateUserId);


    /**
     * 通过
     */
    void approved(Long signOffId,String operateUserId);


    /**
     * 通过workOrderId获取signOff数据
     */
    List<SignOffEntity> getSignOffListByWorkOrderId(String workOrderId, String signOffGroup);


    /**
     * 通过id查询详情
     * @param signOffId
     * @return
     */
    SignOffEntity getSignOffById(Long signOffId);


    /**
     * 计算signOff 类型的结果
     */
    Boolean calculateSignOffResult(String workOrderId);


    Object idrCaseIdValid(@RequestParam String caseId);
}
