package com.cloudwise.douc.customization.biz.service.msg.utils;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.map.MapUtil;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.form.RowData;
import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.api.bean.form.field.*;
import com.cloudwise.douc.customization.biz.model.email.FieldValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;

import java.util.*;

/**
 * @author ming.ma
 * @since 2024-12-11  18:07
 **/
@Slf4j
public class FieldBindVariableUtil {
    
    
    private static final String COMMA = ".";

    private static final String DEFAULT_VALUE = "";
    
    public static Map<String, Object> getBindVariable(List<FieldValue> fields, Map<String, FieldInfo> formData, Map<String, String> fieldValueFormatMap) {
        Map<String, Object> binding = new HashMap<>();
        if (CollUtil.isEmpty(fields)) {
            return binding;
        }

        if(MapUtil.isEmpty(formData)) {
            fields.forEach(field -> binding.put(field.getEmailKey(), ""));
            return binding;
        }

        for (FieldValue fieldValue : fields) {
            String emailKey = fieldValue.getEmailKey();
            String fieldCode = fieldValue.getName();
            String fieldValueFormat = MapUtils.isEmpty(fieldValueFormatMap)? null: fieldValueFormatMap.get(emailKey);
            //判断是否是表格变量
            if (fieldCode.contains(COMMA)) {
                List<String> values = new ArrayList<>();
                String[] split = fieldCode.split(COMMA);
                if (split.length != 2) {
                    log.info("[表格变量处理] not a table value:emailKey:{},name:{}", emailKey, fieldCode);
                    continue;
                }
                String tableFieldCode = split[0];
                fieldCode = split[1];
                FieldInfo fieldInfo = formData.get(tableFieldCode);
                if (Objects.isNull(fieldInfo)) {
                    log.info("[表格变量处理] get tableName:{} form data is null,", tableFieldCode);
                    continue;
                }
                TableFormField tableForm = (TableFormField) fieldInfo.getFieldValueObj();
                if (Objects.isNull(tableForm)) {
                    log.info("[表格变量处理] get tableName:{} form data value is null,", tableFieldCode);
                    continue;
                }
                Collection<RowData> rowDatas = tableForm.getValue();
                if (CollUtil.isNotEmpty(rowDatas)) {
                    for (RowData rowData: rowDatas) {
                        Map<String, FieldInfo> columnDataMap = rowData.getColumnDataMap();
                        values.add(switchFieldType(columnDataMap, fieldCode, fieldValueFormat));
                    }
                    binding.put(emailKey, String.join(",", values));
                }
            } else {
                binding.put(emailKey, switchFieldType(formData, fieldCode, fieldValueFormat));
            }
        }
        return binding;
    }
    
    /**
     * 获取表单字段值
     *
     * @param formDataMap 表单细腻些
     * @param fieldCode        字段编码
     * @return 字段值
     */
    public static String switchFieldType(Map<String, FieldInfo> formDataMap, String fieldCode, String fieldValueFormat) {
        // dateRange filed data format: fieldCode->propertyFieldCode
        String[] fieldCodes = fieldCode.split("->");

        String value = DEFAULT_VALUE;
        FieldInfo fieldInfo = formDataMap.get(fieldCodes[0]);
        if (Objects.isNull(fieldInfo)) {
            log.info("get name:{} form data is null,", fieldCode);
            return value;
        }


        FieldValueTypeEnum fieldType = fieldInfo.getFieldType();
        com.cloudwise.dosm.api.bean.form.field.FieldValue fieldValue = fieldInfo.getFieldValueObj();
        if (fieldValue == null || fieldValue.getValue() == null) {
            return value;
        }
        switch (fieldType) {
            case NUMBER: //数字
            case INPUT: //单行文本
            case TEXTAREA: //多行文本
            case TIME://时间
            case EVALUATE_STAR: //星级评价
            case TEXT: //文字
            case MEMBER: //成员
            case GROUP: //成员组
            case RICH_TEXT: //富文本
                value = fieldValue.formatValue();
                break;
            case DATE: //日期
                value = getDateValue(((DateField) fieldValue), fieldValueFormat);
                break;
            case DATERANGE://日期范围
                value = getDateRangeValue(((DateRangeField) fieldValue), fieldCodes.length>=2? fieldCodes[1]: null, fieldValueFormat);
                break;
            case RADIO: //单选框
                RadioField radioField = (RadioField) fieldValue;
                value = radioField.getLabel();
                break;
            case CHECKBOX: //多选框
                CheckboxField checkboxField = (CheckboxField) fieldValue;
                Collection<String> labels = checkboxField.getLabel();
                if (CollUtil.isNotEmpty(labels)) {
                    value = String.join(",", labels);
                }
                break;
            case SELECT_MANY: //多选下拉框
                SelectManyField selectManyField = (SelectManyField) fieldValue;
                Collection<String> selLabels = selectManyField.getLabel();
                if (CollUtil.isNotEmpty(selLabels)) {
                    value = String.join(",", selLabels);
                }
                break;
            case SELECT: //单选下拉框
                SelectField selectField = (SelectField) fieldValue;
                value = selectField.getLabel();
                break;
            case MULTI_SELECT: //多级下拉
                MultiSelectField multiSelectField = (MultiSelectField) fieldValue;
                Collection<String> muLabels = multiSelectField.getLabel();
                if (CollUtil.isNotEmpty(muLabels)) {
                    value = String.join(",", muLabels);
                }
                break;
            case TABLE_FORM: //表格
            case UPLOAD: //上传
            case CMDB_MODEL: //模型配置
            case CMDB_CONFIG: //配置
            case CMDB_DATA://数据表配置项
            case CMDB_CONFIG_TAB: //配置项标签
            case QUOTE: //引用
            default:
                log.warn("not found field value type, fieldName: {}, fieldCode: {}, fieldType: {}", fieldCode, fieldCode, fieldType);
        }
        return value;
    }

    private static String getDateValue(DateField fieldValue, String fieldValueFormat) {
        if(fieldValue == null) {
            return DEFAULT_VALUE;
        }
        return getDateValue(fieldValue.getValue(), fieldValueFormat);
    }

    private static String getDateValue(Long dateTime, String fieldValueFormat) {
        if(dateTime == null) {
            return DEFAULT_VALUE;
        }
        return DateUtil.format(new Date(dateTime), fieldValueFormat);
    }

    private static String getDateRangeValue(DateRangeField fieldValue, String propertyCode, String fieldValueFormat) {
        if(fieldValue == null || fieldValue.getValue() == null) {
            return DEFAULT_VALUE;
        }
        if("startDate".equals(propertyCode)) {
            return getDateValue(fieldValue.getValue().getStartDate(), fieldValueFormat);
        } else if("endDate".equals(propertyCode)){
            return getDateValue(fieldValue.getValue().getEndDate(), fieldValueFormat);
        } else {
            return fieldValue.formatValue();
        }
    }
}