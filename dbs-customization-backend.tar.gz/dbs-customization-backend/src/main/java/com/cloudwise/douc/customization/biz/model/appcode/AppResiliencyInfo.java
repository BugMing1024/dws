package com.cloudwise.douc.customization.biz.model.appcode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Magina
 * @date 2024/12/24 6:30 下午
 * @description
 **/

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppResiliencyInfo {
    
    @JsonProperty("AppCode")
    private String appCode;
    
    @JsonProperty("Resiliency")
    private String resiliency;
}
