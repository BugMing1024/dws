package com.cloudwise.douc.customization.biz.model.email;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-05  15:09
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NormalValue implements Serializable {
    
    private static final long serialVersionUID = -5127403977457835896L;
    
    
    /**
     * 普通值
     */
    private List<String> values;
    
    /**
     * 用户id
     */
    private List<String> userIds;
    
    /**
     * 邮箱列表
     */
    private List<String> emails;
}
