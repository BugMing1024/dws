package com.cloudwise.douc.customization.biz.config;


import cn.hutool.core.collection.ListUtil;
import com.cloudwise.douc.customization.biz.constant.ExecutorType;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
@Data
@Slf4j
@Component
@ConfigurationProperties(prefix = SyncProperties.PREFIX)
public class SyncProperties implements InitializingBean {
    
    public static final String PREFIX = "sync";
    
    private Boolean enabled = false;
    
    private List<ExecutorType> activeExecutors = ListUtil.of(ExecutorType.STARTUP, ExecutorType.SCHEDULED, ExecutorType.REST);
    
    @NestedConfigurationProperty
    private ScheduledSyncExecutorProperties scheduled = new ScheduledSyncExecutorProperties();
    
    @Override
    public void afterPropertiesSet() {
        log.info("Sync properties loaded successfully: {}", JsonUtils.toJsonStr(this));
    }
}
