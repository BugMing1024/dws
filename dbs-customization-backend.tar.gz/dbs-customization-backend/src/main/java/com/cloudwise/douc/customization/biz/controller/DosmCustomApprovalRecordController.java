package com.cloudwise.douc.customization.biz.controller;

import com.cloudwise.douc.customization.biz.model.email.ApproveRecord;
import com.cloudwise.douc.customization.biz.model.email.ApproveRecordConfigVo;
import com.cloudwise.douc.customization.biz.model.email.ApproveRecordVo;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomApprovalRecordService;
import com.cloudwise.douc.customization.common.model.ApiResponse;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-26  10:58
 **/
@Slf4j
@RestController
@RequestMapping("/custom/api/")
public class DosmCustomApprovalRecordController {


    @Autowired
    DosmCustomApprovalRecordService dosmCustomApprovalRecordService;


    @GetMapping("/getApprovalRecords")
    public ApiResponse<Object> getApprovalRecords(String processInstanceId) {
        List<ApproveRecordVo> approvalRecords = dosmCustomApprovalRecordService.getApprovalRecords(processInstanceId);
        return ApiResponse.ok(approvalRecords);
    }

    @GetMapping("/getCustomApprovalRecords")
    public ApiResponse<List<ApproveRecord>> getCustomApprovalRecords(String workOrderId) {
        List<ApproveRecordConfigVo> approvalRecords = dosmCustomApprovalRecordService.getCustomApprovalRecords(workOrderId);
        log.info("Get approvalRecords is:{}", JsonUtils.toJsonStr(approvalRecords));
        List<ApproveRecord> records = dosmCustomApprovalRecordService.getRecords(approvalRecords);
        return new ApiResponse<>(100000, "success", records);
    }


}
