package com.cloudwise.douc.customization.biz.model.table;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

/**
 * 表单定义实体
 *
 * @author: damon.fu
 * @since: 2021-06-11 16:30
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("mdl_instance")
public class MdlInstance {
    
    /**
     * 主键ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String id;
    
    /**
     * 顶级租户ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String topAccountId;
    
    /**
     * 租户ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String accountId;
    
    /**
     * 模型编码
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String mdlDefCode;
    
    /**
     * 模型定义def_key
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String mdlDefKey;
    
    /**
     * 流程实例ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String processInstanceId;
    
    /**
     * 归属服务目录列表
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String serviceIds;
    
    /**
     * 归属服务项ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String serviceItemId;
    
    /**
     * 标题
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String title;
    
    /**
     * 工单编号
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String bizKey;
    
    /**
     * 业务描述
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String bizDesc;
    
    /**
     * 优先级 0低,1中,2高,紧急
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Long urgentLevel;
    
    /**
     * 是否测试 0否,1是
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Long isTest;
    
    /**
     * 工单来源 1,"网页表单" ， 2,"即时消息" {@code WorkOrderSourceCorvertEnum}
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String sourceId;
    
    /**
     * 优先使用：@see com.cloudwise.dosm.api.bean.enums.DosmWorkStatusEnum 其次使用：@see com.cloudwise.dosm.core.enums.DataStatusEnum 最后使用：@see
     * com.cloudwise.dosm.biz.calendar.enums.WorkOrderStatusEnum 状态 0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭  50 挂起
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Integer dataStatus;
    
    /**
     * 催办时间
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Timestamp urgedTime;
    
    /**
     * 表单业务数据
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Object formData;
    
    /**
     * 计划开始时间
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Timestamp planStartTime;
    
    /**
     * 计划结束时间
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Timestamp planEndTime;
    
    /**
     * 乐观锁
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private long revision;
    
    /**
     * 创建人ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String createdBy;
    
    /**
     * 创建时间
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Timestamp createdTime;
    
    /**
     * 修改人ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String updatedBy;
    
    /**
     * 修改时间
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Timestamp updatedTime;
    
    /**
     * 指派用户
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Object appointUser;
    
    /**
     * 0有效1删除
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private long isDel;
    
    /**
     * 节点id
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String nodeId;
    
    /**
     * 节点名称
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String nodeName;
    
    /**
     * taskId
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String taskId;
    
    /**
     * 工单类型
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String orderType;
    
    /**
     * 部门id
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String depId;
    
    /**
     * 部门深度
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String depLevel;
    
    /**
     * 草稿ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String workOrderNo;
    
    /**
     * 关联工单的临时工单ID
     */
    private String tempWorkOrderId;
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Integer vip;
    
    /**
     * code 是否逾期  逾期 OVERDUE  即将逾期 WILL_OVERDUE
     */
    private Integer slaStatus;
    
    /**
     * 是否是子流程工单
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String isSubProcessOrder;
    
    /**
     * 主流程的节点id
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String mainNodeId;
    
    /**
     * 子流程类型
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String subProcessType;
    
    /**
     * sla/ola  解决状态记录
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Object slaServiceStatus;
    
    /**
     * sla/ola  响应状态记录
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Object olaServiceStatus;
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String linkOrderTypeMes;
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String backStatus;
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String backNodes;
    
    //添加要展示的编码
    @JsonIgnoreProperties(ignoreUnknown = true)
    private List<String> showCode;
    
    /**
     * 父级工单创建人ID
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String parentCreatedBy;
    
    /**
     * 是否为草稿 默认false代表非草稿 true代表是草稿
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    @TableField(exist = false)
    private boolean draft;
    
}


