package com.cloudwise.douc.customization.biz.facade.user;

import lombok.Data;

@Data
public class Page {
    
    private long pageSize;
    
    private long totalCount;
    
    private long totalPageCount;
    
    private long currentPageNo;
    
}
