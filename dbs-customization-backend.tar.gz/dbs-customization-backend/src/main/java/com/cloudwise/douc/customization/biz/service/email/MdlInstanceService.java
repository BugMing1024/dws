package com.cloudwise.douc.customization.biz.service.email;

import com.cloudwise.douc.customization.biz.model.table.MdlInstance;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/23
 */
public interface MdlInstanceService {
    
    void updateMdlInstance2ClosedCancelOnOne();
    
    void updateMdlInstance2ClosedCancelOnFive();

    List<MdlInstance> getBizKeyFromCRStatusAndTime(Map<String,Object> map);
}
