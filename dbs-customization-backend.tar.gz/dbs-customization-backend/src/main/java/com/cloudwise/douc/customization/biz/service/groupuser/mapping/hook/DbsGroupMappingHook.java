package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;

import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.dto.v3.group.AddOrUpdateGroupReq;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@RequiredArgsConstructor
public class DbsGroupMappingHook implements MappingHook<DbsGroupInfo, AddOrUpdateGroupReq> {
    
    private final ExtendMapMappings extendMapMappings;
    
    @Override
    public void beforeMapping(DbsGroupInfo source) {
    
    }
    
    @Override
    public void afterMapping(DbsGroupInfo source, AddOrUpdateGroupReq target) {
        target.setAddUserCodes(source.getAddUserCodes());
        target.setRemoveUserCodes(source.getRemoveUserCodes());
        Map<String, String> mapping = extendMapMappings.mapping(source);
        target.setExtend(mapping);
    }
}
