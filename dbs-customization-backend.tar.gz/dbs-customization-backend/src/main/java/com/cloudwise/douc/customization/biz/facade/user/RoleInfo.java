package com.cloudwise.douc.customization.biz.facade.user;


import lombok.Data;

@Data
public class RoleInfo {
    
    
    /**
     * 角色id
     */
    private String id;
    
    /**
     * 角色组id
     */
    private String roleGroupId;
    
    /**
     * 角色组名称
     */
    private String name;
    
    /**
     * 租户id
     */
    private Integer accountId;
    
    /**
     * 类型
     */
    private Integer type;
    
    /**
     * 角色关联用户数
     */
    private Integer perNum;
    
    /**
     * 角色关联活跃用户数
     */
    private Integer perNumInUse;
    
    
}
