package com.cloudwise.douc.customization.biz.model.appcode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author Magina
 * @date 2024/12/24 6:01 下午
 * @description
 **/

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppCodeInfo {
    
    @JsonProperty("APPID")
    private String appId;
    
    @JsonProperty("APPNAME")
    private String appName;
    
    @JsonProperty("APPOWNER")
    private String appOwner;
    
    @JsonProperty("APPCATLEVEL")
    private String appCatLevel;
    
    @JsonProperty("LOCATION")
    private String location;
    
    @JsonProperty("SUPPLIER")
    private String supplier;
    
    @JsonProperty("LIFECYCLESTATE")
    private String lifeCycleState;
    
    @JsonProperty("SME1")
    private String sme1;
    
    @JsonProperty("SME2")
    private String sme2;
    
    @JsonProperty("HOSTINGLOC")
    private String hostingLoc;
    
    @JsonProperty("INFOTYPE")
    private String infoType;
    
    @JsonProperty("SUPPORTUNIT")
    private String supportUnit;
    
    @JsonProperty("TECHMD_EMAIL")
    private String techmdEmail;
    
    @JsonProperty("SME1_EMAIL")
    private String sme1Email;
    
    @JsonProperty("SME2_EMAIL")
    private String sme2Email;
    
    @JsonProperty("APP_OWNER_EMAIL")
    private String appOwnerEmail;
    
    @JsonProperty("PLATFORM")
    private String platForm;
    
    @JsonProperty("PLATFORMSUPPLIER")
    private String platFormSupplier;
    
    @JsonProperty("MAS")
    private String mas;
    
    @JsonProperty("CII")
    private String cii;
    
    @JsonProperty("CAC")
    private String cac;
    
    @JsonProperty("APPHANDOVER")
    private String appHandover;
    
    @JsonProperty("DATACLASS")
    private String dataClass;
    
    @JsonProperty("SECONDARY_APP_OWNER")
    private String secondaryAppOwner;
    
    @JsonProperty("SECONDARY_APP_OWNER_EMAIL")
    private String secondaryAppOwnerEmail;
    
    @JsonProperty("Resiliency")
    private String resiliency;
    
    private Date saveDate;
    
//    private Integer id;
    
    
}
