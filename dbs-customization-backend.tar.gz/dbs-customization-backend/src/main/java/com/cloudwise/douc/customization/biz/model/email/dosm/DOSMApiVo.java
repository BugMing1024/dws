package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.Data;

/**
 * dosm的对象
 */
@Data
public class DOSMApiVo<T> {
    
    private String status;
    
    private String msg;
    
    private Integer code;
    
    private T data;
    
}
