package com.cloudwise.douc.customization.biz.service.appcode;

import com.cloudwise.douc.customization.biz.model.appcode.AppCodeReq;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/18
 */
public interface AppcodeLobCountryService {
    
    Boolean checkMasFlag(AppCodeReq appCodeReq);
}
