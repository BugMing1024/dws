package com.cloudwise.douc.customization.biz.model.groupuser;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.anno.ExtendMapProperty;
import com.cloudwise.douc.customization.biz.anno.MappingProperty;
import com.cloudwise.douc.dto.v3.common.GroupInfo;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
public class DbsGroupInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @MappingProperty("accountId")
    private Long accountId = 110L;
    
    private Long id;
    
    @MappingProperty("name")
    private String name;
    
    @MappingProperty("code")
    private String code;
    
    @MappingProperty("leaderCode")
    private String ownerCode;
    
    @ExtendMapProperty("lob")
    private String lob;
    
    @ExtendMapProperty("country")
    private String country;
    
    @ExtendMapProperty("appCode")
    private String appCode;
    
    private Integer type = 1;
    
    private String label;
    
    
    @MappingProperty("parentCode")
    private String parentCode;
    
    @ExtendMapProperty("groupType")
    private String groupType;
    
    @MappingProperty("description")
    private String description;
    
    
    private List<GroupInfo> children;
    
    private List<String> addUserCodes;
    
    private List<String> removeUserCodes;
    
    private List<String> addDepartmentCodes;
    
    
    private List<String> removeDepartmentCodes;
    
    private String groupRole;
    
    @ExtendMapProperty("hasLOBCountryMapping")
    private String hasLOBCountryMapping;
    
    @ExtendMapProperty("allRank")
    private String allRank;
    
    private Set<String> rank = new HashSet<>();
    
    public void setParentCode(String parentCode) {
        setParentCode(parentCode, parentCode);
    }
    
    public void setParentCode(String parentCode, String defaultCode) {
        this.parentCode = parentCode;
        if (StrUtil.isBlank(groupType)) {
            groupType = defaultCode;
        }
    }
    
    
    public void addRank(String rank) {
        if (StrUtil.isBlank(rank)) {
            return;
        }
        for (String s : rank.split(",")) {
            this.rank.add(s);
        }
    }
    
    public void finish() {
        if (CollUtil.isEmpty(rank)) {
            return;
        }
        allRank = String.join(",", rank);
    }
}
