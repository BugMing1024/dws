package com.cloudwise.douc.customization.biz.service.email;

import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.SendForApprovalVo;
import com.cloudwise.douc.customization.biz.service.msg.model.bean.ApproveParam;

/**
 * @author ming.ma
 * @since 2024-12-09  09:50
 **/
public interface DosmCustomService {

    boolean sendMessage(MessageContext messageContext);


    boolean emailApprove(String sender, String subject, ApproveParam approveParam, String body);

    void uncloseNotify(MessageContext messageContext);


    boolean sendForApproval(SendForApprovalVo sendForApprovalVo);

    void sendApprovalMessage(String workOrderId, String notifyScene, String userId);
}
