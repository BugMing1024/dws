package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.IdUtil;
import com.cloudwise.dosm.api.bean.form.DateRange;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.api.bean.form.field.DateRangeField;
import com.cloudwise.dosm.api.bean.form.field.FieldValue;
import com.cloudwise.dosm.api.bean.form.field.SelectField;
import com.cloudwise.dosm.api.bean.utils.JsonUtils;
import com.cloudwise.douc.customization.biz.dao.MdlInstanceMapper;
import com.cloudwise.douc.customization.biz.enums.*;
import com.cloudwise.douc.customization.biz.facade.UserSSOClient;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.handler.NotificationSenderManager;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.biz.model.table.CustomDelayMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomDelayMessageRecordService;
import com.cloudwise.douc.customization.biz.service.email.DosmApiService;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.biz.service.msg.model.bean.ApproveParam;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.MsgAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author ming.ma
 * @since 2024-12-09  09:50
 **/
@Slf4j
@Service
public class DosmCustomServiceImpl implements DosmCustomService {


    @Lazy
    @Autowired
    DosmApiService dosmApiService;

    @Autowired
    UserSSOClient userSSOClient;

    @Autowired
    DosmConfig dosmConfig;

    @Autowired
    MdlInstanceMapper mdlInstanceMapper;

    @Autowired
    CustomDelayMessageRecordService customDelayMessageRecordService;

    @Autowired
    NotificationSenderManager notificationSenderManager;

    @Autowired
    private DosmWorkOrderService dosmWorkOrderService;

    @Override
    public boolean sendMessage(MessageContext messageContext) {
        try {
            NotifyVo emailNotify = messageContext.getNotify();
            if (Objects.isNull(emailNotify)) {
                log.info("SendMessage notify config is empty,skip send");
                return false;
            }
            NotifyScenceEnum notifyScene = emailNotify.getNotifyScene();
            //1.组装消息内容
            if (null == notifyScene) {
                log.info("No email notification scenario:[{}] found ", notifyScene);
                return false;
            }

            // tmp Record id
            messageContext.setTmpRecordId(IdUtil.simpleUUID());
            log.info("SendMessage messageContext param:{}", messageContext);
            String workOrderId = messageContext.getWorkOrderId();
            if (CharSequenceUtil.isBlank(workOrderId)) {
                log.info("SendMessage workOrderId is empty,skip send");
                return false;
            }

            MessageVo message = MsgAnalysisUtil.getMessage(messageContext);

            //2.发送消息
            if (!CharSequenceUtil.isAllNotBlank(message.getTitle(), message.getBody())) {
                log.info("Get email message title or body is empty, notifyWay: {}, notifyScene:{}, title: {}, workOrderId:{}", message.getNotifyWay(), message.getNotifyScene(), message.getTitle(), message.getWorkOrderId());
                return false;
            }
            if (CollUtil.isEmpty(message.getReceivers())) {
                log.info("Get email message receivers is empty, notifyWay: {}, notifyScene:{}, title: {}, workOrderId:{}", message.getNotifyWay(), message.getNotifyScene(), message.getTitle(), message.getWorkOrderId());
                return false;
            }
            log.info("SendMessage message notifyWay: {}, notifyScene:{}, title: {}, workOrderId:{}", message.getNotifyWay(), message.getNotifyScene(), message.getTitle(), message.getWorkOrderId());
            notificationSenderManager.send(message);
            log.info("SendMessage send message success");
        } catch (Exception e) {
            log.error("SendMessage message fail, messageContext:{}", messageContext, e);
            return false;
        }
        return true;
    }

    @Override
    public boolean emailApprove(String sender, String subject, ApproveParam approveParam, String body) {
        log.info("[邮件审批] Email approve param: sender:{},subject:{},body:{}", sender, subject, body);
        try {
            String userName = EmailAnalysisUtil.getUserNameByEmail(sender);
            log.info("[邮件审批] Analysis email userName :{}", userName);
            if (CharSequenceUtil.isBlank(userName)) {
                log.info("[邮件审批] Analysis email userName is empty");
                return false;
            }
            List<String> groupIds = new ArrayList<>();
            String userId = "";
            List<UserInfo> userListByEmail = userSSOClient.getUsersByAliasList(Lists.newArrayList(userName), dosmConfig.getUserId(), dosmConfig.getAccountId());
            //List<UserInfo> userListByEmail = userSSOClient.getUserListByEmail(dosmConfig.getUserId(), dosmConfig.getAccountId(), sender);
            if (CollUtil.isNotEmpty(userListByEmail)) {
                userId = String.valueOf(userListByEmail.get(0).getUserId());
                List<Long> userGroupIds = userListByEmail.get(0).getGroupIds();
                if (CollUtil.isNotEmpty(groupIds)) {
                    groupIds = userGroupIds.stream().map(String::valueOf).collect(Collectors.toList());
                }
            }
            if (CharSequenceUtil.isBlank(userId)) {
                log.info("[邮件审批] Email approve user info is empty,sender:{}", sender);
                //userId = dosmConfig.getUserId();
                return false;
            }


            log.info("[邮件审批] Email approve workOrderId is :{}", approveParam.getWorkOrderId());
            if (CharSequenceUtil.isBlank(approveParam.getWorkOrderId())) {
                log.info("[邮件审批] Email approve get workOrderId is empty:{}", sender);
                return false;
            }

            ApproveOrderVo approveOrder = ApproveOrderVo.builder()
                    .workOrderId(approveParam.getWorkOrderId())
                    .approveStatus(approveParam.getStatus())
                    .signOffId(approveParam.getSignOffId())
                    .stage(StringUtils.isBlank(approveParam.getSignOffId()) ? CRStageEnum.APPROVAL : CRStageEnum.SIGN_OFF)
                    .userId(userId)
                    .groupIds(groupIds)
                    .emailContent(null)
                    .build();
            return dosmApiService.approveOrder(approveOrder);
        } catch (Exception e) {
            log.error("[邮件审批] Email approve fail:", e);
            return false;
        }
    }

    @Override
    public void uncloseNotify(MessageContext messageContext) {
        String userId = messageContext.getUserId();
        String workOrderId = messageContext.getWorkOrderId();
        String nodeId = messageContext.getNodeId();
        if (CharSequenceUtil.isBlank(workOrderId)) {
            log.info("UncloseNotify workOrderId is empty,skip send");
            return;
        }
        if (CharSequenceUtil.isBlank(userId)) {
            log.info("[邮件审批] UncloseNotify approve user info is empty");
            userId = dosmConfig.getUserId();
        }
        Map<String, FieldInfo> formData = dosmWorkOrderService.getFormData(workOrderId, userId);
        if (formData == null) {
            log.info("UncloseNotify formData is empty,skip send");
            return;
        }
        DosmConfig.UncloseNotify uncloseNotify = dosmConfig.getUncloseNotify();
        if (uncloseNotify == null) {
            log.info("UncloseNotify config  is empty,skip send");
            return;
        }
        log.info("UncloseNotify start match status");
        String statusKey = uncloseNotify.getStatusKey();
        String statusKeyValue = uncloseNotify.getStatusKeyValue();
        String nodeIdKey = uncloseNotify.getNodeId();
        String dateRangeKey = uncloseNotify.getDateRangeKey();
        long time = uncloseNotify.getTime();
        long day = uncloseNotify.getDay();
        if (CharSequenceUtil.isNotBlank(statusKey) && CharSequenceUtil.isNotBlank(statusKeyValue) && CharSequenceUtil.equals(nodeIdKey, nodeId)) {
            log.info("UncloseNotify config match statusKey:{},statusKeyValue:{},nodeIdKey:{}", statusKey, statusKeyValue, nodeIdKey);
            FieldInfo fieldInfo = formData.get(statusKey);
            if (fieldInfo == null) {
                log.info("UncloseNotify get fieldInfo is empty. statusKey:{},statusKeyValue:{},nodeIdKey:{}", statusKey, statusKeyValue, nodeIdKey);
                return;
            }
            FieldValue statusValue = fieldInfo.getFieldValueObj();
            if (statusValue == null) {
                log.info("UncloseNotify get statusValue is empty. statusKey:{},statusKeyValue:{},nodeIdKey:{}", statusKey, statusKeyValue, nodeIdKey);
                return;
            }
            String formatValue;
            FieldValueTypeEnum statusFieldType = fieldInfo.getFieldType();
            if (FieldValueTypeEnum.SELECT.equals(statusFieldType)) {
                formatValue = ((SelectField) statusValue).getLabel();
            } else {
                formatValue = statusValue.formatValue();
            }
            log.info("UncloseNotify get form status value :{}", formatValue);

            if (CharSequenceUtil.equals(statusKeyValue, formatValue)) {
                log.info("UncloseNotify order status match");
                FieldInfo dateRangeFileInfo = formData.get(dateRangeKey);
                if (dateRangeFileInfo == null) {
                    log.info("UncloseNotify dateRangeFileInfo is empty");
                    return;
                }
                log.info("UncloseNotify handler date range");
                DateRangeField dateRangeFieldValue = (DateRangeField) dateRangeFileInfo.getFieldValueObj();
                DateRange dateRange = dateRangeFieldValue.getValue();
                Long endDate = dateRange.getEndDate();
                Long startDate = dateRange.getStartDate();
                long exeAt = endDate + day * time;
                log.info("UncloseNotify exeAt date is:{}", exeAt);
                CustomDelayMessageRecord notifyMessage = customDelayMessageRecordService.getNotifyMessages(messageContext.getWorkOrderId(),
                        messageContext.getNodeId());
                if (notifyMessage != null) {
                    notifyMessage.setStartTime(new Date(startDate));
                    notifyMessage.setEndTime(new Date(endDate));
                    notifyMessage.setExecAt(new Date(exeAt));
                    notifyMessage.setNotifyContent(JsonUtils.toJsonString(messageContext));
                    Date date = new Date();
                    notifyMessage.setUpdatedBy(messageContext.getCreatedBy());
                    notifyMessage.setUpdatedTime(date);
                    notifyMessage.setCreatedTime(date);
                    customDelayMessageRecordService.updateDelayMessageRecord(Lists.newArrayList(notifyMessage));
                    log.info("UncloseNotify update delay message success,id:{}", notifyMessage.getId());
                } else {
                    CustomDelayMessageRecord customDelayMessageRecord = CustomDelayMessageRecord.buildInsertInfo(messageContext);
                    customDelayMessageRecord.setStartTime(new Date(startDate));
                    customDelayMessageRecord.setEndTime(new Date(endDate));
                    customDelayMessageRecord.setExecAt(new Date(exeAt));
                    customDelayMessageRecordService.insertRecord(customDelayMessageRecord);
                    log.info("UncloseNotify insert delay message success,id:{}", customDelayMessageRecord.getId());
                }
            }
        }
    }

    @Override
    public boolean sendForApproval(SendForApprovalVo sendForApprovalVo) {
        String nodeId = sendForApprovalVo.getNodeId();
        String mdlDefKey = sendForApprovalVo.getMdlDefKey();
        String workOrderId = sendForApprovalVo.getWorkOrderId();
        String userId = sendForApprovalVo.getUserId();
        Map<String, List<DosmConfig.NodeConfig>> processConfig = dosmConfig.getProcessConfig();
        if (CollUtil.isEmpty(processConfig)) {
            log.info("SendForApproval get processConfig is empty");
            return false;
        }
        List<DosmConfig.NodeConfig> nodeConfigs = processConfig.get(mdlDefKey);
        if (CollUtil.isEmpty(nodeConfigs)) {
            log.info("SendForApproval get nodeConfigs is empty");
            return false;
        }
        for (DosmConfig.NodeConfig nodeConfig : nodeConfigs) {
            String configNodeId = nodeConfig.getNodeId();
            String rejectKey = nodeConfig.getRejectKey();
            if (CharSequenceUtil.equals(nodeId, configNodeId)) {
                String notifyScene = nodeConfig.getNotifyScene();
                boolean skipSend = nodeConfig.isSkipSend();
                //send message
                if (!skipSend) {
                    sendApprovalMessage(workOrderId, notifyScene, userId);
                }
                mdlInstanceMapper.updateFormDataByFieldKey(workOrderId, rejectKey, "");
                return true;
            }
        }
        return false;
    }

    @Override
    public void sendApprovalMessage(String workOrderId, String notifyScene, String userId) {
        // 发送邮件
        MessageContext messageContext = new MessageContext();
        messageContext.setWorkOrderId(workOrderId);
        messageContext.setUserId(userId);
        messageContext.setCreatedBy(userId);
        messageContext.setTopAccountId(dosmConfig.getTopAccountId());
        messageContext.setAccountId(dosmConfig.getAccountId());
        NotifyVo notifyVo = new NotifyVo();
        notifyVo.setChannelType(NotifyWayEnum.EMAIL);
        notifyVo.setReceivers(Lists.newArrayList(ValueContent.builder()
                .type(ValueTypeEnum.NORMAL)
                .normalValue(NormalValue.builder().userIds(Lists.newArrayList(userId)).build())
                .build())
        );
        messageContext.setNotify(notifyVo);
        NotifyScenceEnum scenceEnum = null;
        if (CharSequenceUtil.isNotBlank(notifyScene)) {
            scenceEnum = NotifyScenceEnum.of(notifyScene);
        } else {
            WorkOrderDetail workOrderDetail = dosmWorkOrderService.getWorkOrderDetail(workOrderId, userId);
            if (null == workOrderDetail) {
                return;
            }
            Map<String, String> publicFields = new HashMap<>();
            EmailAnalysisUtil.buildPublicFields(workOrderDetail, publicFields);
            messageContext.setPublicFields(publicFields);
            messageContext.setNodeId(workOrderDetail.getCurrentNodeId());

            String formData = workOrderDetail.getFormData();
            JsonNode formJson = JsonUtils.parseJsonNode(formData);
            JsonNode sdNode = formJson.get("ScheduledDowntime_Time");
            log.info("SendApprovalMessage ScheduledDowntime_Time is :{}", sdNode);
            if (sdNode != null && !sdNode.isNull()) {
                scenceEnum = NotifyScenceEnum.CR_OPEN_AVE_SCHEDULED_DOWNTIME_APPROVAL;
            } else {
                JsonNode smNode = formJson.get("ScheduledMaintenance_Time");
                log.info("SendApprovalMessage ScheduledMaintenance_Time is :{}", smNode);
                if (smNode != null && !smNode.isNull()) {
                    scenceEnum = NotifyScenceEnum.CR_OPEN_AVE_SCHEDULED_MAINTENANCE_APPROVAL;
                }
            }
        }
        notifyVo.setNotifyScene(scenceEnum);
        if (scenceEnum == null) {
            log.info("SendApprovalMessage scenceEnum is empty");
            return;
        }
        boolean result = this.sendMessage(messageContext);
        log.info("SendApprovalMessage result:{}", result);
    }

}
