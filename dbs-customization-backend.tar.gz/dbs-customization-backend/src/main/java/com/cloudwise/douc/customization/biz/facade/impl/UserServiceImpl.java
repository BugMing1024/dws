package com.cloudwise.douc.customization.biz.facade.impl;

import com.cloudwise.douc.customization.biz.facade.UserService;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.facade.user.UserPage;
import com.cloudwise.douc.customization.biz.facade.user.UserRoleInfo;
import com.cloudwise.douc.dto.*;
import com.cloudwise.douc.dto.v3.common.CommonResp;
import com.cloudwise.douc.dto.v3.common.PageResp;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.cloudwise.douc.facade.UserV2DubboFacade;
import com.cloudwise.douc.facadev3.UserFacade;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  18:10
 **/
@Slf4j
@Service
public class UserServiceImpl implements UserService {

    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserV2DubboFacade userV2DubboFacade;

    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserFacade userFacade;

    @Autowired
    private Gson gson;

    @Override
    public DubboCommonResp<List<UserInfo>> getUserListByIds(DubboIdsReq req) {
        DubboCommonResp<List<UserInfo>> result;
        log.info("Request UserV2DubboFacade.getUserListByIds start,params:{}", req);
        try {
            DubboCommonResp<String> userListByIds = userV2DubboFacade.getUserListByIds(req);
            if (!userListByIds.isSuccess()) {
                log.error("Request UserV2DubboFacade.getUserListByIds failed,msg:{}", userListByIds.getMsg());
                result = new DubboCommonResp<List<UserInfo>>().generateFailResp();
                result.setMsg(userListByIds.getMsg());
                return result;
            }
            log.info("Request UserV2DubboFacade.getUserListByIds success:{}", userListByIds);
            result = new DubboCommonResp<List<UserInfo>>().generateSuccessResp(
                    (List<UserInfo>) gson.fromJson(userListByIds.getData(), new TypeToken<List<UserInfo>>() {
                    }.getType()));
        } catch (Exception e) {
            result = new DubboCommonResp<List<UserInfo>>().generateFailResp();
            log.error("Request UserV2DubboFacade.getUserListByIds failed,cause by:{}", e);
        }
        return result;
    }

    @Override
    public DubboCommonResp<List<UserRoleInfo>> getRoloInfosByUserId(DubboUserIdAccountIdRequest req) {
        DubboCommonResp<List<UserRoleInfo>> result;
        log.info("Request UserV2DubboFacade.getRoloInfosByUserId start,params:{}", req);
        try {
            DubboCommonResp<String> users = userV2DubboFacade.getRoloInfosByUserId(req);
            if (!users.isSuccess()) {
                log.error("Request UserV2DubboFacade.getRoloInfosByUserId failed,msg :{}", users.getMsg());
                result = new DubboCommonResp<List<UserRoleInfo>>().generateFailResp();
                result.setMsg(users.getMsg());
                return result;
            }
            log.info("Request UserV2DubboFacade.getRoloInfosByUserId success:{}", users);
            result = new DubboCommonResp<List<UserRoleInfo>>().generateSuccessResp(
                    (List<UserRoleInfo>) gson.fromJson(users.getData(), new TypeToken<List<UserRoleInfo>>() {
                    }.getType()));
        } catch (Exception e) {

            result = new DubboCommonResp<List<UserRoleInfo>>().generateFailResp();
            log.error("Request UserV2DubboFacade.getRoloInfosByUserId failed,cause by:{}", e);
        }

        return result;
    }

    @Override
    public DubboCommonResp<UserPage> getUserListByParam(DubboRpcQueryParams req) {
        DubboCommonResp<UserPage> result;
        log.info("Request UserV2DubboFacade.getUserListByParam start,params:{}", req);
        try {
            DubboCommonResp<String> userlist = userV2DubboFacade.getUserListByParam(req);
            if (!userlist.isSuccess()) {
                log.error("Request UserV2DubboFacade.getUserListByParam failed,msg :{}", userlist.getMsg());
                result = new DubboCommonResp<UserPage>().generateFailResp();
                result.setMsg(userlist.getMsg());
                return result;
            }
            log.info("Request UserV2DubboFacade.getUserListByParam success:{}", userlist);
            result = new DubboCommonResp<UserPage>().generateSuccessResp(gson.fromJson(userlist.getData(), UserPage.class));
        } catch (Exception e) {

            result = new DubboCommonResp<UserPage>().generateFailResp();
            log.error("Request UserV2DubboFacade.getUserListByParam failed,cause by:{}", e);
        }

        return result;
    }

    @Override
    public UserInfo getUserDetailInfoById(String userId, String accountId) {
        DubboUserIdAccountIdRequest req = new DubboUserIdAccountIdRequest();
        long userIdLong = Long.parseLong(userId);
        req.setAccountId(Long.parseLong(accountId));
        req.setUserId(userIdLong);
        UserInfo result;
        log.info("Request UserV2DubboFacade.getUserDetailInfoById start,params:{}", req);
        try {
            DubboCommonResp<String> userDetailInfoById = userV2DubboFacade.getUserDetailInfoById(req);
            if (!userDetailInfoById.isSuccess()) {
                log.error("Request UserV2DubboFacade.getUserDetailInfoById failed,msg :{}", userDetailInfoById.getMsg());
                return null;
            }
            log.info("Request UserV2DubboFacade.getUserDetailInfoById success,detailData:{}", userDetailInfoById);
            result = new DubboCommonResp<UserInfo>().generateSuccessResp(gson.fromJson(userDetailInfoById.getData(), UserInfo.class)).getData();
            if (null == result.getRoleIds()) {
                result.setRoleIds(Lists.newArrayList());
            }
            if (null == result.getGroupIds()) {
                result.setGroupIds(Lists.newArrayList());
            }
        } catch (Exception e) {

            result = null;
            log.error("Request UserV2DubboFacade.getUserDetailInfoById failed,cause by:", e);
        }

        return result;
    }

    @Override
    public DubboCommonResp<List<UserInfo>> getUsersByAliasList(DubboUserAliasReq req) {
        DubboCommonResp<List<UserInfo>> result;
        log.info("Request UserV2DubboFacade.getUsersByAliasList start,params:{}", req);
        try {
            DubboCommonResp<String> usersByAliasList = userV2DubboFacade.getUsersByAliasList(req);
            if (!usersByAliasList.isSuccess()) {
                log.error("Request UserV2DubboFacade.getUsersByAliasList failed,msg:{}", usersByAliasList.getMsg());
                result = new DubboCommonResp<List<UserInfo>>().generateFailResp();
                result.setMsg(usersByAliasList.getMsg());
                return result;
            }
            log.info("Request UserV2DubboFacade.getUsersByAliasList success:{}", usersByAliasList);
            result = new DubboCommonResp<List<UserInfo>>().generateSuccessResp(gson.fromJson(usersByAliasList.getData(), new TypeToken<List<UserInfo>>() {
            }.getType()));
        } catch (Exception e) {

            result = new DubboCommonResp<List<UserInfo>>().generateFailResp();
            log.error("Request UserV2DubboFacade.getUsersByAliasList failed,cause by:{}", e);
        }

        return result;
    }



    @Override
    public PageResp<com.cloudwise.douc.dto.v3.common.UserInfo> getUserByCondition(UserConditionReq req) {
        try {
            CommonResp<PageResp<com.cloudwise.douc.dto.v3.common.UserInfo>> userPageListResp = userFacade.getUserByCondition(req);
            if (!userPageListResp.isSuccess()) {
                log.error("Request userFacade.getUserByCondition failed,msg:{}", userPageListResp.getMsg());
                return null;
            }
            log.info("Request userFacade.getUserByCondition success:{}", userPageListResp.getData());
            return userPageListResp.getData();
        } catch (Exception e) {
            log.error("Request userFacade.getUserByCondition failed,params:{}", req, e);
            throw e;
        }
    }
}
