package com.cloudwise.douc.customization.biz.service.groupuser.processor;

import com.cloudwise.douc.customization.biz.constant.BusinessType;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.Mapper;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.MapperFactory;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.MappingHook;
import com.cloudwise.douc.customization.biz.service.groupuser.reader.Reader;
import com.cloudwise.douc.customization.biz.service.groupuser.writer.Writer;
import com.cloudwise.douc.customization.common.context.ExecutorContext;
import com.cloudwise.douc.customization.common.context.ExecutorContextHolder;
import com.cloudwise.douc.customization.common.context.ProcessorCountContext;
import com.cloudwise.douc.customization.common.util.SpringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.ApplicationContext;
import org.springframework.core.ResolvableType;
import org.springframework.util.Assert;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created on 2022-4-21.
 *
 * @author skiya
 */
@Slf4j
public abstract class AbstractSyncProcessor<S, T> implements SyncProcessor, InitializingBean {
    
    protected List<BusinessType> businessType;
    
    private Reader<S> reader;
    
    private Writer<T> writer;
    
    private Mapper<S, T> mapper;
    
    public void setBusinessType(List<BusinessType> businessType) {
        this.businessType = businessType;
    }
    
    @Override
    public void init() {
        Optional.ofNullable(ExecutorContextHolder.get()).ifPresent(ctx -> {
            ProcessorCountContext processorCountContext = new ProcessorCountContext();
            processorCountContext.init(this.reader.getElementClass().getSimpleName());
            ctx.setProcessorCountContext(processorCountContext);
        });
    }
    
    public void start() {
        this.write(this.read());
    }
    
    @Override
    public void afterDone() {
        Optional.ofNullable(ExecutorContextHolder.get()).map(ExecutorContext::getProcessorCountContext).ifPresent(ctx -> {
            String dataName = ctx.getDataName();
            Integer readCount = ctx.getReadCount();
            Integer writeCount = ctx.getWriteCount();
            Integer failedCount = ctx.getFailedCount();
            log.info("{} data sync done, total read: {}, total write: {}, failed: {}", dataName, readCount, writeCount, failedCount);
        });
    }
    
    public final void write(List<S> sourceValues) {
        List<T> targetValues = mapper.convert(sourceValues);
        Optional.ofNullable(ExecutorContextHolder.get()).map(ExecutorContext::getProcessorCountContext)
                .ifPresent(context -> context.updateWriteCount(targetValues.size()));
        this.writer.write(targetValues);
        this.writer.afterWrite(targetValues);
    }
    
    public final List<S> read(Object... params) {
        List<S> sourceValues = reader.afterRead(reader.read(params));
        Optional.ofNullable(ExecutorContextHolder.get()).map(ExecutorContext::getProcessorCountContext)
                .ifPresent(context -> context.updateReadCount(sourceValues.size()));
        return sourceValues;
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public void afterPropertiesSet() {
        ApplicationContext context = SpringUtils.getApplicationContext();
        context.getBeanProvider(
                        ResolvableType.forClassWithGenerics(Reader.class, ResolvableType.forType(this.getClass()).getSuperType().getGeneric(0))).stream()
                .findFirst().ifPresent(bean -> this.reader = (Reader<S>) bean);
        context.getBeanProvider(
                        ResolvableType.forClassWithGenerics(Writer.class, ResolvableType.forType(this.getClass()).getSuperType().getGeneric(1))).stream()
                .findFirst().ifPresent(bean -> this.writer = (Writer<T>) bean);
        Assert.notNull(reader, "Reader is null");
        Assert.notNull(writer, "Writer is null");
        Collection<MappingHook<S, T>> mappingHooks = new HashSet<>();
        mappingHooks.addAll(this.getDefaultMappingHooks());
        mappingHooks.addAll(this.getMappingHooks());
        this.mapper = MapperFactory.getMapper(this.reader.getElementClass(), this.writer.getElementClass(), mappingHooks);
    }
    
    private Collection<MappingHook<S, T>> getDefaultMappingHooks() {
        ResolvableType resolvableType = ResolvableType.forClassWithGenerics(MappingHook.class, ResolvableType.NONE,
                ResolvableType.forType(this.writer.getElementClass()));
        ObjectProvider<MappingHook<S, T>> provider = SpringUtils.getApplicationContext().getBeanProvider(resolvableType);
        return provider.stream().collect(Collectors.toSet());
    }
    
    private Collection<MappingHook<S, T>> getMappingHooks() {
        ResolvableType resolvableType = ResolvableType.forClassWithGenerics(MappingHook.class, ResolvableType.forType(this.reader.getElementClass()),
                ResolvableType.forType(this.writer.getElementClass()));
        ObjectProvider<MappingHook<S, T>> provider = SpringUtils.getApplicationContext().getBeanProvider(resolvableType);
        return provider.stream().collect(Collectors.toSet());
    }
}
