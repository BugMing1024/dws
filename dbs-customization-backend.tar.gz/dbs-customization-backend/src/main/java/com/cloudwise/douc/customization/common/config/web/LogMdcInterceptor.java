package com.cloudwise.douc.customization.common.config.web;

import cn.hutool.core.util.IdUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 日志mdc拦截器 在请求上下文添加日志traceId
 *
 * @author skiya
 * @date Created on 2021-9-24.
 */
@Slf4j
@Component
public class LogMdcInterceptor implements HandlerInterceptor {
    
    /**
     * 用来日志追踪的traceId
     */
    public static final String TRACE_ID = "traceId";
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 放入当前请求线程中去
        MDC.put(TRACE_ID, IdUtil.simpleUUID());
        return true;
    }
    
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        // 执行完成后清除，防止线程复用 污染数据
        MDC.clear();
    }
}
