package com.cloudwise.douc.customization.biz.facade;

import com.cloudwise.douc.customization.biz.facade.user.RoleInfo;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboIdsReq;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  18:52
 **/
public interface RoleService {
    
    DubboCommonResp<List<RoleInfo>> getRoleListByIds(DubboIdsReq req);
    
}
