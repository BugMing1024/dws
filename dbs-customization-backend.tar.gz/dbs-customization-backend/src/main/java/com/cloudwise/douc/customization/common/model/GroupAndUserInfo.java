package com.cloudwise.douc.customization.common.model;

import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupDetail;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsRespCommonGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.ImplementerGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.MdApproveGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.UserTSO;
import com.google.common.collect.Lists;
import lombok.Data;

import java.util.List;

/**
 * 用户和组数据
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-22 01:24; update at 2024-12-22 01:24
 */
@Data
public class GroupAndUserInfo {
    
    private List<DbsRespCommonGroup> approveGroups = Lists.newArrayList();
    
    private List<ImplementerGroup> implementerGroups = Lists.newArrayList();
    
    private List<MdApproveGroup> mdApproveGroups = Lists.newArrayList();
    
    private List<DbsRespCommonGroup> releaseGroups = Lists.newArrayList();
    
    private List<DbsRespCommonGroup> changeGroups = Lists.newArrayList();
    
    private List<UserTSO> users = Lists.newArrayList();
}
