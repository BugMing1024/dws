package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.cache.utils.RedisUtils;
import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.constant.BusinessType;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.service.groupuser.processor.DoucGroupSyncProcessor;
import com.cloudwise.douc.customization.biz.service.groupuser.processor.DoucUserSyncProcessor;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import com.google.common.collect.Lists;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 所有映射的处理
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-22 01:06; update at 2024-12-22 01:06
 */
@Slf4j
@RestController()
@SyncEndpoint(name = "approve")
@RequestMapping("/approve")
@Conditional(value = SyncCheckCondition.class)
public class ApproveGroupSyncJob {
    
    @Autowired
    private DoucProperties properties;
    
    @Autowired
    private DbsProperties dbsProperties;
    
    @Autowired
    private DoucGroupSyncProcessor groupSyncProcessor;
    
    @Autowired
    private DoucUserSyncProcessor userSyncProcessor;
    
    @Autowired(required = false)
    private RedisUtils redisUtils;
    
    private boolean isRunning;
    
    @GetMapping("/sync")
    @XxlJob("approve")
    public void jobRun() {
        log.debug("------AllSyncJob--job-start----");
        if (isRunning) {
            return;
        }
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            if (isRunning) {
                return;
            }
            try {
                if (!isRunning) {
                    isRunning = true;
                }
                executeInternal();
            } catch (Throwable exception) {
                log.error("error run task", exception);
            } finally {
                isRunning = false;
            }
        });
        log.debug("------AllSyncJob--job-end----");
    }
    
    
    protected void executeInternal() {
        log.debug("------AllSyncJob--Runnable-start----");
        if (redisUtils != null && !redisUtils.setnx(this.getClass().getSimpleName(), "", 10L, TimeUnit.MINUTES)) {
            log.warn("same task is running");
            return;
        }
        try {
            // do something
            List<BusinessType> businessType = Lists.newArrayList();
            businessType.add(BusinessType.APPROVE_GROUP);
            businessType.add(BusinessType.USER);
            userSyncProcessor.setBusinessType(businessType);
            userSyncProcessor.init();
            userSyncProcessor.start();
            groupSyncProcessor.setBusinessType(businessType);
            groupSyncProcessor.init();
            List<DbsGroupInfo> groups = groupSyncProcessor.read(businessType);
            groupSyncProcessor.write(groups);
            groupSyncProcessor.checkAndDelete(Lists.newArrayList(dbsProperties.getApprover().getGroupCode()), groups);
            XxlJobHelper.log("test2");
        } finally {
            redisUtils.del(this.getClass().getSimpleName());
        }
        log.debug("------AllSyncJob--Runnable-end----");
    }
}
