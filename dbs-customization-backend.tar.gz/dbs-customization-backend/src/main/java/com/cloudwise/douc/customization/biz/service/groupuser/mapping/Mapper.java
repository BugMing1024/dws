package com.cloudwise.douc.customization.biz.service.groupuser.mapping;

import cn.hutool.core.convert.Converter;
import cn.hutool.core.convert.ConverterRegistry;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.anno.MappingProperty;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.MappingHook;
import com.cloudwise.douc.customization.common.converter.AutoConverter;
import com.cloudwise.douc.customization.common.util.SpringUtils;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created on 2022-4-2.`
 *
 * @author skiya
 */
@Slf4j
public class Mapper<S, T> {
    
    private final Class<S> sourceClass;
    
    private final Class<T> targetClass;
    
    private final List<ResultMap> mappings;
    
    private final Collection<MappingHook<S, T>> hooks;
    
    public Mapper(Class<S> sourceClass, Class<T> targetClass, Collection<MappingHook<S, T>> hooks) {
        if (sourceClass == null || targetClass == null) {
            throw new IllegalArgumentException("sourceClass or targetClass can't not be null");
        }
        this.sourceClass = sourceClass;
        this.targetClass = targetClass;
        this.mappings = getMappings();
        this.hooks = hooks;
    }
    
    private List<ResultMap> getMappings() {
        List<ResultMap> resultMaps = new ArrayList<>();
        Field[] sourceFields = sourceClass.getDeclaredFields();
        for (Field sourceField : sourceFields) {
            ResultMap resultMap = new ResultMap();
            MappingProperty mappingProperty = sourceField.getAnnotation(MappingProperty.class);
            if (mappingProperty == null) {
                continue;
            }
            String targetFieldPropertyName = mappingProperty.value();
            resultMap.setSource(sourceField.getName());
            resultMap.setTarget(targetFieldPropertyName);
            resultMap.setConverter(mappingProperty.converter());
            resultMaps.add(resultMap);
        }
        return resultMaps;
    }
    
    public Mapper(Class<S> sourceClass, Class<T> targetClass, List<ResultMap> mappings, Collection<MappingHook<S, T>> hooks) {
        if (sourceClass == null || targetClass == null) {
            throw new IllegalArgumentException("sourceClass or targetClass can't not be null");
        }
        this.sourceClass = sourceClass;
        this.targetClass = targetClass;
        this.mappings = mappings;
        this.hooks = hooks;
    }
    
    public List<T> convert(List<S> sourceValues) {
        if (sourceValues == null || sourceValues.isEmpty()) {
            return new ArrayList<>();
        }
        return sourceValues.stream().map(this::remapping).collect(Collectors.toList());
    }
    
    private T remapping(S sourceValue) {
        
        boolean hooked = hooks != null && !hooks.isEmpty();
        if (hooked) {
            hooks.forEach(hook -> hook.beforeMapping(sourceValue));
        }
        T targetInstance = ReflectUtil.newInstance(targetClass);
        for (ResultMap mapping : mappings) {
            String source = mapping.getSource();
            String target = mapping.getTarget();
            Class<? extends Converter<?>> converter = mapping.getConverter();
            
            Object sourceFieldValue = ReflectUtil.getFieldValue(sourceValue, source);
            Field targetField = ReflectUtil.getField(targetClass, target);
            if (targetField == null) {
                throw new IllegalArgumentException(StrUtil.format("target field [{}] not found in [{}]", target, targetClass.getName()));
            }
            Object convertResult;
            if (converter.equals(AutoConverter.class)) {
                convertResult = ConverterRegistry.getInstance().convert(targetField.getType(), sourceFieldValue);
            } else {
                Converter<?> converterInstance = SpringUtils.getBean(converter);
                convertResult = converterInstance.convert(sourceFieldValue, null);
            }
            
            ReflectUtil.setFieldValue(targetInstance, target, convertResult);
        }
        if (hooked) {
            hooks.forEach(hook -> hook.afterMapping(sourceValue, targetInstance));
        }
        return targetInstance;
    }
    
}
