package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class TaskInfo {
    
    private String taskId;
    
    private String taskName;
    
    private String assginee;
}
