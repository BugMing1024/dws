package com.cloudwise.douc.customization.biz.service.email;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  10:05
 **/
public interface CustomMessageRecordService extends IService<CustomMessageRecord> {
    
    String insertRecord(CustomMessageRecord messageRecord);
    
    void updateRecord(List<CustomMessageRecord> messageRecords);
    
    
    List<CustomMessageRecord> getFailMessages();
}
