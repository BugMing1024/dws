package com.cloudwise.douc.customization.biz.model.appcode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Magina
 * @date 2024/12/6 4:59 下午
 * @description
 **/

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppcodeLobCountry {
    
    @JsonProperty("AppCode")
    private String appCode;
    
    
    @JsonProperty("iCHAMPLOB")
    private String ichampLob;
    
    
    @JsonProperty("iCHAMPCountry")
    private String ichampCountry;
    
    
    @JsonProperty("OverDueECROrRCAStatus")
    private String overDueecrOrRcaStatus;
    
//    private Integer id;
    
    
}





