package com.cloudwise.douc.customization.biz.model.appcode;

import lombok.Data;

@Data
public class AppManager4Impacted {
    
    private String sme1Email;
    
    private String sme2Email;
}
