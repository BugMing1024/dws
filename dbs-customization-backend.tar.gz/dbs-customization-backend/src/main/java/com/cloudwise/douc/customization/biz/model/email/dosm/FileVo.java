package com.cloudwise.douc.customization.biz.model.email.dosm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileVo {
    
    /**
     * 主键ID
     */
    @ApiModelProperty(hidden = true)
    private String id;
    
    /**
     * 文件名
     */
    @ApiModelProperty(value = "文件名", example = "img.png", hidden = true)
    private String fileName;
    
    /**
     * 文件名不带后缀
     */
    @ApiModelProperty(value = "文件名不带后缀", example = "img", hidden = true)
    private String fileNameWithoutSuffix;
    
    /**
     * 文件扩展名
     */
    @ApiModelProperty(value = "文件扩展名", example = "png", hidden = true)
    private String fileExt;
    
    /**
     * 文件大小
     */
    @ApiModelProperty(value = "文件大小带单位的字符串", example = "102.2MB", hidden = true)
    private String fileSize;
    
    /**
     * fileSize被特殊处理了
     */
    @ApiModelProperty(value = "文件大小(单位：Byte)", example = "1024", hidden = true)
    private Long fileLongSize;
    
    /**
     * 文件路径
     */
    @ApiModelProperty(value = "文件路径", example = "/", hidden = true)
    private String filePath;
    
    /**
     * 租户ID
     */
    @ApiModelProperty(hidden = true)
    private String accountId;
    
    /**
     * 创建人ID
     */
    @ApiModelProperty(hidden = true)
    private String createdBy = "";
    
    /**
     * 创建时间
     */
    @ApiModelProperty(hidden = true)
    private Date createdTime = new Date();
    
    /**
     * 修改人ID
     */
    @ApiModelProperty(hidden = true)
    private String updatedBy = "";
    
    /**
     * 修改时间
     */
    @ApiModelProperty(hidden = true)
    private Date updatedTime = new Date();
    
    ;
    
    /**
     * 乐观锁
     */
    @ApiModelProperty(hidden = true)
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer revision = 0;
    
    /**
     * 0有效1删除
     */
    @ApiModelProperty(hidden = true)
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer isDel = 0;
    
    private String uploadUserName;
    
    
    public static FileInfo convertFileInfo(FileVo fileVo) {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setId(fileVo.getId());
        fileInfo.setName(fileVo.getFileName());
        fileInfo.setLoad(false);
        fileInfo.setUid("rc-upload-" + new Date().getTime() + "-1");
        fileInfo.setSize(fileVo.getFileSize());
        return fileInfo;
    }
}
