package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SubmitWorkorderDataBean {
    
    private int isTest;
    
    private String workOrderNo;
    
    private String bizDesc;
    
    private int dataStatus;
    
    private String formData;
    
    private String mdlDefKey;
    
    private int revision;
    
    private String serviceIds;
    
    private String sourceId;
    
    private String title;
    
    private String urgentLevel;
    
    private String mdlDefCode;
    
    private String processInstanceId;
    
    private String createdBy;
    
    private String updatedBy;
}