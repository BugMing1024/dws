package com.cloudwise.douc.customization.biz.service.crdailybulkreminder;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloudwise.douc.customization.biz.dao.RptCrTodoDailyDataMapper;
import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.enums.ValueTypeEnum;
import com.cloudwise.douc.customization.biz.handler.NotificationSenderManager;
import com.cloudwise.douc.customization.biz.model.crdailybulkreminder.RptCrTodoDailyData;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.service.msg.utils.MsgAnalysisUtil;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Daily Bulk Reminder Service
 */
@Slf4j
@Service
public class CrDailyBulkReminderService {
    private final RptCrTodoDailyDataMapper rptCrTodoDailyDataMapper;
    private final NotificationSenderManager notificationSenderManager;
    private final CrDailyBulkReminderProperties crDailyBulkReminderProperties;
    private final DosmConfig dosmConfig;
    private String processName;
    private List<String> taskNameList = new ArrayList<>();
    private Map<String, String> task2EmailTemplatemap = new HashMap<>();
    private String changeScheduleStartdateFullpath;

    public CrDailyBulkReminderService(RptCrTodoDailyDataMapper rptCrTodoDailyDataMapper, NotificationSenderManager notificationSenderManager,
                                      CrDailyBulkReminderProperties crDailyBulkReminderProperties, DosmConfig dosmConfig) {
        this.rptCrTodoDailyDataMapper = rptCrTodoDailyDataMapper;
        this.notificationSenderManager = notificationSenderManager;
        this.crDailyBulkReminderProperties = crDailyBulkReminderProperties;
        this.dosmConfig = dosmConfig;
        init();
    }

    private void init() {
        this.processName = crDailyBulkReminderProperties.getProcessName();
        this.changeScheduleStartdateFullpath = crDailyBulkReminderProperties.getChangeScheduleStartdateFullpath();
        for (Map<String, String> node : crDailyBulkReminderProperties.getNodes()) {
            this.taskNameList.add(node.get("key"));
            task2EmailTemplatemap.put(node.get("key"), node.get("value"));
        }
    }

    public void doRebuildBulkReminderDatas() {
        if (processName == null) {
            log.warn("The process name is empty, so there is no need to generate data.");
            return;
        }

        if (changeScheduleStartdateFullpath == null) {
            log.warn("The changeScheduleStartdateFullpath is empty, so there is no need to generate data.");
            return;
        }

        if (taskNameList.isEmpty()) {
            log.warn("The list of tasks is empty, so there is no need to generate data.");
            return;
        }

        log.info("Initializing to-do task intermediate temporary table data has started...");
        cleanupHistoryRptDatas();
        log.info("Initializing to-do task intermediate temporary table data completed...");

        log.info("Initializing to-do order intermediate temporary table data has started...");
        rebuildRptDatas();
        log.info("Initializing to-do order intermediate temporary table data completed...");
    }

    private void cleanupHistoryRptDatas() {
        rptCrTodoDailyDataMapper.truncateRptCrTodoTaskMid();
        log.debug("Initialized clearing of historical data in rpt_cr_todo_task_mid completed.");
        rptCrTodoDailyDataMapper.truncateRptCrTodoOrderMid();
        log.debug("Initialized clearing of historical data in rpt_cr_todo_order_mid completed.");
        rptCrTodoDailyDataMapper.truncateRptCrTodoCountData();
        log.debug("Initialized clearing of historical data in rpt_cr_todo_count_data completed.");
        rptCrTodoDailyDataMapper.truncateRptCrTodoDailyData();
        log.debug("Initialized clearing of historical data in rpt_cr_todo_daily_data completed.");
    }

    private void rebuildRptDatas() {
        rptCrTodoDailyDataMapper.insertRptCrTodoTaskMid(this.taskNameList);
        log.debug("1-1. Generated to-do task intermediate temporary table data completed.");
        rptCrTodoDailyDataMapper.insertRptCrTodoOrderMid(this.processName, this.changeScheduleStartdateFullpath);
        log.debug("1-2. Generated to-do order intermediate temporary table data completed.");
        rptCrTodoDailyDataMapper.insertRptCrTodoCountData();
        log.debug("2-1. Summarized to-do count data completed.");
        rptCrTodoDailyDataMapper.insertRptCrTodoDailyData();
        log.debug("3-1. Generated daily to-do reminder data completed.");
    }

    public void doSendBulkReminderEmails() {
        int pageNo = 1;
        int pageSize = 30;
        List<RptCrTodoDailyData> list = getCrTodoDailyDataByPage(pageNo, pageSize);

        while (!list.isEmpty()) {
            list.forEach(data -> {
                MessageVo messageVo = makeupEmailMessage(data);
                sendEmail(messageVo);
            });
            pageNo += 1;
            list = getCrTodoDailyDataByPage(pageNo, pageSize);
        }
    }

    private List<RptCrTodoDailyData> getCrTodoDailyDataByPage(int pageNo, int pageSize) {
        Page<RptCrTodoDailyData> page = new Page<>(pageNo, pageSize, false);
        Wrapper<RptCrTodoDailyData> queryWrapper = new QueryWrapper();
        return rptCrTodoDailyDataMapper.selectRptCrTodoDailyDataListByPage(page, queryWrapper).getRecords();
    }

    private MessageVo makeupEmailMessage(RptCrTodoDailyData rptCrTodoDailyData) {
        String emailTemplate = task2EmailTemplatemap.get(rptCrTodoDailyData.getTaskName());
        if (emailTemplate == null) {
            log.error("Can not find email template for task: {}", rptCrTodoDailyData.getTaskName());
            return null;
        }

        NotifyScenceEnum notifyScene = NotifyScenceEnum.of(emailTemplate);
        if (notifyScene == null) {
            log.error("Can not find email template for task: {}", rptCrTodoDailyData.getTaskName());
            return null;
        }

        // 定义message 实体类
        MessageContext messageContext = new MessageContext();
        messageContext.setTopAccountId(dosmConfig.getTopAccountId());
        messageContext.setAccountId(dosmConfig.getAccountId());
        messageContext.setUserId(dosmConfig.getUserId());
        messageContext.setCreatedBy(dosmConfig.getUserId());

        /**
         * Declare public fields
         */
        Map<String, String> publicFields = new HashMap<>();
        publicFields.put("sendEmailDateTime", rptCrTodoDailyData.getCreatedTime());
        publicFields.put("approvalCount", String.valueOf(rptCrTodoDailyData.getTodoCount()));
        publicFields.put("earliestChangeScheduleStartDate", String.valueOf(rptCrTodoDailyData.getEarliestChangeScheduleStartdate()));
        messageContext.setPublicFields(publicFields);

        /**
         * Declare email content
         */
        NotifyVo emailNotify = new NotifyVo();
        emailNotify.setChannelType(NotifyWayEnum.EMAIL);
        emailNotify.setNotifyScene(notifyScene);

        ValueContent title = new ValueContent();
        title.setType(ValueTypeEnum.FORM);
        emailNotify.setTitle(title);

        ValueContent content = new ValueContent();
        content.setType(ValueTypeEnum.FORM);
        emailNotify.setContent(content);

        List<ValueContent> receivers = new ArrayList<>();
        ValueContent receiver = new ValueContent();
        receiver.setType(ValueTypeEnum.NORMAL);
        NormalValue receiverValue = new NormalValue();
        List<String> userIdList = new ArrayList<>();
        userIdList.add(rptCrTodoDailyData.getUserId());
        receiverValue.setUserIds(userIdList);
        receiver.setNormalValue(receiverValue);
        receivers.add(receiver);
        emailNotify.setReceivers(receivers);

        messageContext.setNotify(emailNotify);

        // 转换成
        MessageVo message = MsgAnalysisUtil.getMessage(messageContext);

        return message;
    }

    private void sendEmail(MessageVo messageVo) {
        notificationSenderManager.send(messageVo);
        log.info("SendMessage send message success");
    }
}
