package com.cloudwise.douc.customization.biz.service.msg.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.EmailMessageVo;
import com.cloudwise.douc.customization.biz.model.email.UploadFileInfoDto;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import com.cloudwise.douc.customization.biz.service.msg.MessageCenterService;
import com.cloudwise.douc.customization.biz.service.msg.MessageSender;
import com.cloudwise.message.dubbo.api.dto.DubboSendMessageResult;
import com.cloudwise.message.dubbo.api.dto.base.DubboCommonResp;
import com.cloudwise.message.dubbo.api.model.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * 邮件发送
 *
 * @author ming.ma
 * @since 2024-12-04  14:46
 **/
@Slf4j
@Component
public class EmailSender implements MessageSender<EmailMessageVo> {

    private static final String CONTENT_TYPE = "RICH_TEXT";

    private static final String MODULE_CODE = "112";

    private static final String RECEIVER_EXT_USER_EMAIL = "EMAIL";

    private static final String CC_USER_IDS = "ccUserIds";

    private static final String CC_EMAIL = "ccEmail";

    private static final String BCC_USER_IDS = "bccUserIds";

    private static final String BCC_EMAIL = "bccEmail";


    @Autowired
    CustomMessageRecordService customMessageRecordService;

    @Autowired
    MessageCenterService messageCenterService;

    @Override
    public String notifyWay() {
        return NotifyWayEnum.EMAIL.name();
    }


    @Override
    public CompletableFuture<Integer> sendV2(EmailMessageVo message) {
        return CompletableFuture.supplyAsync(() -> {
            Map<UserInfo, String> bodyList = message.getBodyList();
            if(CollUtil.isNotEmpty(bodyList)) {
                for(Map.Entry<UserInfo, String> bodyEntry: bodyList.entrySet()) {
                    message.setReceivers(Lists.newArrayList(bodyEntry.getKey()));
                    message.setBody(bodyEntry.getValue());
                    this.send(message);
                }
                return bodyList.size();
            } else {
                return send(message);
            }
        });
    }

    public Integer send(EmailMessageVo message) {
        List<UserInfo> receivers;
        if (CollUtil.isEmpty(receivers = message.getReceivers())) {
            log.info("[Send email] Message receiver is empty");
            return null;
        }

        // build douc msg request
        DubboProductMultipleChannelMessageV2 request = new DubboProductMultipleChannelMessageV2();
        request.setId(IdUtil.simpleUUID());
        request.setAccountId(Long.valueOf(message.getAccountId()));
        request.setModuleCode(MODULE_CODE);
        request.setLevel(DubboProductMultipleChannelMessageV2.LevelConstants.DEFAULT);
        request.setTimestamp(System.currentTimeMillis());

        DubboMessageChannel channel = new DubboMessageChannel();
        channel.setCode(DubboMessageChannel.ChannelCodeConstants.EMAIL);
        request.setChannels(Lists.newArrayList(channel));

        // msg content
        DubboMessageContent content = new DubboMessageContent();
        request.setContent(content);

        content.setType(DubboMessageContent.TypeConstants.WORK_ORDER);
        content.setContentType(CONTENT_TYPE);

        /** Mail recipients */
        List<Long> receiverUserIds = Lists.newArrayList();
        Set<String> receiverEmails = Sets.newHashSet();
        receivers.forEach(user -> {
            if(user.getUserId() != null) {
                receiverUserIds.add(user.getUserId());
            } else if(user.getEmail() != null) {
                receiverEmails.add(user.getEmail());
            }
        });

        DubboMessageReceivers messageReceivers = new DubboMessageReceivers();
        messageReceivers.setUserIds(CollUtil.isEmpty(receiverUserIds)? null: receiverUserIds);
        if (CollUtil.isNotEmpty(receiverEmails)) {
            // set extendUsers
            Map<String, List<String>> extendUsers = new HashMap<>();
            extendUsers.put(RECEIVER_EXT_USER_EMAIL, new ArrayList<>(receiverEmails));
            messageReceivers.setExtendUsers(extendUsers);
        }
        request.setReceivers(messageReceivers);


        /** carbon copy recipients */
        List<UserInfo> sendCopys = message.getSendCopys();
        if(CollectionUtils.isNotEmpty(sendCopys)) {
            Map<String, Object> extendField = new HashMap<>();
            Set<String> ccUserIds = Sets.newHashSet();
            Set<String> ccEmails = Sets.newHashSet();

            sendCopys.forEach(user -> {
                if(user.getUserId() != null) {
                    ccUserIds.add(user.getUserId().toString());
                } else if(user.getEmail() != null) {
                    ccEmails.add(user.getEmail());
                }
            });

            if (CollUtil.isNotEmpty(ccUserIds)) {
                extendField.put(CC_USER_IDS, ccUserIds);
            }
            if (CollUtil.isNotEmpty(ccEmails)) {
                extendField.put(CC_EMAIL, ccEmails);
            }
            content.setExtendField(extendField);
        }

        /** email title and body */
        content.setTitle(message.getTitle());
        content.setMessage(message.getBody());


        /** mail attachment */
        List<UploadFileInfoDto> uploadFiles = message.getUploadFiles();
        List<DubboMessageEnclosure> fileList = Lists.newArrayList();
        if (CollUtil.isNotEmpty(uploadFiles)) {
            uploadFiles.forEach(e -> {
                DubboMessageEnclosure messageEnclosure = new DubboMessageEnclosure();
                messageEnclosure.setType(2);
                messageEnclosure.setName(e.getFileName());
                messageEnclosure.setUrl(e.getUrl());
                fileList.add(messageEnclosure);
            });
        }
        content.setEnclosures(fileList);

        // Message failure retry settings
        request.setSendMode(DubboMessageSendMode.sendOnce());
        request.setLanguage(DubboMessageLanguage.english());
        // Add message sending record
        CustomMessageRecord customMessageRecord = CustomMessageRecord.buildInsertInfo(message);
        customMessageRecord.setId(message.getMessageContext().getTmpRecordId());
        customMessageRecord.setNotifyWay(NotifyWayEnum.EMAIL.name());
        List<DubboProductMultipleChannelMessageV2> messages = Lists.newArrayList(request);
        log.info("[Send email] messages :{}", JSONUtil.toJsonStr(messages));
        customMessageRecord.setMessageRequest(JSONUtil.toJsonStr(messages));
        customMessageRecord.setMessageContext(JSONUtil.toJsonStr(message.getMessageContext()));
        DubboCommonResp<List<DubboSendMessageResult>> response = messageCenterService.send(messages);
        if (!response.isSuccess()) {
            customMessageRecord.setStatus(0);
            customMessageRecord.setMessageResponse(JSONUtil.toJsonStr(response));
            customMessageRecordService.insertRecord(customMessageRecord);
            log.error("[Send email] send failed，msg :{}", response.getMsg());
            return 0;
        }
        customMessageRecord.setStatus(1);
        customMessageRecord.setMessageResponse(JSONUtil.toJsonStr(response.getData()));
        customMessageRecord.setMessageId(response.getData().get(0).getId());
        customMessageRecordService.insertRecord(customMessageRecord);

        log.info("[Send email] send success，messageId:{},customMessageRecordId:{}", response.getData().get(0).getId(), customMessageRecord.getId());
        return messages.size();
    }
}
