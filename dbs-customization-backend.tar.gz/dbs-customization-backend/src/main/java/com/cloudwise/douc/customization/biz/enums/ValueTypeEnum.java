package com.cloudwise.douc.customization.biz.enums;

/**
 * @author ming.ma
 * @since 2024-12-05  15:15
 **/
public enum ValueTypeEnum {
    /**
     * 普通值
     */
    NORMAL,
    /**
     * 表单获取值
     */
    FORM;
}
