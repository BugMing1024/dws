package com.cloudwise.douc.customization.common.model;


/**
 * @author skiya
 * @date Created on 2021-11-25.
 */
public class PageResponse {
    
    private Long size;
    
    private Long current;
    
    private Long pages;
    
    private Long total;
    
    public Long getSize() {
        return size;
    }
    
    public void setSize(Long size) {
        this.size = size;
    }
    
    public Long getCurrent() {
        return current;
    }
    
    public void setCurrent(Long current) {
        this.current = current;
    }
    
    public Long getPages() {
        return pages;
    }
    
    public void setPages(Long pages) {
        this.pages = pages;
    }
    
    public Long getTotal() {
        return total;
    }
    
    public void setTotal(Long total) {
        this.total = total;
    }
    
}
