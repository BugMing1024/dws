package com.cloudwise.douc.customization.biz.model.table;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.cloudwise.douc.customization.biz.model.email.MessageVo;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 消息记录表
 *
 * @author ming.ma
 * @since 2024-12-10  09:53
 **/
@Data
@TableName("dosm_custom_message_record")
public class CustomMessageRecord implements Serializable {

    private static final long serialVersionUID = -5610667208667921225L;

    /**
     * 消息记录id
     */
    @TableId
    private String id;


    /**
     * 创建用户id
     */
    private String createdBy;

    /**
     * 是否删除
     */
    private int isDel;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新时间
     */
    private Date updatedTime;

    /**
     * 顶级租户ID
     */
    private String topAccountId;

    /**
     * 租户id
     */
    private String accountId;

    /**
     * 更新用户id
     */
    private String updatedBy;

    /**
     * 乐观锁
     */
    private Integer revision;

    /**
     * 消息id
     */
    private String messageId;

    /**
     * 工单id
     */
    private String workOrderId;

    /**
     * 节点id
     */
    private String nodeId;

    /**
     * 消息是否发送成功： 0 -未成功,1-成功
     */
    private int status;

    /**
     * 通知场景
     */
    private String notifyScene;

    /**
     * 消息发送参数
     */
    private String messageRequest;

    /**
     * 消息发送原始参数参数
     */
    private String messageContext;

    /**
     * 消息返回结果
     */
    private String messageResponse;

    /**
     * 重试次数
     */
    private int retry;

    /**
     * 通知类型
     */
    private String notifyWay;


    public static CustomMessageRecord buildInsertInfo(MessageVo emailMessageVo) {
        CustomMessageRecord customMessageRecord = new CustomMessageRecord();
        customMessageRecord.setId(IdUtil.fastSimpleUUID());
        customMessageRecord.setWorkOrderId(emailMessageVo.getWorkOrderId());
        customMessageRecord.setCreatedBy(emailMessageVo.getCreatedBy());
        customMessageRecord.setAccountId(emailMessageVo.getAccountId());
        customMessageRecord.setTopAccountId(emailMessageVo.getTopAccountId());
        customMessageRecord.setNodeId(emailMessageVo.getNodeId());
        customMessageRecord.setNotifyScene(emailMessageVo.getNotifyScene().name());
        Date date = new Date();
        customMessageRecord.setUpdatedBy(emailMessageVo.getCreatedBy());
        customMessageRecord.setUpdatedTime(date);
        customMessageRecord.setCreatedTime(date);
        customMessageRecord.setIsDel(0);
        return customMessageRecord;
    }


}
