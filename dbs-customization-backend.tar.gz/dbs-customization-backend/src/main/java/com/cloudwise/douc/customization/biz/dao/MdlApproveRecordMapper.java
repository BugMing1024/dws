package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.MdlApproveRecord;
import com.cloudwise.douc.customization.biz.model.table.RuTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-26  16:44
 **/
@Mapper
public interface MdlApproveRecordMapper extends BaseMapper<MdlApproveRecord> {
    
    List<MdlApproveRecord> getMdlApproveRecordsByProcessInstanceId(String processInstanceId);
    
    MdlApproveRecord getMdlApproveRecordsByWorkOrderIdAndNodeId(@Param("workOrderId") String workOrderId, @Param("nodeId") String nodeId);

    List<MdlApproveRecord> getMdlApproveRecordsByWorkOrderIdAndNodeIdV2(@Param("workOrderId") String workOrderId, @Param("nodeId") String nodeId);

    List<RuTask> getRuTasksByProcessInstanceId(String processInstanceId);
    
    String getDataDictLableById(String dataDictId);

    String getIdByProcessInstanceIdAndNode(@Param("processInstanceId") String processInstanceId, @Param("nodeId") String nodeId);
}
