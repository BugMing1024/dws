package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.ActHiTask;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/26
 */
@Mapper
public interface ActHiTaskMapper extends BaseMapper<ActHiTask> {

}
