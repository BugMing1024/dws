package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.enums.CRStageEnum;
import com.cloudwise.douc.customization.biz.enums.EmailApproveEnum;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-13  14:45
 **/
@Builder
@Data
public class ApproveOrderVo {
    
    private String workOrderId;
    
    private String userId;
    
    private EmailApproveEnum approveStatus;
    
    private CRStageEnum stage;
    
    private List<String> groupIds;
    
    private Map<String, String> emailContent;

    private String signOffId;
    
}
