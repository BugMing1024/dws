package com.cloudwise.douc.customization.common.config;

import com.cloudwise.douc.customization.common.util.JsonUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
@Data
@Slf4j
@Component
@ConfigurationProperties(prefix = DbsProperties.PREFIX)
public class DbsProperties implements InitializingBean {
    
    public static final String PREFIX = "dbs";
    
    private String appCode;
    
    private String appKey;
    
    private Setting approver;
    
    private Setting implementer;
    
    private Setting mdApprover;
    
    private Setting release;
    
    private Setting change;
    
    private Setting groupDetail;
    
    private Setting tsoid;
    
    private Setting hr;
    
    private Setting changeTeam;
    
    private Setting risk;
    
    private Setting arcApprover;
    
    private Setting ctoApprover;
    
    private Setting signoff;
    
    private Setting notification;
    
    private Mock mockAppCode;
    
    private Mock mockApproveGroups;
    
    private Mock mockImplementerGroups;
    
    private Mock mockHmdApproverData;
    
    private Mock mockGroupDetail;
    
    private Mock mockReleaseGroups;
    
    private Mock mockChangeGroups;
    
    private Mock mockHtsoidData;
    
    private Mock mockHrData;
    
    private Mock mockauthenticate;
    
    private Msg group;
    
    private Msg user;
    
    private Email email;
    
    private List<Special> special;
    
    @Override
    public void afterPropertiesSet() {
        log.info("Douc properties loaded successfully: {}", JsonUtils.toJsonStr(this));
    }
    
    @Data
    public static class Setting {
        
        private Map<String, String> params;
        
        private String url;
        
        private String groupCode;
        
    }
    
    @Data
    public static class Mock {
        
        private String list;
        
    }
    
    @Data
    public static class Msg {
        
        private String syncTopic;
        
        private String groupId;
        
    }
    
    @Data
    public static class Email {
        
        private String readUrl;
        
        private String markReadUrl;
        
    }
    
    @Data
    public static class Special {
        
        private String firstGroupCode;
        
        private List<String> childrenGroupName;
    }
    
}
