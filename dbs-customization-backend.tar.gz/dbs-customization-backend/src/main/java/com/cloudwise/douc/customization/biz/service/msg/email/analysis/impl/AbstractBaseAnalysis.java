package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.dosm.api.bean.form.*;
import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.api.bean.form.field.*;
import com.cloudwise.dosm.api.bean.form.fileupload.v2.FileUploadBeanV2;
import com.cloudwise.dosm.api.bean.utils.JsonUtils;
import com.cloudwise.douc.customization.biz.constant.EmailTemplateConstants;
import com.cloudwise.douc.customization.biz.dao.AppcodeLobCountryMapper;
import com.cloudwise.douc.customization.biz.dao.UploadFileMapper;
import com.cloudwise.douc.customization.biz.enums.EmailApproveEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.enums.ValueTypeEnum;
import com.cloudwise.douc.customization.biz.facade.UserGroupSSOClient;
import com.cloudwise.douc.customization.biz.facade.UserSSOClient;
import com.cloudwise.douc.customization.biz.facade.user.GroupUserInfo;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.appcode.AppManager4Impacted;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.model.email.FieldValue;
import com.cloudwise.douc.customization.biz.model.table.UploadFileInfo;
import com.cloudwise.douc.customization.biz.service.msg.email.analysis.EmailAnalysis;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.FieldBindVariableUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailTemplateUtil;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.biz.util.BpmTemplateUtil;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Author frank.zheng
 * @Date 2025-02-09
 */
@Slf4j
public abstract class AbstractBaseAnalysis implements EmailAnalysis {



    /**
     * email binding ext mapping
     * @param context
     * @return
     */
    abstract void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap);


    /**
     * 获取邮件标题
     * @return
     */
    abstract String getTitleTemplate();


    @Override
    public EmailMessageVo getMessage(MessageContext context) {
        NotifyVo notify = context.getNotify();

        // Mail recipients
        List<UserInfo> receivers = this.getReceivers(context);
        if(CollectionUtils.isEmpty(receivers)) {
            log.error("email receiver is null, workOrderId:{}, notifyReceivers: {}", context.getWorkOrderId(), notify.getReceivers());
            return null;
        }

        Map<String, FieldInfo> formDataMap = null;
        JsonNode formDataJson = context.getFormDataJson();
        if(formDataJson != null && !formDataJson.isEmpty()) {
            formDataMap = getDosmWorkOrderService().getFormData(context.getWorkOrderId(), context.getUserId(), formDataJson);
        } else {
            formDataMap = getDosmWorkOrderService().getFormData(context.getWorkOrderId(), context.getUserId());
        }
        context.setFormData(formDataMap);


        Map<String, Object> bindingMap = this.buildBindingMap(context, receivers);

        EmailMessageVo emailMessage = new EmailMessageVo();
        emailMessage.setNotifyWay(NotifyWayEnum.EMAIL);
        emailMessage.setCreatedBy(context.getUserId());
        emailMessage.setTopAccountId(context.getTopAccountId());
        emailMessage.setAccountId(context.getAccountId());
        emailMessage.setNotifyScene(notify.getNotifyScene());
        emailMessage.setWorkOrderId(context.getWorkOrderId());
        emailMessage.setNodeId(context.getNodeId());
        emailMessage.setMessageContext(context);

        emailMessage.setTitle(this.getTitle(bindingMap));
        emailMessage.setReceivers(receivers);
        // carbon copy recipients
        emailMessage.setSendCopys(this.getSendCopys(context));

        emailMessage.setDetailUrl((String) bindingMap.get(EmailTemplateConstants.Btn.TICKET_DETAIL));

        this.buildMsgBody(context, receivers, bindingMap, emailMessage);

        return emailMessage;
    }


    protected void buildMsgBody(MessageContext context, List<UserInfo> receivers, Map<String, Object> bindingMap, EmailMessageVo emailMessage) {
        NotifyVo notify = context.getNotify();
        emailMessage.setBody(this.getSingleEmailBody(notify, bindingMap));


        List<UploadFileInfoDto> uploadFiles = this.getUploadFiles(context);
        emailMessage.setUploadFiles(uploadFiles);
    }





    /**
     * carbon copy recipients
     *     <p>1、type is “NORMAL”，Preferentially get userId and get userEmail
     *     <p>2、type is “FORM”，Preferentially get userId and get userEmail
     */
    protected List<UserInfo> getSendCopys(MessageContext context) {
        NotifyVo notify = context.getNotify();
        return getEmailUsers(context, notify.getCsReceivers());
    }


    /**
     * get email receivers
     *     <p>1、type is “NORMAL”，Preferentially get userId and get userEmail
     *     <p>2、type is “FORM”，Preferentially get userId and get userEmail
     */
    protected List<UserInfo> getReceivers(MessageContext context) {
        NotifyVo notify = context.getNotify();
        return getEmailUsers(context, notify.getReceivers());
    }

    /**
     * email Subject
     * @param bindingMap
     * @return
     */
    protected String getTitle(Map<String, Object> bindingMap) {
        return BpmTemplateUtil.renderNoSpecial(getTitleTemplate(), bindingMap);
    }





    /**
     * email body param binding mapping
     * <p>1、Multiple approver，assignedUserName=userName1,userName2,...,userNameN
     */
    protected Map<String, Object> buildBindingMap(MessageContext context, List<UserInfo> receivers) {
        NotifyVo notify = context.getNotify();
        Map<String, FieldInfo> formData = context.getFormData();

        Map<String, Object> bindingMap = Maps.newHashMap();

        // email field value format config
        Map<String, String> fieldValueFormatMap = getDosmConfig().getEmailConfig().getFieldValueFormatMap();

        String[] bodyFieldKeys = notify.getNotifyScene().getSmsBodyFieldKeys();
        if(bodyFieldKeys != null) {
            Map<String, String> emailBodyFieldMap = getDosmConfig().getEmailConfig().getBodyFieldMap();
            if(MapUtils.isNotEmpty(emailBodyFieldMap)) {
                // email body field
                List<FieldValue> emailContentFields = Arrays.stream(bodyFieldKeys).map(emailKey -> FieldValue.builder().emailKey(emailKey).name(emailBodyFieldMap.get(emailKey)).build()).filter(item -> StringUtils.isNotBlank(item.getName())).collect(Collectors.toList());
                Map<String, Object> emailContent_bindingMap = FieldBindVariableUtil.getBindVariable(emailContentFields, formData, fieldValueFormatMap);
                bindingMap.putAll(emailContent_bindingMap);
            } else {
                Arrays.stream(bodyFieldKeys).forEach(emailKey -> bindingMap.put(emailKey, ""));
            }
        }

        // form field
        Map<String, Object> emailContent_bindingMap = FieldBindVariableUtil.getBindVariable(notify.getContent() == null? null: notify.getContent().getFields(), formData, fieldValueFormatMap);
        bindingMap.putAll(emailContent_bindingMap);

        // public field
        Map<String, String> publicFields = context.getPublicFields();
        if(CollUtil.isNotEmpty(publicFields)) {
            bindingMap.putAll(publicFields);

            bindingMap.put(EmailTemplateConstants.BodyField.CR_NUMBER, publicFields.get(EmailTemplateConstants.PublicFields.BIZ_KEY));
        }

        // email templat public param
        buildEmailPublicParam(bindingMap, context, receivers);
        // email templat button or link
        buildButtonLink(bindingMap, context);

        // 绑定扩展信息
        buildExtBindingMap(context, bindingMap);

        bindingMap.putIfAbsent(EmailTemplateConstants.EMAIL_APPROVAL_EXCEPTION, "false");
        return bindingMap;
    }

    protected void buildEmailPublicParam(Map<String, Object> bindingMap, MessageContext context, List<UserInfo> receivers) {
        bindingMap.put(EmailTemplateConstants.ITSM_SUPPORT_EMAIL, getDosmConfig().getEmailConfig().getItsmSupportEmail());

        String receiverNameStr = receivers.stream().map(UserInfo::getUserAlias).collect(Collectors.joining(","));
        receiverNameStr = StrUtil.replaceLast(receiverNameStr, ",", " and ");
        bindingMap.put(EmailTemplateConstants.ASSIGNED_USER_NAME, receiverNameStr);
    }


    protected void buildButtonLink(Map<String, Object> bindingMap, MessageContext context) {
        String replyToAddress = getDosmConfig().getReplyToAddress();
        String title = getTitle(bindingMap);

        String approvedMailtoLink = EmailAnalysisUtil.getApproveMailtoLink(EmailApproveEnum.APPROVED, title, replyToAddress, context);
        String rejectMailtoLink = EmailAnalysisUtil.getApproveMailtoLink(EmailApproveEnum.REJECTED, title, replyToAddress, context);

        bindingMap.put(EmailTemplateConstants.Btn.APPROVE, approvedMailtoLink);
        bindingMap.put(EmailTemplateConstants.Btn.REJECT, rejectMailtoLink);
        bindingMap.put(EmailTemplateConstants.Btn.PENDING_MY_APPROVAL_LIST, getDosmConfig().getPendingMyApprovalListLink());
        bindingMap.put(EmailTemplateConstants.Btn.TICKET_DETAIL, getDosmConfig().getOrderDetail() + context.getWorkOrderId());
    }







    /**
     * Get the email content for all recipients to be sent together, return data format: Email Content
     * <p>Send email interface：com.cloudwise.douc.customization.biz.service.msg.email.impl.EmailSender#send(com.cloudwise.douc.customization.biz.model.email.EmailMessageVo)
     * @param notify
     * @param bindingMap
     * @return
     */
    protected String getSingleEmailBody(NotifyVo notify, Map<String, Object> bindingMap) {
        NotifyScenceEnum notifyScene = notify.getNotifyScene();
        return getBody(notifyScene, bindingMap);
    }


    /**
     * get single user email
     * <p>Send email interface：com.cloudwise.douc.customization.biz.service.msg.email.impl.EmailSender#sendV2(com.cloudwise.douc.customization.biz.model.email.EmailMessageVo)
     * @param notify
     * @param bindingMap
     * @return
     */
    protected Map<UserInfo, String> getSingleUserEmail(NotifyVo notify, List<UserInfo> receivers, Map<String, Object> bindingMap) {
        NotifyScenceEnum notifyScene = notify.getNotifyScene();

        return receivers.stream().collect(Collectors.toMap(Function.identity(), user -> {
            bindingMap.put(EmailTemplateConstants.ASSIGNED_USER_NAME, user.getUserAlias());
            return getBody(notifyScene, bindingMap);
        }));
    }



    protected List<UploadFileInfoDto> getUploadFiles(MessageContext context) {
        List<UploadFileInfoDto> files = new ArrayList<>();
        NotifyVo emailNotify = context.getNotify();
        if (null == emailNotify) {
            log.info("GetUploadFilesV2 emailNotify is empty");
            return files;
        }
        Map<String, String> publicFields = context.getPublicFields();
        Map<String, FieldInfo> formData = context.getFormData();
        ValueContent uploadFiles = emailNotify.getUploadFiles();
        if (null == uploadFiles) {
            log.info("GetUploadFilesV2 uploadFiles is empty");
            return files;
        }
        List<FieldValue> fields = uploadFiles.getFields();
        if (CollUtil.isEmpty(fields)) {
            log.info("GetUploadFilesV2 uploadFiles fields is empty");
            return files;
        }
        for (FieldValue fieldValue : fields) {
            String name = fieldValue.getName();
            FieldInfo fieldInfo = formData.get(name);
            if (fieldInfo != null && FieldValueTypeEnum.UPLOAD.equals(fieldInfo.getFieldType())) {
                UploadFieldV2 upload = (UploadFieldV2) fieldInfo.getFieldValueObj();
                FileUploadBeanV2 uploadBeanV2s = upload.getValue();
                if (uploadBeanV2s == null) {
                    continue;
                }
                List<FileBean> fileBeans = uploadBeanV2s.convertFileBeanList();
                for (FileBean fileBean : fileBeans) {
                    String id = fileBean.getId();
                    UploadFileInfo uploadFileInfo = getUploadFileMapper().selectFileInfoListById(id);
                    if (uploadFileInfo != null) {
                        UploadFileInfoDto file = new UploadFileInfoDto();
                        file.setFileName(uploadFileInfo.getFileName());
                        String url = uploadFileInfo.getUrl();
                        String path = url.substring(url.indexOf(File.separator) + 1);
                        file.setUrl(getDosmConfig().getCloudwiseDrivexBaseFilePath() + path);
                        file.setType(uploadFileInfo.getType());
                        file.setUid(uploadFileInfo.getUid());
                        files.add(file);
                    }
                }
            } else {
                String fileId = publicFields.get(name);
                if (CharSequenceUtil.isNotBlank(fileId)) {
                    List<String> fileIds = JsonUtils.convertList(fileId, String.class);
                    if (CollUtil.isEmpty(fileIds)) {
                        return files;
                    }
                    List<UploadFileInfo> uploadFileInfos = getUploadFileMapper().selectFileInfoListByIds(fileIds);
                    for (UploadFileInfo uploadFileInfo : uploadFileInfos) {
                        UploadFileInfoDto file = new UploadFileInfoDto();
                        file.setFileName(uploadFileInfo.getFileName());
                        String url = uploadFileInfo.getUrl();
                        String path = url.substring(url.indexOf(File.separator) + 1);
                        file.setUrl(getDosmConfig().getCloudwiseDrivexBaseFilePath() + path);
                        file.setType(uploadFileInfo.getType());
                        file.setUid(uploadFileInfo.getUid());
                        files.add(file);
                    }
                }
            }
        }
        return files;
    }




    protected String getBody(NotifyScenceEnum notifyScence, Map<String, Object> bindingMap) {
        String template = EmailTemplateUtil.get(notifyScence);
        return BpmTemplateUtil.renderNoSpecial(template, bindingMap);
    }



    /**
     * get email receivers
     *     <p>1、type is “NORMAL”，Preferentially get userId and get userEmail
     *     <p>2、type is “FORM”，Preferentially get userId and get userEmail
     */
    protected List<UserInfo> getEmailUsers(MessageContext context, List<ValueContent> emailUserContents) {
        List<UserInfo> resultList = Lists.newArrayList();
        if(CollUtil.isEmpty(emailUserContents)) {
            log.info("GetEmailUsers receivers is empty");
            return resultList;
        }

        Map<String, Set<String>> groupUserIdMap = Maps.newHashMap();
        Set<String> emailList = Sets.newHashSet();


        for(ValueContent emailUserContent: emailUserContents) {
            ValueTypeEnum valueType = emailUserContent.getType();
            if(ValueTypeEnum.NORMAL.equals(valueType)) {
                log.info("GetEmailUsers value type is normal");
                NormalValue normalValue = emailUserContent.getNormalValue();
                if(null == normalValue) {
                    log.info("GetEmailUsers normal value is empty");
                    continue;
                }

                /** Preferentially get userId, and get userEmail */
                List<String> userIds = normalValue.getUserIds();
                if(CollUtil.isNotEmpty(userIds)) {
                    groupUserIdMap.computeIfAbsent(null, k -> Sets.newHashSet()).addAll(userIds);
                }

                List<String> normalEmails = normalValue.getEmails();
                if(CollUtil.isNotEmpty(normalEmails)) {
                    emailList.addAll(normalEmails);
                }

            } else if(ValueTypeEnum.FORM.equals(valueType)) {
                log.info("GetEmailUsers value type is form");
                List<FieldValue> fields = emailUserContent.getFields();
                if(CollUtil.isEmpty(fields)) {
                    log.info("GetEmailUsers form type fields is empty");
                    continue;
                }

                Map<String, FieldInfo> formData = context.getFormData();
                for(FieldValue fieldValue: fields) {
                    String fieldCode = fieldValue.getName();
                    /** table data */
                    if(fieldCode.contains(EmailAnalysisUtil.COMMA)) {
                        String[] split = fieldCode.split(EmailAnalysisUtil.COMMA);
                        if(split.length != 2) {
                            log.info("[table data] not a table key name:{}", fieldCode);
                            continue;
                        }
                        String tableCode = split[0];
                        fieldCode = split[1];
                        FieldInfo tableField = formData.get(tableCode);
                        TableFormField tableForm = null;
                        Collection<RowData> rowDatas = null;
                        if(Objects.isNull(tableField) || Objects.isNull(tableForm = (TableFormField) tableField.getFieldValueObj()) || CollUtil.isEmpty(rowDatas = tableForm.getValue())) {
                            log.info("[table data] get tableCode:{} form data is null,", tableCode);
                            continue;
                        }
                        // userGroup or member data in table all row
                        for(RowData rowData: rowDatas) {
                            Map<String, FieldInfo> columnDataMap = rowData.getColumnDataMap();
                            handleGroupOrMemberField(columnDataMap, fieldCode, groupUserIdMap, emailList);
                        }
                    } else {
                        handleGroupOrMemberField(formData, fieldCode, groupUserIdMap, emailList);
                    }
                }
            }
        }


        List<UserInfo> userInfos = getUsers(groupUserIdMap);
        if(CollectionUtils.isNotEmpty(userInfos)) {
            resultList.addAll(userInfos);
        }

        if(CollectionUtils.isNotEmpty(emailList)) {
            emailList.forEach(email -> resultList.add(UserInfo.builder().email(email).userAlias(EmailAnalysisUtil.getUserNameByEmail(email)).build()));
        }

        return resultList;
    }

    protected void handleGroupOrMemberField(Map<String, FieldInfo> formData, String fieldCode, Map<String, Set<String>> groupUserIdMap, Set<String> emailList) {
        FieldInfo fieldInfo = formData.get(fieldCode);
        if (fieldInfo == null) {
            return;
        }

        if (FieldValueTypeEnum.GROUP.name().equals(fieldInfo.getFieldType().name())) {
            GroupField groupField = (GroupField) fieldInfo.getFieldValueObj();
            Collection<GroupBean> groups = groupField.getValue();

            if (CollUtil.isNotEmpty(groups)) {
                groups.forEach(group -> groupUserIdMap.computeIfAbsent(group.getGroupId(), key -> Sets.newHashSet()).add(group.getUserId()));
            }
        } else if (FieldValueTypeEnum.MEMBER.name().equals(fieldInfo.getFieldType().name())) {
            MemberField memberField = (MemberField) fieldInfo.getFieldValueObj();
            Collection<UserBean> userBeans = memberField.getValue();

            Set<String> userIdSet = groupUserIdMap.computeIfAbsent(null, key -> Sets.newHashSet());
            userBeans.forEach(user -> userIdSet.add(user.getUserId()));
        } else {
            String email = FieldBindVariableUtil.switchFieldType(formData, fieldCode, null);
            if(CharSequenceUtil.isNotBlank(email) && email.contains(EmailAnalysisUtil.AT)) {
                emailList.add(email);
            }
        }
    }

    protected List<UserInfo> getUsers(Map<String, Set<String>> groupUserIdMap) {
        if(MapUtil.isEmpty(groupUserIdMap)) {
            return null;
        }

        List<UserInfo> resultList = Lists.newArrayList();

        // user is not in userGroup
        Set<String> userIdSet = groupUserIdMap.remove(null);
        if(CollectionUtils.isNotEmpty(userIdSet)) {
            List<UserInfo> doucUserList = getUserSSOClient().getUserListByIds(userIdSet.stream().map(Long::parseLong).collect(Collectors.toList()), Long.valueOf(getDosmConfig().getUserId()), Long.valueOf(getDosmConfig().getAccountId()));
            if(CollectionUtils.isNotEmpty(doucUserList)) {
                resultList.addAll(doucUserList);
            }
        }

        // get user in userGroup
        for(Map.Entry<String, Set<String>> userGroupEntry: groupUserIdMap.entrySet()) {
            GroupUserInfo userGroupInfo = getUserGroupSSOClient().getUserGroupInfoById(Long.valueOf(userGroupEntry.getKey()), true, EmailAnalysisUtil.ACCOUNT_SCOPE);
            if(CollectionUtils.isEmpty(userGroupInfo.getUserInfoList())) {
                // userGroup is not exist or not user in userGroup
                continue;
            }

            // only is userGroup
            if(CollectionUtils.isEmpty(userGroupEntry.getValue()) || userGroupEntry.getValue().contains(null)) {
                userGroupInfo.getUserInfoList().forEach(user -> resultList.add(UserInfo.builder().userId(user.getUserId()).userAlias(user.getName()).email(user.getEmail()).build()));
            } else {
                // is user in userGroup
                userGroupInfo.getUserInfoList().forEach(user -> {
                    if(userGroupEntry.getValue().contains(user.getUserId().toString())) {
                        resultList.add(UserInfo.builder().userId(user.getUserId()).userAlias(user.getName()).email(user.getEmail()).build());
                    }
                });
            }
        }

        return resultList;
    }






    protected UserInfo getRequestor(MessageContext context) {
        String createdById = context.getPublicFields().get(EmailTemplateConstants.PublicFields.CREATED_BY_ID);
        if(StringUtils.isBlank(createdById)) {
            log.error("PublicField createdById value is null");
            return null;
        }
        String createdByName = context.getPublicFields().get(EmailTemplateConstants.PublicFields.CREATED_BY_NAME);
        return UserInfo.builder().userId(Long.valueOf(createdById)).userAlias(createdByName).build();
    }

    /**
     * Primary and Secondary App Manager of Application Impacted
     */
    protected List<UserInfo> getAppManager4AppImpacted(MessageContext context, BiConsumer<AppManager4Impacted, Set<String>> appManagerFun) {
        Map<String, String> emailBodyFieldMap = getDosmConfig().getEmailConfig().getBodyFieldMap();
        if(emailBodyFieldMap == null) {
            log.error("emailBodyFieldMap is null");
            return null;
        }
        String applicationImpactedFieldCode = emailBodyFieldMap.get(EmailTemplateConstants.BodyField.APPLICATION_IMPACTED);
        FieldInfo applicationImpactedField = context.getFormData().get(applicationImpactedFieldCode);
        if(applicationImpactedField == null || applicationImpactedField.getFieldValueObj() == null) {
            log.error("fieldCode: {}, field is null", applicationImpactedFieldCode);
            return null;
        }
        Collection<String> applicationImpactedFieldValue = ((MultiSelectField)applicationImpactedField.getFieldValueObj()).getValue();
        if(CollectionUtils.isEmpty(applicationImpactedFieldValue)) {
            log.error("fieldCode: {}, field value is null", applicationImpactedFieldCode);
            return null;
        }

        List<AppManager4Impacted> appManager4Impacteds = getAppcodeLobCountryMapper().getAppManager4Impacted(applicationImpactedFieldValue);
        if(CollectionUtils.isEmpty(appManager4Impacteds)) {
            log.error("Primary and Secondary App Manager of Application Impacted is null, fieldCode: {}, appIds: {}", applicationImpactedFieldCode, applicationImpactedFieldValue);
            return null;
        }

        Set<String> userNameSet = Sets.newHashSet();
        appManager4Impacteds.forEach(appManager4Impacted -> {
            appManagerFun.accept(appManager4Impacted, userNameSet);
        });

        userNameSet.remove(null);
        if(CollectionUtils.isEmpty(userNameSet)) {
            log.error("userName is null, fieldCode: {}, appIds: {}", applicationImpactedFieldCode, applicationImpactedFieldValue);
            return null;
        }

        UserConditionReq req = new UserConditionReq();
        req.setAlias(Lists.newArrayList(userNameSet));
        req.setSize(userNameSet.size());
        List<com.cloudwise.douc.dto.v3.common.UserInfo> doucUserList = getUserSSOClient().getAllUserByCondition(req);
        if(CollectionUtils.isEmpty(doucUserList)) {
            log.error("doucUser is null, fieldCode: {}, appIds: {}, userNameSet: {}", applicationImpactedFieldCode, applicationImpactedFieldValue, userNameSet);
            return null;
        }

        return doucUserList.stream().map(user -> UserInfo.builder().userId(user.getId()).build()).collect(Collectors.toList());
    }

    /**
     * PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB)
     * @param context
     * @param groupCodeTemplate
     * @return
     */
    protected List<UserInfo> getUserByGroupCode(MessageContext context, String groupCodeTemplate) {
        Map<String, String> emailBodyFieldMap = getDosmConfig().getEmailConfig().getBodyFieldMap();
        if(emailBodyFieldMap == null) {
            log.error("emailBodyFieldMap is null");
            return null;
        }
        String countryOfOriginFieldCode = emailBodyFieldMap.get(EmailTemplateConstants.BodyField.COUNTRY_OF_ORIGIN);
        String lobFieldCode = emailBodyFieldMap.get(EmailTemplateConstants.BodyField.UNIT);
        if(countryOfOriginFieldCode == null || lobFieldCode == null) {
            log.error("countryOfOriginFieldCode: {}, lobFieldCode: {}, field is null", countryOfOriginFieldCode, lobFieldCode);
            return null;
        }

        FieldInfo countryOfOriginField = context.getFormData().get(countryOfOriginFieldCode);
        FieldInfo lobField = context.getFormData().get(lobFieldCode);
        if(countryOfOriginField == null || countryOfOriginField.getFieldValueObj() == null || lobField == null || lobField.getFieldValueObj() == null) {
            log.error("countryOfOriginFieldCode: {}, lobFieldCode: {}, field is null", countryOfOriginFieldCode, lobFieldCode);
            return null;
        }

        String countryOfOriginFieldValue = ((SelectField) countryOfOriginField.getFieldValueObj()).getValue();
        String lobFieldValue = ((SelectField) lobField.getFieldValueObj()).getValue();
        if(countryOfOriginFieldValue == null || lobFieldValue == null) {
            log.error("countryOfOriginFieldCode: {}, lobFieldCode: {}, field value is null", countryOfOriginFieldCode, lobFieldCode);
            return null;
        }

        return getUserByGroupCode(String.format(groupCodeTemplate, countryOfOriginFieldValue, lobFieldValue));
    }


    protected List<UserInfo> getUserByGroupCode(String groupCode) {
        UserConditionReq userConditionReq = new UserConditionReq();
        userConditionReq.setGroupCodes(Lists.newArrayList(groupCode));

        List<com.cloudwise.douc.dto.v3.common.UserInfo> userListInGroup = getUserSSOClient().getAllUserByCondition(userConditionReq);
        if(CollectionUtils.isEmpty(userListInGroup)) {
            log.error("groupCode: {}, user is null", groupCode);
            return null;
        }
        return userListInGroup.stream().map(user -> UserInfo.builder().userId(user.getId()).build()).collect(Collectors.toList());
    }









    private static DosmConfig DOSM_CONFIG;
    protected DosmConfig getDosmConfig() {
        return DOSM_CONFIG != null? DOSM_CONFIG: (DOSM_CONFIG = SpringUtil.getBean(DosmConfig.class));
    }

    private static UploadFileMapper UPLOAD_FILE_MAPPER;
    protected UploadFileMapper getUploadFileMapper() {
        return UPLOAD_FILE_MAPPER != null? UPLOAD_FILE_MAPPER: (UPLOAD_FILE_MAPPER = SpringUtil.getBean(UploadFileMapper.class));
    }

    private static DosmWorkOrderService DOSM_WORK_ORDER_SERVICE;
    protected DosmWorkOrderService getDosmWorkOrderService() {
        return DOSM_WORK_ORDER_SERVICE != null? DOSM_WORK_ORDER_SERVICE: (DOSM_WORK_ORDER_SERVICE = SpringUtil.getBean(DosmWorkOrderService.class));
    }

    private static UserGroupSSOClient USER_GROUP_SSO_CLIENT;
    protected UserGroupSSOClient getUserGroupSSOClient() {
        return USER_GROUP_SSO_CLIENT != null? USER_GROUP_SSO_CLIENT: (USER_GROUP_SSO_CLIENT = SpringUtil.getBean(UserGroupSSOClient.class));
    }

    private static UserSSOClient USER_SSO_CLIENT;
    protected UserSSOClient getUserSSOClient() {
        return USER_SSO_CLIENT != null? USER_SSO_CLIENT: (USER_SSO_CLIENT = SpringUtil.getBean(UserSSOClient.class));
    }

    private static AppcodeLobCountryMapper APPCODE_LOB_COUNTRY_MAPPER;
    protected AppcodeLobCountryMapper getAppcodeLobCountryMapper() {
        return APPCODE_LOB_COUNTRY_MAPPER != null? APPCODE_LOB_COUNTRY_MAPPER: (APPCODE_LOB_COUNTRY_MAPPER = SpringUtil.getBean(AppcodeLobCountryMapper.class));
    }
}
