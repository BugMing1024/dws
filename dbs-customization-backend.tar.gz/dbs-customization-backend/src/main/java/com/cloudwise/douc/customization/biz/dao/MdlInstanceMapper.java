package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.MdlInstance;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-11  16:39
 **/
@Mapper
public interface MdlInstanceMapper extends BaseMapper<MdlInstance> {
    
    String getWorkOrderIdByBizKey(String bizKey);
    
    List<MdlInstance> selectRunningList();
    
    MdlInstance selectMdlInstanceById(String workOrderId);

    String getMainWorkOrderId(String workOrderId);


    void updateFormDataByFieldKey(String workOrderId, String fieldKey, String value);

    int updateByIdSelective(MdlInstance record);

    /**
     * groupId,dateTime
     * @param map
     * @return
     */
    List<MdlInstance> getBizKeyFromCRStatusAndTime(Map<String,Object> map);

    
}
