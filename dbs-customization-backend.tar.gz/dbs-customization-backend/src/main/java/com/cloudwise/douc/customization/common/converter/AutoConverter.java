package com.cloudwise.douc.customization.common.converter;

import cn.hutool.core.convert.Converter;

/**
 * Created on 2022-3-4. 只给MappingProperty做默认值，无用
 *
 * @author skiya
 */
public class AutoConverter implements Converter<Object> {
    
    @Override
    public Object convert(Object value, Object defaultValue) throws IllegalArgumentException {
        return value;
    }
}
