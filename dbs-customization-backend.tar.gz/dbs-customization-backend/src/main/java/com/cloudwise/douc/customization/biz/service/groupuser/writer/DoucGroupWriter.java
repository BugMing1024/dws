package com.cloudwise.douc.customization.biz.service.groupuser.writer;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.context.ExecutorContext;
import com.cloudwise.douc.customization.common.context.ExecutorContextHolder;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.dto.DubboSyncResultInfo;
import com.cloudwise.douc.dto.v3.common.CommonResp;
import com.cloudwise.douc.dto.v3.common.DataMode;
import com.cloudwise.douc.dto.v3.common.GroupInfo;
import com.cloudwise.douc.dto.v3.common.PageResp;
import com.cloudwise.douc.dto.v3.common.UserInfo;
import com.cloudwise.douc.dto.v3.group.AddOrUpdateGroupReq;
import com.cloudwise.douc.dto.v3.group.DeleteGroupReq;
import com.cloudwise.douc.dto.v3.group.GroupConditionReq;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.cloudwise.douc.facadev3.GroupFacade;
import com.cloudwise.douc.facadev3.UserFacade;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created on 2022-4-8.
 *
 * @author skiya
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DoucGroupWriter implements Writer<AddOrUpdateGroupReq> {
    
    private final DoucProperties doucProperties;
    
    private final DbsProperties dbsProperties;
    
    //    @DubboReference(lazy = true, check = false, timeout = 5000, url = "rest://${rest.svc.douc:}")
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private GroupFacade groupFacade;

    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserFacade userFacade;
    
    @Override
    public void write(List<AddOrUpdateGroupReq> groups) {
        if (CollUtil.isEmpty(groups)) {
            return;
        }
        // 过滤异常数据
        List<AddOrUpdateGroupReq> filterGroups = filterWarnGroups(groups);
        // 获取到所有顶级用户组，查询并整合出删除的子用户组
        List<String> parentCodes = Lists.newArrayList(dbsProperties.getApprover().getGroupCode(), dbsProperties.getMdApprover().getGroupCode(),
                dbsProperties.getImplementer().getGroupCode(), dbsProperties.getRelease().getGroupCode(), dbsProperties.getChange().getGroupCode());
        CommonResp<PageResp<GroupInfo>> commonResp = getDoucGroups(parentCodes);
        if (!commonResp.isSuccess()) {
            log.error("sync group data failed, data:{}", JsonUtils.toJsonStr(commonResp));
            return;
        }
        List<GroupInfo> records = commonResp.getData().getRecords();
        Set<String> failIds = CollUtil.newHashSet();
        if (CollUtil.isEmpty(records)) {
            addOrUpdate(filterGroups, failIds);
        } else {
            List<Long> deleteIds = records.stream().filter(record -> StrUtil.isBlank(record.getCode())).map(GroupInfo::getId)
                    .collect(Collectors.toList());
            List<String> doucChildCodes = records.stream().filter(record -> StrUtil.isNotBlank(record.getCode()))
                    .filter(record -> !parentCodes.contains(record.getCode())).map(GroupInfo::getCode).collect(Collectors.toList());
            List<String> dbsChildCodes = filterGroups.stream().filter(addOrUpdateGroupReq -> !parentCodes.contains(addOrUpdateGroupReq.getCode()))
                    .map(AddOrUpdateGroupReq::getCode).collect(Collectors.toList());
            List<String> deleteCodes = CollUtil.subtractToList(doucChildCodes, dbsChildCodes);
            List<AddOrUpdateGroupReq> addOrUpdateGroupReqs = filterGroups.stream()
                    .filter(addOrUpdateGroupReq -> !deleteCodes.contains(addOrUpdateGroupReq.getCode())).collect(Collectors.toList());
            addOrUpdateGroupReqs.sort((o1, o2) -> {
                if (parentCodes.contains(o1.getParentCode()) && !parentCodes.contains(o2.getParentCode())) {
                    return -1;
                }
                if (parentCodes.contains(o1.getParentCode()) && parentCodes.contains(o2.getParentCode())) {
                    return 0;
                }
                if (!parentCodes.contains(o1.getParentCode()) && !parentCodes.contains(o2.getParentCode())) {
                    return 0;
                }
                return 1;
            });
            // 优先父，然后子
            
            //处理子用户组下的用户
            //            fillRemoveUser(dbsChildCodes, addOrUpdateGroupReqs);
            addOrUpdate(addOrUpdateGroupReqs, failIds);
            //            delete(deleteIds, deleteCodes, failIds);
        }
        
        Optional.ofNullable(ExecutorContextHolder.get()).map(ExecutorContext::getProcessorCountContext).ifPresent(context -> {
            context.updateFailedCount(failIds.size());
        });
        
    }
    
    private static List<AddOrUpdateGroupReq> filterWarnGroups(List<AddOrUpdateGroupReq> groups) {
        Map<String, Integer> codeCountMap = new HashMap<>();
        List<AddOrUpdateGroupReq> filterGroups = groups.stream()
                .collect(Collectors.collectingAndThen(Collectors.toMap(AddOrUpdateGroupReq::getCode, a -> {
                    // 记录每个code出现的次数，用于判断是否重复
                    codeCountMap.put(a.getCode(), codeCountMap.getOrDefault(a.getCode(), 0) + 1);
                    return a;
                }, (a, b) -> {
                    log.warn("sync group data filter repeat code: {}, data1: {}, data2: {}", a.getCode(), a, b);
                    return a;
                }), map -> new ArrayList<>(map.values())));
        return filterGroups;
    }
    
    private CommonResp<PageResp<GroupInfo>> getDoucGroups(List<String> parentCodes) {
        GroupConditionReq groupConditionReq = new GroupConditionReq();
        groupConditionReq.setCodes(parentCodes);
        groupConditionReq.setIncludeJuniorGroup(false);
        groupConditionReq.setAccountId(110L);
        groupConditionReq.setUserId(1L);
        groupConditionReq.setSize(99999L);
        groupConditionReq.setReqMode(1);
        groupConditionReq.setIds(Lists.newArrayList());
        CommonResp<PageResp<GroupInfo>> groupByCondition = groupFacade.getGroupByCondition(groupConditionReq);
        if (groupByCondition.isSuccess()) {
            List<GroupInfo> records = groupByCondition.getData().getRecords();
            if (CollUtil.isNotEmpty(records)) {
                groupConditionReq.setIncludeJuniorGroup(true);
                groupConditionReq.setIds(records.stream().map(GroupInfo::getId).collect(Collectors.toList()));
                groupConditionReq.setReqMode(4);
                groupConditionReq.setCodes(Lists.newArrayList());
                return groupFacade.getGroupByCondition(groupConditionReq);
            }
        }
        return CommonResp.failResp();
    }
    
    private void addOrUpdate(List<AddOrUpdateGroupReq> filterGroups, Set<String> failIds) {
        Lists.partition(filterGroups, doucProperties.getMaxSyncSize()).forEach(part -> {
            try {
                if (!Objects.equals(doucProperties.getIgnoreNull(), true)) {
                    part.stream().forEach(addOrUpdateGroupReq -> {
                        addOrUpdateGroupReq.setDataModel(DataMode.EMPTY);
                    });
                }
                log.info("sync group addOrUpdate data:{}", part);
                CommonResp<List<DubboSyncResultInfo>> listCommonResp = groupFacade.addOrUpdateUserGroup(part);
                log.info("sync group addOrUpdate result:{}", JsonUtils.toJsonStr(listCommonResp));
                if (!listCommonResp.isSuccess()) {
                    Set<String> failCodes = new HashSet<>();
                    listCommonResp.getData().stream().filter(dubboSyncResultInfo -> CollUtil.isNotEmpty(dubboSyncResultInfo.getDataCodes()))
                            .forEach(dubboSyncResultInfo -> failCodes.addAll(dubboSyncResultInfo.getDataCodes()));
                    failIds.addAll(failCodes);
                }
                ThreadUtil.sleep(doucProperties.getAntiRateLimitInterval());
            } catch (Exception e) {
                log.warn("sync group addOrUpdate failed, data:{}", part, e);
                failIds.addAll(part.stream().map(AddOrUpdateGroupReq::getCode).collect(Collectors.toList()));
            }
        });
    }
    
    private void fillRemoveUser(List<String> dbsChildCodes, List<AddOrUpdateGroupReq> addOrUpdateGroupReqs) {
        UserConditionReq userConditionReq = new UserConditionReq();
        userConditionReq.setGroupCodes(dbsChildCodes);
        userConditionReq.setAccountId(110L);
        userConditionReq.setRespMode(4);
        userConditionReq.setSize(99999L);
        CommonResp<PageResp<UserInfo>> userByCondition = userFacade.getUserByCondition(userConditionReq);
        if (userByCondition.isSuccess()) {
            List<UserInfo> userInfos = userByCondition.getData().getRecords();
            Map<String, List<String>> groupCodeAndUserCodeMap = Maps.newHashMap();
            userInfos.forEach(userInfo -> {
                userInfo.getGroupRelation().stream().filter(groupInfo -> StrUtil.isNotBlank(groupInfo.getCode())).forEach(groupRelation -> {
                    List<String> userCodes = CollUtil.defaultIfEmpty(groupCodeAndUserCodeMap.get(groupRelation.getCode()), new ArrayList<>());
                    userCodes.add(StrUtil.blankToDefault(userInfo.getCode(), userInfo.getAlias()));
                    groupCodeAndUserCodeMap.put(groupRelation.getCode(), userCodes);
                });
            });
            if (MapUtil.isNotEmpty(groupCodeAndUserCodeMap)) {
                addOrUpdateGroupReqs.forEach(addOrUpdateGroupReq -> {
                    List<String> doucUserCodes = groupCodeAndUserCodeMap.get(addOrUpdateGroupReq.getCode());
                    if (CollUtil.isNotEmpty(doucUserCodes)) {
                        addOrUpdateGroupReq.setRemoveUserCodes(CollUtil.subtractToList(doucUserCodes, addOrUpdateGroupReq.getAddUserCodes()));
                    }
                });
            }
        }
    }
    
    private void delete(List<Long> deleteIds, List<String> deleteCodes, Set<String> failIds) {
        try {
            DeleteGroupReq deleteGroupReq = new DeleteGroupReq();
            deleteGroupReq.setCodes(deleteCodes);
            deleteGroupReq.setIds(deleteIds);
            deleteGroupReq.setAccountId(110L);
            deleteGroupReq.setUserId(1L);
            log.info("sync group delete data:{}", deleteGroupReq);
            CommonResp<Void> voidCommonResp = groupFacade.deleteUserGroup(deleteGroupReq);
            log.info("sync group delete result:{}", JsonUtils.toJsonStr(voidCommonResp));
            if (!voidCommonResp.isSuccess()) {
                failIds.addAll(deleteCodes);
            }
        } catch (Exception e) {
            log.warn("sync group delete failed, data:{}", deleteCodes, e);
            failIds.addAll(deleteCodes);
        }
    }
    
}
