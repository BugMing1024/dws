package com.cloudwise.douc.customization.biz.service.appcode;

import com.cloudwise.douc.customization.biz.model.appcode.ServerDetatils;

import java.util.List;

/**
 * @author Magina
 * @date 2024/12/6 4:59 PM
 * @description
 **/
public interface AppcodeLobCountrySyncService {
    
    Integer syncAppcodeLobCountryData();
    
    Integer syncAppcodesPendingProjectListData();
    
    Integer syncAppCodeInfo();

    Integer syncAppCodeResiliencyInfo();

    Integer syncServerDetatils();
    
    Integer testServerDetatils();
    
    List<ServerDetatils> selectServerDetatils();
}
