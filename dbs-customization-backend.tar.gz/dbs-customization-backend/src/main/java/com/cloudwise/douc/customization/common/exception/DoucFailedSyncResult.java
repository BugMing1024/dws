package com.cloudwise.douc.customization.common.exception;

import lombok.Data;

import java.util.Collection;

/**
 * Created on 2022-4-26.
 *
 * @author skiya
 */
@Data
public class DoucFailedSyncResult {
    
    /**
     * 同步失败错误码
     */
    private String code;
    
    
    /**
     * 同步失败错误描述消息
     */
    private String message;
    
    
    /**
     * 同步失败数据唯一id集合
     */
    private Collection<String> failIds;
}
