package com.cloudwise.douc.customization.common.kafka;

public interface MetaMessageService {
    
    
    /**
     * 消息中间件类型 * @return
     */
    String messageType();
    
    
    /**
     * 发送消息 * @param topic
     *
     * @param tags
     * @param msgBody
     */
    boolean sendMessage(String topic, String tags, String msgBody);
    
    
    /**
     * 消费消息 MessageListenerConcurrently messageListener
     *
     * @param topic
     * @param messageListener
     * @param broadcasting
     */
    void startConsume(String consumerGroup, String topic, Object messageListener, boolean broadcasting);
    
    
}

