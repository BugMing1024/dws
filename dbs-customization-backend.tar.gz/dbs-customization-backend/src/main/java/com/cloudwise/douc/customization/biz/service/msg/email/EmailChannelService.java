package com.cloudwise.douc.customization.biz.service.msg.email;

import com.cloudwise.douc.dto.DubboChannelRealConfigResponse;

/**
 * @author ming.ma
 * @since 2024-12-05  10:12
 **/
public interface EmailChannelService {
    
    /**
     * 根据渠道ID查询渠道信息
     *
     * @param channelId
     * @return
     */
    DubboChannelRealConfigResponse getChannelConfigById(Long channelId, String accountId);
}
