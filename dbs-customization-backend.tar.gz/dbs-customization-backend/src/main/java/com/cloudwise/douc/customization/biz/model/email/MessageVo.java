package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import lombok.Data;

import java.util.List;

/**
 * @author ming.ma
 * @since 2025-01-07  14:23
 **/
@Data
public class MessageVo {

    private String detailUrl;

    private NotifyWayEnum notifyWay;

    /**
     * 通知场景
     */
    private NotifyScenceEnum notifyScene;

    private String title;

    private String body;

    private List<UserInfo> receivers;


    /**
     * 创建用户id
     */
    private String createdBy;

    /**
     * 顶级租户ID
     */
    private String topAccountId;

    /**
     * 租户id
     */
    private String accountId;

    /**
     * 工单id
     */
    private String workOrderId;

    /**
     * 节点id
     */
    private String nodeId;

    /**
     * 原始请求参数
     */
    private MessageContext messageContext;
}
