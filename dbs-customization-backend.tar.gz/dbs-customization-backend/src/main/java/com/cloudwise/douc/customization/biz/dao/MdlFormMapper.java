package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.MdlForm;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author ming.ma
 * @since 2024-12-11  16:39
 **/
@Mapper
public interface MdlFormMapper extends BaseMapper<MdlForm> {
    
    String getFieldListById(String formId, String accountId, String topAccountId);
    
    String getFormId(String workOrderId);
}
