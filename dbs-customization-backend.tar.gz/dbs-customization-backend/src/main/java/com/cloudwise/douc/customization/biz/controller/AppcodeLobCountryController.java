package com.cloudwise.douc.customization.biz.controller;

import com.cloudwise.douc.customization.biz.model.appcode.AppCodeReq;
import com.cloudwise.douc.customization.biz.model.appcode.ServerDetatils;
import com.cloudwise.douc.customization.biz.service.appcode.AppcodeLobCountryService;
import com.cloudwise.douc.customization.biz.service.appcode.AppcodeLobCountrySyncService;
import com.cloudwise.douc.dto.v3.common.CommonResp;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Magina
 * @date 2024/12/6 5:26 PM
 * @description zafir:I don't know why, keep it, but I should use another interface
 **/
@Slf4j
@RestController
@RequestMapping("/api/appcodeLobCountry")
@Api(value = "Custom interface")
public class AppcodeLobCountryController {
    
    
    @Autowired
    private AppcodeLobCountrySyncService appcodeLobCountrySyncService;
    
    @Autowired
    private AppcodeLobCountryService appcodeLobCountryService;
    
    
    @GetMapping("/testServerDetatils")
    public Map testServerDetatils() {
        Integer integer = appcodeLobCountrySyncService.testServerDetatils();
        HashMap<Object, Object> map = new HashMap<>();
        map.put("number", integer);
        return map;
    }
    
    
    @GetMapping("/serverDetatilsList")
    public Map serverDetatilsList() {
        List<ServerDetatils> serverDetatilsList = appcodeLobCountrySyncService.selectServerDetatils();
        HashMap<Object, Object> map = new HashMap<>();
        map.put("message", "SUCCESS");
        map.put("data", serverDetatilsList);
        return map;
    }
    
    @PostMapping("checkMasFlag")
    public CommonResp<Boolean> checkMasFlag(@RequestBody AppCodeReq appCodeReq) {
        return CommonResp.successResp(appcodeLobCountryService.checkMasFlag(appCodeReq));
    }
    
    
}
