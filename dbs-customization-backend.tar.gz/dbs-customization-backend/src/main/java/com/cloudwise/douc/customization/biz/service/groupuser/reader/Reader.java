package com.cloudwise.douc.customization.biz.service.groupuser.reader;

import org.springframework.core.GenericTypeResolver;

import java.util.List;

/**
 * Created on 2022-4-8.
 *
 * @author skiya
 */
public interface Reader<T> {
    
    /**
     * 读
     *
     * @param param 读取参数
     * @return 数据源集合
     */
    List<T> read(Object... param);
    
    default List<T> afterRead(List<T> records) {
        return records;
    }
    
    /**
     * 得到元素类型
     *
     * @return {@link Class}<{@link T}>
     */
    @SuppressWarnings("unchecked")
    default Class<T> getElementClass() {
        return (Class<T>) GenericTypeResolver.resolveTypeArgument(this.getClass(), Reader.class);
    }
}
