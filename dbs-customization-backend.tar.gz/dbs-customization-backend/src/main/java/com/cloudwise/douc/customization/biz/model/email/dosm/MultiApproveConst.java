package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.Getter;
import lombok.Setter;

/**
 * @author wuzhaoyi
 */
public interface MultiApproveConst {
    
    /**
     * 多人会签通过规则
     * <p>
     * - 全部通过：所有人必须审批完成，且全部通过。 - 任一通过：任意一个人审批通过即可为会签审批通过，会签任务可提前结束。 - 自定义通过：可根据匹配通过数和通过占比条件决定会签是否通过，支持会签通过提前结束会签任务，也可以等所有人审批完后在结束会签任务
     */
    enum MultApprovePassRuleEnum {
        ALL("全部通过"),
        ANY("任一通过"),
        CUSTOM("自定义通过");
        
        @Setter
        @Getter
        private String desc;
        
        MultApprovePassRuleEnum(String desc) {
            this.desc = desc;
        }
    }
    
    /**
     * 多人会签驳回规则
     * <p>
     * - 全部驳回：所有人必须审批完成，且全部驳回。 - 任一驳回：任意一个人审批驳回即可为会签审批驳回，会签任务可提前结束。 - 自定义驳回：可根据匹配驳回数和驳回占比条件决定会签是否驳回过，支持会签驳回提前结束会签任务，也可以等所有人审批完后结束
     */
    enum MultApproveRejectRuleEnum {
        ALL("全部驳回"),
        ANY("任一驳回"),
        CUSTOM("自定义驳回");
        
        @Setter
        @Getter
        private String desc;
        
        MultApproveRejectRuleEnum(String desc) {
            this.desc = desc;
        }
    }
    
    
    enum CustomPassRuleTypeEnum {
        /**
         * 按通过次数
         */
        PASS_TIMES,
        
        /**
         * 按通过比例
         */
        PASS_PROPORTION,
        
    }
    
    
    enum CustomRejectRuleTypeEnum {
        
        /**
         * 按驳回次数
         */
        REJECT_TIMES,
        
        /**
         * 按驳回比例
         */
        REJECT_PROPORTION,
        
    }
    
    /**
     * 会签结束设置
     */
    @Deprecated
    enum MultiApproveFinishEnum {
        
        
        /**
         * 所有人完成审批
         */
        ALL_PERSON_PASS,
        
        /**
         * 满足“通过规则”或无法达成“通过规则”时立即结束
         */
        MATCH_PASS_RULE;
        
        
    }
    
    /**
     * 会签结束设置
     */
    enum MultiApproveFinishWhenEnum {
        
        /**
         * 满足通过规则
         */
        WHEN_MEET_PASS_RULE,
        
        /**
         * 无法达成通过规则
         */
        WHEN_CANNOT_MEET_PASS_RULE,
        
        /**
         * 满足驳回规则
         */
        WHEN_MEET_REJECT_RULE,
        
        //        WHEN_CANNOT_MEET_REJECT_RULE
        
        ;
        
    }
    
    
    enum ConditionTypeEnum {
        /**
         * 等于
         */
        EQ,
        /**
         * 大于
         */
        GT,
        /**
         * 大于或等于
         */
        GE,
    }
    
    @Getter
    enum ApprovePassRuleComputeResultEnum {
        /**
         * 通过
         */
        MEET_PASS(ApproveResultEnum.PASS),
        /**
         * 无法达成通过
         */
        CANNOT_MEET_PASS(ApproveResultEnum.REJECT);
        
        private final ApproveResultEnum approveResult;
        
        ApprovePassRuleComputeResultEnum(ApproveResultEnum approvalResult) {
            this.approveResult = approvalResult;
        }
        
    }
    
    @Getter
    enum ApproveRejectRuleComputeResultEnum {
        /**
         * 驳回
         */
        MEET_REJECT(ApproveResultEnum.REJECT),
        /**
         * 无法达成驳回 无法达成驳回不一定算通过，无法直接决定审批结果
         */
        CANNOT_MEET_REJECT(null);
        
        private final ApproveResultEnum approveResult;
        
        ApproveRejectRuleComputeResultEnum(ApproveResultEnum approvalResult) {
            this.approveResult = approvalResult;
        }
        
    }
    
}
