package com.cloudwise.douc.customization.biz.model.email.dosm;

/**
 * 驳回设置项
 *
 * @author jon.lee
 * @since 2022-05-14 16:03
 **/
public enum RejectToEnum {

    /**
     * 首节点
     */
    FIRST_NODE,
    /**
     * 上一节点
     */
    LAST_NODE,

    /**
     * 继续流转
     */
    CONTINUE,
    /**
     * 单前节点
     */
    CURRENT_NODE;

}
