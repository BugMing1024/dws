package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.Data;

/**
 * @author ming.ma
 * @since 2024-12-12  18:02
 **/
@Data
public class FileInfo {
    
    /*** {
     *     "uid": "rc-upload-1733991519245-6",
     *     "name": "20230901-141706.jpeg",
     *     "size": "360.01KB",
     *     "load": false,
     *     "type": "img",
     *     "id": "289b8fe7db13410288f645257086df85",
     *     "url": "/gateway/dosm/api/v2/file/review?businessExt=%7B%22draft%22%3Afalse%2C%22nodeId%22%3A%22UserTask_10pnp20%22%2C%22enableType%22%3A%22myDone%22%2C%22taskId%22%3A%22e828ba3f-b867-11ef-a320-566f1f6e0148%22%7D&businessId=zvEB8IeGSnJHLVPwodfP8T5SkOIK8lVd&id=289b8fe7db13410288f645257086df85&menuCode=&moduleCode=WORK_ORDER",
     *     "uploadUserName": "Admin(Admin)"
     *  }
     */
    private String uid;
    
    private String name;
    
    private String size;
    
    private boolean load;
    
    private String id;
}
