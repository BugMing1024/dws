package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;


import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.dto.DubboUpdateUser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Created on 2022-4-22.
 *
 * @author skiya
 */
@Component
@RequiredArgsConstructor
public class DefaultUserMappingHook<T> implements MappingHook<T, DubboUpdateUser> {
    
    private final DoucProperties doucProperties;
    
    private final ExtendFieldMappings extendFieldMappings;
    
    @Override
    public void beforeMapping(T source) {
    
    }
    
    @Override
    public void afterMapping(T source, DubboUpdateUser target) {
        target.setAccountId(doucProperties.getAccountId());
        if (target.getExtendFields() == null) {
            target.setExtendFields(extendFieldMappings.mapping(source));
        }
        if (doucProperties.getUserActiveDefault()) {
            target.setStatus(1);
        }
    }
}
