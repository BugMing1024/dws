package com.cloudwise.douc.customization.biz.service.msg.sms.config;

import lombok.Data;

import java.util.Map;

/**
 * @Author frank.zheng
 * @Date 2025-02-10
 */
@Data
public class SmsConfig {

    /** sms body field value format config */
    private Map<String, String> fieldValueFormatMap;

    /** reference：https://yunzhihui.feishu.cn/wiki/QYkbwbPnAinQUMkn4NTcJBlMn2c */
    private Map<String, String> bodyFieldMap;


}
