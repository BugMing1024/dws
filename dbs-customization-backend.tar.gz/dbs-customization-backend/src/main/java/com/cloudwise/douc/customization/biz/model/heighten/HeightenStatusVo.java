package com.cloudwise.douc.customization.biz.model.heighten;

/**
 * @author Magina
 * @date 2024/12/17 6:48 下午
 * @description
 **/
public class HeightenStatusVo {

}
