package com.cloudwise.douc.customization.biz.service.email;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageReadRecord;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  10:05
 **/
public interface CustomMessageReadRecordService extends IService<CustomMessageReadRecord> {
    
    String insertRecord(CustomMessageReadRecord messageRecord);

    void insertRecords(List<CustomMessageReadRecord> list);

    String updateStatus(String id);
    
    CustomMessageReadRecord getCustomMessageReadRecordByMessageId(String messageId);
}
