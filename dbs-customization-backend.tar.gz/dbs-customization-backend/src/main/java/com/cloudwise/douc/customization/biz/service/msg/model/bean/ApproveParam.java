package com.cloudwise.douc.customization.biz.service.msg.model.bean;

import com.cloudwise.douc.customization.biz.enums.EmailApproveEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author frank.zheng
 * @Date 2025-02-07
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveParam {

    /**
     * "Approved" or "Rejected"
     */
    private EmailApproveEnum status;


    private String workOrderId;

    private String signOffId;

    /** Custom Message Record Id */
    private String msgRecordId;
}
