package com.cloudwise.douc.customization.biz.enums;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * CR流转阶段枚举
 *
 * @author ming.ma
 * @since 2024-12-05  15:15
 **/
public enum CRStageEnum {
    
    /**
     * Signoff阶段
     */
    SIGN_OFF("Signoff"),
    
    /**
     * Approval阶段
     */
    APPROVAL("Approval"),
    
    /**
     * LV Signoff阶段
     */
    LV_SIGN_OFF("LV Signoff");
    
    private String name;
    
    CRStageEnum(String name) {
        this.name = name;
    }
    
    public static Optional<CRStageEnum> ofNullable(String name) {
        return Stream.of(values()).filter(bean -> bean.getName().equals(name)).findAny();
    }
    
    public String getName() {
        return name;
    }
}
