package com.cloudwise.douc.customization.common.config.xxl.service.impl;


import cn.hutool.http.ContentType;
import cn.hutool.http.Header;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.cloudwise.douc.customization.common.config.xxl.config.XxlJobConfig;
import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorRouteStrategyEnum;
import com.cloudwise.douc.customization.common.config.xxl.model.XxlJobGroup;
import com.cloudwise.douc.customization.common.config.xxl.model.XxlJobInfo;
import com.cloudwise.douc.customization.common.config.xxl.service.IXxlJobService;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @Author zafir.zhong
 * @Since: 2023-08-06 15:28
 */
@Component
@Slf4j
public class XxlJobServiceImpl implements IXxlJobService {
    
    private static final String TITLE = "DCS";
    
    private static final String AUTHOR = "DCS";
    
    @Resource
    private XxlJobConfig xxlJobConfig;
    
    /**
     * 将Object对象里面的属性和值转化成Map对象
     *
     * @param obj
     * @return
     * @
     */
    private static Map<String, Object> objectToMap(Object obj) {
        Map<String, Object> map = new HashMap<>();
        Class<?> clazz = obj.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            ReflectionUtils.makeAccessible(field);
            String fieldName = field.getName();
            try {
                Object value = field.get(obj);
                if (value != null) {
                    map.put(fieldName, value.toString());
                }
            } catch (Exception exception) {
                log.error("xxl job field error", exception);
            }
            
        }
        return map;
    }
    
    @Override
    public void registerJobHandler(XxlJobGroup xxlJobGroup) {
        log.debug("register job handler {}", xxlJobGroup);
        String url = xxlJobConfig.getBaseUrl() + "/jobgroup/save";
        Map<String, Object> params = objectToMap(xxlJobGroup);
        HttpResponse execute = doRequest("registerJobHandler", url, params);
        if (!success(execute)) {
            log.error("registerJobHandler fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
    @Override
    public void updateJonHandler(XxlJobGroup xxlJobGroup) {
        log.debug("update job handler {}", xxlJobGroup);
        String url = xxlJobConfig.getBaseUrl() + "/jobgroup/update";
        Map<String, Object> params = objectToMap(xxlJobGroup);
        HttpResponse execute = doRequest("updateJonHandler", url, params);
        if (!success(execute)) {
            log.error("updateJonHandler fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
    @Override
    public void delJobHandler(int id) {
        log.debug("delete job handler ,id :{}", id);
        String url = xxlJobConfig.getBaseUrl() + "/jobgroup/remove";
        Map<String, Object> params = new HashMap<>();
        params.put("id", String.valueOf(id));
        HttpResponse execute = doRequest("delJobHandler", url, params);
        if (!success(execute)) {
            log.error("delJobHandler fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
    private HttpResponse doRequest(String key, String url, Map<String, Object> params) {
        Map<String, List<String>> requestHeaders = loginAndBuildHeader();
        HttpRequest form = HttpRequest.post(url).header(requestHeaders).form(params);
        log.debug("{} req:{}", key, form);
        HttpResponse execute = form.execute();
        log.debug("{} resp:{}", key, execute);
        return execute;
    }
    
    private boolean success(HttpResponse response) {
        return Objects.equals(response.getStatus(), 200);
    }
    
    private Map<String, List<String>> loginAndBuildHeader() {
        String url = xxlJobConfig.getBaseUrl() + "/login";
        Map<String, Object> params = new HashMap<>();
        params.put("userName", xxlJobConfig.getUserName());
        params.put("password", xxlJobConfig.getPassword());
        
        HttpRequest form = HttpRequest.post(url).contentType(ContentType.FORM_URLENCODED.getValue()).form(params);
        log.debug("request xxl job login request:{}", form);
        HttpResponse execute = form.execute();
        log.debug("request xxl job login resp :{} ", execute);
        if (Objects.equals(execute.getStatus(), 200)) {
            List<String> cookies = execute.headerList("Set-Cookie");
            Map<String, List<String>> headers = new HashMap<>();
            headers.put("Cookie", cookies);
            headers.put(Header.CONTENT_TYPE.getValue(), Collections.singletonList(ContentType.FORM_URLENCODED.getValue()));
            return headers;
        } else {
            log.error("request xxl job login fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
    @Override
    public int registerJob(XxlJobInfo info) {
        log.info("register job:{}", info);
        String url = xxlJobConfig.getBaseUrl() + "/jobinfo/add";
        Map<String, Object> params = objectToMap(info);
        HttpResponse execute = doRequest("registerJob", url, params);
        if (!success(execute)) {
            log.error("registerJob fail resp :{}", execute);
            throw new RuntimeException("error");
        }
        String body = execute.body();
        Map<String, Object> resp = JsonUtils.toBean(body, new TypeReference<Map<String, Object>>() {
            @Override
            public Type getType() {
                return super.getType();
            }
        });
        return Integer.parseInt(resp.get("content").toString());
    }
    
    @Override
    public void registerJob(String name, String cron, String clazz, XxlJobGroup xxlJobGroup, ExecutorRouteStrategyEnum route) {
        // 生成实体对象
        XxlJobInfo info = XxlJobInfo.builder().jobGroup(xxlJobGroup.getId()).jobDesc("douc auto registerJob " + clazz).author(AUTHOR)
                .scheduleConf(cron).executorHandler(name).executorTimeout(5).executorFailRetryCount(3).build();
        info.setDefault();
        if (route != null) {
            info.setExecutorRouteStrategy(route);
        }
        //判断是否在其他节点已经注册任务
        List<XxlJobInfo> jobList = getJobList(xxlJobGroup.getId());
        boolean isExist = false;
        // 查询是否需要注册JobHandler
        for (XxlJobInfo job : jobList) {
            String executorHandler = job.getExecutorHandler();
            if (Objects.equals(name, executorHandler)) {
                log.info("已有服务注册任务 {},检查执行模式", name);
                if (!Objects.equals(job.getExecutorRouteStrategy(), info.getExecutorRouteStrategy())) {
                    log.info("已有服务注册任务 {},执行模式不符，执行重新创建", name);
                    delJob(job.getId());
                    break;
                }
                log.info("已有服务注册任务 {},不进行再次注册", name);
                isExist = true;
                break;
            }
        }
        if (isExist) {
            return;
        }
        
        info.setDefault();
        log.info("=====注册 {} 定时任务 信息:{}", name, info);
        int jobId = registerJob(info);
        // 启动xxlJob
        startJob(jobId);
        log.info("=====注册 {} 定时任务jobId = {}", name, jobId);
    }
    
    @Override
    public void registerJob(String name, boolean enabled, String cron, String clazz, XxlJobGroup xxlJobGroup, ExecutorRouteStrategyEnum route) {
        // 生成实体对象
        XxlJobInfo info = XxlJobInfo.builder().jobGroup(xxlJobGroup.getId()).jobDesc("douc auto registerJob " + clazz).author(AUTHOR)
                .scheduleConf(cron).executorHandler(name).executorTimeout(5).executorFailRetryCount(3).build();
        info.setDefault();
        if (route != null) {
            info.setExecutorRouteStrategy(route);
        }
        //判断是否在其他节点已经注册任务
        List<XxlJobInfo> jobList = getJobList(xxlJobGroup.getId());
        boolean isExist = false;
        // 查询是否需要注册JobHandler
        for (XxlJobInfo job : jobList) {
            String executorHandler = job.getExecutorHandler();
            if (Objects.equals(name, executorHandler)) {
                log.info("已有服务注册任务 {},检查执行模式", name);
                if (!Objects.equals(job.getExecutorRouteStrategy(), info.getExecutorRouteStrategy())) {
                    log.info("已有服务注册任务 {},执行模式不符，执行重新创建", name);
                    delJob(job.getId());
                    break;
                }
                log.info("已有服务注册任务 {},不进行再次注册", name);
                isExist = true;
                if (enabled) {
                    startJob(job.getId());
                } else {
                    stopJob(job.getId());
                }
                break;
            }
        }
        if (isExist) {
            return;
        }
        info.setDefault();
        log.info("=====注册 {} 定时任务 信息:{}", name, info);
        int jobId = registerJob(info);
        // job的状态维护
        if (enabled) {
            startJob(jobId);
        } else {
            stopJob(jobId);
        }
        log.info("=====注册 {} 定时任务jobId = {}", name, jobId);
    }
    
    @Override
    public void registerJob(String name, String cron, String clazz, XxlJobGroup xxlJobGroup) {
        registerJob(name, cron, clazz, xxlJobGroup, null);
    }
    
    @Override
    public void delJob(int id) {
        log.debug("delete job handler ,id :{}", id);
        String url = xxlJobConfig.getBaseUrl() + "/jobinfo/remove";
        Map<String, Object> params = new HashMap<>();
        params.put("id", String.valueOf(id));
        HttpResponse execute = doRequest("delJobHandler", url, params);
        if (!success(execute)) {
            log.error("delJob fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
    @Override
    public List<XxlJobInfo> getJobList(int jobGroupId) {
        String url = xxlJobConfig.getBaseUrl() + "/jobinfo/pageList";
        Map<String, Object> params = new HashMap<>();
        params.put("start", "0");
        params.put("length", "10000");
        params.put("jobGroup", String.valueOf(jobGroupId));
        params.put("triggerStatus", "-1");
        HttpResponse execute = doRequest("getJobList", url, params);
        if (!success(execute)) {
            log.error("getJobList fail resp :{}", execute);
            throw new RuntimeException("error");
        }
        String body = execute.body();
        Map<String, Object> resp = JsonUtils.toBean(body, new TypeReference<Map<String, Object>>() {
            @Override
            public Type getType() {
                return super.getType();
            }
        });
        if (resp.get("data") != null) {
            try {
                return JsonUtils.toBean(JsonUtils.toJsonStr(resp.get("data")), new TypeReference<List<XxlJobInfo>>() {
                    @Override
                    public Type getType() {
                        return super.getType();
                    }
                });
            } catch (Exception exception) {
                log.error("getJobList fail resp json error:", exception);
                throw new RuntimeException(exception);
            }
        } else {
            log.error("getJobList fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
    @Override
    public void startJob(int id) {
        log.debug("start job ,id :{}", id);
        String url = xxlJobConfig.getBaseUrl() + "/jobinfo/start";
        Map<String, Object> params = new HashMap<>();
        params.put("id", String.valueOf(id));
        HttpResponse execute = doRequest("startJob", url, params);
        if (!success(execute)) {
            log.error("startJob resp :{}", execute);
            throw new RuntimeException("error");
        }
        
    }
    
    @Override
    public void stopJob(int id) {
        log.debug("stop job  ,id :{}", id);
        String url = xxlJobConfig.getBaseUrl() + "/jobinfo/stop";
        Map<String, Object> params = new HashMap<>();
        params.put("id", String.valueOf(id));
        HttpResponse execute = doRequest("stopJob", url, params);
        if (!success(execute)) {
            log.error("stopJob resp :{}", execute);
            throw new RuntimeException("error");
        }
        
    }
    
    @Override
    public void triggerJob(int id, int jobGroupId) {
        try {
            startJob(id);
        } catch (Exception e) {
            execute(id, jobGroupId);
        }
        
    }
    
    @Override
    public void execute(int id, int jobGroupId) {
        List<XxlJobInfo> list = getJobList(jobGroupId);
        XxlJobInfo xxlJobInfo = null;
        for (XxlJobInfo info : list) {
            if (info.getId() == id) {
                xxlJobInfo = info;
                break;
            }
        }
        if (xxlJobInfo == null) {
            throw new RuntimeException("job id : " + id + " not exists in jobGroup id : " + jobGroupId + " !");
        }
        String param = xxlJobInfo.getExecutorParam();
        
        log.debug("execute one time job ,id :{}", id);
        String url = xxlJobConfig.getBaseUrl() + "/jobinfo/trigger";
        Map<String, Object> params = new HashMap<>();
        params.put("id", String.valueOf(id));
        params.put("executorParam", param);
        HttpResponse execute = doRequest("execute", url, params);
        if (!success(execute)) {
            log.error("execute resp :{}", execute);
            throw new RuntimeException("error");
        }
        
    }
    
    @Override
    public XxlJobGroup getXxlJobGroupByName(String appName) {
        // 查询是否需要注册JobHandler
        List<XxlJobGroup> jobGroupList = getHandlerList(appName);
        if (jobGroupList.isEmpty()) {
            // 注册xxlJobHelder
            XxlJobGroup xxlJobGroup = new XxlJobGroup();
            xxlJobGroup.setAppname(appName);
            xxlJobGroup.setTitle(TITLE);
            registerJobHandler(xxlJobGroup);
            jobGroupList = getHandlerList(appName);
        } else {
            updateJonHandler(jobGroupList.get(0));
        }
        return jobGroupList.get(0);
    }
    
    private List<XxlJobGroup> getHandlerList(String appName) {
        log.debug("getHandlerList {}", appName);
        String url = xxlJobConfig.getBaseUrl() + "/jobgroup/pageList";
        Map<String, Object> params = new HashMap<>();
        params.put("start", "0");
        params.put("length", "10000");
        if (StringUtils.isNotEmpty(appName)) {
            params.put("appname", appName);
        }
        HttpResponse execute = doRequest("getHandlerList", url, params);
        if (!success(execute)) {
            log.error("getHandlerList fail resp :{}", execute);
            throw new RuntimeException("error");
        }
        String body = execute.body();
        Map<String, Object> resp = JsonUtils.toBean(body, new TypeReference<Map<String, Object>>() {
            @Override
            public Type getType() {
                return super.getType();
            }
        });
        if (resp.get("data") != null) {
            try {
                return JsonUtils.toBean(JsonUtils.toJsonStr(resp.get("data")), new TypeReference<List<XxlJobGroup>>() {
                    @Override
                    public Type getType() {
                        return super.getType();
                    }
                });
            } catch (Exception exception) {
                log.error("getHandlerList fail resp json error:", exception);
                throw new RuntimeException(exception);
            }
        } else {
            log.error("getHandlerList fail resp :{}", execute);
            throw new RuntimeException("error");
        }
    }
    
}
