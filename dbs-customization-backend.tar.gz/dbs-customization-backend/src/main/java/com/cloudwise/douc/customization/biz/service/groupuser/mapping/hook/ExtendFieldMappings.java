package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;

import cn.hutool.core.util.ReflectUtil;
import com.cloudwise.douc.customization.biz.anno.ExtendProperty;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author dwq
 */
@Component
public class ExtendFieldMappings {
    
    public <S> List<Map<String, Object>> mapping(S source) {
        Class<?> sourceClass = source.getClass();
        Field[] declaredFields = ReflectUtil.getFields(sourceClass);
        List<Map<String, Object>> extendFields = new ArrayList<>();
        for (Field declaredField : declaredFields) {
            ExtendProperty annotation = declaredField.getAnnotation(ExtendProperty.class);
            if (annotation != null) {
                Map<String, Object> extendField = new HashMap<>(4);
                String alias = annotation.alias();
                extendField.put("alias", alias);
                extendField.put("value", ReflectUtil.getFieldValue(source, declaredField));
                extendFields.add(extendField);
            }
        }
        return CollectionUtils.isEmpty(extendFields) ? null : extendFields;
    }
}
