package com.cloudwise.douc.customization.biz.service.work.order;

import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Map;

/**
 * @Author frank.zheng
 * @Date 2025-02-09
 */
public interface DosmWorkOrderService {

    WorkOrderDetail getWorkOrderDetail(String workOrderId, String userId);


    String getFormId(String workOrderId);


    Map<String, FieldInfo> getFormData(String workOrderId, String userId, JsonNode formData);


    Map<String, FieldInfo> getFormData(String workOrderId, String userId);


    Map<String, FieldInfo> getFormData(String formId, JsonNode formData);
}
