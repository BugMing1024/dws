package com.cloudwise.douc.customization.biz.model.signoff;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author abell.wu
 */
@TableName("sign_off_manager")
@Data
public class SignOffEntity {

    @TableId(value = "id",type = IdType.AUTO)
    private Long id;


    private String topAccountId;

    private String accountId;

    private Date createdTime;

    private Date updatedTime;

    private String status;

     /**
     * signOff分组
     */
    private String signOffGroup;

    /**
     * signOff类型 多选
     */
    private String signOffType;


    /**
     * signOff用户组
     */
    private String signOffUserGroup;

    /**
     * signOff用户
     */
    private String signOffUser;

    /**
     * 文件 多选
     */
    private String artifact;

    /**
     * 关联工单
     */
    private String workOrderId;


    private String caseId;

}
