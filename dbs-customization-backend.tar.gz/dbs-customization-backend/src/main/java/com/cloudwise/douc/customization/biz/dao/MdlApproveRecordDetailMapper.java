package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.MdlApproveRecordDetail;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author ming.ma
 * @since 2024-12-26  16:44
 **/
@Mapper
public interface MdlApproveRecordDetailMapper extends BaseMapper<MdlApproveRecordDetail> {

}
