package com.cloudwise.douc.customization.biz.service.msg.sms.analysis.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.form.GroupBean;
import com.cloudwise.dosm.api.bean.form.RowData;
import com.cloudwise.dosm.api.bean.form.UserBean;
import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.api.bean.form.field.GroupField;
import com.cloudwise.dosm.api.bean.form.field.MemberField;
import com.cloudwise.dosm.api.bean.form.field.TableFormField;
import com.cloudwise.douc.customization.biz.constant.SmsTemplateConstants;
import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.enums.ValueTypeEnum;
import com.cloudwise.douc.customization.biz.facade.UserSSOClient;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.service.msg.sms.analysis.SmsAnalysis;
import com.cloudwise.douc.customization.biz.service.msg.utils.FieldBindVariableUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.SmsAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.SmsTemplateUtil;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.biz.util.BpmTemplateUtil;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Author frank.zheng
 * @Date 2025-02-09
 */
@Slf4j
public abstract class AbstractBaseAnalysis implements SmsAnalysis {


    abstract void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap);

    @Override
    public SmsMessageVo getMessage(MessageContext context) {
        NotifyVo notify = context.getNotify();

        // Mail recipients
        List<UserInfo> receivers = this.getReceivers(context);
        if(CollectionUtils.isEmpty(receivers)) {
            log.error("sms receiver is null, workOrderId:{}, notifyReceivers: {}", context.getWorkOrderId(), notify.getReceivers());
            return null;
        }

        Map<String, FieldInfo> formDataMap = null;
        JsonNode formDataJson = context.getFormDataJson();
        if(formDataJson != null && !formDataJson.isEmpty()) {
            formDataMap = getDosmWorkOrderService().getFormData(context.getWorkOrderId(), context.getUserId(), formDataJson);
        } else {
            formDataMap = getDosmWorkOrderService().getFormData(context.getWorkOrderId(), context.getUserId());
        }
        context.setFormData(formDataMap);


        Map<String, Object> bindingMap = this.buildBindingMap(context, receivers);

        SmsMessageVo smsMessage = new SmsMessageVo();
        smsMessage.setNotifyWay(NotifyWayEnum.SMS);
        smsMessage.setCreatedBy(context.getUserId());
        smsMessage.setTopAccountId(context.getTopAccountId());
        smsMessage.setAccountId(context.getAccountId());
        smsMessage.setNotifyScene(notify.getNotifyScene());
        smsMessage.setWorkOrderId(context.getWorkOrderId());
        smsMessage.setNodeId(context.getNodeId());
        smsMessage.setMessageContext(context);
        smsMessage.setCountry(getCountry(context, bindingMap));
        smsMessage.setLob(getLob(context, bindingMap));

        this.buildMsgBody(context, receivers, bindingMap, smsMessage);
        return smsMessage;
    }



    /**
     * get sms receivers
     *     <p>1、type is “NORMAL”，Preferentially get userId and values
     *     <p>2、type is “FORM”，Preferentially get userId
     */
    protected List<UserInfo> getReceivers(MessageContext context) {
        NotifyVo notify = context.getNotify();
        List<UserInfo> userList = getSmsUsers(context, notify.getReceivers());
        if(CollectionUtils.isNotEmpty(userList)) {
            return userList;
        }
        UserInfo userInfo = getRequestor(context);
        return userInfo == null? null: Lists.newArrayList(userInfo);
    }


    protected void buildMsgBody(MessageContext context, List<UserInfo> receivers, Map<String, Object> bindingMap, SmsMessageVo smsMessage) {
        NotifyVo notify = context.getNotify();
        NotifyScenceEnum notifyScene = notify.getNotifyScene();

        receivers.stream().collect(Collectors.toMap(Function.identity(), user -> {
            bindingMap.put(SmsTemplateConstants.ASSIGNED_USER_NAME, user.getUserAlias());
            return getBody(notifyScene, bindingMap);
        }));

    }


    protected String getBody(NotifyScenceEnum notifyScence, Map<String, Object> bindingMap) {
        String template = SmsTemplateUtil.get(notifyScence);
        return BpmTemplateUtil.renderNoSpecial(template, bindingMap);
    }



    protected Map<String, Object> buildBindingMap(MessageContext context, List<UserInfo> receivers) {
        NotifyVo notify = context.getNotify();
        Map<String, FieldInfo> formData = context.getFormData();

        Map<String, Object> bindingMap = Maps.newHashMap();

        // sms field value format config
        Map<String, String> fieldValueFormatMap = getDosmConfig().getSmsConfig().getFieldValueFormatMap();

        String[] bodyFieldKeys = notify.getNotifyScene().getSmsBodyFieldKeys();
        if(bodyFieldKeys != null) {
            Map<String, String> smsBodyFieldMap = getDosmConfig().getSmsConfig().getBodyFieldMap();
            if(MapUtils.isNotEmpty(smsBodyFieldMap)) {
                // sms body field
                List<FieldValue> smsContentFields = Arrays.stream(bodyFieldKeys).map(smsKey -> FieldValue.builder().emailKey(smsKey).name(smsBodyFieldMap.get(smsKey)).build()).filter(item -> StringUtils.isNotBlank(item.getName())).collect(Collectors.toList());
                Map<String, Object> smsContent_bindingMap = FieldBindVariableUtil.getBindVariable(smsContentFields, formData, fieldValueFormatMap);
                bindingMap.putAll(smsContent_bindingMap);
            } else {
                Arrays.stream(bodyFieldKeys).forEach(smsKey -> bindingMap.put(smsKey, ""));
            }
        }

        // form field
        Map<String, Object> smsContent_bindingMap = FieldBindVariableUtil.getBindVariable(notify.getContent() == null? null: notify.getContent().getFields(), formData, fieldValueFormatMap);
        bindingMap.putAll(smsContent_bindingMap);

        // public field
        Map<String, String> publicFields = context.getPublicFields();
        if(CollUtil.isNotEmpty(publicFields)) {
            bindingMap.putAll(publicFields);
        }

        // 绑定扩展信息
        buildExtBindingMap(context, bindingMap);
        return bindingMap;
    }







    /**
     * get SMS receivers
     *     <p>1、type is “NORMAL”，Preferentially get userId and values
     *     <p>2、type is “FORM”，Preferentially get userId
     * @param context
     * @return
     */
    protected List<UserInfo> getSmsUsers(MessageContext context, List<ValueContent> userIdContents) {
        if(CollUtil.isEmpty(userIdContents)) {
            log.info("GetSmsUsers receivers is empty");
            return Lists.newArrayList();
        }

        Set<String> userIdSet = Sets.newHashSet();

        for(ValueContent userIdContent: userIdContents) {
            ValueTypeEnum valueType = userIdContent.getType();
            if(ValueTypeEnum.NORMAL.equals(valueType)) {
                log.info("GetSmsUsers value type is normal");
                NormalValue normalValue = userIdContent.getNormalValue();
                if(null == normalValue) {
                    log.info("GetSmsUsers normal value is empty");
                    continue;
                }

                /** Preferentially get value */
                List<String> values = normalValue.getValues();
                if(CollUtil.isNotEmpty(values)) {
                    userIdSet.addAll(values);
                }

                /** Preferentially get userId */
                List<String> userIds = normalValue.getUserIds();
                if(CollUtil.isNotEmpty(userIds)) {
                    userIdSet.addAll(userIds);
                }

            } else if(ValueTypeEnum.FORM.equals(valueType)) {
                log.info("GetSmsUsers value type is form");
                List<FieldValue> fields = userIdContent.getFields();
                if(CollUtil.isEmpty(fields)) {
                    log.info("GetSmsUsers form type fields is empty");
                    continue;
                }

                Map<String, FieldInfo> formData = context.getFormData();
                for(FieldValue fieldValue: fields) {
                    String fieldCode = fieldValue.getName();
                    /** table data */
                    if(fieldCode.contains(SmsAnalysisUtil.COMMA)) {
                        String[] split = fieldCode.split(SmsAnalysisUtil.COMMA);
                        if(split.length != 2) {
                            log.info("[table data] not a table key name:{}", fieldCode);
                            continue;
                        }
                        String tableCode = split[0];
                        fieldCode = split[1];
                        FieldInfo tableField = formData.get(tableCode);
                        TableFormField tableForm = null;
                        Collection<RowData> rowDatas = null;
                        if(Objects.isNull(tableField) || Objects.isNull(tableForm = (TableFormField) tableField.getFieldValueObj()) || CollUtil.isEmpty(rowDatas = tableForm.getValue())) {
                            log.info("[table data] get tableCode:{} form data is null,", tableCode);
                            continue;
                        }
                        // userGroup or member data in table all row
                        for(RowData rowData: rowDatas) {
                            Map<String, FieldInfo> columnDataMap = rowData.getColumnDataMap();
                            handleGroupOrMemberField(columnDataMap, fieldCode, userIdSet);
                        }
                    } else {
                        handleGroupOrMemberField(formData, fieldCode, userIdSet);
                    }
                }
            }
        }

        if(CollectionUtils.isEmpty(userIdSet)) {
            return null;
        }

        UserConditionReq req = new UserConditionReq();
        req.setIds(Lists.newArrayList(userIdSet.stream().map(Long::valueOf).collect(Collectors.toList())));
        List<com.cloudwise.douc.dto.v3.common.UserInfo> doucUserList = getUserSSOClient().getAllUserByCondition(req);

        return doucUserList.stream().map(doucUser -> UserInfo.builder().userId(doucUser.getId()).userAlias(doucUser.getAlias()).build()).collect(Collectors.toList());
    }



    protected void handleGroupOrMemberField(Map<String, FieldInfo> formData, String fieldCode, Set<String> userIdSet) {
        FieldInfo fieldInfo = formData.get(fieldCode);
        if (fieldInfo == null) {
            return;
        }

        if (FieldValueTypeEnum.GROUP.name().equals(fieldInfo.getFieldType().name())) {
            GroupField groupField = (GroupField) fieldInfo.getFieldValueObj();
            Collection<GroupBean> groups = groupField.getValue();

            if (CollUtil.isNotEmpty(groups)) {
                groups.forEach(group -> userIdSet.add(group.getUserId()));
            }
        } else if (FieldValueTypeEnum.MEMBER.name().equals(fieldInfo.getFieldType().name())) {
            MemberField memberField = (MemberField) fieldInfo.getFieldValueObj();
            Collection<UserBean> userBeans = memberField.getValue();
            userBeans.forEach(user -> userIdSet.add(user.getUserId()));
        } else {
            String userId = FieldBindVariableUtil.switchFieldType(formData, fieldCode, null);
            userIdSet.add(userId);
        }
    }


    protected UserInfo getRequestor(MessageContext context) {
        String createdById = context.getPublicFields().get(SmsTemplateConstants.PublicFields.CREATED_BY_ID);
        if(StringUtils.isBlank(createdById)) {
            log.error("PublicField createdById value is null");
            return null;
        }
        String createdByName = context.getPublicFields().get(SmsTemplateConstants.PublicFields.CREATED_BY_NAME);
        return UserInfo.builder().userId(Long.valueOf(createdById)).userAlias(createdByName).build();
    }


    protected String getCountry(MessageContext context, Map<String, Object> bindingMap) {
        return (String) bindingMap.get(SmsTemplateConstants.BodyField.COUNTRY_OF_ORIGIN);
    }


    protected String getLob(MessageContext context, Map<String, Object> bindingMap) {
        return (String) bindingMap.get(SmsTemplateConstants.BodyField.UNIT);
    }




    private static DosmWorkOrderService DOSM_WORK_ORDER_SERVICE;
    protected DosmWorkOrderService getDosmWorkOrderService() {
        return DOSM_WORK_ORDER_SERVICE != null? DOSM_WORK_ORDER_SERVICE: (DOSM_WORK_ORDER_SERVICE = SpringUtil.getBean(DosmWorkOrderService.class));
    }

    private static DosmConfig DOSM_CONFIG;
    protected DosmConfig getDosmConfig() {
        return DOSM_CONFIG != null? DOSM_CONFIG: (DOSM_CONFIG = SpringUtil.getBean(DosmConfig.class));
    }


    private static UserSSOClient USER_SSO_CLIENT;
    protected UserSSOClient getUserSSOClient() {
        return USER_SSO_CLIENT != null? USER_SSO_CLIENT: (USER_SSO_CLIENT = SpringUtil.getBean(UserSSOClient.class));
    }
}
