package com.cloudwise.douc.customization;

import com.cloudwise.cache.lettuce.annotations.EnableLettuceRedis;
import com.cloudwise.cache.redisson.annotations.EnableRedisson;
import com.cloudwise.msg.annotations.Msg;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.LocalDateTime;

/**
 * @author skiya
 */
@EnableRedisson
@EnableLettuceRedis
@EnableAsync
@EnableScheduling
@SpringBootApplication
@Slf4j
@ComponentScan(basePackages = {"com.cloudwise.cache", "com.cloudwise.douc.customization", "com.cloudwise.msg"})
@Msg
public class DataConnectivityService {
    
    public static void main(String[] args) {
        SpringApplication.run(DataConnectivityService.class, args);
        log.info("  _   _   _   _   _   _   _   _");
        log.info(" / \\ / \\ / \\ / \\ / \\ / \\ / \\ / \\");
        log.info("( c | o | m | p | l | e | t | e )");
        log.info(" \\_/ \\_/ \\_/ \\_/ \\_/ \\_/ \\_/ \\_/");
        log.info("启动完毕,时间:{}", LocalDateTime.now());
    }
    
}
