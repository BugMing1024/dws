package com.cloudwise.douc.customization.biz.service.groupuser.reader;

import com.cloudwise.douc.customization.biz.constant.BusinessType;
import com.cloudwise.douc.customization.biz.facade.DbsFacade;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsRespCommonGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.ImplementerGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.MdApproveGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.UserTSO;
import com.cloudwise.douc.customization.common.model.GroupAndUserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 聚合的读取器
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-22 01:14; update at 2024-12-22 01:14
 */
@Component
public class DbsMultiReader {
    
    @Autowired
    private DbsFacade dbsFacade;
    
    public GroupAndUserInfo read(List<BusinessType> businessType) {
        List<DbsRespCommonGroup> approveGroups = new ArrayList<>();
        List<ImplementerGroup> implementerGroups = new ArrayList<>();
        List<MdApproveGroup> mdApproveGroups = new ArrayList<>();
        List<DbsRespCommonGroup> releaseGroups = new ArrayList<>();
        List<DbsRespCommonGroup> changeGroups = new ArrayList<>();
        List<UserTSO> userTSOs = new ArrayList<>();
        if (businessType.contains(BusinessType.APPROVE_GROUP) && businessType.contains(BusinessType.USER)) {
            dbsFacade.buildApprove(approveGroups);
        }
        if (businessType.contains(BusinessType.IMPLEMENTER_GROUP) && businessType.contains(BusinessType.USER)) {
            dbsFacade.buildImplementer(implementerGroups);
        }
        if (businessType.contains(BusinessType.MDAPPROVE_GROUP) && businessType.contains(BusinessType.USER)) {
            dbsFacade.buildMdApprover(mdApproveGroups);
        }
        if (businessType.contains(BusinessType.RELEASE_GROUP) && businessType.contains(BusinessType.USER)) {
            dbsFacade.buildRelease(releaseGroups);
        }
        if (businessType.contains(BusinessType.CHANGE_GROUP) && businessType.contains(BusinessType.USER)) {
            dbsFacade.buildChange(changeGroups);
        }
        if (businessType.contains(BusinessType.TSOID)) {
            dbsFacade.buildTSOId(userTSOs);
        }
        GroupAndUserInfo result = new GroupAndUserInfo();
        result.setApproveGroups(approveGroups);
        result.setImplementerGroups(implementerGroups);
        result.setMdApproveGroups(mdApproveGroups);
        result.setReleaseGroups(releaseGroups);
        result.setChangeGroups(changeGroups);
        result.setUsers(userTSOs);
        return result;
    }
    
    
}
