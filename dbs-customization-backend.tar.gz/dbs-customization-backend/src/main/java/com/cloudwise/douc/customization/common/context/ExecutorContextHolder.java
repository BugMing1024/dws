package com.cloudwise.douc.customization.common.context;

import org.springframework.core.NamedInheritableThreadLocal;
import org.springframework.lang.Nullable;

/**
 * @author skiya
 * @date Created on 2021-12-3.
 */
public class ExecutorContextHolder {
    
    private static final ThreadLocal<ExecutorContext> EXECUTOR_CONTEXT_HOLDER = new NamedInheritableThreadLocal<>("ExecutorContext");
    
    public static void set(@Nullable ExecutorContext context) {
        if (context == null) {
            reset();
        }
        EXECUTOR_CONTEXT_HOLDER.set(context);
    }
    
    public static void reset() {
        EXECUTOR_CONTEXT_HOLDER.remove();
    }
    
    public static ExecutorContext get() {
        return EXECUTOR_CONTEXT_HOLDER.get();
    }
}
