package com.cloudwise.douc.customization.common.exception;

import java.util.List;

/**
 * Created on 2022-10-18.
 *
 * @author skiya
 */
public class DoucUserNotFoundException extends RuntimeException {
    
    private final List<String> userCodes;
    
    public DoucUserNotFoundException(List<String> userCodes) {
        this.userCodes = userCodes;
    }
    
    public List<String> getUserCodes() {
        return this.userCodes;
    }
    
    @Override
    public String getMessage() {
        return "user is not existed: " + this.userCodes;
    }
}
