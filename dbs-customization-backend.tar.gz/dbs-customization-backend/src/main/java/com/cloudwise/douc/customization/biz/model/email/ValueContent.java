package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.enums.ValueTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-05  15:04
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValueContent implements Serializable {
    
    private static final long serialVersionUID = -5127403977457835895L;
    
    
    /**
     * 类型
     */
    private ValueTypeEnum type;
    
    
    /**
     * 字段列表
     */
    private List<FieldValue> fields;
    
    /**
     * 固定值
     */
    private NormalValue normalValue;

}
