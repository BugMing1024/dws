package com.cloudwise.douc.customization.biz.model.email;

import lombok.Data;

import java.io.Serializable;

/**
 * 文件上传类
 */
@Data
public class UploadFileInfoDto implements Serializable {
    
    private static final long serialVersionUID = -8384480856717638599L;
    
    private String id;
    
    private String uid;
    
    private String url;
    
    private String type;
    
    private String fileName;
}
