package com.cloudwise.douc.customization.biz.service.groupuser.processor;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.Mapper;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.DbsGroupMappingHook;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.ExtendMapMappings;
import com.cloudwise.douc.dto.DubboSyncResultInfo;
import com.cloudwise.douc.dto.v3.common.CommonResp;
import com.cloudwise.douc.dto.v3.common.GroupInfo;
import com.cloudwise.douc.dto.v3.common.PageResp;
import com.cloudwise.douc.dto.v3.common.UserInfo;
import com.cloudwise.douc.dto.v3.group.AddOrUpdateGroupReq;
import com.cloudwise.douc.dto.v3.group.DeleteGroupReq;
import com.cloudwise.douc.dto.v3.group.GroupConditionReq;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.cloudwise.douc.facadev3.GroupFacade;
import com.cloudwise.douc.facadev3.UserFacade;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class DoucGroupSyncProcessor extends AbstractSyncProcessor<DbsGroupInfo, AddOrUpdateGroupReq> implements SyncProcessor {
    
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private GroupFacade groupFacade;

    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserFacade userFacade;
    
    @Autowired
    private ExtendMapMappings extendMapMappings;
    
    private Mapper<DbsGroupInfo, AddOrUpdateGroupReq> GROUP_MAPPER;
    
    @PostConstruct
    public void initData() {
        GROUP_MAPPER = new Mapper<>(DbsGroupInfo.class, AddOrUpdateGroupReq.class, Collections.singleton(new DbsGroupMappingHook(extendMapMappings)));
    }
    
    @Override
    public int getOrder() {
        return 2;
    }
    
    @Override
    public void start() {
        this.write(this.read(businessType));
    }
    
    public void checkAndDelete(List<String> parentCode, List<DbsGroupInfo> groups) {
        GroupConditionReq groupConditionReq = new GroupConditionReq();
        groupConditionReq.setAccountId(110L);
        groupConditionReq.setUserId(1L);
        groupConditionReq.setCodes(parentCode);
        groupConditionReq.setSize(99999L);
        CommonResp<PageResp<GroupInfo>> groupByCondition = groupFacade.getGroupByCondition(groupConditionReq);
        if (groupByCondition.getData() == null || CollUtil.isEmpty(groupByCondition.getData().getRecords())) {
            return;
        }
        List<Long> ids = groupByCondition.getData().getRecords().stream().map(GroupInfo::getId).collect(Collectors.toList());
        groupConditionReq = new GroupConditionReq();
        groupConditionReq.setAccountId(110L);
        groupConditionReq.setUserId(1L);
        groupConditionReq.setParentIds(ids);
        groupConditionReq.setSize(99999L);
        groupByCondition = groupFacade.getGroupByCondition(groupConditionReq);
        if (groupByCondition.getData() == null || CollUtil.isEmpty(groupByCondition.getData().getRecords())) {
            return;
        }
        List<Long> secondIds = groupByCondition.getData().getRecords().stream().map(GroupInfo::getId).collect(Collectors.toList());
        GroupConditionReq groupConditionReq2 = new GroupConditionReq();
        groupConditionReq2.setAccountId(110L);
        groupConditionReq2.setUserId(1L);
        groupConditionReq2.setParentIds(secondIds);
        groupConditionReq2.setSize(99999L);
        CommonResp<PageResp<GroupInfo>> groupByCondition2 = groupFacade.getGroupByCondition(groupConditionReq2);
        if (groupByCondition.getData() != null && CollUtil.isNotEmpty(groupByCondition.getData().getRecords())) {
            groupByCondition.getData().getRecords().addAll(groupByCondition2.getData().getRecords());
        }
        List<AddOrUpdateGroupReq> addOrUpdateGroupReqs = GROUP_MAPPER.convert(groups);
        List<String> allGroupCodes = addOrUpdateGroupReqs.stream().map(AddOrUpdateGroupReq::getCode).collect(Collectors.toList());
        
        List<String> checkGroups = groupByCondition.getData().getRecords().stream().map(GroupInfo::getCode).collect(Collectors.toList());
        List<Long> deleteGroupIds = groupByCondition.getData().getRecords().stream().filter(groupInfo -> StrUtil.isBlank(groupInfo.getCode()))
                .map(GroupInfo::getId).collect(Collectors.toList());
        List<String> deleteGroupCodes = CollUtil.subtractToList(checkGroups, allGroupCodes);
        if (CollUtil.isNotEmpty(deleteGroupIds)) {
            Lists.partition(deleteGroupIds, 100).forEach(e -> {
                DeleteGroupReq deleteGroupReq = new DeleteGroupReq();
                deleteGroupReq.setAccountId(110L);
                deleteGroupReq.setIds(e);
                groupFacade.deleteUserGroup(deleteGroupReq);
            });
        }
        if (CollUtil.isNotEmpty(deleteGroupCodes)) {
            Lists.partition(deleteGroupCodes, 100).forEach(e -> {
                DeleteGroupReq deleteGroupReq = new DeleteGroupReq();
                deleteGroupReq.setAccountId(110L);
                deleteGroupReq.setCodes(e);
                groupFacade.deleteUserGroup(deleteGroupReq);
            });
        }
        List<String> addOrUpdateCodes = checkGroups.stream().filter(s -> !deleteGroupCodes.contains(s)).collect(Collectors.toList());
        if (CollUtil.isNotEmpty(addOrUpdateCodes)) {
            fillRemoveUser(addOrUpdateCodes, addOrUpdateGroupReqs);
        }
        
    }
    
    private void fillRemoveUser(List<String> dbsChildCodes, List<AddOrUpdateGroupReq> addOrUpdateGroupReqs) {
        UserConditionReq userConditionReq = new UserConditionReq();
        userConditionReq.setGroupCodes(dbsChildCodes);
        userConditionReq.setAccountId(110L);
        userConditionReq.setRespMode(5);
        userConditionReq.setSize(1000L);
        CommonResp<PageResp<UserInfo>> userByCondition = userFacade.getUserByCondition(userConditionReq);
        if (userByCondition.isSuccess()) {
            List<UserInfo> userInfos = userByCondition.getData().getRecords();
            Map<String, List<String>> groupCodeAndUserCodeMap = Maps.newHashMap();
            Map<String, List<Long>> groupCodeAndUserIdMap = Maps.newHashMap();
            userInfos.forEach(userInfo -> {
                userInfo.getGroupRelation().stream().filter(groupInfo -> StrUtil.isNotBlank(groupInfo.getCode())).forEach(groupRelation -> {
                    if (StrUtil.isBlank(userInfo.getCode())) {
                        List<Long> userIds = CollUtil.defaultIfEmpty(groupCodeAndUserIdMap.get(groupRelation.getCode()), new ArrayList<>());
                        userIds.add(userInfo.getId());
                        groupCodeAndUserIdMap.put(groupRelation.getCode(), userIds);
                    } else {
                        List<String> userCodes = CollUtil.defaultIfEmpty(groupCodeAndUserCodeMap.get(groupRelation.getCode()), new ArrayList<>());
                        userCodes.add(userInfo.getCode());
                        groupCodeAndUserCodeMap.put(groupRelation.getCode(), userCodes);
                    }
                });
            });
            addOrUpdateGroupReqs.forEach(addOrUpdateGroupReq -> {
                List<String> doucUserCodes = groupCodeAndUserCodeMap.get(addOrUpdateGroupReq.getCode());
                List<Long> doucUserIds = groupCodeAndUserIdMap.get(addOrUpdateGroupReq.getCode());
                if (CollUtil.isNotEmpty(doucUserCodes)) {
                    addOrUpdateGroupReq.setRemoveUserCodes(CollUtil.subtractToList(doucUserCodes, addOrUpdateGroupReq.getAddUserCodes()));
                }
                if (CollUtil.isNotEmpty(doucUserIds)) {
                    addOrUpdateGroupReq.setRemoveUserIds(doucUserIds);
                }
            });
            CommonResp<List<DubboSyncResultInfo>> listCommonResp = groupFacade.addOrUpdateUserGroup(addOrUpdateGroupReqs);
            if (!listCommonResp.isSuccess()) {
                log.error("remove rela user error：{}", listCommonResp);
            }
        }
    }
}
