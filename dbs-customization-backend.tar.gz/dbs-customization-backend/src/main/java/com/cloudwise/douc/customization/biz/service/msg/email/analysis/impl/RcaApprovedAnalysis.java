package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * @Author hekongtao
 * @Date 2025/2/5
 */
@Slf4j
public class RcaApprovedAnalysis extends AbstractBaseAnalysis {

    public final static RcaApprovedAnalysis INSTANCE = new RcaApprovedAnalysis();


    private static final String TITLE_TEMPLATE = "RCA Approved for CR Number: ${bizKey}";


    @Override
    public String getTitleTemplate() {
        return TITLE_TEMPLATE;
    }

    @Override
    public void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap) {

    }

    /**
     * requestor
     */
    @Override
    protected List<UserInfo> getReceivers(MessageContext context) {
        UserInfo requestor = getRequestor(context);
        return requestor == null? null: Lists.newArrayList(requestor);
    }


    /**
     * dbschg@dbs.com
     * <p>+ Members of PSG_DBSGOV_MTOIS
     * <p>+ App Manager Primary(Selected App code in Impacted application of RCA)
     * <p>+ App Manager Secondary(Selected App code in Impacted application of RCA)
     * <p>+ PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB)
     */
    @Override
    protected List<UserInfo> getSendCopys(MessageContext context) {
        List<UserInfo> resultList = Lists.newArrayList();

        resultList.add(UserInfo.builder().email(getDosmConfig().getEmailConfig().getDbsChgEmail()).build());

        /** 2、Members of PSG_DBSGOV_MTOIS */
        List<UserInfo> userByDBSGOV = getUserByGroupCode(context, getDosmConfig().getEmailConfig().getRcaApprovalCCGroupName());
        if(CollectionUtils.isNotEmpty(userByDBSGOV)) {
            resultList.addAll(userByDBSGOV);
        }

        /** 3、App Manager Primary(Selected App code in Impacted application of RCA) + App Manager Secondary(Selected App code in Impacted application of RCA) */
        List<UserInfo> appManagers = getAppManager4AppImpacted(context, (appManager4Impacted, userNameSet) -> {
            // Primary App Manager of Application Impacted
            userNameSet.add(EmailAnalysisUtil.getUserNameByEmail(appManager4Impacted.getSme1Email()));
            // Secondary App Manager of Application Impacted
            userNameSet.add(EmailAnalysisUtil.getUserNameByEmail(appManager4Impacted.getSme2Email()));
        });
        if(CollectionUtils.isNotEmpty(appManagers)) {
            resultList.addAll(appManagers);
        }

        /** 4、PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB) */
        List<UserInfo> userByGroupCode = getUserByGroupCode(context, getDosmConfig().getEmailConfig().getRcaApprovalCCGroupName());
        if(CollectionUtils.isNotEmpty(userByGroupCode)) {
            resultList.addAll(userByGroupCode);
        }

        return resultList;
    }

}
