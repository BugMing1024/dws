package com.cloudwise.douc.customization.biz.service.msg.sms.analysis;

import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.SmsMessageVo;

/**
 * @author ming.ma
 * @since 2024-12-06  16:26
 **/
public interface SmsAnalysis {

    SmsMessageVo getMessage(MessageContext context);
}
