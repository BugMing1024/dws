package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-09  10:23
 **/
@Data
public class EmailMessageVo extends MessageVo {

    private List<UserInfo> sendCopys;

    private List<UploadFileInfoDto> uploadFiles;

    private Map<UserInfo, String> bodyList;


}
