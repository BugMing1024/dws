package com.cloudwise.douc.customization.biz.controller;

import com.cloudwise.douc.customization.biz.model.heighten.WorkTimeLongPiece;
import com.cloudwise.douc.customization.biz.service.heighten.HeightenSyncService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Magina
 * @date 2024/12/5 4:35 下午
 * @description
 **/

@Slf4j
@RestController
@RequestMapping("/api/heighten")
@Api(value = "定制接口")
public class HeightenController {
    
    @Autowired
    private HeightenSyncService heightenSyncService;
    
    
    private AtomicBoolean SYNC_HEIGHTEN_STATUS_IS_RUNING = new AtomicBoolean(false);
    
    
    //校验Heighten规则
    @PostMapping("/heightenStatus")
    public Map<String, Object> heightenStatus(@RequestBody String data) {
        return heightenSyncService.heightenStatus(data);
    }
    
    @PostMapping("/bannerHeightenStatus")
    public Map<String, Object> bannerHeightenStatus(@RequestBody String data) {
        return heightenSyncService.bannerHeightenStatus(data);
    }
    
    //固定Heighten period定义的时间范围
    @PostMapping("/heightenPeriod")
    public Object heightenPeriodTime(@RequestBody String data) {
        List<WorkTimeLongPiece> workTimeLongPieces = heightenSyncService.heightenPeriodTime(data);
        return workTimeLongPieces;
    }
    
}
