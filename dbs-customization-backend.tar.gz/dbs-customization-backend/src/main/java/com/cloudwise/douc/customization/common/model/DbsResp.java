package com.cloudwise.douc.customization.common.model;

import lombok.Data;

/**
 * 响应信息
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-12 18:32; update at 2024-12-12 18:32
 */
@Data

public class DbsResp<T> {
    
    private String code;
    
    private T data;
    
    private String message;
    
    public DbsResp() {
    }
    
    public DbsResp(String code, String message) {
        this.code = code;
        this.message = message;
    }
    
    public DbsResp(String code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }
    
    public static <T> DbsResp<T> ok() {
        return new DbsResp<>("200", "success");
    }
    
    public static <T> DbsResp<T> ok(T data) {
        return new DbsResp<>("200", "success", data);
    }
    
    public static <T> DbsResp<T> fail(String code, String message) {
        return new DbsResp<>(code, message);
    }
    
    public static <T> DbsResp<T> fail(Exception e) {
        return new DbsResp<>("500", e.getMessage());
    }
    
    
}
