package com.cloudwise.douc.customization.biz.util;

import com.cloudwise.douc.customization.biz.factory.BeetlTemplateFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.beetl.core.Template;

import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-10  11:24
 **/
@Slf4j
public class BpmTemplateUtil {

    public static String renderNoSpecial(String key, Map templateBindMap) {
        if (StringUtils.isEmpty(key)) {
            return StringUtils.EMPTY;
        }
        Template template = BeetlTemplateFactory.getInstance().getGroupTemplate().getTemplate(key);
        template.binding(templateBindMap);
        return template.render();
    }
    
}
