package com.cloudwise.douc.customization.common.context;

import lombok.Data;

/**
 * Created on 2022-4-25.
 *
 * @author skiya
 */
@Data
public class ExecutorContext {
    
    private ResultContext resultContext;
    
    private ProcessorCountContext processorCountContext;
}
