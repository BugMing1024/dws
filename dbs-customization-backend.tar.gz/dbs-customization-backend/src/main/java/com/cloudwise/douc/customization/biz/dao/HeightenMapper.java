package com.cloudwise.douc.customization.biz.dao;

import com.cloudwise.douc.customization.biz.model.heighten.HeightenAppCountry;
import com.cloudwise.douc.customization.biz.model.heighten.HeightenPeriod;
import com.cloudwise.douc.customization.biz.model.heighten.PublicHolidayCount;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * @author Magina
 * @date 2024/12/4 3:34 下午
 * @description
 **/
@Mapper
public interface HeightenMapper {
    

    Integer insertHeightenAppCountry(@Param("heightenAppCountryList") List<HeightenAppCountry> heightenAppCountryList);
    

    Integer insertHeightenPeriodList(@Param("heightenPeriodList") List<HeightenPeriod> heightenPeriodList);
    
    

    Integer delHeightenAppCountryById(@Param("ids") List<String> ids);
    
    @Select("select id from heighten_app_country")
    Set<String> selHeightenAppCountryIds();
    
    @Delete("delete from freezed_holidays where 1=1")
    Integer delPublicHolidays();
    
    //根据app 查寻数据

    List<HeightenAppCountry> getDataByappCode(@Param("appCode") List<String> appCode, @Param("freezeDates") List<String> freezeDates);
    
    //根据country_of_origin查寻数据

    List<HeightenAppCountry> getDataBycountryOfOrigin(@Param("countryOfOrigin") String countryOfOrigin, @Param("freezeDates") List<String> freezeDates);
    
    //根据country_impact查寻数据

    List<HeightenAppCountry> getDataByaCountryImpact(@Param("countryImpact") List<String> countryImpact, @Param("freezeDates") List<String> freezeDates);
    
    

    List<HeightenPeriod> getHeightenPeriodsByFreezeDate(@Param("freezeDates") List<String> freezeDates);
    
    
    @Select("select freeze_date from freezed_holidays where freeze_date > #{freezeDate}")
    List<Date> getAllHeightenPeriods(@Param("freezeDate") Date freezeDate);
    
    @Select("select * from heighten_app_country")
    List<HeightenAppCountry> getAllHeightenAppCountry();


    @Select("SELECT count(*) as total,ADDDATE(CURDATE(), INTERVAL #{count} DAY) as dateStr,DAYNAME(ADDDATE(CURDATE(), INTERVAL #{count} DAY)) as dayName  from freezed_holidays where  freeze_date = (CURDATE()+ INTERVAL #{count} DAY) and upper(freeze_type) = upper('Public Holiday')")
    PublicHolidayCount isPublicHoliday(@Param("count") int count);

    int getHeightenCount(@Param("startDate") Date startDate, @Param("endDate") Date endDate);
}
