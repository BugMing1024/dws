package com.cloudwise.douc.customization.biz.enums;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * @author ming.ma
 * @since 2024-12-05  15:15
 **/
public enum EmailApproveEnum {
    
    /**
     * 审批通过
     */
    APPROVED("Approved"),
    
    /**
     * 审批拒绝
     */
    REJECTED("Rejected"),
    ;
    
    private final String name;
    
    EmailApproveEnum(String name) {
        this.name = name;
    }
    
    public static Optional<EmailApproveEnum> ofNullable(String name) {
        return Stream.of(values()).filter(bean -> bean.getName().equals(name)).findAny();
    }
    
    public String getName() {
        return name;
    }
    
}
