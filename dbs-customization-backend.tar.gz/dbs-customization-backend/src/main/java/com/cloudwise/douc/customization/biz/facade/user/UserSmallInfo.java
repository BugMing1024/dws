package com.cloudwise.douc.customization.biz.facade.user;

import lombok.Data;

@Data
public class UserSmallInfo {
    
    /**
     * 用户id
     */
    private Long userId;
    
    /**
     * 名称
     */
    private String name;
    
    /**
     * 电话
     */
    private String mobile;
    
    /**
     * 邮箱
     */
    private String email;
    
    /**
     * 状态
     */
    private Integer status;
    
    /**
     * 别名
     */
    private String userAlias;
    
    /**
     * 部门id
     */
    private Long departmentId;
    
    /**
     * 部门名称
     */
    private String department;
    
}
