package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @Author hekongtao
 * @Date 2025/2/5
 */
@Slf4j
public class CrOpenAveD4dAnalysis extends CrOpenAveAnalysis {

    public final static CrOpenAveD4dAnalysis INSTANCE = new CrOpenAveD4dAnalysis();

    /**
     * XXX <XXX@dbs.com> (requester)
     */
    @Override
    protected List<UserInfo> getSendCopys(MessageContext context) {
        UserInfo userInfo = getRequestor(context);
        return userInfo == null? null: Lists.newArrayList(userInfo);
    }
}
