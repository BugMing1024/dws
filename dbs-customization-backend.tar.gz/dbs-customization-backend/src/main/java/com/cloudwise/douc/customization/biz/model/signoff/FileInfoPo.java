package com.cloudwise.douc.customization.biz.model.signoff;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author dylan.qin
 * @Since: 2021-06-30 21:05
 */
@Data
@NoArgsConstructor
@AllArgsConstructor

public class FileInfoPo {
    /**
     * 主键ID
     */
    private String id;
    /**
     * 文件名称
     */
    private String fileName;

    /**
     * 文件扩展名
     */
    private String fileExt;

    /**
     * 文件大小
     */
    private Long fileSize;

    /**
     * 文件路径
     */
    private String filePath;


    /**
     * 业务数据ID（工单ID/流程ID）
     */
    private String businessId;

    /**
     * 业务扩展信息（JSON格式）
     */
    private String businessExt;


    public FileInfoPo(String id, String fileName) {
        this.id = id;
        this.fileName = fileName;
    }
}
