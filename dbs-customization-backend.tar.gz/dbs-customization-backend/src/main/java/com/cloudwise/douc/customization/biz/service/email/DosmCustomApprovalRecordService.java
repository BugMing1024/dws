package com.cloudwise.douc.customization.biz.service.email;

import com.cloudwise.douc.customization.biz.model.email.ApproveRecord;
import com.cloudwise.douc.customization.biz.model.email.ApproveRecordConfigVo;
import com.cloudwise.douc.customization.biz.model.email.ApproveRecordVo;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-26  16:55
 **/
public interface DosmCustomApprovalRecordService {
    
    List<ApproveRecordVo> getApprovalRecords(String processInstanceId);
    
    List<ApproveRecordConfigVo> getCustomApprovalRecords(String workOrderId);

    public List<ApproveRecord> getRecords(List<ApproveRecordConfigVo> approveRecordConfigs);


    }
