package com.cloudwise.douc.customization.common.exception;


import com.cloudwise.douc.customization.common.constant.ErrorCodeEnum;

/**
 * @author skiya
 * @date Created in 2021/7/26.
 */
public class BizException extends RuntimeException {
    
    /**
     * 异常错误编码
     */
    private final int code;
    
    /**
     * 异常信息
     */
    private final String message;
    
    public BizException(ErrorCodeEnum errorEnum) {
        this.code = errorEnum.code;
        this.message = errorEnum.message;
    }
    
    public BizException(ErrorCodeEnum errorEnum, String errorMessage) {
        this.code = errorEnum.code;
        this.message = errorMessage;
    }
    
    public int getCode() {
        return this.code;
    }
    
    @Override
    public String getMessage() {
        return this.message;
    }
}
