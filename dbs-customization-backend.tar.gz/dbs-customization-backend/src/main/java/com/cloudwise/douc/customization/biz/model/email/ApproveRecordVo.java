package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.dosm.ApproveBehaviorTypeEnum;
import lombok.Data;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-26  17:02
 **/
@Data
public class ApproveRecordVo {
    
    private String approveStatus;
    
    
    private String nodeId;
    
    private String nodeName;
    
    private String approveResult;
    
    private List<ApproveResult> approveResults;
    
    
    @Data
    public static class ApproveResult {
        
        private String taskId;
        
        /**
         * 审批理由，数据字典id
         */
        private String reason;
        
        private String reasonLable;
        
        /**
         * 审批用户
         */
        private String userId;
        
        /**
         * 审批用户信息
         */
        private UserInfo approveUser;
        
        /**
         * 审批意见
         */
        private String approveMsg;
        
        private ApproveBehaviorTypeEnum approveType;
        
        
    }
}
