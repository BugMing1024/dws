package com.cloudwise.douc.customization.biz.facade.impl;

import com.cloudwise.douc.customization.biz.facade.RoleService;
import com.cloudwise.douc.customization.biz.facade.user.RoleInfo;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboIdsReq;
import com.cloudwise.douc.facade.RoleV2DubboFacade;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  18:54
 **/
@Slf4j
@Service
public class RoleServiceImpl implements RoleService {
    
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private RoleV2DubboFacade roleV2DubboFacade;
    
    @Autowired
    private Gson gson;
    
    @Override
    public DubboCommonResp<List<RoleInfo>> getRoleListByIds(DubboIdsReq req) {
        DubboCommonResp<List<RoleInfo>> result;
        log.info("Request roleV2DubboFacade.getRoleListByIds start,params:{}", req);
        try {
            DubboCommonResp<String> rolesStr = roleV2DubboFacade.getRoleListByIds(req);
            if (!rolesStr.isSuccess()) {
                log.error("Request roleV2DubboFacade.getRoleListByIds failed,msg:{}", rolesStr.getMsg());
                result = new DubboCommonResp<List<RoleInfo>>().generateFailResp();
                result.setMsg(rolesStr.getMsg());
                return result;
            }
            log.info("Request roleV2DubboFacade.getRoleListByIds success");
            result = new DubboCommonResp<List<RoleInfo>>().generateSuccessResp(gson.fromJson(rolesStr.getData(), new TypeToken<List<RoleInfo>>() {
            }.getType()));
        } catch (Exception e) {
            result = new DubboCommonResp<List<RoleInfo>>().generateFailResp();
            log.error("Request roleV2DubboFacade.getRoleListByIds failed,cause by ", e);
        }
        return result;
    }
}
