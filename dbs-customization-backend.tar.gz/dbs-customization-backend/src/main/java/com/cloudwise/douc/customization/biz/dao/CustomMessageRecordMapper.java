package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author ming.ma
 * @since 2024-12-10  10:04
 **/
@Mapper
public interface CustomMessageRecordMapper extends BaseMapper<CustomMessageRecord> {

}
