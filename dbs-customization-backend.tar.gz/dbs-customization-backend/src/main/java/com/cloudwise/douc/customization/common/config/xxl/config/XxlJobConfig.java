package com.cloudwise.douc.customization.common.config.xxl.config;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * xxlJob 配置类
 *
 * @Author dylan.qin
 * @Since: 2021-07-06 15:34
 */
@Configuration
@Data
public class XxlJobConfig {
    
    @Value("${xxl.job.admin.addresses:}")
    private String baseUrl;
    
    @Value("${xxl.job.user.name:}")
    private String userName;
    
    @Value("${xxl.job.user.password:12}")
    private String password;
    
    @Value("${xxl.job.executor.appname:douc-api-service:}")
    private String appName;
    
    @Value("${xxl.job.accessToken:}")
    private String accessToken;
    
    @Value("${xxl.job.executor.address:}")
    private String address;
    
    @Value("${xxl.job.executor.ip:}")
    private String ip;
    
    @Value("${xxl.job.executor.port:80}")
    private int port;
    
    @Value("${xxl.job.executor.logpath:}")
    private String logPath;
    
    @Value("${xxl.job.executor.logretentiondays:3}")
    private int logRetentionDays;
    
}