package com.cloudwise.douc.customization.biz.service.groupuser.processor;

import cn.hutool.core.collection.ListUtil;
import com.cloudwise.douc.customization.biz.constant.BusinessType;
import com.cloudwise.douc.customization.biz.constant.ExecutorType;

import java.util.List;

/**
 * Created on 2022-4-21.
 *
 * @author skiya
 */
public interface SyncProcessor {
    
    int HIGHEST_PRECEDENCE = Integer.MIN_VALUE;
    int LOWEST_PRECEDENCE = Integer.MAX_VALUE;
    
    void setBusinessType(List<BusinessType> businessType);
    
    /**
     * 初始化
     */
    default void init() {
    }
    
    /**
     * 同步处理开始
     */
    void start();
    
    
    /**
     * 处理完成后
     */
    default void afterDone() {
    }
    
    /**
     * 处理器排序值，数值小的处理器优先执行
     *
     * @return int
     */
    default int getOrder() {
        return 0;
    }
    
    
    /**
     * processor 在哪些 executor 中运行，默认在 startup、scheduled 两个 executor 中运行
     *
     * @return {@link List}<{@link ExecutorType}> 激活的执行器列表
     */
    default List<ExecutorType> runIn() {
        return ListUtil.of(ExecutorType.STARTUP, ExecutorType.SCHEDULED, ExecutorType.REST);
    }
    
}
