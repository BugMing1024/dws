package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.service.crdailybulkreminder.CrDailyBulkReminderService;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Daily Bulk Reminder Task
 */
@Slf4j
@Component
@SyncEndpoint(name = "crDailyBulkReminder", cron = "0 0 10,14 * * ?")
@Conditional(value = SyncCheckCondition.class)
@RestController()
@RequestMapping("/crDailyBulkReminder")
public class CrDailyBulkReminderJob {
    @Autowired
    private CrDailyBulkReminderService crDailyBulkReminderService;

    private static boolean isRunning = false;

    /**
     * Executes the daily bulk reminder task.
     * <p>
     * This method is called when the scheduled task is triggered.
     */
    @XxlJob("crDailyBulkReminder")
    @GetMapping("/triggerReminder")
    public void crDailyBulkReminder() {
        log.debug("------ crDailyBulkReminder job start ------");
        if (isRunning) {
            return;
        } else {
            isRunning = true;
        }
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            try {
                log.info("crDailyBulkReminder task started execution");
                crDailyBulkReminderService.doRebuildBulkReminderDatas();
                crDailyBulkReminderService.doSendBulkReminderEmails();
                log.info("crDailyBulkReminder scheduled task execution completed");
            } catch (Throwable exception) {
                log.error("error run crDailyBulkReminder task", exception);
            } finally {
                isRunning = false;
            }
        });
        log.debug("------ crDailyBulkReminder job end ------");
    }
}
