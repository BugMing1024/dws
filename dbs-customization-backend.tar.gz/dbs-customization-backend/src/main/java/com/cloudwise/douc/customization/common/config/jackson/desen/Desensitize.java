package com.cloudwise.douc.customization.common.config.jackson.desen;

import com.cloudwise.douc.customization.common.config.jackson.desen.impl.NoneDesensitization;
import com.fasterxml.jackson.annotation.JacksonAnnotationsInside;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created on 2023-2-24. 使用方式：在类成员字段 上标注此注解即可，并指定脱敏策略，如：@Desensitize(DesensitizeStrategy.MOBILE)
 * 也可以使用自定义脱敏策略，如@Desensitize(usingDesensitization=自定义脱敏策略类)
 *
 * @author skiya
 */
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@JacksonAnnotationsInside
@JsonSerialize(using = DesensitizeSerializer.class)
@Documented
public @interface Desensitize {
    
    DesensitizeStrategy value() default DesensitizeStrategy.NONE;
    
    Class<? extends Desensitization> usingDesensitization() default NoneDesensitization.class;
}
