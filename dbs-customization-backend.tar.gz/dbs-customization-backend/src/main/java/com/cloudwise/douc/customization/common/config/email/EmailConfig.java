package com.cloudwise.douc.customization.common.config.email;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * @author ming.ma
 * @since 2024-12-04  18:09
 **/
@Data
@RefreshScope
@Configuration
@Component
@ConfigurationProperties(prefix = "dosm.mail")
public class EmailConfig {

    /**
     * 请求条数
     */
    private Integer count = 1000;

    /**
     * 超时时间
     */
    private Integer timeout = 5;

    private Integer waitTime = 1;

    /**
     * 请求频率 0是当天
     */
    private Integer timeInterval = 0;

    private Boolean filterAttachment = false;

}
