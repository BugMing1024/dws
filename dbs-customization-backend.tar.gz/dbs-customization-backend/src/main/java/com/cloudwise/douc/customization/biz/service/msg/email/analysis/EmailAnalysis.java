package com.cloudwise.douc.customization.biz.service.msg.email.analysis;

import com.cloudwise.douc.customization.biz.model.email.EmailMessageVo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;

/**
 * @author ming.ma
 * @since 2024-12-06  16:26
 **/
public interface EmailAnalysis {

    EmailMessageVo getMessage(MessageContext context);

}
