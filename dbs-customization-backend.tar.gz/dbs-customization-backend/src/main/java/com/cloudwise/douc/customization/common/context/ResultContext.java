package com.cloudwise.douc.customization.common.context;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.HashSet;
import java.util.Set;

/**
 * Created on 2022-4-25.
 *
 * @author skiya
 */
@Data
@Accessors(chain = true)
public class ResultContext {
    
    private Set<String> successCodes = new HashSet<>();
    
    private Set<String> failCodes = new HashSet<>();
    
    private Set<String> ignoreCodes = new HashSet<>();
}
