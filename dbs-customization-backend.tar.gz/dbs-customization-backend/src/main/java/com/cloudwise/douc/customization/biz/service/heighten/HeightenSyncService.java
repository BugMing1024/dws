package com.cloudwise.douc.customization.biz.service.heighten;

import com.cloudwise.douc.customization.biz.model.heighten.WorkTimeLongPiece;

import java.util.List;
import java.util.Map;

/**
 * @author Magina
 * @date 2024/12/5 3:43 下午
 * @description
 **/
public interface HeightenSyncService {
    
    Integer syncHeightenAppCountryData();
    
    Integer syncHeightenPeriodData();
    
    Map<String,Object> heightenStatus(String data);

    Map<String,Object> bannerHeightenStatus(String data);
    
    List<WorkTimeLongPiece> heightenPeriodTime(String data);
}
