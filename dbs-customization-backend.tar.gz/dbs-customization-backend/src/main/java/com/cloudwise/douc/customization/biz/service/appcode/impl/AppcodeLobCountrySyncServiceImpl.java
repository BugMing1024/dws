package com.cloudwise.douc.customization.biz.service.appcode.impl;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.biz.dao.AppcodeLobCountryMapper;
import com.cloudwise.douc.customization.biz.model.appcode.*;
import com.cloudwise.douc.customization.biz.service.appcode.AppcodeLobCountrySyncService;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Magina
 * @date 2024/12/6 5:12 PM
 * @description
 **/

@Service
@Slf4j
public class AppcodeLobCountrySyncServiceImpl implements AppcodeLobCountrySyncService {

    @Value("${heighten.apiurl:https://itsm.cmwf.ocp.uat.dbs.com}")
    private String apiUrl;

    @Value("${heighten.apiurl.functionld:F00009}")
    private String functionld;

    @Value("${heighten.getAppCode.url:/common-server/ichamp/getAppCode}")
    private String getAppCodeUrl;

    @Value("${heighten.getCutoverData.url:/common-server/ichamp/getCutoverData}")
    private String getCutoverDataUrl;

    @Value("${heighten.getAppCodeInfo.url:/common-server/invensys/getAppCodeInfo}")
    private String getAppCodeInfoUrl;

    @Value("${heighten.getAppResiliencyInfo.url:/common-server/ichamp/getAppResiliencyInfo}")
    private String getAppResiliencyInfoUrl;

    @Value("${heighten.getAppDetails.url:/common-server/invensys/getAppDetails}")
    private String getAppDetailsUrl;


    @Autowired
    private AppcodeLobCountryMapper appcodeLobCountryMapper;

    @Autowired
    private DbsProperties dbsProperties;

    @Override
    public Integer syncAppcodeLobCountryData() {
        Integer count = 0;
        String periodResponse = HttpUtil.createPost(apiUrl + getAppCodeUrl).contentType("application/json")
                .header("appCode", dbsProperties.getAppCode()).header("appKey", dbsProperties.getAppKey()).timeout(20000).execute().body();
        log.info("syncAppcodeLobCountryData periodResponse :{}", JSONUtil.toJsonStr(periodResponse));
        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            Map<String, Object> dataMap = JsonUtils.parseObject(JSONUtil.toJsonStr(map.get("data")));
            List<AppcodeLobCountry> appcodeLobCountrys = JsonUtils.parseArray(JSONUtil.toJsonStr(dataMap.get("Data")), AppcodeLobCountry.class);
            appcodeLobCountryMapper.delAppcodeLobCountrys();
            count += appcodeLobCountryMapper.insertAppcodeLobCountryList(appcodeLobCountrys);
        }
        return count;
    }

    @Override
    public Integer syncAppcodesPendingProjectListData() {
        Integer count = 0;
        String periodResponse = HttpUtil.createPost(apiUrl + getCutoverDataUrl).contentType("application/json")
                .header("appCode", dbsProperties.getAppCode()).header("appKey", dbsProperties.getAppKey()).timeout(20000).execute().body();
        log.info("syncAppcodesPendingProjectListData periodResponse :{}", JSONUtil.toJsonStr(periodResponse));
        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            Map<String, Object> dataMap = JsonUtils.parseObject(JSONUtil.toJsonStr(map.get("data")));
            List<AppcodesPendingProjectList> appcodesPendingProjectLists = JsonUtils.parseArray(JSONUtil.toJsonStr(dataMap.get("Data")),AppcodesPendingProjectList.class);
            appcodeLobCountryMapper.delAppcodesPendingProjects();
            if (appcodesPendingProjectLists.size() > 0) {
                count += appcodeLobCountryMapper.insertAppcodesPendingProjectList(appcodesPendingProjectLists);
            }
        }
        return count;
    }

    @Override
    public Integer syncAppCodeInfo() {
        String periodResponse = HttpUtil.createGet(apiUrl + getAppCodeInfoUrl).contentType("application/json")
                .header("appCode", dbsProperties.getAppCode()).header("appKey", dbsProperties.getAppKey()).timeout(50000).execute().body();
        log.info("syncAppCodeInfo periodResponse :{}", JSONUtil.toJsonStr(periodResponse));

        Integer count = 0;
//        Map<String, String> appResiliencyInfo = getAppResiliencyInfo();
        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            String response = JSONUtil.toJsonStr(map.get("data"));
            List<AppCodeInfo> appCodeInfos = JsonUtils.parseArray(JSONUtil.toJsonStr(response), AppCodeInfo.class);

//            List<AppCodeInfo> appCodeInfosList = appCodeInfos.stream().map(appCodeInfo -> {
//                String appId = appCodeInfo.getAppId();
//                String resiliency = appResiliencyInfo.get(appId);
//                appCodeInfo.setResiliency(resiliency);
//                appCodeInfo.setSaveDate(new Date());
//                return appCodeInfo;
//            }).collect(Collectors.toList());

            //Delete old data
            appcodeLobCountryMapper.delAppCodes();
            //Insert new data
            if (appCodeInfos.size() > 2000) {
                //Batch warehousing
                List<List<AppCodeInfo>> lists = splitList(appCodeInfos, 2000);
                for (int i = 0; i < lists.size(); i++) {
                    List<AppCodeInfo> appCodeInfos1 = lists.get(i);
                    count += appcodeLobCountryMapper.insertAppCodes(appCodeInfos1);
                }
            } else {
                count += appcodeLobCountryMapper.insertAppCodes(appCodeInfos);
            }
        }
        return count;
    }

    @Override
    public Integer syncAppCodeResiliencyInfo() {
        Map<String, String> appResiliencyInfo = getAppResiliencyInfo();
        // select appCode
        List<AppCodeInfo> appCodeInfos = appcodeLobCountryMapper.selectAllAppcode();


        List<AppCodeInfo>  list = new ArrayList<>();
        List<String> listAppIds = new ArrayList<>();
        for (int i = 0; i < appCodeInfos.size(); i++) {
            AppCodeInfo appCodeInfo = appCodeInfos.get(i);
            String appId = appCodeInfo.getAppId();
            String resiliency = appCodeInfo.getResiliency();
            String response = appResiliencyInfo.get(appId);
            if (Strings.isNotEmpty(resiliency) && Strings.isNotEmpty(response) && !response.equals(resiliency)){
                appCodeInfo.setResiliency(response);
                appCodeInfo.setSaveDate(new Date());
                listAppIds.add(appId);
                list.add(appCodeInfo);
            }
        }
        int count=0;
        //Delete old data
        appcodeLobCountryMapper.delAppCodeInfoByAppId(listAppIds);
        //Insert new data
        if (list.size() > 2000) {
            //Batch warehousing
            List<List<AppCodeInfo>> lists = splitList(list, 2000);
            for (int i = 0; i < lists.size(); i++) {
                List<AppCodeInfo> appCodeInfos1 = lists.get(i);
                count += appcodeLobCountryMapper.insertAppCodes(appCodeInfos1);
            }
        } else {
            count += appcodeLobCountryMapper.insertAppCodes(list);
        }
        return count;
    }

    @Override
    public Integer syncServerDetatils() {

        String periodResponse = HttpUtil.createGet(apiUrl + getAppDetailsUrl).contentType("application/json")
                .header("appCode", dbsProperties.getAppCode()).header("appKey", dbsProperties.getAppKey()).timeout(500000).execute().body();
        log.info("syncServerDetatils periodResponse :{}", JSONUtil.toJsonStr(periodResponse));

        Integer count = 0;

        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            String response = JSONUtil.toJsonStr(map.get("data"));
            List<ServerDetatils> serverDetatils = JsonUtils.parseArray(JSONUtil.toJsonStr(response), ServerDetatils.class);

            List<ServerDetatils> serverDetatilsList = serverDetatils.stream().map(serverDetatil -> {
                serverDetatil.setSaveDate(new Date());
                return serverDetatil;
            }).collect(Collectors.toList());

            //Delete old data
            Integer integer = appcodeLobCountryMapper.delServerDetatils();
            //Insert new data
            if (serverDetatilsList.size() > 2000) {
                //分批入库
                List<List<ServerDetatils>> lists = splitList(serverDetatilsList, 2000);
                for (int i = 0; i < lists.size(); i++) {
                    List<ServerDetatils> list = lists.get(i);
                    count += appcodeLobCountryMapper.insertServerDetatilsList(list);
                    log.info("Number of inserted databases：{}", list.size());
                }
            } else {
                count += appcodeLobCountryMapper.insertServerDetatilsList(serverDetatilsList);
            }
        }
        return count;
    }

    @Override
    public Integer testServerDetatils() {
        String periodResponse = "{\"message\":\"SUCCESS\",\"data\":[{\"HOSTNAME\":\"bindingMapbindingMap\",\"FRAME_NAME\":\"v01raixvpvm202a_sg3\",\"PARTITION_TYPE\":\"LPAR\",\"IPADDRESS\":\"10.89.32.52\",\"NETWORK_ZONE\":\"APPDB\",\"INFRA_TYPE\":\"EPC\",\"PLATFORM\":\"AIX\",\"ENVIRONMENT\":\"DR\",\"SYSTEM_TYPE\":\"DB\",\"APPLICATION_CODE\":\"IB88\",\"APPLICATION_CATEGORY\":\"1\",\"LOB\":\"CBGT\",\"COUNTRY\":\"SG\",\"STATUS\":\"Active\"},{\"HOSTNAME\":\"yyyyyyyy\",\"FRAME_NAME\":\"v01raixvpvm202a_sg3\",\"PARTITION_TYPE\":\"LPAR\",\"IPADDRESS\":\"10.89.32.52\",\"NETWORK_ZONE\":\"APPDB\",\"INFRA_TYPE\":\"EPC\",\"PLATFORM\":\"AIX\",\"ENVIRONMENT\":\"DR\",\"SYSTEM_TYPE\":\"DB\",\"APPLICATION_CODE\":\"IB88\",\"APPLICATION_CATEGORY\":\"1\",\"LOB\":\"CBGT\",\"COUNTRY\":\"SG\",\"STATUS\":\"Active\"}]}";
        log.info("syncServerDetatils periodResponse :{}", JSONUtil.toJsonStr(periodResponse));

        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            String response = JSONUtil.toJsonStr(map.get("data"));
            List<ServerDetatils> serverDetatils = JsonUtils.parseArray(JSONUtil.toJsonStr(response), ServerDetatils.class);

            List<ServerDetatils> list = new ArrayList<>();
            for (int i = 0; i < 10000; i++) {
                list.addAll(serverDetatils);
            }
            if (list.size() > 2000) {
                //Batch warehousing
                List<List<ServerDetatils>> lists = splitList(list, 2000);
                for (int i = 0; i < lists.size(); i++) {
                    List<ServerDetatils> list1 = lists.get(i);
                    appcodeLobCountryMapper.insertServerDetatilsLisTest(list1);
                }
            } else {
                appcodeLobCountryMapper.insertServerDetatilsLisTest(list);
            }

        }
        return null;
    }

    @Override
    public List<ServerDetatils> selectServerDetatils() {
        List<ServerDetatils> serverDetatilsList = appcodeLobCountryMapper.selAllServerDetatils();

        return serverDetatilsList;
    }

    //get app resiliency info
    public Map<String, String> getAppResiliencyInfo() {

        String periodResponse = HttpUtil.createPost(apiUrl + getAppResiliencyInfoUrl).contentType("application/json")
                .header("appCode", dbsProperties.getAppCode())
                .header("appKey", dbsProperties.getAppKey())
                .timeout(20000)
                .execute().body();
        log.info("getAppResiliencyInfo periodResponse :{}", JSONUtil.toJsonStr(periodResponse));

        Map<String, String> allAppResiliency = new HashMap<>();

        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            Map<String, Object> dataMap = JsonUtils.parseObject(JSONUtil.toJsonStr(map.get("data")));
            List<AppResiliencyInfo> appResiliencyInfos = JsonUtils.parseArray(JSONUtil.toJsonStr(dataMap.get("Data")), AppResiliencyInfo.class);
            for (int i = 0; i < appResiliencyInfos.size(); i++) {
                AppResiliencyInfo appResiliencyInfo = appResiliencyInfos.get(i);
                String appCode = appResiliencyInfo.getAppCode();
                String resiliency = appResiliencyInfo.getResiliency();
                allAppResiliency.put(appCode, resiliency);
            }
        }
        return allAppResiliency;
    }

    public static <T> List<List<T>> splitList(List<T> list, int batchSize) {
        List<List<T>> result = new ArrayList<>();
        int size = list.size();
        for (int i = 0; i < size; i += batchSize) {
            int toIndex = Math.min(size, i + batchSize);
            result.add(list.subList(i, toIndex));
        }
        return result;
    }

}
