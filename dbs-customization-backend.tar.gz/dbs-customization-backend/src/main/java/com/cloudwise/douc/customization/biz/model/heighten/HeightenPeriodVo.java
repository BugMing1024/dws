package com.cloudwise.douc.customization.biz.model.heighten;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Magina
 * @date 2024/12/5 4:41 下午
 * @description
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HeightenPeriodVo {
    
    @JsonProperty("AppCode")
    private String appCode;
    
    @JsonProperty("CreatedDate")
    private String createdDate;
    
    @JsonProperty("FreezeDate")
    private String freezeDate;
    
    @JsonProperty("FreezeType")
    private String freezeType;
    
    @JsonProperty("ChangedDate")
    private String changedDate;
    
    @JsonProperty("Description")
    private String description;
    
}
