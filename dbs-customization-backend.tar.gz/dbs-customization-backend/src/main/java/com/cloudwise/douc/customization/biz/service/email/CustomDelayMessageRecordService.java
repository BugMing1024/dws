package com.cloudwise.douc.customization.biz.service.email;

import com.cloudwise.douc.customization.biz.model.table.CustomDelayMessageRecord;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  10:05
 **/
public interface CustomDelayMessageRecordService {
    
    String insertRecord(CustomDelayMessageRecord messageRecord);
    
    void updateDelayMessageRecord(List<CustomDelayMessageRecord> messageRecords);
    
    
    List<CustomDelayMessageRecord> getDelayNotifyMessages();
    
    CustomDelayMessageRecord getNotifyMessages(String workOrderId, String nodeId);
}
