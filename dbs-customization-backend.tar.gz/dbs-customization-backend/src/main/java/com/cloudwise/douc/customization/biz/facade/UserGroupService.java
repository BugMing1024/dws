package com.cloudwise.douc.customization.biz.facade;

import com.cloudwise.douc.customization.biz.facade.user.GroupUserInfo;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboGroupIdReq;

/**
 * @author ming.ma
 * @since 2024-12-19  19:59
 **/
public interface UserGroupService {
    
    /**
     * 入参说明 : accountId必填 groupId 必填 userId必填 isContainUser 非 默认false
     */
    DubboCommonResp<GroupUserInfo> getUserGroupInfoById(DubboGroupIdReq req);
}
