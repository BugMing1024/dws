package com.cloudwise.douc.customization.biz.facade.user;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo {
    
    public static final UserInfo DEFAULT = new UserInfo();
    
    /**
     * 用户id
     */
    private Long userId;
    
    /**
     * 租户id
     */
    private Long accountId;
    
    /**
     * 用户名
     */
    private String name;
    
    /**
     * 用户电话
     */
    private String mobile;
    
    
    /**
     * 邮箱
     */
    private String email;
    
    /**
     * 状态  1 正常 2停用
     */
    private Integer status;
    
    
    /**
     * 别名
     */
    private String userAlias;
    
    /**
     * 所在部门id
     */
    private Long departmentId;
    
    
    /**
     * 部门名称
     */
    private String department;
    
    /**
     * 部门层级深度
     */
    private String departmentLevel;
    
    
    /**
     * 部门名称
     */
    private String departmentDetail;
    
    /**
     * 用户所属角色
     */
    private List<Long> roleIds = new ArrayList<>();
    
    /**
     * 用户所属用户组
     */
    private List<Long> groupIds = new ArrayList<>();
    
    /**
     * 所在地
     */
    private String userOrigin;
    
    /**
     * 属性
     */
    private String attribute;
    
    /**
     * 顶级租户id
     */
    private String topAccountId;
    
    /**
     * 钉钉账号
     */
    private String dingtalkAccount;
    
    /**
     * 微信账号
     */
    private String weixinworkAccount;
    
    /**
     * 飞书账号-userid
     */
    private String feishuAccount;
    
    /**
     * 扩展
     */
    private List<BaseExtend> extend;
    
    /**
     * 职位
     */
    private String position;
    
    
    /**
     * 用户占用配额
     */
    private List<String> licFeatureCodes;
    
    
}
