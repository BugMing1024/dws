package com.cloudwise.douc.customization.common.condition;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * 验证表达式情况的类
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-17 02:06; update at 2024-12-17 02:06
 */
@Component
@SyncEndpoint(name = "user")
@Conditional(value = SyncCheckCondition.class)
public class ConditionTest {
    
    @PostConstruct
    private void test() {
        System.out.println("abc");
    }
    
    @XxlJob(value = "user")
    public void test2() {
    
    }
    
}
