package com.cloudwise.douc.customization.biz.service.groupuser.mapping;

import cn.hutool.core.convert.Converter;
import lombok.Data;

/**
 * Created on 2022-3-4.
 *
 * @author skiya
 */
@Data
public class ResultMap {
    
    private String source;
    
    private String target;
    
    private Class<? extends Converter<?>> converter;
    
}
