package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.table.UploadFileInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-19  17:31
 **/
@Mapper
public interface UploadFileMapper extends BaseMapper<UploadFileInfo> {
    
    
    UploadFileInfo selectFileInfoListById(@Param("id") String id);

    List<UploadFileInfo> selectFileInfoListByIds(@Param("ids") List<String> ids);

}
