package com.cloudwise.douc.customization.biz.model.groupuser;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Created on 2022-10-18.
 *
 * @author skiya
 */
@Data
@NoArgsConstructor
public class DoucPageResponse<T> implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("pageSize")
    private Integer pageSize;
    
    @JsonProperty("totalCount")
    private Integer totalCount;
    
    @JsonProperty("currentPageNo")
    private Integer currentPageNo;
    
    @JsonProperty("totalPageCount")
    private Integer totalPageCount;
    
    @JsonAlias({"list", "data"})
    private T data;
}
