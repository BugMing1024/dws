package com.cloudwise.douc.customization.biz.model.email.dosm;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author wuzhaoyi
 */
@Data
public class MultiApproveConf {
    
    /**
     * 通过规则
     */
    @ApiModelProperty(value = "通过规则", example = "    ALL(\"全部通过\"),\n" + "        ANY(\"任一通过\"),\n"
            + "        CUSTOM(\"自定义通过\");", required = true)
    private MultiApproveConst.MultApprovePassRuleEnum passRule;
    
    
    @ApiModelProperty(value = "自定义通过规则", example = ";", required = true)
    private CustomApprovePassRule customPassRule;
    
    
    /**
     * 驳回规则
     */
    @ApiModelProperty(value = "驳回规则", example = "    ALL(\"全部驳回\"),\n" + "        ANY(\"任一驳回\"),\n"
            + "        CUSTOM(\"自定义驳回\");", required = true)
    private MultiApproveConst.MultApproveRejectRuleEnum rejectRule = MultiApproveConst.MultApproveRejectRuleEnum.ALL;
    
    
    @ApiModelProperty(value = "自定义驳回规则", example = ";", required = true)
    private CustomApproveRejectRule customRejectRule;
    
    
    @ApiModelProperty(value = "提前结束会签", example = ";", required = true)
    private boolean enableApproveFinishConf = false;
    
    //    @ApiModelProperty(value = "提前结束会签设置", example = ";", required = true)
    //    private MultiApproveFinishConf approveFinishConf;
    
    @ApiModelProperty(value = "提前结束会签设置", example = "['WHEN_MEET_PASS_RULE','WHEN_MEET_REJECT_RULE']")
    private List<MultiApproveConst.MultiApproveFinishWhenEnum> approveFinishConf;
    
    /**
     * v1/v2没有此参数 v1 通过规则只有全部通过和任一通过 v2 增加了自定义通过规则，增加了满足或无法达成通过规则时可以提前结束 v3 增加了驳回规则，提前结束设置改为多选: 满足通过规则、无法达成通过规则、满足驳回规则
     */
    @ApiModelProperty(value = "配置版本", example = "3")
    private long version;
    
    
}