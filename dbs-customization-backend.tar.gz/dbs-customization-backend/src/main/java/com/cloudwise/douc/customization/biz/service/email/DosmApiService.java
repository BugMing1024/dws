package com.cloudwise.douc.customization.biz.service.email;

import com.cloudwise.douc.customization.biz.model.email.ApproveOrderVo;

/**
 * @author ming.ma
 * @since 2024-12-11  14:13
 **/
public interface DosmApiService {
    
    boolean approveOrder(ApproveOrderVo approveOrder);
    
}
