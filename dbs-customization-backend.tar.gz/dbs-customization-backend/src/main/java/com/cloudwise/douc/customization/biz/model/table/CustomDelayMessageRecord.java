package com.cloudwise.douc.customization.biz.model.table;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 延迟消息记录表
 *
 * @author ming.ma
 * @since 2024-12-10  09:53
 **/
@Data
@TableName("dosm_custom_delay_message_record")
public class CustomDelayMessageRecord implements Serializable {
    
    private static final long serialVersionUID = -7559818045010522101L;
    
    /**
     * 消息记录id
     */
    @TableId
    private String id;
    
    
    /**
     * 创建用户id
     */
    private String createdBy;
    
    /**
     * 是否删除
     */
    private int isDel;
    
    /**
     * 创建时间
     */
    private Date createdTime;
    
    /**
     * 更新时间
     */
    private Date updatedTime;
    
    /**
     * 顶级租户ID
     */
    private String topAccountId;
    
    /**
     * 租户id
     */
    private String accountId;
    
    /**
     * 更新用户id
     */
    private String updatedBy;
    
    /**
     * 乐观锁
     */
    private Integer revision;
    
    /**
     * 工单id
     */
    private String workOrderId;
    
    /**
     * 节点id
     */
    private String nodeId;
    
    /**
     * 消息是否发送成功： 0 -未开始,1-成功 2-失效
     */
    private int status;
    
    
    /**
     * 消息发送参数
     */
    private String notifyContent;
    
    /**
     * 重试次数
     */
    private int retry;
    
    /**
     * 期望执行时间
     */
    private Date execAt;
    
    /**
     * 创建时间
     */
    private Date startTime;
    
    /**
     * 更新时间
     */
    private Date endTime;
    
    
    public static CustomDelayMessageRecord buildInsertInfo(MessageContext messageContext) {
        CustomDelayMessageRecord customMessageRecord = new CustomDelayMessageRecord();
        customMessageRecord.setId(IdUtil.fastSimpleUUID());
        customMessageRecord.setWorkOrderId(messageContext.getWorkOrderId());
        customMessageRecord.setCreatedBy(messageContext.getCreatedBy());
        customMessageRecord.setAccountId(messageContext.getAccountId());
        customMessageRecord.setTopAccountId(messageContext.getTopAccountId());
        customMessageRecord.setNodeId(messageContext.getNodeId());
        customMessageRecord.setNotifyContent(JsonUtils.toJsonStr(messageContext));
        Date date = new Date();
        customMessageRecord.setUpdatedBy(messageContext.getCreatedBy());
        customMessageRecord.setUpdatedTime(date);
        customMessageRecord.setCreatedTime(date);
        customMessageRecord.setIsDel(0);
        customMessageRecord.setStatus(0);
        return customMessageRecord;
    }
    
    
}
