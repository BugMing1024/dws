package com.cloudwise.douc.customization.biz.model.email.dosm;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author jonlee
 */
@Data
public class CustomApproveRejectRule {
    
    @ApiModelProperty(value = "自定义驳回规则", example = "  /**\n" + "         * 按驳回次数\n" + "         */\n" + "        REJECT_TIMES,\n" + "\n"
            + "        /**\n" + "         * 按驳回比例\n" + "         */\n" + "        REJECT_PROPORTION,", required = false)
    private MultiApproveConst.CustomRejectRuleTypeEnum customRuleAttributes;
    
    @ApiModelProperty(value = "条件比对,等于 EQ, 大于或等于 GE, 大于GT", example = "", required = false)
    private MultiApproveConst.ConditionTypeEnum conditionCompare;
    
    @ApiModelProperty(value = "自定义分子", example = "1", required = false)
    private Integer molecularNum;
    
    @ApiModelProperty(value = "自定义分母", example = "2", required = false)
    private Integer denominatorNum;
    
    @ApiModelProperty(value = "自定义驳回数", example = "", required = false)
    private Integer rejectNum;
    
    
}
