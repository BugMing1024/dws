package com.cloudwise.douc.customization.biz.model.table;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.ibatis.type.JdbcType;

/**
 * 表单定义实体
 *
 * @author: damon.fu
 * @since: 2021-06-11 16:30
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("mdl_form")
public class MdlForm {
    
    /**
     * uuid
     */
    private String mdlUuid;
    
    /**
     * 表单布局信息
     */
    private String formInfo;
    
    /**
     * 表单数据 { "fieldName": "", //字段名称 "fieldValueType": "", // 详见上方取值 "fieldCode": "", //属性编码 // "fieldInfo": {} "parentFieldKey": //暂未知，保留
     * "parentFieldTitle": //暂未知，保留 "enumSourceLevel": //暂未知，保留 "isPrepositionField": //暂未知，保留 "defaultValue": //存在默认值传值，不存在传""，当前日期传currentDate
     * "fieldType": //表示控件是自定义控件还是内建控件 CUSTOM（自定义），BUILTIN（内建） "fieldRule": { "check":
     * //PHONE（正则手机），EMAIl（正则邮箱），NORULE（无规则），REGULAR，CUSTOM(自定义正则）,ENUM（枚举），RECURSIVE_ENUM（迭代枚举），NUMBER(数字），NORULE（固定行） ，EUMN（非固定行） "range": { //范围
     * "min": //最小值 "max": //最大值 }， "enumSourceType": //数据字典名称, "enumSourceId": //数据字典ID, "isInt": //是否为整数 true（整数），false（非整数） "decimalsMount":
     * //小数保留位数 "regularExpression": //正则表达式 "fieldWidth": //字段宽度 WHOLE_LINE(整行），HALF_LINE(二分之一行），ONE_THIRD_LINE(三分之一行），ONE_FOURTH_LINE(四分之一行）
     * "filedVisible": //字段可见性（保密设置） ALL_VISIBLE(全部可见)，PART_VISIBLE(部分可见) "isOnlyDate": //是否仅日期 true（是），false（否） "isMultiple": //是否支持多选
     * true（多选），false（单选） "starLength": //星级长度 STAR_LENGTH_3(3），STAR_LENGTH_5(5),STAR_LENGTH_10(10) "nameVisible": //文字控件，字段隐藏与显示,true隐藏，false显示
     * "align": //对齐方式 ALIGN_LEFT（左对齐），ALIGN_MIDDLE（居中），ALIGN_RIGHT（右对齐） "approvalFieldFlag": //是否审批字段，是true，否false "size": //文件上传大小限制 "count":
     * //文件上传数量限制 "dateFormat": //日期控件传值，YEAR_MONTH_DAY（年月日）， YEAR_MONTH_DAY_HOURS_MINUTES_SECONDS（年月日时分秒） "enumList": [ //check字段非NORULE,此字段存在值 {
     * "label": //名称 "value": //枚举值默认按照1，2，3生成,迭代枚举为1,1-1,1-1-1方式生成；enumSourceType=DICTIONARY，为创建数据字典的data "children": //迭代枚举子集 数据字典子集 "parentId":
     * //数据字典会有多层级，父级别的id "data": //未知，暂保留 "level": //数据字典所在层级 "type": //成员组枚举类型 GROUP(组类型），USER(用户类型） //表单新增控件类型 单行文本(INPUT) 多行文本(TEXTAREA)
     * 下拉框单选(SELECT) 下拉框多选(SELECT_MANY) 多级下拉(MULTI_SELECT) 数字(NUMBER) 日期(DATE) 成员(MEMBER) }, { "label": //名称 "value":
     * //枚举值默认按照1，2，3生成,迭代枚举为1,1-1,1-1-1方式生成；enumSourceType=DICTIONARY，为创建数据字典的data "children": //迭代枚举子集 "parentId": //数据字典会有多层级，父级别的id "data":
     * //未知，暂保留 "level": //数据字典所在层级 "type": //成员组枚举类型 GOURP(组类型），USER(用户类型） //表单新增控件类型 单行文本(INPUT) 多行文本(TEXTAREA) 下拉框单选(SELECT) 下拉框多选(SELECT_MANY)
     * 多级下拉(MULTI_SELECT) 数字(NUMBER) 日期(DATE) 成员(MEMBER) }, { "label": //名称 "value":
     * //枚举值默认按照1，2，3生成,迭代枚举为1,1-1,1-1-1方式生成；enumSourceType=DICTIONARY，为创建数据字典的data "children": //迭代枚举子集 "parentId": //数据字典会有多层级，父级别的id "data":
     * //未知，暂保留 "level": //数据字典所在层级 "type": //成员组枚举类型 GOURP(组类型），USER(用户类型） //表单新增控件类型 单行文本(INPUT) 多行文本(TEXTAREA) 下拉框单选(SELECT) 下拉框多选(SELECT_MANY)
     * 多级下拉(MULTI_SELECT) 数字(NUMBER) 日期(DATE) 成员(MEMBER) } ] } }
     */
    private String fieldList;
    
    /**
     * 版本号
     */
    private Integer version;
    
    
    //mybatis mapper 获取不到继承的属性
    @ApiModelProperty(value = "顶级租户ID", example = "110")
    @TableField(value = "top_account_id", jdbcType = JdbcType.VARCHAR)
    private String topAccountId;
    
    /**
     * 租户ID
     */
    @ApiModelProperty(value = "租户ID", example = "110")
    @TableField(value = "account_id", jdbcType = JdbcType.VARCHAR)
    private String accountId;
    
    /**
     * 0启用1停用
     */
    private Integer status;
    
    @TableField(exist = false)
    private String processDefId;
    
    @TableField(exist = false)
    private String processDefKey;
    
    /**
     * 是否存在CMDB模型配置项字段
     */
    private Boolean hasCmdbField;
    
    /**
     * 加密扩展类的bean id
     */
    private String encryptExtId;
    
}


