package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.service.heighten.HeightenSyncService;
import com.cloudwise.douc.customization.biz.util.SyncJobUtil;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Magina
 * @date 2024/12/27 11:03 上午
 * @description
 **/

@Slf4j
@RestController()
@SyncEndpoint(name = "syncHeightenPeriodData", cron = Constants.SYNC_HEIGHTEN_DATA_JOB_CRON)
@RequestMapping("/api/heighten")
@Conditional(value = SyncCheckCondition.class)
public class HeightenJobHandler {
    
    private AtomicBoolean SYNC_HEIGHTEN_PERIOD_DATAP_IS_RUNING = new AtomicBoolean(false);
    
    
    @Autowired
    private HeightenSyncService heightenSyncService;
    
    
    @XxlJob("syncHeightenPeriodData")
    @GetMapping("/syncHeightenPeriodData")
    public Map<String, Object> syncAppCodeInfo() {
        log.info("syncHeightenPeriodData start");
        SyncJobUtil.syncJob(() -> heightenSyncService.syncHeightenPeriodData(), SYNC_HEIGHTEN_PERIOD_DATAP_IS_RUNING);
        log.info("syncHeightenPeriodData end");
        return new HashMap();
    }
    
}
