package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-05  16:36
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageContext implements Serializable {
    
    private static final long serialVersionUID = -3368815311669246003L;
    
    private Map<String, FieldInfo> formData;

    /**
     * The front-end page sends the form data, which takes precedence over the data form data
     */
    private JsonNode formDataJson;
    
    /**
     * 邮件通知内容
     */
    private NotifyVo notify;
    
    /**
     * 公共字段属性值列表
     */
    private Map<String, String> publicFields = new HashMap<>();
    
    /**
     * 工单id
     */
    private String workOrderId;
    
    /**
     * 节点id
     */
    private String nodeId;
    
    /**
     * 创建用户id
     */
    private String createdBy;
    
    /**
     * 顶级租户ID
     */
    private String topAccountId;
    
    /**
     * 租户id
     */
    private String accountId;
    
    /**
     * 用户id
     */
    private String userId;


    // yongyu linshi cunchu xiaoxi jilu id    yongyu shenpi fansheng cuowu de changji chongxin fasong
    private String tmpRecordId;



}
