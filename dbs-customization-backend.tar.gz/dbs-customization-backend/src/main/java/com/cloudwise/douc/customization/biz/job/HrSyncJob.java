package com.cloudwise.douc.customization.biz.job;

import cn.hutool.core.collection.CollUtil;
import com.cloudwise.cache.utils.RedisUtils;
import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.facade.DbsFacade;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.customization.biz.service.groupuser.processor.DoucGroupSyncProcessor;
import com.cloudwise.douc.customization.biz.service.groupuser.processor.DoucUserSyncProcessor;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import com.cloudwise.douc.dto.v3.common.CommonResp;
import com.cloudwise.douc.dto.v3.common.PageResp;
import com.cloudwise.douc.dto.v3.common.UserInfo;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.cloudwise.douc.facadev3.UserFacade;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 所有映射的处理
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-22 01:06; update at 2024-12-22 01:06
 */
@Slf4j
@RestController()
@SyncEndpoint(name = "hr")
@RequestMapping("/hr")
@Conditional(value = SyncCheckCondition.class)
public class HrSyncJob {
    
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserFacade userFacade;
    
    private boolean isRunning;
    
    @Autowired
    private DoucUserSyncProcessor userSyncProcessor;
    
    @Autowired
    private DoucProperties doucProperties;
    
    @Autowired
    private DbsFacade dbsFacade;
    
    @Autowired
    private DoucGroupSyncProcessor doucGroupSyncProcessor;
    
    @Autowired(required = false)
    private RedisUtils redisUtils;
    
    @Autowired
    private DbsProperties dbsProperties;
    
    @GetMapping("/sync")
    @XxlJob("hr")
    public void jobRun() {
        log.debug("------hr--job-start----");
        if (isRunning) {
            return;
        }
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            if (isRunning) {
                return;
            }
            try {
                if (!isRunning) {
                    isRunning = true;
                }
                executeInternal();
            } catch (Throwable exception) {
                log.error("error run task", exception);
            } finally {
                isRunning = false;
            }
        });
        log.debug("------hr--job-end----");
    }
    
    protected void executeInternal() {
        log.debug("------hrsync--Runnable-start----");
        if (redisUtils != null && !redisUtils.setnx(this.getClass().getSimpleName(), "", 10L, TimeUnit.MINUTES)) {
            log.warn("same task is running");
            return;
        }
        try {
            // do something
            ArrayList<DbsUserInfo> users = Lists.newArrayList();
            dbsFacade.buildHRUser(users);
            userSyncProcessor.init();
            userSyncProcessor.write(users);
            XxlJobHelper.log("test2");
            UserConditionReq userConditionReq = new UserConditionReq();
            userConditionReq.setGroupCodes(Lists.newArrayList(dbsProperties.getHr().getGroupCode()));
            userConditionReq.setAccountId(doucProperties.getAccountId());
            userConditionReq.setSize(100);
            Set<String> doucCodes = Sets.newHashSet();
            long page = 1L;
            while (true) {
                userConditionReq.setCurrent(page++);
                CommonResp<PageResp<UserInfo>> userByCondition = userFacade.getUserByCondition(userConditionReq);
                if (!userByCondition.isSuccess() || userByCondition.getData() == null || CollUtil.isEmpty(userByCondition.getData().getRecords())) {
                    break;
                }
                doucCodes.addAll(userByCondition.getData().getRecords().stream().map(UserInfo::getCode).collect(Collectors.toList()));
                if (userByCondition.getData().getPages() < page) {
                    break;
                }
            }
            List<String> dbsCodes = users.stream().map(DbsUserInfo::getCode).collect(Collectors.toList());
            List<String> delCodes = CollUtil.subtractToList(doucCodes, dbsCodes);
            DbsGroupInfo group = new DbsGroupInfo();
            group.setCode(dbsProperties.getHr().getGroupCode());
            group.setAccountId(doucProperties.getAccountId());
            group.setAddUserCodes(dbsCodes);
            group.setRemoveUserCodes(delCodes);
            doucGroupSyncProcessor.init();
            doucGroupSyncProcessor.write(Collections.singletonList(group));
        } finally {
            redisUtils.del(this.getClass().getSimpleName());
        }
        log.debug("------hr sync--Runnable-end----");
    }
}
