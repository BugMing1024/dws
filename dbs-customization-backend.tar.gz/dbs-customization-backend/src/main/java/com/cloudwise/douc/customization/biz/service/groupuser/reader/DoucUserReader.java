package com.cloudwise.douc.customization.biz.service.groupuser.reader;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjUtil;
import com.cloudwise.douc.customization.biz.constant.BusinessType;
import com.cloudwise.douc.customization.biz.facade.DbsFacade;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsRespCommonGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.ImplementerGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.MdApproveGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.UserTSO;
import com.cloudwise.douc.customization.common.model.GroupAndUserInfo;
import com.google.common.collect.Maps;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Slf4j
@Component
@RequiredArgsConstructor
public class DoucUserReader implements Reader<DbsUserInfo> {
    
    private final DbsMultiReader dbsMultiReader;
    
    private final DbsFacade dbsFacade;
    
    @Override
    public List<DbsUserInfo> read(Object... param) {
        if (param == null || param.length == 0) {
            return Collections.emptyList();
        }
        GroupAndUserInfo read = dbsMultiReader.read((List<BusinessType>) param[0]);
        if (read == null) {
            return Collections.emptyList();
        }
        return build(read.getApproveGroups(), read.getImplementerGroups(), read.getMdApproveGroups(), read.getReleaseGroups(), read.getChangeGroups(),
                read.getUsers());
    }
    
    private List<DbsUserInfo> build(List<DbsRespCommonGroup> approveGroups, List<ImplementerGroup> implementerGroups,
            List<MdApproveGroup> mdApproveGroups, List<DbsRespCommonGroup> releaseGroups, List<DbsRespCommonGroup> changeGroups,
            List<UserTSO> userTSOs) {
        List<DbsUserInfo> result = new ArrayList<>();
        Map<String, DbsUserInfo> memberMap = Maps.newHashMapWithExpectedSize(1);
        if (CollUtil.isNotEmpty(implementerGroups)) {
            for (ImplementerGroup implementerGroup : implementerGroups) {
                String memberLogin = implementerGroup.getMemberLogin();
                if (memberMap.containsKey(memberLogin)) {
                    DbsUserInfo dbsUserInfo = memberMap.get(memberLogin);
                    if (dbsUserInfo != null && !Objects.equals(dbsUserInfo.getName(), implementerGroup.getMemberName())) {
                        log.warn("发现重复的memberLogin键: {}，将取第一个值：{}。", dbsUserInfo.getEmail(), implementerGroup.getMemberName());
                    }
                    continue;
                }
                String memberEmail = implementerGroup.getMemberEmail();
                if (memberLogin != null) {
                    DbsUserInfo dbsUserInfo = new DbsUserInfo();
                    dbsUserInfo.setName(implementerGroup.getMemberName());
                    dbsUserInfo.setEmail(implementerGroup.getMemberEmail());
                    dbsUserInfo.setAlias(memberLogin);
                    dbsUserInfo.setMobile(implementerGroup.getMemberMobile());
                    dbsUserInfo.setCode(memberLogin);
                    dbsUserInfo.setOneBankId(memberLogin);
                    memberMap.put(memberLogin, dbsUserInfo);
                    result.add(dbsUserInfo);
                }
                String groupOwnerLogin = implementerGroup.getGroupOwnerLogin();
                if (!memberMap.containsKey(groupOwnerLogin)) {
                    if (groupOwnerLogin != null) {
                        DbsUserInfo dbsUserInfo = new DbsUserInfo();
                        dbsUserInfo.setName(ObjUtil.defaultIfBlank(implementerGroup.getGroupOwner(), groupOwnerLogin));
                        dbsUserInfo.setEmail(implementerGroup.getGroupOwnerEmail());
                        dbsUserInfo.setAlias(groupOwnerLogin);
                        dbsUserInfo.setCode(groupOwnerLogin);
                        dbsUserInfo.setOneBankId(groupOwnerLogin);
                        memberMap.put(memberLogin, dbsUserInfo);
                        result.add(dbsUserInfo);
                    }
                }
            }
            
        }
        buildCommonUser(approveGroups, memberMap, result);
        buildCommonUser(releaseGroups, memberMap, result);
        buildCommonUser(changeGroups, memberMap, result);
        if (CollUtil.isNotEmpty(mdApproveGroups)) {
            for (MdApproveGroup mdApproveGroup : mdApproveGroups) {
                String memberLogin = mdApproveGroup.getLogin();
                // 没有意义的信息，不比对，但是设置rank
                if (memberMap.containsKey(memberLogin)) {
                    DbsUserInfo dbsUserInfo = memberMap.get(memberLogin);
                    dbsUserInfo.setMdGroupRank(mdApproveGroup.getRank());
                    continue;
                }
                if (memberLogin != null) {
                    DbsUserInfo dbsUserInfo = new DbsUserInfo();
                    dbsUserInfo.setAlias(memberLogin);
                    dbsUserInfo.setName(mdApproveGroup.getApprover());
                    dbsUserInfo.setCode(memberLogin);
                    dbsUserInfo.setOneBankId(memberLogin);
                    //                dbsUserInfo.setEmail(mdApproveGroup.getLogin() + "@dbs.com");
                    dbsUserInfo.setMdGroupRank(mdApproveGroup.getRank());
                    memberMap.put(memberLogin, dbsUserInfo);
                    result.add(dbsUserInfo);
                }
            }
        }
        if (CollUtil.isNotEmpty(userTSOs)) {
            for (UserTSO userTSO : userTSOs) {
                String memberLogin = userTSO.getLogin();
                // 没有用信息，不比对，但是设置tsoid
                if (memberMap.containsKey(memberLogin)) {
                    DbsUserInfo dbsUserInfo = memberMap.get(memberLogin);
                    dbsUserInfo.setTsoId(userTSO.getTSOID());
                    continue;
                }
                if (memberLogin != null) {
                    DbsUserInfo dbsUserInfo = new DbsUserInfo();
                    dbsUserInfo.setCode(memberLogin);
                    dbsUserInfo.setAlias(memberLogin);
                    dbsUserInfo.setTsoId(userTSO.getTSOID());
                    memberMap.put(memberLogin, dbsUserInfo);
                    result.add(dbsUserInfo);
                }
            }
        }
        dbsFacade.buildUserDetail(result);
        return result;
    }
    
    private void buildCommonUser(List<DbsRespCommonGroup> approveGroups, Map<String, DbsUserInfo> memberMap, List<DbsUserInfo> result) {
        if (CollUtil.isNotEmpty(approveGroups)) {
            for (DbsRespCommonGroup approveGroup : approveGroups) {
                String memberLogin = approveGroup.getMemberLogin();
                if (memberMap.containsKey(memberLogin)) {
                    // TODO比对
                    DbsUserInfo dbsUserInfo = memberMap.get(memberLogin);
                    if (dbsUserInfo != null && !Objects.equals(dbsUserInfo.getName(), approveGroup.getMemberName())) {
                        log.warn("发现重复的memberLogin键: {}，将取第一个值：{}。", dbsUserInfo.getEmail(), approveGroup.getMemberName());
                    }
                    continue;
                }
                if (memberLogin != null) {
                    DbsUserInfo dbsUserInfo = new DbsUserInfo();
                    dbsUserInfo.setName(approveGroup.getMemberName());
                    dbsUserInfo.setEmail(approveGroup.getMemberEmail());
                    dbsUserInfo.setAlias(memberLogin);
                    dbsUserInfo.setCode(memberLogin);
                    dbsUserInfo.setOneBankId(memberLogin);
                    memberMap.put(memberLogin, dbsUserInfo);
                    result.add(dbsUserInfo);
                }
                String groupOwnerLogin = approveGroup.getGroupOwnerLogin();
                if (!memberMap.containsKey(groupOwnerLogin)) {
                    if (groupOwnerLogin != null) {
                        DbsUserInfo dbsUserInfo = new DbsUserInfo();
                        dbsUserInfo.setName(ObjUtil.defaultIfBlank(approveGroup.getGroupOwner(), groupOwnerLogin));
                        dbsUserInfo.setEmail(approveGroup.getGroupOwnerEmail());
                        dbsUserInfo.setAlias(groupOwnerLogin);
                        dbsUserInfo.setCode(groupOwnerLogin);
                        dbsUserInfo.setOneBankId(groupOwnerLogin);
                        memberMap.put(memberLogin, dbsUserInfo);
                        result.add(dbsUserInfo);
                    }
                }
                
            }
        }
    }
}
