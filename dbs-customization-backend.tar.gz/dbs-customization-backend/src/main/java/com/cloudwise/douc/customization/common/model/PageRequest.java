package com.cloudwise.douc.customization.common.model;

import lombok.Getter;
import lombok.ToString;

/**
 * @author skiya
 * @date Created on 2021-11-18.
 */
@Getter
@ToString
public class PageRequest {
    
    private Long current;
    
    private Long size;
    
    public PageRequest() {
        this.current = 1L;
        this.size = 10L;
    }
    
    public PageRequest(Long current, Long size) {
        this.current = current;
        this.size = size;
    }
    
    public void setCurrent(Long current) {
        if (current < 0) {
            current = 1L;
        }
        this.current = current;
    }
    
    public void setSize(Long size) {
        if (size < 0) {
            size = 10L;
        }
        this.size = size;
    }
}
