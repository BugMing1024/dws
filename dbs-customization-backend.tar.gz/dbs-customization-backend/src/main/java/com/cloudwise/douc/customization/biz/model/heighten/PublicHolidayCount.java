package com.cloudwise.douc.customization.biz.model.heighten;

import lombok.Data;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/30
 */
@Data
public class PublicHolidayCount {
    private int total;
    private String dateStr;
    private String dayName;
}
