package com.cloudwise.douc.customization.biz.model.user;

import lombok.Data;

import java.io.Serializable;

/**
 * @author abell.wu
 */
@Data
public  class UserInfo implements Serializable {
    private String userId;
    private String userName;
    private String groupId;
    private String groupName;
}