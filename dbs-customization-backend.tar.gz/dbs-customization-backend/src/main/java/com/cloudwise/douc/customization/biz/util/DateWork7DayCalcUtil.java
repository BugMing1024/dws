package com.cloudwise.douc.customization.biz.util;

import cn.hutool.core.date.DateUtil;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

public class DateWork7DayCalcUtil {



    // 假设我们有一个方法可以从数据库中获取所有的节假日
    private static Set<LocalDate> getHolidaysFromDatabase(JdbcTemplate jdbcTemplate) {
        Set<LocalDate> holidays = new HashSet<>();

        String sql = "select freeze_date  from freeze_holidays ";
        Map<String, String> args = new HashMap<>();
        NamedParameterJdbcTemplate query = new NamedParameterJdbcTemplate(jdbcTemplate);

        query.query(sql, args, (RowMapper) (rs, rowNum) -> {
            String status = rs.getString("freeze_date");
            holidays.add(rs.getDate("freeze_date").toLocalDate());
            return status;
        });

//        LocalDate e = LocalDate.of(2024,1,27);
//        LocalDate e1 = LocalDate.of(2025,1,28);
//        holidays.add(e);
//        holidays.add(e1);
        return holidays;
    }

    public static LocalDate calculateNonWorkingDays(JdbcTemplate jdbcTemplate, LocalDate creationDate, int workingDaysToSkip) {
        Set<LocalDate> holidays = getHolidaysFromDatabase(jdbcTemplate);
        LocalDate currentDate = creationDate;
        int daysSkipped = 0;

        while (daysSkipped < workingDaysToSkip) {
            currentDate = currentDate.plusDays(1);
            if (isWorkingDay(currentDate, holidays)) {
                daysSkipped++;
            }
        }

        return currentDate;
    }

    private static boolean isWorkingDay(LocalDate date, Set<LocalDate> holidays) {
        // 判断是否为周末
        if (date.getDayOfWeek().getValue() == 6 || date.getDayOfWeek().getValue() == 7) {
            return false;
        }
        // 判断是否为节假日
        return !holidays.contains(date);
    }


    public static Date getLastDay(JdbcTemplate jdbcTemplate) {
        LocalDate creationDate = LocalDate.now();
        int nonWorkingDaysToSkip = 7;
        LocalDate resultDate = calculateNonWorkingDays(jdbcTemplate,creationDate, nonWorkingDaysToSkip);
        Date resultDateAsDate = Date.from(resultDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        return resultDateAsDate;
    }


    public static void main(String[] args) {
//        CreateCrRelationRacWorkUtils calculator = new CreateCrRelationRacWorkUtils();
//        LocalDate creationDate = LocalDate.now();
//        int nonWorkingDaysToSkip = 7;
//        LocalDate resultDate = calculateNonWorkingDays(jdbcTemplate, creationDate, nonWorkingDaysToSkip);
//        System.out.println("工单创建时间: " + creationDate);
//        System.out.println("延顺后的日期: " + resultDate);
//
//        // resultDate 转换成 new date();
//
//        // 将 LocalDate 转换为 Date
//        Date resultDateAsDate = Date.from(resultDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
//        System.out.println("延顺后的日期: " + DateUtil.format(resultDateAsDate, "yyyy-MM-dd"));

    }
}
