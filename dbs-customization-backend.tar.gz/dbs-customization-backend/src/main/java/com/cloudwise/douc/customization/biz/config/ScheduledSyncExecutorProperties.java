package com.cloudwise.douc.customization.biz.config;

import lombok.Data;

/**
 * 定时执行 Created on 2022-4-7.
 *
 * @author skiya
 */
@Data
public class ScheduledSyncExecutorProperties {
    
    /**
     * 默认 1h 执行一次
     */
    private String execIntervalCron = "0 0/60 * * * ?";
}
