package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;

import java.util.List;

/**
 * cr is new -> Project Cutover Signoff -> Service Monitoring at SNOC
 * @Author frank.zheng
 * @Date 2025-02-09
 */
public class CrNewPrjServiceMonitoringSNOCAnalysis extends CrNewCommSignoffAnalysis {

    public final static CrNewPrjServiceMonitoringSNOCAnalysis INSTANCE = new CrNewPrjServiceMonitoringSNOCAnalysis();


    /**
     * return userGroup email: PSG_DBSAPP_NOTIFY_SNOC
     */
    @Override
    protected List<UserInfo> getReceivers(MessageContext context) {
        return getUserByGroupCode(getDosmConfig().getEmailConfig().getCrNewPrjServiceMonitoringSNOCReceiverGroupName());
    }
}
