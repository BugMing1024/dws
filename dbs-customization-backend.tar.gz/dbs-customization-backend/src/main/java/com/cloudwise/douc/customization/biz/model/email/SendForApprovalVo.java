package com.cloudwise.douc.customization.biz.model.email;

import lombok.Data;

/**
 * @author ming.ma
 * @since 2025-01-16  14:39
 **/
@Data
public class SendForApprovalVo {
    private String workOrderId;
    private String nodeId;
    private String mdlDefKey;
    private String userId;
}
