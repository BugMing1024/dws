package com.cloudwise.douc.customization.biz.constant;


/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
public enum BusinessType {
    
    APPROVE_GROUP,
    
    IMPLEMENTER_GROUP,
    
    MDAPPROVE_GROUP,
    
    RELEASE_GROUP,
    
    CHANGE_GROUP,
    
    USER,
    
    TSOID;
}
