package com.cloudwise.douc.customization.common.config.xxl.model;

import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorBlockStrategyEnum;
import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorRouteStrategyEnum;
import com.cloudwise.douc.customization.common.config.xxl.enums.GlueTypeEnum;
import com.cloudwise.douc.customization.common.config.xxl.enums.MisfireStrategyEnum;
import com.cloudwise.douc.customization.common.config.xxl.enums.ScheduleTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * xxl-job info
 *
 * @author xuxueli  2016-1-12 18:25:49
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class XxlJobInfo {
    
    private Integer id;                // 主键ID
    
    private int jobGroup;        // 执行器主键ID
    
    private String jobDesc;
    
    private Date addTime;
    
    private Date updateTime;
    
    private String author;        // 负责人
    
    private String alarmEmail;    // 报警邮件
    
    private ScheduleTypeEnum scheduleType = ScheduleTypeEnum.CRON;            // 调度类型
    
    private String scheduleConf;            // 调度配置，值含义取决于调度类型
    
    private MisfireStrategyEnum misfireStrategy = MisfireStrategyEnum.DO_NOTHING;            // 调度过期策略
    
    private ExecutorRouteStrategyEnum executorRouteStrategy = ExecutorRouteStrategyEnum.ROUND;    // 执行器路由策略
    
    private String executorHandler;            // 执行器，任务Handler名称
    
    private String executorParam;            // 执行器，任务参数
    
    private ExecutorBlockStrategyEnum executorBlockStrategy = ExecutorBlockStrategyEnum.SERIAL_EXECUTION;    // 阻塞处理策略
    
    private int executorTimeout;            // 任务执行超时时间，单位秒
    
    private int executorFailRetryCount;        // 失败重试次数
    
    private GlueTypeEnum glueType = GlueTypeEnum.BEAN;        // GLUE类型#com.xxl.job.core.glue.GlueTypeEnum
    
    private String glueSource;        // GLUE源代码
    
    private String glueRemark;        // GLUE备注
    
    private Date glueUpdatetime;    // GLUE更新时间
    
    private String childJobId;        // 子任务ID，多个逗号分隔
    
    private int triggerStatus;        // 调度状态：0-停止，1-运行
    
    private long triggerLastTime;    // 上次调度时间
    
    private long triggerNextTime;    // 下次调度时间
    
    public void setDefault() {
        if (scheduleType == null) {
            scheduleType = ScheduleTypeEnum.CRON;            // 调度类型
        }
        if (misfireStrategy == null) {
            misfireStrategy = MisfireStrategyEnum.DO_NOTHING;            // 调度过期策略
        }
        if (executorRouteStrategy == null) {
            executorRouteStrategy = ExecutorRouteStrategyEnum.ROUND;    // 执行器路由策略
        }
        if (executorBlockStrategy == null) {
            executorBlockStrategy = ExecutorBlockStrategyEnum.SERIAL_EXECUTION;    // 阻塞处理策略
        }
        if (glueType == null) {
            glueType = GlueTypeEnum.BEAN;        // GLUE类型#com.xxl.job.core.glue.GlueTypeEnum
        }
    }
    
}
