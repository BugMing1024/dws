package com.cloudwise.douc.customization.biz.facade;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.facade.user.UserPage;
import com.cloudwise.douc.customization.biz.facade.user.UserRoleInfo;
import com.cloudwise.douc.dto.*;
import com.cloudwise.douc.dto.v3.common.PageResp;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  18:09
 **/
public interface UserService {
    
    /**
     * 根据用户ids获取用户基础信息列表 入参说明： accountId 必填 userId必填 ids必填
     */
    DubboCommonResp<List<UserInfo>> getUserListByIds(DubboIdsReq req);
    
    DubboCommonResp<List<UserRoleInfo>> getRoloInfosByUserId(DubboUserIdAccountIdRequest req);
    
    
    /**
     * 根据关键属性组合分页查询用户信息列表<该接口为模糊查询，性能较差除非必须使用模糊查询，慎用> 入参： accountId    必填 userId 必填 roleIds  角色id，将属于该角色下的所有用户查询出来 name 名称，模糊查询 alias  用户别名 精确查询
     * nameOrAlias  名称或者别名 模糊查询 mobile   手机号  精确查询 email  邮箱。 精确查询 status  用户状态：1启用 2停用 code: code 精确查寻 groupIds：将属于该用户组下的所有用户查询出来 currentPageNo
     * pageSize
     */
    DubboCommonResp<UserPage> getUserListByParam(DubboRpcQueryParams req);
    
    UserInfo getUserDetailInfoById(String userId, String accountId);

    /**
     * 根据用户别名集合获取用户基本信息列表
     * 入参说明：
     * accountId 必填
     * userId必填
     * useralias 必填
     */
    DubboCommonResp<List<UserInfo>> getUsersByAliasList(DubboUserAliasReq req);


    PageResp<com.cloudwise.douc.dto.v3.common.UserInfo> getUserByCondition(UserConditionReq req);
    
}
