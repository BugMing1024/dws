package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUnit;
import com.cloudwise.douc.customization.biz.constant.EmailTemplateConstants;
import com.cloudwise.douc.customization.biz.enums.EmailApproveEnum;
import com.cloudwise.douc.customization.biz.facade.DbsFacade;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.ReadEmail;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageReadRecord;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageReadRecordService;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.biz.service.email.EmailTicketingJobService;
import com.cloudwise.douc.customization.biz.service.msg.email.EmailChannelService;
import com.cloudwise.douc.customization.biz.service.msg.model.bean.ApproveParam;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.config.email.EmailConfig;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.dto.DubboChannelRealConfigResponse;
import com.cloudwise.email.api.ReadEmailApi;
import com.cloudwise.email.model.dto.EmailMessageDetail;
import com.cloudwise.email.model.dto.SimpleEmailMessage;
import com.cloudwise.email.util.ReadEmailUtils;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;

/**
 * @author ming.ma
 * @since 2024-12-05  10:08
 **/
@Slf4j
@Service
public class EmailTicketingJobServiceImpl implements EmailTicketingJobService {

    public static final String CUSTOM_EMAIL_LOCK_KEY = "CUSTOM_DOSM_EMAIL_LOCK_KEY_";

    private final ExecutorService executorService = Executors.newFixedThreadPool(5);

    @Autowired
    DosmConfig dosmConfig;

    @Autowired
    EmailConfig emailConfig;

    @Autowired
    EmailChannelService emailChannelService;

    @Autowired
    DosmCustomService dosmCustomService;

    @Autowired
    CustomMessageReadRecordService customMessageReadRecordService;
    @Autowired
    CustomMessageRecordService customMessageRecordService;


    @Resource
    private RedissonClient redissonClient;

    @Autowired
    private DbsFacade dbsFacade;

    @Override
    public void readEmail(String param) {
        ArrayList<ReadEmail> readEmails = Lists.newArrayList();
        dbsFacade.buildReadEmails(readEmails);
        log.info("读取邮件数量:{}", readEmails.size());
        if (CollUtil.isEmpty(readEmails)) {
            return;
        }
        List<String> emailIds = new ArrayList<>();
        List<CustomMessageReadRecord> list = new ArrayList<>();
        for (ReadEmail readEmail : readEmails) {
            String id = readEmail.getId();
            CustomMessageReadRecord customMessageReadRecord = customMessageReadRecordService.getCustomMessageReadRecordByMessageId(id);
            if (customMessageReadRecord != null) {
                continue;
            }
            String sender = readEmail.getFrom();
            String subject = readEmail.getSubject();

            EmailApproveEnum approveStatus = EmailAnalysisUtil.getApproveStatus(subject);
            ApproveParam approveParam = EmailAnalysisUtil.getApproveParam(subject);
            if (approveStatus == null || approveParam == null) {
                log.info("邮件标题不符合规范:{}", subject);
                continue;
            }
            approveParam.setStatus(approveStatus);

            String body = readEmail.getBody();
            boolean isApprove = dosmCustomService.emailApprove(sender, subject, approveParam, body);
            //只有建单完成才标记为已读
            if (isApprove) {
                emailIds.add(id);
                CustomMessageReadRecord insertReadRecord = CustomMessageReadRecord.buildInsertInfo(subject, body, id);
                readEmail.setAttachment(null);
                insertReadRecord.setOther(JsonUtils.toJsonStr(readEmail));
                list.add(customMessageReadRecord);
            }
            if (!isApprove) {
                // 审批异常 发送失败消息
                String customMessageRecordId = approveParam.getMsgRecordId();
                CustomMessageRecord record = customMessageRecordService.getById(customMessageRecordId);
                String messageContext = record.getMessageContext();
                MessageContext failMessageContext = JsonUtils.parseObject(messageContext, MessageContext.class);
                Map<String, String> publicFields = failMessageContext.getPublicFields();
                if(publicFields == null) {
                    publicFields = new HashMap<>();
                }
                publicFields.put(EmailTemplateConstants.EMAIL_APPROVAL_EXCEPTION, "true");
                failMessageContext.setPublicFields(publicFields);
                dosmCustomService.sendMessage(failMessageContext);
            }

            customMessageReadRecordService.insertRecords(list);
            if (CollUtil.isNotEmpty(emailIds)) {
                log.info("邮件标记已读数量:{}", emailIds.size());
                dbsFacade.markReadEmails(emailIds);
            }
        }
    }

    @Override
    public void handle(String param) {
        String filePath = getFilePath();
        log.info("邮件缓存目录:{}", filePath);
        File file = new File(filePath);
        if (!file.exists()) {
            log.info("文件目录开始创建");
            file.mkdirs();
        }
        log.info("开始处理渠道信息");
        DubboChannelRealConfigResponse channelConfig = emailChannelService.getChannelConfigById(Long.valueOf(dosmConfig.getChannelId()),
                dosmConfig.getAccountId());
        log.info("获取渠道信息：{}", JsonUtils.toJsonStr(channelConfig));

        if (channelConfig == null || !Objects.equals(channelConfig.getStatus(), Constants.CHANEL_OPEN)) {
            log.info("渠道信息为空 ，channelId :{}", dosmConfig.getChannelId());
        }
        batchEmailMessage(file, channelConfig);

    }

    private String getFilePath() {
        String path = "";
        String cwTmpPath = System.getProperty("cwTmpPath");
        if (StringUtils.isNotEmpty(cwTmpPath)) {
            path = cwTmpPath + "/" + "email";
        } else {
            String cwDataPath = System.getProperty("cwDataPath");
            path = cwDataPath + "/" + "email";
        }
        log.info("临时邮件保存路径:{}", path);
        return path;
    }

    private void batchEmailMessage(File file, DubboChannelRealConfigResponse channelConfig) {
        List<SimpleEmailMessage> inboxEmails = new ArrayList<>();
        log.info("开始处理渠道信息：{}", JsonUtils.toJsonStr(channelConfig));

        //不自动关闭资源
        Map<String, String> fields = channelConfig.getFields();
        fields.put("close_folder", "false");
        ReadEmailApi handler = ReadEmailUtils.init(fields);
        Future<List<SimpleEmailMessage>> completableFuture = null;
        Future<EmailMessageDetail> completableDatailFuture = null;

        try {
            //开启资源
            handler.startResource();
            long startTime = Timestamp.valueOf(LocalDate.now().atStartOfDay()).getTime() - DateUnit.DAY.getMillis() * emailConfig.getTimeInterval();
            log.info("获取邮件开始时间：{},收件箱近当天邮件{}", startTime, JsonUtils.toJsonStr(channelConfig));

            completableFuture = getInboxEmailsAsync(handler, startTime, -1, emailConfig.getCount(), 2);
            inboxEmails = completableFuture.get(emailConfig.getTimeout(), TimeUnit.MINUTES);
            log.info("获取邮件结束数量：{}", inboxEmails.size());
            if (CollUtil.isEmpty(inboxEmails)) {
                log.info("获取邮件为空，不处理");
                return;
            }

            log.info("开始处理批量邮件:{}", inboxEmails.size());
            for (SimpleEmailMessage simpleEmailMessage : inboxEmails) {
                String emailId = simpleEmailMessage.getId();
                log.info("邮件Id:{}", emailId);

                CustomMessageReadRecord customMessageReadRecord = customMessageReadRecordService.getCustomMessageReadRecordByMessageId(emailId);
                if (customMessageReadRecord != null) {
                    continue;
                }
                //根据邮件查询发件人
                String sender = simpleEmailMessage.getSender();
                log.info("邮件发送人:{}", sender);

                String subject = simpleEmailMessage.getSubject();
                EmailApproveEnum approveStatus = EmailAnalysisUtil.getApproveStatus(subject);
                ApproveParam approveParam = EmailAnalysisUtil.getApproveParam(subject);
                if (approveStatus == null || approveParam == null) {
                    log.info("邮件标题不符合规范:{}", subject);
                    continue;
                }

                approveParam.setStatus(approveStatus);

                //抄送
                List<String> ccRecipientsAddress = simpleEmailMessage.getCcRecipientsAddress();
                log.info("邮件抄送人:{}", ccRecipientsAddress);

                String name = CUSTOM_EMAIL_LOCK_KEY + emailId;
                log.info("邮件审批锁名称：{}", name);
                RLock lock = redissonClient.getLock(name);
                if (lock.tryLock(emailConfig.getWaitTime(), emailConfig.getTimeout(), TimeUnit.MINUTES)) {
                    log.info("获取锁成功，开始处理邮件:{}", name);
                    log.info("成功获取锁，线程ID: {}", Thread.currentThread().getId());
                    try {
                        completableDatailFuture = getDetailWithAttachmentAsync(handler, emailId, file);
                        EmailMessageDetail detail = completableDatailFuture.get(emailConfig.getTimeout(), TimeUnit.MINUTES);
                        if (detail == null) {
                            log.info("邮件详情下载为空，暂不处理");
                            continue;
                        }
                        log.info("获取邮件内容:{}", detail.getBody());
                        String body = detail.getBody();
                        log.info("Start email approve");
                        boolean isApprove = dosmCustomService.emailApprove(sender, subject, approveParam, body);
                        //只有建单完成才标记为已读
                        if (isApprove) {
                            String recordId = customMessageReadRecordService.insertRecord(CustomMessageReadRecord.buildInsertInfo(subject, body, emailId));
                            boolean marked = handler.markEmailAsReadById(simpleEmailMessage.getId());
                            log.info("邮件标记为已读：{},recordId:{}", marked, recordId);
                        }
                    } catch (Exception e) {
                        if (completableDatailFuture != null && !completableDatailFuture.isCancelled()) {
                            completableDatailFuture.cancel(true);
                        }
                        log.error("邮件审批异常", e);
                    } finally {
                        if (lock.isHeldByCurrentThread()) {
                            lock.unlock();
                        } else {
                            log.warn("邮件审批解锁失败：当前线程未持有锁, thread-id: {}", Thread.currentThread().getId());
                        }
                    }
                }
            }
        } catch (TimeoutException e) {
            log.error("邮件拉取超时", e);
            if (!completableFuture.isCancelled()) {
                log.info("开始强制关闭线程");
                completableFuture.cancel(true);
            }
        } catch (Exception e) {
            log.info("获取邮件异常：渠道信息：{},{}", JsonUtils.toJsonStr(channelConfig), e);
        } finally {
            log.info("关闭资源");
            handler.stopResource();
        }
    }

    /**
     * 获取邮件列表 线程池方式
     *
     * @param handler
     * @param startTime
     * @param endTime
     * @param count
     * @param flags
     * @return
     */
    public Future<List<SimpleEmailMessage>> getInboxEmailsAsync(ReadEmailApi handler, long startTime, int endTime, int count, int flags) {
        return executorService.submit(() -> {
            log.info("开始拉起邮件列表:{}", startTime);
            List<SimpleEmailMessage> inboxEmails = handler.getInboxEmails(startTime, endTime, count, flags);
            log.info("拉起邮件列表结束:{}", JsonUtils.toJsonStr(inboxEmails));
            if (CollUtil.isNotEmpty(inboxEmails)) {
                return inboxEmails;
            } else {
                return new ArrayList<>();
            }
        });
    }

    /**
     * 获取邮件内容 线程池方式
     *
     * @param handler
     * @return
     */
    public Future<EmailMessageDetail> getDetailWithAttachmentAsync(ReadEmailApi handler, String id, File file) {
        return executorService.submit(() -> {
            log.info("开始拉邮件详情:{}", id);
            EmailMessageDetail detailWithAttachment = handler.getDetailWithAttachment(id, file);
            log.info("拉起邮件列表结束:{}", JsonUtils.toJsonStr(detailWithAttachment));
            return detailWithAttachment;
        });
    }
}
