package com.cloudwise.douc.customization.biz.model.email.dosm;

/**
 * 自动通过跟随节点类型
 *
 * @author jon.lee
 * @since 2022-05-14 16:08
 **/
public enum AutoPassFollowTypeEnum {
    /**
     * 相邻节点相同审批人
     */
    NEXT_TO,
    /**
     * 历史节点相同审批人
     */
    HISTORY
    
}
