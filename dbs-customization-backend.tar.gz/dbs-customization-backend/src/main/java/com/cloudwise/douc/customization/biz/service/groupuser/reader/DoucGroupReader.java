package com.cloudwise.douc.customization.biz.service.groupuser.reader;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.constant.BusinessType;
import com.cloudwise.douc.customization.biz.facade.DbsFacade;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsRespCommonGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.ImplementerGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.MdApproveGroup;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.model.GroupAndUserInfo;
import com.cloudwise.douc.customization.common.util.FieldComparator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class DoucGroupReader implements Reader<DbsGroupInfo> {
    
    private final DoucProperties doucProperties;
    
    private final DbsMultiReader dbsMultiReader;
    
    private final DbsFacade dbsFacade;
    
    private final DbsProperties dbsProperties;
    
    
    @Override
    public List<DbsGroupInfo> read(Object... param) {
        if (param == null || param.length == 0) {
            return Collections.emptyList();
        }
        GroupAndUserInfo read = dbsMultiReader.read((List<BusinessType>) param[0]);
        if (read == null) {
            return Collections.emptyList();
        }
        return build(read.getApproveGroups(), read.getImplementerGroups(), read.getMdApproveGroups(), read.getReleaseGroups(),
                read.getChangeGroups());
    }
    
    private List<DbsGroupInfo> build(List<DbsRespCommonGroup> approveGroups, List<ImplementerGroup> implementerGroups,
            List<MdApproveGroup> mdApproveGroups, List<DbsRespCommonGroup> releaseGroups, List<DbsRespCommonGroup> changeGroups) {
        List<DbsGroupInfo> result = new ArrayList<>();
        Map<String, DbsGroupInfo> code2Info = new HashMap<>();
        // 把三个常见的单独提取
        buildCommonResp(approveGroups, code2Info, result, dbsProperties.getApprover().getGroupCode());
        buildCommonResp(releaseGroups, code2Info, result, dbsProperties.getRelease().getGroupCode());
        buildCommonResp(changeGroups, code2Info, result, dbsProperties.getChangeTeam().getGroupCode());
        if (CollUtil.isNotEmpty(implementerGroups)) {
            String[] dbsGroupField2 = new String[] {"name", "code", "appCode", "lob", "country"};
            String[] implementGroupField = new String[] {"Group", "Group", "Appcode", "GroupLOB", "GroupCountry"};
            implementerGroups.forEach(each -> {
                // 二级组
                String codeSecondLevel = each.getGroup();
                // 三级组
                String codeThirdLevel = each.getGroup() + "-" + each.getGroupLOB() + "-" + each.getGroupCountry();
                if (StrUtil.isBlank(codeSecondLevel)) {
                    log.warn("implementerGroup:{} found empty group", each);
                    return;
                }
                // 三级组已经有了的话，那就无需填充了
                if (code2Info.containsKey(codeThirdLevel)) {
                    DbsGroupInfo dbsGroupInfo = code2Info.get(codeThirdLevel);
                    List<String> addUserCodes = dbsGroupInfo.getAddUserCodes();
                    if (StrUtil.isNotBlank(each.getMemberLogin())) {
                        addUserCodes.add(each.getMemberLogin());
                    }
                    if (!FieldComparator.compareFields(dbsGroupInfo, each, dbsGroupField2, implementGroupField)) {
                        log.warn("implementGroup:{} found abnormal data, data1:{}, data2:{}", codeThirdLevel, dbsGroupInfo, each);
                    }
                    if (Boolean.TRUE.equals(doucProperties.getGroupIncludeUser()) && StrUtil.isNotBlank(each.getMemberLogin())) {
                        code2Info.get(codeSecondLevel).getAddUserCodes().add(each.getMemberLogin());
                    }
                    return;
                }
                // 二级组如果没填充过，那就填充一下
                if (!code2Info.containsKey(codeSecondLevel)) {
                    DbsGroupInfo dbsGroupInfo = new DbsGroupInfo();
                    // 二级组，不再填充lob、country，但是填充
                    //                    dbsGroupInfo.setLob(each.getGroupLOB());
                    //                    dbsGroupInfo.setCountry(each.getGroupCountry());
                    dbsGroupInfo.setGroupRole(each.getGroupRole());
                    dbsGroupInfo.setOwnerCode(each.getGroupOwnerLogin());
                    dbsGroupInfo.setCode(each.getGroup());
                    dbsGroupInfo.setName(each.getGroup());
                    dbsGroupInfo.setHasLOBCountryMapping("true");
                    dbsGroupInfo.setDescription(each.getGroupDescription());
                    dbsGroupInfo.setAppCode(each.getAppcode());
                    ArrayList<String> addUserCodes = new ArrayList<>();
                    dbsGroupInfo.setAddUserCodes(addUserCodes);
                    dbsGroupInfo.setParentCode(dbsProperties.getImplementer().getGroupCode());
                    //            dbsGroupInfo.setDescription(each.getGroupDescription());
                    code2Info.put(codeSecondLevel, dbsGroupInfo);
                    result.add(dbsGroupInfo);
                }
                if (Boolean.TRUE.equals(doucProperties.getGroupIncludeUser()) && StrUtil.isNotBlank(each.getMemberLogin())) {
                    code2Info.get(codeSecondLevel).getAddUserCodes().add(each.getMemberLogin());
                }
                // 三级组上面已经判断过确定没填充了
                DbsGroupInfo dbsGroupInfo = new DbsGroupInfo();
                dbsGroupInfo.setCode(codeThirdLevel);
                dbsGroupInfo.setName(each.getGroupLOB() + "-" + each.getGroupCountry());
                dbsGroupInfo.setLob(each.getGroupLOB());
                dbsGroupInfo.setCountry(each.getGroupCountry());
                dbsGroupInfo.setHasLOBCountryMapping("false");
                dbsGroupInfo.setParentCode(each.getGroup(), dbsProperties.getImplementer().getGroupCode());
                ArrayList<String> addUserCodes = new ArrayList<>();
                dbsGroupInfo.setAddUserCodes(addUserCodes);
                if (StrUtil.isNotBlank(each.getMemberLogin())) {
                    addUserCodes.add(each.getMemberLogin());
                }
                code2Info.put(codeThirdLevel, dbsGroupInfo);
                result.add(dbsGroupInfo);
            });
        }
        if (CollUtil.isNotEmpty(mdApproveGroups)) {
            String[] dbsGroupField3 = new String[] {"name", "code", "lob", "country"};
            String[] mdApproveGroupField = new String[] {"GroupName", "GroupName", "LOB", "Country"};
            mdApproveGroups.forEach(each -> {
                // 二级组
                String codeSecondLevel = each.getGroupName();
                // 三级组
                String codeThirdLevel = each.getGroupName() + "-" + each.getLOB() + "-" + each.getCountry();
                if (StrUtil.isBlank(codeSecondLevel)) {
                    log.warn("mdApproveGroup:{} found empty group", each);
                    return;
                }
                if (code2Info.containsKey(codeThirdLevel)) {
                    DbsGroupInfo dbsGroupInfo = code2Info.get(codeThirdLevel);
                    List<String> addUserCodes = dbsGroupInfo.getAddUserCodes();
                    if (StrUtil.isNotBlank(each.getLogin())) {
                        addUserCodes.add(each.getLogin());
                    }
                    if (!FieldComparator.compareFields(dbsGroupInfo, each, dbsGroupField3, mdApproveGroupField)) {
                        log.warn("mdApproveGroup:{} found abnormal data, data1:{}, data2:{}", codeThirdLevel, dbsGroupInfo, each);
                    }
                    // rank补充
                    dbsGroupInfo.addRank(each.getRank());
                    code2Info.get(codeSecondLevel).addRank(each.getRank());
                    if (Boolean.TRUE.equals(doucProperties.getGroupIncludeUser()) && StrUtil.isNotBlank(each.getLogin())) {
                        code2Info.get(codeSecondLevel).getAddUserCodes().add(each.getLogin());
                    }
                    return;
                }
                // 二级组如果没填充过，那就填充一下
                if (!code2Info.containsKey(codeSecondLevel)) {
                    DbsGroupInfo dbsGroupInfo = new DbsGroupInfo();
                    dbsGroupInfo.addRank(each.getRank());
                    dbsGroupInfo.setCode(each.getGroupName());
                    dbsGroupInfo.setName(each.getGroupName());
                    // 二级组，不再填充lob、country，但是填充
                    //                    dbsGroupInfo.setLob(each.getLOB());
                    //                    dbsGroupInfo.setCountry(each.getCountry());
                    ArrayList<String> addUserCodes = new ArrayList<>();
                    dbsGroupInfo.setAddUserCodes(addUserCodes);
                    dbsGroupInfo.setHasLOBCountryMapping("true");
                    dbsGroupInfo.setParentCode(dbsProperties.getMdApprover().getGroupCode());
                    //            dbsGroupInfo.setDescription(each.getGroupDescription());
                    code2Info.put(codeSecondLevel, dbsGroupInfo);
                    result.add(dbsGroupInfo);
                } else {
                    code2Info.get(codeSecondLevel).addRank(each.getRank());
                }
                if (Boolean.TRUE.equals(doucProperties.getGroupIncludeUser()) && StrUtil.isNotBlank(each.getLogin())) {
                    code2Info.get(codeSecondLevel).getAddUserCodes().add(each.getLogin());
                }
                // 三级组上面已经判断过确定没填充了
                DbsGroupInfo dbsGroupInfo = new DbsGroupInfo();
                dbsGroupInfo.setCode(codeThirdLevel);
                dbsGroupInfo.setName(each.getLOB() + "-" + each.getCountry());
                dbsGroupInfo.setLob(each.getLOB());
                dbsGroupInfo.setCountry(each.getCountry());
                ArrayList<String> addUserCodes = new ArrayList<>();
                dbsGroupInfo.setAddUserCodes(addUserCodes);
                if (StrUtil.isNotBlank(each.getLogin())) {
                    addUserCodes.add(each.getLogin());
                }
                dbsGroupInfo.addRank(each.getRank());
                dbsGroupInfo.setHasLOBCountryMapping("false");
                dbsGroupInfo.setParentCode(each.getGroupName(), dbsProperties.getMdApprover().getGroupCode());
                //            dbsGroupInfo.setDescription(each.getGroupDescription());
                code2Info.put(codeThirdLevel, dbsGroupInfo);
                result.add(dbsGroupInfo);
            });
        }
        dbsFacade.buildDetail(result);
        dbsFacade.buildSignoff(result);
        result.forEach(DbsGroupInfo::finish);
        return result;
    }
    
    private void buildCommonResp(List<DbsRespCommonGroup> approveGroups, Map<String, DbsGroupInfo> code2Info, List<DbsGroupInfo> result,
            String type) {
        String[] dbsGroupField = new String[] {"name", "code", "ownerCode", "lob", "country"};
        String[] commonsGroupField = new String[] {"Group", "Group", "GroupOwner", "GroupLOB", "GroupCountry"};
        if (CollUtil.isNotEmpty(approveGroups)) {
            approveGroups.forEach(each -> {
                // 二级组
                String codeSecondLevel = each.getGroup();
                // 三级组
                String codeThirdLevel = each.getGroup() + "-" + each.getGroupLOB() + "-" + each.getGroupCountry();
                if (StrUtil.isBlank(codeSecondLevel)) {
                    log.warn("{}:{} found empty group", type, each);
                    return;
                }
                // 三级组，需要加上人
                if (code2Info.containsKey(codeThirdLevel)) {
                    DbsGroupInfo dbsGroupInfo = code2Info.get(codeThirdLevel);
                    List<String> addUserCodes = dbsGroupInfo.getAddUserCodes();
                    if (StrUtil.isNotBlank(each.getMemberLogin())) {
                        addUserCodes.add(each.getMemberLogin());
                    }
                    if (!FieldComparator.compareFields(dbsGroupInfo, each, dbsGroupField, commonsGroupField)) {
                        log.warn("{}:{} found abnormal data, data1:{}, data2:{}", type, codeThirdLevel, dbsGroupInfo, each);
                    }
                    if (Boolean.TRUE.equals(doucProperties.getGroupIncludeUser()) && StrUtil.isNotBlank(each.getMemberLogin())) {
                        code2Info.get(codeSecondLevel).getAddUserCodes().add(each.getMemberLogin());
                    }
                    return;
                }
                // 二级组如果没填充过，那就填充一下
                if (!code2Info.containsKey(codeSecondLevel)) {
                    DbsGroupInfo dbsGroupInfo = new DbsGroupInfo();
                    dbsGroupInfo.setCode(each.getGroup());
                    dbsGroupInfo.setName(each.getGroup());
                    dbsGroupInfo.setOwnerCode(each.getGroupOwnerLogin());
                    // 二级组，不再填充lob、country，但是填充
                    //                    dbsGroupInfo.setLob(each.getGroupLOB());
                    //                    dbsGroupInfo.setCountry(each.getGroupCountry());
                    dbsGroupInfo.setHasLOBCountryMapping("true");
                    dbsGroupInfo.setGroupRole(each.getGroupRole());
                    String groupCode = type;
                    dbsGroupInfo.setParentCode(groupCode);
                    dbsGroupInfo.setDescription(each.getGroupDescription());
                    ArrayList<String> addUserCodes = new ArrayList<>();
                    dbsGroupInfo.setAddUserCodes(addUserCodes);
                    code2Info.put(codeSecondLevel, dbsGroupInfo);
                    result.add(dbsGroupInfo);
                }
                if (Boolean.TRUE.equals(doucProperties.getGroupIncludeUser()) && StrUtil.isNotBlank(each.getMemberLogin())) {
                    code2Info.get(codeSecondLevel).getAddUserCodes().add(each.getMemberLogin());
                }
                // 三级组上面已经判断过确定没填充了
                DbsGroupInfo dbsGroupInfo = new DbsGroupInfo();
                dbsGroupInfo.setCode(codeThirdLevel);
                dbsGroupInfo.setName(each.getGroupLOB() + "-" + each.getGroupCountry());
                dbsGroupInfo.setLob(each.getGroupLOB());
                dbsGroupInfo.setCountry(each.getGroupCountry());
                dbsGroupInfo.setHasLOBCountryMapping("false");
                dbsGroupInfo.setParentCode(each.getGroup(), type);
                ArrayList<String> addUserCodes = new ArrayList<>();
                dbsGroupInfo.setAddUserCodes(addUserCodes);
                if (StrUtil.isNotBlank(each.getMemberLogin())) {
                    addUserCodes.add(each.getMemberLogin());
                }
                code2Info.put(codeThirdLevel, dbsGroupInfo);
                result.add(dbsGroupInfo);
            });
        }
    }
}
