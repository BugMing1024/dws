package com.cloudwise.douc.customization.biz.model.email;

import lombok.Data;

/**
 * @author ming.ma
 * @since 2024-12-27  16:37
 **/
@Data
public class UserApproveRecord {

    private String approver;

    private String approverId;

    private String status;

    private String reason;

    private String reasonLable;

    private String approveMsg;

    private Long updateTime;


}
