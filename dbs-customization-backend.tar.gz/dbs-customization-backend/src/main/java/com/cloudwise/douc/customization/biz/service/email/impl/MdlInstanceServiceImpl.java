package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloudwise.douc.customization.biz.dao.ActHiTaskMapper;
import com.cloudwise.douc.customization.biz.dao.HeightenMapper;
import com.cloudwise.douc.customization.biz.dao.MdlInstanceMapper;
import com.cloudwise.douc.customization.biz.dao.MdlInstanceTableDataMapper;
import com.cloudwise.douc.customization.biz.model.table.ActHiTask;
import com.cloudwise.douc.customization.biz.model.table.MdlInstance;
import com.cloudwise.douc.customization.biz.service.email.MdlInstanceService;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.customization.biz.model.heighten.PublicHolidayCount;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/23
 */
@Slf4j
@Service
public class MdlInstanceServiceImpl implements MdlInstanceService {
    @Resource
    private MdlInstanceMapper mdlInstanceMapper;
    @Resource
    private ActHiTaskMapper actHiTaskMapper;
    @Resource
    private HeightenMapper heightenMapper;

    @Resource
    private DosmConfig dosmConfig;
    @Resource
    private MdlInstanceTableDataMapper mdlInstanceTableDataMapper;
    @Value("${rest.http.dosm:10.0.16.105:18271}")
    private String dosmUrl;

    @Override
    public void updateMdlInstance2ClosedCancelOnOne() {
        PublicHolidayCount publicHoliday = heightenMapper.isPublicHoliday(0);
        if (publicHoliday.getTotal() > 0) {
            log.info("updateMdlInstance2ClosedCancelOnFive cancel when today is public holiday");
            return;
        }
        List<MdlInstance> mdlInstances = mdlInstanceMapper.selectRunningList();
        for (MdlInstance mdlInstance : mdlInstances) {
            boolean isNeedRollback = false;
            boolean isNeedUpdateForm = false;
            Object data = mdlInstance.getFormData();
            JsonNode formData = JsonUtils.toJsonNode(data);
            String crStatus = formData.get("crStatus_value").asText();
            String changeTypeValue = formData.get("changeType_value").asText();
            if (changeTypeValue.equals("Heighten") || changeTypeValue.equals("Heighten App")) {
                continue;
            }

            if (crStatus.equals("Open")) {
                boolean isL15 = isL15(mdlInstance, formData);
                if (isL15) {
                    continue;
                }
                JsonNode changeScheduleStartEndTime = formData.get("ChangeSchedule_StartEndTime");
                JsonNode startDate = changeScheduleStartEndTime.get("startDate");
                long startDateLong = startDate.asLong();
                Date nowDate = new Date();
                DateTime twoClock = DateUtil.date(nowDate).setField(DateField.HOUR_OF_DAY, 14)
                        .setField(DateField.MINUTE, 0)
                        .setField(DateField.SECOND, 0)
                        .setField(DateField.MILLISECOND, 0);
                DateTime fiveClock = DateUtil.date(nowDate).setField(DateField.HOUR_OF_DAY, 17)
                        .setField(DateField.MINUTE, 59)
                        .setField(DateField.SECOND, 59)
                        .setField(DateField.MILLISECOND, 999);
                //如果计划开始时间处于当天的
                if (startDateLong <= twoClock.getTime() && startDateLong >= fiveClock.getTime()) {
                    isNeedRollback = true;

                }
            }
//            else if (crStatus.equals("Rejected")) {
//                //证明已经在创建节点了，只需要更新表单即可
//                isNeedUpdateForm = true;
//            }
            handleRollbackAndUpdate(mdlInstance, isNeedRollback, isNeedUpdateForm);
        }
    }

    @Override
    public void updateMdlInstance2ClosedCancelOnFive() {

        PublicHolidayCount publicHoliday = heightenMapper.isPublicHoliday(0);
        if (publicHoliday.getTotal() > 0) {
            log.info("updateMdlInstance2ClosedCancelOnFive cancel when today is public holiday");
            return;
        }

        int count = 1;
        int nextFlag = 1;
        String nextDayDate = null;
        String nextDayName = null;
        while (nextFlag > 0) {
            PublicHolidayCount holiday = heightenMapper.isPublicHoliday(count);
            nextFlag = holiday.getTotal();
            nextDayDate = holiday.getDateStr();
            nextDayName = holiday.getDayName();
            if (("Friday").equals(holiday.getDayName()) && holiday.getTotal() == 1) {
                count++;
            }

            if (("Sunday").equals(holiday.getDayName()) || ("Saturday").equals(holiday.getDayName())) {
                nextFlag = 1;
            }
            count++;
        }


        List<MdlInstance> mdlInstances = mdlInstanceMapper.selectRunningList();
        for (MdlInstance mdlInstance : mdlInstances) {
            boolean isNeedRollback = false;
            boolean isNeedUpdateForm = false;
            Object data = mdlInstance.getFormData();
            JsonNode formData = com.cloudwise.dosm.api.bean.utils.JsonUtils.parseJsonNode(data);
            if (!formData.has("crStatus_value") || !formData.has("changeType_value") || !formData.has("ChangeSchedule_StartEndTime")) {
                continue;
            }
            String crStatus = formData.get("crStatus_value").asText();
            if (crStatus.equals("Open")) {
                boolean isL15 = isL15(mdlInstance, formData);
                if (isL15) {
                    continue;
                }
                JsonNode changeScheduleStartEndTime = formData.get("ChangeSchedule_StartEndTime");
                JsonNode startDate = changeScheduleStartEndTime.get("startDate");
                long startDateLong = startDate.asLong();
                Date nowDate = new Date();
                DateTime startTime = DateUtil.date(nowDate).setField(DateField.HOUR_OF_DAY, 18)
                        .setField(DateField.MINUTE, 0)
                        .setField(DateField.SECOND, 0)
                        .setField(DateField.MILLISECOND, 0);
                DateTime endTime = DateUtil.parseDate(nextDayDate).setField(DateField.HOUR_OF_DAY, 13)
                        .setField(DateField.MINUTE, 59)
                        .setField(DateField.SECOND, 59)
                        .setField(DateField.MILLISECOND, 999);
                if (startDateLong < startTime.getTime() && startDateLong >= endTime.getTime()) {
                    isNeedRollback = true;
                }
            }
            handleRollbackAndUpdate(mdlInstance, isNeedRollback, isNeedUpdateForm);
        }
    }

    private void handleRollbackAndUpdate(MdlInstance mdlInstance, boolean isNeedRollback, boolean isNeedUpdateForm) {
        if (isNeedRollback) {
            HttpRequest post = HttpUtil.createPost(dosmUrl + "/api/v2/open/form/callback");
            post.header("accountId", "110");
            post.header("topAccountId", "110");
            //TODO
            post.header("userId", "2");
            post.contentType("application/json");
            ObjectNode objectNode = JsonUtils.createObjectNode();
            objectNode.put("workOrderId", mdlInstance.getId());
            objectNode.put("remark", "System auto closed cancel");
            post.body(JsonUtils.toJsonValueString(objectNode));
            try (HttpResponse execute = post.execute()) {
                log.info("handleRollbackAndUpdate:bizkey:{},result:{}", mdlInstance.getBizKey(), execute.body());
            } catch (Exception e) {
                log.error("System auto closed cancel error:{}", e.getMessage(), e);
            }
        } else if (isNeedUpdateForm) {
            Object data = mdlInstance.getFormData();
            ObjectNode formData = (ObjectNode) com.cloudwise.dosm.api.bean.utils.JsonUtils.parseJsonNode(data);
            //TODO
            formData.put("crStatus", "");
            formData.put("crStatus_value", "Closed Cancel");
            mdlInstance.setFormData(JsonUtils.toJsonValueString(formData));
            mdlInstanceMapper.updateById(mdlInstance);
        }
    }

    private boolean isL15(MdlInstance mdlInstance, JsonNode formData) {
        JsonNode changeTypeValue = formData.get("changeType_value");
        String changeTypeValueText = changeTypeValue.asText();
        if (StrUtil.equalsAny(changeTypeValueText, "ECR", "Standard", "Standard-Annual", "Automated")) {
            return true;
        }
//
//        JsonNode changeGroupValue = formData.get("changeGroup_value");
//        String changeGroupValueText = changeGroupValue.asText();
//
//        if (StrUtil.equalsAny(changeGroupValueText, "Project Cutover Technical","Project Cutover Business","Project Cutover Technical & Business")) {
//            return true;
//        }
//
//        JsonNode crClassificationValue = formData.get("crClassification_value");
//        JsonNode appResiliencyClassificationValue = formData.get("appResiliencyClassification_value");
//        JsonNode changeCategory = formData.get("changeCategory");
//        String changeCategoryText = changeCategory.asText();
//        String appResiliencyClassificationValueText = appResiliencyClassificationValue.asText();
//        String crClassificationValueText = crClassificationValue.asText();
//        if (!(StrUtil.equals(crClassificationValueText, "Managed") && StrUtil.equals(appResiliencyClassificationValueText, "Green"))) {
//            return StrUtil.equals(crClassificationValueText, "Heightened") || StrUtil.equals(changeCategoryText, "High");
//        }

        List<ActHiTask> actHiTasks = actHiTaskMapper.selectList(Wrappers.lambdaQuery(ActHiTask.class)
                .eq(ActHiTask::getProcInstId_, mdlInstance.getProcessInstanceId())
        );
        long l15Count = actHiTasks.stream().filter(item -> item.getTaskDefKey().equals(dosmConfig.getCloseCancel().getCmNodeId())).count();
        if (actHiTasks.size() == 1 && l15Count == 1) {
            long count = actHiTasks.stream().filter(item -> item.getEndTime_() == null).count();
            return count != 0;
        }
        return false;
    }

    @Override
    public List<MdlInstance> getBizKeyFromCRStatusAndTime(Map<String, Object> map) {

        return mdlInstanceMapper.getBizKeyFromCRStatusAndTime(map);
    }
}

