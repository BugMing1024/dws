package com.cloudwise.douc.customization.biz.service.msg;

import java.util.concurrent.CompletableFuture;

/**
 * @author ming.ma
 * @since 2024-12-04  14:44
 **/
public interface MessageSender<T> {

    String notifyWay();


    CompletableFuture<Integer> sendV2(T message);
    
}
