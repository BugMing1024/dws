package com.cloudwise.douc.customization.biz.constant;


/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
public enum ExecutorType {
    
    
    /**
     * 启动时执行（只执行一次）
     */
    STARTUP,
    
    /**
     * 调用接口执行
     */
    REST,
    
    /**
     * 定时执行（周期执行）
     */
    SCHEDULED;
}
