package com.cloudwise.douc.customization.biz.service.email.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloudwise.douc.customization.biz.dao.CustomMessageRecordMapper;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  10:05
 **/
@Service
public class CustomMessageRecordServiceImpl extends ServiceImpl<CustomMessageRecordMapper,CustomMessageRecord> implements CustomMessageRecordService {
    
    @Autowired
    CustomMessageRecordMapper customMessageRecordMapper;
    
    @Override
    public String insertRecord(CustomMessageRecord messageRecord) {
        customMessageRecordMapper.insert(messageRecord);
        return messageRecord.getId();
    }
    
    @Override
    public void updateRecord(List<CustomMessageRecord> messageRecords) {
        customMessageRecordMapper.updateById(messageRecords);
    }
    
    @Override
    public List<CustomMessageRecord> getFailMessages() {
        LambdaQueryWrapper<CustomMessageRecord> queryWrapper = Wrappers.lambdaQuery(CustomMessageRecord.class).eq(CustomMessageRecord::getStatus, 0)
                .le(CustomMessageRecord::getRetry, 3);
        return customMessageRecordMapper.selectList(queryWrapper);
    }
}
