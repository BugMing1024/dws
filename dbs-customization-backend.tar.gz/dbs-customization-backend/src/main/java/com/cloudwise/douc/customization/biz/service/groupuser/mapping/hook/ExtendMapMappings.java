package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;

import cn.hutool.core.util.ReflectUtil;
import com.cloudwise.douc.customization.biz.anno.ExtendMapProperty;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * @author dwq
 */
@Component
public class ExtendMapMappings {
    
    public <S> Map<String, String> mapping(S source) {
        Class<?> sourceClass = source.getClass();
        Field[] declaredFields = ReflectUtil.getFields(sourceClass);
        Map<String, String> extend = new HashMap<>();
        for (Field declaredField : declaredFields) {
            ExtendMapProperty annotation = declaredField.getAnnotation(ExtendMapProperty.class);
            if (annotation != null) {
                String alias = annotation.value();
                Object value = ReflectUtil.getFieldValue(source, declaredField);
                if (value == null) {
                    continue;
                }
                extend.put(alias, value.toString());
            }
        }
        return CollectionUtils.isEmpty(extend) ? null : extend;
    }
}
