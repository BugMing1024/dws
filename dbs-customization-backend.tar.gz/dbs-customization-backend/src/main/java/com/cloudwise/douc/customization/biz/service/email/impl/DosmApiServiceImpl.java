package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.dosm.facewall.extension.core.exception.BaseException;
import com.cloudwise.douc.customization.biz.enums.CRStageEnum;
import com.cloudwise.douc.customization.biz.enums.EmailApproveEnum;
import com.cloudwise.douc.customization.biz.enums.ValueTypeEnum;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.model.email.dosm.*;
import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import com.cloudwise.douc.customization.biz.service.email.DosmApiService;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.signoff.SignOffService;
import com.cloudwise.douc.customization.biz.util.DosmHttpUtil;
import com.cloudwise.douc.customization.biz.util.DosmUtil;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum.CR_APPROVED;
import static com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum.CR_REJECTED;

/**
 * @author ming.ma
 * @since 2024-12-11  14:13
 **/
@Slf4j
@Service
public class DosmApiServiceImpl implements DosmApiService {

    @Autowired
    DosmHttpUtil dosmHttpUtil;

    @Autowired
    DosmConfig dosmConfig;

    @Lazy
    @Autowired
    SignOffService signOffService;

    @Override
    public boolean approveOrder(ApproveOrderVo approveOrder) {
        log.info("ApproveOrder param :{}", approveOrder);
        String workOrderId = approveOrder.getWorkOrderId();
        String userId = approveOrder.getUserId();
        EmailApproveEnum approveStatus = approveOrder.getApproveStatus();
        WorkOrderDetail workorderDetail = dosmHttpUtil.getWorkOrderDetail(workOrderId, userId);
        if (null == workorderDetail) {
            return false;
        }
        String mdlDefKey = workorderDetail.getMdlDefKey();
        String currentNodeId = workorderDetail.getCurrentNodeId();
        SubmitWorkorderDataBean submitWorkorderDataBean = SubmitWorkorderDataBean.builder().workOrderNo(workorderDetail.getId())
                .bizDesc(workorderDetail.getBizDesc()).createdBy(Convert.toStr(userId)).dataStatus(workorderDetail.getDataStatus())
                .formData(workorderDetail.getFormData()).mdlDefKey(workorderDetail.getMdlDefKey()).revision(0)
                .serviceIds(workorderDetail.getServiceIds()).sourceId(workorderDetail.getSourceId()).title(workorderDetail.getTitle())
                .updatedBy(Convert.toStr(userId)).urgentLevel(workorderDetail.getUrgentLevel() + "").mdlDefCode(workorderDetail.getMdlDefCode())
                .build();

        SubmitWorkorderBean workorder = SubmitWorkorderBean.builder().bizKey(workorderDetail.getBizKey()).formId(workorderDetail.getFormId())
                .mdlDefCode(workorderDetail.getMdlDefCode()).nodeId(workorderDetail.getCurrentNodeId()).nodeName(workorderDetail.getNodeName())
                .processInstanceId(workorderDetail.getProcessInstanceId()).taskId(DosmUtil.getTaskId(workorderDetail))
                .workOrderId(workorderDetail.getId()).workOrderSource(1).data(submitWorkorderDataBean).build();

        String formData = workorderDetail.getFormData();
        Map<String, String> emailContent = approveOrder.getEmailContent();
//        JsonNode stageApproveFormData = cRStageFormUtil.getStageApproveFormData(formData, approveOrder.getStage(), userId, approveStatus.getName(),
//                emailContent);
//        if (stageApproveFormData == null) {
//            return false;
//        }
//        submitWorkorderDataBean.setFormData(JsonUtils.toJsonStr(stageApproveFormData));
        submitWorkorderDataBean.setFormData(formData);
        CRStageEnum stage = approveOrder.getStage();
        log.info("APPROVAL approve result stage :{},approveStatus:{}", stage, approveStatus);
        switch (stage) {
            case APPROVAL:
                if (approveStatus == EmailApproveEnum.APPROVED) {
                    log.info("ApproveOrder Approved:{}", approveStatus);
                    log.info("ApproveOrder approval start approveOrder");
                    boolean success = dosmHttpUtil.approveOrder(userId, JsonUtils.toJsonStr(workorder));
                    if (success){
                        sendNormalApproveEmail(userId,workorder.getWorkOrderId(),EmailApproveEnum.APPROVED);
                    }
                    return success;
                } else {
                    log.info("ApproveOrder Rejected:{}", approveStatus);
                    DosmConfig.ApprovalStage approvalStage = dosmConfig.getApprovalStage();
                    Map<String, String> reasonCodeMap = approvalStage != null ? approvalStage.getReasonCodeMap() : new HashMap<>();
                    log.info("ApproveOrder reasonCodeMap :{}", reasonCodeMap);
                    ApproveConfVo approveConf = workorderDetail.getApproveConf();
                    if (approveConf != null) {
                        String rejectTo = approveConf.getRejectTo() != null ? approveConf.getRejectTo().get(0).name() : RejectToEnum.LAST_NODE.name();
                        workorder.setRejectTo(rejectTo);
                        workorder.setRemark(emailContent.get(Constants.REJECT_REASON));
                        if (CollUtil.isNotEmpty(reasonCodeMap)) {
                            workorder.setReason(reasonCodeMap.get(emailContent.get(Constants.REJECT_CODE)));
                        }
                        log.info("ApproveOrder approval start rejectOrder");

                        submitWorkorderDataBean.setFormData(JsonUtils.toJsonStr(updateRejectedStatus(mdlDefKey, currentNodeId, JsonUtils.toJsonNode(formData))));
                        boolean success = dosmHttpUtil.rejectOrder(userId, JsonUtils.toJsonStr(workorder));
                        if (success){
                            sendNormalApproveEmail(userId,workorder.getWorkOrderId(),EmailApproveEnum.REJECTED);
                        }
                        return success;
                    }
                    return false;
                }
            case SIGN_OFF:
                String signOffId = approveOrder.getSignOffId();
                log.info("SIGN_OFF approve result signOffId:{},approveStatus:{}", signOffId, approveStatus);
                if (CharSequenceUtil.isBlank(signOffId)) {
                    return false;
                }
                if(approveStatus == EmailApproveEnum.APPROVED) {
                    signOffService.approved(Long.valueOf(signOffId), userId);
                    sendSignOffApproveEmail(signOffId, userId, EmailApproveEnum.APPROVED, workorderDetail);
                } else {
                    signOffService.rejected(Long.valueOf(signOffId), userId);
                    sendSignOffApproveEmail(signOffId, userId, EmailApproveEnum.REJECTED, workorderDetail);
                }
                return true;
            default:
                return true;
            //return dosmHttpUtil.submitOrder(userId, JsonUtils.toJsonStr(workorder));
        }
    }

    private void sendNormalApproveEmail(String userId, String workOrderId, EmailApproveEnum approved) {
        // 发送邮件
        MessageContext messageContext = new MessageContext();
        messageContext.setWorkOrderId(workOrderId);
        messageContext.setUserId(userId);
        messageContext.setAccountId(dosmConfig.getAccountId());

        NotifyVo emailNotify = new NotifyVo();

        // 内容
        ValueContent valueContent = new ValueContent();
        valueContent.setType(ValueTypeEnum.FORM);
        valueContent.setFields(Lists.newArrayList());
        emailNotify.setContent(valueContent);

        // 接受人
        ValueContent receivers = new ValueContent();
        receivers.setType(ValueTypeEnum.NORMAL);
        NormalValue receiversValue = new NormalValue();
        receiversValue.setUserIds(Lists.newArrayList(userId));
        receivers.setNormalValue(receiversValue);
        emailNotify.setReceivers(Lists.newArrayList(receivers));

        // 标题
        ValueContent title = new ValueContent();
        title.setType(ValueTypeEnum.NORMAL);
        NormalValue titleValue = new NormalValue();
        titleValue.setValues(Lists.newArrayList("test title"));
        title.setNormalValue(titleValue);
        emailNotify.setTitle(title);

        if (approved == EmailApproveEnum.APPROVED) {
            emailNotify.setNotifyScene(CR_APPROVED);
        }else {
            emailNotify.setNotifyScene(CR_REJECTED);
        }
        messageContext.setNotify(emailNotify);
        DosmCustomService dosmCustomService = SpringUtil.getBean(DosmCustomService.class);
        dosmCustomService.sendMessage(messageContext);

    }

    private boolean sendSignOffApproveEmail(String signOffId, String userId, EmailApproveEnum emailApproveEnum, WorkOrderDetail workorderDetail) {
        // 发送邮件
        SignOffEntity signoffEntity = signOffService.getSignOffById(Long.valueOf(signOffId));

        MessageContext messageContext = new MessageContext();
        messageContext.setWorkOrderId(signoffEntity.getWorkOrderId());
        messageContext.setUserId(userId);
        messageContext.setAccountId(dosmConfig.getAccountId());

        NotifyVo emailNotify = new NotifyVo();
        messageContext.setNotify(emailNotify);
        HashMap<String, String> publicFields = new HashMap<>();
        messageContext.setPublicFields(publicFields);

        EmailAnalysisUtil.buildSignoffMsgContext(signoffEntity, workorderDetail, emailNotify, publicFields, emailApproveEnum);

        DosmCustomService dosmCustomService = SpringUtil.getBean(DosmCustomService.class);
        boolean b = dosmCustomService.sendMessage(messageContext);
        if (b) {
            return true;
        }
        throw new BaseException("Failed to send an approval email");

    }

    private static final String APP_OWNER = "ApplicationOwnerType";
    private static final String Rejection_Reason = "RejectionReason";
    private static final String REJECTED_BY = "Rejectedby";
    private static final String APP_OWNER_VALUE = "PrimaryOrSecondaryApplicationOwner";
    private static final String REJECTED = "rejected";


    private JsonNode updateRejectedStatus(String mdlDefKey, String nodeId, JsonNode formDataNode) {
        ObjectNode formDataNodeOb = (ObjectNode) formDataNode;
        Map<String, List<DosmConfig.NodeConfig>> processConfig = dosmConfig.getProcessConfig();
        if (processConfig == null) {
            log.info("RejectBtnTrigger get processConfig is empty");
            return formDataNodeOb;
        }
        log.info("RejectBtnTrigger get processConfig is:{}", processConfig);
        List<DosmConfig.NodeConfig> nodeConfigs = processConfig.get(mdlDefKey);
        if (nodeConfigs == null) {
            log.info("RejectBtnTrigger get nodeConfigs is empty,mdlDefKey:{}", mdlDefKey);
            return formDataNodeOb;
        }
        for (DosmConfig.NodeConfig nodeConfig : nodeConfigs) {
            String configNodeId = nodeConfig.getNodeId();
            String rejectKey = nodeConfig.getRejectKey();
            boolean judge = nodeConfig.isJudge();
            if (CharSequenceUtil.equals(nodeId, configNodeId)) {
                if (judge) {
                    JsonNode appOwner = formDataNodeOb.get(APP_OWNER);
                    JsonNode appOwnerValue = formDataNodeOb.get(APP_OWNER + "_value");
                    if (appOwnerValue != null && CharSequenceUtil.isNotBlank(appOwnerValue.asText())) {
                        String value = appOwnerValue.asText();
                        List<String> judgeValue = nodeConfig.getJudgeValue();
                        if (CollUtil.isNotEmpty(judgeValue)) {
                            if (judgeValue.contains(value)) {
                                formDataNodeOb.put(rejectKey, REJECTED);
                            }
                        } else {
                            if (APP_OWNER_VALUE.equals(value)) {
                                formDataNodeOb.put(rejectKey, REJECTED);
                            }
                        }
                    } else {
                        if (appOwner != null && CharSequenceUtil.isNotBlank(appOwner.asText())) {
                            List<String> judgeValue = nodeConfig.getJudgeValue();
                            String value = appOwner.asText();
                            if (CollUtil.isNotEmpty(judgeValue)) {
                                if (judgeValue.contains(value)) {
                                    formDataNodeOb.put(rejectKey, REJECTED);
                                }
                            } else {
                                if (APP_OWNER_VALUE.equals(value)) {
                                    formDataNodeOb.put(rejectKey, REJECTED);
                                }
                            }
                        }
                    }
                } else {
                    formDataNodeOb.put(rejectKey, REJECTED);
                }
                break;
            }
        }
        return formDataNodeOb;
    }

}
