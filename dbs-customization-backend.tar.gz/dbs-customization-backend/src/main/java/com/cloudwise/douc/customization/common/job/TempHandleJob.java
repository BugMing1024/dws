package com.cloudwise.douc.customization.common.job;

import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 身份源全量同步定时任务
 *
 * @author bruce.liu
 * @date 2021-07-16 18:07
 **/
@Slf4j
@Component
public class TempHandleJob {
    
    
    private boolean isRunning;
    
    @XxlJob("Enum")
    public void jobRun() {
        log.debug("------IdentitySourceSyncDataHandleJob--job-start----");
        if (isRunning) {
            return;
        }
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            if (isRunning) {
                return;
            }
            try {
                if (!isRunning) {
                    isRunning = true;
                }
                executeInternal();
            } catch (Throwable exception) {
                log.error("error run task", exception);
            } finally {
                isRunning = false;
            }
        });
        log.debug("------IdentitySourceSyncDataHandleJob--job-end----");
    }
    
    protected void executeInternal() {
        log.debug("------IdentitySourceSyncDataHandleJob--Runnable-start----");
        // do something
        log.debug("------IdentitySourceSyncDataHandleJob--Runnable-end----");
    }
    
}
