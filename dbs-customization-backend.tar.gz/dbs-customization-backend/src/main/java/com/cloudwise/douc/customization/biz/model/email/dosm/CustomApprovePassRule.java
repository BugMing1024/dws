package com.cloudwise.douc.customization.biz.model.email.dosm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class CustomApprovePassRule {
    
    @ApiModelProperty(value = "自定义通过规则", example = "  /**\n" + "         * 按通过次数\n" + "         */\n" + "        PASS_TIMES,\n" + "\n"
            + "        /**\n" + "         * 按通过比例\n" + "         */\n" + "        PASS_PROPORTION,", required = false)
    private MultiApproveConst.CustomPassRuleTypeEnum customRuleAttributes;
    
    @ApiModelProperty(value = "条件比对,等于 EQ, 大于或等于 GE, 大于GT", example = "", required = false)
    private MultiApproveConst.ConditionTypeEnum conditionCompare;
    
    @ApiModelProperty(value = "自定义分子", example = "1", required = false)
    private Integer molecularNum;
    
    @ApiModelProperty(value = "自定义分母", example = "2", required = false)
    private Integer denominatorNum;
    
    @ApiModelProperty(value = "自定义通过数", example = "", required = false)
    private Integer passNum;
    
    /**
     * 会签结束设置
     */
    @ApiModelProperty(value = "会签结束设置条件", example = "\n" + "        /**\n" + "         * 所有人完成审批\n" + "         */\n"
            + "        ALL_PERSON_PASS,\n" + "\n" + "        /**\n" + "         * 满足“通过规则”或无法达成“通过规则”时立即结束\n" + "         */\n"
            + "        MATCH_PASS_RULE;")
    @Deprecated
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private MultiApproveConst.MultiApproveFinishEnum approveFinishCondition;
    
    
}
