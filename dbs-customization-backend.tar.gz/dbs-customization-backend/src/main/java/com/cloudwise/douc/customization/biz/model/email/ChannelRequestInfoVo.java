package com.cloudwise.douc.customization.biz.model.email;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 渠道查询信息
 *
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/3/30 14:53
 */
@ApiModel("渠道信息")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChannelRequestInfoVo {
    
    /**
     * 渠道类型
     */
    @ApiModelProperty(value = "渠道类型", example = "EMAIL", required = false)
    private String channelCode;
    
    /**
     * 渠道名称
     */
    @ApiModelProperty(value = "渠道名称", example = "邮件", required = false)
    private String channelName;
    
    /**
     * 当前页
     */
    @ApiModelProperty(value = "当前页", example = "1", required = true)
    private Integer currentPage = 1;
    
    /**
     * 当前页数
     */
    @ApiModelProperty(value = "页大小", example = "10", required = true)
    private Integer pageSize = 10;
    
    
    /**
     * 查询的ID
     */
    @ApiModelProperty(value = "id列表", example = "10", required = true)
    private List<Long> ids;
}
