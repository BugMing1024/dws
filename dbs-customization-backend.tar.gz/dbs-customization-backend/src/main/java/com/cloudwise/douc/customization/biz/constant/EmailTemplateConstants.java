package com.cloudwise.douc.customization.biz.constant;

/**
 * @Author frank.zheng
 * @Date 2025-02-05
 */
public interface EmailTemplateConstants {


    String TESTING_SIGN_OFF_TYPES = "testingSignOffTypes";
    String SCIENCE_TYPE           = "scienceType";


    /** ITSM support email */
    String ITSM_SUPPORT_EMAIL = "itsmSupportEmail";

    /** Email Approval Parse Exception */
    String EMAIL_APPROVAL_EXCEPTION = "emailApprovalException";

    /** Email Approval Parse Exception */
    String DATE_7_WORKDAY = "date7workDay";

    /** Email Approval Parse Exception */
    String ASSIGNED_USER_NAME = "assignedUserName";

    String SEND_EMAIL_DATE_TIME = "sendEmailDateTime";

    String APPROVAL_COUNT = "approvalCount";

    String EARLIEST_CHANGE_SCHEDULE_START_DATE = "earliestChangeScheduleStartDate";


    /** button */
    interface Btn {

        /** approved mailto link */
        String APPROVE = "approveMailtoLink";
        /** rejected mailto link */
        String REJECT  = "rejectMailtoLink";

        /** ticket detail link */
        String TICKET_DETAIL = "ticketDetailLink";

        /** Pending My Approval link */
        String PENDING_MY_APPROVAL_LIST = "pendingMyApprovalListLink";
    }


    interface PublicFields {

        /** work order id */
        String WORK_ORDER_ID = "workOrderId";

        /** work order biz key */
        String BIZ_KEY = "bizKey";

        String WORK_ORDER_STATUS = "workOrderStatus";

        /** work order current node */
        String CURRENT_NODE = "currentNode";

        /** work order created by */
        String CREATED_BY_ID    = "createdById";
        String CREATED_BY_EMAIL = "createdByEmail";
        String CREATED_BY_NAME  = "createdByName";

        /** work order mdlDefKey */
        String MDL_DEF_KEY = "mdlDefKey";

        String WORK_ORDER_URI = "workOrderUri";

        String MAIN_WORK_ORDER_URI = "mainWorkOrderUri";

        /** work order operator */
        String OPERATOR_ALIAS = "operatorAlias";

        /** work order signoff UploadFile */
        String SIGNOFF_UPLOAD_FILE = "signOffUploadFile";

        String SIGN_OFF_ID = "signOffId";

        String SIGN_OFF_TYPE = "signOffType";
    }


    interface BodyField {

        /** CR Number */
        String CR_NUMBER                                     = "CR_NUMBER";
        /** Requester Name (Requester) */
        String REQUESTER_NAME                                = "REQUESTER_NAME";
        /** Unit (LOB) */
        String UNIT                                          = "UNIT";
        /** Location */
        String LOCATION                                      = "LOCATION";
        /** Application Impacted (Show the highest MAS Category and App Category) */
        String APPLICATION_IMPACTED                          = "APPLICATION_IMPACTED";
        /** Main Application Requiring Change (Show the MAS Category and App Category) */
        String MAIN_APPLICATION_REQUIRING_CHANGE             = "MAIN_APPLICATION_REQUIRING_CHANGE";
        /** Schedule Start Date */
        String SCHEDULE_START_DATE                           = "SCHEDULE_START_DATE";
        /** Schedule End Date */
        String SCHEDULE_END_DATE                             = "SCHEDULE_END_DATE";
        /** Summary (Change Summary) */
        String SUMMARY                                       = "SUMMARY";
        /** Description (Change Description) */
        String DESCRIPTION                                   = "DESCRIPTION";
        /** Country of Origin (Hosting Country) */
        String COUNTRY_OF_ORIGIN                             = "COUNTRY_OF_ORIGIN";
        /** Country Impacted */
        String COUNTRY_IMPACTED                              = "COUNTRY_IMPACTED";
        /** Change Type */
        String CHANGE_TYPE                                   = "CHANGE_TYPE";
        /** Change Group */
        String CHANGE_GROUP                                  = "CHANGE_GROUP";
        /** Change Category */
        String CHANGE_CATEGORY                               = "CHANGE_CATEGORY";
        /** Change Nature */
        String CHANGE_NATURE                                 = "CHANGE_NATURE";
        /** CR Classification */
        String CR_CLASSIFICATION                             = "CR_CLASSIFICATION";
        /** App(s) Resiliency Classification */
        String APP_RESILIENCY_CLASSIFICATION                 = "APP_RESILIENCY_CLASSIFICATION";
        /** Major Change */
        String MAJOR_CHANGE                                  = "MAJOR_CHANGE";
        /** Other Application Impacted (App Code (LOB)) */
        String OTHER_APPLICATION_IMPACTED                    = "OTHER_APPLICATION_IMPACTED";
        /** Impact and Risks Identified when doing this change */
        String IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE        = "IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE";
        /** How the Identified Risks are Mitigated when doing this change */
        String HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE = "HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE";
        /** Potential Blast Radius If the Change Fails */
        String POTENTIAL_BLAST_RADIUS_CHANGE_FAILS           = "POTENTIAL_BLAST_RADIUS_CHANGE_FAILS";
        /** Implementation Start Date / Time */
        String IMPLEMENTATION_START_DATETIME                 = "IMPLEMENTATION_START_DATETIME";
        /** Implementation End Date/Time */
        String IMPLEMENTATION_END_DATETIME                   = "IMPLEMENTATION_END_DATETIME";
        /** Reversion Start Date/Time */
        String REVERSION_START_DATETIME                      = "REVERSION_START_DATETIME";
        /** Reversion End Date/Time */
        String REVERSION_END_DATETIME                        = "REVERSION_END_DATETIME";
        /** Mainframe CR Type */
        String MAINFRAME_CR_TYPE                             = "MAINFRAME_CR_TYPE";
        /** Data Patch App Owner Approval */
        String DATA_PATCH_APP_OWNER_APPROVAL                 = "DATA_PATCH_APP_OWNER_APPROVAL";
        /** App Governance Approval 1 */
        String APP_GOVERNANCE_APPROVAL_1                     = "APP_GOVERNANCE_APPROVAL_1";
        /** Tech MD Approval */
        String TECH_MD_APPROVAL                              = "TECH_MD_APPROVAL";
        /** L1.5 Change Management Team Approval */
        String L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL          = "L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL";
        /** Design for Data: Does this CR include Data Requirements? */
        String DESIGN_DATA_CR_INCLUDE_DATA_REQUIREMENTS      = "DESIGN_DATA_CR_INCLUDE_DATA_REQUIREMENTS";
        /** Design for Data: D4D Data Owner */
        String DESIGN_DATA_D4D_DATA_OWNER                    = "DESIGN_DATA_D4D_DATA_OWNER";
        /** Design for Data: Details of Data Requirements */
        String DESIGN_DATA_DETAILS_DATA_REQUIREMENTS         = "DESIGN_DATA_DETAILS_DATA_REQUIREMENTS";
        /** Service Monitoring at SNOC */
        String SERVICE_MONITORING_AT_SNOC                    = "SERVICE_MONITORING_AT_SNOC";
        /** Service Monitoring at SNOC Link */
        String SERVICE_MONITORING_AT_SNOC_LINK               = "SERVICE_MONITORING_AT_SNOC_LINK";
        /** Service Monitoring at SNOC New Application */
        String SERVICE_MONITORING_AT_SNOC_NEW_APPLICATION    = "SERVICE_MONITORING_AT_SNOC_NEW_APPLICATION";
        /** Data Patch (Number of Records) */
        String DATA_PATCH_NUMBER_OF_RECORDS                  = "DATA_PATCH_NUMBER_OF_RECORDS";
        /** URL For Project Docs and Artefacts */
        String URL_PROJECT_DOCS_ARTEFACTS                    = "URL_PROJECT_DOCS_ARTEFACTS";

        /** Impacted application */
        String IMPACTED_APPLICATION                                          = "IMPACTED_APPLICATION";
        /** Why the change implementation failed? */
        String WHY_CHANGE_IMPLEMENTATION_FAILED                              = "WHY_CHANGE_IMPLEMENTATION_FAILED";
        /** Any incident ticket raised due to the failed change implementation? */
        String ANY_INCIDENT_TICKET_RAISED_DUE_2_FAILED_CHANGE_IMPLEMENTATION = "ANY_INCIDENT_TICKET_RAISED_DUE_2_FAILED_CHANGE_IMPLEMENTATION";


        String[] FKS_CR_NEW_TESTING_SIGNOFF_COMM = {CR_NUMBER, REQUESTER_NAME, LOCATION, SCHEDULE_START_DATE, SCHEDULE_END_DATE, APPLICATION_IMPACTED, SUMMARY, DESCRIPTION};


        String[] FKS_CR_NEW_PRJ_SIGNOFF_COMM                    = {CR_NUMBER, REQUESTER_NAME, LOCATION, SCHEDULE_START_DATE, SCHEDULE_END_DATE, UNIT, MAIN_APPLICATION_REQUIRING_CHANGE, APPLICATION_IMPACTED, SUMMARY, DESCRIPTION, COUNTRY_OF_ORIGIN, COUNTRY_IMPACTED, CHANGE_TYPE, CHANGE_GROUP, CHANGE_CATEGORY, CHANGE_NATURE, CR_CLASSIFICATION, APP_RESILIENCY_CLASSIFICATION, MAJOR_CHANGE, OTHER_APPLICATION_IMPACTED, IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE, HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE, POTENTIAL_BLAST_RADIUS_CHANGE_FAILS, IMPLEMENTATION_START_DATETIME, IMPLEMENTATION_END_DATETIME, REVERSION_START_DATETIME, REVERSION_END_DATETIME, DATA_PATCH_APP_OWNER_APPROVAL, APP_GOVERNANCE_APPROVAL_1, MAINFRAME_CR_TYPE, TECH_MD_APPROVAL, L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL, URL_PROJECT_DOCS_ARTEFACTS};
        String[] FKS_CR_NEW_PRJ_SIGNOFF_D4D                     = {CR_NUMBER, REQUESTER_NAME, LOCATION, SCHEDULE_START_DATE, SCHEDULE_END_DATE, UNIT, MAIN_APPLICATION_REQUIRING_CHANGE, APPLICATION_IMPACTED, SUMMARY, DESCRIPTION, COUNTRY_OF_ORIGIN, COUNTRY_IMPACTED, CHANGE_TYPE, CHANGE_GROUP, CHANGE_CATEGORY, CHANGE_NATURE, CR_CLASSIFICATION, APP_RESILIENCY_CLASSIFICATION, MAJOR_CHANGE, OTHER_APPLICATION_IMPACTED, IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE, HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE, POTENTIAL_BLAST_RADIUS_CHANGE_FAILS, IMPLEMENTATION_START_DATETIME, IMPLEMENTATION_END_DATETIME, REVERSION_START_DATETIME, REVERSION_END_DATETIME, DATA_PATCH_APP_OWNER_APPROVAL, APP_GOVERNANCE_APPROVAL_1, MAINFRAME_CR_TYPE, TECH_MD_APPROVAL, L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL, DESIGN_DATA_CR_INCLUDE_DATA_REQUIREMENTS, DESIGN_DATA_D4D_DATA_OWNER, DESIGN_DATA_DETAILS_DATA_REQUIREMENTS, URL_PROJECT_DOCS_ARTEFACTS};
        String[] FKS_CR_NEW_PRJ_SIGNOFF_SERVICE_MONITORING_SNOC = {CR_NUMBER, REQUESTER_NAME, LOCATION, SCHEDULE_START_DATE, SCHEDULE_END_DATE, UNIT, MAIN_APPLICATION_REQUIRING_CHANGE, APPLICATION_IMPACTED, SUMMARY, DESCRIPTION, COUNTRY_OF_ORIGIN, COUNTRY_IMPACTED, CHANGE_TYPE, CHANGE_GROUP, CHANGE_CATEGORY, CHANGE_NATURE, CR_CLASSIFICATION, APP_RESILIENCY_CLASSIFICATION, MAJOR_CHANGE, OTHER_APPLICATION_IMPACTED, IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE, HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE, POTENTIAL_BLAST_RADIUS_CHANGE_FAILS, IMPLEMENTATION_START_DATETIME, IMPLEMENTATION_END_DATETIME, REVERSION_START_DATETIME, REVERSION_END_DATETIME, DATA_PATCH_APP_OWNER_APPROVAL, APP_GOVERNANCE_APPROVAL_1, MAINFRAME_CR_TYPE, TECH_MD_APPROVAL, L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL, SERVICE_MONITORING_AT_SNOC, SERVICE_MONITORING_AT_SNOC_LINK, SERVICE_MONITORING_AT_SNOC_NEW_APPLICATION, URL_PROJECT_DOCS_ARTEFACTS};


        String[] FKS_CR_NEW_OTHER_SIGNOFF_COMM = {CR_NUMBER, REQUESTER_NAME, LOCATION, SCHEDULE_START_DATE, SCHEDULE_END_DATE, UNIT, MAIN_APPLICATION_REQUIRING_CHANGE, APPLICATION_IMPACTED, SUMMARY, DESCRIPTION, COUNTRY_OF_ORIGIN, COUNTRY_IMPACTED, CHANGE_TYPE, CHANGE_GROUP, CHANGE_CATEGORY, CHANGE_NATURE, CR_CLASSIFICATION, APP_RESILIENCY_CLASSIFICATION, MAJOR_CHANGE, OTHER_APPLICATION_IMPACTED, IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE, HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE, POTENTIAL_BLAST_RADIUS_CHANGE_FAILS, IMPLEMENTATION_START_DATETIME, IMPLEMENTATION_END_DATETIME, REVERSION_START_DATETIME, REVERSION_END_DATETIME, DATA_PATCH_APP_OWNER_APPROVAL, APP_GOVERNANCE_APPROVAL_1, TECH_MD_APPROVAL, L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL};


        String[] FKS_CR_OPEN_IEN_COMM = FKS_CR_NEW_OTHER_SIGNOFF_COMM;
        String[] FKS_CR_OPEN_AVE_COMM = {CR_NUMBER, SCHEDULE_START_DATE, SCHEDULE_END_DATE, SUMMARY, LOCATION, APPLICATION_IMPACTED, COUNTRY_IMPACTED, CHANGE_TYPE, CHANGE_GROUP, CHANGE_CATEGORY, CR_CLASSIFICATION, APP_RESILIENCY_CLASSIFICATION, MAJOR_CHANGE};


        String[] FKS_CR_APPROVED                 = FKS_CR_NEW_TESTING_SIGNOFF_COMM;
        String[] FKS_CR_REJECTED                 = FKS_CR_NEW_TESTING_SIGNOFF_COMM;
        String[] FKS_STANDALONE_CR_REJECTED_COMM = FKS_CR_NEW_TESTING_SIGNOFF_COMM;
        String[] FKS_CR_CLOSED_CANCEL            = FKS_CR_NEW_TESTING_SIGNOFF_COMM;


        String[] FKS_RCA_PENDING_COMM  = FKS_CR_NEW_OTHER_SIGNOFF_COMM;
        String[] FKS_RCA_APPROVAL_COMM = {CR_NUMBER, REQUESTER_NAME, LOCATION, SCHEDULE_START_DATE, SCHEDULE_END_DATE, UNIT, MAIN_APPLICATION_REQUIRING_CHANGE, APPLICATION_IMPACTED, SUMMARY, DESCRIPTION, COUNTRY_OF_ORIGIN, COUNTRY_IMPACTED, CHANGE_TYPE, CHANGE_GROUP, CHANGE_CATEGORY, CHANGE_NATURE, CR_CLASSIFICATION, APP_RESILIENCY_CLASSIFICATION, MAJOR_CHANGE, OTHER_APPLICATION_IMPACTED, IMPACT_RISKS_IDENTIFIED_WHEN_DO_CHANGE, HOW_IDENTIFIED_RISKS_MITIGATED_WHEN_DO_CHANGE, POTENTIAL_BLAST_RADIUS_CHANGE_FAILS, IMPLEMENTATION_START_DATETIME, IMPLEMENTATION_END_DATETIME, REVERSION_START_DATETIME, REVERSION_END_DATETIME, DATA_PATCH_APP_OWNER_APPROVAL, APP_GOVERNANCE_APPROVAL_1, TECH_MD_APPROVAL, L1_5_CHANGE_MANAGEMENT_TEAM_APPROVAL, IMPACTED_APPLICATION, WHY_CHANGE_IMPLEMENTATION_FAILED, ANY_INCIDENT_TICKET_RAISED_DUE_2_FAILED_CHANGE_IMPLEMENTATION};
        String[] FKS_RCA_APPROVED_COMM = FKS_RCA_APPROVAL_COMM;
        String[] FKS_RCA_REJECTED_COMM = FKS_RCA_APPROVAL_COMM;
    }


}
