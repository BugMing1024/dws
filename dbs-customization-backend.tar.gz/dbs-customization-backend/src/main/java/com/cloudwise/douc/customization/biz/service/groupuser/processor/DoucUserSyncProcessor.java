package com.cloudwise.douc.customization.biz.service.groupuser.processor;

import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.dto.v3.user.AddOrUpdateUserReq;
import org.springframework.stereotype.Component;

@Component
public class DoucUserSyncProcessor extends AbstractSyncProcessor<DbsUserInfo, AddOrUpdateUserReq> implements SyncProcessor {
    
    @Override
    public int getOrder() {
        return 1;
    }
    
    @Override
    public void start() {
        this.write(this.read(businessType));
    }
}
