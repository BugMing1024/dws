package com.cloudwise.douc.customization.biz.facade;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import com.cloudwise.douc.customization.biz.model.groupuser.DoucPageResponse;
import com.cloudwise.douc.customization.biz.model.groupuser.DoucUser;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.constant.ErrorCodeEnum;
import com.cloudwise.douc.customization.common.exception.BizException;
import com.cloudwise.douc.customization.common.exception.DoucUserNotFoundException;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboRpcQueryParam;
import com.cloudwise.douc.dto.DubboRpcQueryParams;
import com.cloudwise.douc.dto.DubboUserAliasReq;
import com.cloudwise.douc.facade.UserV2DubboFacade;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created on 2022-10-18.
 *
 * @author skiya
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DoucUserFacade {
    
    private final DoucProperties doucProperties;
    
    //@DubboReference(lazy = true ,check = false ,timeout = 5000,url = "rest://${rest.svc.douc:}")
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserV2DubboFacade userV2DubboFacade;
    
    /**
     * 根据用户编码获取用户
     *
     * @param userCode 用户代码
     * @return {@link DoucUser}
     * @throws BizException              当接口返回失败结果时，抛出
     * @throws DoucUserNotFoundException 当查询的用户不存在时，抛出
     */
    public DoucUser getUserByCode(String userCode) {
        DubboRpcQueryParams params = new DubboRpcQueryParams();
        params.setAccountId(doucProperties.getAccountId());
        params.setUserId(doucProperties.getAdminId());
        
        DubboRpcQueryParam param = new DubboRpcQueryParam();
        param.setCurrentPageNo(1);
        param.setPageSize(1);
        param.setCode(userCode);
        params.setQueryParam(param);
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(params));
        DubboCommonResp<String> commonResp = userV2DubboFacade.getUserListByParam(params);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        if (!commonResp.isSuccess()) {
            log.warn("douc rpc error: {}", commonResp.getMsg());
            throw new BizException(ErrorCodeEnum.API_REQUEST_FAILED);
        }
        List<DoucUser> doucUsers = JsonUtils.toBean(commonResp.getData(), new TypeReference<DoucPageResponse<List<DoucUser>>>() {
        }).getData();
        
        if (CollUtil.isEmpty(doucUsers)) {
            throw new DoucUserNotFoundException(ListUtil.of(userCode));
        }
        
        return doucUsers.get(0);
    }
    
    /**
     * 根据用户登录账号获取用户
     *
     * @param accounts 用户登录账号
     * @return {@link List}<{@link DoucUser}> 查询不到时返回空集合
     */
    public List<DoucUser> getUsersByAccounts(List<String> accounts) {
        DubboUserAliasReq req = new DubboUserAliasReq();
        req.setAccountId(doucProperties.getAccountId());
        req.setUserId(doucProperties.getAdminId());
        req.setUseralias(accounts);
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(req));
        DubboCommonResp<String> commonResp = userV2DubboFacade.getUsersByAliasList(req);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        return Optional.ofNullable(commonResp).filter(DubboCommonResp::isSuccess).map(DubboCommonResp::getData)
                .map(d -> JsonUtils.toList(d, DoucUser.class)).orElse(new ArrayList<>());
    }
}
