package com.cloudwise.douc.customization.biz.enums;

/**
 * @author ming.ma
 * @since 2025-01-07  14:01
 **/

public enum NotifyWayEnum {
    /**
     * 邮箱
     */
    EMAIL,
    /**
     * 短信
     */
    SMS;
}
