//package com.cloudwise.douc.customization.common.config.datasource;
//
//import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
//import org.apache.ibatis.session.SqlSessionFactory;
//import org.mybatis.spring.SqlSessionFactoryBean;
//import org.mybatis.spring.SqlSessionTemplate;
//import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.core.io.Resource;
//import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
//import org.springframework.jdbc.datasource.DataSourceTransactionManager;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//
//import javax.sql.DataSource;
//import java.io.IOException;
//import java.util.Arrays;
//import java.util.stream.Stream;
//
///**
// * @author ming.ma
// * @since 2024-12-04  09:51
// **/
//@Configuration
//@MapperScan(basePackages = {"com.cloudwise.douc.customization.dosm.dao"}, sqlSessionFactoryRef = "dosmSqlSessionFactory")
//public class DosmDataSourceConfig {
//
//    @Primary
//    @Bean(name = "dosmDataSource")
//    @ConfigurationProperties("spring.datasource.dosm")
//    public DataSource dosmDataSource() {
//        return new DriverManagerDataSource();
//    }
//
//    @Primary
//    @Bean(name = "dosmSqlSessionFactory")
//    public MybatisSqlSessionFactoryBean dosmSqlSessionFactory(@Qualifier("dosmDataSource") DataSource dataSource) throws IOException {
//        MybatisSqlSessionFactoryBean sessionFactory = new MybatisSqlSessionFactoryBean();
//        sessionFactory.setDataSource(dataSource);
//        Resource[] resources = new PathMatchingResourcePatternResolver().getResources("classpath:mapper/dosm/*.xml");
//        sessionFactory.setMapperLocations(resources);
//        return sessionFactory;
//    }
//
//    @Primary
//    @Bean(name = "dosmSqlSessionTemplate")
//    public SqlSessionTemplate dosmSqlSessionTemplate(
//            @Qualifier("dosmSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
//        return new SqlSessionTemplate(sqlSessionFactory);
//    }
//
//    @Primary
//    @Bean(name = "dosmTransactionManager")
//    public DataSourceTransactionManager dosmTransactionManager(@Qualifier("dosmDataSource") DataSource dataSource) {
//        return new DataSourceTransactionManager(dataSource);
//    }
//}
