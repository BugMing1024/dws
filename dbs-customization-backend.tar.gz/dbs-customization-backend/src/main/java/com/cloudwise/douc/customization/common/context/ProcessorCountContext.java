package com.cloudwise.douc.customization.common.context;

import lombok.Getter;

/**
 * Created on 2022-12-27.
 *
 * @author skiya
 */
@Getter
public class ProcessorCountContext {
    
    /**
     * 数据名
     */
    private String dataName;
    
    /**
     * 读取总数
     */
    private Integer readCount;
    
    /**
     * 写入总数
     */
    private Integer writeCount;
    
    /**
     * 失败数
     */
    private Integer failedCount;
    
    public void init(String dataName) {
        readCount = 0;
        writeCount = 0;
        failedCount = 0;
        this.dataName = dataName;
    }
    
    
    public void updateReadCount(Integer readCount) {
        this.readCount = this.readCount + readCount;
    }
    
    public void updateWriteCount(Integer writeCount) {
        this.writeCount = this.writeCount + writeCount;
    }
    
    public void updateFailedCount(Integer failedCount) {
        this.failedCount = this.failedCount + failedCount;
    }
}
