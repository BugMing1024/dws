package com.cloudwise.douc.customization.biz.service.msg.utils;

import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.MessageVo;
import com.cloudwise.douc.customization.biz.model.email.NotifyVo;
import com.cloudwise.douc.customization.biz.service.msg.email.analysis.EmailAnalysis;
import com.cloudwise.douc.customization.biz.service.msg.sms.analysis.SmsAnalysis;
import lombok.extern.slf4j.Slf4j;

/**
 * @Author frank.zheng
 * @Date 2025-02-06
 */
@Slf4j
public class MsgAnalysisUtil {

    public static MessageVo getMessage(MessageContext context) {
        NotifyVo notify = context.getNotify();
        if(null == notify) {
            log.error("notify is null, workOrderId:{}", context.getWorkOrderId());
            return null;
        }

        NotifyWayEnum channelType = notify.getChannelType();
        if(NotifyWayEnum.EMAIL.equals(channelType)) {
            return getEmailMessage(context);
        } else if(NotifyWayEnum.SMS.equals(channelType)) {
            return getSmsMessage(context);
        }
        log.error("channelType is invalid, workOrderId:{}", context.getWorkOrderId());
        return null;
    }


    public static MessageVo getEmailMessage(MessageContext context) {
        NotifyVo notify = context.getNotify();
        NotifyScenceEnum notifyScene = notify.getNotifyScene();
        if(notifyScene == null) {
            log.error("notifyScene is null, workOrderId:{}", context.getWorkOrderId());
            return null;
        }
        EmailAnalysis emailAnalysis = notifyScene.getEmailAnalysis();
        return emailAnalysis.getMessage(context);
    }


    public static MessageVo getSmsMessage(MessageContext context) {
        NotifyVo emailNotify = context.getNotify();
        NotifyScenceEnum notifyScene = emailNotify.getNotifyScene();
        if(notifyScene == null) {
            log.error("notifyScene is null, workOrderId:{}", context.getWorkOrderId());
            return null;
        }
        SmsAnalysis smsAnalysis = notifyScene.getSmsAnalysis();
        return smsAnalysis == null? null: smsAnalysis.getMessage(context);
    }

}
