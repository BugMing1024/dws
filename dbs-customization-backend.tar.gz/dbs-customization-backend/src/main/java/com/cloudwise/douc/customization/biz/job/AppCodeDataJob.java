package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.service.appcode.AppcodeLobCountrySyncService;
import com.cloudwise.douc.customization.biz.util.SyncJobUtil;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * appcode的同步
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2025-02-09 21:32; update at 2025-02-09 21:32
 */
@Slf4j
@RestController()
@SyncEndpoint(name = "syncAppCodeInfo", cron = Constants.SYNC_APPCODE_DATA_CRON)
@RequestMapping()
@Conditional(value = SyncCheckCondition.class)
public class AppCodeDataJob {
    
    private AtomicBoolean SYNC_APP_CODE_IS_RUNING = new AtomicBoolean(false);
    
    @Autowired
    private AppcodeLobCountrySyncService appcodeLobCountrySyncService;
    
    @XxlJob("syncAppCodeInfo")
    @GetMapping("/api/appcodeLobCountry/syncAppCodeInfo")
    public void syncAppCodeInfo() {
        log.info("syncAppCodeInfo start");
        SyncJobUtil.syncJob(() -> appcodeLobCountrySyncService.syncAppCodeInfo(), SYNC_APP_CODE_IS_RUNING);
        log.info("syncAppCodeInfo end");
    }
    
    
}
