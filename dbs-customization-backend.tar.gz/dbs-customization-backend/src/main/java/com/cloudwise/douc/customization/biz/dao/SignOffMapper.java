package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *
 * </p>
 *
 * @author abell.wu
 * @since 2024/12/26
 */
@Mapper
public interface SignOffMapper extends BaseMapper<SignOffEntity> {

}
