package com.cloudwise.douc.customization.biz.model.groupuser;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
public class ImplementerGroup implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // 用户组名称，作为唯一标识
    private String Group;
    
    // 用户组描述
    private String GroupDescription;
    
    private String GroupRole;
    
    private String GroupOwnerLogin;
    
    private String GroupOwnerEmail;
    
    private String GroupOwner;
    
    // 用户状态
    private String UserStatus;
    
    // 用户邮箱
    private String MemberEmail;
    
    // 用户手机号
    private String MemberMobile;
    
    // 用户姓名
    private String MemberName;
    
    // 成员1bankId
    private String MemberLogin;
    
    // appCode
    private String Appcode;
    
    // lob属性
    private String GroupLOB;
    
    // country属性
    private String GroupCountry;
    
}
