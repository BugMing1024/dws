package com.cloudwise.douc.customization.common.condition;

import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorRouteStrategyEnum;
import com.cloudwise.douc.customization.common.job.XxlJobInitService;
import com.cloudwise.douc.customization.common.model.XxlDataSetting;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * azureAd功能的开关
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024/1/12 1:06; update at 2024/1/12 1:06
 */
@Slf4j
public class SyncCheckCondition implements Condition {
    
    //    private static StringBuilder setting = new StringBuilder();
    //
    //    private static Set<String> names = new HashSet<>();
    
    @Override
    public boolean matches(ConditionContext conditionContext, AnnotatedTypeMetadata annotatedTypeMetadata) {
        Environment environment = conditionContext.getEnvironment();
        Map<String, Object> annotationAttributes = annotatedTypeMetadata.getAnnotationAttributes(
                "com.cloudwise.douc.customization.biz.anno.SyncEndpoint");
        Object o = annotationAttributes.get("name");
        if (o instanceof String) {
            String name = (String) o;
            // job中有的会进行加载，而tws中有的会进行停用
            String condition = environment.getProperty("condition.job.setting", "");
            String disabledCondition = environment.getProperty("condition.tws.setting", "");
            Set<String> collect = Arrays.stream(condition.split(",")).collect(Collectors.toSet());
            Set<String> disabledCollect = Arrays.stream(disabledCondition.split(",")).collect(Collectors.toSet());
            boolean contains = collect.contains(name);
            //            if (names.add(name)) {
            //                setting.append(name).append(",");
            //                log.error("condition.job.setting:{}", setting.toString());
            //            }
            if (contains) {
                XxlDataSetting setting = new XxlDataSetting();
                setting.setName(name);
                setting.setEnabled(!disabledCollect.contains(name));
                setting.setCron(annotationAttributes.get("cron").toString());
                setting.setRoute((ExecutorRouteStrategyEnum) annotationAttributes.get("route"));
                XxlJobInitService.jobs.add(setting);
            }
            return contains;
        }
        return false;
        
    }
}