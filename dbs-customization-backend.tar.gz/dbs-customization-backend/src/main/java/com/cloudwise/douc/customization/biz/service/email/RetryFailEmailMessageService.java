package com.cloudwise.douc.customization.biz.service.email;

/**
 * @author ming.ma
 * @since 2024-12-18  16:43
 **/
public interface RetryFailEmailMessageService {
    
    void retryFailEmailMessage();
    
    void sendDelayMessage();
}
