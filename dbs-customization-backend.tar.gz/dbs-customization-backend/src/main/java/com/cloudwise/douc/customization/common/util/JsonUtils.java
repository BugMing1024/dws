package com.cloudwise.douc.customization.common.util;

import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.ALWAYS;
import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.SerializationFeature.FAIL_ON_EMPTY_BEANS;
import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;

/**
 * jackson 封装工具类 主要是把 原生 ObjectMapper 的异常catch然后重新throw
 *
 * @author skiya
 * @date Created on 2021-11-25.
 */
@Slf4j
public class JsonUtils {

    public static final ObjectMapper mapper = new ObjectMapper()
            .configure(FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(WRITE_DATES_AS_TIMESTAMPS, false)
            .configure(FAIL_ON_EMPTY_BEANS, false)
            .setSerializationInclusion(ALWAYS);

    private static final ObjectMapper MAPPER;
    
    static {
        MAPPER = new ObjectMapper();
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        MAPPER.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        JacksonTypeHandler.setObjectMapper(mapper);
    }
    
    public static ObjectNode createObjectNode() {
        return MAPPER.createObjectNode();
    }
    
    public static ArrayNode createArrayNode() {
        return MAPPER.createArrayNode();
    }
    
    @SneakyThrows
    public static String toJsonStr(Object obj) {
        return MAPPER.writeValueAsString(obj);
    }
    
    @SneakyThrows
    public static String toJsonPrettyStr(Object obj) {
        return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
    }
    
    @SneakyThrows
    public static <T> T toBean(String jsonStr, Class<T> type) {
        return MAPPER.readValue(jsonStr, type);
    }
    
    @SneakyThrows
    public static <T> T toBean(String jsonStr, TypeReference<T> type) {
        return MAPPER.readValue(jsonStr, type);
    }
    
    public static <T> T toBean(ObjectNode objectNode, Class<T> type) {
        return MAPPER.convertValue(objectNode, type);
    }
    
    public static <T> T toBean(ObjectNode objectNode, TypeReference<T> type) {
        return MAPPER.convertValue(objectNode, type);
    }
    
    /**
     * 转化为 map
     */
    @SneakyThrows
    public static Map<String, Object> toMap(String jsonStr) {
        return MAPPER.readValue(jsonStr, new TypeReference<Map<String, Object>>() {
        });
    }
    
    /**
     * 转化为 list
     */
    @SneakyThrows
    public static <E> List<E> toList(String jsonStr, Class<E> type) {
        return MAPPER.readValue(jsonStr, MAPPER.getTypeFactory().constructCollectionType(List.class, type));
    }
    
    public static <E> List<E> toList(ArrayNode arrayNode, Class<E> type) {
        return MAPPER.convertValue(arrayNode, MAPPER.getTypeFactory().constructCollectionType(List.class, type));
    }
    
    public static JsonNode toJsonNode(Object obj) {
        return MAPPER.valueToTree(obj);
    }
    
    /**
     * 需要对象格式 json,否则抛出ClassCastException
     */
    public static ObjectNode toObjectNode(String jsonStr) {
        return (ObjectNode) toJsonNode(jsonStr);
    }
    
    @SneakyThrows
    public static JsonNode toJsonNode(String jsonStr) {
        return MAPPER.readTree(jsonStr);
    }
    
    /**
     * 需要数组格式 json,否则抛出ClassCastException
     */
    public static ArrayNode toArrayNode(String jsonStr) {
        return (ArrayNode) toJsonNode(jsonStr);
    }

    public static <T> List<T> parseArray(Object object, Class<T> clazz) {
        try {
            if(object == null) {
                return null;
            }
            JavaType javaType = mapper.getTypeFactory().constructParametricType(ArrayList.class, clazz);
            if(object instanceof String) {
                try {
                    return mapper.readValue((String) object, javaType);
                } catch(Exception e) {
                    log.error("parse string to list error, param:{}", object, e);
                }
            }

            return mapper.readValue(mapper.writeValueAsString(object), javaType);
        } catch(Exception e) {
            log.error("parse object to list error, param:{}", object, e);
            return null;
        }
    }

    public static <T> T parseObject(String json, Class<T> clazz) {
        try {
            return mapper.readValue(json, clazz);
        } catch (Exception e) {
            log.debug("String conversion Object failed", e);
            log.info(json, e);
        }
        return null;
    }

    public static Map<String, Object> parseObject(Object object) {
        try {
            if(object == null) {
                return null;
            }

            TypeReference<Map<String, Object>> typeReference = new TypeReference<Map<String, Object>>() {};
            if(object instanceof String) {
                try {
                    return mapper.readValue((String) object, typeReference);
                } catch(Exception e) {
                    log.error("parse string to map error, param:{}", object, e);
                }
            }
            return mapper.readValue(toJsonValueString(object), typeReference);
        } catch(Exception e) {
            log.error("parse object to map error, param:{}", object, e);
            return null;
        }
    }

    public static String toJsonValueString(Object object) {
        try {
            if(object == null) {
                return null;
            }
            return mapper.writeValueAsString(object);
        } catch(Exception e) {
            log.debug("Object conversion JSON String failed", e);
        }
        return null;
    }




}
