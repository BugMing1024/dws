package com.cloudwise.douc.customization.biz.facade.user;


import lombok.Data;

@Data
public class UserRoleInfo {
    
    
    /**
     * 角色id
     */
    private int roleId;
    
    /**
     * 角色名称
     */
    private String name;
    
    /**
     * 角色类型
     */
    private String type;
    
    /**
     * 角色组id
     */
    private String roleGroupId;
    
}
