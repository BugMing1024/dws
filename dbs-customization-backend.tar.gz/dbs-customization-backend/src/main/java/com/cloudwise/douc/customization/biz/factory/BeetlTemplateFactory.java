package com.cloudwise.douc.customization.biz.factory;

import lombok.extern.slf4j.Slf4j;
import org.beetl.core.Configuration;
import org.beetl.core.GroupTemplate;
import org.beetl.core.resource.StringTemplateResourceLoader;

import java.util.Optional;

@Slf4j
public class BeetlTemplateFactory {
    
    private volatile static BeetlTemplateFactory singleton = null;
    
    static {
        BeetlTemplateFactory.getInstance();
    }
    
    private GroupTemplate groupTemplate;
    
    /**
     * 触发器通知模版工厂  为了获取单例
     */
    public BeetlTemplateFactory() {
        if (singleton == null) {
            synchronized (BeetlTemplateFactory.class) {
                try {
                    if (singleton == null) {
                        groupTemplate = new GroupTemplate(new StringTemplateResourceLoader(), Configuration.defaultConfiguration());
                    }
                } catch (Exception ex) {
                    log.error("triggerNotifyTemplateFactory init error", ex);
                }
            }
        }
    }
    
    /**
     * 初始化
     *
     * @return
     */
    public static BeetlTemplateFactory getInstance() {
        if (!Optional.ofNullable(singleton).isPresent()) {
            synchronized (BeetlTemplateFactory.class) {
                if (!Optional.ofNullable(singleton).isPresent()) {
                    singleton = new BeetlTemplateFactory();
                }
            }
        }
        return singleton;
    }
    
    public GroupTemplate getGroupTemplate() {
        return singleton.groupTemplate;
    }
}

