package com.cloudwise.douc.customization.biz.util;

import cn.hutool.core.collection.CollectionUtil;
import com.cloudwise.douc.customization.biz.model.email.dosm.Nodes;
import com.cloudwise.douc.customization.biz.model.email.dosm.TaskInfo;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;

/**
 * @author ming.ma
 * @since 2024-12-11  14:53
 **/
public class DosmUtil {
    
    public static String getTaskId(WorkOrderDetail workorderDetail) {
        if (CollectionUtil.isEmpty(workorderDetail.getNodeIdsMap())) {
            return "";
        }
        Nodes nodes = workorderDetail.getNodeIdsMap().get(0);
        if (nodes == null || CollectionUtil.isEmpty(nodes.getTaskInfoList())) {
            return "";
        }
        TaskInfo taskInfo = nodes.getTaskInfoList().get(0);
        return taskInfo.getTaskId();
    }
}
