package com.cloudwise.douc.customization.biz.facade.impl;

import com.cloudwise.douc.customization.biz.facade.UserGroupService;
import com.cloudwise.douc.customization.biz.facade.user.GroupUserInfo;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboGroupIdReq;
import com.cloudwise.douc.facade.UserGroupV2DubboFacade;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author ming.ma
 * @since 2024-12-19  19:59
 **/
@Service
@Slf4j
public class UserGroupServiceImpl implements UserGroupService {
    
    @Autowired
    private Gson gson;
    
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", cache = "expiringCaffeine", parameters = {
            "cache.seconds=30"}, url = "rest://${rest.svc.douc:}")
    private UserGroupV2DubboFacade userGroupV2DubboFacade;
    
    
    @Override
    public DubboCommonResp<GroupUserInfo> getUserGroupInfoById(DubboGroupIdReq req) {
        DubboCommonResp<GroupUserInfo> result;
        log.info("Request userGroupV2DubboFacade.getUserGroupInfoById start,params:{}", req);
        try {
            DubboCommonResp<String> userGroupListStr = userGroupV2DubboFacade.getUserGroupInfoById(req);
            if (!userGroupListStr.isSuccess()) {
                result = new DubboCommonResp<GroupUserInfo>().generateFailResp();
                result.setMsg(userGroupListStr.getMsg());
                return result;
            }
            GroupUserInfo groupUserInfo = gson.fromJson(userGroupListStr.getData(), GroupUserInfo.class);
            result = new DubboCommonResp<GroupUserInfo>().generateSuccessResp(groupUserInfo);
            log.info("Request  getUserGroupInfoById success:{}", userGroupListStr);
            
        } catch (Exception e) {
            
            result = new DubboCommonResp<GroupUserInfo>().generateFailResp();
            log.error("Request userGroupV2DubboFacade.getUserGroupInfoById failed,cause by:{}", e);
        }
        
        return result;
    }
}
