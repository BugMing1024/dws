package com.cloudwise.douc.customization.biz.model.email.dosm;

import cn.hutool.core.util.ObjectUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 节点处理方式
 *
 * @Author frank.zheng
 * @Since 2021-06-10 16:29
 */
public enum NodeHandlerTypeEnum {
    
    SINGLE_PROCESSING("单人处理"),
    MULTI_PROCESSING("多人处理"),
    SEQUENCE_HANDLE("依次处理"),
    FREE_PROCESSING("任意处理"),
    ;
    
    private final static NodeHandlerTypeEnum[] ENUMS = NodeHandlerTypeEnum.values();
    
    private final static List<Map<String, String>> ENUM_MAP_LIST = new ArrayList<>();
    
    static {
        for (NodeHandlerTypeEnum nodeType : ENUMS) {
            Map<String, String> enumMap = new HashMap<>();
            enumMap.put("key", nodeType.name());
            enumMap.put("value", nodeType.getDesc());
            ENUM_MAP_LIST.add(enumMap);
        }
    }
    
    private String desc;
    
    NodeHandlerTypeEnum(String desc) {
        this.desc = desc;
    }
    
    /**
     * 获取 key-value 集合
     *
     * @return
     */
    public final static List<Map<String, String>> getList() {
        return ENUM_MAP_LIST;
    }
    
    public final static boolean isSingleProcessing(NodeHandlerTypeEnum type) {
        return ObjectUtil.equal(type, NodeHandlerTypeEnum.SINGLE_PROCESSING);
    }
    
    public final static String getApproveMapingName(NodeHandlerTypeEnum type) {
        if (ObjectUtil.isNull(type)) {
            return null;
        }
        //MULTI_PROCESSING = 并签方式  SEQUENCE_HANDLE =  串签方式  SINGLE_PROCESSING = 单人审批
        if (type == NodeHandlerTypeEnum.MULTI_PROCESSING) {
            return "并行会签";
        }
        if (type == NodeHandlerTypeEnum.SEQUENCE_HANDLE) {
            return "串签方式";
        }
        return null;
    }
    
    public String getDesc() {
        return desc;
    }
    
    
}
