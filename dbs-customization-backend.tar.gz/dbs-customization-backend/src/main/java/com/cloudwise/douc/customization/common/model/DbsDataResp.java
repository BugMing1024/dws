package com.cloudwise.douc.customization.common.model;

import cn.hutool.core.annotation.Alias;
import lombok.Data;

/**
 * 响应信息
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-12 18:32; update at 2024-12-12 18:32
 */
@Data
public class DbsDataResp<T> {
    
    @Alias("Code")
    private String Code;
    
    @Alias("Data")
    private T Data;
    
    @Alias("Message")
    private String Message;
    
}
