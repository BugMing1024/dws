package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SubmitWorkorderBean {
    
    private String taskId;
    
    private String nodeId;
    
    private String nodeName;
    
    private String workOrderId;
    
    private int workOrderSource;
    
    private String bizKey;
    
    private boolean authorized;
    
    private String mdlDefCode;
    
    private String formId;
    
    private boolean isCheckFlag;
    
    private SubmitWorkorderDataBean data;
    
    private String processInstanceId;
    
    private String rejectTo;
    
    /**
     * 驳回原因， 数据字典
     */
    private String reason;
    
    /**
     * 原因
     */
    private String remark;
    
}