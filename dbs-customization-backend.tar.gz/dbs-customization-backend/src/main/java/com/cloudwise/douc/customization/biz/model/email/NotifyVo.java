package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-05  14:52
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotifyVo implements Serializable {

    private NotifyWayEnum channelType = NotifyWayEnum.EMAIL;
    
    /**
     * 通知场景
     */
    private NotifyScenceEnum notifyScene;
    
    /**
     * 标题
     */
    private ValueContent title;
    
    /**
     * 内容
     */
    private ValueContent content;
    
    /**
     * 接收人
     */
    private List<ValueContent> receivers;
    
    
    /**
     * 抄送人
     */
    private List<ValueContent> csReceivers;
    
    /**
     * 附件
     */
    private ValueContent uploadFiles;
}
