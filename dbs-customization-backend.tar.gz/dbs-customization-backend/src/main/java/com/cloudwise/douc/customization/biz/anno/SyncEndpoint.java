package com.cloudwise.douc.customization.biz.anno;

import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorRouteStrategyEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 业务标识注解
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-09 00:19; update at 2024-12-09 00:19
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface SyncEndpoint {
    
    String name();
    
    String cron() default "0 0 0 * * ?";
    
    ExecutorRouteStrategyEnum route() default ExecutorRouteStrategyEnum.RANDOM;
    
}
