package com.cloudwise.douc.customization.biz.service.msg.utils;

import cn.hutool.core.io.FileUtil;
import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.nio.charset.StandardCharsets;

/**
 * @author ming.ma
 * @since 2024-12-06  17:29
 **/
@Slf4j
public class SmsTemplateUtil {

    private static final String PATH = "sms/";

    private static final String SUFFIX = ".txt";

    public static String get(String name) {
        NotifyScenceEnum notifyScence = EnumUtils.getEnum(NotifyScenceEnum.class, name);
        if (notifyScence == null) {
            log.info("Not found email scene:[{}]", name);
            return "";
        }

        return get(notifyScence);
    }


    public static String get(NotifyScenceEnum notifyScence) {
        try {
            ClassPathResource classPathResource = new ClassPathResource(PATH + notifyScence.getFileName() + SUFFIX);
            log.info("Get sms template path:{}", classPathResource.getPath());
            File file = classPathResource.getFile();
            return FileUtil.readString(file, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.info("Get sms template fail:", e);
        }
        return null;
    }

}
