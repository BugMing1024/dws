package com.cloudwise.douc.customization.common.config.jackson.desen;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
public interface Desensitization {
    
    String desensitize(String source);
}
