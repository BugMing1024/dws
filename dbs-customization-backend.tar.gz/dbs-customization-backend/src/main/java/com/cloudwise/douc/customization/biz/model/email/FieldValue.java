package com.cloudwise.douc.customization.biz.model.email;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ming.ma
 * @since 2024-12-05  15:05
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldValue implements Serializable {
    
    /**
     * 表单字段名称
     */
    private String name;
    
    /**
     * 字段类型
     */
    private String type;
    
    /**
     * 邮箱字段
     */
    private String emailKey;
    
    /**
     * 固定值
     */
    private NormalValue value;
}
