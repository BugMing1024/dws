package com.cloudwise.douc.customization.biz.resync;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import com.cloudwise.douc.customization.biz.facade.DoucBaseFacade;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.exception.DoucFailedSyncResult;
import com.cloudwise.douc.customization.common.exception.DoucSyncException;
import com.cloudwise.douc.dto.DubboAddUserDepartmentInfo;
import com.cloudwise.douc.dto.DubboUpdateUser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class ReSyncEmpAspect {
    
    private final static List<String> DUPLICATE_OR_ERROR_MOBILE = ListUtil.of("110007", "111000");
    
    private final static String DUPLICATE_EMAIL_ERROR_CODE = "110006";
    
    private final static List<String> ORG_DISABLED_OR_NOT_EXISTED = ListUtil.of("110026", "130197");
    
    private final DoucProperties doucProperties;
    
    private final DoucBaseFacade doucBaseFacade;
    
    /**
     * 切入点：addOrUpdateUsers()方法
     */
    @Pointcut("execution(* com.cloudwise.douc.customization.biz.facade.DoucBaseFacade.addOrUpdateUsers(..))")
    public void pointCut() {
    }
    
    @Around("pointCut() && args(dubboUpdateUsers)")
    public Object handleDataSyncException(ProceedingJoinPoint joinPoint, List<DubboUpdateUser> dubboUpdateUsers) throws Throwable {
        try {
            return joinPoint.proceed();
        } catch (DoucSyncException e) {
            
            Collection<DoucFailedSyncResult> reSyncResults = e.getSyncResults();
            Collection<DoucFailedSyncResult> reThrowResults = CollUtil.newHashSet();
            
            Collection<String> resetMobileEmpIds = CollUtil.newHashSet();
            Collection<String> resetEmailEmpIds = CollUtil.newHashSet();
            Collection<String> resetOrgEmpIds = CollUtil.newHashSet();
            
            for (DoucFailedSyncResult syncResult : reSyncResults) {
                if (DUPLICATE_OR_ERROR_MOBILE.contains(syncResult.getCode())) {
                    resetMobileEmpIds.addAll(syncResult.getFailIds());
                } else if (DUPLICATE_EMAIL_ERROR_CODE.equals(syncResult.getCode())) {
                    resetEmailEmpIds.addAll(syncResult.getFailIds());
                } else if (ORG_DISABLED_OR_NOT_EXISTED.contains(syncResult.getCode())) {
                    resetOrgEmpIds.addAll(syncResult.getFailIds());
                } else {
                    reThrowResults.add(syncResult);
                }
            }
            
            List<DubboUpdateUser> resetMobileEmp = CollUtil.newArrayList();
            List<DubboUpdateUser> resetEmailEmp = CollUtil.newArrayList();
            List<DubboUpdateUser> resetOrgEmp = CollUtil.newArrayList();
            for (DubboUpdateUser user : dubboUpdateUsers) {
                String userCode = user.getUserCode();
                if (resetMobileEmpIds.contains(userCode)) {
                    user.setMobile(null);
                    resetMobileEmp.add(user);
                } else if (resetEmailEmpIds.contains(userCode)) {
                    user.setEmail(null);
                    resetEmailEmp.add(user);
                } else if (resetOrgEmpIds.contains(userCode)) {
                    DubboAddUserDepartmentInfo departmentInfo = new DubboAddUserDepartmentInfo();
                    departmentInfo.setIsMainDepartment(true);
                    departmentInfo.setDepartmentCode(doucProperties.getDefaultOrgCode());
                    user.setDepartmentInfo(ListUtil.of(departmentInfo));
                    resetOrgEmp.add(user);
                }
            }
            
            if (CollUtil.isNotEmpty(resetMobileEmp)) {
                log.info("duplicate or error mobile, reset to null: {}",
                        resetMobileEmp.stream().map(DubboUpdateUser::getUserCode).collect(Collectors.toList()));
                doucBaseFacade.addOrUpdateUsers(resetMobileEmp);
            }
            
            if (CollUtil.isNotEmpty(resetEmailEmp)) {
                log.info("duplicate email, reset to null: {}", resetEmailEmp.stream().map(DubboUpdateUser::getUserCode).collect(Collectors.toList()));
                doucBaseFacade.addOrUpdateUsers(resetEmailEmp);
            }
            
            if (CollUtil.isNotEmpty(resetOrgEmp)) {
                log.info("error org code, reset to default org: {}",
                        resetOrgEmp.stream().map(DubboUpdateUser::getUserCode).collect(Collectors.toList()));
                doucBaseFacade.addOrUpdateUsers(resetOrgEmp);
            }
            
            if (CollUtil.isNotEmpty(reThrowResults)) {
                throw new DoucSyncException(reThrowResults);
            }
            
            return null;
        }
    }
}
