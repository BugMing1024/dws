package com.cloudwise.douc.customization.biz.config;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.util.HttpUtils;
import com.google.common.collect.Maps;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitConfig {
    
    @Value("${rest.svc.douc:}")
    private String restSvcDouc;
    
    private final DoucProperties doucProperties;
    
    @PostConstruct
    public void init() {
        log.info("init data start...");
        try {
            List<String> initInitType = doucProperties.getInitInitType();
            // dubbo url
            String initDoucDubboUrl = StrUtil.blankToDefault(doucProperties.getInitDoucDubboUrl(), restSvcDouc);
            // dubbo header
            Map<String, String> dubboHeaders = Maps.newHashMapWithExpectedSize(3);
            dubboHeaders.put("content-type", "application/json");
            dubboHeaders.put("rest-service-group", "DOUC_RPC_DUBBO");
            dubboHeaders.put("rest-service-version", "1.0.0");
            // http url
            String initDoucHttpUrl = doucProperties.getInitDoucHttpUrl();
            // http header
            Map<String, String> httpHeaders = Maps.newHashMapWithExpectedSize(4);
            httpHeaders.put("content-type", "application/json");
            httpHeaders.put("userId", "1");
            httpHeaders.put("accountId", "110");
            httpHeaders.put("username", "admin");
            initInitType.forEach(type -> {
                log.info("initializing {}", type);
                switch (type) {
                    case "dic_type":
                        Optional<String> post = HttpUtils.post(initDoucDubboUrl + "/douc/dubbo/baseInfoV2/addOrUpdateDicType",
                                JSONUtil.parseArray(doucProperties.getInitDicTypeParam()), dubboHeaders);
                        post.ifPresent(resp -> {
                            log.info("initializing dic_type resp={}", resp);
                        });
                        break;
                    case "dic_data":
                        Optional<String> post1 = HttpUtils.post(initDoucDubboUrl + "/douc/dubbo/baseInfoV2/addOrUpdateDic",
                                JSONUtil.parseArray(doucProperties.getInitDicDataParam()), dubboHeaders);
                        post1.ifPresent(resp -> {
                            log.info("initializing dic_data resp={}", resp);
                        });
                        break;
                    case "ext_user":
                    case "ext_group":
                        Optional<String> post2 = HttpUtils.get(initDoucHttpUrl + "/douc/api/v1/dic/typeList", null, httpHeaders);
                        post2.ifPresent(resp -> {
                            log.info("initializing ext_user all type resp={}", resp);
                            String paramStr = "";
                            if ("ext_user".equalsIgnoreCase(type)) {
                                paramStr = doucProperties.getInitExtUserParam();
                            }
                            if ("ext_group".equalsIgnoreCase(type)) {
                                paramStr = doucProperties.getInitExtGroupParam();
                            }
                            JSONArray data = JSONUtil.parseObj(resp).getJSONArray("data");
                            for (Object obj : data) {
                                String code = JSONUtil.parseObj(obj).getStr("code");
                                String id = JSONUtil.parseObj(obj).getStr("id");
                                for (String targetCode : doucProperties.getInitRelaGroupDicTypeParam()) {
                                    if (targetCode.equalsIgnoreCase(code)) {
                                        paramStr = StrUtil.replace(paramStr, "#{" + code + "}", id);
                                    }
                                }
                            }
                            JSONUtil.parseArray(paramStr).forEach(o -> {
                                Optional<String> post3 = HttpUtils.post(initDoucHttpUrl + "/douc/api/v1/extend/addExtendConf", JSONUtil.parseObj(o),
                                        httpHeaders);
                                post3.ifPresent(resp1 -> {
                                    log.info("initializing ext_user resp={}", resp1);
                                });
                            });
                        });
                        break;
                    case "role_group":
                        Optional<String> post4 = HttpUtils.post(initDoucDubboUrl + "/douc/dubbo/roleV3/addOrUpdateRoleGroup",
                                JSONUtil.parseArray(doucProperties.getInitRoleGroupParam()), dubboHeaders);
                        post4.ifPresent(resp -> {
                            log.info("initializing role_group resp={}", resp);
                        });
                        break;
                    case "role":
                        Optional<String> post5 = HttpUtils.post(initDoucDubboUrl + "/douc/dubbo/roleV3/addOrUpdateRole",
                                JSONUtil.parseArray(doucProperties.getInitRoleParam()), dubboHeaders);
                        post5.ifPresent(resp -> {
                            log.info("initializing role resp={}", resp);
                        });
                        break;
                    case "group":
                        Optional<String> post6 = HttpUtils.post(initDoucDubboUrl + "/douc/dubbo/groupV3/addOrUpdateUserGroup",
                                JSONUtil.parseArray(doucProperties.getInitGroupParam()), dubboHeaders);
                        post6.ifPresent(resp -> {
                            log.info("initializing group resp={}", resp);
                        });
                        break;
                    case "group_cust":
                        Optional<String> post7 = HttpUtils.post(initDoucDubboUrl + "/douc/dubbo/groupV3/getGroupByCondition",
                                JSONUtil.parseObj(doucProperties.getInitGroupSearchParam()), dubboHeaders);
                        post7.ifPresent(resp -> {
                            log.info("initializing group_cust all group resp={}", resp);
                            String paramStr = doucProperties.getInitGroupCustParam();
                            JSONArray records = JSONUtil.parseObj(resp).getJSONObject("data").getJSONArray("records");
                            for (Object obj : records) {
                                String code = JSONUtil.parseObj(obj).getStr("code");
                                String id = JSONUtil.parseObj(obj).getStr("id");
                                for (String targetCode : doucProperties.getInitRelaGroupCustCodeParam()) {
                                    if (targetCode.equalsIgnoreCase(code)) {
                                        paramStr = StrUtil.replace(paramStr, "#{" + code + "}", id);
                                    }
                                }
                            }
                            JSONUtil.parseArray(paramStr).forEach(o -> {
                                Optional<String> post8 = HttpUtils.post(initDoucHttpUrl + "/douc/api/v1/group/saveOrUpdateGroupCustomConditionInfo",
                                        JSONUtil.parseObj(o), httpHeaders);
                                post8.ifPresent(resp1 -> {
                                    log.info("initializing group_cust resp={}", resp1);
                                });
                            });
                        });
                        break;
                    default:
                }
            });
        } catch (Exception e) {
            log.error("init data error", e);
        }
        log.info("init data end...");
    }
}
