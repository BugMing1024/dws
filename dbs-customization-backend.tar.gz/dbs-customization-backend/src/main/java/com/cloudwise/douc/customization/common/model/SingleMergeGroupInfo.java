package com.cloudwise.douc.customization.common.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 实时同步接收实体
 */
@Data
public class SingleMergeGroupInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // 组信息
    private String Group;
    
    private String GroupDescription;
    
    private String GroupLOB;
    
    private String GroupCountry;
    
    private String GroupRank;
    
    private String GroupOwnerEmail;
    
    // 角色
    private String GroupRole;
    
    // 人员
    private String MemberEmail;
    
    private String MemberName;
    
    private String MemberMobile;
    
    private String Member1bankId;
    
    private String MemberTSOId;
}
