package com.cloudwise.douc.customization.biz.enums;


public interface SignoffConstants {




    enum SignoffType {
        TESTING_SIGNOFF("TestingSignoff"),
        PROCUTOVER_SIGNOFF("ProCutoverSignoff"),
        OTHER_SIGNOFFS("OtherSignoffs"),
        OPTIONAL_ARTEFACTS("OptionalArtefacts"),
        HEIGHTENED_SIGNOFF("HeightenedSignoff");

        private final String type;

        SignoffType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public static SignoffType fromString(String text) {
            for (SignoffType signoffType : SignoffType.values()) {
                if (signoffType.getType().equalsIgnoreCase(text)) {
                    return signoffType;
                }
            }
            throw new IllegalArgumentException("No constant with text " + text + " found");
        }
    }


    enum SignoffItem {
        USER_ACCEPTANCE_TESTING("User Acceptance Testing (UAT)", SignoffType.TESTING_SIGNOFF, true),
        REGRESSION_TESTING("Regression Testing", SignoffType.TESTING_SIGNOFF, true),
        REVERSION_BACKOUT_ROLLBACK_TESTING("Reversion / Backout / Rollback Testing", SignoffType.TESTING_SIGNOFF, true),
        PERFORMANCE_TESTING("Performance Testing", SignoffType.TESTING_SIGNOFF, true),
        PRODUCTION_ASSURANCE_TESTING("Production Assurance Testing", SignoffType.TESTING_SIGNOFF, true),
        CHAOS_TESTING("Chaos Testing", SignoffType.TESTING_SIGNOFF, true),


        HA_DR_FLIP_SIGNOFF("HA & DR Flip Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        MD_DELEGATE_SIGNOFF("MD Delegate Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        BU_APPLICATION_OWNER_SIGNOFF("BU/Application Owner Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        DATA_CENTER_OPS_BATCH_SIGNOFF("Data Center OPS (Batch) Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        IMPACT_TO_MAINFRAME_SIGNOFF("Impact To Mainframe Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        DESIGN_FOR_DATA_D4D_SIGNOFF("Design For Data (D4D) Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        SERVICE_MONITORING_AT_SNOC("Service Monitoring at SNOC", SignoffType.PROCUTOVER_SIGNOFF, false),
        CUS_SIGNOFF("CUS Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),
        IDR_SIGNOFF_PROCUTOVER("IDR Signoff", SignoffType.PROCUTOVER_SIGNOFF, false),

        IDR_SIGNOFF_OTHER("IDR Signoff", SignoffType.OTHER_SIGNOFFS, true),
        ISS_SIGNOFF("ISS Signoff", SignoffType.OTHER_SIGNOFFS, true),
        CODE_CHECKER_SIGNOFF("Code Checker Signoff", SignoffType.OTHER_SIGNOFFS, true),
        DR_TEAM_SIGNOFF("DR team Signoff", SignoffType.OTHER_SIGNOFFS, true),
        STORAGE_TEAM_SIGNOFF("Storage team Signoff", SignoffType.OTHER_SIGNOFFS, true),
        DCON_SIGNOFF("DCON Signoff", SignoffType.OTHER_SIGNOFFS, true),
        LV_SIGNOFF("LV Signoff", SignoffType.OTHER_SIGNOFFS, true),
        IMPLEMENTATION_CHECKER_SIGNOFF("Implementation Checker Signoff", SignoffType.OTHER_SIGNOFFS, true),


        HEIGHTENED_HEIGHTENED_PERIOD_RELATED_ARTEFACTS("Heightened/Heightened Period Related Artefacts", SignoffType.OPTIONAL_ARTEFACTS, true),
        ADDITIONAL_TECH_MD_TECH_MD_DELEGATE_APPROVAL("Additional Tech MD/Tech MD Delegate Approval", SignoffType.OPTIONAL_ARTEFACTS, true),
        COMPLIANCE_RELATED_ARTEFACTS("Compliance Related Artefacts", SignoffType.OPTIONAL_ARTEFACTS, true),
        UNAUTHORIZED_CHANGE_REPORT_DOCS("Unauthorized Change Report/ Docs", SignoffType.OPTIONAL_ARTEFACTS, true),

        ARC_SIGNOFF("ARC Signoff", SignoffType.HEIGHTENED_SIGNOFF, true),
        LOBT_CHANGE_MANAGERS_CONCURRENCE("LOBT Change managers' concurrence", SignoffType.HEIGHTENED_SIGNOFF, true),
        CTO_S_APPROVALS_INFRA_AND_APP("CTO's approvals (infra and app)", SignoffType.HEIGHTENED_SIGNOFF, true);

        private final String name;
        private final SignoffType type;

        public Boolean getAffectStatus() {
            return affectStatus;
        }

        private final Boolean affectStatus;

        SignoffItem(String name, SignoffType type, Boolean affectStatus) {
            this.name = name;
            this.type = type;
            this.affectStatus = affectStatus;
        }

        public String getName() {
            return name;
        }

        public SignoffType getType() {
            return type;
        }

        public static SignoffItem fromString(String signOffGroup, String signOffType) {
            for (SignoffItem signoffItem : SignoffItem.values()) {
                if (signoffItem.getName().equalsIgnoreCase(signOffType) && signoffItem.getType().getType().equalsIgnoreCase(signOffGroup)) {
                    return signoffItem;
                }
            }
            throw new IllegalArgumentException("No constant with text " + signOffType + " found");
        }
    }
}
