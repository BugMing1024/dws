package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.douc.customization.biz.model.rca.DbsRcaApplicationPending;
import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

/**
 * <p>
 *
 * </p>
 *
 * @author abell.wu
 * @since 2024/12/26
 */
@Mapper
public interface DbsRcaApplicationPendingMapper extends BaseMapper<DbsRcaApplicationPending> {

    @Update("UPDATE dbs_rca_application_pending SET is_pending = true WHERE DATE(last_pending_time) < CURRENT_DATE")
    void updateRcaPendingApplication();
}
