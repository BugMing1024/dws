package com.cloudwise.douc.customization.biz.model.email.dosm;

/**
 * 审批类型
 *
 * @author jon.lee
 * @since 2022-05-14 16:06
 **/
public enum ApproveBehaviorTypeEnum {
    /**
     * 通过
     */
    PASS,
    /**
     * 驳回
     */
    REJECT,
    /**
     * 自动通过
     */
    
    AUTO_PASS;
    
    public static boolean supportBatch(ApproveBehaviorTypeEnum behavior) {
        return behavior == ApproveBehaviorTypeEnum.PASS || behavior == ApproveBehaviorTypeEnum.REJECT;
    }
    
    public static boolean isPass(ApproveBehaviorTypeEnum behavior) {
        return behavior == ApproveBehaviorTypeEnum.PASS || behavior == ApproveBehaviorTypeEnum.AUTO_PASS;
    }
}
