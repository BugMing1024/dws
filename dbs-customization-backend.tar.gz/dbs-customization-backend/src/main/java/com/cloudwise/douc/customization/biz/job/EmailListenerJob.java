package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.service.email.EmailTicketingJobService;
import com.cloudwise.douc.customization.biz.service.email.RetryFailEmailMessageService;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * emailticket拆分出来的类
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2025-02-09 21:38; update at 2025-02-09 21:38
 */
@Slf4j
@RestController()
@SyncEndpoint(name = Constants.EMAIL_LISTENER_JOB, cron = Constants.EMAIL_LISTENER_JOB_CRON)
@RequestMapping(Constants.EMAIL_LISTENER_JOB)
@Conditional(value = SyncCheckCondition.class)
public class EmailListenerJob {
    
    @Autowired
    private RetryFailEmailMessageService retryFailEmailMessageService;
    
    @Autowired
    private EmailTicketingJobService emailTicketingJobService;
    
    @XxlJob(Constants.EMAIL_LISTENER_JOB)
    @RequestMapping("/sync")
    public void retryFailEmailMessage() {
        log.info("邮件监听任务开始执行");
        String param = XxlJobHelper.getJobParam();
        emailTicketingJobService.readEmail(param);
        log.info("邮件监听定时任务执行结束");
    }
}
