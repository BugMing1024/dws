package com.cloudwise.douc.customization.biz.facade;

import com.cloudwise.douc.customization.biz.facade.user.GroupUserInfo;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboGroupIdReq;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @author ming.ma
 * @since 2024-12-19  19:56
 **/
@Component
public class UserGroupSSOClient {
    
    private final String INTERNAL = "internal";
    
    @Autowired
    DosmConfig dosmConfig;
    
    @Autowired
    UserGroupService userGroupService;
    
    
    /**
     * 入参说明 : groupId 必填 isContainUser 非 默认false
     */
    public GroupUserInfo getUserGroupInfoById(Long groupId, Boolean isContainUser, String groupScope) {
        DubboGroupIdReq req = new DubboGroupIdReq();
        req.setAccountId(Long.valueOf(dosmConfig.getAccountId()));
        req.setUserId(Long.valueOf(dosmConfig.getUserId()));
        req.setGroupId(groupId);
        req.setContainUser(isContainUser);
        if (null == groupScope) {
            req.setGroupScope(INTERNAL);
        } else {
            req.setGroupScope(groupScope);
        }
        return Optional.ofNullable(userGroupService.getUserGroupInfoById(req)).map(DubboCommonResp::getData).orElse(null);
    }
}
