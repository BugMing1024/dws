package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.enums.CrApprovalEnum;
import lombok.Data;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-27  16:37
 **/
@Data
public class ApproveRecordConfigVo {

    private boolean displaySendForApprovalBtn;

    private String nodeId;

    private String nodeName;

    private String groupProcess;

    private String groupName;

    private String approveResult;

    private List<ApproverUser> approvers;

    private String status = CrApprovalEnum.PENDING_APPROVAL.getName();

    List<UserApproveRecord> userApproveRecords;

    private boolean followUser;
    /**
     * Is it the first node
     */
    private boolean firstNode;


}
