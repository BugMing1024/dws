package com.cloudwise.douc.customization.common.config.jackson.desen.impl;

import cn.hutool.core.util.DesensitizedUtil;
import com.cloudwise.douc.customization.common.config.jackson.desen.Desensitization;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
public class PasswordDesensitization implements Desensitization {
    
    @Override
    public String desensitize(String source) {
        return DesensitizedUtil.password(source);
    }
}
