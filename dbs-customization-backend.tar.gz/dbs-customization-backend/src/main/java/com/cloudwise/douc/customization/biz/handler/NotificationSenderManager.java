package com.cloudwise.douc.customization.biz.handler;

import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.model.email.MessageVo;
import com.cloudwise.douc.customization.biz.service.msg.MessageSender;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentMap;

/**
 * @author ming.ma
 * @since 2025-01-07  14:15
 **/
@Slf4j
@Component
public class NotificationSenderManager {
    private final ConcurrentMap<String, MessageSender<MessageVo>> senders = Maps.newConcurrentMap();

    @Autowired(required = false)
    public void setNotificationSenders(List<MessageSender> notificationSenders) {
        for (MessageSender notificationSender : notificationSenders) {
            senders.putIfAbsent(notificationSender.notifyWay(), notificationSender);
        }
    }

    public CompletableFuture<Integer> send(MessageVo messageVo) {
        NotifyWayEnum notifyWay = messageVo.getNotifyWay();
        if (notifyWay == null) {
            return CompletableFuture.completedFuture(0);
        }
        MessageSender<MessageVo> messageSender = senders.get(notifyWay.name());
        return messageSender.sendV2(messageVo);
    }

}
