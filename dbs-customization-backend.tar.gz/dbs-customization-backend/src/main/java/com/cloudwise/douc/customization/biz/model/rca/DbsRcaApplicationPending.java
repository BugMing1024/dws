package com.cloudwise.douc.customization.biz.model.rca;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author abell.wu
 */
@TableName("dbs_rca_application_pending")
@Data
public class DbsRcaApplicationPending {

    private Date createdTime;

    private Date lastPendingTime;

    private String applicationName;

    private String crWorkOrderId;

    private String rcaWorkOrderId;

    private Boolean isPending;


}
