package com.cloudwise.douc.customization.common.exception;

import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
public class DoucSyncException extends RuntimeException {
    
    private final Collection<DoucFailedSyncResult> syncResults;
    
    public DoucSyncException(Collection<DoucFailedSyncResult> results) {
        this.syncResults = results;
    }
    
    public Collection<String> getAllFailIds() {
        if (syncResults == null) {
            return new ArrayList<>();
        }
        return this.syncResults.stream().flatMap(result -> result.getFailIds().stream()).collect(Collectors.toList());
    }
    
    public Collection<DoucFailedSyncResult> getSyncResults() {
        return this.syncResults;
    }
    
    @Override
    public String getMessage() {
        return this.syncResults.stream().map(DoucFailedSyncResult::getMessage).collect(Collectors.joining(";"));
    }
}
