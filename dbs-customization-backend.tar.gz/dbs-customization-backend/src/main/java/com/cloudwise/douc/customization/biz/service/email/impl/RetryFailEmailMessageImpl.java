package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.json.JSONUtil;
import com.cloudwise.dosm.api.bean.form.DateRange;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.api.bean.form.field.DateRangeField;
import com.cloudwise.dosm.api.bean.form.field.FieldValue;
import com.cloudwise.dosm.api.bean.form.field.SelectField;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.biz.model.table.CustomDelayMessageRecord;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomDelayMessageRecordService;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.biz.service.email.RetryFailEmailMessageService;
import com.cloudwise.douc.customization.biz.service.msg.MessageCenterService;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.biz.util.DosmHttpUtil;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.message.dubbo.api.dto.DubboSendMessageResult;
import com.cloudwise.message.dubbo.api.dto.base.DubboCommonResp;
import com.cloudwise.message.dubbo.api.model.DubboProductMultipleChannelMessageV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-18  16:43
 **/
@Slf4j
@Service
public class RetryFailEmailMessageImpl implements RetryFailEmailMessageService {

    @Autowired
    CustomMessageRecordService customMessageRecordService;

    @Autowired
    MessageCenterService messageCenterService;

    @Autowired
    CustomDelayMessageRecordService customDelayMessageRecordService;

    @Autowired
    DosmHttpUtil dosmHttpUtil;

    @Autowired
    DosmCustomService dosmCustomService;

    @Autowired
    DosmConfig dosmConfig;

    @Autowired
    private DosmWorkOrderService dosmWorkOrderService;

    @Override
    public void retryFailEmailMessage() {
        List<CustomMessageRecord> updates = new ArrayList<>();
        List<CustomMessageRecord> failMessages = customMessageRecordService.getFailMessages();
        if (CollUtil.isNotEmpty(failMessages)) {
            log.info("[重试出错消息发送数量:{}]", failMessages.size());
            for (CustomMessageRecord customMessageRecord : failMessages) {
                String messageRequest = customMessageRecord.getMessageRequest();
                List<DubboProductMultipleChannelMessageV2> messages = JsonUtils.parseArray(messageRequest,
                        DubboProductMultipleChannelMessageV2.class);
                if (CollUtil.isNotEmpty(messages)) {
                    String messageId = IdUtil.fastSimpleUUID();
                    messages.get(0).setId(messageId);
                    DubboCommonResp<List<DubboSendMessageResult>> response = messageCenterService.send(messages);
                    if (!response.isSuccess()) {
                        customMessageRecord.setRetry(customMessageRecord.getRetry() + 1);
                        log.error("[邮箱消息] 发送失败，msg :{}", response.getMsg());
                    } else {
                        customMessageRecord.setStatus(1);
                    }
                    customMessageRecord.setMessageId(messageId);
                    customMessageRecord.setMessageRequest(JsonUtils.toJsonStr(messages));
                    customMessageRecord.setMessageResponse(JSONUtil.toJsonStr(response));
                    updates.add(customMessageRecord);
                }

            }
        }
        if (!updates.isEmpty()) {
            customMessageRecordService.updateRecord(updates);
        }
    }

    @Override
    public void sendDelayMessage() {
        List<CustomDelayMessageRecord> delayNotifyMessages = customDelayMessageRecordService.getDelayNotifyMessages();
        log.info("发送延迟消息的数量:{}", delayNotifyMessages.size());
        if (CollUtil.isEmpty(delayNotifyMessages)) {
            log.info("发送延迟消息的数量为空");
            return;
        }

        List<CustomDelayMessageRecord> updates = new ArrayList<>();
        for (CustomDelayMessageRecord delayMessageRecord : delayNotifyMessages) {
            delayMessageRecord.setStatus(2);
            updates.add(delayMessageRecord);

            String workOrderId = delayMessageRecord.getWorkOrderId();
            String createdBy = delayMessageRecord.getCreatedBy();
            String notifyContent = delayMessageRecord.getNotifyContent();
            Date startTime = delayMessageRecord.getStartTime();
            Date endTime = delayMessageRecord.getEndTime();

            MessageContext messageContext = JsonUtils.toBean(notifyContent, MessageContext.class);

            WorkOrderDetail workorderDetail = dosmHttpUtil.getWorkOrderDetail(workOrderId, createdBy);
            String formId = workorderDetail.getFormId();
            String nodeId = workorderDetail.getCurrentNodeId();
            log.info("SendDelayMessage get workOrderId:{},nodeId:{}", workOrderId, nodeId);
            Map<String, FieldInfo> formData = dosmWorkOrderService.getFormData(formId, JsonUtils.toJsonNode(workorderDetail.getFormData()));
            if (formData == null) {
                log.info("SendDelayMessage getFormData is empty,skip send");
                continue;
            }
            DosmConfig.UncloseNotify uncloseNotify = dosmConfig.getUncloseNotify();
            String statusKey = uncloseNotify.getStatusKey();
            String statusKeyValue = uncloseNotify.getStatusKeyValue();
            String nodeIdKey = uncloseNotify.getNodeId();
            String dateRangeKey = uncloseNotify.getDateRangeKey();

            if (CharSequenceUtil.isNotBlank(statusKey) && CharSequenceUtil.isNotBlank(statusKeyValue) && CharSequenceUtil.equals(nodeIdKey, nodeId)) {
                log.info("SendDelayMessage config match statusKey:{},statusKeyValue:{},nodeIdKey:{}", statusKey, statusKeyValue, nodeIdKey);
                FieldInfo fieldInfo = formData.get(statusKey);
                if (fieldInfo == null) {
                    log.info("SendDelayMessage get fieldInfo is empty. statusKey:{},statusKeyValue:{},nodeIdKey:{}", statusKey, statusKeyValue,
                            nodeIdKey);
                    continue;
                }
                FieldValue statusValue = fieldInfo.getFieldValueObj();
                if (statusValue == null) {
                    log.info("SendDelayMessage get statusValue is empty. statusKey:{},statusKeyValue:{},nodeIdKey:{}", statusKey, statusKeyValue,
                            nodeIdKey);
                    continue;
                }
                String formatValue;
                FieldValueTypeEnum statusFieldType = fieldInfo.getFieldType();
                if (FieldValueTypeEnum.SELECT.equals(statusFieldType)) {
                    formatValue = ((SelectField) statusValue).getLabel();
                } else {
                    formatValue = statusValue.formatValue();
                }
                log.info("SendDelayMessage get form status value :{}", formatValue);

                //匹配状态
                if (CharSequenceUtil.equals(statusKeyValue, formatValue)) {
                    log.info("SendDelayMessage order status match");
                    FieldInfo dateRangeFileInfo = formData.get(dateRangeKey);
                    if (dateRangeFileInfo == null) {
                        log.info("SendDelayMessage dateRangeFileInfo is empty");
                        return;
                    }
                    log.info("SendDelayMessage handler date range :{}", dateRangeKey);
                    DateRangeField dateRangeFieldValue = (DateRangeField) dateRangeFileInfo.getFieldValueObj();
                    DateRange dateRange = dateRangeFieldValue.getValue();
                    Long endDate = dateRange.getEndDate();
                    Long startDate = dateRange.getStartDate();
                    //时间范围未改变,执行定时任务
                    if (endDate.equals(endTime.getTime()) && startDate.equals(startTime.getTime())) {
                        messageContext.setFormData(formData);
                        boolean result = dosmCustomService.sendMessage(messageContext);
                        log.info("SendDelayMessage result:{}", result);
                        if (result) {
                            delayMessageRecord.setStatus(1);
                        } else {
                            delayMessageRecord.setStatus(0);
                            delayMessageRecord.setRetry(delayMessageRecord.getRetry() + 1);
                        }
                    }
                }
            }
        }
        log.info("SendDelayMessage update size:{}", updates.size());
        customDelayMessageRecordService.updateDelayMessageRecord(updates);
    }
}
