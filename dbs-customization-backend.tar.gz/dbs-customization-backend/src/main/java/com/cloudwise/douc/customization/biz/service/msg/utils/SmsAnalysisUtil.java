package com.cloudwise.douc.customization.biz.service.msg.utils;

import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.utils.JsonUtils;
import com.cloudwise.douc.customization.biz.constant.SmsTemplateConstants;
import com.cloudwise.douc.customization.biz.enums.CrApprovalEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.enums.ValueTypeEnum;
import com.cloudwise.douc.customization.biz.facade.UserSSOClient;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.NormalValue;
import com.cloudwise.douc.customization.biz.model.email.NotifyVo;
import com.cloudwise.douc.customization.biz.model.email.ValueContent;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.biz.model.msg.WorkOrderApprovalBean;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-12  14:45
 **/
@Slf4j
@Component
public class SmsAnalysisUtil {

    public static final String COMMA                   = ".";


    /**
     * 1、send Approved context
     * <p>2、send Rejected context
     * <p>3、send Closed Cancel context
     */
    public static MessageContext buildApprovalMsgContext(WorkOrderApprovalBean workOrderApproval) {
        if(workOrderApproval == null || StringUtils.isBlank(workOrderApproval.getWorkOrderId())) {
            log.error("workOrderApproval or workOrderId is null");
            return null;
        }
        WorkOrderDetail workOrderDetail = getDosmWorkOrderService().getWorkOrderDetail(workOrderApproval.getWorkOrderId(), getDosmConfig().getUserId());
        return buildApprovalMsgContext(workOrderDetail, workOrderApproval.getCrApproval());
    }


    /**
     * 1、send Approved context
     * <p>2、send Rejected context
     * <p>3、send Closed Cancel context
     */
    public static MessageContext buildApprovalMsgContext(WorkOrderDetail workOrderDetail, CrApprovalEnum crApproval) {
        if(workOrderDetail == null) {
            log.error("workOrderDetail is null");
            return null;
        }

        // 发送邮件
        MessageContext messageContext = new MessageContext();
        messageContext.setWorkOrderId(workOrderDetail.getId());
        messageContext.setUserId(getDosmConfig().getUserId());
        messageContext.setCreatedBy(getDosmConfig().getUserId());
        messageContext.setTopAccountId(getDosmConfig().getTopAccountId());
        messageContext.setAccountId(getDosmConfig().getAccountId());

        NotifyVo notify = new NotifyVo();
        messageContext.setNotify(notify);
        HashMap<String, String> publicFields = new HashMap<>();
        messageContext.setPublicFields(publicFields);

        messageContext.setNodeId(workOrderDetail.getCurrentNodeId());
        Map<String, FieldInfo> formData = getDosmWorkOrderService().getFormData(workOrderDetail.getFormId(), JsonUtils.parseJsonNode(workOrderDetail.getFormData()));
        messageContext.setFormData(formData);

        if(buildApprovalMsgContext(workOrderDetail, notify, publicFields, crApproval)) {
            return messageContext;
        }
        return null;
    }


    /** send Approved context */
    public static boolean buildApprovedContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields) {
        return buildApprovalMsgContext(workOrderDetail, notify, publicFields, CrApprovalEnum.APPROVED);
    }



    /** send Rejected context */
    public static boolean buildRejectedContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields) {
        return buildApprovalMsgContext(workOrderDetail, notify, publicFields, CrApprovalEnum.REJECTED);
    }



    /** send Closed Cancel context */
    public static boolean buildClosedCancelContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields) {
        return buildApprovalMsgContext(workOrderDetail, notify, publicFields, CrApprovalEnum.CLOSED_CANCEL);
    }


    /**
     * 1、send Approved context
     * <p>2、send Rejected context
     * <p>3、send Closed Cancel context
     */
    public static boolean buildApprovalMsgContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields, CrApprovalEnum crApproval) {
        if(CrApprovalEnum.APPROVED == crApproval) {
            notify.setNotifyScene(NotifyScenceEnum.CR_APPROVED);
        } else if(CrApprovalEnum.REJECTED == crApproval) {
            notify.setNotifyScene(NotifyScenceEnum.CR_REJECTED);
        } else if(CrApprovalEnum.CLOSED_CANCEL == crApproval) {
            notify.setNotifyScene(NotifyScenceEnum.CR_CLOSED_CANCEL);
        } else {
            log.error("SMS is not supported in this scenario. crApproval: {}", crApproval);
            return false;
        }

        // public field
        buildPublicFields(workOrderDetail, publicFields);

        notify.setChannelType(NotifyWayEnum.SMS);

        // receivers
        notify.setReceivers(Lists.newArrayList(ValueContent.builder()
                .type(ValueTypeEnum.NORMAL)
                .normalValue(NormalValue.builder().userIds(Lists.newArrayList(workOrderDetail.getCreatedBy())).build())
                .build())
        );

        return true;
    }






    public static void buildPublicFields(WorkOrderDetail workOrderDetail, Map<String, String> publicFields) {
        if(workOrderDetail == null) {
            String[] emailPublicFields = {SmsTemplateConstants.PublicFields.WORK_ORDER_ID, SmsTemplateConstants.PublicFields.BIZ_KEY,
                    SmsTemplateConstants.PublicFields.CREATED_BY_ID, SmsTemplateConstants.PublicFields.CREATED_BY_NAME,
            };
            Arrays.stream(emailPublicFields).forEach(field -> publicFields.put(field, ""));
            return;
        }
        publicFields.put(SmsTemplateConstants.PublicFields.WORK_ORDER_ID, workOrderDetail.getId());
        publicFields.put(SmsTemplateConstants.PublicFields.BIZ_KEY, StringUtils.isBlank(workOrderDetail.getBizKey())? workOrderDetail.getId(): workOrderDetail.getBizKey());
        publicFields.put(SmsTemplateConstants.PublicFields.CREATED_BY_ID, workOrderDetail.getCreatedBy());

        UserInfo createdBy = getUserSSOClient().getUserById(workOrderDetail.getCreatedBy());
        publicFields.put(SmsTemplateConstants.PublicFields.CREATED_BY_NAME, createdBy == null? "": createdBy.getUserAlias());
    }










    private static DosmConfig DOSM_CONFIG;
    public static DosmConfig getDosmConfig() {
        return DOSM_CONFIG != null? DOSM_CONFIG: (DOSM_CONFIG = SpringUtil.getBean(DosmConfig.class));
    }

    private static UserSSOClient USER_SSO_CLIENT;
    public static UserSSOClient getUserSSOClient() {
        return USER_SSO_CLIENT != null? USER_SSO_CLIENT: (USER_SSO_CLIENT = SpringUtil.getBean(UserSSOClient.class));
    }


    private static DosmWorkOrderService DOSM_WORK_ORDER_SERVICE;
    public static DosmWorkOrderService getDosmWorkOrderService() {
        return DOSM_WORK_ORDER_SERVICE != null? DOSM_WORK_ORDER_SERVICE: (DOSM_WORK_ORDER_SERVICE = SpringUtil.getBean(DosmWorkOrderService.class));
    }
}
