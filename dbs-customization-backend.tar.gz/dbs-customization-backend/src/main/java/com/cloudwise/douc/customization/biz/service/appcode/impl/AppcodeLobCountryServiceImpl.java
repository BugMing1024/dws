package com.cloudwise.douc.customization.biz.service.appcode.impl;

import com.cloudwise.douc.customization.biz.dao.AppcodeLobCountryMapper;
import com.cloudwise.douc.customization.biz.model.appcode.AppCodeReq;
import com.cloudwise.douc.customization.biz.service.appcode.AppcodeLobCountryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/18
 */
@Service
public class AppcodeLobCountryServiceImpl implements AppcodeLobCountryService {
    
    @Resource
    private AppcodeLobCountryMapper appcodeLobCountryMapper;
    
    @Override
    public Boolean checkMasFlag(AppCodeReq appCodeReq) {
        //TODO 查询mas标识
        return false;
    }
}
