package com.cloudwise.douc.customization.common.kafka;

public abstract class AbstractMetaMessageService implements MetaMessageService {
    
    
    @Override
    public abstract String messageType();
    
    @Override
    public abstract boolean sendMessage(String topic, String tags, String msgBody);
    
    @Override
    public abstract void startConsume(String consumerGroup, String topic, Object messageListener, boolean broadcasting);
}

