package com.cloudwise.douc.customization.biz.model.email;

import lombok.Data;

/**
 * @author ming.ma
 * @since 2025-01-10  17:16
 **/
@Data
public class ApproveRecord {

    private boolean displaySendForApprovalBtn;

    private String nodeId;

    private String nodeName;

    private String groupProcess;

    private String groupName;

    private String approveResult;

    private String status;

    private String approver;

    private String approverId;

    private String reason;

    private String reasonLable;

    private String approveMsg;

    private Long updateTime;
}
