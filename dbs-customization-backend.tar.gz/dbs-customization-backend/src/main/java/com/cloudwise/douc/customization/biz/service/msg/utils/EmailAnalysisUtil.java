package com.cloudwise.douc.customization.biz.service.msg.utils;

import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.utils.JsonUtils;
import com.cloudwise.douc.customization.biz.constant.EmailTemplateConstants;
import com.cloudwise.douc.customization.biz.enums.*;
import com.cloudwise.douc.customization.biz.facade.UserSSOClient;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.biz.model.msg.WorkOrderApprovalBean;
import com.cloudwise.douc.customization.biz.model.signoff.FileInfoPo;
import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import com.cloudwise.douc.customization.biz.service.msg.model.bean.ApproveParam;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author ming.ma
 * @since 2024-12-12  14:45
 **/
@Slf4j
@Component
public class EmailAnalysisUtil {

    public static final String ACCOUNT_SCOPE = "all";


    public static final String AT                      = "@";
    public static final String COMMA                   = ".";
    public static final String COLON                   = ":";
    public static final String EMAIL_TITLE_SPLIT       = "#####";
    public static final String EMAIL_TITLE_PLACEHOLDER = "__";



    /**
     * get user name by email
     * @param email
     * @return
     */
    public static String getUserNameByEmail(String email) {
        log.info("EmailAnalysisUtil getUserName subject:[{}]", email);
        int index = -1;
        if(email == null || (index = email.indexOf(AT)) == -1) {
            return null;
        }

        return email.substring(0, index);
    }


    /**
     *  subject format: Rejected/Approved: {title} ##### {workOrderId} ##### {nodeId} ##### {signOffId} ##### {customMessageRecordId}
     * @param subject
     * @return
     */
    public static ApproveParam getApproveParam(String subject) {
        String[] splits = subject.split(EMAIL_TITLE_SPLIT);
        if(splits.length >= 5) {
            return ApproveParam.builder()
                    .workOrderId(splits[1])
                    .signOffId(EMAIL_TITLE_PLACEHOLDER.equals(splits[3]) ?null: splits[3])
                    .msgRecordId(EMAIL_TITLE_PLACEHOLDER.equals(splits[4]) ?null: splits[4])
                    .build();
        }
        return null;
    }


    public static EmailApproveEnum getApproveStatus(String subject) {
        log.info("EmailAnalysisUtil getApproveStatus subject:[{}]", subject);
        if(subject == null) {
            return null;
        }

        int index = subject.indexOf(COLON);
        if(index == -1) {
            return null;
        }

        return EnumUtils.getEnum(EmailApproveEnum.class, subject.substring(0, index));
    }


    public static String getApproveMailtoLink(EmailApproveEnum status, String title, String replyToAddress, MessageContext context) {
        String body = EmailTemplateUtil.get(EmailApproveEnum.APPROVED.equals(status)? NotifyScenceEnum.EMAIL_ACKNOWLEDGEMENT_APPROVED: NotifyScenceEnum.EMAIL_ACKNOWLEDGEMENT_REJECTED);
        if(CharSequenceUtil.isBlank(body)) {
            return "";
        }
        String emailBody = body.replace("\\n", "%0A").replace(" ", "%20");

        // Rejected/Approved: {title} ##### {workOrderId} ##### {nodeId} ##### {signOffId} ##### {customMessageRecordId}
        StringBuilder subject = new StringBuilder();
        subject.append(status.getName());
        subject.append(COLON);
        subject.append(title);
        subject.append(EMAIL_TITLE_SPLIT);
        subject.append(context.getWorkOrderId());
        subject.append(EMAIL_TITLE_SPLIT);
        subject.append(StrUtil.isNotBlank(context.getNodeId())? context.getNodeId(): EMAIL_TITLE_PLACEHOLDER);
        subject.append(EMAIL_TITLE_SPLIT);
        String signOffId = context.getPublicFields().getOrDefault("signOffId", EMAIL_TITLE_PLACEHOLDER);
        subject.append(signOffId);
        subject.append(EMAIL_TITLE_SPLIT);
        subject.append(StrUtil.isNotBlank(context.getTmpRecordId())? context.getTmpRecordId(): EMAIL_TITLE_PLACEHOLDER);
        if(CharSequenceUtil.isBlank(replyToAddress)) {
            log.info("Get getApproveRejectMailtoLink replyToAddress is empty");
            return "";
        }
        // build mailto link
        return "mailto:" + replyToAddress + "?subject=" + subject.toString().replace(" ", "%20") + "&body=" + emailBody;
    }






    /**
     * 1、send Approved context
     * <p>2、send Rejected context
     * <p>3、send Standalone CR Rejection context
     * <p>4、send Closed Cancel context
     */
    public static MessageContext buildApprovalMsgContext(WorkOrderApprovalBean workOrderApproval) {

        if(workOrderApproval == null || StringUtils.isBlank(workOrderApproval.getWorkOrderId())) {
            log.error("workOrderApproval or workOrderId is null");
            return null;
        }
        WorkOrderDetail workOrderDetail = getDosmWorkOrderService().getWorkOrderDetail(workOrderApproval.getWorkOrderId(), getDosmConfig().getUserId());
        return buildApprovalMsgContext(workOrderDetail, workOrderApproval.getCrApproval());
    }


    /**
     * 1、send Approved context
     * <p>2、send Rejected context
     * <p>3、send Standalone CR Rejection context
     * <p>4、send Closed Cancel context
     */
    public static MessageContext buildApprovalMsgContext(WorkOrderDetail workOrderDetail, CrApprovalEnum crApproval) {
        if(workOrderDetail == null) {
            log.error("workOrderDetail is null");
            return null;
        }

        // 发送邮件
        MessageContext messageContext = new MessageContext();
        messageContext.setWorkOrderId(workOrderDetail.getId());
        messageContext.setUserId(getDosmConfig().getUserId());
        messageContext.setCreatedBy(getDosmConfig().getUserId());
        messageContext.setTopAccountId(getDosmConfig().getTopAccountId());
        messageContext.setAccountId(getDosmConfig().getAccountId());

        NotifyVo notify = new NotifyVo();
        messageContext.setNotify(notify);
        HashMap<String, String> publicFields = new HashMap<>();
        messageContext.setPublicFields(publicFields);

        messageContext.setNodeId(workOrderDetail.getCurrentNodeId());
        Map<String, FieldInfo> formData = getDosmWorkOrderService().getFormData(workOrderDetail.getFormId(), JsonUtils.parseJsonNode(workOrderDetail.getFormData()));
        messageContext.setFormData(formData);

        if(buildApprovalMsgContext(workOrderDetail, notify, publicFields, crApproval)) {
            return messageContext;
        }
        return null;
    }


    /** send Approved context */
    public static boolean buildApprovedContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields) {
        return buildApprovalMsgContext(workOrderDetail, notify, publicFields, CrApprovalEnum.APPROVED);
    }


    /**
     * 1、send Rejected context
     * <p>2、send Standalone CR Rejection context
     */
    public static boolean buildRejectedContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields) {
        return buildApprovalMsgContext(workOrderDetail, notify, publicFields, CrApprovalEnum.REJECTED);
    }



    /** send Closed Cancel context */
    public static boolean buildClosedCancelContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields) {
        return buildApprovalMsgContext(workOrderDetail, notify, publicFields, CrApprovalEnum.CLOSED_CANCEL);
    }


    /**
     * 1、send Approved context
     * <p>2、send Rejected context
     * <p>3、send Standalone CR Rejection context
     * <p>4、send Closed Cancel context
     */
    public static boolean buildApprovalMsgContext(WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields, CrApprovalEnum crApproval) {
        if(CrApprovalEnum.APPROVED == crApproval) {
            notify.setNotifyScene(NotifyScenceEnum.CR_APPROVED);
        } else if(CrApprovalEnum.REJECTED == crApproval) {
            notify.setNotifyScene(NotifyScenceEnum.CR_REJECTED);
        } else if(CrApprovalEnum.CLOSED_CANCEL == crApproval) {
            notify.setNotifyScene(NotifyScenceEnum.CR_CLOSED_CANCEL);
        } else {
            log.error("SMS is not supported in this scenario. crApproval: {}", crApproval);
            return false;
        }

        notify.setChannelType(NotifyWayEnum.EMAIL);

        // public field
        buildPublicFields(workOrderDetail, publicFields);
        publicFields.put(EmailTemplateConstants.PublicFields.WORK_ORDER_ID, workOrderDetail.getId());

        // receivers
        notify.setReceivers(Lists.newArrayList(ValueContent.builder()
                .type(ValueTypeEnum.NORMAL)
                .normalValue(NormalValue.builder().userIds(Lists.newArrayList(workOrderDetail.getCreatedBy())).build())
                .build())
        );

        return true;
    }



    public static boolean buildSignoffMsgContext(SignOffEntity signoffEntity, WorkOrderDetail workOrderDetail, NotifyVo notify, Map<String, String> publicFields, EmailApproveEnum emailApprove) {
        notify.setChannelType(NotifyWayEnum.EMAIL);

        // public field
        buildPublicFields(workOrderDetail, publicFields);
        publicFields.put(EmailTemplateConstants.PublicFields.WORK_ORDER_ID, signoffEntity.getWorkOrderId());
        publicFields.put(EmailTemplateConstants.PublicFields.SIGN_OFF_ID, String.valueOf(signoffEntity.getId()));
        publicFields.put(EmailTemplateConstants.PublicFields.SIGN_OFF_TYPE, signoffEntity.getSignOffType());

        List<String> signOffTypeList = JsonUtils.convertList(signoffEntity.getSignOffType(), String.class);
        String signOffTypeStr = String.join(",", signOffTypeList);
        signOffTypeStr = StrUtil.replaceLast(signOffTypeStr, ",", " and ");
        publicFields.put(EmailTemplateConstants.TESTING_SIGN_OFF_TYPES, signOffTypeStr);
        publicFields.put(EmailTemplateConstants.SCIENCE_TYPE, signOffTypeStr);

        if(EmailApproveEnum.APPROVED == emailApprove) {
            notify.setNotifyScene(NotifyScenceEnum.CR_APPROVED);

            // receivers
            notify.setReceivers(Lists.newArrayList(ValueContent.builder()
                    .type(ValueTypeEnum.NORMAL)
                    .normalValue(NormalValue.builder().userIds(Lists.newArrayList(workOrderDetail.getCreatedBy())).build())
                    .build())
            );
        } else if(EmailApproveEnum.REJECTED == emailApprove) {
            notify.setNotifyScene(NotifyScenceEnum.CR_REJECTED);

            // receivers
            notify.setReceivers(Lists.newArrayList(ValueContent.builder()
                    .type(ValueTypeEnum.NORMAL)
                    .normalValue(NormalValue.builder().userIds(Lists.newArrayList(workOrderDetail.getCreatedBy())).build())
                    .build())
            );
        } else {
            // receivers
            List<com.cloudwise.douc.customization.biz.model.user.UserInfo> userInfos = JsonUtils.convertList(signoffEntity.getSignOffUser(), com.cloudwise.douc.customization.biz.model.user.UserInfo.class);
            com.cloudwise.douc.customization.biz.model.user.UserInfo userInfo = userInfos.get(0);
            notify.setReceivers(Lists.newArrayList(ValueContent.builder()
                    .type(ValueTypeEnum.NORMAL)
                    .normalValue(NormalValue.builder().userIds(Lists.newArrayList(userInfo.getUserId())).build())
                    .build())
            );

            SignoffConstants.SignoffItem signoffItem = SignoffConstants.SignoffItem.fromString(signoffEntity.getSignOffGroup(), signOffTypeList.get(0));
            NotifyScenceEnum notifyScenceEnum = EmailTemplateUtil.signOffTemplateMapping.get(signoffItem);
            notify.setNotifyScene(notifyScenceEnum);

            /** -------------------------------------------- The following information is related to 【cr is new -> xx signoff】 ------------------------------------------------ */
            // Artifact
            if(StringUtils.isNotBlank(signoffEntity.getArtifact())) {
                List<FileInfoPo> fileInfos = JsonUtils.convertList(signoffEntity.getArtifact(), FileInfoPo.class);
                if(CollectionUtils.isNotEmpty(fileInfos)) {
                    List<String> fileIds = fileInfos.stream().map(FileInfoPo::getId).collect(Collectors.toList());
                    notify.setUploadFiles(ValueContent.builder()
                            .type(ValueTypeEnum.FORM)
                            .fields(Lists.newArrayList(FieldValue.builder().name(EmailTemplateConstants.PublicFields.SIGNOFF_UPLOAD_FILE).build()))
                            .build()
                    );
                    publicFields.put(EmailTemplateConstants.PublicFields.SIGNOFF_UPLOAD_FILE, JsonUtils.toJsonString(fileIds));
                }
            }
        }

        return true;
    }


    public static void buildPublicFields(WorkOrderDetail workOrderDetail, Map<String, String> publicFields) {
        if(workOrderDetail == null) {
            String[] emailPublicFields = {EmailTemplateConstants.PublicFields.WORK_ORDER_ID, EmailTemplateConstants.PublicFields.BIZ_KEY,
                    EmailTemplateConstants.PublicFields.CREATED_BY_ID, EmailTemplateConstants.PublicFields.CREATED_BY_EMAIL, EmailTemplateConstants.PublicFields.CREATED_BY_NAME,
                    EmailTemplateConstants.PublicFields.MDL_DEF_KEY, EmailTemplateConstants.PublicFields.WORK_ORDER_URI
            };
            Arrays.stream(emailPublicFields).forEach(field -> publicFields.put(field, ""));
            return;
        }
        publicFields.put(EmailTemplateConstants.PublicFields.WORK_ORDER_ID, workOrderDetail.getId());
        publicFields.put(EmailTemplateConstants.PublicFields.BIZ_KEY, StringUtils.isBlank(workOrderDetail.getBizKey())? workOrderDetail.getId(): workOrderDetail.getBizKey());
        publicFields.put(EmailTemplateConstants.PublicFields.CREATED_BY_ID, workOrderDetail.getCreatedBy());

        UserInfo createdBy = getUserSSOClient().getUserById(workOrderDetail.getCreatedBy());
        publicFields.put(EmailTemplateConstants.PublicFields.CREATED_BY_EMAIL, createdBy == null? "": createdBy.getEmail());
        publicFields.put(EmailTemplateConstants.PublicFields.CREATED_BY_NAME, createdBy == null? "": createdBy.getUserAlias());

        publicFields.put(EmailTemplateConstants.PublicFields.MDL_DEF_KEY, workOrderDetail.getMdlDefKey());

        publicFields.put(EmailTemplateConstants.PublicFields.WORK_ORDER_URI, getDosmConfig().getOrderDetail() + workOrderDetail.getId());
    }


    private static DosmConfig DOSM_CONFIG;
    public static DosmConfig getDosmConfig() {
        return DOSM_CONFIG != null? DOSM_CONFIG: (DOSM_CONFIG = SpringUtil.getBean(DosmConfig.class));
    }

    private static UserSSOClient USER_SSO_CLIENT;
    public static UserSSOClient getUserSSOClient() {
        return USER_SSO_CLIENT != null? USER_SSO_CLIENT: (USER_SSO_CLIENT = SpringUtil.getBean(UserSSOClient.class));
    }

    private static DosmWorkOrderService DOSM_WORK_ORDER_SERVICE;
    public static DosmWorkOrderService getDosmWorkOrderService() {
        return DOSM_WORK_ORDER_SERVICE != null? DOSM_WORK_ORDER_SERVICE: (DOSM_WORK_ORDER_SERVICE = SpringUtil.getBean(DosmWorkOrderService.class));
    }
}
