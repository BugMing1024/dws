package com.cloudwise.douc.customization.common.model;


import com.cloudwise.douc.customization.common.constant.ErrorCodeEnum;
import com.cloudwise.douc.customization.common.exception.BizException;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.fasterxml.jackson.annotation.JsonInclude;

import static com.cloudwise.douc.customization.common.constant.ErrorCodeEnum.BUSINESS_ERROR;

/**
 * @author skiya
 * @date Created on 2021-11-25.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {
    
    private Integer status;
    
    private String message;
    
    private T data;
    
    private PageResponse pagination;
    
    private ApiResponse() {
    }
    
    public ApiResponse(Integer status, String message, T data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }
    
    public static ApiResponse<Void> ok() {
        return ok(null);
    }
    
    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(200, "success", data);
    }
    
    public static <T> ApiResponse<T> page(T data, PageResponse page) {
        ApiResponse<T> apiResponse = new ApiResponse<>(200, "success", data);
        apiResponse.pagination = page;
        return apiResponse;
    }
    
    public static <T> ApiResponse<T> fail(BizException e) {
        return new ApiResponse<>(e.getCode(), e.getMessage(), null);
    }
    
    public static <T> ApiResponse<T> fail(ErrorCodeEnum errorCode) {
        return fail(errorCode, errorCode.message);
    }


       public static <T> ApiResponse<T> fail(String errorMsg) {
        return fail(BUSINESS_ERROR, errorMsg);
    }
    
    public static <T> ApiResponse<T> fail(ErrorCodeEnum errorCode, String message) {
        return new ApiResponse<>(errorCode.code, message, null);
    }
    
    @Override
    public String toString() {
        return JsonUtils.toJsonStr(this);
    }
    
    public Integer getStatus() {
        return status;
    }
    
    public String getMessage() {
        return message;
    }
    
    public T getData() {
        return data;
    }
    
    public PageResponse getPagination() {
        return this.pagination;
    }
}
