package com.cloudwise.douc.customization.biz.service.msg;

import com.cloudwise.message.dubbo.api.dto.DubboSendMessageResult;
import com.cloudwise.message.dubbo.api.dto.base.DubboCommonResp;
import com.cloudwise.message.dubbo.api.model.DubboProductMultipleChannelMessageV2;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-04  14:38
 **/
public interface MessageCenterService {
    
    DubboCommonResp<List<DubboSendMessageResult>> send(List<DubboProductMultipleChannelMessageV2> messages);
    
}
