package com.cloudwise.douc.customization.biz.model.email.dosm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 审批节点审批配置
 *
 * @author jon.lee
 * @since 2022-05-14 15:32
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "审批节点审批配置")
public class ApproveConfVo {
    
    @ApiModelProperty(value = "背靠背模式", example = "true", required = false)
    private Boolean backToBack;
    
    @ApiModelProperty(value = "是否允许取回已进行审批的工单", example = "true", required = false)
    private Boolean isAllowGetBackApproved;
    
    //当前节点的处理类型
    @ApiModelProperty(value = " MULTI_PROCESSING = 并签方式  SEQUENCE_HANDLE =  串签方式  SINGLE_PROCESSING = 单人审批", example = "MULTI_PROCESSING", required = true)
    private NodeHandlerTypeEnum approveType;
    
    
    @ApiModelProperty(value = "是否开启相同审批人自动审批", example = "true 开启 ，false 关闭", required = true)
    private boolean autoApprove;
    
    @ApiModelProperty(value = "跟随节点类型", example = "NEXT_TO 相邻节点相同审批人 ，HISTORY 历史邻节点相同审批人", required = true)
    private AutoPassFollowTypeEnum followType;
    
    @ApiModelProperty(value = "审批意见类型", example = "CUSTOM 自定义，FOLLOW 跟随上一相同处理人审批意见", required = true)
    private ApproveMsgTypeEnum approveMsgType;
    
    @ApiModelProperty(value = "自定义审批意见内容", example = "同意！", required = true)
    private String approveMsg;
    
    @ApiModelProperty(value = "驳回设置", example = "FIRST_NODE 首节点，LAST_NODE 上一节点", required = true)
    private List<RejectToEnum> rejectTo;
    
    
    @ApiModelProperty(value = "多人会签配置", example = "", required = false)
    private MultiApproveConf multiApproveConf;
    
    @ApiModelProperty(value = "审批默认值配置", example = "", required = false)
    private ApproveDefault approveDefault;
    
    
    @ApiModelProperty(value = "通过是否展示弹窗 默认true", example = "", required = false)
    private Boolean showPressPage = true;
    
    @ApiModelProperty(value = "驳回是否展示弹窗 默认true", example = "", required = false)
    private Boolean showRejectPage = true;
    
}
