package com.cloudwise.douc.customization.biz.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloudwise.douc.customization.biz.model.crdailybulkreminder.RptCrTodoDailyData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RptCrTodoDailyDataMapper extends BaseMapper<RptCrTodoDailyData> {
    IPage<RptCrTodoDailyData> selectRptCrTodoDailyDataListByPage(Page<RptCrTodoDailyData> page, @Param(Constants.WRAPPER) Wrapper<RptCrTodoDailyData> queryWrapper);

    void truncateRptCrTodoTaskMid();

    void truncateRptCrTodoOrderMid();

    void truncateRptCrTodoCountData();

    void truncateRptCrTodoDailyData();


    void insertRptCrTodoTaskMid(@Param("taskNameList") List<String> taskNameList);

    void insertRptCrTodoOrderMid(@Param("processName") String processName, @Param("changeScheduleStartdateFullpath") String changeScheduleStartdateFullpath);

    void insertRptCrTodoCountData();

    void insertRptCrTodoDailyData();

}
