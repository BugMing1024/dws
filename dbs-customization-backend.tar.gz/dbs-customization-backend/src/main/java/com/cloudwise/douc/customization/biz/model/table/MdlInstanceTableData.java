package com.cloudwise.douc.customization.biz.model.table;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/23
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("mdl_instance_table_data")
public class MdlInstanceTableData {
    
    private String id;
    
    private String rowData;
}
