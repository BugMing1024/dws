package com.cloudwise.douc.customization.biz.service.msg.impl;

import com.cloudwise.douc.customization.biz.service.msg.MessageCenterService;
import com.cloudwise.message.dubbo.api.dto.DubboSendMessageResult;
import com.cloudwise.message.dubbo.api.dto.base.DubboCommonResp;
import com.cloudwise.message.dubbo.api.facade.MessageSenderFacade;
import com.cloudwise.message.dubbo.api.model.DubboProductMultipleChannelMessageV2;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-04  14:41
 **/
@Slf4j
@Service
public class MessageCenterServiceImpl implements MessageCenterService {
    
    @DubboReference(lazy = true, check = false, timeout = 100000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private MessageSenderFacade messageSenderFacade;
    
    @Override
    public DubboCommonResp<List<DubboSendMessageResult>> send(List<DubboProductMultipleChannelMessageV2> messages) {
        DubboCommonResp<List<DubboSendMessageResult>> resp;
        log.info("Request MessageSenderFacade.sendV2 start");
        try {
            resp = messageSenderFacade.sendV2(messages);
            if (!resp.isSuccess()) {
                log.error("Request MessageSenderFacade.send failed,params:{}, msg:{}", messages, resp.getMsg());
                resp = new DubboCommonResp<List<DubboSendMessageResult>>().generateFailResp();
                return resp;
            }
            log.info("Request MessageSenderFacade.sendV2 success:{}", resp);
        } catch (Exception e) {
            resp = new DubboCommonResp<List<DubboSendMessageResult>>().generateFailResp();
            log.error("Request MessageSenderFacade.sendV2 failed,params:{}", messages, e);
        }
        return resp;
    }
}
