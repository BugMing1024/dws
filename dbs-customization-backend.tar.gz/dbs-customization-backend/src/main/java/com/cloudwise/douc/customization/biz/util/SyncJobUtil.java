package com.cloudwise.douc.customization.biz.util;

import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * @author cade.liu
 * @since 2025-1-23 17:29
 **/
@Slf4j
public class SyncJobUtil {

    public static <T> void syncJob(Supplier<T> supplier, AtomicBoolean isRunning) {
        log.debug("------all--sync--job--start----");
        if (isRunning.get()) {
            return;
        }
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            if (isRunning.get()) {
                return;
            }
            try {
                isRunning.set(true);
                supplier.get();
            } catch (Throwable exception) {
                log.error("Error run task", exception);
            } finally {
                isRunning.set(false);
            }
            log.debug("------all--sync--job--end----");
        });
    }

}
