package com.cloudwise.douc.customization.biz.controller;

import com.cloudwise.dosm.api.bean.adv.extend.BtnActionBo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.email.SendForApprovalVo;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.common.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author ming.ma
 * @since 2024-12-09  09:47
 **/
@Slf4j
@RestController
@RequestMapping("/custom/api/")
public class DosmCustomController {

    @Autowired
    DosmCustomService dosmCustomService;

    @PostMapping("/sendMessage")
    public ApiResponse<Boolean> sendMessage(@RequestBody MessageContext messageContext) {
        log.info("==Start sendMessage==");
        return ApiResponse.ok(dosmCustomService.sendMessage(messageContext));
    }

    @PostMapping("/uncloseNotify")
    public void uncloseNotify(@RequestBody MessageContext messageContext) {
        log.info("==Start uncloseNotify==");
        dosmCustomService.uncloseNotify(messageContext);
    }

    @PostMapping("/sendForApproval")
    public ApiResponse<Boolean> sendForApproval(@RequestBody SendForApprovalVo sendForApprovalVo) {
        log.info("==Start sendForApproval==");
        return new ApiResponse<>(100000, "success", dosmCustomService.sendForApproval(sendForApprovalVo));
    }

    @GetMapping("/sendApprovalMessage")
    public ApiResponse<Boolean> sendApprovalMessage(String workOrderId, String notifyScene, String userId) {
        log.info("==Start sendApprovalMessage==");
        dosmCustomService.sendApprovalMessage(workOrderId, notifyScene, userId);
        return new ApiResponse<>(100000, "success", true);
    }

}
