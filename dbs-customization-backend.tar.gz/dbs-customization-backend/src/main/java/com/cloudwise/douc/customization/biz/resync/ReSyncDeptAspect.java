package com.cloudwise.douc.customization.biz.resync;

import cn.hutool.core.collection.CollUtil;
import com.cloudwise.douc.customization.biz.facade.DoucBaseFacade;
import com.cloudwise.douc.customization.common.exception.DoucFailedSyncResult;
import com.cloudwise.douc.customization.common.exception.DoucSyncException;
import com.cloudwise.douc.dto.DubboUpdateDepartment;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class ReSyncDeptAspect {
    
    private final static String DUPLICATE_DEPT_NAME_ERROR_CODE = "110109";
    
    private final DoucBaseFacade doucBaseFacade;
    
    /**
     * 切入点：addOrUpdateDepartments()方法
     */
    @Pointcut("execution(* com.cloudwise.douc.customization.biz.facade.DoucBaseFacade.addOrUpdateDepartments(..))")
    public void pointCut() {
    }
    
    @Around("pointCut() && args(dubboUpdateDepartments)")
    public Object handleDataSyncException(ProceedingJoinPoint joinPoint, List<DubboUpdateDepartment> dubboUpdateDepartments) throws Throwable {
        try {
            return joinPoint.proceed();
        } catch (DoucSyncException e) {
            
            Collection<String> renameDeptIds = CollUtil.newHashSet();
            Collection<DoucFailedSyncResult> reSyncResults = e.getSyncResults();
            Collection<DoucFailedSyncResult> reThrowResults = CollUtil.newHashSet();
            for (DoucFailedSyncResult syncResult : reSyncResults) {
                if (DUPLICATE_DEPT_NAME_ERROR_CODE.equals(syncResult.getCode())) {
                    renameDeptIds.addAll(syncResult.getFailIds());
                } else {
                    reThrowResults.add(syncResult);
                }
            }
            
            List<DubboUpdateDepartment> renameDepartments = CollUtil.newArrayList();
            for (DubboUpdateDepartment department : dubboUpdateDepartments) {
                if (renameDeptIds.contains(department.getDepartmentCode())) {
                    department.setDepartmentName(department.getDepartmentName() + "(" + department.getDepartmentCode() + ")");
                    renameDepartments.add(department);
                }
            }
            if (CollUtil.isNotEmpty(renameDepartments)) {
                log.info("duplicate name or code, try to rename: {}",
                        renameDepartments.stream().map(DubboUpdateDepartment::getDepartmentCode).collect(Collectors.toList()));
                doucBaseFacade.addOrUpdateDepartments(renameDepartments);
            }
            
            if (CollUtil.isNotEmpty(reThrowResults)) {
                throw new DoucSyncException(reThrowResults);
            }
            
            return null;
        }
    }
}
