package com.cloudwise.douc.customization.biz.service.groupuser.writer;

import org.springframework.core.GenericTypeResolver;

import java.util.List;

/**
 * Created on 2022-12-27.
 *
 * @author skiya
 */
public interface Writer<T> {
    
    /**
     * 写入数据
     *
     * @param records 数据集合
     */
    void write(List<T> records);
    
    default void afterWrite(List<T> records) {
    }
    
    /**
     * 得到元素类型
     *
     * @return {@link Class}<{@link T}>
     */
    @SuppressWarnings("unchecked")
    default Class<T> getElementClass() {
        return (Class<T>) GenericTypeResolver.resolveTypeArgument(this.getClass(), Writer.class);
    }
}
