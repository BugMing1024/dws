package com.cloudwise.douc.customization.biz.controller;

import com.cloudwise.dosm.api.bean.form.field.DictDataField;
import com.cloudwise.douc.customization.biz.model.signoff.SignOffEntity;
import com.cloudwise.douc.customization.biz.service.signoff.SignOffService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * </p>
 *
 * @author abell.wu
 * @since 2024/12/24
 */
@Slf4j
@RestController
@RequestMapping("/dosm/signOff")
public class SignOffController {

    @Autowired
    private SignOffService signOffService;

    @PostMapping("/insert")
    public Long insert(@RequestBody SignOffEntity signOff) {
        return signOffService.insert(signOff);
    }

    @PostMapping("/insertBatch")
    public void insertBatch(@RequestBody List<SignOffEntity> signOff) {
        signOffService.insert(signOff);
    }


    @PostMapping("/update")
    public Long update(@RequestBody SignOffEntity signOff) {
        return signOffService.update(signOff);
    }


    @PostMapping("/sendEmail")
    public boolean sendEmail(@RequestParam Long signOffId, HttpServletRequest request) {
        String userId = request.getHeader("userId");
        return signOffService.sendEmail(signOffId, userId);
    }


    @PostMapping("/status")
    public void status(@RequestParam Long signOffId, @RequestParam String status) {
        signOffService.status(signOffId, status);
    }


    @PostMapping("/rejected")
    public void rejected(@RequestParam("signOffId") Long signOffId, HttpServletRequest request) {

        String userId = request.getHeader("userId");
        signOffService.rejected(signOffId, userId);
    }


    @PostMapping("/approved")
    public void approved(@RequestParam Long signOffId, HttpServletRequest request) {

        String userId = request.getHeader("userId");

        signOffService.approved(signOffId, userId);
    }


    @PostMapping("/getSignOffListByWorkOrderId")
    public List<SignOffEntity> getSignOffListByWorkOrderId(@RequestParam String workOrderId, @RequestParam String signOffGroup) {
        return signOffService.getSignOffListByWorkOrderId(workOrderId, signOffGroup);
    }


    @PostMapping("/getSignOffById")
    public SignOffEntity getSignOffById(@RequestParam Long signOffId) {
        return signOffService.getSignOffById(signOffId);
    }


    @PostMapping("/calculateSignOffResult")
    public Boolean calculateSignOffResult(@RequestParam String workOrderId) {
        try {
            return signOffService.calculateSignOffResult(workOrderId);
        } catch (Exception e) {
            log.error("calculateSignOffResult error:{}", ExceptionUtils.getStackTrace(e));
            return false;
        }
    }


    @PostMapping("/idrCaseIdValid")
    public Object idrCaseIdValid(@RequestParam String caseId) {
        return signOffService.idrCaseIdValid(caseId);

    }

    public static void main(String[] args) {
        List<DictDataField> targetlist = new ArrayList<>();
        DictDataField applicationImpactedVo1 = new DictDataField();
        applicationImpactedVo1.setId("id1");
        applicationImpactedVo1.setLabel("ichamp_country1");
        applicationImpactedVo1.setValue("value1");
        targetlist.add(applicationImpactedVo1);

        DictDataField applicationImpactedVo2 = new DictDataField();
        applicationImpactedVo2.setId("id2");
        applicationImpactedVo2.setLabel("ichamp_country1");
        applicationImpactedVo2.setValue("value2");
        targetlist.add(applicationImpactedVo2);

        DictDataField applicationImpactedVo3 = new DictDataField();
        applicationImpactedVo3.setId("id3");
        applicationImpactedVo3.setLabel("ichamp_country3");
        applicationImpactedVo3.setValue("value3");
        targetlist.add(applicationImpactedVo3);


        Set<String> seenLabels = new HashSet<>();
        List<DictDataField> targetlist2 = targetlist.stream()
                .filter(item -> seenLabels.add(item.getLabel()))
                .collect(Collectors.toList());

        System.out.println(targetlist2);
    }

}
