package com.cloudwise.douc.customization.biz.facade;

import cn.hutool.core.lang.TypeReference;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.biz.model.email.ReadEmail;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupDetail;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsRespCommonGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.ImplementerGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.MdApproveGroup;
import com.cloudwise.douc.customization.biz.model.groupuser.UserTSO;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.model.DbsDataResp;
import com.cloudwise.douc.customization.common.model.DbsResp;
import com.cloudwise.douc.customization.common.util.HttpUtils;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 外观部分处理
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-22 01:34; update at 2024-12-22 01:34
 */
@Slf4j
@Component
public class DbsFacade {
    
    @Autowired
    private DbsProperties dbsProperties;
    
    public void buildApprove(List<DbsRespCommonGroup> approveGroups) {
        Map<String, String> header = buildHeader();
        //header.put("functionId", dbsProperties.getApprover().getFunctionId());
        Optional<String> respOpt = HttpUtils.get(dbsProperties.getApprover().getUrl(), null, header);
        respOpt.ifPresent(s -> {
            log.info("approver resp is:{}", s);
            DbsResp<DbsDataResp<List<DbsRespCommonGroup>>> bean = JSONUtil.toBean(respOpt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<DbsRespCommonGroup>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("approver data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            approveGroups.addAll(bean.getData().getData());
        });
    }
    
    public Map<String, String> buildHeader() {
        Map<String, String> header = Maps.newHashMapWithExpectedSize(3);
        header.put("appCode", dbsProperties.getAppCode());
        header.put("appKey", dbsProperties.getAppKey());
        return header;
    }
    
    public void buildImplementer(List<ImplementerGroup> implementerGroups) {
        Map<String, String> header = buildHeader();
        //header.put("functionId", dbsProperties.getImplementer().getFunctionId());
        Optional<String> resp2Opt = HttpUtils.get(dbsProperties.getImplementer().getUrl(), null, header);
        resp2Opt.ifPresent(s -> {//new TypeReference<>()
            log.info("implementer esp is:{}", s);
            DbsResp<DbsDataResp<List<ImplementerGroup>>> bean = JSONUtil.toBean(resp2Opt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<ImplementerGroup>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("implementer data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            implementerGroups.addAll(bean.getData().getData());
        });
    }
    
    public void buildMdApprover(List<MdApproveGroup> mdApproveGroups) {
        Map<String, String> header = buildHeader();
        //header.put("functionId", dbsProperties.getMdApprover().getFunctionId());
        Optional<String> resp3Opt = HttpUtils.get(dbsProperties.getMdApprover().getUrl(), null, header);
        resp3Opt.ifPresent(s -> {
            log.info("mdApprover resp is:{}", s);
            DbsResp<DbsDataResp<List<MdApproveGroup>>> bean = JSONUtil.toBean(resp3Opt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<MdApproveGroup>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("mdApprover data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            mdApproveGroups.addAll(bean.getData().getData());
        });
    }
    
    public void buildTSOId(List<UserTSO> userTSOs) {
        Map<String, String> header = buildHeader();
        //header.put("functionId", dbsProperties.getTsoid().getFunctionId());
        Optional<String> resp4Opt = HttpUtils.get(dbsProperties.getTsoid().getUrl(), null, header);
        resp4Opt.ifPresent(s -> {
            log.info("tsoid resp is:{}", s);
            DbsResp<DbsDataResp<List<UserTSO>>> bean = JSONUtil.toBean(resp4Opt.get(), new TypeReference<DbsResp<DbsDataResp<List<UserTSO>>>>() {
                @Override
                public Type getType() {
                    return super.getType();
                }
            }, true);
            log.info("tsoid data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            userTSOs.addAll(bean.getData().getData());
        });
    }
    
    public void buildDetail(List<DbsGroupInfo> dbsGroupInfos) {
        Map<String, String> body = dbsProperties.getGroupDetail().getParams();
        Map<String, DbsGroupDetail> result = Maps.newHashMap();
        //header.put("functionId", dbsProperties.getTsoid().getFunctionId());
        Optional<String> resp4Opt = HttpUtils.post(dbsProperties.getGroupDetail().getUrl(), body, buildHeader());
        resp4Opt.ifPresent(s -> {
            log.info("detail resp is:{}", s);
            DbsResp<DbsDataResp<List<DbsGroupDetail>>> bean = JSONUtil.toBean(resp4Opt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<DbsGroupDetail>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("detail data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            for (DbsGroupDetail datum : bean.getData().getData()) {
                result.put(datum.getGroup(), datum);
            }
        });
        dbsGroupInfos.forEach(e -> {
            DbsGroupDetail dbsGroupDetail = result.get(e.getCode());
            if (dbsGroupDetail == null) {
                return;
            }
            e.setDescription(dbsGroupDetail.getGroupDescription());
            e.setCountry(dbsGroupDetail.getGroupCountry());
            e.setLob(dbsGroupDetail.getGroupLOB());
            e.setOwnerCode(dbsGroupDetail.getGroupOwnerLogin());
        });
    }
    
    public void buildSignoff(List<DbsGroupInfo> dbsGroupInfos) {
        Map<String, String> secondGroupCodeMap = Maps.newHashMap();
        dbsGroupInfos.forEach(dbsGroupInfo -> {
            String firstGroupCode = findFirstGroupCode(dbsGroupInfo.getName());
            if (StrUtil.isNotBlank(firstGroupCode)) {
                dbsGroupInfo.setParentCode(firstGroupCode);
                dbsGroupInfo.setGroupType(firstGroupCode);
                secondGroupCodeMap.put(dbsGroupInfo.getCode(), firstGroupCode);
            }
        });
        if (MapUtil.isNotEmpty(secondGroupCodeMap)) {
            dbsGroupInfos.forEach(dbsGroupInfo -> {
                String secondGroupCode = secondGroupCodeMap.get(dbsGroupInfo.getParentCode());
                if (StrUtil.isNotBlank(secondGroupCode)) {
                    dbsGroupInfo.setGroupType(secondGroupCode);
                }
            });
        }
    }
    
    public String findFirstGroupCode(String value) {
        List<DbsProperties.Special> special = dbsProperties.getSpecial();
        for (DbsProperties.Special special1 : special) {
            if (special1.getChildrenGroupName().contains(value)) {
                return special1.getFirstGroupCode();
            }
        }
        return null;
    }
    
    
    public void buildUserDetail(List<DbsUserInfo> dbsUserInfos) {
        Map<String, String> body = dbsProperties.getGroupDetail().getParams();
        Map<String, DbsUserInfo> result = Maps.newHashMap();
        //header.put("functionId", dbsProperties.getTsoid().getFunctionId());
        Optional<String> resp4Opt = HttpUtils.post(dbsProperties.getGroupDetail().getUrl(), body, buildHeader());
        resp4Opt.ifPresent(s -> {
            log.info("detail resp is:{}", s);
            DbsResp<DbsDataResp<List<DbsGroupDetail>>> bean = JSONUtil.toBean(resp4Opt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<DbsGroupDetail>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("detail data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            List<String> userCodes = dbsUserInfos.stream().map(DbsUserInfo::getCode).collect(Collectors.toList());
            for (DbsGroupDetail dbsGroupDetail : bean.getData().getData()) {
                if (!userCodes.contains(dbsGroupDetail.getGroupOwnerLogin())) {
                    DbsUserInfo dbsUserInfo = new DbsUserInfo();
                    dbsUserInfo.setName(ObjUtil.defaultIfBlank(dbsGroupDetail.getGroupOwner(), dbsGroupDetail.getGroupOwnerLogin()));
                    dbsUserInfo.setEmail(dbsGroupDetail.getGroupOwnerEmail());
                    dbsUserInfo.setAlias(dbsGroupDetail.getGroupOwnerLogin());
                    dbsUserInfo.setCode(dbsGroupDetail.getGroupOwnerLogin());
                    dbsUserInfo.setOneBankId(dbsGroupDetail.getGroupOwnerLogin());
                    dbsUserInfos.add(dbsUserInfo);
                }
            }
        });
        
    }
    
    
    public void buildHRUser(List<DbsUserInfo> dbsUserInfos) {
        Map<String, String> header = buildHeader();
        //请求体：{
        //"country":"string",
        //"countryMangerId":"string",
        //"empId":"string",
        //"firstName":"string",
        //"oneBankId":"string",
        //"organizationId":"string"
        //}
        Map<String, String> requestPayload = new HashMap<>();
        requestPayload.put("country", "");
        requestPayload.put("empId", "");
        requestPayload.put("firstName", "");
        requestPayload.put("oneBankId", "");
        requestPayload.put("organizationId", "");
        Optional<String> resp4Opt = HttpUtils.post(dbsProperties.getHr().getUrl(), requestPayload, header);
        resp4Opt.ifPresent(s -> {
            log.info("hr user resp is:{}", s);
            DbsResp<Map<String, Object>> bean = JSONUtil.toBean(resp4Opt.get(), new TypeReference<DbsResp<Map<String, Object>>>() {
                @Override
                public Type getType() {
                    return super.getType();
                }
            }, true);
            log.info("hr user is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            Object o = bean.getData().get("content");
            if (o instanceof List) {
                // 取回数据分析（From Quentin）
                //标记部分是需要同步存储到 DOUC 的信息
                //提取信息的下标：
                //3 ==  name
                //23 == rank
                //26 == email
                //37 == 1bankid
                //44 == mobile
                //48 == city
                
                List<?> o1 = (List<?>) o;
                for (Object o2 : o1) {
                    DbsUserInfo dbsUserInfo = new DbsUserInfo();
                    Object data = ((List<?>) o2).get(3);
                    if (data instanceof String) {
                        dbsUserInfo.setName((String) data);
                    }
                    data = ((List<?>) o2).get(23);
                    if (data instanceof String) {
                        dbsUserInfo.setRank((String) data);
                    }
                    data = ((List<?>) o2).get(26);
                    if (data instanceof String) {
                        dbsUserInfo.setEmail((String) data);
                    }
                    data = ((List<?>) o2).get(37);
                    if (data instanceof String) {
                        dbsUserInfo.setCode((String) data);
                        dbsUserInfo.setAlias((String) data);
                        dbsUserInfo.setOneBankId((String) data);
                        
                    }
                    data = ((List<?>) o2).get(44);
                    if (data instanceof String) {
                        dbsUserInfo.setMobile((String) data);
                    }
                    dbsUserInfos.add(dbsUserInfo);
                }
            }
        });
    }
    
    public void buildReadEmails(List<ReadEmail> readEmails) {
        Map<String, String> header = buildHeader();
        Optional<String> resp4Opt = HttpUtils.get(dbsProperties.getEmail().getReadUrl(), null, header);
        resp4Opt.ifPresent(s -> {
            log.info("Read email resp is:{}", s);
            DbsResp<DbsDataResp<List<ReadEmail>>> bean = JSONUtil.toBean(resp4Opt.get(), new TypeReference<DbsResp<DbsDataResp<List<ReadEmail>>>>() {
                @Override
                public Type getType() {
                    return super.getType();
                }
            }, true);
            log.info("Read email is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            readEmails.addAll(bean.getData().getData());
        });
    }
    
    public void markReadEmails(List<String> emailIds) {
        Map<String, String> header = buildHeader();
        header.put("Content-Type", "application/json");
        Optional<String> resp4Opt = HttpUtils.post(dbsProperties.getEmail().getMarkReadUrl(), emailIds, header);
        resp4Opt.ifPresent(s -> {
            log.info("Mark read email resp is:{}", s);
            DbsResp<DbsDataResp<List<ReadEmail>>> bean = JSONUtil.toBean(resp4Opt.get(), new TypeReference<DbsResp<DbsDataResp<List<ReadEmail>>>>() {
                @Override
                public Type getType() {
                    return super.getType();
                }
            }, true);
            log.info("Mark read is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
        });
    }
    
    public void buildRelease(List<DbsRespCommonGroup> releaseGroups) {
        Map<String, String> body = dbsProperties.getRelease().getParams();
        //header.put("functionId", dbsProperties.getTsoid().getFunctionId());
        Optional<String> resp4Opt = HttpUtils.post(dbsProperties.getRelease().getUrl(), body, buildHeader());
        resp4Opt.ifPresent(s -> {
            log.info("detail resp is:{}", s);
            DbsResp<DbsDataResp<List<DbsRespCommonGroup>>> bean = JSONUtil.toBean(resp4Opt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<DbsRespCommonGroup>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("detail data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            releaseGroups.addAll(bean.getData().getData());
        });
    }
    
    public void buildChange(List<DbsRespCommonGroup> changeGroups) {
        Map<String, String> body = dbsProperties.getChange().getParams();
        //header.put("functionId", dbsProperties.getTsoid().getFunctionId());
        Optional<String> resp4Opt = HttpUtils.post(dbsProperties.getChange().getUrl(), body, buildHeader());
        resp4Opt.ifPresent(s -> {
            log.info("detail resp is:{}", s);
            DbsResp<DbsDataResp<List<DbsRespCommonGroup>>> bean = JSONUtil.toBean(resp4Opt.get(),
                    new TypeReference<DbsResp<DbsDataResp<List<DbsRespCommonGroup>>>>() {
                        @Override
                        public Type getType() {
                            return super.getType();
                        }
                    }, true);
            log.info("detail data is:{} data:{}", bean, bean.getData());
            if (bean.getData() == null) {
                return;
            }
            changeGroups.addAll(bean.getData().getData());
        });
    }
}
