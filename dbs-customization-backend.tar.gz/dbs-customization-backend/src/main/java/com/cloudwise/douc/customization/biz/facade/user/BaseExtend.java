package com.cloudwise.douc.customization.biz.facade.user;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 扩展字段
 */
@Data
public class BaseExtend {
    
    
    @ApiModelProperty("扩展字段id")
    private Integer extendId;
    
    @ApiModelProperty("是否必须")
    private Boolean isMust;
    
    @ApiModelProperty("字段类型")
    private String dataType;
    
    @ApiModelProperty("字段名")
    private String name;
    
    @ApiModelProperty("字段别名")
    private String alias;
    
    @ApiModelProperty("选中名称")
    private String selectedName;
    
    @ApiModelProperty("字段值")
    private String value;
    
    @ApiModelProperty("字段值同步成员")
    private Object valueForMember;
    
}
