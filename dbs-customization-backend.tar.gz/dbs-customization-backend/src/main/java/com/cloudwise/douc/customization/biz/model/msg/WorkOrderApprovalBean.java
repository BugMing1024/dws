package com.cloudwise.douc.customization.biz.model.msg;

import com.cloudwise.douc.customization.biz.enums.CrApprovalEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author frank.zheng
 * @Date 2025-02-11
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrderApprovalBean {

    private String workOrderId;

    private CrApprovalEnum crApproval;
}
