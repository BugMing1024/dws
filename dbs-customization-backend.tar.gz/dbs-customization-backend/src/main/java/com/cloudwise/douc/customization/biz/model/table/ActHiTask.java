package com.cloudwise.douc.customization.biz.model.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/26
 */
@Data
@TableName("act_hi_taskinst")
public class ActHiTask {
    
    @TableId("id_")
    private String id_;
    
    @TableField("proc_inst_id_")
    private String procInstId_;
    
    @TableField("task_def_key_")
    private String taskDefKey;
    
    @TableField("end_time_")
    private Date endTime_;
}
