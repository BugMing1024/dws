package com.cloudwise.douc.customization.biz.service.work.order.impl;

import com.cloudwise.dosm.api.bean.form.FieldConf;
import com.cloudwise.dosm.api.bean.form.FieldInfo;
import com.cloudwise.dosm.api.bean.form.FormDataConverter;
import com.cloudwise.dosm.api.bean.utils.JsonUtils;
import com.cloudwise.douc.customization.biz.dao.MdlFormMapper;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.biz.service.work.order.DosmWorkOrderService;
import com.cloudwise.douc.customization.biz.util.DosmHttpUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @Author frank.zheng
 * @Date 2025-02-09
 */
@Slf4j
@Component
public class DosmWorkOrderServiceImpl implements DosmWorkOrderService {

    @Autowired
    private MdlFormMapper mdlFormMapper;

    @Autowired
    private DosmHttpUtil dosmHttpUtil;


    @Override
    public WorkOrderDetail getWorkOrderDetail(String workOrderId, String userId) {
        return dosmHttpUtil.getWorkOrderDetail(workOrderId, userId);
    }


    @Override
    public String getFormId(String workOrderId) {
        return mdlFormMapper.getFormId(workOrderId);
    }

    @Override
    public Map<String, FieldInfo> getFormData(String workOrderId, String userId, JsonNode formData) {
        String formId = getFormId(workOrderId);
        return getFormData(formId, formData);
    }

    @Override
    public Map<String, FieldInfo> getFormData(String workOrderId, String userId) {
        log.info("GetFormData param workOrderId:{}, userId:{}", workOrderId, userId);
        JsonNode formData = dosmHttpUtil.getFormData(workOrderId, userId);
        if (formData == null) {
            return Collections.emptyMap();
        }
        String formId = getFormId(workOrderId);
        return getFormData(formId, formData);
    }


    @Override
    public Map<String, FieldInfo> getFormData(String formId, JsonNode formData) {
        log.info("GetFormData param formId:{}", formId);
        String formFieldListStr = mdlFormMapper.getFieldListById(formId, null, null);
        if (formFieldListStr == null) {
            log.info("GetFormData formFieldListStr is empty");
            return Collections.emptyMap();
        }

        List<FieldConf> formFieldConfList = JsonUtils.convertList(formFieldListStr, FieldConf.class);
        if (CollectionUtils.isEmpty(formFieldConfList)) {
            log.info("GetFormData formFieldConfList is empty");
            return Collections.emptyMap();
        }

        Map<String, FieldInfo> formDataMap = Maps.newHashMap();
        FormDataConverter.toFieldMap(formData, formFieldConfList, formDataMap);
        return formDataMap;
    }
}
