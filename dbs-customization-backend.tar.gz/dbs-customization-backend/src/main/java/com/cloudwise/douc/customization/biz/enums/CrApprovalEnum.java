package com.cloudwise.douc.customization.biz.enums;

/**
 * @author ming.ma
 * @since 2025-01-03  10:06
 **/
public enum CrApprovalEnum {

    /**
     * 审批通过
     */
    APPROVED("Approved"),

    /**
     * 审批拒绝
     */
    REJECTED("Rejected"),

    /**
     * 审批中
     */
    PENDING_APPROVAL("Pending Approval"),

    /**
     * 关闭
     */
    CLOSED_CANCEL("Closed Cancel"),
    ;

    private final String name;

    CrApprovalEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
