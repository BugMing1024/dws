package com.cloudwise.douc.customization.biz.model.groupuser;

import com.cloudwise.douc.customization.biz.anno.ExtendMapProperty;
import com.cloudwise.douc.customization.biz.anno.MappingProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
public class DbsUserInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    
    @MappingProperty("alias")
    private String alias;
    
    @MappingProperty("code")
    private String code;
    
    @MappingProperty("status")
    private Integer status = 1;
    
    private Integer origin;
    
    private Integer adminType;
    
    @MappingProperty("name")
    private String name;
    
    private String areaCode;
    
    //    @MappingProperty("mobile")
    private String mobile;
    
    @MappingProperty("email")
    private String email;
    
    
    private String importType;
    
    
    @MappingProperty("accountId")
    private Long accountId = 110L;
    
    @ExtendMapProperty("1bankId")
    private String oneBankId;
    
    @ExtendMapProperty("tsoid")
    private String tsoId;
    
    @ExtendMapProperty("rank")
    private String rank;
    
    @ExtendMapProperty("mdGroupRank")
    private String mdGroupRank;
    
    
}
