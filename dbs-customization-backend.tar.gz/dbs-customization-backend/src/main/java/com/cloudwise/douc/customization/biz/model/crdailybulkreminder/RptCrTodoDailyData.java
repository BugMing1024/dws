package com.cloudwise.douc.customization.biz.model.crdailybulkreminder;

import lombok.Data;

/**
 * Represents daily to-do data for a user.
 */
@Data
public class RptCrTodoDailyData {
    /**
     * Unique identifier of the user.
     */
    private String userId;

    /**
     * Name of the task or to-do item.
     */
    private String taskName;

    /**
     * Number of to-do items.
     */
    private Integer todoCount;

    /**
     * Earliest scheduled start date for the to-do item.
     */
    private String earliestChangeScheduleStartdate;

    /**
     * Field to store the date when the data was created
     */
    private String createdTime;
}
