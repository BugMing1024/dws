package com.cloudwise.douc.customization.common.filter;

import com.cloudwise.douc.customization.common.context.ExecutorContext;
import com.cloudwise.douc.customization.common.context.ExecutorContextHolder;
import com.cloudwise.douc.customization.common.context.ProcessorCountContext;
import com.cloudwise.douc.customization.common.context.ResultContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author zafir.zhong
 * @description
 * @date Created in 15:05 2023/9/30.
 */
@Slf4j
@Component
public class ThreadLocalFilter extends OncePerRequestFilter {
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        //校验请求request Header中是否有对应值
        try {
            ResultContext resultContext = new ResultContext();
            ExecutorContext executorContext = new ExecutorContext();
            executorContext.setResultContext(resultContext);
            executorContext.setProcessorCountContext(new ProcessorCountContext());
            ExecutorContextHolder.set(executorContext);
            // Goes to default servlet.
            filterChain.doFilter(request, response);
        } finally {
            // 清空线程变量
            ExecutorContextHolder.reset();
        }
    }
}
