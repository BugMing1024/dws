package com.cloudwise.douc.customization.biz.model.groupuser;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
public class MdApproveGroup implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // country属性
    private String Country;
    
    // 成员姓名
    private String GroupName;
    
    // lob属性
    private String LOB;
    
    // 成员1bankId
    private String Login;
    
    private String Rank;
    
    private String Approver;
    
}
