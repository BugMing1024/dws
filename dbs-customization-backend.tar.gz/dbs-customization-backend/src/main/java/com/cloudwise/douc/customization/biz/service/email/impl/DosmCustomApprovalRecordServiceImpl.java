package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloudwise.dosm.api.bean.form.GroupBean;
import com.cloudwise.dosm.api.bean.form.UserBean;
import com.cloudwise.douc.customization.biz.dao.MdlApproveRecordDetailMapper;
import com.cloudwise.douc.customization.biz.dao.MdlApproveRecordMapper;
import com.cloudwise.douc.customization.biz.dao.MdlInstanceMapper;
import com.cloudwise.douc.customization.biz.enums.CrApprovalEnum;
import com.cloudwise.douc.customization.biz.facade.UserSSOClient;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.*;
import com.cloudwise.douc.customization.biz.model.email.dosm.ApproveBehaviorTypeEnum;
import com.cloudwise.douc.customization.biz.model.email.dosm.ApproveResultEnum;
import com.cloudwise.douc.customization.biz.model.email.dosm.RejectToEnum;
import com.cloudwise.douc.customization.biz.model.table.MdlApproveRecord;
import com.cloudwise.douc.customization.biz.model.table.MdlApproveRecordDetail;
import com.cloudwise.douc.customization.biz.model.table.MdlInstance;
import com.cloudwise.douc.customization.biz.model.table.RuTask;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomApprovalRecordService;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.esotericsoftware.minlog.Log;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author ming.ma
 * @since 2024-12-26  16:55
 **/
@Service
public class DosmCustomApprovalRecordServiceImpl implements DosmCustomApprovalRecordService {

    @Autowired
    MdlApproveRecordMapper mdlApproveRecordMapper;

    @Autowired
    MdlApproveRecordDetailMapper mdlApproveRecordDetailMapper;

    @Autowired
    UserSSOClient userSSOClient;

    @Autowired
    DosmConfig dosmConfig;

    @Autowired
    MdlInstanceMapper mdlInstanceMapper;


    @Override
    public List<ApproveRecordVo> getApprovalRecords(String processInstanceId) {
        List<ApproveRecordVo> approveRecordVos = new ArrayList<>();
        Map<String, String> dataDictMap = new HashMap<>();
        List<MdlApproveRecord> mdlApproveRecords = mdlApproveRecordMapper.getMdlApproveRecordsByProcessInstanceId(processInstanceId);
        if (CollUtil.isEmpty(mdlApproveRecords)) {
            return approveRecordVos;
        }
        List<String> mainRecordIdList = mdlApproveRecords.stream().map(MdlApproveRecord::getId).collect(Collectors.toList());
        LambdaQueryWrapper<MdlApproveRecordDetail> subRecordQuery = Wrappers.lambdaQuery(MdlApproveRecordDetail.class);
        subRecordQuery.in(MdlApproveRecordDetail::getApproveRecordId, mainRecordIdList);
        List<MdlApproveRecordDetail> mdlApproveRecordDetails = mdlApproveRecordDetailMapper.selectList(subRecordQuery);
        if (CollUtil.isEmpty(mdlApproveRecordDetails)) {
            return approveRecordVos;
        }
        Map<String, List<MdlApproveRecordDetail>> mainRecordMap = mdlApproveRecordDetails.stream()
                .collect(Collectors.groupingBy(MdlApproveRecordDetail::getApproveRecordId));
        mdlApproveRecords.forEach(mdlApproveRecord -> {
            ApproveRecordVo approveRecordVo = new ApproveRecordVo();
            approveRecordVo.setNodeId(mdlApproveRecord.getNodeId());
            approveRecordVo.setNodeName(mdlApproveRecord.getNodeName());
            approveRecordVo.setApproveStatus(mdlApproveRecord.getApproveStatus());
            if (mdlApproveRecord.getApproveResult() != null) {
                approveRecordVo.setApproveResult(mdlApproveRecord.getApproveResult().name());
            }
            List<MdlApproveRecordDetail> recordDetails = mainRecordMap.get(mdlApproveRecord.getId());
            if (CollUtil.isNotEmpty(recordDetails)) {
                List<ApproveRecordVo.ApproveResult> approveResults = new ArrayList<>();
                for (MdlApproveRecordDetail recordDetail : recordDetails) {
                    ApproveRecordVo.ApproveResult approveResult = new ApproveRecordVo.ApproveResult();
                    approveResult.setUserId(recordDetail.getCreatedBy());
                    if (CharSequenceUtil.isNotBlank(recordDetail.getReason())) {
                        String reason = recordDetail.getReason();
                        approveResult.setReason(reason);
                        String reasonLable = dataDictMap.get(reason);
                        if (CharSequenceUtil.isBlank(reasonLable)) {
                            String dataDictLable = mdlApproveRecordMapper.getDataDictLableById(reason);
                            if (CharSequenceUtil.isNotBlank(dataDictLable)) {
                                dataDictMap.put(reason, dataDictLable);
                            }
                        }
                        approveResult.setReasonLable(dataDictMap.get(reason));
                    }
                    approveResult.setApproveType(recordDetail.getApproveType());
                    approveResult.setApproveMsg(recordDetail.getApproveMsg());
                    approveResult.setTaskId(recordDetail.getTaskId());
                    approveResults.add(approveResult);
                }
                approveRecordVo.setApproveResults(approveResults);
            }
            approveRecordVos.add(approveRecordVo);
        });

        List<MdlApproveRecord> noFinishStatus = mdlApproveRecords.stream().filter(approveRecordVo -> "10".equals(approveRecordVo.getApproveStatus()))
                .collect(Collectors.toList());
        Map<String, List<RuTask>> actRuTaskNode = Maps.newHashMap();
        if (CollUtil.isNotEmpty(noFinishStatus)) {
            List<RuTask> ruTasks = mdlApproveRecordMapper.getRuTasksByProcessInstanceId(processInstanceId);
            if (CollUtil.isNotEmpty(ruTasks)) {
                actRuTaskNode = ruTasks.stream().collect(Collectors.groupingBy(RuTask::getTaskDefKey));
            }
        }
        Map<Integer, UserInfo> userInfoMap = getUserInfo(approveRecordVos, actRuTaskNode);

        handlerApproveRecord(approveRecordVos, actRuTaskNode, userInfoMap);
        return approveRecordVos;
    }

    private Map<Integer, UserInfo> getUserInfo(List<ApproveRecordVo> approveRecordVos, Map<String, List<RuTask>> actRuTaskNode) {
        Set<Long> approveUserId = new HashSet<>();
        Set<Long> approveGroupId = new HashSet<>();
        approveRecordVos.forEach(approveRecordVo -> {
            if (CollUtil.isEmpty(approveRecordVo.getApproveResults())) {
                return;
            }
            approveUserId.addAll(
                    approveRecordVo.getApproveResults().stream().map(detail -> Long.valueOf(detail.getUserId())).collect(Collectors.toSet()));
        });
        actRuTaskNode.forEach((k, v) -> {
            Set<Long> collect = v.stream().filter(s -> CharSequenceUtil.isNotBlank(s.getAssignee()) && !s.getAssignee().startsWith("GROUP_"))
                    .map(task -> Long.valueOf(task.getAssignee())).collect(Collectors.toSet());
            approveUserId.addAll(collect);
            Set<Long> groupIds = v.stream().filter(s -> CharSequenceUtil.isNotBlank(s.getAssignee()) && s.getAssignee().startsWith("GROUP_"))
                    .map(task -> Long.valueOf(task.getAssignee())).collect(Collectors.toSet());
            approveGroupId.addAll(groupIds);
        });
        List<UserInfo> userInfos = Optional.ofNullable(
                userSSOClient.getUserListByIds(Lists.newArrayList(approveUserId), Long.valueOf(dosmConfig.getUserId()),
                        Long.valueOf(dosmConfig.getAccountId()))).orElse(Collections.emptyList());
        return userInfos.stream().collect(Collectors.toMap(u -> Math.toIntExact(u.getUserId()), v -> v));
    }

    private void handlerApproveRecord(List<ApproveRecordVo> approveRecordVos, Map<String, List<RuTask>> actRuTaskNode,
                                      Map<Integer, UserInfo> userMap) {
        approveRecordVos.forEach(approveRecordVo -> {
            List<ApproveRecordVo.ApproveResult> approveResults = approveRecordVo.getApproveResults();
            if (CollUtil.isEmpty(approveResults)) {
                return;
            }
            if ("10".equals(approveRecordVo.getApproveStatus())) {
                Map<String, ApproveRecordVo.ApproveResult> recordDetailMap = approveResults.stream()
                        .collect(Collectors.toMap(ApproveRecordVo.ApproveResult::getTaskId, v -> v));
                for (ApproveRecordVo.ApproveResult approveResult : approveResults) {
                    UserInfo userInfo = userMap.get(Integer.valueOf(approveResult.getUserId()));
                    approveResult.setApproveUser(userInfo);
                }
                List<RuTask> actRuTasks = Optional.ofNullable(actRuTaskNode.get(approveRecordVo.getNodeId())).orElse(Lists.newArrayList());

                for (RuTask actRuTask : actRuTasks) {
                    ApproveRecordVo.ApproveResult mdlApproveRecordDetail = recordDetailMap.get(actRuTask.getId());
                    if (ObjectUtils.isEmpty(mdlApproveRecordDetail)) {
                        ApproveRecordVo.ApproveResult approveResult = new ApproveRecordVo.ApproveResult();
                        approveResult.setUserId(actRuTask.getAssignee());
                        approveResult.setApproveUser(userMap.get(Integer.valueOf(actRuTask.getAssignee())));
                        approveResult.setTaskId(actRuTask.getId());
                        approveResults.add(approveResult);
                    }
                }
            } else {
                approveResults.forEach(detail -> {
                    UserInfo userInfo = userMap.get(Integer.valueOf(detail.getUserId()));
                    detail.setApproveUser(userInfo);
                });
            }
        });
    }

    @Override
    public List<ApproveRecordConfigVo> getCustomApprovalRecords(String workOrderId) {
        List<ApproveRecordConfigVo> approveRecordConfigs = new ArrayList<>();
        Map<String, String> dataDictMap = new HashMap<>();
        MdlInstance mdlInstance = mdlInstanceMapper.selectMdlInstanceById(workOrderId);
        if (Objects.isNull(mdlInstance)) {
            return approveRecordConfigs;
        }
        String mdlDefKey = mdlInstance.getMdlDefKey();
        Map<String, String> nodeConfigMap = nodeConfigMap(mdlDefKey);
        String currentNodeId = getCurrentNodeId(mdlInstance.getProcessInstanceId());
        Log.info("GetCustomApprovalRecords currentNodeId:{}", currentNodeId);

        List<String> nodesBeforeApprovalStage = dosmConfig.getNodesBeforeApprovalStage();
        boolean firstNode = nodesBeforeApprovalStage != null && nodesBeforeApprovalStage.contains(currentNodeId);

        Map<String, DosmConfig.GroupProcess> groupProcessMap = dosmConfig.getGroupProcessMap();
        Object formData = mdlInstance.getFormData();
        JsonNode formDataNode = JsonUtils.toBean(formData.toString(), JsonNode.class);
        approveRecordConfigs = getApproveRecordConfigVo(formDataNode, groupProcessMap);
        for (ApproveRecordConfigVo approveRecordConfig : approveRecordConfigs) {
            approveRecordConfig.setFirstNode(firstNode);
            String nodeId = approveRecordConfig.getNodeId();
            MdlApproveRecord mdlApproveRecord = mdlApproveRecordMapper.getMdlApproveRecordsByWorkOrderIdAndNodeId(workOrderId, nodeId);
            String matchValue = nodeConfigMap.get(nodeId);
            if (CharSequenceUtil.isNotBlank(matchValue)) {
                List<MdlApproveRecord> mdlApproveRecordsByWorkOrderIdAndNodeIdV2 = mdlApproveRecordMapper.getMdlApproveRecordsByWorkOrderIdAndNodeIdV2(workOrderId, nodeId);
                JsonNode matchNode = formDataNode.get(matchValue);
                if (matchNode != null) {
                    String value = matchNode.asText();
                    if ("rejected".equals(value)) {
                        if (CollUtil.isNotEmpty(mdlApproveRecordsByWorkOrderIdAndNodeIdV2) && mdlApproveRecordsByWorkOrderIdAndNodeIdV2.size() == 2) {
                            MdlApproveRecord mdlApproveRecordTwo = mdlApproveRecordsByWorkOrderIdAndNodeIdV2.get(1);
                            RejectToEnum rejectTo = mdlApproveRecordTwo.getRejectTo();
                            if (RejectToEnum.CURRENT_NODE == rejectTo) {
                                mdlApproveRecord = mdlApproveRecordTwo;
                                approveRecordConfig.setDisplaySendForApprovalBtn(true);
                            }
                        }
                    }
                }
            }
            if (mdlApproveRecord == null) {
                continue;
            }
            approveRecordConfig.setNodeName(mdlApproveRecord.getNodeName());
            ApproveResultEnum approveResult = mdlApproveRecord.getApproveResult();
            if (approveResult == null) {
                approveRecordConfig.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
            } else {
                approveRecordConfig.setApproveResult(approveResult.name());
                switch (approveResult) {
                    case PASS:
                        approveRecordConfig.setStatus(CrApprovalEnum.APPROVED.getName());
                        break;
                    case REJECT:
                        approveRecordConfig.setStatus(CrApprovalEnum.REJECTED.getName());
                        break;
                    default:
                        break;
                }
            }
            if (firstNode) {
                approveRecordConfig.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
                approveRecordConfig.setApproveResult(null);
            }
            boolean followUser = approveRecordConfig.isFollowUser();
            List<MdlApproveRecordDetail> mdlApproveRecordDetails = new ArrayList<>();
            if (followUser) {
                List<ApproverUser> approvers = approveRecordConfig.getApprovers();
                if (CollUtil.isEmpty(approvers)) {
                    continue;
                }
                List<String> userIds = approvers.stream().map(ApproverUser::getApproverId).collect(Collectors.toList());

                LambdaQueryWrapper<MdlApproveRecordDetail> subRecordQuery = Wrappers.lambdaQuery(MdlApproveRecordDetail.class);
                subRecordQuery.eq(MdlApproveRecordDetail::getApproveRecordId, mdlApproveRecord.getId());
                subRecordQuery.in(MdlApproveRecordDetail::getCreatedBy, userIds);
                mdlApproveRecordDetails = mdlApproveRecordDetailMapper.selectList(subRecordQuery);
            } else {
                LambdaQueryWrapper<MdlApproveRecordDetail> subRecordQuery = Wrappers.lambdaQuery(MdlApproveRecordDetail.class);
                subRecordQuery.eq(MdlApproveRecordDetail::getApproveRecordId, mdlApproveRecord.getId());
                subRecordQuery.eq(MdlApproveRecordDetail::getNodeId, nodeId);
                mdlApproveRecordDetails = mdlApproveRecordDetailMapper.selectList(subRecordQuery);
            }
            List<String> userIds = mdlApproveRecordDetails.stream().map(MdlApproveRecordDetail::getCreatedBy).collect(Collectors.toList());
            List<UserInfo> userInfos = Optional.ofNullable(userSSOClient.getUserListByIds(userIds, dosmConfig.getUserId(), dosmConfig.getAccountId())).orElse(Collections.emptyList());
            Map<String, String> userMap = userInfos.stream().collect(Collectors.toMap(u -> String.valueOf(u.getUserId()), v -> v.getName() + "(" + v.getUserAlias() + ")"));

            List<ApproverUser> approvers = new ArrayList<>();
            List<UserApproveRecord> userApproveRecords = new ArrayList<>();
            for (MdlApproveRecordDetail mdlApproveRecordDetail : mdlApproveRecordDetails) {
                String createdBy = mdlApproveRecordDetail.getCreatedBy();
                ApproverUser approverUser = new ApproverUser();
                approverUser.setApproverId(createdBy);
                approverUser.setApprover(userMap.get(createdBy));
                approvers.add(approverUser);
                UserApproveRecord userApproveRecord = new UserApproveRecord();
                userApproveRecord.setApprover(userMap.get(createdBy));
                userApproveRecord.setApproverId(createdBy);

                if (firstNode) {
                    approveRecordConfig.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
                } else {
                    String approveMsg = mdlApproveRecordDetail.getApproveMsg();
                    ApproveBehaviorTypeEnum approveType = mdlApproveRecordDetail.getApproveType();
                    String reason = mdlApproveRecordDetail.getReason();
                    userApproveRecord.setReason(reason);
                    if (ApproveBehaviorTypeEnum.PASS == approveType || ApproveBehaviorTypeEnum.AUTO_PASS == approveType) {
                        userApproveRecord.setStatus(CrApprovalEnum.APPROVED.getName());
                    } else if (ApproveBehaviorTypeEnum.REJECT == approveType) {
                        userApproveRecord.setStatus(CrApprovalEnum.REJECTED.getName());
                    } else {
                        userApproveRecord.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
                    }
                    userApproveRecord.setApproveMsg(approveMsg);
                    userApproveRecord.setUpdateTime(mdlApproveRecordDetail.getUpdatedTime().getTime());
                    String reasonLable = dataDictMap.get(reason);
                    if (CharSequenceUtil.isBlank(reasonLable)) {
                        String dataDictLable = mdlApproveRecordMapper.getDataDictLableById(reason);
                        if (CharSequenceUtil.isNotBlank(dataDictLable)) {
                            dataDictMap.put(reason, dataDictLable);
                        }
                    }
                    userApproveRecord.setReasonLable(dataDictMap.get(reason));
                }
                userApproveRecords.add(userApproveRecord);
            }
            if (CollUtil.isNotEmpty(approvers)) {
                approveRecordConfig.setApprovers(approvers);
            }
            approveRecordConfig.setUserApproveRecords(userApproveRecords);
        }
        return approveRecordConfigs;
    }

    @Override
    public List<ApproveRecord> getRecords(List<ApproveRecordConfigVo> approveRecordConfigs) {

        String systemUserId = dosmConfig.getSystemUserId();
        List<ApproveRecord> records = new ArrayList<>();
        for (ApproveRecordConfigVo approveRecordConfig : approveRecordConfigs) {
            boolean firstNode = approveRecordConfig.isFirstNode();
            List<UserApproveRecord> userApproveRecords = approveRecordConfig.getUserApproveRecords();
            Map<String, UserApproveRecord> userApproveMap;
            if (CollUtil.isEmpty(userApproveRecords)) {
                userApproveMap = new HashMap<>();
            } else {
                userApproveMap = userApproveRecords.stream().collect(Collectors.toMap(UserApproveRecord::getApproverId, Function.identity()));
            }
            List<ApproverUser> approvers = approveRecordConfig.getApprovers();
            if (CollUtil.isEmpty(approvers)) {
                Log.info("GetRecords nodeId:{} approvers is empty", approveRecordConfig.getNodeId());
                ApproveRecord approveRecord = new ApproveRecord();
                approveRecord.setNodeId(approveRecordConfig.getNodeId());
                approveRecord.setNodeName(approveRecordConfig.getNodeName());
                approveRecord.setGroupName(approveRecordConfig.getGroupName());
                approveRecord.setGroupProcess(approveRecordConfig.getGroupProcess());
                approveRecord.setApproveResult(approveRecordConfig.getApproveResult());
                if (firstNode) {
                    approveRecord.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
                } else {
                    approveRecord.setStatus(approveRecordConfig.getStatus());
                }
                records.add(approveRecord);
            } else {
                for (ApproverUser approverUser : approvers) {
                    String approverId = approverUser.getApproverId();
                    //审批人为系统用户跳过
                    if (CharSequenceUtil.equals(systemUserId, approverId)) {
                        continue;
                    }
                    ApproveRecord approveRecord = new ApproveRecord();
                    approveRecord.setNodeId(approveRecordConfig.getNodeId());
                    approveRecord.setNodeName(approveRecordConfig.getNodeName());
                    approveRecord.setGroupName(approveRecordConfig.getGroupName());
                    approveRecord.setGroupProcess(approveRecordConfig.getGroupProcess());
                    approveRecord.setApprover(approverUser.getApprover());
                    approveRecord.setApproverId(approverUser.getApproverId());
                    approveRecord.setApproveResult(approveRecordConfig.getApproveResult());
                    if (firstNode) {
                        approveRecord.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
                    } else {
                        approveRecord.setStatus(approveRecordConfig.getStatus());
                    }
                    UserApproveRecord userApproveRecord = userApproveMap.get(approverUser.getApproverId());
                    if (userApproveRecord != null) {
                        approveRecord.setReasonLable(userApproveRecord.getReasonLable());
                        approveRecord.setReason(userApproveRecord.getReason());
                        approveRecord.setUpdateTime(userApproveRecord.getUpdateTime());
                        approveRecord.setApproveMsg(userApproveRecord.getApproveMsg());
                        if (CrApprovalEnum.REJECTED.getName().equals(userApproveRecord.getStatus())) {
                            approveRecord.setDisplaySendForApprovalBtn(approveRecordConfig.isDisplaySendForApprovalBtn());
                        }
                        if (firstNode) {
                            approveRecord.setDisplaySendForApprovalBtn(false);
                            approveRecord.setStatus(CrApprovalEnum.PENDING_APPROVAL.getName());
                        } else {
                            approveRecord.setStatus(userApproveRecord.getStatus());
                        }
                    }
                    records.add(approveRecord);
                }
            }
        }
        return records;
    }

    public List<ApproveRecordConfigVo> getApproveRecordConfigVo(JsonNode formDataNode, Map<String, DosmConfig.GroupProcess> groupProcessMap) {
        List<ApproveRecordConfigVo> approveRecordConfigs = new ArrayList<>();
        if (CollUtil.isEmpty(groupProcessMap) || Objects.isNull(formDataNode)) {
            return approveRecordConfigs;
        }
        groupProcessMap.forEach((groupKey, groupProcess) -> {
            ApproveRecordConfigVo approveRecordConfigVo = new ApproveRecordConfigVo();
            approveRecordConfigVo.setNodeId(groupProcess.getNodeId());
//            JsonNode groupProcessNode = formDataNode.get(groupKey);
//            if (groupProcessNode == null) {
//                return;
//            }
            approveRecordConfigVo.setGroupProcess(groupProcess.getApproveGroupType());

            String groupName = groupProcess.getGroupName();
            String approver = groupProcess.getApprover();
            boolean followUser = groupProcess.isFollowUser();
            approveRecordConfigVo.setFollowUser(followUser);
            JsonNode groupNameNode = formDataNode.get(groupName);
            boolean nullGroup = true;
            if (groupNameNode != null) {
                List<GroupBean> groupBeans = JsonUtils.toList(groupNameNode.toString(), GroupBean.class);
                if (CollUtil.isNotEmpty(groupBeans)) {
                    nullGroup = false;
                    approveRecordConfigVo.setGroupName(groupBeans.get(0).getGroupName());
                }
            } else {
                approveRecordConfigVo.setGroupName(groupName);
            }
            JsonNode approverNode = formDataNode.get(approver);
            //The processing group and processor are both empty filters
            if (nullGroup && (approverNode == null || approverNode.isNull())) {
                return;
            }
            if (approverNode != null) {
                List<ApproverUser> approvers = new ArrayList<>();
                List<UserBean> userBeans = JsonUtils.toList(approverNode.toString(), UserBean.class);
                if (CollUtil.isNotEmpty(userBeans)) {
                    for (UserBean userBean : userBeans) {
                        ApproverUser approverUser = new ApproverUser();
                        approverUser.setApprover(userBean.getUserName());
                        approverUser.setApproverId(userBean.getUserId());
                        approvers.add(approverUser);
                    }
                    approveRecordConfigVo.setApprovers(approvers);
                    approveRecordConfigs.add(approveRecordConfigVo);
                }
            }
        });
        return approveRecordConfigs;
    }


    private Map<String, String> nodeConfigMap(String mdlDefKey) {
        Map<String, String> map = new HashMap<>();
        Map<String, List<DosmConfig.NodeConfig>> processConfig = dosmConfig.getProcessConfig();
        if (processConfig == null) {
            return map;
        }
        List<DosmConfig.NodeConfig> nodeConfigs = processConfig.get(mdlDefKey);
        for (DosmConfig.NodeConfig nodeConfig : nodeConfigs) {
            map.put(nodeConfig.getNodeId(), nodeConfig.getRejectKey());
        }
        return map;
    }


    private String getCurrentNodeId(String processInstanceId) {
        List<RuTask> ruTasks = mdlApproveRecordMapper.getRuTasksByProcessInstanceId(processInstanceId);
        if (CollUtil.isNotEmpty(ruTasks)) {
            return ruTasks.get(0).getTaskDefKey();
        }
        return "";
    }
}


















