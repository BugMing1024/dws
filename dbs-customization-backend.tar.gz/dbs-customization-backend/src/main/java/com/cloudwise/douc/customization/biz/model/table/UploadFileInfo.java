package com.cloudwise.douc.customization.biz.model.table;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @author Rhyme
 * @date Create in 2022/10/10 6:20 PM
 */
@Data
@TableName("dosm_file_info")
public class UploadFileInfo implements Serializable {
    
    private static final long serialVersionUID = -8384480856717638599L;
    
    private String id;
    
    private String uid;
    
    private String url;
    
    private String type;
    
    private String fileName;
}
