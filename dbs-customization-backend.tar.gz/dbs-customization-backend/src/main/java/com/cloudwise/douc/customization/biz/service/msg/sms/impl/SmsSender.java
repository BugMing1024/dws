package com.cloudwise.douc.customization.biz.service.msg.sms.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.biz.enums.NotifyWayEnum;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.SmsMessageVo;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import com.cloudwise.douc.customization.biz.service.msg.MessageCenterService;
import com.cloudwise.douc.customization.biz.service.msg.MessageSender;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.cloudwise.message.dubbo.api.dto.DubboSendMessageResult;
import com.cloudwise.message.dubbo.api.dto.base.DubboCommonResp;
import com.cloudwise.message.dubbo.api.model.*;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * @author ming.ma
 * @since 2025-01-07  14:11
 **/
@Slf4j
@Component
public class SmsSender implements MessageSender<SmsMessageVo> {

    private static final String CONTENT_TYPE = "TEXT";

    private static final String MODULE_CODE = "112";

    private static final String RECEIVER_EXT_USER_EMAIL = "SMS";

    private static final String EXTEND_FIELD_LOB = "lob";
    private static final String EXTEND_FIELD_COUNTRY = "country";

    @Autowired
    CustomMessageRecordService customMessageRecordService;

    @Autowired
    MessageCenterService messageCenterService;

    @Override
    public String notifyWay() {
        return NotifyWayEnum.SMS.name();
    }

    @Override
    public CompletableFuture<Integer> sendV2(SmsMessageVo message) {
        return CompletableFuture.supplyAsync(() -> {
            Map<UserInfo, String> bodyList = message.getBodyList();
            if (CollUtil.isNotEmpty(bodyList)) {
                for(Map.Entry<UserInfo, String> bodyEntry: bodyList.entrySet()) {
                    message.setReceivers(Lists.newArrayList(bodyEntry.getKey()));
                    message.setBody(bodyEntry.getValue());
                    this.send(message);
                }
                return bodyList.size();
            } else {
                return send(message);
            }
        });
    }

    public Integer send(SmsMessageVo message) {
        String msgId = IdUtil.simpleUUID();
        //拼装douc消息发送接口入参
        DubboProductMultipleChannelMessageV2 request = new DubboProductMultipleChannelMessageV2();
        request.setId(msgId);
        request.setAccountId(Long.valueOf(message.getAccountId()));
        request.setModuleCode(MODULE_CODE);
        request.setLevel(DubboProductMultipleChannelMessageV2.LevelConstants.DEFAULT);
        request.setTimestamp(System.currentTimeMillis());

        //渠道设置
        DubboMessageChannel channel = new DubboMessageChannel();
        channel.setCode(DubboMessageChannel.ChannelCodeConstants.SMS);
        request.setChannels(Lists.newArrayList(channel));

        //消息内容
        DubboMessageContent content = new DubboMessageContent();
        content.setType(DubboMessageContent.TypeConstants.WORK_ORDER);

        content.setTitle(message.getTitle());
        content.setMessage(message.getBody());
        content.setContentType(CONTENT_TYPE);

        String innerValue = Constants.INNER_VALUE;
        if (message.getDetailUrl().contains(innerValue)) {
            innerValue = "";
        }
        String url = innerValue + message.getDetailUrl();
        DubboMessageButton button = DubboMessageButton.detailButtonEn(url);
        content.setMultiButton(Lists.newArrayList(button));

        // 设置 extendField
        Map<String, Object> extendField = new HashMap<>();
        extendField.put(EXTEND_FIELD_LOB, message.getLob());
        extendField.put(EXTEND_FIELD_COUNTRY, message.getCountry());

        content.setExtendField(extendField);

        request.setContent(content);
        //接收人
        DubboMessageReceivers receivers = new DubboMessageReceivers();
        List<UserInfo> receiverUsers = message.getReceivers();
        if (CollUtil.isEmpty(receiverUsers)) {
            log.info("[短信消息] 消息接收人为空");
            return null;
        }
        List<String> receiverUserIds = receiverUsers.stream().map(u->u.getUserId().toString()).collect(Collectors.toList());
        List<String> receiverEmails = receiverUsers.stream().map(u->u.getEmail()).collect(Collectors.toList());
        if (CollUtil.isNotEmpty(receiverUserIds)) {
            receivers.setUserIds(receiverUserIds.stream().map(Long::valueOf).distinct().collect(Collectors.toList()));
        }
        if (CollUtil.isNotEmpty(receiverEmails)) {
            // 设置 extendUsers
            Map<String, List<String>> extendUsers = new HashMap<>();
            extendUsers.put(RECEIVER_EXT_USER_EMAIL, new ArrayList<>(new HashSet<>(receiverEmails)));
            receivers.setExtendUsers(extendUsers);
        }

        request.setReceivers(receivers);
        //消息失败重试设置
        request.setSendMode(DubboMessageSendMode.sendOnce());
        request.setLanguage(DubboMessageLanguage.english());
        //添加消息发送记录
        CustomMessageRecord customMessageRecord = CustomMessageRecord.buildInsertInfo(message);
        customMessageRecord.setNotifyWay(NotifyWayEnum.SMS.name());
        List<DubboProductMultipleChannelMessageV2> messages = Lists.newArrayList(request);
        log.info("[短信消息] 发送内容，messages :{}", JSONUtil.toJsonStr(messages));
        customMessageRecord.setMessageRequest(JSONUtil.toJsonStr(messages));

        DubboCommonResp<List<DubboSendMessageResult>> response = messageCenterService.send(messages);
        if (!response.isSuccess()) {
            customMessageRecord.setStatus(0);
            customMessageRecord.setMessageResponse(JSONUtil.toJsonStr(response));
            customMessageRecordService.insertRecord(customMessageRecord);
            log.error("[短信消息] 发送失败，msg :{}", response.getMsg());
            return 0;
        }
        customMessageRecord.setStatus(1);
        customMessageRecord.setMessageResponse(JSONUtil.toJsonStr(response.getData()));
        customMessageRecord.setMessageId(response.getData().get(0).getId());
        customMessageRecordService.insertRecord(customMessageRecord);

        log.info("[短信消息] 发送成功，messageId:{},customMessageRecordId:{}", response.getData().get(0).getId(), customMessageRecord.getId());
        return messages.size();
    }
}
