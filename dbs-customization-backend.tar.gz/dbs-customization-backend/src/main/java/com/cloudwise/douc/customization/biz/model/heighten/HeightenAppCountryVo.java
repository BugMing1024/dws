package com.cloudwise.douc.customization.biz.model.heighten;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Magina
 * @date 2024/12/5 4:42 下午
 * @description
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HeightenAppCountryVo {
    
    @JsonProperty("CreatedDate")
    private String createdDate;
    
    @JsonProperty("CountryImpact")
    private String countryImpact;
    
    @JsonProperty("CountryOfOrigin")
    private String countryOfOrigin;
    
    @JsonProperty("FreezeSystem")
    private String freezeSystem;
    
    @JsonProperty("FreezeDate")
    private String freezeDate;
    
    @JsonProperty("ChangedDate")
    private String changedDate;
    
    @JsonProperty("Description")
    private String description;
    
    @JsonProperty("FreezeType")
    private String freezeType;
    
    @JsonProperty("FreezeReason")
    private String freezeReason;
    
    @JsonProperty("AppCode") // 这个字段可能不是所有对象都有，所以可能需要额外的处理或将其设为可选
    private String appCode;
}
