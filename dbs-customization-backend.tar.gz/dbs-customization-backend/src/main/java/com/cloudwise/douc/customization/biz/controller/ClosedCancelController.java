package com.cloudwise.douc.customization.biz.controller;

import com.cloudwise.douc.customization.biz.model.table.MdlInstance;
import com.cloudwise.douc.customization.biz.service.email.MdlInstanceService;
import com.cloudwise.douc.customization.common.model.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/24
 */
@RestController
@RequestMapping("/dosm/closedCancel")
public class ClosedCancelController {
    
    @Autowired
    private MdlInstanceService mdlInstanceService;
    
    @PostMapping("/five")
    public void closeFive() {
        mdlInstanceService.updateMdlInstance2ClosedCancelOnFive();
    }

    @PostMapping("/getBizKeyFromCRStatusAndTime")
    public ApiResponse<List<MdlInstance>>  getBizKeyFromCRStatusAndTime(@RequestBody Map<String, Object> map) {

        /**
         * groupId,dateTime
         */
        List<MdlInstance> list = mdlInstanceService.getBizKeyFromCRStatusAndTime(map);
        if(list!=null && list.size()>0){
            return new ApiResponse<>(100000, "success", list);
        }else{
            return new ApiResponse<>(100001, "error", null);
        }

    }
}
