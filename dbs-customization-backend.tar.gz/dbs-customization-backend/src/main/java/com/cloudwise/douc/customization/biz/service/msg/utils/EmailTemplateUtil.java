package com.cloudwise.douc.customization.biz.service.msg.utils;

import cn.hutool.core.io.FileUtil;
import com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum;
import com.cloudwise.douc.customization.biz.enums.SignoffConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static com.cloudwise.douc.customization.biz.enums.NotifyScenceEnum.*;
import static com.cloudwise.douc.customization.biz.enums.SignoffConstants.SignoffItem.*;
import static com.cloudwise.douc.customization.biz.enums.SignoffConstants.SignoffItem.CODE_CHECKER_SIGNOFF;

/**
 * @author ming.ma
 * @since 2024-12-06  17:29
 **/
@Slf4j
public class EmailTemplateUtil {
    
    private static final String PATH = "email/";

    private static final String SUFFIX = ".html";

    public static final Map<SignoffConstants.SignoffItem,NotifyScenceEnum> signOffTemplateMapping = new HashMap<>();

    static {
        /** cr is new -> testing signoff */
        signOffTemplateMapping.put(USER_ACCEPTANCE_TESTING, CR_NEW_TESTING_SIGNOFF);
        signOffTemplateMapping.put(REGRESSION_TESTING, CR_NEW_TESTING_SIGNOFF);
        signOffTemplateMapping.put(REVERSION_BACKOUT_ROLLBACK_TESTING, CR_NEW_TESTING_SIGNOFF);
        signOffTemplateMapping.put(PERFORMANCE_TESTING, CR_NEW_TESTING_SIGNOFF);
        signOffTemplateMapping.put(PRODUCTION_ASSURANCE_TESTING, CR_NEW_TESTING_SIGNOFF);
        signOffTemplateMapping.put(CHAOS_TESTING, CR_NEW_TESTING_SIGNOFF);

        /** cr is new -> project cutover signoff */
        signOffTemplateMapping.put(HA_DR_FLIP_SIGNOFF, CR_NEW_PRJ_HA_DR_FLIP_SIGNOFF);
        signOffTemplateMapping.put(MD_DELEGATE_SIGNOFF, CR_NEW_PRJ_MD_DELEGATE_SIGNOFF);
        signOffTemplateMapping.put(BU_APPLICATION_OWNER_SIGNOFF, CR_NEW_PRJ_BU_APP_OWNER_SIGNOFF);
        signOffTemplateMapping.put(DATA_CENTER_OPS_BATCH_SIGNOFF, CR_NEW_PRJ_DATA_CENTER_OPS_SIGNOFF);
        signOffTemplateMapping.put(IMPACT_TO_MAINFRAME_SIGNOFF, CR_NEW_PRJ_IMPACT_2_MAINFRAME_SIGNOFF);
        signOffTemplateMapping.put(DESIGN_FOR_DATA_D4D_SIGNOFF, CR_NEW_PRJ_D4D_SIGNOFF);
        signOffTemplateMapping.put(SERVICE_MONITORING_AT_SNOC, CR_NEW_PRJ_SERVICE_MONITORING_SNOC);

        /** cr is new -> other signoff */
        signOffTemplateMapping.put(IDR_SIGNOFF_OTHER, CR_NEW_OTHER_IDR_SIGNOFF);
        signOffTemplateMapping.put(ISS_SIGNOFF, CR_NEW_OTHER_ISS_SIGNOFF);
        signOffTemplateMapping.put(CODE_CHECKER_SIGNOFF, CR_NEW_OTHER_CODE_CHECKER_SIGNOFF);
        signOffTemplateMapping.put(DR_TEAM_SIGNOFF, CR_NEW_OTHER_DR_SIGNOFF);
        signOffTemplateMapping.put(STORAGE_TEAM_SIGNOFF, CR_NEW_OTHER_STORAGE_SIGNOFF);


    }
    public static String get(String name) {
        NotifyScenceEnum notifyScence = EnumUtils.getEnum(NotifyScenceEnum.class, name);
        if (notifyScence == null) {
            log.info("Not found email scene:[{}]", name);
            return "";
        }

        return get(notifyScence);
    }


    public static String get(NotifyScenceEnum notifyScence) {
        try {
            ClassPathResource classPathResource = new ClassPathResource(PATH + notifyScence.getFileName() + SUFFIX);
            log.info("Get email template path:{}", classPathResource.getPath());
            File file = classPathResource.getFile();
            return FileUtil.readString(file, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("Get email template fail，notifyScence：{}", notifyScence, e);
        }
        return null;
    }
    
}
