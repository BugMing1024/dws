package com.cloudwise.douc.customization.common.kafka;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.customization.common.condition.KafkaConsumerCondition;
import com.cloudwise.msg.config.CustomMsgConfig;
import com.cloudwise.msg.consumers.service.ConsumerService;
import com.cloudwise.msg.utils.MsgUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;


@Component(KafkaMessageServiceImpl.BEAN_NAME)
@Slf4j
@Conditional(KafkaConsumerCondition.class)
@Order(Ordered.HIGHEST_PRECEDENCE)
public class KafkaMessageServiceImpl extends AbstractMetaMessageService {
    
    public static final String BEAN_NAME = "kafka";
    
    @Autowired
    private MsgUtils msgUtils;
    
    @Override
    public String messageType() {
        return null;
    }
    
    @Override
    public boolean sendMessage(String topic, String tag, String msgBody) {
        log.info("kafka asyncSend start");
        if (StringUtils.isNotEmpty(tag)) {
            topic = topic + StrPool.UNDERLINE + tag;
        }
        log.debug("kafka asyncSend success topic = {}, data = {}", topic, msgBody);
        ListenableFuture<SendResult<String, Object>> future = msgUtils.producer().send(topic, msgBody);
        try {
            SendResult<String, Object> sendResult = future.get();
            if (sendResult != null) {
                log.info("kafka asyncSend success, topic: {}, reuslt: {}", topic, sendResult);
                return true;
            }
        } catch (Exception e) {
            log.error("kafka asyncSend error topic = {}, data = {}", topic, msgBody);
            log.error("kafka asyncSend error", e);
        }
        log.error("kafka sendMessage end(fail)");
        return false;
    }
    
    
    @Override
    public void startConsume(String consumerGroup, String topic, Object messageListener, boolean broadcasting) {
        ConsumerService consumer = msgUtils.consumer();
        consumer.consumer(CustomMsgConfig.builder().consunmerTopic(topic).build());
    }
}

