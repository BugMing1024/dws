package com.cloudwise.douc.customization.biz.model.email.dosm;

/**
 * 审批意见类型
 *
 * @author jon.lee
 * @since 2022-05-14 16:06
 **/
public enum ApproveMsgTypeEnum {
    /**
     * 自定义
     */
    CUSTOM,
    /**
     * 跟随上一相同处理人审批意见
     */
    FOLLOW;
    
}
