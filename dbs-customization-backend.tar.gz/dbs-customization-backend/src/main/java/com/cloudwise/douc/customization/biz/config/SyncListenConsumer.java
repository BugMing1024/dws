package com.cloudwise.douc.customization.biz.config;


import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsGroupInfo;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.Mapper;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.DbsGroupMappingHook;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.DbsUserMappingHook;
import com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook.ExtendMapMappings;
import com.cloudwise.douc.customization.biz.service.groupuser.writer.DoucGroupWriter;
import com.cloudwise.douc.customization.biz.service.groupuser.writer.DoucUserWriter;
import com.cloudwise.douc.customization.common.condition.KafkaConsumerCondition;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.dto.v3.group.AddOrUpdateGroupReq;
import com.cloudwise.douc.dto.v3.user.AddOrUpdateUserReq;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Conditional;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;

@Component
@Slf4j
@Conditional(KafkaConsumerCondition.class)
@RequiredArgsConstructor
public class SyncListenConsumer {
    
    private final DoucGroupWriter doucGroupWriter;
    
    private final DoucUserWriter doucUserWriter;
    
    private final ExtendMapMappings extendMapMappings;
    
    private final DoucProperties doucProperties;
    
    private Mapper<DbsGroupInfo, AddOrUpdateGroupReq> DEPT_MAPPER;
    
    private Mapper<DbsUserInfo, AddOrUpdateUserReq> DEPT_MAPPER2;
    
    @PostConstruct
    public void init() {
        DEPT_MAPPER = new Mapper<>(DbsGroupInfo.class, AddOrUpdateGroupReq.class, Collections.singleton(new DbsGroupMappingHook(extendMapMappings)));
        DEPT_MAPPER2 = new Mapper<>(DbsUserInfo.class, AddOrUpdateUserReq.class,
                Collections.singleton(new DbsUserMappingHook(doucProperties, extendMapMappings)));
    }
    
    @KafkaListener(topics = "${dbs.group.sync-topic:}", properties = {"auto.offset.reset=latest"}, groupId = "${dbs.group.group-id:}")
    public void onMessage(String message, Acknowledgment acknowledgment) {
        log.debug("kafka SyncListenConsumer consumer group get message: {}", message);
        try {
            if (StrUtil.isBlank(message)) {
                return;
            }
            List<DbsGroupInfo> dbsGroupInfos = JSONUtil.toList(message, DbsGroupInfo.class);
            doucGroupWriter.write(DEPT_MAPPER.convert(dbsGroupInfos));
        } catch (RuntimeException exception) {
            log.error("kafka SyncListenConsumer consume group message fail, message: {}", message, exception);
        }
    }
    
    @KafkaListener(topics = "${dbs.user.sync-topic:}", properties = {"auto.offset.reset=latest"}, groupId = "${dbs.user.group-id:}")
    public void onMessage2(String message, Acknowledgment acknowledgment) {
        log.debug("kafka SyncListenConsumer consumer user get message: {}", message);
        try {
            if (StrUtil.isBlank(message)) {
                return;
            }
            List<DbsUserInfo> userInfos = JSONUtil.toList(message, DbsUserInfo.class);
            doucUserWriter.write(DEPT_MAPPER2.convert(userInfos));
        } catch (RuntimeException exception) {
            log.error("kafka SyncListenConsumer consume user message fail, message: {}", message, exception);
        }
    }
    
}




