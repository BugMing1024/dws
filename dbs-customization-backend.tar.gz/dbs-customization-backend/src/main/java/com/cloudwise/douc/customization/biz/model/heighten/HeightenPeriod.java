package com.cloudwise.douc.customization.biz.model.heighten;

import lombok.Data;

import java.util.Date;

/**
 * @author Magina
 * @date 2024/12/5 10:07 上午
 * @description
 **/
@Data
public class HeightenPeriod {
    
    private String appCode;
    
    private Date freezeDate;
    
    private String freezeType;
    
    private String changedDate;
    
    private Date createdTime;
    
    private String description;
    
    private Date saveDate;
    
    private Integer id;
    
}
