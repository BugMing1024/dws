package com.cloudwise.douc.customization.biz.model.email.dosm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 审批节点默认值配置
 *
 * @author mamba.wang
 * @since 2023-02-03 15:32
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "审批节点审批配置")
public class ApproveDefaultType {
    
    @ApiModelProperty(value = "是否必填", example = "true", required = false)
    private Boolean require;
    
    @ApiModelProperty(value = "默认值", example = "审批通过/审批驳回", required = false)
    private String defMsg;
    
}
