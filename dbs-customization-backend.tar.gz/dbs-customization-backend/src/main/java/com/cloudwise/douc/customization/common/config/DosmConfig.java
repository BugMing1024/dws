package com.cloudwise.douc.customization.common.config;

import com.cloudwise.douc.customization.biz.service.msg.email.config.EmailConfig;
import com.cloudwise.douc.customization.biz.service.msg.sms.config.SmsConfig;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-11  10:35
 **/
@Data
@RefreshScope
@Configuration
@Component
@ConfigurationProperties(prefix = "dosm.custom")
public class DosmConfig {
    /**
     * 工单详情地址
     */
    private String orderDetail;
    /**
     * dosm后端ip:端口
     */
    private String host;
    /**
     * 回复邮箱地址
     */
    private String replyToAddress;

    private String hostPrefix = "http://";

    private String workOrderDetailUrl = "/api/v2/open/body/get";
    /**
     * 文件上传地址
     */
    private String uploadUrl;
    /**
     * 工单审批接口
     */
    private String approveUrl = "/api/v2/biz/btn/btnaction/approvePass";
    /**
     * 工单拒绝接口
     */
    private String approveRejectUrl = "/api/v2/biz/btn/btnaction/approveReject";
    /**
     * 工单更新接口
     */
    private String updatetUrl = "/api/v2/biz/btn/btnaction/update";
    /**
     * 工单提交接口
     */
    private String commitUrl = "/api/v2/biz/btn/btnaction/commit";

    private String accountId = "110";

    private String topAccountId = "110";

    private String userId = "2";
    /**
     * 渠道id
     */
    private String channelId;

    private SignOffStage signOffStage;

    private ApprovalStage approvalStage;

    private LvSignoffStage lvSignoffStage;

    private Map<String, String> approvalStatusMap;

    private Map<String, String> signOffStatusMap;

    private UncloseNotify uncloseNotify;

    private CloseCancel closeCancel;

    private Map<String, GroupProcess> groupProcessMap;
    private CountryLob countryLob;

    private Map<String, List<NodeConfig>> processConfig;

    private String pendingMyApprovalListLink;

    private String systemUserId = "3";


    private EmailConfig emailConfig;


    private SmsConfig smsConfig;


    @Value("${CloudwiseDrivexBaseFilePath:}")
    private String cloudwiseDrivexBaseFilePath;

    /**
     * Nodes before the approval stage
     */
    private List<String> nodesBeforeApprovalStage;


    @Data
    public static class ProcessConfig {
        private String processCode;
        private List<NodeConfig> nodeConfigs;
    }

    @Data
    public static class NodeConfig {
        private String nodeId;
        private String rejectKey;
        private boolean judge = false;
        private List<String> judgeValue;
        private String notifyScene;
        private boolean skipSend;
    }

    @Data
    public static class SignOffStage {
        private String statusKey;
        private String tableKey;
        private String tableStatusKey;
        private String userKey;
    }

    @Data
    public static class ApprovalStage {
        private String statusKey;
        private String tableKey;
        private String tableStatusKey;
        private String tableRejectionReasonCodeKey;
        private String tableApprovalRejectReasonsKey;
        private String userKey;
        private Map<String, String> reasonCodeMap;

    }

    @Data
    public static class LvSignoffStage {
        private String statusKey;
    }

    @Data
    public static class UncloseNotify {
        private String statusKey;
        private String statusKeyValue;
        private String dateRangeKey;
        private String nodeId;
        private long day = 1;
        private long time = 24 * 60 * 60 * 1000L;
    }

    @Data
    public static class CloseCancel {
        private String cmFieldCode;
        private String cmNodeId;
    }

    /**
     * 审批记录配置
     */
    @Data
    public static class GroupProcess {
        private String groupName;
        private String approveGroupType;
        private String approver;
        /**
         * Whether to follow the approver user, default to true to follow,
         * query the approval status based on the approver user,
         * false not to follow, query the specific approval user and approval status from the approval record table
         */
        private boolean followUser = true;
        private String nodeId;
    }

    @Data
    public static class CountryLob {
        private String countryOfOrigin;
        private String lob;
    }

}
