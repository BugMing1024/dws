package com.cloudwise.douc.customization.biz.model.heighten;

import lombok.Data;

import java.util.Date;

/**
 * @author Magina
 * @date 2024/12/5 10:07 上午
 * @description
 **/
@Data
public class HeightenAppCountry {
    
    private String appCode;
    
    private String countryOfOrigin;
    
    private String countryImpact;
    
    private String freezeSystem;
    
    private Date freezeDate;
    
    private Date changedDate;
    
    private String description;
    
    private String freezeType;
    
    private String freezeReason;
    
    private Date createdDate;
    
    //惟一id，由app_code,country_impact,freeze_system,freeze_date,freeze_type拼接组成
    private String id;
    
    private Date saveDate;
}

