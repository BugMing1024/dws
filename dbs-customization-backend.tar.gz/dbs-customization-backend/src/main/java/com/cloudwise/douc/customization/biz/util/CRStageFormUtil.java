package com.cloudwise.douc.customization.biz.util;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import com.cloudwise.douc.customization.biz.enums.CRStageEnum;
import com.cloudwise.douc.customization.biz.enums.EmailApproveEnum;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @author ming.ma
 * @since 2024-12-13  11:25
 **/
@Component
public class CRStageFormUtil {
    
    @Autowired
    DosmConfig dosmConfig;
    
    
    public JsonNode getStageApproveFormData(String formData, CRStageEnum stage, String userId, String status, Map<String, String> emailContent) {
        switch (stage) {
            case SIGN_OFF:
                return getSignOffApproveResult(formData, status, userId);
            case APPROVAL:
                return getApprovalResult(formData, status, userId, emailContent);
            case LV_SIGN_OFF:
                return getLvSignOffApproveResult(formData, status);
            default:
                break;
        }
        return null;
    }
    
    
    public JsonNode getSignOffApproveResult(String formData, String status, String userId) {
        ObjectNode formDataNode = JsonUtils.toObjectNode(formData);
        DosmConfig.SignOffStage signOffStage = dosmConfig.getSignOffStage();
        if (null == signOffStage) {
            return formDataNode;
        }
        Map<String, String> statusMap = dosmConfig.getSignOffStatusMap();
        String signOffStatusKey = signOffStage.getStatusKey();
        if (CharSequenceUtil.isNotBlank(signOffStatusKey)) {
            formDataNode.put(signOffStatusKey, statusMap.get(status));
        }
        String signOffTableStatusKey = signOffStage.getTableStatusKey();
        String signOffUserKey = signOffStage.getUserKey();
        String signOffTableKey = signOffStage.getTableKey();
        JsonNode tableData = formDataNode.get(signOffTableKey);
        if (tableData != null && tableData.isArray()) {
            ArrayNode arrayNode = (ArrayNode) tableData;
            for (JsonNode node : arrayNode) {
                ObjectNode objectNode = (ObjectNode) node;
                ObjectNode rowData = (ObjectNode) objectNode.get("rowData");
                if (rowData != null) {
                    ArrayNode userArray = (ArrayNode) rowData.get(signOffUserKey);
                    if (userArray != null) {
                        boolean flag = false;
                        for (JsonNode userNode : userArray) {
                            String tbUseId = userNode.get("userId").asText();
                            if (userId.equals(tbUseId)) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            rowData.put(signOffTableStatusKey, statusMap.get(status));
                        }
                    }
                }
            }
        }
        return formDataNode;
    }
    
    public JsonNode getApprovalResult(String formData, String status, String userId, Map<String, String> emailContent) {
        ObjectNode formDataNode = JsonUtils.toObjectNode(formData);
        DosmConfig.ApprovalStage approvalStage = dosmConfig.getApprovalStage();
        if (null == approvalStage) {
            return formDataNode;
        }
        Map<String, String> approvalStatusMap = dosmConfig.getApprovalStatusMap();
        String approvalStatusKey = approvalStage.getStatusKey();
        if (CharSequenceUtil.isNotBlank(approvalStatusKey)) {
            formDataNode.put(approvalStatusKey, status);
        }
        String approvalTableKey = approvalStage.getTableKey();
        String approvalTableStatusKey = approvalStage.getTableStatusKey();
        String approvalUserKey = approvalStage.getUserKey();
        String tableApprovalRejectReasonsKey = approvalStage.getTableApprovalRejectReasonsKey();
        String tableRejectionReasonCodeKey = approvalStage.getTableRejectionReasonCodeKey();
        Map<String, String> reasonCodeMap = approvalStage.getReasonCodeMap();
        JsonNode tableData = formDataNode.get(approvalTableKey);
        if (tableData != null && tableData.isArray()) {
            ArrayNode arrayNode = (ArrayNode) tableData;
            for (JsonNode node : arrayNode) {
                ObjectNode objectNode = (ObjectNode) node;
                ObjectNode rowData = (ObjectNode) objectNode.get("rowData");
                if (rowData != null) {
                    ArrayNode userArray = (ArrayNode) rowData.get(approvalUserKey);
                    if (userArray != null) {
                        boolean flag = false;
                        for (JsonNode userNode : userArray) {
                            String tbUseId = userNode.get("userId").asText();
                            if (userId.equals(tbUseId)) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            rowData.put(approvalTableStatusKey, approvalStatusMap.get(status));
                            if (EmailApproveEnum.REJECTED.getName().equals(status)) {
                                if (CharSequenceUtil.isNotBlank(tableApprovalRejectReasonsKey)) {
                                    rowData.put(tableApprovalRejectReasonsKey, emailContent.get(Constants.REJECT_REASON));
                                }
                                if (CharSequenceUtil.isNotBlank(tableRejectionReasonCodeKey)) {
                                    if (CollUtil.isNotEmpty(reasonCodeMap)) {
                                        rowData.put(tableRejectionReasonCodeKey, reasonCodeMap.get(emailContent.get(Constants.REJECT_CODE)));
                                    } else {
                                        rowData.put(tableRejectionReasonCodeKey, emailContent.get(Constants.REJECT_CODE));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return formDataNode;
    }
    
    
    public JsonNode getLvSignOffApproveResult(String formData, String status) {
        ObjectNode formDataNode = JsonUtils.toObjectNode(formData);
        DosmConfig.LvSignoffStage lvSignoffStage = dosmConfig.getLvSignoffStage();
        if (null == lvSignoffStage) {
            return formDataNode;
        }
        String signOffStatusKey = lvSignoffStage.getStatusKey();
        formDataNode.put(signOffStatusKey + "_value", status);
        return formDataNode;
    }
    
}
