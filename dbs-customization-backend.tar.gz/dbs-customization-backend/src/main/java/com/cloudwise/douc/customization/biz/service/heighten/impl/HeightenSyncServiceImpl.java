package com.cloudwise.douc.customization.biz.service.heighten.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.customization.biz.dao.HeightenMapper;
import com.cloudwise.douc.customization.biz.model.heighten.*;
import com.cloudwise.douc.customization.biz.service.heighten.HeightenSyncService;
import com.cloudwise.douc.customization.common.config.DbsProperties;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Magina
 * @date 2024/12/5 3:43 下午
 * @description
 **/
@Service
@Slf4j
public class HeightenSyncServiceImpl implements HeightenSyncService {


    @Value("${heighten.apiurl:https://itsm.cmwf.ocp.uat.dbs.com}")
    private String apiUrl;

    @Value("${heighten.apiurl.functionld:F00009}")
    private String functionld;

    @Value("${heighten.appcountry.url:/common-server/ichamp/getHeightenApp}")
    private String appcountryUrl;

    @Value("${heighten.period.url:/common-server/ichamp/getPublicHolidays}")
    private String periodUrl;

    @Autowired
    private HeightenMapper heightenMapper;

    @Autowired
    private DbsProperties dbsProperties;

    public static List<Date> isOverlap(List<Date> interval1, List<Date> interval2) {
        if (interval1.size() != 2 || interval2.size() != 2) {
            throw new IllegalArgumentException("Each interval must contain exactly two elements: start and end.");
        }

        Date start1 = interval1.get(0);
        Date end1 = interval1.get(1);
        Date start2 = interval2.get(0);
        Date end2 = interval2.get(1);

        // Determine whether there is an overlap.
        if (end1.before(start2) || end2.before(start1)) {
            // If there is no overlap, return an empty list.
            return new ArrayList<>();
        } else {
            Date overlapStart = (start1.compareTo(start2) <= 0) ? start1 : start2;
            Date overlapEnd = (end1.compareTo(end2) >= 0) ? end2 : end1;

            List<Date> overlapInterval = new ArrayList<>();
            overlapInterval.add(overlapStart);
            overlapInterval.add(overlapEnd);
            return overlapInterval;
        }
    }

    //Data conversion.
    public static List<HeightenPeriod> transHeightenPeriod(Object data) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfhms = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        List<HeightenPeriod> list = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper();

        List<HeightenPeriodVo> heightenPeriodVos = new ArrayList<>();
        try {
            heightenPeriodVos = objectMapper.readValue(JSONUtil.toJsonStr(data), new TypeReference<List<HeightenPeriodVo>>() {
            });
            heightenPeriodVos.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (heightenPeriodVos != null && heightenPeriodVos.size() > 0) {
            for (int i = 0; i < heightenPeriodVos.size(); i++) {

                try {
                    HeightenPeriodVo heightenPeriodVo = heightenPeriodVos.get(i);
                    String appCode = heightenPeriodVo.getAppCode();
                    String freezeDateStr = heightenPeriodVo.getFreezeDate();
                    String createdDateStr = heightenPeriodVo.getCreatedDate();
                    String changedDate = heightenPeriodVo.getChangedDate();
                    String description = heightenPeriodVo.getDescription();
                    String freezeType = heightenPeriodVo.getFreezeType();

                    HeightenPeriod heightenPeriod = new HeightenPeriod();

                    heightenPeriod.setAppCode(appCode);
                    Date freezeDate = sdf.parse(freezeDateStr);
                    heightenPeriod.setFreezeDate(freezeDate);
                    heightenPeriod.setFreezeType(freezeType);
                    Date createdDate = sdfhms.parse(createdDateStr);
                    heightenPeriod.setCreatedTime(createdDate);

                    heightenPeriod.setChangedDate(changedDate);
                    heightenPeriod.setDescription(description);
                    heightenPeriod.setSaveDate(new Date());
                    list.add(heightenPeriod);
                } catch (Exception e) {

                }


            }
        }

        return list;
    }

    @Override
    public Integer syncHeightenAppCountryData() {

        Integer integer = 0;

        //Retrieve the app and country data.
        String appcountryResponse = HttpUtil.createGet(apiUrl + appcountryUrl).contentType("application/json")
                .header("appCode", dbsProperties.getAppCode()).header("appKey", dbsProperties.getAppKey()).timeout(20000).execute().body();
        log.info("periodResponse :{}", JSONUtil.toJsonStr(appcountryResponse));

        Map<String, Object> map = JsonUtils.parseObject(appcountryResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            Map<String, Object> dataMap = JsonUtils.parseObject(JSONUtil.toJsonStr(map.get("data")));
            List<HeightenAppCountry> heightenAppCountries = transHeightenAppCountry(dataMap.get("Data"));
            log.info("heightenAppCountries size:{}", heightenAppCountries.size());
            log.info("heightenAppCountries:{}", JSONUtil.toJsonStr(heightenAppCountries));

            Set<String> listOldIds = heightenMapper.selHeightenAppCountryIds();
            log.info("listOldIds size:{}", listOldIds.size());

            if (listOldIds != null && listOldIds.size() > 0) {
                Set<String> listNewIds = heightenAppCountries.stream().map(HeightenAppCountry::getId).collect(Collectors.toSet());

                // Find the elements that exist in listOldIds but do not exist in listNewIds, and then delete them.
                List<String> onlyInOld = listOldIds.stream().filter(id -> !listNewIds.contains(id)).collect(Collectors.toList());
                log.info("onlyInOld :{}", onlyInOld);
                if (null != onlyInOld && onlyInOld.size() > 0) {
                    heightenMapper.delHeightenAppCountryById(onlyInOld);
                }

                // Find the elements that do not exist in `listOldIds` but exist in `listNewIds` - Add them.
                List<String> onlyInNew = listNewIds.stream().filter(id -> !listOldIds.contains(id)).collect(Collectors.toList());
                log.info("onlyInNew :{}", onlyInNew);
                if (null != onlyInNew && onlyInNew.size() > 0) {
                    List<HeightenAppCountry> heightenAppCountriesAdd = heightenAppCountries.stream()
                            .filter(country -> onlyInNew.contains(country.getId())).collect(Collectors.toList());

                    integer = heightenMapper.insertHeightenAppCountry(heightenAppCountriesAdd);
                }
            } else {
                log.info("Initial synchronization:");
                integer = heightenMapper.insertHeightenAppCountry(heightenAppCountries);
            }
        }

        return integer;
    }

    @Override
    public Integer syncHeightenPeriodData() {
        Integer integer = 0;

        String periodResponse = HttpUtil.createGet(apiUrl + periodUrl).contentType("application/json").header("appCode", dbsProperties.getAppCode())
                .header("appKey", dbsProperties.getAppKey()).timeout(20000).execute().body();
        log.info("periodResponse :{}", JSONUtil.toJsonStr(periodResponse));

        //        String periodResponse = "{\"message\":\"SUCCESS\",\"data\":{\"Data\":[{\"CreatedDate\":\"2024-11-12 14:31:31\",\"FreezeDate\":\"2024-11-20\",\"ChangedDate\":1,\"AppCode\":\"2024-11-12 14:31:31\",\"Description\":\"0\"},{\"Description\":\"0\",\"AppCode\":\"2024-11-1214:31:31\",\"ChangedDate\":1,\"FreezeDate\":\"2024-11-21\",\"CreatedDate\":\"2024-11-12 14:31:31:31\"},{\"CreatedDate\":\"2024-11-12 14:31:31\",\"FreezeDate\":\"2024-11-22\",\"ChangedDate\":1,\"AppCode\":\"2024-11-12 14:31:31\",\"Description\":\"0\"},{\"FreezeDate\":\"2024-11-23\",\"CreatedDate\":\"2024-11-12 14:31:31\",\"Description\":\"0\",\"ChangedDate\":1,\"AppCode\":\"2024-11-12 14:31:31:31\"}]}}";
        Map<String, Object> map = JsonUtils.parseObject(periodResponse);
        String message = map.get("message").toString();
        if ("SUCCESS".equals(message)) {
            Map<String, Object> dataMap = JsonUtils.parseObject(JSONUtil.toJsonStr(map.get("data")));

            List<HeightenPeriod> heightenPeriodList = transHeightenPeriod(dataMap.get("Data"));
            log.info("heightenPeriodList size:{}", heightenPeriodList.size());
            log.info("heightenPeriodList:{}", JSONUtil.toJsonStr(heightenPeriodList));
            Integer integer1 = heightenMapper.delPublicHolidays();
            integer = heightenMapper.insertHeightenPeriodList(heightenPeriodList);
        }
        return integer;
    }

    @Override
    public Map<String, Object> heightenStatus(String data) {
        Map<String, Object> result = new HashMap<>();
        //data transform formData
        JSONObject formData = JSONUtil.parseObj(data);

        //Change Type
        String changeType = formData.getStr("ChangeType");
        //Whether the selected value of "Application(s) Impacted" contains "Heighten App"
        List<String> app = formData.getBeanList("Application", String.class);
        //Does the selected value of "Country of Origin" contain "Heighten country"?
        String countryOfOrigin = formData.getStr("countryOfOrigin");
        //Does the selected value of "Country Impacted" contain "Heighten country"?
        List<String> countryImpacted = formData.getBeanList("countryImpacted", String.class);

        Long startTime = formData.getLong("changeScheduleStartTime");
        Long endTime = formData.getLong("changeScheduleEndTime");

        String desc = "";

        //All the time within the start - end time range - days
        List<String> dateList = getDateList(new Date(startTime), new Date(endTime));

        Map<String, Set<String>> map = containData();
        Set<String> containDataApp = map.get("app");
        Set<String> containDataCountryImpact = map.get("countryImpact");
        Set<String> containDataCountryOfOrigin = map.get("countryOfOrigin");
        result.put("alert", false);
        //Scenario 1
        List<String> changeTypeSceneOne = Arrays.asList("Normal", "Standard", "Standard-Annual");
        if (changeTypeSceneOne.contains(changeType)) {

            int count = heightenMapper.getHeightenCount(new Date(startTime), new Date(endTime));
            if (count > 0) {
                result.put("alert", true);
                desc = "Change Schedule Start and End date range should not contain Heighten dates.";
                result.put("desc", desc);
                return result;
            }

            if (null != app) {
                //Search for the app's time
                List<HeightenAppCountry> dataByappCodes = heightenMapper.getDataByappCode(app, dateList);
                if (null != dataByappCodes && dataByappCodes.size() > 0) {
                    //There is an overlap - Calculate the overlapping range.
                    Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataByappCodes);
                    Set<String> strings = stringListMap.keySet();
                    List<List<Date>> list = new ArrayList<>();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        list.addAll(lists);
                    }
                    if (isAlertTrue(result)) {
                        desc += "Application(s) Impacted " + app
                                + "in Heighten for selected date.Selected date range should not contain App Code Heighten dates.Heighten Date(s): ("
                                + dateToStr(list) + ")<br>";
                    } else {
                        result.put("alert", true);
                        desc = "Application(s) Impacted " + app
                                + "in Heighten for selected date.Selected date range should not contain App Code Heighten dates.Heighten Date(s): ("
                                + dateToStr(list) + ")<br>";
                    }

                }
            }
            if (null != countryOfOrigin && StringUtils.isNotEmpty(countryOfOrigin)) {
                //Search for the app's time
                List<HeightenAppCountry> dataBycountryOfOrigin = heightenMapper.getDataBycountryOfOrigin(countryOfOrigin, dateList);
                if (null != dataBycountryOfOrigin && dataBycountryOfOrigin.size() > 0) {
                    //There is an overlap - Calculate the overlapping range.
                    Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataBycountryOfOrigin);
                    Set<String> strings = stringListMap.keySet();
                    List<List<Date>> list = new ArrayList<>();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        list.addAll(lists);
                    }
                    if (isAlertTrue(result)) {
                        desc += "Country of Origin " + countryOfOrigin
                                + " in Heighten for selected date.Selected date range should not contain Country of Origin Heighten dates.Heighten Date(s):("
                                + dateToStr(list) + ")<br>";
                    } else {
                        desc = "Country of Origin " + countryOfOrigin
                                + " in Heighten for selected date.Selected date range should not contain Country of Origin Heighten dates.Heighten Date(s):("
                                + dateToStr(list) + ")<br>";
                        result.put("alert", true);
                    }

                }
            }
            if (null != countryImpacted) {
                //Search for the app's time
                List<HeightenAppCountry> dataByaCountryImpact = heightenMapper.getDataByaCountryImpact(countryImpacted, dateList);
                if (null != dataByaCountryImpact && dataByaCountryImpact.size() > 0) {
                    //There is an overlap - Calculate the overlapping range.
                    Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataByaCountryImpact);
                    Set<String> strings = stringListMap.keySet();
                    List<List<Date>> list = new ArrayList<>();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        list.addAll(lists);
                    }
                    if (isAlertTrue(result)) {
                        desc += "Country Impacted " + countryImpacted
                                + "in Heighten for selected date.Selected date range should not contain Country Impacted Heighten dates.Heighten Date(s):("
                                + dateToStr(list) + ")<br>";
                    } else {
                        desc = "Country Impacted " + countryImpacted
                                + "in Heighten for selected date.Selected date range should not contain Country Impacted Heighten dates.Heighten Date(s):("
                                + dateToStr(list) + ")<br>";
                        result.put("alert", true);
                    }

                }
            }
        }

        //Scenario 2
        if ("Heighten".equals(changeType)) {
            //Get the data of the Heighten period based on the selected startTime and endTime.
            List<HeightenPeriod> heightenPeriods = heightenMapper.getHeightenPeriodsByFreezeDate(dateList);
            if (null != heightenPeriods && heightenPeriods.size() > 0) {
                //Yes, there is an overlapping time range point.
                //                List<List<Date>> lists = heightenGroupTime(heightenPeriods);
                Map<String, List<List<Date>>> stringListMap = heightenGroupTime(heightenPeriods);
                if (ObjectUtils.isNotEmpty(stringListMap)) {
                    Set<String> strings = stringListMap.keySet();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        desc += "Reason for Heighten Freeze: " + ss + "(" + dateToStr(lists) + ") <br>";
                    }
                }
                int a = 0;
                //Start to determine whether there are overlaps among the app, country of origin, and impacted country.
                String appCountryDesc = "";
                if (null != app) {
                    //Search for the app's time
                    List<HeightenAppCountry> dataByappCodes = heightenMapper.getDataByappCode(app, dateList);
                    if (null != dataByappCodes && dataByappCodes.size() > 0) {
                        //There is an overlap - Calculate the overlapping range.
                        Map<String, List<List<Date>>> stringListMap1 = heightenAppCountryGroupTime(dataByappCodes);
                        Set<String> strings = stringListMap1.keySet();
                        for (String ss : strings) {
                            List<List<Date>> lists = stringListMap1.get(ss);
                            appCountryDesc += "" + ss + "(" + dateToStr(lists) + ") <br>";
                        }
                        a += 1;
                    } else {
                        //Determine whether it contains:
                        if (null != containDataApp) {
                            for (String appCode : app) {
                                boolean contains = containDataApp.contains(appCode);
                                if (contains) {
                                    if (isAlertTrue(result)) {
                                        desc += "There is no Heighten date between selected dates Heighten App Change Type is only applicable for ApplicationCountry Heighten dates. <br>";
                                    } else {
                                        result.put("alert", true);
                                        desc = "There is no Heighten date between selected dates Heighten App Change Type is only applicable for ApplicationCountry Heighten dates. <br>";
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                if (null != countryOfOrigin && StringUtils.isNotEmpty(countryOfOrigin)) {
                    //Search for the time related to the country of origin.
                    List<HeightenAppCountry> dataBycountryOfOrigin = heightenMapper.getDataBycountryOfOrigin(countryOfOrigin, dateList);
                    if (null != dataBycountryOfOrigin && dataBycountryOfOrigin.size() > 0) {
                        //There is an overlap - Calculate the overlapping range.
                        Map<String, List<List<Date>>> stringListMap1 = heightenAppCountryGroupTime(dataBycountryOfOrigin);
                        Set<String> strings = stringListMap1.keySet();
                        for (String ss : strings) {
                            List<List<Date>> lists = stringListMap1.get(ss);
                            appCountryDesc += "" + ss + dateToStr(lists) + " <br>";
                        }
                        a += 1;
                    } else {
                        if (null != containDataCountryOfOrigin && containDataCountryOfOrigin.contains(countryOfOrigin)) {
                            if (isAlertTrue(result)) {
                                desc += "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country of Origin Heighten dates. <br>";
                            } else {
                                result.put("alert", true);
                                desc = "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country of Origin Heighten dates. <br>";
                            }
                        }
                    }
                }
                if (null != countryImpacted) {
                    //Find the CountryImpact time
                    List<HeightenAppCountry> dataByaCountryImpact = heightenMapper.getDataByaCountryImpact(countryImpacted, dateList);
                    if (null != dataByaCountryImpact && dataByaCountryImpact.size() > 0) {
                        //There is a crossover. - Statistical crossover range
                        Map<String, List<List<Date>>> stringListMap1 = heightenAppCountryGroupTime(dataByaCountryImpact);
                        Set<String> strings = stringListMap1.keySet();
                        for (String ss : strings) {
                            List<List<Date>> lists = stringListMap1.get(ss);
                            appCountryDesc += "" + ss + "(" + dateToStr(lists) + ")" + "\n";
                        }
                        a += 1;
                    } else {
                        if (null != containDataCountryImpact && containDataCountryImpact.contains(countryImpacted)) {
                            if (isAlertTrue(result)) {
                                desc += "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country Impacted Heighten dates."
                                        + "<br>";
                            } else {
                                result.put("alert", true);
                                desc = "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country Impacted Heighten dates."
                                        + "<br>";
                            }

                        }
                    }
                }
                if (a > 0) {
                    //Presence of crossover
                    desc += "Reason for Heighten App Freeze: <br>" + appCountryDesc;
                }
            } else {
                //No crossover
                if (isAlertTrue(result)) {
                    desc += "Change Schedule Start and End date range should contain Heighten dates.";
                } else {
                    result.put("alert", true);
                    desc = "Change Schedule Start and End date range should contain Heighten dates.";
                }
            }

        }

        //Scenario 3
        if ("Heighten App".equals(changeType)) {
            if (null != app) {
                //Find the time of `app`.
                List<HeightenAppCountry> dataByappCodes = heightenMapper.getDataByappCode(app, dateList);
                if (null != dataByappCodes && dataByappCodes.size() > 0) {
                    //There is an overlap - Calculate the overlapping range.
                    Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataByappCodes);
                    Set<String> strings = stringListMap.keySet();
                    List<List<Date>> list = new ArrayList<>();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        list.addAll(lists);
                    }
                    desc += "Reason for Heighten App Freeze: Application(s) Impacted Freeze for " + app + "(" + dateToStr(list) + ") <br>";

                } else {
                    if (null != containDataApp) {
                        for (String appCode : app) {
                            if (containDataApp.contains(appCode)) {
                                if (isAlertTrue(result)) {
                                    desc += "There is no Heighten date between selected dates Heighten App Change Type is only applicable for ApplicationCountry Heighten dates. <br>";
                                } else {
                                    result.put("alert", true);
                                    desc = "There is no Heighten date between selected dates Heighten App Change Type is only applicable for ApplicationCountry Heighten dates. <br>";
                                }
                                break;
                            }
                        }
                    }
                }
            }
            if (null != countryOfOrigin && StringUtils.isNotEmpty(countryOfOrigin)) {
                //Find the time of `countryOfOrigin`.
                List<HeightenAppCountry> dataBycountryOfOrigin = heightenMapper.getDataBycountryOfOrigin(countryOfOrigin, dateList);
                if (null != dataBycountryOfOrigin && dataBycountryOfOrigin.size() > 0) {
                    //There is an overlap - Calculate the overlapping range.
                    Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataBycountryOfOrigin);
                    Set<String> strings = stringListMap.keySet();
                    List<List<Date>> list = new ArrayList<>();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        list.addAll(lists);
                    }
                    desc += "Reason for Heighten App Freeze: Country of Origin Freeze for " + countryImpacted + "(" + dateToStr(list) + ") <br>";

                } else {
                    if (null != containDataCountryOfOrigin && containDataCountryOfOrigin.contains(countryOfOrigin)) {
                        if (isAlertTrue(result)) {
                            desc += "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country of Origin Heighten dates. <br>";
                        } else {
                            result.put("alert", true);
                            desc = "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country of Origin Heighten dates. <br>";
                        }
                    }
                }
            }
            if (null != countryImpacted) {
                //Find the CountryImpact time.
                List<HeightenAppCountry> dataByaCountryImpact = heightenMapper.getDataByaCountryImpact(countryImpacted, dateList);
                if (null != dataByaCountryImpact && dataByaCountryImpact.size() > 0) {
                    //There is an overlap - Calculate the overlapping range.
                    Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataByaCountryImpact);
                    Set<String> strings = stringListMap.keySet();
                    List<List<Date>> list = new ArrayList<>();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap.get(ss);
                        list.addAll(lists);
                    }
                    desc += "Reason for Heighten App Freeze: Country of Origin Freeze for " + countryImpacted + "(" + dateToStr(list) + ")" + "<br>";
                } else {
                    if (null != containDataCountryImpact && containDataCountryImpact.contains(countryImpacted)) {
                        for (String countryImpact : countryImpacted) {
                            if (containDataCountryImpact.contains(countryImpact)) {
                                if (isAlertTrue(result)) {
                                    desc += "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country Impacted Heighten dates."
                                            + "<br>";
                                } else {
                                    result.put("alert", true);
                                    desc = "There is no Heighten date between selected dates Heighten App Change Type is only applicable for Country Impacted Heighten dates."
                                            + "<br>";
                                }

                                break;
                            }
                        }
                    }
                }
            }
        }
        result.put("desc", desc);
        return result;
    }


    @Override
    public Map<String, Object> bannerHeightenStatus(String data) {
        Map<String, Object> result = new HashMap<>();
        //data Converts formData
        JSONObject formData = JSONUtil.parseObj(data);

        //Application(s) Impacted selects whether the value includes Heighten App
        List<String> app = formData.getBeanList("Application", String.class);

        Long startTime = formData.getLong("changeScheduleStartTime");
        Long endTime = formData.getLong("changeScheduleEndTime");

        String heightenFreezeStr = "";

        //All times in the start-end time range - days
        List<String> dateList = getDateList(new Date(startTime), new Date(endTime));


        //Scenario 2
        //Obtain Heighten period data based on the selected startTime and endTime
        List<HeightenPeriod> heightenPeriods = heightenMapper.getHeightenPeriodsByFreezeDate(dateList);
        if (null != heightenPeriods && heightenPeriods.size() > 0) {
            //Yes, cross time range points
            Map<String, List<List<Date>>> stringListMap = heightenGroupTime(heightenPeriods);
            if (ObjectUtils.isNotEmpty(stringListMap)) {
                Set<String> strings = stringListMap.keySet();
                for (String ss : strings) {
                    List<List<Date>> lists = stringListMap.get(ss);
                    heightenFreezeStr += "Reason for Heighten Freeze: " + ss + "(" + dateToStr(lists) + ") <br>";
                }
            }
            int a = 0;
            //Began to judge the app, countryOfOrigin, countryImpacted whether there is a cross
            String appCountryDesc = "";
            if (null != app) {
                //Find app time
                List<HeightenAppCountry> dataByappCodes = heightenMapper.getDataByappCode(app, dateList);
                if (null != dataByappCodes && dataByappCodes.size() > 0) {
                    //There is a crossover. - Statistical crossover range
                    Map<String, List<List<Date>>> stringListMap1 = heightenAppCountryGroupTime(dataByappCodes);
                    Set<String> strings = stringListMap1.keySet();
                    for (String ss : strings) {
                        List<List<Date>> lists = stringListMap1.get(ss);
                        appCountryDesc += "" + ss + "(" + dateToStr(lists) + ") <br>";
                    }
                    a += 1;
                }
            }
            if (a > 0) {
                //Presence of crossover
                heightenFreezeStr += "Reason for Heighten App Freeze: <br>" + appCountryDesc;
            }
        } else {
        }

        String heightenAppFreezeStr = "";
        //Scenario 3
        if (null != app) {
            List<HeightenAppCountry> dataByappCodes = heightenMapper.getDataByappCode(app, dateList);
            if (null != dataByappCodes && dataByappCodes.size() > 0) {
                Map<String, List<List<Date>>> stringListMap = heightenAppCountryGroupTime(dataByappCodes);
                Set<String> strings = stringListMap.keySet();
                List<List<Date>> list = new ArrayList<>();
                for (String ss : strings) {
                    List<List<Date>> lists = stringListMap.get(ss);
                    list.addAll(lists);
                }
                heightenAppFreezeStr += "Reason for Heighten App Freeze: Application(s) Impacted Freeze for " + app + "(" + dateToStr(list) + ") <br>";

            } else {
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (StringUtils.isNotBlank(heightenAppFreezeStr)) {
            stringBuilder.append(heightenAppFreezeStr);
        }
        if (StringUtils.isNotBlank(heightenFreezeStr)) {
            stringBuilder.append(heightenFreezeStr);
        }
        result.put("desc", stringBuilder.toString());
        return result;
    }

    @Override
    public List<WorkTimeLongPiece> heightenPeriodTime(String data) {
        JSONObject formData = JSONUtil.parseObj(data);

        //Change Type
        String changeType = formData.getStr("ChangeType");

        List<WorkTimeLongPiece> listData = new ArrayList<>();

        long dayEndTime = System.currentTimeMillis();
        if (null != changeType && Strings.isNotEmpty(changeType)) {
            WorkTimeLongPiece hisDate = WorkTimeLongPiece.builder().begin(0l).end(dayEndTime).build();
            listData.add(hisDate);
            if ("Heighten".equals(changeType)) {
                //All future time points
            } else {
                //Heighten App (In the time calendar, you can only select times outside the period defined by "heighten period", and only future times can be selected.)
                List<Date> allHeightenPeriods = heightenMapper.getAllHeightenPeriods(new Date(dayEndTime - (24 * 60 * 60 * 1000)));//subtracted one day
                if (null != allHeightenPeriods && allHeightenPeriods.size() > 0) {
                    //Remove duplicates
                    Set<Date> dateSet = new HashSet<>(allHeightenPeriods);
                    List<Date> uniqueDateList = new ArrayList<>(dateSet);
                    for (int i = 0; i < uniqueDateList.size(); i++) {
                        Date date = uniqueDateList.get(i);
                        //Start time: 00:00:00
                        long startTime = dayStartOrEndTime(date, "start");
                        //End time: 00:00:00
                        long endTime = dayStartOrEndTime(date, "end");
                        WorkTimeLongPiece build = WorkTimeLongPiece.builder().begin(startTime).end(endTime).build();
                        listData.add(build);
                    }
                }
            }
        }

        return listData;
    }

    public static long dayStartOrEndTime(Date date, String type) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        long timestamp = calendar.getTime().getTime();
        if ("end".equals(type)) {
            timestamp = calendar.getTime().getTime() + (24 * 60 * 60 * 1000L - 1000L);
        }
        return timestamp;
    }

    public static List<String> getDateList(Date startTime, Date endTime) {
        List<String> dateList = new ArrayList<>();
        // Create a Calendar instance for startTime
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startTime);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        // Iterate from startTime to endTime
        while (!calendar.getTime().after(endTime)) {
            // Add the current date to the list
            dateList.add(DateUtil.format(calendar.getTime(), "yyyyMMdd"));
            // Move the calendar to the next day
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        return dateList;
    }

    public Map<String, Set<String>> containData() {
        Map<String, Set<String>> map = new HashMap<>();

        List<HeightenAppCountry> allHeightenAppCountry = heightenMapper.getAllHeightenAppCountry();

        Set<String> listApp = new HashSet<>();
        Set<String> listCountryImp = new HashSet<>();
        Set<String> ListCountryOrg = new HashSet<>();

        for (int i = 0; i < allHeightenAppCountry.size(); i++) {
            HeightenAppCountry heightenAppCountry = allHeightenAppCountry.get(i);
            listApp.add(heightenAppCountry.getAppCode());
            listCountryImp.add(heightenAppCountry.getCountryImpact());
            ListCountryOrg.add(heightenAppCountry.getCountryOfOrigin());
        }

        map.put("app", listApp);
        map.put("countryImpact", listCountryImp);
        map.put("countryOfOrigin", ListCountryOrg);

        return map;

    }

    //Statistical cross - range:
    public Map<String, List<List<Date>>> heightenAppCountryGroupTime(List<HeightenAppCountry> heightenAppCountrys) {

        Map<String, List<List<Date>>> map = new HashMap<>();
        //Group according to the descriptions.
        Set<String> descriptions = new HashSet<>();

        for (int i = 0; i < heightenAppCountrys.size(); i++) {
            HeightenAppCountry heightenAppCountry = heightenAppCountrys.get(i);
            String description = heightenAppCountry.getDescription();
            descriptions.add(description);
        }
        for (String str : descriptions) {
            List<Date> list = new ArrayList<>();
            for (int i = 0; i < heightenAppCountrys.size(); i++) {
                HeightenAppCountry heightenAppCountry = heightenAppCountrys.get(i);
                Date freezeDate = heightenAppCountry.getFreezeDate();
                String description = heightenAppCountry.getDescription();
                if (Strings.isNotEmpty(str) && str.equals(description)) {
                    list.add(freezeDate);
                }else {
                    list.add(freezeDate);
                }
            }
            List<List<Date>> lists = heightenPeriodGroupTime(list);
            if (Strings.isNotEmpty(str)){
                map.put(str, lists);
            }else {
                map.put(" ", lists);
            }
        }

        return map;
    }

    public String dateToStr(List<List<Date>> lists) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        List<String> list = new ArrayList<>();

        for (int i = 0; i < lists.size(); i++) {
            List<String> listDataStr = new ArrayList<>();

            List<Date> dates = lists.get(i);
            Date startDate = dates.get(0);
            list.add(sdf.format(startDate));
            if (dates.size() >= 2) {
                Date endTime = dates.get(dates.size() - 1);
                list.add(sdf.format(endTime));
            }
        }
        return list.stream().collect(Collectors.joining(","));
    }

    //Statistical cross - range: period
    public Map<String, List<List<Date>>> heightenGroupTime(List<HeightenPeriod> heightenPeriodList) {

        Map<String, List<List<Date>>> map = new HashMap<>();

        //Group according to the descriptions.
        Set<String> descriptions = new HashSet<>();

        for (int i = 0; i < heightenPeriodList.size(); i++) {
            HeightenPeriod heightenPeriod = heightenPeriodList.get(i);
            String description = heightenPeriod.getDescription();
            descriptions.add(description);
        }

        for (String str : descriptions) {
            List<Date> list = new ArrayList<>();
            for (int i = 0; i < heightenPeriodList.size(); i++) {
                HeightenPeriod heightenPeriod = heightenPeriodList.get(i);
                Date freezeDate = heightenPeriod.getFreezeDate();
                String description = heightenPeriod.getDescription();
                if (str.equals(description)) {
                    list.add(freezeDate);
                }
            }
            List<List<Date>> lists = heightenPeriodGroupTime(list);
            map.put(str, lists);
        }

        return map;
    }

    //Group by time.
    public static List<List<Date>> heightenPeriodGroupTime(List<Date> dates) {
        try {
            // Use a `TreeSet` to keep the times sorted.
            TreeSet<Date> sortedDates = new TreeSet<>(dates);
            // A list for storing the grouped results.
            List<List<Date>> groupedDates = new ArrayList<>();
            // Traverse the sorted times to create groups.
            Iterator<Date> iterator = sortedDates.iterator();
            if (iterator.hasNext()) {
                Date startDate = iterator.next();
                List<Date> currentGroup = new ArrayList<>();
                currentGroup.add(startDate);
                while (iterator.hasNext()) {
                    Date nextDate = iterator.next();
                    long diffInMilliseconds = nextDate.getTime() - startDate.getTime();
                    long diffInDays = diffInMilliseconds / (1000 * 60 * 60 * 24);
                    if (diffInDays == 1) {
                        // If the dates are consecutive, add them to the current group.
                        currentGroup.add(nextDate);
                    } else {
                        // If the dates are not consecutive, end the current group and start a new one.
                        groupedDates.add(currentGroup);
                        currentGroup = new ArrayList<>();
                        currentGroup.add(nextDate);
                    }
                    // Update the `startDate` to the currently traversed date for the next comparison.
                    startDate = nextDate;
                }
                //Add the last group.
                groupedDates.add(currentGroup);
            }
            return groupedDates;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<HeightenAppCountry> transHeightenAppCountry(Object data) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfhms = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        List<HeightenAppCountry> list = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper();

        List<HeightenAppCountryVo> heightenAppCountryVos = new ArrayList<>();
        try {
            heightenAppCountryVos = objectMapper.readValue(JSONUtil.toJsonStr(data), new TypeReference<List<HeightenAppCountryVo>>() {
            });
            // Now, the `freezeInfoList` contains all the parsed `FreezeInfo` objects.
            heightenAppCountryVos.forEach(System.out::println); // Here, you need to override the `toString` method of the `FreezeInfo` class to get meaningful output.
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (heightenAppCountryVos != null && heightenAppCountryVos.size() > 0) {
            for (int i = 0; i < heightenAppCountryVos.size(); i++) {
                try {
                    HeightenAppCountryVo heightenAppCountryVo = heightenAppCountryVos.get(i);
                    String appCode = heightenAppCountryVo.getAppCode();
                    String countryOfOrigin = heightenAppCountryVo.getCountryOfOrigin();
                    String countryLmpact = heightenAppCountryVo.getCountryImpact();
                    String freezeSystem = heightenAppCountryVo.getFreezeSystem();
                    String freezeDateStr = heightenAppCountryVo.getFreezeDate();
                    String changedDateStr = heightenAppCountryVo.getChangedDate();
                    String description = heightenAppCountryVo.getDescription();
                    String freezeType = heightenAppCountryVo.getFreezeType();
                    String createdDateStr = heightenAppCountryVo.getCreatedDate();
                    HeightenAppCountry heightenAppCountry = new HeightenAppCountry();

                    //A unique ID, which is composed by concatenating `app_code`, `countryOfOrigin`, `country_impact`, `freeze_system`, `freeze_date`, `freeze_type`, and `createdDateStr`.
                    String id = appCode + countryOfOrigin + countryLmpact + freezeSystem + freezeDateStr + freezeType + createdDateStr;
                    id = id.replaceAll(" ", "");
                    heightenAppCountry.setId(id);
                    heightenAppCountry.setAppCode(appCode);
                    heightenAppCountry.setCountryOfOrigin(countryOfOrigin);
                    heightenAppCountry.setCountryImpact(countryLmpact);
                    heightenAppCountry.setFreezeSystem(freezeSystem);
                    Date freezeDate = sdf.parse(freezeDateStr);
                    heightenAppCountry.setFreezeDate(freezeDate);

                    Date changedDate = sdfhms.parse(changedDateStr);
                    heightenAppCountry.setChangedDate(changedDate);

                    heightenAppCountry.setDescription(description);
                    heightenAppCountry.setFreezeType(freezeType);
                    Date createdDate = sdfhms.parse(createdDateStr);
                    heightenAppCountry.setCreatedDate(createdDate);

                    heightenAppCountry.setSaveDate(new Date());
                    list.add(heightenAppCountry);
                } catch (Exception e) {

                }
            }
        }

        return list;
    }

    public Map<String, List<Date>> validationCrossingByAppCode(List<HeightenAppCountry> heightenAppCountries) {

        Map<String, List<Date>> map = null;
        Set<String> appCodes = new HashSet<>();
        if (null != heightenAppCountries && heightenAppCountries.size() > 0) {
            for (int i = 0; i < heightenAppCountries.size(); i++) {
                HeightenAppCountry heightenAppCountry = heightenAppCountries.get(i);
                String appCode = heightenAppCountry.getAppCode();
                appCodes.add(appCode);
            }
            for (String app : appCodes) {
                List<Date> listDate = new ArrayList<>();
                for (int i = 0; i < heightenAppCountries.size(); i++) {
                    HeightenAppCountry heightenAppCountry = heightenAppCountries.get(i);
                    String appCode = heightenAppCountry.getAppCode();
                    if (app.equals(appCode)) {
                        listDate.add(heightenAppCountry.getFreezeDate());
                    }
                }
                Date minDate = Collections.min(listDate);
                Date maxDate = Collections.max(listDate);
                List<Date> list = new ArrayList<>();
                list.add(minDate);
                list.add(maxDate);
                map.put(app, list);
            }

        }

        return map;
    }

    public Map<String, List<Date>> validationCrossingByaCountryImpact(List<HeightenAppCountry> heightenAppCountries) {

        Map<String, List<Date>> map = null;
        Set<String> countryImpacts = new HashSet<>();
        for (int i = 0; i < heightenAppCountries.size(); i++) {
            HeightenAppCountry heightenAppCountry = heightenAppCountries.get(i);
            String countryImpact = heightenAppCountry.getCountryImpact();
            countryImpacts.add(countryImpact);
        }
        for (String countryImpact : countryImpacts) {
            List<Date> listDate = new ArrayList<>();
            for (int i = 0; i < heightenAppCountries.size(); i++) {
                HeightenAppCountry heightenAppCountry = heightenAppCountries.get(i);
                String countryCountryImpact = heightenAppCountry.getCountryImpact();
                if (countryImpact.equals(countryCountryImpact)) {
                    listDate.add(heightenAppCountry.getFreezeDate());
                }
            }
            Date minDate = Collections.min(listDate);
            Date maxDate = Collections.max(listDate);
            List<Date> list = new ArrayList<>();
            list.add(minDate);
            list.add(maxDate);
            map.put(countryImpact, list);
        }
        return map;
    }

    public Map<String, List<Date>> validationCrossingBycountryOfOrigin(List<HeightenAppCountry> heightenAppCountries) {

        Map<String, List<Date>> map = null;
        Set<String> countryOfOrigins = new HashSet<>();
        for (int i = 0; i < heightenAppCountries.size(); i++) {
            HeightenAppCountry heightenAppCountry = heightenAppCountries.get(i);
            String countryOfOrigin = heightenAppCountry.getCountryOfOrigin();
            countryOfOrigins.add(countryOfOrigin);
        }
        for (String countryOfOrigin : countryOfOrigins) {
            List<Date> listDate = new ArrayList<>();
            for (int i = 0; i < heightenAppCountries.size(); i++) {
                HeightenAppCountry heightenAppCountry = heightenAppCountries.get(i);
                String country = heightenAppCountry.getCountryOfOrigin();
                if (countryOfOrigin.equals(country)) {
                    listDate.add(heightenAppCountry.getFreezeDate());
                }
            }
            Date minDate = Collections.min(listDate);
            Date maxDate = Collections.max(listDate);
            List<Date> list = new ArrayList<>();
            list.add(minDate);
            list.add(maxDate);
            map.put(countryOfOrigin, list);
        }
        return map;
    }

    public static boolean isAlertTrue(Map<String, Object> dataMap) {
        if (dataMap.containsKey("alert")) {
            Object alertValue = dataMap.get("alert");
            if (alertValue instanceof Boolean) {
                return (Boolean) alertValue;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}
