package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.model.groupuser.DbsUserInfo;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.dto.v3.common.DeptInfo;
import com.cloudwise.douc.dto.v3.user.AddOrUpdateUserReq;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class DbsUserMappingHook implements MappingHook<DbsUserInfo, AddOrUpdateUserReq> {
    
    private final DoucProperties doucProperties;
    
    private final ExtendMapMappings extendMapMappings;
    
    @Override
    public void beforeMapping(DbsUserInfo source) {
    
    }
    
    @Override
    public void afterMapping(DbsUserInfo source, AddOrUpdateUserReq target) {
        target.setAccountId(doucProperties.getAccountId());
        DeptInfo info = new DeptInfo();
        info.setCode(doucProperties.getDefaultOrgCode());
        info.setIsMain(true);
        target.setDepartmentRelation(Collections.singletonList(info));
        if (doucProperties.getUserActiveDefault()) {
            target.setStatus(1);
        }
        if (StrUtil.isNotBlank(source.getMobile())) {
            String mobile = source.getMobile();
            if (!mobile.startsWith("+")) {
                mobile = "+" + mobile;
            }
            for (String areaCode : doucProperties.getAreaCode()) {
                if (mobile.startsWith(areaCode)) {
                    target.setAreaCode(areaCode);
                    target.setMobile(mobile.substring(areaCode.length()).trim());
                    break;
                }
            }
        }
        Map<String, String> mapping = extendMapMappings.mapping(source);
        target.setExtend(mapping);
    }
}
