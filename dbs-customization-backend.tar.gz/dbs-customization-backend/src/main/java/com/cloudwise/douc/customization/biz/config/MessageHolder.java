package com.cloudwise.douc.customization.biz.config;

import com.cloudwise.douc.customization.common.kafka.MetaMessageService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


@Component
public class MessageHolder implements BeanPostProcessor {
    
    private static Map<String, MetaMessageService> messageMap = new HashMap<>();
    
    private static MetaMessageService defaultBean;
    
    @Value("${message.send.mq.select:}")
    private String messageSelect;
    
    public static Map<String, MetaMessageService> getValveMap() {
        return messageMap;
    }
    
    public MetaMessageService getMessageBean() {
        // 为空肯定返回空
        if (messageMap.isEmpty()) {
            return null;
            // 只有一个返回默认
        } else if (messageMap.size() == 1) {
            return defaultBean;
        }
        // 有多个返回选择的
        MetaMessageService metaMessageService = messageMap.get(messageSelect);
        if (metaMessageService == null) {
            return defaultBean;
        }
        return metaMessageService;
    }
    
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }
    
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof MetaMessageService) {
            messageMap.put(beanName, (MetaMessageService) bean);
            if (Objects.equals(beanName, "kafka")) {
                defaultBean = (MetaMessageService) bean;
            } else if (defaultBean == null) {
                defaultBean = (MetaMessageService) bean;
            }
        }
        return bean;
    }
}

