package com.cloudwise.douc.customization.biz.enums;

/**
 * @author abell.wu
 */

public enum SignOffStatusEnum {


    WAITSEND("WAITSEND", "Waiting for Send"),

    PENDING("PENDING", "Pending Approval"),


    APPROVED("APPROVED", "Approved"),


    REJECTED("REJECTED", "Rejected"),


    ;


    private String code;


    private String desc;


    SignOffStatusEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }


}
