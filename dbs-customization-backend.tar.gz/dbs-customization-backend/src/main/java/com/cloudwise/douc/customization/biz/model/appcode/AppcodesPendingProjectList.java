package com.cloudwise.douc.customization.biz.model.appcode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Magina
 * @date 2024/12/6 4:59 下午
 * @description
 **/

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppcodesPendingProjectList {
    
    @JsonProperty("CutOverCR")
    private String cutoverCr;

    @JsonProperty("CutOverDescription")
    private String cutoverDescription;
    
    @JsonProperty("CutOverStatus")
    private String cutoverStatus;
    
    @JsonProperty("AppCode")
    private String appCode;
    
//    private Integer id;
    
    
}
