package com.cloudwise.douc.customization.biz.util;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.cloudwise.douc.customization.biz.model.email.dosm.DOSMApiVo;
import com.cloudwise.douc.customization.biz.model.email.dosm.FileVo;
import com.cloudwise.douc.customization.biz.model.email.dosm.WorkOrderDetail;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Objects;

/**
 * @author ming.ma
 * @since 2024-12-11  11:12
 **/
@Slf4j
@Component
public class DosmHttpUtil {
    
    private static final String USER_ID = "userId";
    
    private static final String ACCOUNT_ID = "accountId";
    
    private static final String TOP_ACCOUNT_ID = "topAccountId";
    
    @Autowired
    DosmConfig dosmConfig;
    
    public FileVo uploadFile(File file, String userId) {
        String uploadUrl = getHost() + dosmConfig.getUploadUrl();
        // 使用 Hutool 上传文件
        HttpResponse response = HttpUtil.createPost(uploadUrl).form("file", file).header(USER_ID, userId)
                .header(ACCOUNT_ID, dosmConfig.getAccountId()).header(TOP_ACCOUNT_ID, dosmConfig.getTopAccountId()).timeout(3000).execute();
        if (response.isOk()) {
            String body = response.body();
            DOSMApiVo tdosmApiVo = JsonUtils.toBean(body, DOSMApiVo.class);
            if (!Objects.equals(tdosmApiVo.getCode(), 100000)) {
                log.info("[dosm-api] UploadFile result fail:{}", tdosmApiVo.getMsg());
                return null;
            }
            log.info("[dosm-api] UploadFile result success:{}", tdosmApiVo.getData());
            return JsonUtils.toBean(JsonUtils.toJsonStr(tdosmApiVo.getData()), FileVo.class);
        }
        return null;
    }
    
    public String getHost() {
        String hostPrefix = dosmConfig.getHostPrefix();
        String host = dosmConfig.getHost();
        String realHost = IpUtil.getHost(host);
        return hostPrefix + realHost;
    }
    
    public boolean approveOrder(String userId, String body) {
        String approveUrl = getHost() + dosmConfig.getApproveUrl();
        log.info("[dosm-api] ApproveOrder param: url:{}, userId:{},params:{}", approveUrl, userId, body);
        String result = HttpRequest.post(approveUrl).header(USER_ID, userId).header(ACCOUNT_ID, dosmConfig.getAccountId())
                .header(TOP_ACCOUNT_ID, dosmConfig.getTopAccountId()).body(body).timeout(3000).execute().body();
        DOSMApiVo tdosmApiVo = JsonUtils.toBean(result, DOSMApiVo.class);
        if (!Objects.equals(tdosmApiVo.getCode(), 100000)) {
            log.info("[dosm-api] ApproveOrder fail:{}", tdosmApiVo.getMsg());
            return false;
        }
        log.info("[dosm-api] ApproveOrder result:{}", result);
        return true;
    }
    
    public boolean rejectOrder(String userId, String body) {
        String approveUrl = getHost() + dosmConfig.getApproveRejectUrl();
        log.info("[dosm-api] ApproveOrder param: url:{}, userId:{},params:{}", approveUrl, userId, body);
        String result = HttpRequest.post(approveUrl).header(USER_ID, userId).header(ACCOUNT_ID, dosmConfig.getAccountId())
                .header(TOP_ACCOUNT_ID, dosmConfig.getTopAccountId()).body(body).timeout(3000).execute().body();
        DOSMApiVo tdosmApiVo = JsonUtils.toBean(result, DOSMApiVo.class);
        if (!Objects.equals(tdosmApiVo.getCode(), 100000)) {
            log.info("[dosm-api] ApproveOrder fail:{}", tdosmApiVo.getMsg());
            return false;
        }
        log.info("[dosm-api] ApproveOrder result:{}", result);
        return true;
    }
    
    public boolean submitOrder(String userId, String body) {
        String approveUrl = getHost() + dosmConfig.getCommitUrl();
        log.info("[dosm-api] ApproveOrder param: url:{}, userId:{},params:{}", approveUrl, userId, body);
        String result = HttpRequest.post(approveUrl)
                //.header(USER_ID, userId)
                .header(USER_ID, userId).header(ACCOUNT_ID, dosmConfig.getAccountId()).header(TOP_ACCOUNT_ID, dosmConfig.getTopAccountId()).body(body)
                .timeout(5000).execute().body();
        DOSMApiVo tdosmApiVo = JsonUtils.toBean(result, DOSMApiVo.class);
        if (!Objects.equals(tdosmApiVo.getCode(), 100000)) {
            log.info("[dosm-api] ApproveOrder fail:{}", tdosmApiVo.getMsg());
            return false;
        }
        log.info("[dosm-api] ApproveOrder result:{}", result);
        return true;
    }
    
    public WorkOrderDetail getWorkOrderDetail(String workOrderId, String userId) {
        log.info("Get workorderDetail param workOrderId:{},userId:{}", workOrderId, userId);
        String workOrderDetailUrl = getHost() + dosmConfig.getWorkOrderDetailUrl() + "?id=" + workOrderId;

        log.info("[dosm-api] getWorkorderDetail param: url:{}, userId:{}", workOrderDetailUrl, userId);
        String result = HttpRequest.get(workOrderDetailUrl).header(USER_ID, userId).header(ACCOUNT_ID, dosmConfig.getAccountId())
                .header(TOP_ACCOUNT_ID, dosmConfig.getTopAccountId()).timeout(5000).execute().body();
        log.info("[dosm-api] getWorkorderDetail result url:{},userId:{} result:{}", workOrderDetailUrl, userId, result);
        DOSMApiVo tdosmApiVo = JsonUtils.toBean(result, DOSMApiVo.class);
        if (!Objects.equals(tdosmApiVo.getCode(), 100000)) {
            log.info("[dosm-api] result fail:{}", tdosmApiVo.getMsg());
            return null;
        }
        log.info("[dosm-api] getWorkorderDetail result:{}", result);
        return JsonUtils.toBean(JsonUtils.toJsonStr(tdosmApiVo.getData()), WorkOrderDetail.class);
    }

    public JsonNode getFormData(String workOrderId, String userId) {
        WorkOrderDetail workorderDetail = this.getWorkOrderDetail(workOrderId, userId);
        if (null == workorderDetail) {
            return null;
        }
        return JsonUtils.toJsonNode(workorderDetail.getFormData());
    }

}
