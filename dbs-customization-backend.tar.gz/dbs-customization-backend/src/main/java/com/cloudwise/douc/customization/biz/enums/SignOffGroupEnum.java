package com.cloudwise.douc.customization.biz.enums;

/**
 * signOff group 类型分组
 *
 * @author abell.wu
 */
public enum SignOffGroupEnum {


    TESTING("TESTING", "testing signOff"),

    PROJECT_CONVERT("PROJECT_CONVERT", "project convert signOff"),

    HEIGHTEN("HEIGHTEN", "Heighten signOff"),

    OTHER("OTHER", "Heighten signOff"),


    ;


    private String code;


    private String desc;


    SignOffGroupEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }


}
