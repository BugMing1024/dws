package com.cloudwise.douc.customization.common.model;

import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorRouteStrategyEnum;
import lombok.Data;

/**
 * xxl的配置问题
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-12-22 00:51; update at 2024-12-22 00:51
 */
@Data
public class XxlDataSetting {
    
    private String name;
    
    private String cron;
    
    private boolean enabled;
    
    private ExecutorRouteStrategyEnum route;
    
}
