package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.service.email.MdlInstanceService;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/26
 */
@Slf4j
@RestController()
@SyncEndpoint(name = "closedCancelOnOne", cron = "0 0 13 * * ? ")
@RequestMapping("/workOrder/closedCancelOnOne")
@Conditional(value = SyncCheckCondition.class)
public class ClosedCancelOnePmJobHandler {
    
    @Autowired
    private MdlInstanceService mdlInstanceService;
    
    @GetMapping()
    @XxlJob("closedCancelOnOne")
    public void jobRun() {
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            executeInternal();
        });
    }
    
    private void executeInternal() {
        mdlInstanceService.updateMdlInstance2ClosedCancelOnOne();
    }
}
