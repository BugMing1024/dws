package com.cloudwise.douc.customization.common.util;


import cn.hutool.core.builder.EqualsBuilder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FieldComparator {
    
    public static <T, U> boolean compareFields(T object1, U object2, String[] fieldNames1, String[] fieldNames2) {
        if (fieldNames1.length != fieldNames2.length) {
            throw new IllegalArgumentException("compare fields length does not match field names length");
        }
        for (int i = 0; i < fieldNames1.length; i++) {
            try {
                Object value1 = object1.getClass().getMethod("get" + fieldNames1[i].substring(0, 1).toUpperCase() + fieldNames1[i].substring(1))
                        .invoke(object1);
                Object value2 = object2.getClass().getMethod("get" + fieldNames2[i].substring(0, 1).toUpperCase() + fieldNames2[i].substring(1))
                        .invoke(object2);
                if (!EqualsBuilder.reflectionEquals(value1, value2)) {
                    return false;
                }
            } catch (Exception e) {
                log.error("compareFields error, o1:{},o2:{},field1:{},field2:{}", object1, object2, fieldNames1, fieldNames2, e);
                return false;
            }
        }
        return true;
    }
}