package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloudwise.douc.customization.biz.dao.CustomMessageReadRecordMapper;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageReadRecord;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageReadRecordService;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  10:05
 **/
@Service
public class CustomMessageReadRecordServiceImpl extends ServiceImpl<CustomMessageReadRecordMapper, CustomMessageReadRecord> implements CustomMessageReadRecordService {

    @Autowired
    CustomMessageReadRecordMapper customMessageReadRecordMapper;

    @Override
    public String insertRecord(CustomMessageReadRecord messageRecord) {
        customMessageReadRecordMapper.insert(messageRecord);
        return messageRecord.getId();
    }

    @Override
    public void insertRecords(List<CustomMessageReadRecord> list) {
        if(CollUtil.isEmpty(list)){
            return;
        }
        customMessageReadRecordMapper.insert(list, list.size());
    }

    @Override
    public String updateStatus(String id) {
        CustomMessageReadRecord messageRecord = new CustomMessageReadRecord();
        messageRecord.setStatus(1);
        customMessageReadRecordMapper.updateById(messageRecord);
        return null;
    }

    @Override
    public CustomMessageReadRecord getCustomMessageReadRecordByMessageId(String messageId) {
        LambdaQueryWrapper<CustomMessageReadRecord> queryWrapper = Wrappers.lambdaQuery(CustomMessageReadRecord.class)
                .eq(CustomMessageReadRecord::getMessageId, messageId);
        queryWrapper.select(CustomMessageReadRecord::getId);
        return customMessageReadRecordMapper.selectOne(queryWrapper);
    }
}
