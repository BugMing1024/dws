package com.cloudwise.douc.customization.biz.model.email;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author ming.ma
 * @since 2025-01-09  16:41
 **/
@Data
public class ReadEmail implements Serializable {

    private static final long serialVersionUID = -1974061597824311409L;

    private String id;
    private String from;
    private List<String> to;
    private List<String> cc;
    private List<String> bcc;
    private String subject;
    private String body;
    private String attachment;
    private String remarks;


}
