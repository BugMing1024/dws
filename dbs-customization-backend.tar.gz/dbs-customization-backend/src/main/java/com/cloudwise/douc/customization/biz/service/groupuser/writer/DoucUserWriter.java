package com.cloudwise.douc.customization.biz.service.groupuser.writer;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.context.ExecutorContext;
import com.cloudwise.douc.customization.common.context.ExecutorContextHolder;
import com.cloudwise.douc.customization.common.exception.DoucSyncException;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.dto.DubboSyncResultInfo;
import com.cloudwise.douc.dto.v3.common.CommonResp;
import com.cloudwise.douc.dto.v3.common.DataMode;
import com.cloudwise.douc.dto.v3.user.AddOrUpdateUserReq;
import com.cloudwise.douc.facadev3.UserFacade;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created on 2022-4-8.
 *
 * @author skiya
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DoucUserWriter implements Writer<AddOrUpdateUserReq> {
    
    private final DoucProperties doucProperties;
    
    //    @DubboReference(lazy = true, check = false, timeout = 5000, url = "rest://${rest.svc.douc:}")
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private UserFacade userFacade;
    
    @Override
    public void write(List<AddOrUpdateUserReq> users) {
        if (CollUtil.isEmpty(users)) {
            return;
        }
        List<AddOrUpdateUserReq> finalUsers = mergeUsersByCode(users);
        Set<String> failIds = CollUtil.newHashSet();
        Lists.partition(finalUsers, doucProperties.getMaxSyncSize()).forEach(part -> {
            try {
                if (!Objects.equals(doucProperties.getIgnoreNull(), true)) {
                    part.stream().forEach(addOrUpdateUserReq -> {
                        addOrUpdateUserReq.setDataModel(DataMode.EMPTY);
                    });
                }
                log.info("sync user data:{}", part);
                CommonResp<List<DubboSyncResultInfo>> listCommonResp = userFacade.addOrUpdateUser(part);
                log.info("sync user result:{}", JsonUtils.toJsonStr(listCommonResp));
                ThreadUtil.sleep(doucProperties.getAntiRateLimitInterval());
            } catch (DoucSyncException e) {
                log.warn("sync user failed, data:{}", JsonUtils.toJsonStr(e.getSyncResults()));
                failIds.addAll(e.getAllFailIds());
            }
        });
        // 通过 thread 传递 userId
        Optional.ofNullable(ExecutorContextHolder.get()).map(ExecutorContext::getResultContext).ifPresent(context -> {
            Set<String> userIds = context.getFailCodes();
            userIds.addAll(finalUsers.stream().map(AddOrUpdateUserReq::getCode).collect(Collectors.toSet()));
            userIds.removeAll(failIds);
        });
        Optional.ofNullable(ExecutorContextHolder.get()).map(ExecutorContext::getProcessorCountContext).ifPresent(context -> {
            context.updateFailedCount(failIds.size());
        });
    }
    
    public List<AddOrUpdateUserReq> mergeUsersByCode(List<AddOrUpdateUserReq> users) {
        // 使用Map来存储以code为键，第一个出现的对应AddOrUpdateUserReq对象为值
        Map<String, AddOrUpdateUserReq> codeToUserMap = new HashMap<>();
        
        for (AddOrUpdateUserReq user : users) {
            String code = user.getCode();
            if (!codeToUserMap.containsKey(code)) {
                // 如果map中还没有该code对应的元素，直接放入
                codeToUserMap.put(code, user);
            } else {
                // 如果已经存在该code对应的元素，进行合并逻辑（这里假设AddOrUpdateUserReq中的属性需要合并，可根据实际需求调整）
                AddOrUpdateUserReq existingUser = codeToUserMap.get(code);
                log.warn("发现重复的code键进行合并: {}，重复数据将取第一个值：{}。", existingUser.getCode(), existingUser);
                BeanUtil.copyProperties(user, existingUser, true);
            }
        }
        return new ArrayList<>(codeToUserMap.values());
    }
    
}
