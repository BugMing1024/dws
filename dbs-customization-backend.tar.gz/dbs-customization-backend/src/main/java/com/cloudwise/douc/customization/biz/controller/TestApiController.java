package com.cloudwise.douc.customization.biz.controller;

import cn.hutool.core.util.IdUtil;
import com.cloudwise.douc.customization.biz.dao.UploadFileMapper;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.model.msg.WorkOrderApprovalBean;
import com.cloudwise.douc.customization.biz.model.table.CustomMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomMessageRecordService;
import com.cloudwise.douc.customization.biz.service.email.DosmCustomService;
import com.cloudwise.douc.customization.biz.service.email.EmailTicketingJobService;
import com.cloudwise.douc.customization.biz.service.email.RetryFailEmailMessageService;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailTemplateUtil;
import com.cloudwise.douc.customization.biz.service.msg.utils.SmsAnalysisUtil;
import com.cloudwise.douc.customization.common.model.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-04  10:14
 **/
@RestController
@RequestMapping("/test")
public class TestApiController {


    @Autowired
    DosmCustomService dosmCustomService;


    @Autowired
    EmailTicketingJobService emailTicketingJobService;

    @Autowired
    CustomMessageRecordService customMessageRecordService;

    @Autowired
    RetryFailEmailMessageService retryFailEmailMessageService;

    @Autowired
    UploadFileMapper uploadFileMapper;

    @GetMapping("/testMapper")
    public ApiResponse<Object> testMapper() {
        CustomMessageRecord customMessageRecord = new CustomMessageRecord();
        customMessageRecord.setId(IdUtil.fastSimpleUUID());
        customMessageRecord.setCreatedBy("2");
        customMessageRecord.setAccountId("110");
        customMessageRecord.setTopAccountId("110");
        customMessageRecord.setNodeId("test");
        customMessageRecord.setNotifyScene("est");
        Date date = new Date();
        customMessageRecord.setUpdatedBy("1");
        customMessageRecord.setUpdatedTime(date);
        customMessageRecord.setCreatedTime(date);
        customMessageRecord.setIsDel(0);
        return ApiResponse.ok(customMessageRecordService.insertRecord(customMessageRecord));
    }

    @GetMapping("/emailSender")
    public ApiResponse<Object> getResult() {
        return ApiResponse.ok(dosmCustomService.sendMessage(null));
    }


    @GetMapping("/emailTicketingJob")
    public void emailTicketingJob() {
        emailTicketingJobService.handle(null);
    }

    @GetMapping("/html")
    public String getHtml() {
        return EmailTemplateUtil.get("ApproveRemin");
    }

    @GetMapping("/retryFailEmailMessage")
    public void retryFailEmailMessage() {
        retryFailEmailMessageService.retryFailEmailMessage();
    }

    @GetMapping("/sendDelayMessage")
    public void sendDelayMessage() {
        retryFailEmailMessageService.sendDelayMessage();
    }

    @PostMapping("/getFileInfos")
    public ApiResponse<Object> getFileInfos(@RequestBody List<String> fileIds) {
        return ApiResponse.ok(uploadFileMapper.selectFileInfoListByIds(fileIds));
    }

//    @PostMapping("/testGetReadEmail")
//    public void testGetReadEmail() {
//        emailTickingJobHandler.emailTickingJob();
//    }


    @PostMapping("/sendApprovalMsg")
    public Boolean sendApprovalMsg(@RequestBody WorkOrderApprovalBean workOrderApproval) {
        MessageContext emailMsgContext = EmailAnalysisUtil.buildApprovalMsgContext(workOrderApproval);
        dosmCustomService.sendMessage(emailMsgContext);

        MessageContext smsMsgContext = SmsAnalysisUtil.buildApprovalMsgContext(workOrderApproval);
        dosmCustomService.sendMessage(smsMsgContext);
        return true;
    }

}
