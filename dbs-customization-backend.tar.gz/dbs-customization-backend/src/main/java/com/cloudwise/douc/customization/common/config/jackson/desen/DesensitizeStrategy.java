package com.cloudwise.douc.customization.common.config.jackson.desen;

import com.cloudwise.douc.customization.common.config.jackson.desen.impl.EmailDesensitization;
import com.cloudwise.douc.customization.common.config.jackson.desen.impl.MobileDesensitization;
import com.cloudwise.douc.customization.common.config.jackson.desen.impl.NameDesensitization;
import com.cloudwise.douc.customization.common.config.jackson.desen.impl.NoneDesensitization;
import com.cloudwise.douc.customization.common.config.jackson.desen.impl.PasswordDesensitization;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
public enum DesensitizeStrategy {
    
    /**
     * 无脱敏策略
     */
    NONE(NoneDesensitization.class),
    /**
     * 姓名脱敏
     */
    NAME(NameDesensitization.class),
    /**
     * 密码脱敏
     */
    PASSWORD(PasswordDesensitization.class),
    /**
     * 邮箱脱敏
     */
    EMAIL(EmailDesensitization.class),
    /**
     * 手机号脱敏
     */
    MOBILE(MobileDesensitization.class);
    
    public final Class<? extends Desensitization> desensitizeClass;
    
    DesensitizeStrategy(Class<? extends Desensitization> desensitizeClass) {
        this.desensitizeClass = desensitizeClass;
    }
}
