package com.cloudwise.douc.customization.common.config;

import com.cloudwise.douc.customization.common.util.JsonUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
@Data
@Slf4j
@Component
@ConfigurationProperties(prefix = DoucProperties.PREFIX)
public class DoucProperties implements InitializingBean {
    
    public static final String PREFIX = "douc";
    
    private String host;
    
    private Long adminId = 2L;
    
    private Long accountId = 110L;
    
    private String rootOrgCode;
    
    private String defaultOrgCode;
    
    private Boolean orgActiveDefault = false;
    
    private Boolean userActiveDefault = false;
    
    private Boolean orderDepartment = true;
    
    private Boolean orderUsersByLeaderCode = true;
    
    private Boolean syncUserLeaderCode = false;
    
    private Long antiRateLimitInterval = 50L;
    
    private Integer maxSyncSize = 5;
    
    private Boolean ignoreNull = true;
    
    //    private String approverCode;
    //
    //    private String implementerCode;
    //
    //    private String mdApproverCode;
    //
    //    private String hrCode;
    
    private String lobCountryMappingCode;
    
    private List<String> areaCode;
    
    private Boolean groupIncludeUser;
    
    private String initDoucHttpUrl;
    
    private String initDoucDubboUrl;
    
    private String initAppCodeUrl;
    
    private List<String> initInitType;
    
    private String initDicTypeParam;
    
    private String initDicDataParam;
    
    private String initExtUserParam;
    
    private String initExtGroupParam;
    
    private String initRoleGroupParam;
    
    private String initRoleParam;
    
    private String initGroupParam;
    
    private String initGroupCustParam;
    
    private String initGroupSearchParam;
    
    private List<String> initRelaGroupDicTypeParam;
    
    private List<String> initRelaGroupCustCodeParam;
    
    @Override
    public void afterPropertiesSet() {
        log.info("Douc properties loaded successfully: {}", JsonUtils.toJsonStr(this));
    }
    
}
