package com.cloudwise.douc.customization.biz.model.email.dosm;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 审批节点默认值配置
 *
 * @author mamba.wang
 * @since 2023-02-03 15:32
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "审批节点默认值配置")
public class ApproveDefault {
    
    @ApiModelProperty(value = "审批通过", example = "", required = true)
    private ApproveDefaultType pass;
    
    @ApiModelProperty(value = "审批驳回", example = "", required = true)
    private ApproveDefaultType reject;
    
}
