package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

/**
 * @Author hekongtao
 * @Date 2025/2/5
 */
@Slf4j
public class CrCloseCancelAnalysis extends AbstractBaseAnalysis {

    public final static CrCloseCancelAnalysis INSTANCE = new CrCloseCancelAnalysis();


    private static final String TITLE_TEMPLATE = "CR is Closed Cancel for CR Number: ${bizKey}";


    @Override
    public String getTitleTemplate() {
        return TITLE_TEMPLATE;
    }

    @Override
    public void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap) {
    }

}
