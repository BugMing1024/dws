package com.cloudwise.douc.customization.biz.job;

import com.cloudwise.douc.customization.biz.anno.SyncEndpoint;
import com.cloudwise.douc.customization.biz.service.appcode.AppcodeLobCountrySyncService;
import com.cloudwise.douc.customization.biz.util.SyncJobUtil;
import com.cloudwise.douc.customization.common.condition.SyncCheckCondition;
import com.cloudwise.douc.customization.common.constant.Constants;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Magina
 * @date 2025/2/10 5:53 PM
 * @description
 **/
@Slf4j
@RestController()
@SyncEndpoint(name = "syncAppCodeResiliencyInfo", cron = Constants.SYNC_APPCODE_RESILIENCY_DATA_CRON)
@RequestMapping()
@Conditional(value = SyncCheckCondition.class)
public class AppCodeResiliencyDataJob {
    
    private AtomicBoolean SYNC_APP_CODE_RESILIENCY_IS_RUNING = new AtomicBoolean(false);
    
    
    @Autowired
    private AppcodeLobCountrySyncService appcodeLobCountrySyncService;
    
    @XxlJob("syncAppCodeResiliencyInfo")
    @GetMapping("/api/appcodeLobCountry/syncAppCodeResiliencyInfo")
    public void syncAppCodeResiliencyInfo() {
        log.info("syncAppCodeInfo start");
        SyncJobUtil.syncJob(() -> appcodeLobCountrySyncService.syncAppCodeResiliencyInfo(), SYNC_APP_CODE_RESILIENCY_IS_RUNING);
        log.info("syncAppCodeInfo end");
    }
}
