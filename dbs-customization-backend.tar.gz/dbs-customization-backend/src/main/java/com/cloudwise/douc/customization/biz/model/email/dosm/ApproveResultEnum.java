package com.cloudwise.douc.customization.biz.model.email.dosm;

/**
 * 审批结果
 *
 * @author jon.lee
 * @since 2022-05-14 16:06
 **/
public enum ApproveResultEnum {
    /**
     * 通过
     */
    PASS,
    /**
     * 驳回
     */
    REJECT
}
