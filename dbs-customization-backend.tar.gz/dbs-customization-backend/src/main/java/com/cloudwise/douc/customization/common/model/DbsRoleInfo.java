package com.cloudwise.douc.customization.common.model;

import com.cloudwise.douc.customization.biz.anno.MappingProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class DbsRoleInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @MappingProperty("accountId")
    private Long accountId = 110L;
    
    @MappingProperty("code")
    private String code;
    
    @MappingProperty("name")
    private String name;
    
    private Integer status;
    
    @MappingProperty("description")
    private String description;
    
    @MappingProperty("addGroupCodes")
    private List<String> addGroupCodes;
    
    
    private List<String> removeGroupCodes;
}
