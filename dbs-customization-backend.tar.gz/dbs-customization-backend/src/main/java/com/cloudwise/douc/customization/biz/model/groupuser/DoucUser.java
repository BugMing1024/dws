package com.cloudwise.douc.customization.biz.model.groupuser;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Created on 2022-10-18.
 *
 * @author skiya
 */
@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
@NoArgsConstructor
public class DoucUser implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("userId")
    private Integer userId;
    
    @JsonProperty("accountId")
    private Integer accountId;
    
    @JsonProperty("name")
    private String name;
    
    @JsonProperty("mobile")
    private String mobile;
    
    @JsonProperty("email")
    private String email;
    
    @JsonProperty("status")
    private Integer status;
    
    @JsonProperty("userAlias")
    private String userAlias;
    
    private Long departmentId;
    
    private String department;
    
    private String departmentLevel;
    
    private String userOrigin;
    
    private String attribute;
    
    private String dingtalkAccount;
    
    private String weixinworkAccount;
    
    private String feishuAccount;
    
    private String wxpushAccount;
    
    private String position;
    
    private String phone;
    
    private String workNum;
    
    /**
     * 拓展字段返回
     */
    private List<Map<String, Object>> extend;
    
    private String areaCode;
    
    private String code;
}
