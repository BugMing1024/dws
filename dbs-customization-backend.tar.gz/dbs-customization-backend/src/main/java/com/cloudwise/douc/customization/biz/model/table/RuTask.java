package com.cloudwise.douc.customization.biz.model.table;

import lombok.Data;

/**
 * @author ming.ma
 * @since 2024-12-26  18:15
 **/
@Data
public class RuTask {
    
    private String id;
    
    private String procInstId;
    
    private String taskDefKey;
    
    private String assignee;
    
    private String name;
}
