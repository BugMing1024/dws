package com.cloudwise.douc.customization.biz.model.appcode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author Magina
 * @date 2024/12/26 3:08 下午
 * @description
 **/

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServerDetatils {
    
    @JsonProperty("HOSTNAME")
    private String hostname;
    
    @JsonProperty("FRAME_NAME")
    private String frameName;
    
    @JsonProperty("PARTITION_TYPE")
    private String partitionType;
    
    @JsonProperty("IPADDRESS")
    private String ipaddress;
    
    @JsonProperty("NETWORK_ZONE")
    private String networkZone;
    
    @JsonProperty("INFRA_TYPE")
    private String infraType;
    
    @JsonProperty("PLATFORM")
    private String platform;
    
    @JsonProperty("ENVIRONMENT")
    private String environment;
    
    @JsonProperty("SYSTEM_TYPE")
    private String systemType;
    
    @JsonProperty("APPLICATION_CODE")
    private String applicationCode;
    
    @JsonProperty("APPLICATION_CATEGORY")
    private String applicationCategory;
    
    @JsonProperty("LOB")
    private String lob;
    
    @JsonProperty("COUNTRY")
    private String country;
    
    @JsonProperty("STATUS")
    private String status;
    
    private Date saveDate;
    
//    private Integer id;
    
    
}
