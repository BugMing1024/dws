package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;

/**
 * 钩子接口，实现并且在MapperFactory传入实现类，可以实现在映射前后，扩展一些自定义的操作
 *
 * @author skiya
 */
public interface MappingHook<S, T> {
    
    /**
     * 映射前
     *
     * @param source 源
     */
    void beforeMapping(S source);
    
    /**
     * 映射后
     *
     * @param source 源
     * @param target 目标
     */
    void afterMapping(S source, T target);
    
}
