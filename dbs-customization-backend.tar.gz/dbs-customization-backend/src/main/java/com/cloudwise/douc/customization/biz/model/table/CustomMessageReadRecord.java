package com.cloudwise.douc.customization.biz.model.table;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 消息记录表
 *
 * @author ming.ma
 * @since 2024-12-10  09:53
 **/
@Data
@TableName("dosm_custom_message_read_record")
public class CustomMessageReadRecord implements Serializable {

    private static final long serialVersionUID = -8066883995603031427L;

    /**
     * 消息记录id
     */
    @TableId
    private String id;

    /**
     * 消息标题
     */
    private String title;

    /**
     * 消息内容
     */
    private String content;

    private String messageId;

    private int status;

    /**
     * 创建时间
     */
    private Date createdTime;

    private String other;


    public static CustomMessageReadRecord buildInsertInfo(String title, String content, String emailId) {
        CustomMessageReadRecord customMessageRecord = new CustomMessageReadRecord();
        customMessageRecord.setId(IdUtil.fastSimpleUUID());
        Date date = new Date();
        customMessageRecord.setTitle(title);
        customMessageRecord.setContent(content);
        customMessageRecord.setCreatedTime(date);
        customMessageRecord.setMessageId(emailId);
        customMessageRecord.setStatus(1);
        return customMessageRecord;
    }


}
