package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Nodes {
    
    private String nodeId;
    
    private String nodeName;
    
    private List<TaskInfo> taskInfoList;
}
