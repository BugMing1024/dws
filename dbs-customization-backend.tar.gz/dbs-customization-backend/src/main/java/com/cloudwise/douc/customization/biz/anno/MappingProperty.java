package com.cloudwise.douc.customization.biz.anno;

import cn.hutool.core.convert.Converter;
import com.cloudwise.douc.customization.common.converter.AutoConverter;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created on 2022-2-28.
 *
 * @author skiya
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface MappingProperty {
    
    String value() default "";
    
    Class<? extends Converter<?>> converter() default AutoConverter.class;
    
}
