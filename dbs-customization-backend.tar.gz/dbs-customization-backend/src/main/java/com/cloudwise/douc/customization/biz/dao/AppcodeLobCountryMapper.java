package com.cloudwise.douc.customization.biz.dao;

import com.cloudwise.douc.customization.biz.model.appcode.*;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Collection;
import java.util.List;

/**
 * @author Magina
 * @date 2024/12/6 5:02 PM
 * @description
 **/
@Mapper
public interface AppcodeLobCountryMapper {
    
    @Insert({"<script>", "INSERT INTO    ic_application_code_mapping_t " + "(app_code, ichamp_lob, ichamp_country," + "overdue_ecr_or_rca_status) ",
            "VALUES ", "<foreach collection=\"appcodeLobCountryList\" item=\"item\" index=\"index\" separator=\",\"> ",
            " (#{item.appCode}, #{item.ichampLob}, #{item.ichampCountry}," + " #{item.overDueecrOrRcaStatus})", "</foreach> ", "</script>"})
    Integer insertAppcodeLobCountryList(@Param("appcodeLobCountryList") List<AppcodeLobCountry> appcodeLobCountryList);
    
    
    @Delete("delete from ic_application_code_mapping_t where 1=1")
    Integer delAppcodeLobCountrys();
    
    @Insert({"<script>",
            "INSERT INTO    ic_application_code_pending_project_list_t " + "(cutover_cr, cutover_description, cutover_status, " + "app_code) ",
            "VALUES ", "<foreach collection=\"appcodesPendingProjectListList\" item=\"item\" index=\"index\" separator=\",\"> ",
            " (#{item.cutoverCr}, #{item.cutoverDescription}, #{item.cutoverStatus}, " + " #{item.appCode})", "</foreach> ", "</script>"})
    Integer insertAppcodesPendingProjectList(
            @Param("appcodesPendingProjectListList") List<AppcodesPendingProjectList> appcodesPendingProjectListList);
    
    @Delete("delete from ic_application_code_pending_project_list_t where 1=1")
    Integer delAppcodesPendingProjects();
    
    
    @Insert({"<script>", "INSERT INTO    ic_appcode " + "(app_id, app_name, app_owner,app_cat_level,location,supplier,life_cycle_state,sme1,sme2, "
            + "hosting_loc,info_type,support_unit,techmd_email,sme1_email,sme2_email,app_owner_email,plat_form, "
            + "plat_form_supplier,mas,cll,cac,app_handover,data_class,secondary_app_owner,secondary_app_owner_email, " + "resiliency,save_date) ",
            "VALUES ", "<foreach collection=\"appCodeInfos\" item=\"item\" index=\"index\" separator=\",\"> ",
            " (#{item.appId}, #{item.appName}, #{item.appOwner}, #{item.appCatLevel}, #{item.location}, #{item.supplier}, #{item.lifeCycleState}, #{item.sme1}, #{item.sme2} , "
                    + " #{item.hostingLoc}, #{item.infoType}, #{item.supportUnit}, #{item.techmdEmail}, #{item.sme1Email}, #{item.sme2Email}, #{item.appOwnerEmail}, #{item.platForm},"
                    + " #{item.platFormSupplier}, #{item.mas}, #{item.cii}, #{item.cac}, #{item.appHandover}, #{item.dataClass}, #{item.secondaryAppOwner}, #{item.secondaryAppOwnerEmail},"
                    + " #{item.resiliency}, #{item.saveDate})", "</foreach> ", "</script>"})
    Integer insertAppCodes(@Param("appCodeInfos") List<AppCodeInfo> appCodeInfos);

    @Select("select distinct app_id as code, app_name as name from ic_appcode")
    List<SimpleAppCode> select();

    @Select("select * from ic_appcode")
    List<AppCodeInfo> selectAllAppcode();

    @Delete({"<script>", "delete from ic_appcode where app_id in (",
            "<foreach collection=\"ids\" item=\"item\" index=\"index\" open=\"\" close=\"\" separator=\",\"> " + "            #{item} "
                    + "    </foreach> " + ") ", "</script>"})
    Integer delAppCodeInfoByAppId(@Param("ids") List<String> ids);


    @Delete("delete from ic_appcode where 1=1")
    Integer delAppCodes();
    
    
    @Insert({"<script>",
            "INSERT INTO    ic_server_detatils_t " + "(hostname, frame_name, partition_type,ipaddress,network_zone,infra_type,platform,environment, "
                    + "system_type,application_code,application_category,lob,country,status,save_date) ", "VALUES ",
            "<foreach collection=\"serverDetatils\" item=\"item\" index=\"index\" separator=\",\"> ",
            " (#{item.hostname}, #{item.frameName}, #{item.partitionType}, #{item.ipaddress}, #{item.networkZone}, #{item.infraType}, #{item.platform}, #{item.environment}, "
                    + " #{item.systemType}, #{item.applicationCode}, #{item.applicationCategory}, #{item.lob}, #{item.country}, #{item.status}, #{item.saveDate})",
            "</foreach> ", "</script>"})
    Integer insertServerDetatilsList(@Param("serverDetatils") List<ServerDetatils> serverDetatils);
    
    @Insert({"<script>", "INSERT INTO    ic_server_detatils_t_test "
            + "(hostname, frame_name, partition_type,ipaddress,network_zone,infra_type,platform,environment, "
            + "system_type,application_code,application_category,lob,country,status,save_date) ", "VALUES ",
            "<foreach collection=\"serverDetatils\" item=\"item\" index=\"index\" separator=\",\"> ",
            " (#{item.hostname}, #{item.frameName}, #{item.partitionType}, #{item.ipaddress}, #{item.networkZone}, #{item.infraType}, #{item.platform}, #{item.environment}, "
                    + " #{item.systemType}, #{item.applicationCode}, #{item.applicationCategory}, #{item.lob}, #{item.country}, #{item.status}, #{item.saveDate})",
            "</foreach> ", "</script>"})
    Integer insertServerDetatilsLisTest(@Param("serverDetatils") List<ServerDetatils> serverDetatils);
    
    
    @Delete("delete from ic_server_detatils_t where 1=1")
    Integer delServerDetatils();
    
    @Select("select * from ic_server_detatils_t_test")
    List<ServerDetatils> selAllServerDetatils();

    @Select({"select sme1_email,sme2_email from ic_appcode where app_id in ",
            "<foreach collection=\"appIds\" item=\"appId\" index=\"index\" open=\"(\" close=\")\" separator=\",\"> ",
            "#{item}",
            "</foreach>"
    })
    List<AppManager4Impacted> getAppManager4Impacted(@Param("appIds") Collection<String> appIds);
    
    
}
