package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.douc.customization.biz.constant.EmailTemplateConstants;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.util.DateWork7DayCalcUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;

/**
 * @Author hekongtao
 * @Date 2025/2/6
 */
@Slf4j
public class CrOpenBadrAnalysis extends AbstractBaseAnalysis {

    public final static CrOpenBadrAnalysis INSTANCE = new CrOpenBadrAnalysis();


    private static final String TITLE_TEMPLATE = "Request for ${scienceType}";


    @Override
    public String getTitleTemplate() {
        return TITLE_TEMPLATE;
    }

    @Override
    public void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap) {
        bindingMap.put(EmailTemplateConstants.SCIENCE_TYPE, context.getNotify().getNotifyScene().getScienceType());

        // set date7workDay
        LocalDate localDate = DateWork7DayCalcUtil.calculateNonWorkingDays(SpringUtil.getBean(JdbcTemplate.class), LocalDate.now(), 7);
        Date resultDateAsDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        String date7workDay = DateFormatUtils.format(resultDateAsDate, "YYYY/MM/DD");
        bindingMap.put(EmailTemplateConstants.DATE_7_WORKDAY, date7workDay);
    }

}
