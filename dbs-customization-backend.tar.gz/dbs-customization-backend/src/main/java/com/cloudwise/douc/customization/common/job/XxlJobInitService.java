package com.cloudwise.douc.customization.common.job;

import com.cloudwise.douc.customization.common.config.xxl.config.XxlJobConfig;
import com.cloudwise.douc.customization.common.config.xxl.model.XxlJobGroup;
import com.cloudwise.douc.customization.common.config.xxl.service.IXxlJobService;
import com.cloudwise.douc.customization.common.model.XxlDataSetting;
import com.cloudwise.douc.customization.common.util.AsyncTaskPool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author dylan.qin
 * @Since: 2021-09-01 16:18
 */
@Component
@Slf4j
@Deprecated
public class XxlJobInitService implements ApplicationRunner {
    
    public static List<XxlDataSetting> jobs = new ArrayList<>();
    
    
    @Resource
    private IXxlJobService xxlJobService;
    
    @Resource
    private XxlJobConfig xxlJobConfig;
    
    @Override
    public void run(ApplicationArguments args) throws Exception {
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            log.info("XxlJobInitService start！");
            try {
                init();
            } catch (Exception exception) {
                log.info("XxlJobInitService end error！", exception);
            }
            log.info("XxlJobInitService end！");
        });
    }
    
    
    public void init() throws IllegalAccessException {
        String appName = xxlJobConfig.getAppName();
        try {
            XxlJobGroup xxlJobGroup = xxlJobService.getXxlJobGroupByName(appName);
            // 请勿在加入此逻辑！！！
            // 参考代码：ApproveGroupSyncJob
            // 现在会自动化的注册的了，只要要sync和其他一并使用
            //            xxlJobService.registerJob(Constants.EMAIL_LISTENER_JOB, Constants.EMAIL_LISTENER_JOB_CRON, Constants.EMAIL_LISTENER_JOB_CLASS,
            //                    xxlJobGroup);
            //            xxlJobService.registerJob(Constants.RETRY_FAIL_EMAIL_MESSAGE_JOB, Constants.RETRY_FAIL_EMAIL_MESSAGE_JOB_CRON,
            //                    Constants.RETRY_FAIL_EMAIL_MESSAGE_JOB_CLASS, xxlJobGroup);
            //            xxlJobService.registerJob(Constants.SEND_DELAY_MESSAGE_JOB, Constants.SEND_DELAY_MESSAGE_JOB_CRON, Constants.SEND_DELAY_MESSAGE_JOB_CLASS,
            //                    xxlJobGroup);
            //            xxlJobService.registerJob(Constants.SYNC_HEIGHTEN_DATA_JOB, Constants.SYNC_HEIGHTEN_DATA_JOB_CRON, Constants.SYNC_HEIGHTEN_DATA_JOB_CLASS,
            //                    xxlJobGroup);
            //            xxlJobService.registerJob(Constants.SYNC_APPCODE_DATA_JOB, Constants.SYNC_APPCODE_DATA_CRON, Constants.SYNC_APPCODE_DATA_JOB_CLASS,
            //                    xxlJobGroup);
            //            xxlJobService.registerJob(Constants.SYNC_APPCODE_LOBCOUNTRY_DATA_JOB, Constants.SYNC_APPCODE_LOBCOUNTRY_DATA_CRON,
            //                    Constants.SYNC_APPCODE_LOBCOUNTRY_DATA_JOB_CLASS, xxlJobGroup);
            //            xxlJobService.registerJob(Constants.SYNC_RCA_APPLICATION_PENDING_JOB, Constants.SYNC_RCA_APPLICATION_PENDING_JOB_CRON,
            //                    Constants.SYNC_RCA_APPLICATION_PENDING_JOBJOB_CLASS, xxlJobGroup);
            // 当前处理：不进行注册，后续可能的处理：全部删除部分不使用调度的不进行注册，关闭开关的不进行注册（这样就是必须首次没有），xxljob中数据进行一次手动维护删除
            jobs.forEach(job -> {
                xxlJobService.registerJob(job.getName(), job.isEnabled(), job.getCron(), job.getName(), xxlJobGroup, job.getRoute());
            });
            
            //            xxlJobService.registerJob(JobConstants.ACCOUNT_MODULE_STATUS_TIMEOUT_JOB_NAME, JobConstants.ACCOUNT_MODULE_STATUS_TIMEOUT_JOB_CRON,
            //                    AccountModuleStatusTimeoutJob.class.getSimpleName(), xxlJobGroup);
        } catch (Exception e) {
            log.error(" register job error!", e);
        }
        
    }
    
}