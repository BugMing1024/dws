package com.cloudwise.douc.customization.biz.model.email.dosm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class WorkOrderDetail {
    
    private String id;
    
    private String accountId;
    
    private String mdlDefCode;
    
    private String mdlDefKey;
    
    private String processDefId;
    
    private String processInstanceId;
    
    private String formId;
    
    private String serviceIds;
    
    private String title;
    
    private String bizKey;
    
    private String bizDesc;
    
    private int urgentLevel;
    
    private int isTest;
    
    /**
     * 工单来源  WEB_FORM：1网页表单, EMAIL：2邮件, MONITOR_SYSTEM：3监控系统, INTELLIGENT_ROBOT：4智能机器人,WE_CHAT：5邮微信小程序,DING_DING：6钉钉小程序, OA_AUTO：7呼叫系统, H5：8
     * H5,ROUTINE_WORK：9例行工作 这里存的是：WEB_FORM
     */
    private String sourceId;
    
    private int dataStatus;
    
    private String urgedTime;
    
    private String formData;
    
    private String formDataInfo;
    
    private String advDynamic;
    
    private String planStartTime;
    
    private String planEndTime;
    
    private String createdBy;
    
    private String createdTime;
    
    private String updatedBy;
    
    private String updatedTime;
    
    private String depId;
    
    private String depLevel;
    
    private String handlerGroupId;
    
    private List<Nodes> nodeIdsMap;
    
    private String nodeName;
    
    private String currentNodeId;
    
    private String preNum;
    
    private String orderType;
    
    private boolean readOnlyflag;
    
    private boolean isApprove;
    
    private int slaStatus;
    
    private ApproveConfVo approveConf;
    
}
