package com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.MessageContext;
import com.cloudwise.douc.customization.biz.service.msg.utils.EmailAnalysisUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * @Author hekongtao
 * @Date 2025/2/5
 */
@Slf4j
public class CrApprovedAnalysis extends AbstractBaseAnalysis {

    public final static CrApprovedAnalysis INSTANCE = new CrApprovedAnalysis();


    private static final String TITLE_TEMPLATE = "Approved for CR Number: ${bizKey}";


    @Override
    public String getTitleTemplate() {
        return TITLE_TEMPLATE;
    }

    @Override
    public void buildExtBindingMap(MessageContext context, Map<String, Object> bindingMap) {
    }


    /**
     * Primary and Secondary App Manager of Application Impacted
     */
    @Override
    protected List<UserInfo> getSendCopys(MessageContext context) {
        return getAppManager4AppImpacted(context, (appManager4Impacted, userNameSet) -> {
            // Primary App Manager of Application Impacted
            userNameSet.add(EmailAnalysisUtil.getUserNameByEmail(appManager4Impacted.getSme1Email()));
            // Secondary App Manager of Application Impacted
            userNameSet.add(EmailAnalysisUtil.getUserNameByEmail(appManager4Impacted.getSme2Email()));
        });
    }
}
