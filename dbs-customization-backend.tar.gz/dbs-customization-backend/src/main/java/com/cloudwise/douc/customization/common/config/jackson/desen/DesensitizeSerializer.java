package com.cloudwise.douc.customization.common.config.jackson.desen;

import com.cloudwise.douc.customization.common.config.jackson.desen.impl.NoneDesensitization;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.ContextualSerializer;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
public class DesensitizeSerializer extends StdSerializer<String> implements ContextualSerializer {
    
    private transient Desensitization desensitization;
    
    public DesensitizeSerializer() {
        super(String.class);
    }
    
    @Override
    public void serialize(String s, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        if (desensitization != null) {
            jsonGenerator.writeString(desensitization.desensitize(s));
        }
    }
    
    @Override
    public JsonSerializer<?> createContextual(SerializerProvider serializerProvider, BeanProperty beanProperty) throws JsonMappingException {
        Desensitize annotation = beanProperty.getAnnotation(Desensitize.class);
        DesensitizeSerializer serializer = new DesensitizeSerializer();
        if (annotation != null) {
            Class<? extends Desensitization> usingDesensitization = annotation.usingDesensitization();
            DesensitizeStrategy strategy = annotation.value();
            
            if (!usingDesensitization.equals(NoneDesensitization.class)) {
                serializer.setDesensitization(DesensitizationFactory.getDesensitization(usingDesensitization));
            } else {
                serializer.setDesensitization(DesensitizationFactory.getDesensitization(strategy.desensitizeClass));
            }
        }
        
        return serializer;
    }
    
    public void setDesensitization(Desensitization desensitization) {
        this.desensitization = desensitization;
    }
}
