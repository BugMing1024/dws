package com.cloudwise.douc.customization.biz.util;

import cn.hutool.core.util.RandomUtil;

/**
 * @author ming.ma
 * @since 2024-12-11  20:04
 **/
public class IpUtil {
    
    public static String getHost(String ips) {
        String[] split = ips.split(",");
        int idx = RandomUtil.randomInt(0, split.length);
        return split[idx];
    }
}
