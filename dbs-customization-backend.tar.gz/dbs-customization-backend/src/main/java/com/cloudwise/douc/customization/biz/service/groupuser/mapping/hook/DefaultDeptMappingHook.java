package com.cloudwise.douc.customization.biz.service.groupuser.mapping.hook;


import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.dto.DubboUpdateDepartment;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Created on 2022-4-22.
 *
 * @author skiya
 */
@Component
@RequiredArgsConstructor
public class DefaultDeptMappingHook<T> implements MappingHook<T, DubboUpdateDepartment> {
    
    private final DoucProperties doucProperties;
    
    private final ExtendFieldMappings extendFieldMappings;
    
    @Override
    public void beforeMapping(T source) {
    
    }
    
    @Override
    public void afterMapping(T source, DubboUpdateDepartment target) {
        target.setAccountId(doucProperties.getAccountId());
        if (target.getExtendFields() == null) {
            target.setExtendFields(extendFieldMappings.mapping(source));
        }
        if (doucProperties.getOrgActiveDefault()) {
            target.setStatus(1);
        }
    }
}
