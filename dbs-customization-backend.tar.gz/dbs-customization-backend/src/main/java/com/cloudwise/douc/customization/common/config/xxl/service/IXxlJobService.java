package com.cloudwise.douc.customization.common.config.xxl.service;


import com.cloudwise.douc.customization.common.config.xxl.enums.ExecutorRouteStrategyEnum;
import com.cloudwise.douc.customization.common.config.xxl.model.XxlJobGroup;
import com.cloudwise.douc.customization.common.config.xxl.model.XxlJobInfo;

import java.util.List;

/**
 * @Author dylan.qin
 * @Since: 2021-07-06 15:28
 */
public interface IXxlJobService {
    
    /**
     * 注册执行器
     *
     * @param xxlJobGroup
     */
    void registerJobHandler(XxlJobGroup xxlJobGroup);
    
    void updateJonHandler(XxlJobGroup xxlJobGroup);
    
    /**
     * 根据ID删除执行器
     *
     * @param id
     */
    void delJobHandler(int id);
    
    /**
     * 注册任务
     *
     * @param info
     * @return
     */
    int registerJob(XxlJobInfo info);
    
    
    void registerJob(String name, String cron, String clazz, XxlJobGroup xxlJobGroup, ExecutorRouteStrategyEnum route);
    
    void registerJob(String name, boolean enabled, String cron, String clazz, XxlJobGroup xxlJobGroup, ExecutorRouteStrategyEnum route);
    
    void registerJob(String name, String cron, String clazz, XxlJobGroup xxlJobGroup);
    
    /**
     * 根据ID删除任务
     *
     * @param id
     */
    void delJob(int id);
    
    /**
     * 获取所有任务
     *
     * @return
     */
    List<XxlJobInfo> getJobList(int jobGroupId);
    
    void startJob(int id);
    
    void stopJob(int id);
    
    void triggerJob(int id, int jobGroupId);
    
    void execute(int id, int jobGroupId);
    
    XxlJobGroup getXxlJobGroupByName(String appName);
    
}