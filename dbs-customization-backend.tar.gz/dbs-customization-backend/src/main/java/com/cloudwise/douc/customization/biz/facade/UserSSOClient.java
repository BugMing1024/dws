package com.cloudwise.douc.customization.biz.facade;

import com.cloudwise.douc.customization.biz.facade.user.RoleInfo;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.facade.user.UserPage;
import com.cloudwise.douc.customization.biz.facade.user.UserRoleInfo;
import com.cloudwise.douc.customization.common.config.DosmConfig;
import com.cloudwise.douc.dto.*;
import com.cloudwise.douc.dto.v3.common.PageResp;
import com.cloudwise.douc.dto.v3.user.UserConditionReq;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author ming.ma
 * @since 2024-12-10  19:14
 **/
@Component
public class UserSSOClient {

    @Autowired
    @Lazy
    private UserService userService;

    @Autowired
    @Lazy
    private RoleService roleService;

    @Autowired
    @Lazy
    private DosmConfig dosmConfig;


    public UserInfo getUserById(String id) {
        List<UserInfo> userInfos = getUserListByIds(Lists.newArrayList(id), dosmConfig.getUserId(), dosmConfig.getAccountId());
        return CollectionUtils.isEmpty(userInfos)? null: userInfos.get(0);
    }

    public List<UserInfo> getUserListByIds(List<String> ids, String userId, String accountId) {
        return getUserListByIds(ids.stream().map(Long::valueOf).collect(Collectors.toList()), Long.valueOf(userId), Long.valueOf(accountId));
    }

    /**
     * 根据用户ids获取用户基础信息列表 ids必填
     */
    public List<UserInfo> getUserListByIds(List<Long> ids, Long userId, Long accountId) {
        DubboIdsReq req = new DubboIdsReq();
        req.setUserId(userId);
        req.setAccountId(accountId);
        req.setIds(ids);
        return Optional.ofNullable(userService.getUserListByIds(req)).map(DubboCommonResp::getData).orElse(Collections.emptyList());
    }

    public List<UserRoleInfo> getRoleInfosByUserId(String userId, String accountId) {
        DubboUserIdAccountIdRequest req = new DubboUserIdAccountIdRequest();
        req.setUserId(Long.valueOf(userId));
        req.setAccountId(Long.valueOf(accountId));
        req.setLanguage("en_US");
        return userService.getRoloInfosByUserId(req).getData();
    }


    public List<RoleInfo> getRoleListByIds(List<Long> ids, String userId, String accountId) {
        DubboIdsReq dubboIdsReq = new DubboIdsReq();
        dubboIdsReq.setAccountId(Long.valueOf(accountId));
        dubboIdsReq.setIds(ids);
        dubboIdsReq.setUserId(Long.valueOf(userId));
        //dubboIdsReq.setLanguage("zn_CN");
        dubboIdsReq.setLanguage("en_US");
        return roleService.getRoleListByIds(dubboIdsReq).getData();
    }

    /**
     * 根据用户邮箱获取用户详细信息
     */
    public List<UserInfo> getUserListByEmail(String userId, String accountId, String email) {
        DubboRpcQueryParams req = new DubboRpcQueryParams();
        DubboRpcQueryParam queryParam = new DubboRpcQueryParam();
        queryParam.setEmail(email);
        queryParam.setCurrentPageNo(1);
        queryParam.setPageSize(20);
        queryParam.setAccountId(Long.valueOf(accountId));
        req.setUserId(Long.valueOf(userId));
        req.setAccountId(Long.valueOf(accountId));
        req.setAllUser(true);
        req.setQueryParam(queryParam);
        return Optional.ofNullable(userService.getUserListByParam(req)).map(DubboCommonResp::getData).map(UserPage::getList)
                .orElse(Collections.emptyList());
    }

    /**
     * 根据用户别名集合获取用户基本信息列表
     * 入参说明：
     * useralias 必填
     */
    public List<UserInfo> getUsersByAliasList(List<String> useralias, String userId, String accountI) {
        DubboUserAliasReq req = new DubboUserAliasReq();
        req.setUserId(Long.valueOf(userId));
        req.setAccountId(Long.valueOf(accountI));
        req.setUseralias(useralias);
        return Optional.ofNullable(userService.getUsersByAliasList(req)).map(DubboCommonResp::getData).orElse(Collections.emptyList());
    }

    /**
     * get page list of user
     * @param req
     * @return
     */
    public PageResp<com.cloudwise.douc.dto.v3.common.UserInfo> getUserByCondition(UserConditionReq req) {
        req.setUserId(Long.valueOf(dosmConfig.getUserId()));
        req.setAccountId(Long.valueOf(dosmConfig.getAccountId()));

        return userService.getUserByCondition(req);
    }

    /**
     * get all user
     * @param req
     * @return
     */
    public List<com.cloudwise.douc.dto.v3.common.UserInfo> getAllUserByCondition(UserConditionReq req) {
        req.setUserId(Long.valueOf(dosmConfig.getUserId()));
        req.setAccountId(Long.valueOf(dosmConfig.getAccountId()));

        List<com.cloudwise.douc.dto.v3.common.UserInfo> userList = Lists.newArrayList();
        long page = req.getCurrent() <= 0? 1: req.getCurrent();
        long tmp_total = page * req.getSize();

        PageResp<com.cloudwise.douc.dto.v3.common.UserInfo> userPageList = userService.getUserByCondition(req);
        if(CollectionUtils.isNotEmpty(userPageList.getRecords())) {
            userList.addAll(userPageList.getRecords());
        }

        for(; tmp_total < userPageList.getTotal(); tmp_total += req.getSize()) {
            req.setCurrent(page++);
            userPageList = userService.getUserByCondition(req);
            if(CollectionUtils.isNotEmpty(userPageList.getRecords())) {
                userList.addAll(userPageList.getRecords());
            }
        }

        return userList;
    }
}
