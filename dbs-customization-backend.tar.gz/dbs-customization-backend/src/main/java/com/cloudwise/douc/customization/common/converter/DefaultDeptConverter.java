package com.cloudwise.douc.customization.common.converter;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.convert.Converter;
import com.cloudwise.douc.dto.DubboAddUserDepartmentInfo;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created on 2022-4-11.
 *
 * @author skiya
 */
@Component
public class DefaultDeptConverter implements Converter<List<DubboAddUserDepartmentInfo>> {
    
    @Override
    public List<DubboAddUserDepartmentInfo> convert(Object value, List<DubboAddUserDepartmentInfo> defaultValue) throws IllegalArgumentException {
        DubboAddUserDepartmentInfo dubboAddUserDepartmentInfo = new DubboAddUserDepartmentInfo();
        dubboAddUserDepartmentInfo.setIsMainDepartment(true);
        dubboAddUserDepartmentInfo.setDepartmentCode(Convert.toStr(value));
        return CollUtil.newArrayList(dubboAddUserDepartmentInfo);
    }
}
