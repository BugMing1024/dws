package com.cloudwise.douc.customization.biz.enums;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.constant.SmsTemplateConstants;
import com.cloudwise.douc.customization.biz.service.msg.email.analysis.EmailAnalysis;
import com.cloudwise.douc.customization.biz.service.msg.email.analysis.impl.*;
import com.cloudwise.douc.customization.biz.service.msg.sms.analysis.SmsAnalysis;
import lombok.AllArgsConstructor;
import lombok.Getter;

import static com.cloudwise.douc.customization.biz.constant.EmailTemplateConstants.BodyField.*;

/**
 * 通知场景

 * @author ming.ma
 * @since 2024-12-05  15:15
 **/
@Getter
@AllArgsConstructor
public enum NotifyScenceEnum {

    CR_NEW_TESTING_SIGNOFF("CRNewTestingSignoff", FKS_CR_NEW_TESTING_SIGNOFF_COMM, CrNewTestingSignoffAnalysis.INSTANCE, null, null, null),
    CR_NEW_PRJ_BU_APP_OWNER_SIGNOFF("CRNewPrj_BUAppOwnerSignoff", FKS_CR_NEW_PRJ_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Project Cutover BU / Application Owner Signoff", null, null),
    CR_NEW_PRJ_HA_DR_FLIP_SIGNOFF("CRNewPrj_HADRFlipSignoff", FKS_CR_NEW_PRJ_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Project Cutover HA & DR Flip Signoff", null, null),
    CR_NEW_PRJ_IMPACT_2_MAINFRAME_SIGNOFF("CRNewPrj_Impact2MainframeSignoff", FKS_CR_NEW_PRJ_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Project Cutover Impact to Mainframe Signoff", null, null),
    CR_NEW_PRJ_D4D_SIGNOFF("CRNewPrj_D4DSignoff", FKS_CR_NEW_PRJ_SIGNOFF_D4D, CrNewCommSignoffAnalysis.INSTANCE, "Project Cutover Design for Data (D4D) Signoff ", null, null),
    CR_NEW_PRJ_DATA_CENTER_OPS_SIGNOFF("CRNewPrj_DataCenterOpsSignoff", FKS_CR_NEW_PRJ_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Project Cutover Data Center OPS (Batch) Signoff", null, null),
    CR_NEW_PRJ_MD_DELEGATE_SIGNOFF("CRNewPrj_MDDelegateSignoff", FKS_CR_NEW_PRJ_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Project Cutover MD Delegate Signoff ", null, null),
    CR_NEW_PRJ_SERVICE_MONITORING_SNOC("CRNewPrj_ServiceMonitoringSNOC", FKS_CR_NEW_PRJ_SIGNOFF_SERVICE_MONITORING_SNOC, CrNewPrjServiceMonitoringSNOCAnalysis.INSTANCE, "Cutover Service Monitoring at SNOC", null, null),
    CR_NEW_OTHER_IDR_SIGNOFF("CRNewOtherIDRSignoff", FKS_CR_NEW_OTHER_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "IDR Signoff", null, null),
    CR_NEW_OTHER_ISS_SIGNOFF("CRNewOtherISSSignoff", FKS_CR_NEW_OTHER_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "ISS Signoff", null, null),
    CR_NEW_OTHER_DR_SIGNOFF("CRNewOtherStorageSignoff", FKS_CR_NEW_OTHER_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "DR Signoff", null, null),
    CR_NEW_OTHER_STORAGE_SIGNOFF("CRNewOtherDRSignoff", FKS_CR_NEW_OTHER_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Storage Signoff", null, null),
    CR_NEW_OTHER_CODE_CHECKER_SIGNOFF("CRNewOtherCodeCheckerSignoff", FKS_CR_NEW_OTHER_SIGNOFF_COMM, CrNewCommSignoffAnalysis.INSTANCE, "Code Checker Signoff", null, null),


    CR_OPEN_BADR_L1_APP_GOV_APPROVER_1_6("CROpenBADR_L1AppGovApprover1_6", null, CrOpenBadrAnalysis.INSTANCE, "App Governance Approval", null, null),
    CR_OPEN_BADR_L1_CHANGE_MANAGER("CROpenBADR_L1ChangeManager", null, CrOpenBadrAnalysis.INSTANCE, "L1 Change Manager Approvals", null, null),
    CR_OPEN_BADR_L1_RISK_MANAGER("CROpenBADR_L1RiskManager", null, CrOpenBadrAnalysis.INSTANCE, "L1 Risk Manager Approvals", null, null),
    CR_OPEN_BADR_TECH_MD("CROpenBADR_techMD", null, CrOpenBadrAnalysis.INSTANCE, "Tech MD", null, null),
    CR_OPEN_BADR_L1_5_CHANGE_MNG_TEAM_4_HEIGHTENED_CR("CROpenBADR_L1.5ChangeMngTeam4HeightenedCR", null, CrOpenBadrAnalysis.INSTANCE, "L1.5 Change Management Team for heightened CR", null, null),
    CR_OPEN_BADR_ARC_APPROVER("CROpenBADR_ARCApprover", null, CrOpenBadrAnalysis.INSTANCE, "ARC Approval", null, null),
    CR_OPEN_IEN_ISS_OVERDUE_PATCH_APPROVAL("CROpenIEN_ISSOverduePatchApproval", FKS_CR_OPEN_IEN_COMM, CrOpenIenAnalysis.INSTANCE, "ISS Overdue Patch Approval", null, null),
    CR_OPEN_AVE_SCHEDULED_DOWNTIME_APPROVAL("CROpenAVE_ScheduledDowntimeApproval", FKS_CR_OPEN_AVE_COMM, CrOpenAveAnalysis.INSTANCE, "Scheduled Downtime Approval", null, null),
    CR_OPEN_AVE_SCHEDULED_MAINTENANCE_APPROVAL("CROpenAVE_ScheduledMaintenanceApproval", FKS_CR_OPEN_AVE_COMM, CrOpenAveAnalysis.INSTANCE, "Scheduled Maintenance Approval", null, null),
    CR_OPEN_AVE_APP_OWNER_APPROVAL("CROpenAVE_AppOwnerApproval", FKS_CR_OPEN_AVE_COMM, CrOpenAveAnalysis.INSTANCE, "Data Patch Approval", null, null),
    CR_OPEN_AVE_D4D_APPROVAL("CROpenAVE_D4DApproval", FKS_CR_OPEN_AVE_COMM, CrOpenAveD4dAnalysis.INSTANCE, "Design for Data (D4D) Approval", null, null),


    CR_APPROVED("CRApproved", FKS_CR_APPROVED, CrApprovedAnalysis.INSTANCE, null, SmsTemplateConstants.BodyField.FKS_CR_APPROVED, com.cloudwise.douc.customization.biz.service.msg.sms.analysis.impl.CrApprovedAnalysis.INSTANCE),
    CR_REJECTED("CRRejected", FKS_CR_REJECTED, CrRejectedAnalysis.INSTANCE, null, SmsTemplateConstants.BodyField.FKS_CR_REJECTED, com.cloudwise.douc.customization.biz.service.msg.sms.analysis.impl.CrRejectedAnalysis.INSTANCE),
    CR_REJECTED_SCHEDULE_DOWNTIME("CRRejected_ScheduleDowntime", FKS_STANDALONE_CR_REJECTED_COMM, CrStandaloneRejectedAnalysis.INSTANCE, "Scheduled Downtime Approval", null, null),
    CR_REJECTED_SCHEDULE_MAINTENANCE("CRRejected_ScheduleMaintenance", FKS_STANDALONE_CR_REJECTED_COMM, CrStandaloneRejectedAnalysis.INSTANCE, "Scheduled Maintenance Approval", null, null),
    CR_REJECTED_APP_OWNER("CRRejected_AppOwner", FKS_STANDALONE_CR_REJECTED_COMM, CrStandaloneRejectedAnalysis.INSTANCE, "Application Owner (For Data Patch) Approval", null, null),
    CR_REJECTED_D4D("CRRejected_D4D", FKS_STANDALONE_CR_REJECTED_COMM, CrStandaloneRejectedAnalysis.INSTANCE, "D4D Approval", null, null),
    CR_CLOSED_CANCEL("CRClosedCancel", FKS_CR_CLOSED_CANCEL, CrCloseCancelAnalysis.INSTANCE, "", SmsTemplateConstants.BodyField.FKS_CR_CLOSED_CANCEL, com.cloudwise.douc.customization.biz.service.msg.sms.analysis.impl.CrCloseCancelAnalysis.INSTANCE),


    EMAIL_ACKNOWLEDGEMENT_APPROVED("EmailAcknowledgement_Approved", null, EmailAcknowledgementApprovedAnalysis.INSTANCE, null, null, null),
    EMAIL_ACKNOWLEDGEMENT_REJECTED("EmailAcknowledgement_Rejected", null, EmailAcknowledgementRejectedAnalysis.INSTANCE, null, null, null),


    RCA_PENDING("RCAPending", FKS_RCA_PENDING_COMM, RcaPendingAnalysis.INSTANCE, null, null, null),
    RCA_APPROVAL("RCAApproval", FKS_RCA_APPROVAL_COMM, RcaApprovalAnalysis.INSTANCE, null, null, null),
    RCA_APPROVED("RCAApproved", FKS_RCA_APPROVED_COMM, RcaApprovedAnalysis.INSTANCE, null, null, null),
    RCA_REJECTED("RCARejected", FKS_RCA_REJECTED_COMM, RcaRejectedAnalysis.INSTANCE, null, null, null),

    ;

    /** 文件名 */
    private String fileName;

    private String[] emailBodyFieldKeys;
    private EmailAnalysis emailAnalysis;

    private String scienceType;


    private String[]    smsBodyFieldKeys;
    private SmsAnalysis smsAnalysis;

    public static NotifyScenceEnum of(String notifyScene) {
        for(NotifyScenceEnum value: NotifyScenceEnum.values()) {
            if(StrUtil.equals(value.name(), notifyScene)) {
                return value;
            }
        }
        return null;
    }

}
