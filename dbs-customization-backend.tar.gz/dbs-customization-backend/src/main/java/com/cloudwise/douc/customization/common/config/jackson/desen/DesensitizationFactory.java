package com.cloudwise.douc.customization.common.config.jackson.desen;

import java.util.HashMap;
import java.util.Map;

/**
 * Created on 2023-2-24.
 *
 * @author skiya
 */
public class DesensitizationFactory {
    
    private static final Map<Class<?>, Desensitization> map = new HashMap<>();
    
    private DesensitizationFactory() {
    }
    
    public static Desensitization getDesensitization(Class<?> clazz) {
        if (clazz.isInterface()) {
            throw new UnsupportedOperationException("usingDesensitization is interface, what is expected is an implementation class !");
        }
        return map.computeIfAbsent(clazz, k -> {
            try {
                return (Desensitization) clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                throw new UnsupportedOperationException(e.getMessage(), e);
            }
        });
    }
    
}
