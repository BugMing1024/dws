package com.cloudwise.douc.customization.biz.service.msg.email.config;

import lombok.Data;

import java.util.Map;

/**
 * @Author frank.zheng
 * @Date 2025-02-09
 */
@Data
public class EmailConfig {

    private String itsmSupportEmail = "Ipa_o365_uat1@dbsbank.asia";

    /** RCA Approved -> cc */
    private String dbsChgEmail = "dbschg@dbs.com";

    /** cr is new -> Project Cutover Signoff -> Service Monitoring at SNOC Receivers */
    private String crNewPrjServiceMonitoringSNOCReceiverGroupName = "PSG_DBSAPP_NOTIFY_SNOC";

    /** RCA approval -> cc -> PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB) */
    private String rcaApprovalCCGroupName = "P%s_DBSAPP_CHANGEFOCAL_%s";

    /** RCA approved -> cc -> PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB) */
    private String rcaApprovedCCGroupName = "P%s_DBSAPP_CHANGEFOCAL_%s";

    /** RCA panding -> cc -> PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB) */
    private String rcaPandingCCGroupName = "P%s_DBSAPP_CHANGEFOCAL_%s";

    /** RCA Rejected -> cc -> PXX_DBSAPP_CHANGEFOCAL_YYYY (XX =Country of Origin / YYYY=LOB) */
    private String rcaRejectedCCGroupName = "P%s_DBSAPP_CHANGEFOCAL_%s";

    /** email body field value format config */
    private Map<String, String> fieldValueFormatMap;

    /** reference：https://yunzhihui.feishu.cn/wiki/MyWvwaSCtiVsNKkhpk0cp1vSncg */
    private Map<String, String> bodyFieldMap;




    public String getItsmSupportEmail() {
        return itsmSupportEmail == null? "": itsmSupportEmail;
    }
}
