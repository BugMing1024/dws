package com.cloudwise.douc.customization.biz.constant;

/**
 * @Author frank.zheng
 * @Date 2025-02-05
 */
public interface SmsTemplateConstants {

    /** SMS Approval Parse Exception */
    String ASSIGNED_USER_NAME = "assignedUserName";


    interface PublicFields {

        /** work order id */
        String WORK_ORDER_ID = "workOrderId";

        /** work order biz key */
        String BIZ_KEY = "bizKey";

        /** work order created by */
        String CREATED_BY_ID   = "createdById";
        String CREATED_BY_NAME = "createdByName";

    }


    interface BodyField {

        /** Requester Name */
        String REQUESTER_NAME      = "REQUESTER_NAME";
        /** Schedule Start Date */
        String SCHEDULE_START_DATE = "SCHEDULE_START_DATE";
        /** Schedule End Date */
        String SCHEDULE_END_DATE   = "SCHEDULE_END_DATE";
        /** Unit (LOB) */
        String UNIT                = "UNIT";
        /** Country of Origin (Hosting Country) */
        String COUNTRY_OF_ORIGIN   = "COUNTRY_OF_ORIGIN";


        String[] FKS_CR_APPROVED = {REQUESTER_NAME, SCHEDULE_START_DATE, SCHEDULE_END_DATE};
        ;
        String[] FKS_CR_REJECTED      = FKS_CR_APPROVED;
        String[] FKS_CR_CLOSED_CANCEL = FKS_CR_APPROVED;

    }


}
