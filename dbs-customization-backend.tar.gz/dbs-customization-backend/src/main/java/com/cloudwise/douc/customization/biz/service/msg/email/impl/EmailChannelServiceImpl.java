package com.cloudwise.douc.customization.biz.service.msg.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.biz.model.email.ChannelRequestInfoVo;
import com.cloudwise.douc.customization.biz.service.msg.email.EmailChannelService;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.dto.DubboChannelRealConfigPageQueryRequest;
import com.cloudwise.douc.dto.DubboChannelRealConfigResponse;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboPageResp;
import com.cloudwise.douc.facade.ChannelDubboFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * @author ming.ma
 * @since 2024-12-05  10:02
 **/
@Slf4j
@Service
public class EmailChannelServiceImpl implements EmailChannelService {
    
    @DubboReference(lazy = true, check = false, timeout = 5000, retries = 0, version = "${dubbo.service.version}", group = "${dubbo.service.group}", url = "rest://${rest.svc.douc:}")
    private ChannelDubboFacade channelDubboFacade;
    
    @Override
    public DubboChannelRealConfigResponse getChannelConfigById(Long channelId, String accountId) {
        log.info("根据ID查询的信息为:{}", channelId);
        ChannelRequestInfoVo infoVo = new ChannelRequestInfoVo();
        infoVo.setIds(Collections.singletonList(channelId));
        DubboCommonResp<DubboPageResp<DubboChannelRealConfigResponse>> resp = getCommonResp(infoVo, accountId);
        log.info("根据ID查询的结果为:{}", JsonUtils.toJsonStr(resp));
        if (resp.isSuccess()) {
            return resp.getData().getList().get(0);
        }
        return null;
    }
    
    private DubboCommonResp<DubboPageResp<DubboChannelRealConfigResponse>> getCommonResp(ChannelRequestInfoVo channelInfo, String accountId) {
        log.info("请求参数:{}", JsonUtils.toJsonStr(channelInfo));
        //封装dosm请求参数
        DubboChannelRealConfigPageQueryRequest request = new DubboChannelRealConfigPageQueryRequest();
        request.setPageSize(channelInfo.getPageSize());
        request.setCurrentPageNo(channelInfo.getCurrentPage());
        request.setChannelCode(channelInfo.getChannelCode());
        request.setAccountId(Long.valueOf(accountId));
        if (CollUtil.isNotEmpty(channelInfo.getIds())) {
            request.setIds(channelInfo.getIds());
        }
        if (StrUtil.isNotEmpty(channelInfo.getChannelName())) {
            request.setName(channelInfo.getChannelName());
        }
        log.info("转换后参数:{}", JsonUtils.toJsonStr(request));
        DubboCommonResp<DubboPageResp<DubboChannelRealConfigResponse>> resp = channelDubboFacade.pageQueryChannelReadConfig(request);
        log.info("响应参数:{}", JsonUtils.toJsonStr(resp));
        return resp;
    }
}
