package com.cloudwise.douc.customization.biz.service.email;

/**
 * @author ming.ma
 * @since 2024-12-05  10:08
 **/
public interface EmailTicketingJobService {
    
    void handle(String param);

    void readEmail(String para);
}
