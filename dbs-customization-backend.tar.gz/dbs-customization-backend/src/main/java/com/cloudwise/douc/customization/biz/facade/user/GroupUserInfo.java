package com.cloudwise.douc.customization.biz.facade.user;

import lombok.Data;

import java.util.List;

/**
 * @Author: ksana.kong
 * @Date: 2021/6/30 10:31 上午
 * @Description: *
 */

@Data
public class GroupUserInfo {
    
    /**
     * 用户组id
     */
    private Long groupId;
    
    /**
     * 名称
     */
    private String groupName;
    
    /**
     * 上级id
     */
    private String parentId;
    
    /**
     * 用户组用户数量
     */
    private String userCount;
    
    /**
     * 当前用户组用户
     */
    private List<UserSmallInfo> userInfoList;
}
