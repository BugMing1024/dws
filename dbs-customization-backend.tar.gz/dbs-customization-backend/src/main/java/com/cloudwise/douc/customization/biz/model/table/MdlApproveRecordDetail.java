package com.cloudwise.douc.customization.biz.model.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import com.cloudwise.douc.customization.biz.model.email.dosm.ApproveBehaviorTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.ibatis.type.JdbcType;

import java.io.Serializable;
import java.util.Date;

/**
 * 审批记录详情
 *
 * @author jon.lee
 * @TableName mdl_approve_record_detail
 * @since 2022-05-14 15:32
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MdlApproveRecordDetail implements Serializable {
    
    private static final long serialVersionUID = 9047407611414373748L;
    
    /**
     * 主键ID
     */
    @ApiModelProperty(value = "主键ID", example = "123")
    @TableId("id")
    protected String id;
    
    /**
     * 顶级租户ID
     */
    @ApiModelProperty(value = "顶级租户ID", example = "110")
    @TableField(value = "top_account_id", jdbcType = JdbcType.VARCHAR)
    protected String topAccountId;
    
    /**
     * 租户ID
     */
    @ApiModelProperty(value = "租户ID", example = "110")
    @TableField(value = "account_id", jdbcType = JdbcType.VARCHAR)
    protected String accountId;
    
    /**
     * 创建人ID
     */
    @ApiModelProperty(value = "创建人ID", example = "2")
    @TableField(value = "created_by", jdbcType = JdbcType.VARCHAR)
    protected String createdBy;
    
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", example = "2021-10-01 01:00:00")
    @TableField("created_time")
    protected Date createdTime = new Date();
    
    /**
     * 修改人ID
     */
    @ApiModelProperty(value = "修改人ID", example = "2")
    @TableField("updated_by")
    protected String updatedBy;
    
    /**
     * 修改时间
     */
    @ApiModelProperty(value = "修改时间", example = "2021-10-01 01:00:00")
    @TableField("updated_time")
    protected Date updatedTime = new Date();
    
    /**
     * 乐观锁
     */
    @ApiModelProperty(value = "乐观锁", example = "0")
    @TableField("revision")
    protected Integer revision = 0;
    
    /**
     * 0有效1删除
     */
    @ApiModelProperty(value = "删除标识 0有效1删除", example = "0")
    @TableField("is_del")
    protected Integer isDel = 0;
    
    /**
     * 节点 id
     */
    private String nodeId;
    
    private String nodeName;
    
    /**
     * 审批记录 id
     */
    private String approveRecordId;
    
    /**
     * PASS通过，REJECT驳回，AUTO_PASS自动通过
     */
    private ApproveBehaviorTypeEnum approveType;
    
    private String reason;
    
    /**
     * 审批意见
     */
    private String approveMsg;
    
    /**
     * 工单 id
     */
    private String workOrderId;
    
    /**
     * 流程实例 id
     */
    private String processInstanceId;
    
    /**
     * 流程处理记录组id
     */
    private String processRecordGroupId;
    
    /**
     * 任务 id
     */
    private String taskId;
    
    @TableField(exist = false)
    private UserInfo approveUser;
    
    
}