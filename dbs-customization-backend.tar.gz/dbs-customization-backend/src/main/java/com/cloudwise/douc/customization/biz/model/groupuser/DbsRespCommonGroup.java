package com.cloudwise.douc.customization.biz.model.groupuser;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
public class DbsRespCommonGroup implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // country属性
    private String GroupCountry;
    
    // 成员1bankId
    private String MemberLogin;
    
    // 成员姓名
    private String MemberName;
    
    // 组长邮箱
    private String GroupOwnerEmail;
    
    // lob属性
    private String GroupLOB;
    
    // 用户组名称，作为唯一标识
    private String Group;
    
    // 用户组描述
    private String GroupDescription;
    
    // 组长姓名，高优先级，重复时废弃
    private String GroupOwner;
    
    private String GroupOwnerLogin;
    
    // 用户组关联角色
    private String GroupRole;
    
    // 用户组关联用户的邮箱
    private String MemberEmail;
}
