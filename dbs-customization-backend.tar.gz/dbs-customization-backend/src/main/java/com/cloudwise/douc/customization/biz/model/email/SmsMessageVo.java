package com.cloudwise.douc.customization.biz.model.email;

import com.cloudwise.douc.customization.biz.facade.user.UserInfo;
import lombok.Data;

import java.util.Map;

/**
 * @author ming.ma
 * @since 2025-01-07  14:40
 **/
@Data
public class SmsMessageVo extends MessageVo {

    private Map<UserInfo, String> bodyList;

    private String country;
    private String lob;

}
