package com.cloudwise.douc.customization.biz.model.heighten;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Magina
 * @date 2024/12/17 7:20 下午
 * @description
 **/

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkTimeLongPiece {
    
    private long begin;
    
    private long end;
}
