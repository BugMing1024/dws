package com.cloudwise.douc.customization.biz.facade;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.customization.common.config.DoucProperties;
import com.cloudwise.douc.customization.common.exception.DoucFailedSyncResult;
import com.cloudwise.douc.customization.common.exception.DoucSyncException;
import com.cloudwise.douc.customization.common.util.JsonUtils;
import com.cloudwise.douc.dto.DubboAddUser;
import com.cloudwise.douc.dto.DubboCommonResp;
import com.cloudwise.douc.dto.DubboDeleteDepartment;
import com.cloudwise.douc.dto.DubboDeleteUser;
import com.cloudwise.douc.dto.DubboSyncResultInfo;
import com.cloudwise.douc.dto.DubboUpdateDepartment;
import com.cloudwise.douc.dto.DubboUpdateUser;
import com.cloudwise.douc.facade.BaseInfoV2DubboFacade;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created on 2022-4-7.
 *
 * @author skiya
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DoucBaseFacade {
    
    /**
     * 同步部分失败
     */
    private final static String PARTIAL_FAIL_CODE = "100018";
    
    private final DoucProperties doucProperties;
    
    //@DubboReference(lazy = true ,check = false ,timeout = 5000,url = "rest://${rest.svc.douc:}")
    private BaseInfoV2DubboFacade baseInfoV2DubboFacade;
    
    /**
     * 新增或更新部门 根据departmentCode是否已经存在来执行新增或者更新操作 departmentCode存在 -> 更新，会全量覆盖，为 null 的会被更新为空值 departmentCode不存在 -> 新增
     *
     * @param dubboUpdateDepartments 新增或者更新部门参数实体
     * @throws DoucSyncException 有数据同步失败时会抛出 DoucSyncException，异常类中包含所需要的异常信息，具体查看该类
     */
    public void addOrUpdateDepartments(List<DubboUpdateDepartment> dubboUpdateDepartments) {
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(dubboUpdateDepartments));
        DubboCommonResp<List<DubboSyncResultInfo>> commonResp = baseInfoV2DubboFacade.addOrUpdateDepartments(dubboUpdateDepartments);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        Collection<DoucFailedSyncResult> results = new ArrayList<>();
        if (!commonResp.isSuccess()) {
            if (StrUtil.equals(PARTIAL_FAIL_CODE, commonResp.getCode())) {
                Optional.ofNullable(commonResp.getData()).ifPresent(d -> d.forEach(e -> {
                    DoucFailedSyncResult result = new DoucFailedSyncResult();
                    result.setCode(e.getFailCode());
                    result.setMessage(e.getFailMsg());
                    result.setFailIds(e.getDataCodes());
                    results.add(result);
                }));
            } else {
                List<String> deptCodes = dubboUpdateDepartments.stream().map(DubboUpdateDepartment::getDepartmentCode).collect(Collectors.toList());
                DoucFailedSyncResult result = new DoucFailedSyncResult();
                result.setCode(commonResp.getCode());
                result.setMessage(commonResp.getMsg());
                result.setFailIds(deptCodes);
                results.add(result);
            }
            throw new DoucSyncException(results);
        }
    }
    
    /**
     * 根据部门编码 departmentCode 删除部门
     *
     * @param deptCodes 部门编码集合
     * @throws DoucSyncException 有数据同步失败时会抛出 DoucSyncException，异常类中包含所需要的异常信息，具体查看该类
     */
    public void deleteDepartments(List<String> deptCodes) {
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(deptCodes));
        DubboDeleteDepartment department = new DubboDeleteDepartment();
        department.setDepartmentCodes(deptCodes);
        department.setAccountId(doucProperties.getAccountId());
        DubboCommonResp<List<DubboSyncResultInfo>> commonResp = baseInfoV2DubboFacade.deleteDepartments(department);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        Collection<DoucFailedSyncResult> results = new ArrayList<>();
        if (!commonResp.isSuccess()) {
            if (StrUtil.equals(PARTIAL_FAIL_CODE, commonResp.getCode())) {
                Optional.ofNullable(commonResp.getData()).ifPresent(d -> d.forEach(e -> {
                    DoucFailedSyncResult result = new DoucFailedSyncResult();
                    result.setCode(e.getFailCode());
                    result.setMessage(e.getFailMsg());
                    result.setFailIds(e.getDataCodes());
                    results.add(result);
                }));
            } else {
                DoucFailedSyncResult result = new DoucFailedSyncResult();
                result.setCode(commonResp.getCode());
                result.setMessage(commonResp.getMsg());
                result.setFailIds(deptCodes);
                results.add(result);
            }
            throw new DoucSyncException(results);
        }
    }
    
    /**
     * 添加或更新用户 根据userCode是否已经存在来执行新增或者更新操作 userCode存在 -> 更新，会全量覆盖，为 null 的会被更新为空值 userCode不存在 -> 新增
     *
     * @param dubboUpdateUsers 新增或者更新用户参数实体
     * @throws DoucSyncException 有数据同步失败时会抛出 DoucSyncException，异常类中包含所需要的异常信息，具体查看该类
     */
    public void addOrUpdateUsers(List<DubboUpdateUser> dubboUpdateUsers) {
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(dubboUpdateUsers));
        DubboCommonResp<List<DubboSyncResultInfo>> commonResp = baseInfoV2DubboFacade.addOrUpdateUsers(dubboUpdateUsers);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        Collection<DoucFailedSyncResult> results = new ArrayList<>();
        if (!commonResp.isSuccess()) {
            if (StrUtil.equals(PARTIAL_FAIL_CODE, commonResp.getCode())) {
                Optional.ofNullable(commonResp.getData()).ifPresent(d -> d.forEach(e -> {
                    DoucFailedSyncResult result = new DoucFailedSyncResult();
                    result.setCode(e.getFailCode());
                    result.setMessage(e.getFailMsg());
                    result.setFailIds(e.getDataCodes());
                    results.add(result);
                }));
            } else {
                List<String> userCodes = dubboUpdateUsers.stream().map(DubboUpdateUser::getUserCode).collect(Collectors.toList());
                DoucFailedSyncResult result = new DoucFailedSyncResult();
                result.setCode(commonResp.getCode());
                result.setMessage(commonResp.getMsg());
                result.setFailIds(userCodes);
                results.add(result);
            }
            throw new DoucSyncException(results);
        }
    }
    
    /**
     * 删除用户
     *
     * @param userCodes 用户编码集合
     * @throws DoucSyncException 有数据同步失败时会抛出 DoucSyncException，异常类中包含所需要的异常信息，具体查看该类
     */
    public void deleteUsers(List<String> userCodes) {
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(userCodes));
        DubboDeleteUser user = new DubboDeleteUser();
        user.setUserCodes(userCodes);
        user.setAccountId(doucProperties.getAccountId());
        DubboCommonResp<List<DubboSyncResultInfo>> commonResp = baseInfoV2DubboFacade.deleteUsers(user);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        Collection<DoucFailedSyncResult> results = new ArrayList<>();
        if (!commonResp.isSuccess()) {
            if (StrUtil.equals(PARTIAL_FAIL_CODE, commonResp.getCode())) {
                Optional.ofNullable(commonResp.getData()).ifPresent(d -> d.forEach(e -> {
                    DoucFailedSyncResult result = new DoucFailedSyncResult();
                    result.setCode(e.getFailCode());
                    result.setMessage(e.getFailMsg());
                    result.setFailIds(e.getDataCodes());
                    results.add(result);
                }));
            } else {
                DoucFailedSyncResult result = new DoucFailedSyncResult();
                result.setCode(commonResp.getCode());
                result.setMessage(commonResp.getMsg());
                result.setFailIds(userCodes);
                results.add(result);
            }
            throw new DoucSyncException(results);
        }
    }
    
    /**
     * 添加用户并初始化部门，用于同时添加用户和部门，并且该用户会挂在此部门下
     *
     * @param users 参数实体
     * @throws DoucSyncException 有数据同步失败时会抛出 DoucSyncException，异常类中包含所需要的异常信息，具体查看该类
     */
    public void addUserAndDepartment(List<DubboAddUser> users) {
        log.info("douc rpc params: {}", JsonUtils.toJsonStr(users));
        DubboCommonResp<List<DubboSyncResultInfo>> commonResp = baseInfoV2DubboFacade.addUsersAndInitDepartments(users);
        log.info("douc rpc result: {}", JsonUtils.toJsonStr(commonResp));
        Collection<DoucFailedSyncResult> results = new ArrayList<>();
        if (!commonResp.isSuccess()) {
            if (StrUtil.equals(PARTIAL_FAIL_CODE, commonResp.getCode())) {
                Optional.ofNullable(commonResp.getData()).ifPresent(d -> d.forEach(e -> {
                    DoucFailedSyncResult result = new DoucFailedSyncResult();
                    result.setCode(e.getFailCode());
                    result.setMessage(e.getFailMsg());
                    result.setFailIds(e.getDataCodes());
                    results.add(result);
                }));
            } else {
                List<String> userCodes = users.stream().map(DubboAddUser::getUserCode).collect(Collectors.toList());
                DoucFailedSyncResult result = new DoucFailedSyncResult();
                result.setCode(commonResp.getCode());
                result.setMessage(commonResp.getMsg());
                result.setFailIds(userCodes);
                results.add(result);
            }
            throw new DoucSyncException(results);
        }
    }
}
