package com.cloudwise.douc.customization.biz.service.email.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloudwise.douc.customization.biz.dao.CustomDelayMessageRecordMapper;
import com.cloudwise.douc.customization.biz.model.table.CustomDelayMessageRecord;
import com.cloudwise.douc.customization.biz.service.email.CustomDelayMessageRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @author ming.ma
 * @since 2024-12-10  10:05
 **/
@Slf4j
@Service
public class CustomDelayMessageRecordServiceImpl implements CustomDelayMessageRecordService {
    
    @Autowired
    CustomDelayMessageRecordMapper customDelayMessageRecordMapper;
    
    @Override
    public String insertRecord(CustomDelayMessageRecord messageRecord) {
        customDelayMessageRecordMapper.insert(messageRecord);
        return messageRecord.getId();
    }
    
    @Override
    public void updateDelayMessageRecord(List<CustomDelayMessageRecord> messageRecords) {
        customDelayMessageRecordMapper.updateById(messageRecords);
    }
    
    @Override
    public List<CustomDelayMessageRecord> getDelayNotifyMessages() {
        LambdaQueryWrapper<CustomDelayMessageRecord> queryWrapper = Wrappers.lambdaQuery(CustomDelayMessageRecord.class)
                .eq(CustomDelayMessageRecord::getStatus, 0).le(CustomDelayMessageRecord::getRetry, 3)
                .le(CustomDelayMessageRecord::getExecAt, new Date());
        return customDelayMessageRecordMapper.selectList(queryWrapper);
    }
    
    public CustomDelayMessageRecord getNotifyMessages(String workOrderId, String nodeId) {
        log.info("GetNotifyMessages param workOrderId:{},nodeId:{}", workOrderId, nodeId);
        if (!CharSequenceUtil.isAllNotBlank(workOrderId, nodeId)) {
            log.info("GetNotifyMessages param workOrderId or nodeId  is empty");
            return null;
        }
        LambdaQueryWrapper<CustomDelayMessageRecord> queryWrapper = Wrappers.lambdaQuery(CustomDelayMessageRecord.class)
                .eq(CustomDelayMessageRecord::getWorkOrderId, workOrderId).eq(CustomDelayMessageRecord::getNodeId, nodeId)
                .eq(CustomDelayMessageRecord::getStatus, 0);
        List<CustomDelayMessageRecord> customDelayMessageRecords = customDelayMessageRecordMapper.selectList(queryWrapper);
        return CollUtil.isNotEmpty(customDelayMessageRecords) ? customDelayMessageRecords.get(0) : null;
    }
}
