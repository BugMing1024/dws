package com.cloudwise.douc.customization.biz.model.email;

import lombok.Data;

/**
 * @author ming.ma
 * @since 2025-01-10  16:00
 **/
@Data
public class ApproverUser {

    private String approver;

    private String approverId;

}
