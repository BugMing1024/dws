package com.cloudwise.douc.customization.biz.model.appcode;

import lombok.Data;

/**
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @date created at 2025-01-06 17:54; update at 2025-01-06 17:54
 */
@Data
public class SimpleAppCode {
    
    private String code;
    
    private String name;
}
