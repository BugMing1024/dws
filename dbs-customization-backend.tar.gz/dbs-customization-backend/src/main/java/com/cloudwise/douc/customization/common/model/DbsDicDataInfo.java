package com.cloudwise.douc.customization.common.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class DbsDicDataInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long accountId;
    
    private Long id;
    
    private String typeCode;
    
    private Long typeId;
    
    private String code;
    
    private String name;
    
    private int sortCode;
    
    private String description;
    
    private boolean isDefault;
    
    private boolean isEnable;
    
}
