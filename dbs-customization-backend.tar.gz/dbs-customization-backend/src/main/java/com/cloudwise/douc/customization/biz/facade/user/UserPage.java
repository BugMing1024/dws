package com.cloudwise.douc.customization.biz.facade.user;

import lombok.Data;

import java.util.List;

@Data
public class UserPage extends Page {
    
    /**
     * 用户信息分页列表
     */
    private List<UserInfo> list;
}
