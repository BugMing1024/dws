package com.cloudwise.douc.customization.common.constant;

/**
 * @author ming.ma
 * @since 2024-12-04  14:58
 **/
public interface Constants {
    String INNER_VALUE = "${_inner.url}";

    /**
     * douc渠道状态 启用
     */
    Integer CHANEL_OPEN = 1;
    String USERIDS = "userIds";
    String EMAILS = "emails";
    String USERNAMES = "userNames";

    String REJECT_CODE = "Reject Code";
    String REJECT_REASON = "Reject Reason";

    String EMAIL_LISTENER_JOB = "emailListenerJob";
    String EMAIL_LISTENER_JOB_CRON = "0 0/5 * * * ?";
    String EMAIL_LISTENER_JOB_CLASS = "emailListenerJob";

    String RETRY_FAIL_EMAIL_MESSAGE_JOB = "retryFailEmailMessage";
    String RETRY_FAIL_EMAIL_MESSAGE_JOB_CRON = "0 0/3 * * * ?";
    String RETRY_FAIL_EMAIL_MESSAGE_JOB_CLASS = "retryFailEmailMessage";

    String SEND_DELAY_MESSAGE_JOB = "sendDelayMessage";
    String SEND_DELAY_MESSAGE_JOB_CRON = "0 0/10 * * * ?";
    String SEND_DELAY_MESSAGE_JOB_CLASS = "sendDelayMessage";

    String SYNC_HEIGHTEN_DATA_JOB = "syncHeightenData";
    String SYNC_HEIGHTEN_DATA_JOB_CRON = "0 0/10 * * * ?";
    String SYNC_HEIGHTEN_DATA_JOB_CLASS = "syncHeightenData";

    String SYNC_APPCODE_DATA_JOB = "syncAppCodeData";
    String SYNC_APPCODE_DATA_CRON = "0 30 13,18 * * ?";
    String SYNC_APPCODE_DATA_JOB_CLASS = "syncAppCodeData";

    String SYNC_APPCODE_RESILIENCY_DATA_JOB = "syncAppCodeResiliencyInfo";
    String SYNC_APPCODE_RESILIENCY_DATA_CRON = "0 0 21 * * ?";
    String SYNC_APPCODE_RESILIENCY_DATA_JOB_CLASS = "syncAppCodeResiliencyInfo";


    String SYNC_APPCODE_LOBCOUNTRY_DATA_JOB = "syncAppcodeLobCountryData";
    String SYNC_APPCODE_LOBCOUNTRY_DATA_CRON = "0 0 8,13,18 * * ?";
    String SYNC_APPCODE_LOBCOUNTRY_DATA_JOB_CLASS = "syncAppcodeLobCountryData";


    String SYNC_RCA_APPLICATION_PENDING_JOB = "rcaPendingApplicationJob";
    String SYNC_RCA_APPLICATION_PENDING_JOB_CRON = "0 0 1 * * ?";
    String SYNC_RCA_APPLICATION_PENDING_JOBJOB_CLASS = "rcaPendingApplicationJob";







}
