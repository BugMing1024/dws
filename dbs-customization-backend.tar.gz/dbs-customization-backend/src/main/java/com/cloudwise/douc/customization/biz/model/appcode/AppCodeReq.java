package com.cloudwise.douc.customization.biz.model.appcode;

import lombok.Data;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2024/12/18
 */
@Data
public class AppCodeReq {
    
    private List<String> appCodes;
    
    private List<String> otherAppCodes;
}
