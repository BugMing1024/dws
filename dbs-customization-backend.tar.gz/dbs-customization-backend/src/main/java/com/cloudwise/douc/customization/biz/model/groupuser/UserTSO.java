package com.cloudwise.douc.customization.biz.model.groupuser;

import cn.hutool.core.annotation.Alias;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Data
public class UserTSO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String ChangedDate;
    
    @Alias("TSOID")
    private String TSOID;
    
    private String CreatedDate;
    
    private String Login;
}
