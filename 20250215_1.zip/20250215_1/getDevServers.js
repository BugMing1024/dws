
module.exports = getDevServer = (config) => {
  let devConfig = { ...config};
  // 默认端口
  devConfig.port = 8007;
  devConfig.client = {
    overlay:false, // 当出现编译器错误或警告时，在浏览器中显示全屏覆盖。
  }
  // 默认启动时自动打开页面
  devConfig.open = true;
  devConfig.host = '127.0.0.1';
  devConfig.proxy = {
    '/api/v2/lowcode': {
      target: "http://10.0.16.105:18271",
      changeOrigin: true,
    },
    '/api/v2': {
      // target: 'http://10.0.20.240:18272',
      // target: "http://10.0.6.250:18271",
      // target: "http://10.0.16.105:18271",
      target: "http://101.47.23.55:18271", // 扩展容器
      changeOrigin: true
    },
    '/douc_support/dosm/signOff': {
      target: "http://10.0.16.105:8087",
      changeOrigin: true
    },
    '/custom/api': {
      target: "http://10.0.16.105:8087",
      changeOrigin: true
    },
  }
  // config.proxy = [
  //   {
  //     context: [
  //       '/docp/gateway',
  //       '/gateway',
  //       '/douc/api',
  //       '/docp/api',
  //       '/docp/douc/api',
  //       '/api',
  //       '/api/v2/lowcode',
  //     ],
  //     target: 'http://10.0.16.104:18080',
  //     changeOrigin: true,
  //     secure: false,
  //   },
  // ];
  return devConfig;
}
