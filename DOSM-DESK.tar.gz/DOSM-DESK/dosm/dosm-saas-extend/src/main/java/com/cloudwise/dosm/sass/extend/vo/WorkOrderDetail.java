package com.cloudwise.dosm.sass.extend.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author roderick.zou
 * @Description: 工单详情
 * @date 3/16/23 2:14 PM
 */
@Data
public class WorkOrderDetail {
    @ApiModelProperty(value = "工单ID", example = "", required = true)
    private String workOrderId;

    @ApiModelProperty(value = "工单编号", example = "", required = true)
    private String workOrderKey;

    @ApiModelProperty(value = "表单数据", example = "", required = true)
    private Object formData;


}
