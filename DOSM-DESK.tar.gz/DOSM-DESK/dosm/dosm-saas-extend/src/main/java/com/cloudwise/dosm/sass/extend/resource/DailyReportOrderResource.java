package com.cloudwise.dosm.sass.extend.resource;


import com.cloudwise.dosm.biz.instance.vo.MdlInstanceViewVo;
import com.cloudwise.dosm.biz.workOrder.service.impl.workorder.base.AbstractListWorkOrderV2Service;
import com.cloudwise.dosm.biz.workOrder.service.impl.workorder.base.ListWorkOrderV2Factory;
import com.cloudwise.dosm.biz.workOrder.service.impl.workorder.v2.CustomViewListV2Service;
import com.cloudwise.dosm.biz.workOrder.vo.WorkOrderQueryInputVO;
import com.cloudwise.dosm.biz.workOrder.vo.WorkOrderQueryVO;
import com.cloudwise.dosm.core.enums.DetailEnableTypeEnum;
import com.cloudwise.dosm.core.pojo.bo.CommonBo;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.pojo.vo.PageVo;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.core.utils.UUIDUtils;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.facewall.core.annotation.IgnoreResponseAdvice;
import com.cloudwise.dosm.sass.extend.vo.SelectReturnData;
import com.cloudwise.dosm.sass.extend.vo.SelectReturnResultVo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.google.common.collect.Maps;
import jodd.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;

/**
 * 每日上报流程接口数据API
 */

@Slf4j
@RestController
@IgnoreResponseAdvice
@RequestMapping("/extend/dailyReport/order")
public class DailyReportOrderResource {
    /**
     * 分页大小
     */
    @Value("${sass.extend.pageSize:10000}")
    private int pageSize;
    /**
     * 当前页码
     */
    private final int CURRENT_PAGE = 1;
    /**
     * 语言
     */
    private final String LANGUAGE = "zh_CN";
    /**
     * trace id
     */
    private final String TRACE_ID = UUIDUtils.build();
    /**
     * 是否启用当前API服务
     */
    @Value("${sass.extend.enable:false}")
    private Boolean enable;
    /**
     * 租户ID 303141000
     */
    @Value("${sass.extend.accountId:''}")
    private String accountId;
    /**
     * 顶级租户ID 303141000
     */
    @Value("${sass.extend.topAccountId:''}")
    private String topAccountId;
    /**
     * 鉴权用户ID 246821
     */
    @Value("${sass.extend.userId:''}")
    private String userId;
    /**
     * 流程视图ID  d18349c301884a19ac4ecd744567d2ad
     */
    @Value("${sass.extend.viewId:''}")
    private String viewId;
    /**
     * 流程展示字段类型ID d18349c301884a19ac4ecd744567d2ad
     */
    @Value("${sass.extend.showFormFieldType:''}")
    private String showFormFieldType;
    /**
     * 非需求任务流程key moejegjf
     */
    @Value("${sass.extend.nonRequired.modeldefinitionKey:''}")
    private String nonRequiredModelKey;
    /**
     * 原始任务流程key kpyqyudi
     */
    @Value("${sass.extend.originalTask.modeldefinitionKey:''}")
    private String originalTaskModelKey;

    /**
     * 时间持续长度 默认90天(近三月)
     */
    @Value("${sass.extend.timeDuration:90}")
    private int timeDuration;

//    /**
//     * 关联故事流程key kpyqyudi
//     */
//    @Value("${sass.extend.relationStory.modeldefinitionKey:ukexjsww}")
//    private String relationStoryModelKey;

//    /**
//     * 故事流程故事类型字段编码  INPUT_57a7f3d01b22bf
//     */
//    @Value("${sass.extend.storyType.fieldCode:'INPUT_57a7f3d01b22bf'}")
//    private String storyTypeFieldCode;

    @Resource
    private ListWorkOrderV2Factory listWorkOrderV2Factory;

    /**
     * 7.3 每日任务上报流程中的【每日非需求类任务清单】表格中的【关联非需求任务（非需求任务流程下的所有工单）】字段，
     * 属性编码：SELECT_9006c6d8b6432，该字段需要引用非需求任务流程下的所有状态的工单
     *
     * @return
     */
    @GetMapping(value = "/getNonRequiredTasksOrder/list")
    public SelectReturnResultVo getNonRequiredTasksOrderList() {
        log.info("call mehtod getNonRequiredTasksOrder start....");
        RequestDomain requestDomain = UserHolder.get();
        log.info("requestDomain.getAccountId():{}", requestDomain.getAccountId());
        log.info("requestDomain.getTopAccountId():{}", requestDomain.getTopAccountId());
        log.info("requestDomain.getUserId():{}", requestDomain.getUserId());
        //构建公共参数
        CommonBo paramBo = CommonBo.buildWith(accountId, topAccountId, userId,
                CURRENT_PAGE, pageSize,
                LANGUAGE, TRACE_ID);
        //实例化自定义视图service实体
        Class<? extends AbstractListWorkOrderV2Service> clazz = CustomViewListV2Service.class;
        Map<String, Object> extendField = Maps.newHashMap();
        extendField.put("viewId", viewId);
        paramBo.setExtendField(extendField);
        //构建工单查询入参实体
        WorkOrderQueryInputVO workOrderQueryInputVO = new WorkOrderQueryInputVO();
        List<WorkOrderQueryVO> workOrderQueryVOS = new ArrayList<>();
        WorkOrderQueryVO workOrderQueryVO = new WorkOrderQueryVO();
        workOrderQueryVO.setFieldKey("modelDefinitionKeyList");
        workOrderQueryVO.setType("SELECT_MANY");
        JsonNode jsonNode = JsonUtils.parseJsonNode(Arrays.asList(nonRequiredModelKey));
        workOrderQueryVO.setValue(jsonNode);
        workOrderQueryVOS.add(workOrderQueryVO);
//        WorkOrderQueryVO workOrderQueryVO1=new WorkOrderQueryVO();
//        workOrderQueryVO1.setFieldKey("orderStatusList");
//        workOrderQueryVO1.setType("SELECT_MANY");
//        JsonNode jsonNode1= JsonUtils.parseJsonNode(Arrays.asList("10","0","50"));
//        workOrderQueryVO1.setValue(jsonNode1);
//        workOrderQueryVOS.add(workOrderQueryVO1);
        workOrderQueryInputVO.setQueryData(workOrderQueryVOS);
        workOrderQueryInputVO.setShowFormFieldType(showFormFieldType);
        workOrderQueryInputVO.setEnableType(DetailEnableTypeEnum.other);
        workOrderQueryInputVO.setViewId(viewId);
        //定义下拉框返回结果集对象
        SelectReturnResultVo selectReturnResultVo = new SelectReturnResultVo();
        // 判断接口服务是否开启，若关闭则不进行业务处理
        if (!enable) {
            log.info("call mehtod getNonRequiredTasksOrder enable is false");
            return selectReturnResultVo;
        }
        try {
            //查询工单实例
            PageVo<MdlInstanceViewVo> mdlInstanceViewVoPageVo = listWorkOrderV2Factory.getListAndCountV2(clazz, paramBo, workOrderQueryInputVO);
            if (mdlInstanceViewVoPageVo.getRecords() != null && mdlInstanceViewVoPageVo.getRecords().size() > 0) {
                List<SelectReturnData> selectReturnDataList = new ArrayList<>();
                mdlInstanceViewVoPageVo.getRecords().forEach(mdlInstanceViewVo -> {
                    SelectReturnData selectReturnData = new SelectReturnData();
                    selectReturnData.setData(mdlInstanceViewVo.getBizKey());
                    selectReturnData.setId(mdlInstanceViewVo.getId());
                    selectReturnData.setLabel(mdlInstanceViewVo.getTitle());
                    selectReturnDataList.add(selectReturnData);
                });
                selectReturnResultVo.setData(selectReturnDataList);
            }
        } catch (Exception e) {
            log.error("call mehtod getNonRequiredTasksOrder error:{}", e);
        }
        log.info("call mehtod getNonRequiredTasksOrder end....");
        return selectReturnResultVo;
    }

    /**
     * 7.1 每日任务上报流程中的【每日需求类任务清单】表格中的【关联需求任务（原始任务流程下的所有工单）】字段，
     * 属性编码：SELECT_b1c9f209429c3，该字段需要引用原始任务流程下的所有未完成/未关闭状态的工单
     *
     * @return
     */
    @GetMapping(value = "/getRequiredTasksOrder/list")
    public SelectReturnResultVo getRequiredTasksOrderList() {
        RequestDomain requestDomain = UserHolder.get();
        log.info("requestDomain.getAccountId():{}", requestDomain.getAccountId());
        log.info("requestDomain.getTopAccountId():{}", requestDomain.getTopAccountId());
        log.info("requestDomain.getUserId():{}", requestDomain.getUserId());
        //构建公共参数
        CommonBo paramBo = CommonBo.buildWith(accountId, topAccountId, userId, CURRENT_PAGE, pageSize, LANGUAGE, TRACE_ID);
        //实例化自定义视图service实体
        Class<? extends AbstractListWorkOrderV2Service> clazz = CustomViewListV2Service.class;
        Map<String, Object> extendField = Maps.newHashMap();
        extendField.put("viewId", viewId);
        paramBo.setExtendField(extendField);

        //构建工单查询入参实体
        WorkOrderQueryInputVO workOrderQueryInputVO = new WorkOrderQueryInputVO();

        List<WorkOrderQueryVO> workOrderQueryVOS = new ArrayList<>();
        WorkOrderQueryVO workOrderQueryVO = new WorkOrderQueryVO();
        workOrderQueryVO.setFieldKey("modelDefinitionKeyList");
        workOrderQueryVO.setType("SELECT_MANY");

        JsonNode jsonNode = JsonUtils.parseJsonNode(Arrays.asList(originalTaskModelKey));
        workOrderQueryVO.setValue(jsonNode);
        workOrderQueryVOS.add(workOrderQueryVO);

//        WorkOrderQueryVO workOrderQueryVO1 = new WorkOrderQueryVO();
//        workOrderQueryVO1.setFieldKey("orderStatusList");
//        workOrderQueryVO1.setType("SELECT_MANY");
//        JsonNode jsonNode1 = JsonUtils.parseJsonNode(Arrays.asList("10", "0", "50"));
//        workOrderQueryVO1.setValue(jsonNode1);
//        workOrderQueryVOS.add(workOrderQueryVO1);

        WorkOrderQueryVO workOrderQueryVO2 = new WorkOrderQueryVO();
        workOrderQueryVO2.setFieldKey("createdTime");
        workOrderQueryVO2.setType("DATE");
        long dayStartTime = RelativeTimeUtil.getDayStartTime(-timeDuration);
        log.info("dayStartTime is :{}", dayStartTime);
        long dayEndTime = RelativeTimeUtil.getDayEndTime(0);
        log.info("dayEndTime is :{}", dayEndTime);
        JsonNode jsonNode2 = JsonUtils.parseJsonNode(Arrays.asList(dayStartTime, dayEndTime));
        workOrderQueryVO2.setValue(jsonNode2);
        workOrderQueryVOS.add(workOrderQueryVO2);

        workOrderQueryInputVO.setQueryData(workOrderQueryVOS);
        workOrderQueryInputVO.setShowFormFieldType(showFormFieldType);
        workOrderQueryInputVO.setEnableType(DetailEnableTypeEnum.other);
        workOrderQueryInputVO.setViewId(viewId);
        //定义下拉框返回结果集对象
        SelectReturnResultVo selectReturnResultVo = new SelectReturnResultVo();
        // 判断接口服务是否开启，若关闭则不进行业务处理
        if (!enable) {
            log.info("call mehtod getRequiredTasksOrder enable is false");
            return selectReturnResultVo;
        }
        try {
            //查询工单实例
            PageVo<MdlInstanceViewVo> mdlInstanceViewVoPageVo = listWorkOrderV2Factory.getListAndCountV2(clazz, paramBo, workOrderQueryInputVO);
            if (mdlInstanceViewVoPageVo.getRecords() != null && mdlInstanceViewVoPageVo.getRecords().size() > 0) {
                List<SelectReturnData> selectReturnDataList = new ArrayList<>();
                mdlInstanceViewVoPageVo.getRecords().forEach(mdlInstanceViewVo -> {
                    SelectReturnData selectReturnData = new SelectReturnData();
                    selectReturnData.setData(mdlInstanceViewVo.getBizKey());
                    selectReturnData.setId(mdlInstanceViewVo.getId());
                    selectReturnData.setLabel(mdlInstanceViewVo.getTitle());
                    selectReturnDataList.add(selectReturnData);
                });
                selectReturnResultVo.setData(selectReturnDataList);
            }
        } catch (Exception e) {
            log.error("call method getRequiredTasksOrder error:{}", e);
        }
        return selectReturnResultVo;
    }

    /**
     * 7.8 每日任务上报流程中的【每日非需求类任务清单】表格中的【关联故事】字段，属性编码：SELECT_d2e027f0bb60b，该字段需所有状态的非需求类故事流程工单
     * storyType: "required"
     * storyType: "nonRequired"
     * env: "prod"
     * env: "test"
     */
//    @GetMapping(value = "/getRelationStoryOrder/list")
//    public SelectReturnResultVo getRelationStoryOrderList() {
    @GetMapping(value = "/getRelationStoryOrder/list2")
    public SelectReturnResultVo getRelationStoryOrderList(@RequestParam(value = "modelDefKey") String modelDefKey,
                                                          @RequestParam(value = "modelDefId") String modelDefId,
                                                          @RequestParam(value = "storyTypeFieldCode") String storyTypeFieldCode,
                                                          @RequestParam(value = "storyTypeFieldValue") String storyTypeFieldValue,
                                                          @RequestParam(value = "startTimeFieldCode") String startTimeFieldCode) {
        log.info("modelDefId is :{}", modelDefId);
        log.info("storyTypeFieldCode is :{}", storyTypeFieldCode);
        log.info("storyTypeFieldValue is :{}", storyTypeFieldValue);
        RequestDomain requestDomain = UserHolder.get();
        log.info("requestDomain.getAccountId():{}", requestDomain.getAccountId());
        log.info("requestDomain.getTopAccountId():{}", requestDomain.getTopAccountId());
        log.info("requestDomain.getUserId():{}", requestDomain.getUserId());
        //构建公共参数
        CommonBo paramBo = CommonBo.buildWith(accountId, topAccountId, userId, CURRENT_PAGE, pageSize, LANGUAGE, TRACE_ID);
        //实例化自定义视图service实体
        Class<? extends AbstractListWorkOrderV2Service> clazz = CustomViewListV2Service.class;
        Map<String, Object> extendField = Maps.newHashMap();
        extendField.put("viewId", viewId);
        paramBo.setExtendField(extendField);

        //构建工单查询入参实体
        WorkOrderQueryInputVO workOrderQueryInputVO = new WorkOrderQueryInputVO();

        List<WorkOrderQueryVO> workOrderQueryVOS = new ArrayList<>();
        WorkOrderQueryVO workOrderQueryVO = new WorkOrderQueryVO();
        workOrderQueryVO.setFieldKey("modelDefinitionKeyList");
        workOrderQueryVO.setType("SELECT_MANY");

        JsonNode jsonNode = JsonUtils.parseJsonNode(Arrays.asList(modelDefKey));
//        JsonNode jsonNode = JsonUtils.parseJsonNode(Arrays.asList("ukexjsww"));
        workOrderQueryVO.setValue(jsonNode);
        workOrderQueryVOS.add(workOrderQueryVO);

        WorkOrderQueryVO workOrderQueryVO1 = new WorkOrderQueryVO();
        workOrderQueryVO1.setFieldKey(modelDefId + "|" + storyTypeFieldCode);
        workOrderQueryVO1.setPreNum(modelDefKey);
        workOrderQueryVO1.setType("INPUT");
        String storyTypeCN = storyTypeFieldValue.equals("required") ? "需求类型" : "非需求类";
        JsonNode jsonNode1 = new TextNode(storyTypeCN);
        workOrderQueryVO1.setValue(jsonNode1);
        workOrderQueryVOS.add(workOrderQueryVO1);

        if (StringUtil.isNotBlank(startTimeFieldCode) && storyTypeFieldValue.equals("required")) {
            WorkOrderQueryVO workOrderQueryVO2 = new WorkOrderQueryVO();
            workOrderQueryVO2.setFieldKey(modelDefId + "|" + startTimeFieldCode);
            workOrderQueryVO2.setPreNum(modelDefKey);
            workOrderQueryVO2.setType("DATE");
            long dayStartTime = RelativeTimeUtil.getDayStartTime(-timeDuration);
            log.info("dayStartTime is :{}", dayStartTime);
            long dayEndTime = RelativeTimeUtil.getDayEndTime(0);
            log.info("dayEndTime is :{}", dayEndTime);
            JsonNode jsonNode2 = JsonUtils.parseJsonNode(Arrays.asList(dayStartTime, dayEndTime));
            workOrderQueryVO2.setValue(jsonNode2);
            workOrderQueryVOS.add(workOrderQueryVO2);
        }

        workOrderQueryInputVO.setQueryData(workOrderQueryVOS);
        workOrderQueryInputVO.setShowFormFieldType(showFormFieldType);
        workOrderQueryInputVO.setEnableType(DetailEnableTypeEnum.other);
        workOrderQueryInputVO.setViewId(viewId);
        log.info("viewId is :{}", viewId);
        log.info("workOrderQueryInputVO is :{}", JsonUtils.toJsonString(workOrderQueryInputVO));
        //定义下拉框返回结果集对象
        SelectReturnResultVo selectReturnResultVo = new SelectReturnResultVo();
        // 判断接口服务是否开启，若关闭则不进行业务处理
        log.info("enable is :{}", enable);
        if (!enable) {
            log.info("call mehtod getRelationStoryOrderList enable is false");
            return selectReturnResultVo;
        }
        try {
            //查询工单实例
            PageVo<MdlInstanceViewVo> mdlInstanceViewVoPageVo = listWorkOrderV2Factory.getListAndCountV2(clazz, paramBo, workOrderQueryInputVO);
            log.info("mdlInstanceViewVoPageVo getRecords size is :{}", mdlInstanceViewVoPageVo.getRecords().size());
            if (mdlInstanceViewVoPageVo.getRecords() != null && mdlInstanceViewVoPageVo.getRecords().size() > 0) {
                List<SelectReturnData> selectReturnDataList = new ArrayList<>();
                mdlInstanceViewVoPageVo.getRecords().forEach(mdlInstanceViewVo -> {
                    SelectReturnData selectReturnData = new SelectReturnData();
                    selectReturnData.setData(mdlInstanceViewVo.getBizKey());
                    selectReturnData.setId(mdlInstanceViewVo.getId());
                    selectReturnData.setLabel(mdlInstanceViewVo.getTitle());
                    selectReturnDataList.add(selectReturnData);
                });
                selectReturnResultVo.setData(selectReturnDataList);
            }
        } catch (Exception e) {
            log.error("call method getRequiredTasksOrder error:{}", e);
        }
        return selectReturnResultVo;
    }

    @GetMapping(value = "/getRelationStoryOrder/list")
    public SelectReturnResultVo getRelationStoryOrderList(@RequestParam(value = "modelDefKey") String modelDefKey,
                                                          @RequestParam(value = "modelDefId") String modelDefId,
                                                          @RequestParam(value = "storyTypeFieldCode") String storyTypeFieldCode,
                                                          @RequestParam(value = "storyTypeFieldValue") String storyTypeFieldValue) {
        log.info("modelDefId is :{}", modelDefId);
        log.info("storyTypeFieldCode is :{}", storyTypeFieldCode);
        log.info("storyTypeFieldValue is :{}", storyTypeFieldValue);
        RequestDomain requestDomain = UserHolder.get();
        log.info("requestDomain.getAccountId():{}", requestDomain.getAccountId());
        log.info("requestDomain.getTopAccountId():{}", requestDomain.getTopAccountId());
        log.info("requestDomain.getUserId():{}", requestDomain.getUserId());
        //构建公共参数
        CommonBo paramBo = CommonBo.buildWith(accountId, topAccountId, userId, CURRENT_PAGE, pageSize, LANGUAGE, TRACE_ID);
        //实例化自定义视图service实体
        Class<? extends AbstractListWorkOrderV2Service> clazz = CustomViewListV2Service.class;
        Map<String, Object> extendField = Maps.newHashMap();
        extendField.put("viewId", viewId);
        paramBo.setExtendField(extendField);

        //构建工单查询入参实体
        WorkOrderQueryInputVO workOrderQueryInputVO = new WorkOrderQueryInputVO();

        List<WorkOrderQueryVO> workOrderQueryVOS = new ArrayList<>();
        WorkOrderQueryVO workOrderQueryVO = new WorkOrderQueryVO();
        workOrderQueryVO.setFieldKey("modelDefinitionKeyList");
        workOrderQueryVO.setType("SELECT_MANY");

        JsonNode jsonNode = JsonUtils.parseJsonNode(Arrays.asList(modelDefKey));
//        JsonNode jsonNode = JsonUtils.parseJsonNode(Arrays.asList("ukexjsww"));
        workOrderQueryVO.setValue(jsonNode);
        workOrderQueryVOS.add(workOrderQueryVO);

        WorkOrderQueryVO workOrderQueryVO1 = new WorkOrderQueryVO();
        workOrderQueryVO1.setFieldKey(modelDefId + "|" + storyTypeFieldCode);
        workOrderQueryVO1.setPreNum(modelDefKey);
        workOrderQueryVO1.setType("INPUT");
        String storyTypeCN = storyTypeFieldValue.equals("required") ? "需求类型" : "非需求类";
        JsonNode jsonNode1 = new TextNode(storyTypeCN);
        workOrderQueryVO1.setValue(jsonNode1);
        workOrderQueryVOS.add(workOrderQueryVO1);

//        if (StringUtil.isNotBlank(startTimeFieldCode) && storyTypeFieldValue.equals("required")) {
//            WorkOrderQueryVO workOrderQueryVO2 = new WorkOrderQueryVO();
//            workOrderQueryVO2.setFieldKey(modelDefId + "|" + startTimeFieldCode);
//            workOrderQueryVO2.setPreNum(modelDefKey);
//            workOrderQueryVO2.setType("DATE");
//            long dayStartTime = RelativeTimeUtil.getDayStartTime(-timeDuration);
//            log.info("dayStartTime is :{}", dayStartTime);
//            long dayEndTime = RelativeTimeUtil.getDayEndTime(0);
//            log.info("dayEndTime is :{}", dayEndTime);
//            JsonNode jsonNode2 = JsonUtils.parseJsonNode(Arrays.asList(dayStartTime, dayEndTime));
//            workOrderQueryVO2.setValue(jsonNode2);
//            workOrderQueryVOS.add(workOrderQueryVO2);
//        }

        workOrderQueryInputVO.setQueryData(workOrderQueryVOS);
        workOrderQueryInputVO.setShowFormFieldType(showFormFieldType);
        workOrderQueryInputVO.setEnableType(DetailEnableTypeEnum.other);
        workOrderQueryInputVO.setViewId(viewId);
        log.info("viewId is :{}", viewId);
        log.info("workOrderQueryInputVO is :{}", JsonUtils.toJsonString(workOrderQueryInputVO));
        //定义下拉框返回结果集对象
        SelectReturnResultVo selectReturnResultVo = new SelectReturnResultVo();
        // 判断接口服务是否开启，若关闭则不进行业务处理
        log.info("enable is :{}", enable);
        if (!enable) {
            log.info("call mehtod getRelationStoryOrderList enable is false");
            return selectReturnResultVo;
        }
        try {
            //查询工单实例
            PageVo<MdlInstanceViewVo> mdlInstanceViewVoPageVo = listWorkOrderV2Factory.getListAndCountV2(clazz, paramBo, workOrderQueryInputVO);
            log.info("mdlInstanceViewVoPageVo getRecords size is :{}", mdlInstanceViewVoPageVo.getRecords().size());
            if (mdlInstanceViewVoPageVo.getRecords() != null && mdlInstanceViewVoPageVo.getRecords().size() > 0) {
                List<SelectReturnData> selectReturnDataList = new ArrayList<>();
                mdlInstanceViewVoPageVo.getRecords().forEach(mdlInstanceViewVo -> {
                    SelectReturnData selectReturnData = new SelectReturnData();
                    selectReturnData.setData(mdlInstanceViewVo.getBizKey());
                    selectReturnData.setId(mdlInstanceViewVo.getId());
                    selectReturnData.setLabel(mdlInstanceViewVo.getTitle());
                    selectReturnDataList.add(selectReturnData);
                });
                selectReturnResultVo.setData(selectReturnDataList);
            }
        } catch (Exception e) {
            log.error("call method getRequiredTasksOrder error:{}", e);
        }
        return selectReturnResultVo;
    }

    static class RelativeTimeUtil {
        private static final String TIME_ZONE = "GMT+8";

        public static long getDayStartTime(int num) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
            calendar.add(Calendar.DATE, num);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            return calendar.getTimeInMillis();
        }

        public static long getDayEndTime(int num) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
            calendar.add(Calendar.DATE, num);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 59);
            calendar.set(Calendar.MILLISECOND, 0);
            return calendar.getTimeInMillis();
        }
    }
}
