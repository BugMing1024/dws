package com.cloudwise.dosm.sass.extend.vo;

/**
 * @author roderick.zou
 * @Description:
 * @date 2/2/23 10:18 AM
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 下拉框组件返回对象
 */
@Data
public class SelectReturnResultVo {

    @ApiModelProperty(value = "状态", example = "", required = true)
    private String status="success";

    @ApiModelProperty(value = "数据实体", example = "", required = true)
    private List<SelectReturnData> data;


}
