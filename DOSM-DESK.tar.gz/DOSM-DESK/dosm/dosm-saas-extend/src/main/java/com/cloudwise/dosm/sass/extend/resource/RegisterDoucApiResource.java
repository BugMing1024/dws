package com.cloudwise.dosm.sass.extend.resource;


import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.core.utils.UUIDUtils;
import com.cloudwise.dosm.douc.entity.user.UserInfo;
import com.cloudwise.dosm.douc.reference.DoucReferenceManager;
import com.cloudwise.dosm.douc.sso.UserSSOClient;
import com.cloudwise.dosm.facewall.core.annotation.IgnoreResponseAdvice;
import com.cloudwise.douc.dto.DubboApiModifyInfo;
import com.cloudwise.douc.dto.DubboApiModifyReq;
import com.cloudwise.douc.dto.DubboAppAndApiQueryReq;
import com.cloudwise.douc.facade.ApiAuthDubboFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * 注册douc-API控制器
 */
@Slf4j
@RestController
@IgnoreResponseAdvice
@RequestMapping("/extend/registerApi")
public class RegisterDoucApiResource {
    /**
     * trace id
     */
    private final String TRACE_ID = UUIDUtils.build();
    /**
     * 是否启用当前API服务
     */
    @Value("${sass.extend.enable:false}")
    private Boolean enable;
    /**
     * 租户ID 303141000
     */
    @Value("${sass.extend.accountId:''}")
    private String accountId;
    /**
     * 顶级租户ID 303141000
     */
    @Value("${sass.extend.topAccountId:''}")
    private String topAccountId;
    /**
     * 鉴权用户ID 246821
     */
    @Value("${sass.extend.userId:''}")
    private String userId;

    @Autowired
    private UserSSOClient userSSOClient;
    @Autowired
    private DoucReferenceManager doucReferenceManager;

    public static final String DOSM_MODEL_CODE = "112";
    public static final String WEB_FORM = "WEB_FORM";
    public static final String MONITOR_SYSTEM = "MONITOR_SYSTEM";
    public static final String H5 = "H5";
    public static final String ROUTINE_WORK = "ROUTINE_WORK";

    //示例 {"name":"创建工单saas","code":"orderCreate","uri":"/gatewayApi/dosm/api/v2/open/api/orderCreate","rule":"{}","status":1,"apiType":1,"requestInfo":"{}"}
    @PostMapping(value = "/saas")
    public String saas(@RequestBody DubboApiModifyInfo dubboApiModifyInfo) {
        log.info("DubboAsyncApiReq dubboAsyncApiReq before setting common value, is {}", JsonUtils.toJsonString(dubboApiModifyInfo));
        // 判断接口服务是否开启，若关闭则不进行业务处理
        if (!enable) {
            log.info("call mehtod saas enable is false");
            return null;
        }
        List<DubboApiModifyInfo> apiInfoList = new ArrayList<>();
        if(StringUtils.isBlank(dubboApiModifyInfo.getCode())) {
            dubboApiModifyInfo.setCode(UUIDUtils.build());
        }
        dubboApiModifyInfo.setModuleCode(DOSM_MODEL_CODE);
        log.info("DubboAsyncApiReq dubboAsyncApiReq after setting common value, is {}", JsonUtils.toJsonString(dubboApiModifyInfo));
        apiInfoList.add(dubboApiModifyInfo);
        //SAAS分支注册方式
        log.info("saas初始化环境注册api,本次注册的租户为:{}", accountId);
        DubboAppAndApiQueryReq dubboAppAndApiQueryReq = new DubboAppAndApiQueryReq();
        dubboAppAndApiQueryReq.setAccountId(accountId);
        try {
            UserInfo systemUser = userSSOClient.getSystemUsersByAccountId(accountId);
            DubboApiModifyReq dubboApiModifyReq = new DubboApiModifyReq();
            dubboApiModifyReq.setAccountId(accountId);
            if (ObjectUtils.isEmpty(systemUser)) {
                dubboApiModifyReq.setUserId("3");
            } else {
                dubboApiModifyReq.setUserId(String.valueOf(systemUser.getUserId()));
            }
            dubboApiModifyReq.setApiInfoList(apiInfoList);
            log.info("insert account:{},apiList:{}", accountId, dubboApiModifyReq);
            com.cloudwise.douc.dto.DubboCommonResp<String> addResult = doucReferenceManager.getApiAuthDubboFacade().modifyApiInfo(dubboApiModifyReq);
            if (!addResult.isSuccess()) {
                log.error("insert account api fail, accountUser = {},errorMsg:{}", accountId, addResult);
            }
        } catch (Exception e) {
            log.error("insert account api fail, accountUser = {},errorMsg:{}", accountId, e);
            return "failer";
        }
        return "success";
    }
}
