package com.cloudwise.dosm.sass.extend.resource;

import com.cloudwise.dosm.biz.instance.dto.MdlInstanceRes;
import com.cloudwise.dosm.biz.instance.service.mdlins.order.WorkOrderDetailService;
import com.cloudwise.dosm.biz.instance.vo.MdlInstanceViewVo;
import com.cloudwise.dosm.biz.workOrder.enums.QueryListV2Enum;
import com.cloudwise.dosm.biz.workOrder.service.impl.workorder.base.AbstractListWorkOrderV2Service;
import com.cloudwise.dosm.biz.workOrder.service.impl.workorder.base.ListWorkOrderV2Factory;
import com.cloudwise.dosm.biz.workOrder.service.impl.workorder.v2.CustomViewListV2Service;
import com.cloudwise.dosm.biz.workOrder.vo.WorkOrderQueryInputVO;
import com.cloudwise.dosm.core.enums.DetailEnableTypeEnum;
import com.cloudwise.dosm.core.pojo.bo.CommonBo;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.pojo.vo.PageVo;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.facewall.core.annotation.IgnoreResponseAdvice;
import com.cloudwise.dosm.sass.extend.vo.WorkOrderDetail;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author roderick.zou
 * @Description: 工单列表视图对外API封装
 * @date 3/14/23 7:52 PM
 */

@Slf4j
@RestController
@IgnoreResponseAdvice
@RequestMapping("/api/v2/extend/workOrder/api")
public class WorkOrderApiResource {

    /**
     * 是否启用当前API服务
     */
    @Value("${sass.extend.enable:false}")
    private Boolean enable;


    @Resource
    private ListWorkOrderV2Factory listWorkOrderV2Factory;

    @Autowired
    private WorkOrderDetailService workOrderDetailService;


    /**
     * 自定义视图查询接口
     *
     * @return
     */
    @PostMapping(value = "/customView/list")
    public PageVo<MdlInstanceViewVo> getCutsomViewList(@RequestBody WorkOrderQueryInputVO workOrderQueryInputVO,
    @RequestParam int currentPage, @RequestParam int pageSize) {
        log.info("call mehtod getCutsomViewList start....");
        RequestDomain requestDomain = UserHolder.get();
        log.info("requestDomain.getAccountId():{}", requestDomain.getAccountId());
        log.info("requestDomain.getTopAccountId():{}", requestDomain.getTopAccountId());
        log.info("requestDomain.getUserId():{}", requestDomain.getUserId());

        // 判断接口服务是否开启，若关闭则不进行业务处理
        if (!enable) {
            log.info("call mehtod getCutsomViewList enable is false");
            return null;
        }
        try {
            CommonBo paramBo = CommonBo.buildWith(requestDomain.getAccountId(), requestDomain.getTopAccountId(), requestDomain.getUserId(),
                    currentPage, pageSize,
                    requestDomain.getLanguage(), requestDomain.getTraceId());
            String viewId=workOrderQueryInputVO.getViewId();
            Class<? extends AbstractListWorkOrderV2Service> clazz = CustomViewListV2Service.class;
            Map<String, Object> extendField = Maps.newHashMap();
            extendField.put("viewId", viewId);
            paramBo.setExtendField(extendField);
            workOrderQueryInputVO.setViewId(viewId);
            return listWorkOrderV2Factory.getListAndCountV2(clazz, paramBo, workOrderQueryInputVO);
        }
        catch (Exception e) {
            log.error("call mehtod getCutsomViewList error:{}", e);
        }
        log.info("call mehtod getCutsomViewList end....");
        return null;
    }



    /**
     * 工单详情批量查询接口
     *
     * @return
     */
    @PostMapping(value = "/orderDetail/list")
    public List<WorkOrderDetail> getOrderDetailList(@RequestBody List<String> orderIds) {
        log.info("call mehtod getOrderDetailList start....");
        RequestDomain requestDomain = UserHolder.get();
        log.info("requestDomain.getAccountId():{}", requestDomain.getAccountId());
        log.info("requestDomain.getTopAccountId():{}", requestDomain.getTopAccountId());
        log.info("requestDomain.getUserId():{}", requestDomain.getUserId());

        // 判断接口服务是否开启，若关闭则不进行业务处理
        if (!enable) {
            log.info("call mehtod getOrderDetailList enable is false");
            return null;
        }
        try {
            CommonBo commonBo = CommonBo.buildWith(requestDomain.getAccountId(), requestDomain.getUserId());
            commonBo.setTopAccountId(requestDomain.getTopAccountId());
            commonBo.setEnableType(DetailEnableTypeEnum.other);
            commonBo.setEnableType(DetailEnableTypeEnum.myAuthorized);
            List<WorkOrderDetail> workOrderDetails=new ArrayList<>();
            log.error("call mehtod getOrderDetailList orderIds is :{}", orderIds);
            if(orderIds!=null){
                orderIds.forEach(orderId->{
                    MdlInstanceRes mdlInstance=workOrderDetailService.getNormalWorkOrderBody(commonBo, orderId);
                    if(mdlInstance!=null){
                        WorkOrderDetail workOrderDetail=new WorkOrderDetail();
                        workOrderDetail.setWorkOrderId(orderId);
                        workOrderDetail.setWorkOrderKey(mdlInstance.getBizKey());
                        workOrderDetail.setFormData(mdlInstance.getFormData());
                        workOrderDetails.add(workOrderDetail);
                    }
                });
            }
            return workOrderDetails;
        }
        catch (Exception e) {
            log.error("call mehtod getOrderDetailList error:{}", e);
        }
        log.info("call mehtod getOrderDetailList end....");
        return null;
    }


}
