package com.cloudwise.dosm.sass.extend.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author roderick.zou
 * @Description: 下拉框组件返回对象data字对象实体
 * @date 2/2/23 10:21 AM
 */
@Data
public class SelectReturnData {

    @ApiModelProperty(value = "展示名称", example = "", required = true)
    private String label;

    @ApiModelProperty(value = "实际值", example = "", required = true)
    private String data;

    @ApiModelProperty(value = "主键", example = "", required = true)
    private String id;
}
