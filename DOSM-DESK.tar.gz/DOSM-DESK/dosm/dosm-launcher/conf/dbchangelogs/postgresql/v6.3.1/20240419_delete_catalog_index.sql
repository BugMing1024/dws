
DROP INDEX public.idx_work_order_service_catalog_id;

