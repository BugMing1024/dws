alter table dodi_user_info add  department_id  int;
alter table dodi_user_info add  status  int;