CREATE TABLE "dosm_global_notify_setting_recond" (
                                                     "id" varchar(32) NOT NULL,
                                                     "name" varchar(255),
                                                     "user_scope" varchar(64) NOT NULL,
                                                     "user_range" jsonb,
                                                     "rule_scope" varchar(64) NOT NULL,
                                                     "rule_ids" jsonb,
                                                     "channel_status" varchar(64) NOT NULL,
                                                     "channels" jsonb,
                                                     "status" int4 DEFAULT 0,
                                                     "account_id" varchar(32),
                                                     "top_account_id" varchar(32),
                                                     "is_del" int4 DEFAULT 0,
                                                     "created_by" varchar(32),
                                                     "created_time" timestamp(6),
                                                     "created_by_user" varchar(32),
                                                     "updated_by" varchar(32),
                                                     "updated_time" timestamp(6),
                                                     PRIMARY KEY ("id")
)
;

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."name" IS '名称';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."user_scope" IS '通知人,全部ALL，指定人PART';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."user_range" IS '仅当通知人为PART时生效，通知人范围';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."rule_scope" IS '消息范围，所有消息ALL，部分PART';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."rule_ids" IS '选择消息';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."channel_status" IS '渠道配置 OPEN 启动渠道 CLOSE 关闭渠道';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."channels" IS '选择渠道';

COMMENT ON COLUMN "dosm_global_notify_setting_recond"."status" IS '0：执行中 1：成功 2：失败';