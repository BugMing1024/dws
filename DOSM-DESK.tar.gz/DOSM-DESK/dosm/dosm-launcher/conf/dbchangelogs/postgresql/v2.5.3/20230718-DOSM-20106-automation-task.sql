
CREATE TABLE mdl_automation_request_record (
                                               id varchar(32) NOT NULL, -- 主键id
                                               account_id varchar(32) NOT NULL, -- 租户id
                                               top_account_id varchar(32) NOT NULL, -- 顶级租户id
                                               created_by varchar(32) NOT NULL, -- 创建人
                                               revision int4 NOT NULL DEFAULT 0, -- 乐观锁
                                               created_time timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
                                               updated_by varchar(32) NOT NULL, -- 更新人
                                               updated_time timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
                                               is_del int4 NOT NULL DEFAULT 0, -- 0有效1删除
                                               process_instance_id varchar(255) NOT NULL, -- 流程实例 id
                                               work_order_id varchar(255) NOT NULL, -- 工单 id
                                               node_id varchar(64) NOT NULL, -- 节点 id
                                               node_name varchar(255) NOT NULL, -- 节点 名称
                                               api_id varchar(64) NOT NULL, -- api id
                                               request_url text NULL, -- 请求url
                                               request_mode varchar(32) NULL, -- 请求方式
                                               request_header json NULL, -- 请求header
                                               request_query json NULL, -- 请求query
                                               request_body json NULL, -- 请求body
                                               response_body json NULL, -- 响应body
                                               request_success int4 NOT NULL, -- 请求是否成功
                                               request_times int4 NOT NULL, -- 请求次数
                                               process_record_group_id varchar(64) NOT NULL, -- 流程处理记录组id
                                               CONSTRAINT mdl_automation_request_record_pkey PRIMARY KEY (id)
);
COMMENT ON TABLE public.mdl_automation_request_record IS '自动化节点请求记录';

COMMENT ON COLUMN public.mdl_automation_request_record.id IS '主键id';
COMMENT ON COLUMN public.mdl_automation_request_record.account_id IS '租户id';
COMMENT ON COLUMN public.mdl_automation_request_record.top_account_id IS '顶级租户id';
COMMENT ON COLUMN public.mdl_automation_request_record.created_by IS '创建人';
COMMENT ON COLUMN public.mdl_automation_request_record.revision IS '乐观锁';
COMMENT ON COLUMN public.mdl_automation_request_record.created_time IS '创建时间';
COMMENT ON COLUMN public.mdl_automation_request_record.updated_by IS '更新人';
COMMENT ON COLUMN public.mdl_automation_request_record.updated_time IS '更新时间';
COMMENT ON COLUMN public.mdl_automation_request_record.is_del IS '0有效1删除';
COMMENT ON COLUMN public.mdl_automation_request_record.process_instance_id IS '流程实例 id';
COMMENT ON COLUMN public.mdl_automation_request_record.work_order_id IS '工单 id';
COMMENT ON COLUMN public.mdl_automation_request_record.node_id IS '节点 id';
COMMENT ON COLUMN public.mdl_automation_request_record.node_name IS '节点 名称';
COMMENT ON COLUMN public.mdl_automation_request_record.api_id IS 'api id';
COMMENT ON COLUMN public.mdl_automation_request_record.request_url IS '请求url';
COMMENT ON COLUMN public.mdl_automation_request_record.request_mode IS '请求方式';
COMMENT ON COLUMN public.mdl_automation_request_record.request_header IS '请求header';
COMMENT ON COLUMN public.mdl_automation_request_record.request_query IS '请求query';
COMMENT ON COLUMN public.mdl_automation_request_record.request_body IS '请求body';
COMMENT ON COLUMN public.mdl_automation_request_record.response_body IS '响应body';
COMMENT ON COLUMN public.mdl_automation_request_record.request_success IS '请求是否成功';
COMMENT ON COLUMN public.mdl_automation_request_record.request_times IS '请求次数';
COMMENT ON COLUMN public.mdl_automation_request_record.process_record_group_id IS '流程处理记录组id';