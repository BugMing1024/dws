ALTER TABLE dosm_notify_rule ADD COLUMN exclude_user_range jsonb;
COMMENT ON COLUMN "dosm_notify_rule"."exclude_user_range" IS '屏蔽通知人范围';