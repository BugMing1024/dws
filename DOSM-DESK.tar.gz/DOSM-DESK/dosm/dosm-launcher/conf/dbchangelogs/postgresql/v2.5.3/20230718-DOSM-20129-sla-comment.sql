
comment on column sla_config_log_content.definition_day is '天的定义方式：NATURAL_DAY自然日时间方式计算天数，工作日时间方式计算天数';

comment on column sla_config_template.definition_day is '天的定义方式：NATURAL_DAY自然日时间方式计算天数，工作日时间方式计算天数';