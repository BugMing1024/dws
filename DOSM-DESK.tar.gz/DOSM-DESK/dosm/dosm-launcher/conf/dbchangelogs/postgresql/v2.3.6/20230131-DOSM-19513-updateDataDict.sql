--修改数据字典label长度为1024，原来为128
ALTER TABLE data_dict_detail ALTER COLUMN "label" TYPE varchar(1024) USING "label"::varchar;
