CREATE TABLE model_data_permission
(
    id                      BIGINT                NOT NULL,
    account_id              VARCHAR(32)           NOT NULL,
    is_del                  SMALLINT    DEFAULT 0 NOT NULL,
    revision                SMALLINT    DEFAULT 0 NOT NULL,
    creator                 VARCHAR(255)          NOT NULL,
    operator                VARCHAR(255)          NOT NULL,
    updated_time            TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    created_time            TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    table_id                VARCHAR(255)          NOT NULL,
    table_name              VARCHAR(255)          NOT NULL,
    permission_name         VARCHAR(255)          NOT NULL,
    permissions             json        DEFAULT NULL,
    scope_type              VARCHAR(255)          NOT NULL,
    status                  VARCHAR(32) DEFAULT '1',
    members                 json        DEFAULT NULL,
    rule_content            json        DEFAULT NULL,
    operational_permissions json                  NOT NULL,
    app_key                 VARCHAR(255)          NOT NULL,
    effect_type             varchar(255)          NOT NULL,
    members_role            VARCHAR(255)          NOT NULL,
    members_group           VARCHAR(255)          NOT NULL,
    members_user            VARCHAR(255)          NOT NULL,
    members_dep            VARCHAR(255)          NOT NULL,
    members_creator         BOOLEAN               NOT NULL,
    is_default              VARCHAR(32) default '0',
    CONSTRAINT model_data_permission_pkey PRIMARY KEY (id)
);
COMMENT
ON TABLE model_data_permission IS '表单策略ui-policies';
COMMENT
ON COLUMN model_data_permission.id IS '主键ID';
COMMENT
ON COLUMN model_data_permission.permission_name IS '数据权限名称';
COMMENT
ON COLUMN model_data_permission.account_id IS '租户ID';
COMMENT
ON COLUMN model_data_permission.is_del IS '是否删除 0存在 、1删除';
COMMENT
ON COLUMN model_data_permission.revision IS '乐观锁';
COMMENT
ON COLUMN model_data_permission.creator IS '创建人';
COMMENT
ON COLUMN model_data_permission.operator IS '操作人';
COMMENT
ON COLUMN model_data_permission.updated_time IS '更新时间';
COMMENT
ON COLUMN model_data_permission.created_time IS '创建时间';
COMMENT
ON COLUMN model_data_permission.table_id IS '数据表id';
COMMENT
ON COLUMN model_data_permission.table_name IS '数据表名称';
COMMENT
ON COLUMN model_data_permission.scope_type IS '权限人员，ALL:全局，PART:部分';
COMMENT
ON COLUMN model_data_permission.rule_content IS '规则内容';
COMMENT
ON COLUMN model_data_permission.members IS '指定权限人员';
COMMENT
ON COLUMN model_data_permission.operational_permissions IS '权限设置';
COMMENT
ON COLUMN model_data_permission.permissions IS '权限列表';
COMMENT
ON COLUMN model_data_permission.effect_type IS '生效范围 ALL:全局，PART:部分';
COMMENT
ON COLUMN model_data_permission.is_default IS '是否默认权限 0非默认 1默认创建人权限 2默认admin权限';