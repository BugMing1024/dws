comment on table mdl_tab_data_record is '页签配置项操作日志记录表';
COMMENT ON COLUMN mdl_tab_data_record.created_time IS '创建时间';
COMMENT ON COLUMN mdl_tab_data_record.updated_time IS '更新时间';
COMMENT ON COLUMN mdl_tab_data_record.created_by IS '创建人';
COMMENT ON COLUMN mdl_tab_data_record.updated_by IS '更新人';
COMMENT ON COLUMN mdl_tab_data_record.is_del IS '删除标记.0:正常;1:删除';
COMMENT ON COLUMN mdl_tab_data_record.top_account_id IS '顶级租户ID';