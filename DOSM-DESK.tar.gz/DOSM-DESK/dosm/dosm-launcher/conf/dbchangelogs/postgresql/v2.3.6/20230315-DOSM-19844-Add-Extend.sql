INSERT INTO public.bpm_adv_extend_script (id,name,description,model,"type",script_content,script_language,account_id,created_by,created_time,updated_by,updated_time,revision,is_del,top_account_id,uri,file_id,param) VALUES
('7dbb9e2904e3624','事件解决通知事件中心','事件解决通知事件中心','EXT_CLASS','TRIGGER','','GROOVY','default','3','2023-03-15 17:41:24.383','3','2023-03-15 17:41:24.383',0,0,'default',NULL,NULL,NULL);
INSERT INTO public.bpm_adv_extend_script (id,name,description,model,"type",script_content,script_language,account_id,created_by,created_time,updated_by,updated_time,revision,is_del,top_account_id,uri,file_id,param) VALUES
('8dbb9e2904e3624','事件处理人改变通知事件中心','事件处理人改变通知事件中心','EXT_CLASS','TRIGGER','','GROOVY','default','3','2023-03-15 17:41:24.383','3','2023-03-15 17:41:24.383',0,0,'default',NULL,NULL,NULL);
INSERT INTO public.bpm_adv_extend_script (id,name,description,model,"type",script_content,script_language,account_id,created_by,created_time,updated_by,updated_time,revision,is_del,top_account_id,uri,file_id,param) VALUES
('9dbb9e2904e3624','工单删除通知事件中心','工单删除通知事件中心','EXT_CLASS','TRIGGER','','GROOVY','default','3','2023-03-15 17:41:24.383','3','2023-03-15 17:41:24.383',0,0,'default',NULL,NULL,NULL);

