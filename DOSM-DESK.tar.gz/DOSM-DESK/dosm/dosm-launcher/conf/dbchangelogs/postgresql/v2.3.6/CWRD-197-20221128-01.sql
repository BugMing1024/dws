--CREATE OR REPLACE FUNCTION array_sort ( anyarray ) RETURNS anyarray AS $ytt$ DECLARE temp_array ALIAS FOR $1; tmp VARCHAR; RESULT TEXT []; BEGIN FOR tmp IN SELECT UNNEST ( temp_array ) AS A ORDER BY A ASC loop RESULT := array_append( RESULT, tmp :: TEXT ); END loop; RETURN RESULT; END; $ytt$ LANGUAGE plpgsql;


-- auto-generated definition,下面是视图权限表的sql脚本
create table model_view_permission
(
    id                  int8                  not null
        constraint model_view_permission_pkey
            primary key,
    account_id          varchar(32)           not null,
    table_id            varchar(255)          not null,
    view_id             varchar(255)          not null,
    is_del              int2        default 0 not null,
    revision            int2        default 0 not null,
    creator             varchar(255)          not null,
    operator            varchar(255)          not null,
    updated_time        timestamp(6)          not null,
    created_time        timestamp(6)          not null,
    scope_type          varchar(255),
    status              varchar(32) default '1',
    rule_content        json,
    member_rule_content json,
    app_key             varchar(255)          not null,
    effect_type         varchar(255),
    is_default          varchar(32) default '0'
);
COMMENT ON TABLE model_view_permission IS '视图权限信息表';
COMMENT ON COLUMN model_view_permission.id IS '主键ID';
COMMENT ON COLUMN model_view_permission.account_id IS '租户ID';
COMMENT ON COLUMN model_view_permission.is_del IS '是否删除 0存在 、1删除';
COMMENT ON COLUMN model_view_permission.revision IS '乐观锁';
COMMENT ON COLUMN model_view_permission.creator IS '创建人';
COMMENT ON COLUMN model_view_permission.operator IS '操作人';
COMMENT ON COLUMN model_view_permission.updated_time IS '更新时间';
COMMENT ON COLUMN model_view_permission.created_time IS '创建时间';
COMMENT ON COLUMN model_view_permission.view_id  IS '实例唯一标识';
COMMENT ON COLUMN model_view_permission.table_id IS '表id';
COMMENT ON COLUMN model_view_permission.app_key IS '应用key';
COMMENT ON COLUMN model_view_permission.rule_content IS '数据规则信息';
COMMENT ON COLUMN model_view_permission.member_rule_content IS '成员规则信息';
COMMENT ON COLUMN model_view_permission.status IS '规则状态';


