
CREATE TABLE custom_class_setting
(
    id            BIGINT                      NOT NULL,
    account_id    VARCHAR(32)                 NULL,
    is_del        SMALLINT DEFAULT 0          NOT NULL,
    revision      SMALLINT DEFAULT 0          NOT NULL,
    creator       VARCHAR(255)                NOT NULL,
    "operator"      VARCHAR(255)                NOT NULL,
    updated_time  TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    created_time  TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    instance_id      VARCHAR(255)                NOT NULL,
    describtion       VARCHAR(255)            NULL,
    app_key       VARCHAR(255)                NOT NULL,
    CONSTRAINT custom_class_setting_pkey PRIMARY KEY (id)
);


COMMENT ON TABLE custom_class_setting IS '自定义类设置信息表';
COMMENT ON COLUMN custom_class_setting.id IS '主键ID';
COMMENT ON COLUMN custom_class_setting.account_id IS '租户ID';
COMMENT ON COLUMN custom_class_setting.is_del IS '是否删除 0存在 、1删除';
COMMENT ON COLUMN custom_class_setting.revision IS '乐观锁';
COMMENT ON COLUMN custom_class_setting.creator IS '创建人';
COMMENT ON COLUMN custom_class_setting.operator IS '操作人';
COMMENT ON COLUMN custom_class_setting.updated_time IS '更新时间';
COMMENT ON COLUMN custom_class_setting.created_time IS '创建时间';
COMMENT ON COLUMN custom_class_setting.instance_id  IS '实例唯一标识';
COMMENT ON COLUMN custom_class_setting.describtion IS '描述';
COMMENT ON COLUMN custom_class_setting.app_key IS '应用key';


create unique index index_instance_id on custom_class_setting (instance_id);
