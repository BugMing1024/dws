-- 数据字典详情表增加字段
ALTER TABLE data_dict_detail
    ADD parents VARCHAR,
    ADD status INTEGER NOT NULL DEFAULT 1,
    ADD priority INTEGER,
    ADD leaf INTEGER NOT NULL DEFAULT 1,
    ADD pre_id VARCHAR,
    ADD next_id VARCHAR;
COMMENT ON COLUMN data_dict_detail.parents IS '先辈id';
COMMENT ON COLUMN data_dict_detail.status IS '状态:0停用1启用';
COMMENT ON COLUMN data_dict_detail.priority IS '排序优先级';
COMMENT ON COLUMN data_dict_detail.leaf IS '叶子节点:0 false，1 true';
COMMENT ON COLUMN data_dict_detail.pre_id IS '前一项';
COMMENT ON COLUMN data_dict_detail.next_id IS '后一项';

-- 数据字典表更新历史数据填充parents字段
update data_dict_detail d set parents = v.parents
    from (with recursive dic as
         (
           select
             id, parent_id, level, ',0,' as parents
           from data_dict_detail where parent_id = '0'
           union all
           select
             origin.id, origin.parent_id, origin.level,
             dic.parents || origin.parent_id || ','
           from dic
               join data_dict_detail as origin on origin.parent_id = dic.id
         )
     select id,parents from dic
) v where d.id = v.id;

-- 数据字典表更新历史数据填充priority字段
update data_dict_detail d set priority = n.num
    from
	(
    select
		row_number() over(partition by c.dict_id order by c.level,p.created_time,p.id ,c.can_change desc,c.created_time ) as num,
		c.id
	from data_dict_detail c left join data_dict_detail p on c.parent_id = p.id
	) n
where
    d.id = n.id;

-- 数据字典表更新历史数据填充next_id字段
update data_dict_detail d set next_id = n.next_id
    from
    (
    select d1.id,d1.priority,d2.id next_id,d2.priority next_p,d1.dict_id from  data_dict_detail d1 left join data_dict_detail d2
        on d2.dict_id = d1.dict_id
        and d1.parent_id = d2.parent_id  and d2.priority = d1.priority + 1
    ) n
where
    d.id = n.id;

-- 数据字典表更新历史数据填充pre_id字段
update data_dict_detail d set pre_id = n.pre_id
    from
    (
    select d1.id,d2.id pre_id,d2.priority pre,d1.priority from  data_dict_detail d1 left join data_dict_detail d2
        on d2.dict_id = d1.dict_id
        and d1.parent_id = d2.parent_id  and d2.next_id = d1.id
    ) n
where
    d.id = n.id;

-- 数据字典表更新历史数据填充leaf字段
update data_dict_detail d
set leaf = n.leaf from
            (
            select id ,case when exists (select id from data_dict_detail where parent_id = l.id and is_del = 0 limit 1) then 0 else 1 end as
            leaf
            from data_dict_detail l
            ) n
where
    d.id = n.id;

-- 数据字典表更新历史数据填充can_change字段
update data_dict_detail d set can_change = 0 where can_change is null;