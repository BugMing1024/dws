-- 系统模板
CREATE TABLE dosm_api_manage_template (
    id varchar(32) NOT NULL, -- 主键ID
    api_name varchar(255) NOT NULL, -- 模板名称
    request_mode varchar(255) NULL, -- 请求方式
    url_path text NULL, -- 请求路径
    body text NULL, -- 请求body
    query text NULL, -- 请求query
    headers text NULL, -- 请求头
    result_body text NULL, -- 返回结果
    account_id varchar(32) NOT NULL, -- 租户ID
    created_by varchar(32) NOT NULL, -- 创建人ID
    created_time timestamp NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_by varchar(32) NOT NULL, -- 修改人ID
    updated_time timestamp NULL DEFAULT CURRENT_TIMESTAMP, -- 修改时间
    revision int4 NOT NULL DEFAULT 0, -- 乐观锁
    is_del int4 NOT NULL DEFAULT 0, -- 0有效1删除
    top_account_id varchar(32) NULL, -- 顶级租户ID
    status int2 NULL, -- 接口状态,0-启用,1-禁用
    template_type varchar(32) NULL, -- 类型
    CONSTRAINT dosm_api_manage_template_pk PRIMARY KEY (id)
);
COMMENT ON TABLE dosm_api_manage_template IS 'api模板管理';

-- Column comments

COMMENT ON COLUMN dosm_api_manage_template.id IS '主键ID';
COMMENT ON COLUMN dosm_api_manage_template.api_name IS '模板名称';
COMMENT ON COLUMN dosm_api_manage_template.request_mode IS '请求方式';
COMMENT ON COLUMN dosm_api_manage_template.url_path IS '请求路径';
COMMENT ON COLUMN dosm_api_manage_template.body IS '请求body';
COMMENT ON COLUMN dosm_api_manage_template.query IS '请求query';
COMMENT ON COLUMN dosm_api_manage_template.headers IS '请求头';
COMMENT ON COLUMN dosm_api_manage_template.result_body IS '返回结果';
COMMENT ON COLUMN dosm_api_manage_template.account_id IS '租户ID';
COMMENT ON COLUMN dosm_api_manage_template.created_by IS '创建人ID';
COMMENT ON COLUMN dosm_api_manage_template.created_time IS '创建时间';
COMMENT ON COLUMN dosm_api_manage_template.updated_by IS '修改人ID';
COMMENT ON COLUMN dosm_api_manage_template.updated_time IS '修改时间';
COMMENT ON COLUMN dosm_api_manage_template.revision IS '乐观锁';
COMMENT ON COLUMN dosm_api_manage_template.is_del IS '0有效1删除';
COMMENT ON COLUMN dosm_api_manage_template.top_account_id IS '顶级租户ID';
COMMENT ON COLUMN dosm_api_manage_template.template_type IS '类型';


INSERT INTO dosm_api_manage_template
(id, api_name, request_mode, url_path, body, query, headers, result_body, account_id, created_by, created_time, updated_by, updated_time, revision, is_del, top_account_id, template_type)
VALUES('0', '获取问题详情', 'GET', '/rest/api/2/issue/DOSM-6', '{"bodyType":"json","params":[{"paramName":"root","type":"object","must":false,"id":"root"}]}', NULL, NULL, '{"paramName":"root","type":"object","children":[],"must":false,"id":"15d1da72367c4f4299349fddcba78d75"}', '110', '3', '2022-12-06 17:37:59.392', '3', '2022-12-09 15:13:57.692', 0, 0, '110', 'JIRA');

-- 系统分类增加字段
ALTER TABLE dosm_api_group ADD server_path varchar(128) NULL;
COMMENT ON COLUMN dosm_api_group.server_path IS '服务地址';

ALTER TABLE dosm_api_group ADD api_template_id varchar(32) NULL;
COMMENT ON COLUMN dosm_api_group.api_template_id IS 'api模板id';

ALTER TABLE dosm_api_group ADD authentication_id varchar(32) NULL;
COMMENT ON COLUMN dosm_api_group.authentication_id IS '鉴权id';

-- api管理增加地址栏参数
ALTER TABLE dosm_api_manage ADD url_params text NULL;
COMMENT ON COLUMN dosm_api_manage.url_params IS '地址栏参数';


-- Drop table

-- DROP TABLE dosm_authentication_config;

CREATE TABLE dosm_authentication_config (
       id varchar(32) NOT NULL, -- 主键id
       authentication_name varchar(255) NOT NULL, -- 鉴权名称
       authentication_type varchar(255) NOT NULL, -- 鉴权方式
       account_id varchar(32) NOT NULL, -- 租户ID
       created_by varchar(32) NOT NULL, -- 创建人ID
       created_time timestamp NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
       updated_by varchar(32) NOT NULL, -- 修改人ID
       updated_time timestamp NULL DEFAULT CURRENT_TIMESTAMP, -- 修改时间
       revision int4 NOT NULL DEFAULT 0, -- 乐观锁
       is_del int4 NOT NULL DEFAULT 0, -- 0有效1删除
       top_account_id varchar(32) NULL, -- 顶级租户ID
       status int2 NULL, -- 接口状态,0-启用,1-禁用
       authentication_config text NULL, -- 鉴权配置
       authentication_instance text NULL, -- 鉴权配置实例
       token_result text NULL, -- token返回结果
       expire_time timestamp NULL, -- 到期时间
       refresh_token_exec_times int4 NULL, -- 刷新token执行次数，默认3次
       detail_exception text NULL, -- 执行异常信息
       CONSTRAINT dosm_authentication_config_pk PRIMARY KEY (id)
);

-- Column comments

COMMENT ON COLUMN dosm_authentication_config.id IS '主键id';
COMMENT ON COLUMN dosm_authentication_config.authentication_name IS '鉴权名称';
COMMENT ON COLUMN dosm_authentication_config.authentication_type IS '鉴权方式';
COMMENT ON COLUMN dosm_authentication_config.account_id IS '租户ID';
COMMENT ON COLUMN dosm_authentication_config.created_by IS '创建人ID';
COMMENT ON COLUMN dosm_authentication_config.created_time IS '创建时间';
COMMENT ON COLUMN dosm_authentication_config.updated_by IS '修改人ID';
COMMENT ON COLUMN dosm_authentication_config.updated_time IS '修改时间';
COMMENT ON COLUMN dosm_authentication_config.revision IS '乐观锁';
COMMENT ON COLUMN dosm_authentication_config.is_del IS '0有效1删除';
COMMENT ON COLUMN dosm_authentication_config.top_account_id IS '顶级租户ID';
COMMENT ON COLUMN dosm_authentication_config.status IS '接口状态,0-启用,1-禁用';
COMMENT ON COLUMN dosm_authentication_config.authentication_config IS '鉴权配置';
COMMENT ON COLUMN dosm_authentication_config.authentication_instance IS '鉴权配置实例';
COMMENT ON COLUMN dosm_authentication_config.token_result IS 'token返回结果';
COMMENT ON COLUMN dosm_authentication_config.expire_time IS '到期时间';
COMMENT ON COLUMN dosm_authentication_config.refresh_token_exec_times IS '刷新token执行次数，默认3次';
COMMENT ON COLUMN dosm_authentication_config.detail_exception IS '执行异常信息';

