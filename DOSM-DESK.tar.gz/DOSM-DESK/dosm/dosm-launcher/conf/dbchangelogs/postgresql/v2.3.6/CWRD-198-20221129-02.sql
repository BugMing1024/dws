--多顶级租户改造 动态表单策略管理
ALTER TABLE model_ui_policies ADD "top_account_id" VARCHAR(32) NOT NULL default 110;
COMMENT ON COLUMN "model_ui_policies"."top_account_id" IS '顶级租户ID';



--多顶级租户改造 数据权限管理
ALTER TABLE model_data_permission ADD "top_account_id" VARCHAR(32) NOT NULL default 110;
COMMENT ON COLUMN "model_data_permission"."top_account_id" IS '顶级租户ID';




--多顶级租户改造 外部数据源管理
ALTER TABLE external_data_source ADD "top_account_id" VARCHAR(32) NOT NULL default 110;
COMMENT ON COLUMN "external_data_source"."top_account_id" IS '顶级租户ID';