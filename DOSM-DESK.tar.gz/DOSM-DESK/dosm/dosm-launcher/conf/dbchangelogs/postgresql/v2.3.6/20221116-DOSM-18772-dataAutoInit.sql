CREATE TABLE dosm_init_data_record (
                                                  id varchar(32)  NOT NULL,
                                                  is_del int2 NOT NULL DEFAULT 0,
                                                  account_id varchar(32) ,
                                                  top_account_id varchar(32)  DEFAULT 110,
                                                  revision int2 DEFAULT 0,
                                                  created_by varchar(255) ,
                                                  created_time timestamp(0) DEFAULT CURRENT_TIMESTAMP,
                                                  updated_by varchar(32) ,
                                                  updated_time timestamp(0) DEFAULT CURRENT_TIMESTAMP,
                                                  file_name varchar(255)  NOT NULL,
                                                  init_status int2 NOT NULL,
                                                  init_result varchar(512) ,
                                                  CONSTRAINT dosm_init_data_record_pkey PRIMARY KEY (id)
)
;

 

COMMENT ON COLUMN  dosm_init_data_record.file_name IS '文件路径 ';

COMMENT ON COLUMN dosm_init_data_record.init_status IS '初始化状态0 或者不存在 未执行    1 执行成功   2执行失败';

COMMENT ON COLUMN dosm_init_data_record.init_result IS '初始化结果日志';

COMMENT ON TABLE dosm_init_data_record IS '数据初始化记录';