CREATE TABLE "dosm_notify_link_announcement" (
                                                 "id" varchar(32)  NOT NULL,
                                                 "account_id" varchar(32) ,
                                                 "top_account_id" varchar(32) ,
                                                 "is_del" int4,
                                                 "created_time" timestamp(6),
                                                 "created_by" varchar(32) ,
                                                 "updated_time" timestamp(6),
                                                 "updated_by" varchar(32) ,
                                                 "revision" int4 DEFAULT 0,
                                                 "announcement_first_id" varchar(32) ,
                                                 "announcement_second_id" varchar(32) ,
                                                 CONSTRAINT "dosm_link_announcement_pkey" PRIMARY KEY ("id")
)
;

COMMENT ON COLUMN "dosm_notify_link_announcement"."id" IS '关联主键';

COMMENT ON COLUMN "dosm_notify_link_announcement"."account_id" IS '子租户';

COMMENT ON COLUMN "dosm_notify_link_announcement"."top_account_id" IS '顶级租户';

COMMENT ON COLUMN "dosm_notify_link_announcement"."is_del" IS '是否删除 0 未删除 1 已删除';

COMMENT ON COLUMN "dosm_notify_link_announcement"."created_time" IS '创建时间';

COMMENT ON COLUMN "dosm_notify_link_announcement"."created_by" IS '创建人';

COMMENT ON COLUMN "dosm_notify_link_announcement"."updated_time" IS '更新时间';

COMMENT ON COLUMN "dosm_notify_link_announcement"."updated_by" IS '更新人';

COMMENT ON COLUMN "dosm_notify_link_announcement"."revision" IS '非空，乐观锁 默认为0';

COMMENT ON TABLE "dosm_notify_link_announcement" IS '公告关联关系表';

ALTER TABLE "dosm_notify_announcement_record"
    ADD COLUMN "announcement_type" varchar(32) ,
    ADD COLUMN "publish_dept_id" varchar(32) ;

COMMENT ON COLUMN "dosm_notify_announcement_record"."announcement_type" IS '公告类别';

COMMENT ON COLUMN "dosm_notify_announcement_record"."publish_dept_id" IS '部门id';