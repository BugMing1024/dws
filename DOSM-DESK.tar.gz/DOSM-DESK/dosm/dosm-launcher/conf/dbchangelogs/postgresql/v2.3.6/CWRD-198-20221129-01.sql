--多顶级租户改造 数据表模型管理
ALTER TABLE model_definition ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110;
COMMENT ON COLUMN "model_definition"."top_account_id" IS '顶级租户ID';


ALTER TABLE model_field_definition ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "model_field_definition"."top_account_id" IS '顶级租户ID';

ALTER TABLE model_field_options_definition ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "model_field_options_definition"."top_account_id" IS '顶级租户ID';

ALTER TABLE web_field_list_rule ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "web_field_list_rule"."top_account_id" IS '顶级租户ID';

ALTER TABLE model_table_definition ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "model_table_definition"."top_account_id" IS '顶级租户ID';



--多顶级租户改造 表单视图管理
ALTER TABLE web_classify ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110;
COMMENT ON COLUMN "web_classify"."top_account_id" IS '顶级租户ID';


ALTER TABLE web_definition ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "web_definition"."top_account_id" IS '顶级租户ID';


ALTER TABLE table_view_relation ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "table_view_relation"."top_account_id" IS '顶级租户ID';


ALTER TABLE model_view_permission ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "model_view_permission"."top_account_id" IS '顶级租户ID';

ALTER TABLE view_field_component_relation ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "view_field_component_relation"."top_account_id" IS '顶级租户ID';




--多顶级租户改造 应用管理

ALTER TABLE app_instance ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110;
COMMENT ON COLUMN "app_instance"."top_account_id" IS '顶级租户ID';

ALTER TABLE app_menu ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "app_menu"."top_account_id" IS '顶级租户ID';


ALTER TABLE custom_class_setting ADD "top_account_id" VARCHAR(32) NOT NULL DEFAULT 110 ;
COMMENT ON COLUMN "custom_class_setting"."top_account_id" IS '顶级租户ID';

