-- node conf 添加节点类型索引
CREATE INDEX idx_bpm_process_node_conf_node_type ON bpm_process_node_conf (act_node_type);
