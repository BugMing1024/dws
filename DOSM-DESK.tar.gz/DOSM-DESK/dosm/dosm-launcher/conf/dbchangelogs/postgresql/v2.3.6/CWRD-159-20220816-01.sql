CREATE TABLE model_ui_policies
(
    id            BIGINT                      NOT NULL,
    account_id    VARCHAR(32)                 NOT NULL,
    is_del        SMALLINT DEFAULT 0          NOT NULL,
    revision      SMALLINT DEFAULT 0          NOT NULL,
    creator       VARCHAR(255)                NOT NULL,
    operator      VARCHAR(255)                NOT NULL,
    updated_time  TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    created_time  TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    table_id      VARCHAR(255)                NOT NULL,
    table_name    VARCHAR(255)                NOT NULL,
    rule_order    integer  default NULL,
    rule_desc     VARCHAR(255)                NOT NULL,
    scope_type    VARCHAR(255)                NOT NULL,
    scope_content json     DEFAULT NULL,
    event_type    json                        NOT NULL,
    app_key       VARCHAR(255)                NOT NULL,
    rule_content  json                        NOT NULL,
    CONSTRAINT model_ui_policies_pkey PRIMARY KEY (id)
);
COMMENT ON TABLE model_ui_policies IS '表单策略ui-policies';
COMMENT ON COLUMN model_ui_policies.id IS '主键ID';
COMMENT ON COLUMN model_ui_policies.account_id IS '租户ID';
COMMENT ON COLUMN model_ui_policies.is_del IS '是否删除 0存在 、1删除';
COMMENT ON COLUMN model_ui_policies.revision IS '乐观锁';
COMMENT ON COLUMN model_ui_policies.creator IS '创建人';
COMMENT ON COLUMN model_ui_policies.operator IS '操作人';
COMMENT ON COLUMN model_ui_policies.updated_time IS '更新时间';
COMMENT ON COLUMN model_ui_policies.created_time IS '创建时间';
COMMENT ON COLUMN model_ui_policies.table_id IS '数据表id';
COMMENT ON COLUMN model_ui_policies.table_name IS '数据表名称';
COMMENT ON COLUMN model_ui_policies.rule_order IS '执行顺序';
COMMENT ON COLUMN model_ui_policies.rule_desc IS '策略描述';
COMMENT ON COLUMN model_ui_policies.scope_type IS '生效范围，ALL:全局，PART:部分';
COMMENT ON COLUMN model_ui_policies.scope_content IS '视图，null：全局,部分：[viewId]';
COMMENT ON COLUMN model_ui_policies.event_type IS '生效时机,LOADING:表单加载，ONCHANGE：字段更改';
COMMENT ON COLUMN model_ui_policies.rule_content IS '规则内容';
COMMENT ON COLUMN model_ui_policies.app_key IS '应用key';
