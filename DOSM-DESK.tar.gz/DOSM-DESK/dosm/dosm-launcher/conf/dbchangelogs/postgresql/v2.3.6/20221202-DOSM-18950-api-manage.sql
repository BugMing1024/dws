-- Drop table

-- DROP TABLE dosm_api_manage;

CREATE TABLE dosm_api_manage (
    id varchar(32) NOT NULL, -- 主键ID
    api_name varchar(255) NOT NULL, -- api名称
    request_mode varchar(255) NULL, -- 请求方式
    url_path text NULL, -- 请求路径
    body text NULL, -- 请求body
    query text NULL, -- 请求query
    headers text NULL, -- 请求头
    result_body text NULL, -- 返回结果
    api_group_id varchar(32) NULL, -- api分组id
    account_id varchar(32) NOT NULL, -- 租户ID
    created_by varchar(32) NOT NULL, -- 创建人ID
    created_time timestamp NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_by varchar(32) NOT NULL, -- 修改人ID
    updated_time timestamp NULL DEFAULT CURRENT_TIMESTAMP, -- 修改时间
    revision int4 NOT NULL DEFAULT 0, -- 乐观锁
    is_del int4 NOT NULL DEFAULT 0, -- 0有效1删除
    top_account_id varchar(32) NULL, -- 顶级租户ID
    status int2 NULL, -- 接口状态,0-启用,1-禁用
    CONSTRAINT dosm_api_manage_pk PRIMARY KEY (id)
);
COMMENT ON TABLE dosm_api_manage IS 'api管理';

-- Column comments

COMMENT ON COLUMN dosm_api_manage.id IS '主键ID';
COMMENT ON COLUMN dosm_api_manage.api_name IS 'api名称';
COMMENT ON COLUMN dosm_api_manage.request_mode IS '请求方式';
COMMENT ON COLUMN dosm_api_manage.url_path IS '请求路径';
COMMENT ON COLUMN dosm_api_manage.body IS '请求body';
COMMENT ON COLUMN dosm_api_manage.query IS '请求query';
COMMENT ON COLUMN dosm_api_manage.headers IS '请求头';
COMMENT ON COLUMN dosm_api_manage.result_body IS '返回结果';
COMMENT ON COLUMN dosm_api_manage.api_group_id IS 'api分组id';
COMMENT ON COLUMN dosm_api_manage.account_id IS '租户ID';
COMMENT ON COLUMN dosm_api_manage.created_by IS '创建人ID';
COMMENT ON COLUMN dosm_api_manage.created_time IS '创建时间';
COMMENT ON COLUMN dosm_api_manage.updated_by IS '修改人ID';
COMMENT ON COLUMN dosm_api_manage.updated_time IS '修改时间';
COMMENT ON COLUMN dosm_api_manage.revision IS '乐观锁';
COMMENT ON COLUMN dosm_api_manage.is_del IS '0有效1删除';
COMMENT ON COLUMN dosm_api_manage.top_account_id IS '顶级租户ID';
COMMENT ON COLUMN dosm_api_manage.status IS '接口状态,0-启用,1-禁用';


-- Drop table

-- DROP TABLE dosm_api_group;

CREATE TABLE dosm_api_group (
   id varchar(50) NOT NULL, -- 主键ID
   account_id varchar(32) NOT NULL, -- 租户ID
   created_time timestamp(6) NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
   updated_time timestamp(6) NULL DEFAULT CURRENT_TIMESTAMP, -- 修改时间
   created_by varchar(32) NULL DEFAULT NULL::character varying, -- 创建人ID
   updated_by varchar(32) NULL DEFAULT NULL::character varying, -- 修改人ID
   is_del int4 NULL DEFAULT 0, -- 0有效1删除
   top_account_id varchar(32) NULL, -- 顶级租户ID
   "name" varchar(128) NOT NULL, -- 名称
   remark text NULL, -- 描述
   parent_id varchar(50) NOT NULL DEFAULT 0, -- 父级ID
   state int4 NOT NULL DEFAULT 1, -- 0内置 1新增
   revision int4 NULL DEFAULT 0, -- 乐观锁
   CONSTRAINT dosm_api_group_pk PRIMARY KEY (id)
);
COMMENT ON TABLE dosm_api_group IS 'Api系统分类表';

-- Column comments

COMMENT ON COLUMN dosm_api_group.id IS '主键ID';
COMMENT ON COLUMN dosm_api_group.account_id IS '租户ID';
COMMENT ON COLUMN dosm_api_group.created_time IS '创建时间';
COMMENT ON COLUMN dosm_api_group.updated_time IS '修改时间';
COMMENT ON COLUMN dosm_api_group.created_by IS '创建人ID';
COMMENT ON COLUMN dosm_api_group.updated_by IS '修改人ID';
COMMENT ON COLUMN dosm_api_group.is_del IS '0有效1删除';
COMMENT ON COLUMN dosm_api_group.top_account_id IS '顶级租户ID';
COMMENT ON COLUMN dosm_api_group."name" IS '名称';
COMMENT ON COLUMN dosm_api_group.remark IS '描述';
COMMENT ON COLUMN dosm_api_group.parent_id IS '父级ID';
COMMENT ON COLUMN dosm_api_group.state IS '0内置 1新增';
COMMENT ON COLUMN dosm_api_group.revision IS '乐观锁';

INSERT INTO dosm_api_group
(id, account_id, created_time, updated_time, created_by, updated_by, is_del, top_account_id, "name", remark, parent_id, state, revision)
VALUES('83dc2fe9388d401fa194317a00126718', '110', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '3', '3', 0, '110', '服务管理中心', '服务管理中心', '0', 0, 0);