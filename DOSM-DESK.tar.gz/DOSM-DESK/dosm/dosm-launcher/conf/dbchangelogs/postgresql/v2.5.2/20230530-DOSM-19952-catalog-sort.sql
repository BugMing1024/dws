ALTER TABLE "dosm_catalog_model_auth"
    ADD COLUMN "sort" integer;

COMMENT ON COLUMN "dosm_catalog_model_auth"."sort" IS '顺序';