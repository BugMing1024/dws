alter table public.dosm_custom_change_view
    add one_degree_topology_range jsonb;

comment on column public.dosm_custom_change_view.one_degree_topology_range is '一度拓扑关联配置项字段查询范围';