-- public.dosm_tab_data_table definition

-- Drop table

-- DROP TABLE dosm_tab_data_table;

CREATE TABLE dosm_tab_data_table (
                                     id varchar(32) NOT NULL,
                                     work_order_id varchar(32) NOT NULL, -- 工单id
                                     tab_config_id varchar(32) NOT NULL, -- 页签id
                                     is_del int4 NOT NULL DEFAULT 0, -- 0有效1删除
                                     created_by varchar(32) NULL, -- 创建人ID
                                     created_time timestamp(6) NULL, -- 创建时间
                                     updated_by varchar(32) NULL, -- 修改人
                                     updated_time timestamp(6) NULL, -- 修改时间
                                     revision int4 NULL DEFAULT 0, -- 乐观锁
                                     top_account_id varchar(32) NULL, -- 顶级租户ID
                                     account_id varchar(32) NOT NULL, -- 租户id
                                     data_table_record text NULL, -- 数据表记录
                                     CONSTRAINT dosm_tab_data_table_pk PRIMARY KEY (id)
);
COMMENT ON TABLE dosm_tab_data_table IS '页签关联数据表';

-- Column comments

COMMENT ON COLUMN dosm_tab_data_table.work_order_id IS '工单id';
COMMENT ON COLUMN dosm_tab_data_table.tab_config_id IS '页签id';
COMMENT ON COLUMN dosm_tab_data_table.is_del IS '0有效1删除';
COMMENT ON COLUMN dosm_tab_data_table.created_by IS '创建人ID';
COMMENT ON COLUMN dosm_tab_data_table.created_time IS '创建时间';
COMMENT ON COLUMN dosm_tab_data_table.updated_by IS '修改人';
COMMENT ON COLUMN dosm_tab_data_table.updated_time IS '修改时间';
COMMENT ON COLUMN dosm_tab_data_table.revision IS '乐观锁';
COMMENT ON COLUMN dosm_tab_data_table.top_account_id IS '顶级租户ID';
COMMENT ON COLUMN dosm_tab_data_table.account_id IS '租户id';
COMMENT ON COLUMN dosm_tab_data_table.data_table_record IS '数据表记录';