--模型范围
alter table mdl_tab_config add column cmdb_model jsonb;

--流程ID
alter table mdl_tab_config add column proc_id varchar(64);

--节点权限设置
alter table mdl_tab_config add column node_config jsonb;

--页签说明
alter table mdl_tab_config add column des varchar(256);

COMMENT ON COLUMN mdl_tab_config.cmdb_model IS '模型范围';
COMMENT ON COLUMN mdl_tab_config.proc_id IS '页签id';
COMMENT ON COLUMN mdl_tab_config.node_config IS '节点权限设置';
COMMENT ON COLUMN mdl_tab_config.des IS '配置项页签描述';

--配置项
create table mdl_tab_data
(
    id             varchar(32)       not null primary key,
    tab_id         varchar(32)       not null,
    model_id       varchar(32)       not null,
    ci_id          varchar(32)      ,
    work_order_id  varchar(32)       not null,
    fields         jsonb,
    fields_form    jsonb,
    is_del         integer default 0 not null,
    created_by     varchar(32)       not null,
    created_time   timestamp(6)      not null,
    updated_by     varchar(32)       not null,
    updated_time   timestamp(6)      not null,
    revision       integer default 0 not null,
    account_id     varchar(32)       not null,
    top_account_id varchar(32)       not null
);
COMMENT ON TABLE mdl_tab_data IS '配置项页签数据表';
COMMENT ON COLUMN mdl_tab_data.id IS '主键id';
COMMENT ON COLUMN mdl_tab_data.tab_id IS '页签id';
COMMENT ON COLUMN mdl_tab_data.model_id IS '模型id';
COMMENT ON COLUMN mdl_tab_data.ci_id IS '配置项id';
COMMENT ON COLUMN mdl_tab_data.work_order_id IS '当前工单id';
COMMENT ON COLUMN mdl_tab_data.fields IS '配置项数据';
COMMENT ON COLUMN mdl_tab_data.fields_form IS '属性信息';
COMMENT ON COLUMN mdl_tab_data.revision IS '乐观锁';
COMMENT ON COLUMN mdl_tab_data.created_by IS '创建人';
COMMENT ON COLUMN mdl_tab_data.created_time IS '创建时间';
COMMENT ON COLUMN mdl_tab_data.updated_by IS '更新人';
COMMENT ON COLUMN mdl_tab_data.updated_time IS '更新时间';
COMMENT ON COLUMN mdl_tab_data.is_del IS '0有效1删除';

create index mdl_tab_data_tab_id_model_id on mdl_tab_data (tab_id, model_id);

create index mdl_tab_data_tab_id on mdl_tab_data (tab_id);