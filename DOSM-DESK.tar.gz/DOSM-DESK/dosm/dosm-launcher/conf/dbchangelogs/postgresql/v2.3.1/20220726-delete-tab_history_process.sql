--流程进度页签 删除工单配置
delete from  mdl_instance_tag where tag_id in(select id  from mdl_tab_config  where  tab_name ='流程进度');
--流程进度页签删除
delete from mdl_tab_config  where  tab_name ='流程进度';
--流程进度内容数据删除
DROP TABLE IF EXISTS mdl_tab_flow_progress;