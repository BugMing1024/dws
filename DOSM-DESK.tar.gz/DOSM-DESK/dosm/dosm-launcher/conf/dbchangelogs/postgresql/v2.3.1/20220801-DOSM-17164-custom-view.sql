ALTER TABLE dosm_custom_view ADD query_conditions jsonb NULL;
COMMENT ON COLUMN dosm_custom_view.query_conditions IS '条件设定数据';
ALTER TABLE dosm_custom_view ADD filtrate_properties jsonb NULL;
COMMENT ON COLUMN dosm_custom_view.filtrate_properties IS '筛选器默认数据';
ALTER TABLE dosm_custom_view ADD view_properties jsonb NULL;
COMMENT ON COLUMN dosm_custom_view.view_properties IS '展示列默认数据';
ALTER TABLE dosm_custom_view ADD is_all_process smallint NULL;
COMMENT ON COLUMN dosm_custom_view.is_all_process IS '是否全部流程 0 否 1 是';
