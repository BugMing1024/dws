--高级设置相关表增加复制次数字段 依次是：动态表单表，流程自动化表，权限管理表，API管理表
ALTER TABLE mdl_adv_dynamic_rule
    ADD copy_times int8 DEFAULT 0;
ALTER TABLE bpm_adv_event
    ADD copy_times int8 DEFAULT 0;
ALTER TABLE bpm_adv_permission
    ADD copy_times int8 DEFAULT 0;
ALTER TABLE bpm_adv_api_manage
    ADD copy_times int8 DEFAULT 0;

-- Column comments

COMMENT ON COLUMN mdl_adv_dynamic_rule.copy_times IS '复制次数';
COMMENT ON COLUMN bpm_adv_event.copy_times IS '复制次数';
COMMENT ON COLUMN bpm_adv_permission.copy_times IS '复制次数';
COMMENT ON COLUMN bpm_adv_api_manage.copy_times IS '复制次数';