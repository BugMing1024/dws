alter table mdl_tab_data add operate_sources varchar(32);
comment on column mdl_tab_data.operate_sources is '数据来源';