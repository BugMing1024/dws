ALTER TABLE "model_field_definition"  ADD COLUMN "is_multi_select" int2;
COMMENT ON COLUMN "model_field_definition"."is_multi_select" IS '是否多选';
ALTER TABLE "model_table_definition"  ADD COLUMN "is_virtual_table" int2 NOT NULL DEFAULT 0;

CREATE TABLE "external_data_source" (
  "id" int8 NOT NULL,
  "account_id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "target_table_id" int8,
  "is_pull" int2 NOT NULL DEFAULT 0,
  "describe" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "version" int4 NOT NULL DEFAULT 0,
  "is_del" int2 NOT NULL DEFAULT 0,
  "revision" int2 NOT NULL DEFAULT 0,
  "creator" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "operator" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "updated_time" timestamp(6) NOT NULL,
  "created_time" timestamp(6) NOT NULL,
  CONSTRAINT "external_data_source_pkey" PRIMARY KEY ("id")
);
ALTER TABLE "external_data_source" ADD COLUMN "app_key" varchar(64) COLLATE "pg_catalog"."default" NOT NULL;
COMMENT ON COLUMN "external_data_source"."app_key" IS '应用key';
ALTER TABLE "external_data_source"  ADD COLUMN "action_chain_code" int4;
COMMENT ON COLUMN "external_data_source"."action_chain_code" IS '临时的actionChainCode';

COMMENT ON COLUMN "external_data_source"."id" IS '主键ID';
COMMENT ON COLUMN "external_data_source"."account_id" IS '租户ID';
COMMENT ON COLUMN "external_data_source"."name" IS '名称';
COMMENT ON COLUMN "external_data_source"."target_table_id" IS '目标表ID';
COMMENT ON COLUMN "external_data_source"."is_pull" IS '是否拉取';
COMMENT ON COLUMN "external_data_source"."describe" IS '描述';
COMMENT ON COLUMN "external_data_source"."is_del" IS '是否删除 0存在 、1删除';
COMMENT ON COLUMN "external_data_source"."revision" IS '乐观锁';
COMMENT ON COLUMN "external_data_source"."creator" IS '创建人';
COMMENT ON COLUMN "external_data_source"."operator" IS '操作人';
COMMENT ON COLUMN "external_data_source"."updated_time" IS '更新时间';
COMMENT ON COLUMN "external_data_source"."created_time" IS '创建时间';