--数据表页签设置增加字段
alter table mdl_tab_config add column data_form_model jsonb;
alter table mdl_tab_config add column data_form_node_config jsonb;
COMMENT ON COLUMN mdl_tab_config.data_form_model IS '数据表模型范围';
COMMENT ON COLUMN mdl_tab_config.data_form_node_config IS '数据表节点权限设置';