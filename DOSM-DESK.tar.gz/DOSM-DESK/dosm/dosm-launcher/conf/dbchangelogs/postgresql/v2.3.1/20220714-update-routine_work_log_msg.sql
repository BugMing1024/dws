--例行工作执行日志国际化
ALTER TABLE dosm_xxl_job_log add handle_msg_zh text;
COMMENT ON COLUMN public.dosm_xxl_job_log.handle_msg_zh IS '例行工作执行异常信息-中文';

ALTER TABLE dosm_xxl_job_log add handle_msg_en text;
COMMENT ON COLUMN public.dosm_xxl_job_log.handle_msg_en IS '例行工作执行异常信息-英文';

update dosm_xxl_job_log set handle_msg_zh = handle_msg;
update dosm_xxl_job_log set handle_msg_en = handle_msg;

update dosm_xxl_job_log set handle_msg_en = 'Failed to create the routine. Routine will not be performed outside the service time range' where handle_msg_en = '创建例行工作失败！超出服务时间范围，例行工作不执行';
update dosm_xxl_job_log set handle_msg_en = 'Failed to create the routine. The ticket condition set is wrong, and the verification failed, please check' where handle_msg_en = '创建例行工作失败！工单条件设置错误，校验失败，请检查';
update dosm_xxl_job_log set handle_msg_en = REPLACE (handle_msg_en, '创建例行工作失败！', 'Failed to create the routine. ' );

ALTER TABLE dosm_xxl_job_log DROP COLUMN IF EXISTS handle_msg;