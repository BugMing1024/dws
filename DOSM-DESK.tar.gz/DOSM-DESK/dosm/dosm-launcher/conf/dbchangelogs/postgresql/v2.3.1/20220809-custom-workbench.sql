CREATE TABLE dosm_custom_component (
     id varchar(32) NOT NULL,
     component_name varchar(32) NOT NULL,
     component_type varchar(32) NOT NULL,
     component_type_inside varchar(32) NULL,
     component_content jsonb NULL,
     component_library_flag INT2 NOT NULL DEFAULT 1,
     sort int4 NOT NULL DEFAULT 8,
     status int4 NOT NULL DEFAULT 0,
     revision int2 NOT NULL DEFAULT 0,
     created_by varchar(32) NOT NULL,
     created_time timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
     updated_by varchar(32) NOT NULL,
     updated_time timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
     is_del int2 NOT NULL DEFAULT 0,
     account_id varchar(32) NULL,
     top_account_id varchar(32) NULL,
     CONSTRAINT dosm_custom_component_pk PRIMARY KEY (id)
);
COMMENT ON TABLE dosm_custom_component IS '自定义组件表';

-- Column comments

COMMENT ON COLUMN dosm_custom_component.id IS '主键id';
COMMENT ON COLUMN dosm_custom_component.component_name IS '组件名称';
COMMENT ON COLUMN dosm_custom_component.component_type IS '组件类型 内置INSIDE 列表TABLE 图表CHART 文本TEXT 链接LINK 自定义CUSTOM';
COMMENT ON COLUMN dosm_custom_component.component_type_inside IS '内置组件类型 服务目录 CATALOG 工单消息 WORK_ORDER_NOTIFY 公告消息 ANNOUNCEMENT 我的值班 MY_DUTY 知识查询 KNOWLEDGE 工单统计 STATISTICS 服务台组件 SERVICE_DESK';
COMMENT ON COLUMN dosm_custom_component.component_content IS '组件描述';
COMMENT ON COLUMN dosm_custom_component.component_library_flag IS '组件库标识 1是 0否';
COMMENT ON COLUMN dosm_custom_component.sort IS '排序 升序';
COMMENT ON COLUMN dosm_custom_component.status IS '状态，是否启用 0-启用 1-停用';
COMMENT ON COLUMN dosm_custom_component.revision IS '乐观锁';
COMMENT ON COLUMN dosm_custom_component.created_time IS '创建时间';
COMMENT ON COLUMN dosm_custom_component.created_by IS '创建人';
COMMENT ON COLUMN dosm_custom_component.updated_time IS '更新时间';
COMMENT ON COLUMN dosm_custom_component.updated_by IS '更新人';
COMMENT ON COLUMN dosm_custom_component.is_del IS '是否删除 0-有效 1-删除';
COMMENT ON COLUMN dosm_custom_component.account_id IS '租户ID';
COMMENT ON COLUMN dosm_custom_component.top_account_id IS '顶级租户ID';



-- fill init data
insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('ded9f5de1f6b4347ac322997e2b73d27', '新建工单组件', 'INSIDE', 'CATALOG', '3', '3', '110', '110', 1);
insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('5efb4270d1684be1a50c4433ea496203', '工单消息组件', 'INSIDE', 'WORK_ORDER_NOTIFY', '3', '3', '110', '110', 2);
insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('46b14f7a8d764f89acdfcb02b3407287', '公告消息组件', 'INSIDE', 'ANNOUNCEMENT', '3', '3', '110', '110', 3);
insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('7297c7f5f3254f3fabd7d62a92104a06', '我的值班组件', 'INSIDE', 'MY_DUTY', '3', '3', '110', '110', 4);
insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('5840df838f654386b4e2f65aec5df6a8', '知识查询组件', 'INSIDE', 'KNOWLEDGE', '3', '3', '110', '110', 5);
insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('f143922e17cb46ec9653ec8124aa7317', '工单统计组件', 'INSIDE', 'STATISTICS', '3', '3', '110', '110', 6);
-- 服务台组件这期先不做
-- insert into dosm_custom_component(id, component_name, component_type, component_type_inside, created_by, updated_by, account_id, top_account_id, sort) values('aa8a2ddb05fb4796973d9e1f30134937', '服务台组件', 'INSIDE', 'SERVICE_DESK', '3', '3', '110', '110', 7);


CREATE TABLE "dosm_custom_dashboard_view" (
  "id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "account_id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "view_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "status" int4 NOT NULL DEFAULT 1,
  "created_by" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "created_time" timestamp(6) NOT NULL DEFAULT now(),
  "updated_by" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "updated_time" timestamp(6) NOT NULL DEFAULT now(),
  "revision" int2 NOT NULL DEFAULT 0,
  "is_del" int2 NOT NULL DEFAULT 0,
  "top_account_id" varchar(32) COLLATE "pg_catalog"."default",
  "view_type" varchar(32) COLLATE "pg_catalog"."default",
  "view_code" varchar(32) COLLATE "pg_catalog"."default",
  "is_global" int2 NOT NULL DEFAULT 1,
  "is_default" int2 NOT NULL DEFAULT 1,
  "component_position" jsonb,
  "view_preview" text COLLATE "pg_catalog"."default",
  PRIMARY KEY ("id")
)
;
COMMENT ON TABLE "dosm_custom_dashboard_view" IS '工作台自定义视图表';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."id" IS '工作台自定义视图ID';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."account_id" IS '自定义视图租户ID';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."user_id" IS '自定义视图用户ID';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."view_name" IS '自定义视图名称';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."status" IS '自定义视图状态。 0启用 1不启用';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."view_type" IS '自定义视图类型，WORK_BENCH工作台';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."view_code" IS '视图编码';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."is_global" IS '是否全局视图 0 是 1 不是';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."is_default" IS '是否默认视图 0 是 1 不是';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."component_position" IS '自定义视图-工作台-组件排版设定';
COMMENT ON COLUMN "dosm_custom_dashboard_view"."view_preview" IS '视图预览图';


-- auto-generated definition
create table dosm_custom_view_personal
(
    id                 varchar(32)                not null,
    updated_time       timestamp(6) default now() not null,
    component_position jsonb,
    user_id            varchar(32)                not null,
    account_id         varchar(32)                not null,
    top_account_id     varchar(32)                not null,
    constraint dosm_custom_view_personal_pk
        unique (id, user_id)
);

COMMENT ON TABLE dosm_custom_view_personal IS '个人工作台视图表';
comment on column dosm_custom_view_personal.id is '个人工作台视图ID';
comment on column dosm_custom_view_personal.updated_time is '个人视图更新时间';
comment on column dosm_custom_view_personal.component_position is '个人工作台视图排版';
comment on column dosm_custom_view_personal.user_id is '用户id';
comment on column dosm_custom_view_personal.account_id is '租户id';
comment on column dosm_custom_view_personal.top_account_id is '顶级租户id';