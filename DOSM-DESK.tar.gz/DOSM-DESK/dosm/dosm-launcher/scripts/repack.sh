#!/bin/bash
#----------------------------------------------------------------
#=== 将facewallService 中 liquibase、国际化配置、服务包 放入dosmLauncher 压缩包中
#----------------------------------------------------------------

# =================================== 变量配置 ===================================

GP_mainServerPath=${PROJECT_DIR}
GP_mainServerName=${SERVICE_NAME}
GP_mainServerPackageExt="tar.gz"
GP_submodulePath=${facewallServerPath}
GP_submoduleFileName=${facewallServerName}
GP_submoduleDBChangeDir="facewall"
GP_submoduleI18nPreName="facewall"
GP_submoduleExcludeJarName="facewall-launcher"
GP_submoduleConfExtDirs=""
GP_submoduleOtherExtDirs=""
GP_serviceDbTypeName="postgresql"

# repack.sh 参数对应；argNames 的 for 下标从 0 开始
argNames=("GP_submodulePath" "GP_submoduleFileName" "GP_submoduleDBChangeDir" "GP_submoduleI18nPreName" "GP_submoduleExcludeJarName" "GP_submoduleConfExtDirs" "GP_submoduleOtherExtDirs" "GP_mainServerPath" "GP_mainServerName" "GP_mainServerPackageExt" "GP_serviceDbTypeName")

for i in $(seq 1 $#); do
  argValue=${!i}
  argNameIndex=`expr $i - 1`
  if [[ -n "${argValue}" ]]; then
    eval ${argNames[$argNameIndex]}="${argValue}"
  fi
done

echo "----repack mainServer path: [${GP_mainServerPath}], name: [${GP_mainServerName}], packageExt: [${GP_mainServerPackageExt}], serviceDbTypeName: [${GP_serviceDbTypeName}]"
echo "----repack submodule path: [${GP_submodulePath}], name: [${GP_submoduleFileName}], dbChangeDir: [${GP_submoduleDBChangeDir}], i18nPreName: [${GP_submoduleI18nPreName}], excludeJarName: [${GP_submoduleExcludeJarName}]"




# =================================================================

# 删除服务临时文件
function rmServerTmpDir() {
  for dir in $*; do
    echo "删除临时文件： ${dir}"
    rm -rf ${dir}
  done
}

# 移动包到 lib 目录
function mergeServerLib() {
  TP_jarPath=$1
  TP_mainServerLibPath=$2
  TP_subServerPath=$3
  # 是否强制覆盖
  TP_forceCover=$4

  jarBaseName=$(basename $TP_jarPath)

  if [[ ${TP_forceCover} = true || ! -e ${TP_mainServerLibPath}/${jarBaseName} ]]; then
    echo "移动 ${jarBaseName}"
    # 兼容 SNAPSHOT 版本包,如：facewall-low-code-open-api-bean-3.0.0-SNAPSHOT.jar 去除后为 facewall-low-code-open-api-bean-3.0.0
    jarName=`echo ${jarBaseName%-SNAPSHOT*}`
    # 删除 facewall-low-code-open-api-bean-3.0.0-SNAPSHOT.jar 的同名同版本包【SNAPSHOT版本包打包后为facewall-low-code-open-api-bean-3.0.0-20230614.132446-30.jar】
    rm -rf ${TP_mainServerLibPath}/${jarName}*
    # 将 facewall-low-code-open-api-bean-3.0.0-SNAPSHOT.jar 放入 lib 中
    mv ${TP_subServerPath}/lib/${jarBaseName} ${TP_mainServerLibPath}/
  fi

}

function mvSubServerDir2MainServer() {
  subServer_dir=$1
  mainServer_dir=$2
  mainServer_deletePath=$3

  if [[ -d ${mainServer_dir} ]]; then
    rm -rf ${mainServer_deletePath}
  else
    mkdir -p ${mainServer_dir}
  fi

  echo "----- mv -f ${subServer_dir}/* ${mainServer_dir}/"
  mv -f ${subServer_dir}/* ${mainServer_dir}/
}


# 合并服务, 参数：[主服务路径，子服务路径，子服务liquibase目录，子服务i18n文件前缀，要排除模块(如："dosm-luancher|dosm-api")]
function mergeServer() {
  TP_mainServerPath=$1
  TP_subServerPath=$2
  TP_subServer_liquibase=$3
  TP_subServer_i18n=$4


  echo "---- mergeServer mainServerPath: ${TP_mainServerPath}, packageExt: ${GP_mainServerPackageExt}, subServerPath: ${TP_subServerPath}"

  TP_mainServerPath_conf="${TP_mainServerPath}/conf"
  TP_mainServerPath_lib="${TP_mainServerPath}/lib"
  if [[ "${GP_mainServerPackageExt}" = "war" ]]; then
    TP_mainServerPath_conf="${TP_mainServerPath}/WEB-INF/classes"
    TP_mainServerPath_lib="${TP_mainServerPath}/WEB-INF/lib"
  fi



  if [[ "${GP_mainServerPackageExt}" = "war" ]]; then
    TP_mainServerPath_conf="${TP_mainServerPath}/WEB-INF/classes/conf"
    mkdir -p ${TP_mainServerPath_conf}/dbchangelogs
  fi
  # 将 子服务/conf 中 liquibase、国际化配置 放入 主服务/conf
  mvSubServerDir2MainServer "${TP_subServerPath}/conf/dbchangelogs/${TP_subServer_liquibase}" "${TP_mainServerPath_conf}/dbchangelogs/${TP_subServer_liquibase}" "${TP_mainServerPath_conf}/dbchangelogs/${TP_subServer_liquibase}/*"
  mvSubServerDir2MainServer "${TP_subServerPath}/conf/i18n" "${TP_mainServerPath_conf}/i18n" "${TP_mainServerPath_conf}/i18n/${TP_subServer_i18n}-*.properties"



  if [[ -n "${GP_submoduleConfExtDirs}" ]]; then
    for confExtDir in ${GP_submoduleConfExtDirs}; do
        # 将 子服务/conf 中 initData 放入 主服务/conf
        mvSubServerDir2MainServer "${TP_subServerPath}/conf/${confExtDir}" "${TP_mainServerPath_conf}/${confExtDir}" "${TP_mainServerPath_conf}/${confExtDir}/*"
    done
  fi

  if [[ -n "${GP_submoduleOtherExtDirs}" ]]; then
    for otherExtDir in ${GP_submoduleOtherExtDirs}; do
        # 将 子服务/plugins 放入 主服务/plugins
        mvSubServerDir2MainServer "${TP_subServerPath}/${otherExtDir}" "${TP_mainServerPath}/${otherExtDir}" "${TP_mainServerPath}/${otherExtDir}/*"
    done
  fi





if [[ ! -e ${TP_mainServerPath_conf}/dbchangelogs/changelog_fusion.xml ]]; then
  echo '''<?xml version="1.0" encoding="UTF-8"?>
<databaseChangeLog
        xmlns="http://www.liquibase.org/xml/ns/dbchangelog"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog
         http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-3.1.xsd">


</databaseChangeLog>''' > ${TP_mainServerPath_conf}/dbchangelogs/changelog_fusion.xml
fi


  serverChangeLogContent="   <\!-- 集成 ${TP_subServerPath} -->\n    <include file=\"conf/dbchangelogs/${TP_subServer_liquibase}/${GP_serviceDbTypeName}/changelog.xml\"/>\n\n"
  sed -i "/<\/databaseChangeLog>/i\ ${serverChangeLogContent}" ${TP_mainServerPath_conf}/dbchangelogs/changelog_fusion.xml


  dosmChangeLogPath="conf/dbchangelogs/${GP_serviceDbTypeName}/changelog.xml"
  if [[ -z "$(cat ${TP_mainServerPath_conf}/dbchangelogs/changelog_fusion.xml | grep "file=\"${dosmChangeLogPath}\"")" ]]; then
    serverChangeLogContent="   <\!-- 集成 DOSM -->\n    <include file=\"${dosmChangeLogPath}\"/>\n\n"
    sed -i "/<\/databaseChangeLog>/i\ ${serverChangeLogContent}" ${TP_mainServerPath_conf}/dbchangelogs/changelog_fusion.xml

    if [[ -f ${TP_mainServerPath}/bin/dosmLauncher ]]; then
      sed -i "s#${dosmChangeLogPath}#conf/dbchangelogs/changelog_fusion.xml#" ${TP_mainServerPath}/bin/dosmLauncher
    fi
  fi


  # 将 子服务模块包 放入 主服务/lib
  if [[ -e ${TP_subServerPath}/conf/lib-snap/module.snap ]]; then
    #==== 将子服务模块包放入主服务，避免 comLib 中非最新版本包覆盖【排除当前服务中启动包】
    cat ${TP_subServerPath}/conf/lib-snap/module.snap >> ${TP_mainServerPath_conf}/lib-snap/module.snap

    subServerModuleNames=$(cat ${TP_subServerPath}/conf/lib-snap/module.snap | tr '\n' '|' | sed 's/|$//g')
    # 子服务依赖包信息
    ls ${TP_subServerPath}/lib | grep .jar | grep -Ev ${subServerModuleNames} | xargs -I {} echo lib/{} > ${TP_subServerPath}/conf/lib-snap/dependency.snap

    # 子服务模块包信息
    subServerModuleJarNames=`ls ${TP_subServerPath}/lib/*.jar | grep -E ${subServerModuleNames} | awk -F/ '{print $NF}'`
    for moduleJarName in ${subServerModuleJarNames}; do
      mergeServerLib ${moduleJarName} ${TP_mainServerPath_lib} ${TP_subServerPath} true
    done
  fi


  # 将 子服务/lib 服务包 放入 主服务/lib
  if [[ -e ${TP_subServerPath}/conf/lib-snap/dependency.snap ]]; then

    if [[ "${GP_mainServerPackageExt}" = "war" ]]; then
      TP_moduleJarNames=$(cat ${TP_subServerPath}/conf/lib-snap/dependency.snap | grep 'lib' | grep -v 'tomcat');
    else
      TP_moduleJarNames=$(cat ${TP_subServerPath}/conf/lib-snap/dependency.snap | grep 'lib');
    fi

    for moduleJarName in ${TP_moduleJarNames}; do
      mergeServerLib ${moduleJarName#*/} ${TP_mainServerPath_lib} ${TP_subServerPath} false
    done
  fi
}

# -------------------------- 开始执行 repack --------------------------

# 进入 mainServer 解压包目录
cd ${GP_mainServerPath}/target

# 服务名
submoduleDirName=`echo "${GP_submoduleFileName}" | cut -d- -f1`

# 删除临时文件
rmServerTmpDir ${GP_mainServerName} ${submoduleDirName}

mainServerNameFile=$(ls |grep ${GP_mainServerName}-*.${GP_mainServerPackageExt})
echo "解压主服务包: ${mainServerNameFile}"

if [[ "${GP_mainServerPackageExt}" = "war" ]]; then
  # linux 服务器上无法是使用 tar 命令解压 war 包
  echo "command ----- unzip -q ${mainServerNameFile} -d ${GP_mainServerName}"
  unzip -q ${mainServerNameFile} -d ${GP_mainServerName}
else
  echo "command ----- tar -zxf ${mainServerNameFile}"
  tar -zxf ${mainServerNameFile}
fi
rm -rf ${mainServerNameFile}


# submodule 解压
# tar -zxf ${GP_submodulePath}/${GP_submoduleFileName} -C ${GP_submodulePath}
tar -zxf ${GP_submodulePath}/${GP_submoduleFileName}

# 移除排除的包
for excludeJarName in $(echo ${GP_submoduleExcludeJarName} | tr "," " "); do
  rm -rf ${submoduleDirName}/lib/${excludeJarName}*
done


# 合并服务
mergeServer ${GP_mainServerName} ${submoduleDirName} ${GP_submoduleDBChangeDir} ${GP_submoduleI18nPreName}


echo "---- mainServer 归档: ${mainServerNameFile}"
if [[ "${GP_mainServerPackageExt}" = "war" ]]; then
  # 使用 zip 命令避免 war 包不能使用 unzip 解压
  echo "command ----- cd ${GP_mainServerName} && zip -rq ../${mainServerNameFile} ./* && cd ../"
  cd ${GP_mainServerName} && zip -rq ../${mainServerNameFile} ./* && cd ../
else
  echo "command ----- tar -zcf ${mainServerNameFile} ${GP_mainServerName}"
  tar -zcf ${mainServerNameFile} ${GP_mainServerName}
fi

# 删除临时文件
rmServerTmpDir ${GP_mainServerName} ${submoduleDirName}
