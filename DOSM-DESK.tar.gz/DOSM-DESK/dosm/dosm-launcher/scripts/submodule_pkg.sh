#!/bin/bash
#----------------------------------------------------------------
#=== 下载 子服务，并执行代码编译
#----------------------------------------------------------------

GP_mainServerPath=${PROJECT_DIR}
GP_mainServerName=${SERVICE_NAME}
# 主服务 mvn profile：jar、tong-web、war
GP_mainServerActivateProfiles="jar"
# 服务部署数据库类型（与conf/dbchangelogs下目录名一致【postgresql、mysql】）
GP_serviceDbTypeName="postgresql"
if [[ -n "$1" ]]; then
  GP_mainServerPath="$1"
fi
if [[ -n "$2" ]]; then
  GP_mainServerName="$2"
fi
if [[ -n "$3" ]]; then
  GP_mainServerActivateProfiles="$3"
fi
if [[ -n "${p_serverActivateProfiles}" ]]; then
  GP_mainServerActivateProfiles="${p_serverActivateProfiles}"
fi

if [[ -n "$4" ]]; then
  GP_serviceDbTypeName="$4"
fi
if [[ -n "${p_serviceDbTypeName}" ]]; then
  GP_serviceDbTypeName="${p_serviceDbTypeName}"
fi

GP_submoduleGits=("DOSM/facewall/facewall-platform.git")
GP_submoduleTestBranchs=("dev")
GP_submoduleReleaseBranchs=("master")
GP_submoduleCurrStages=("release")
GP_submoduleServerNames=("facewallServer")
GP_submoduleProjDirs=("facewall-launcher")
GP_submoduleDBChangeDirs=("facewall")
GP_submoduleI18nPreNames=("facewall")
# 子模块需要排除的包名或包名前缀。同一个子模块要排除多个包，样例：("jar1,*jar2,ja*r3")
GP_submoduleExcludeJarNames=("facewall-launcher")
# 同一个服务存在多个目录时样例：("initData0 initData1 initData")
GP_submoduleConfExtDirs=("initData")
# 同一个服务存在多个目录时样例：("plugins/lowcode0 plugins/lowcode1 plugins0/lowcode")
GP_submoduleOtherExtDirs=("plugins/lowcode")


# 主服务最终包扩展名：tar.gz、war
mainServerPackageExt="tar.gz"
if [[ x"${GP_mainServerActivateProfiles}" = x"war" ]]; then
  GP_mainServerActivateProfiles="jar"
  mainServerPackageExt="war"
fi


# =================================================================

GP_GIT_HOST="http://vone_read_only:"nQm93RWzbHf_SR-NLcUN"@git.cloudwise.com"

function gitCheckout() {
  submoduleGit=$1
  submoduleServerName=$2
  submoduleBranch=$3

  echo "---- git checkout: ${submoduleGit}, serverName: ${submoduleServerName}, branch: ${submoduleBranch}"
  git clone -b ${submoduleBranch} ${GP_GIT_HOST}/${submoduleGit} ${submoduleServerName}

  echo "------------ git checkout branch: $(cd ${submoduleServerName} && git branch)"
}


function buildCode() {
  submoduleServerName=$1
  submoduleProjDir=$2
  echo "---- buildCode: serverName: ${submoduleServerName}, projDir: ${submoduleProjDir}"


  cd ${submoduleServerName}

  echo "$(pwd)"

  rm -rf ${submoduleProjDir}/package/conf/lib-snap && mkdir -p ${submoduleProjDir}/package/conf/lib-snap
  mvn  --also-make dependency:tree | grep maven-dependency-plugin | awk '{ print $(NF-1) }' > ${submoduleProjDir}/package/conf/lib-snap/module.snap
  mvn clean package -DskipTests -Dmaven.test.skip=true -P ${GP_mainServerActivateProfiles}

  cd ..

}

function repackege() {
  submoduleServerName="$1"
  submoduleProjDir="$2"
  submoduleDBChangeDir="$3"
  submoduleI18nPreName="$4"
  submoduleExcludeJarName="$5"
  submoduleConfExtDirs="$6"
  submoduleOtherExtDirs="$7"

  submoduleServerPath=$(pwd)
  submoduleServerPath=${submoduleServerPath}/${submoduleServerName}/${submoduleProjDir}/target
  submoduleServerTarName=$(ls ${submoduleServerPath}/${submoduleServerName}-*.tar.gz)
  submoduleServerTarName=${submoduleServerTarName##*/}

  echo "repackege command: ${GP_mainServerPath}/scripts/repack.sh" "${submoduleServerPath}" "${submoduleServerTarName}" "${submoduleDBChangeDir}" "${submoduleI18nPreName}" "${submoduleExcludeJarName}" "${submoduleConfExtDirs}" "${submoduleOtherExtDirs}" "${GP_mainServerPath}" "${GP_mainServerName}" "${mainServerPackageExt}" "${GP_serviceDbTypeName}"
  sh ${GP_mainServerPath}/scripts/repack.sh "${submoduleServerPath}" "${submoduleServerTarName}" "${submoduleDBChangeDir}" "${submoduleI18nPreName}" "${submoduleExcludeJarName}" "${submoduleConfExtDirs}" "${submoduleOtherExtDirs}" "${GP_mainServerPath}" "${GP_mainServerName}" "${mainServerPackageExt}" "${GP_serviceDbTypeName}"
}


# =================================================================

for i in $(seq 0 `expr ${#GP_submoduleGits[@]} - 1`); do
  submoduleServerName="${GP_submoduleServerNames[$i]}"
  echo "============= start build [$i]【${submoduleServerName}】, dir: $(pwd)============="

  submodule_branch=$(eval echo '$'${submoduleServerName}_branch)
  submodule_curr_stage=$(eval echo '$'${submoduleServerName}_curr_stage)
  submodule_test_branch=$(eval echo '$'${submoduleServerName}_test_branch)
  submodule_release_branch=$(eval echo '$'${submoduleServerName}_release_branch)

  if [[ -z "${submodule_curr_stage}" ]]; then
    submodule_curr_stage=${GP_submoduleCurrStages[$i]}
  fi
  if [[ -z "${submodule_test_branch}" ]]; then
    submodule_test_branch=${GP_submoduleTestBranchs[$i]}
  fi
  if [[ -z "${submodule_release_branch}" ]]; then
    submodule_release_branch=${GP_submoduleReleaseBranchs[$i]}
  fi

  echo "----------- branch info: ${submodule_branch}, curr_stage: ${submodule_curr_stage}, test_branch: ${submodule_test_branch}, release_branch: ${submodule_release_branch}"
  if [[ -z "${submodule_branch}" ]]; then
    if [[ "${submodule_curr_stage}" == "test" ]]; then
      submodule_branch=${submodule_test_branch}
    else
      submodule_branch=${submodule_release_branch}
    fi
  fi

  rm -rf ${submoduleServerName} && mkdir -p ${submoduleServerName}

  # ==== 1： 下载仓库
  gitCheckout ${GP_submoduleGits[$i]} ${submoduleServerName} ${submodule_branch}

  # ==== 2： 构建代码
  buildCode ${submoduleServerName} ${GP_submoduleProjDirs[$i]}

  # ==== 3： 合并代码
  repackege "${submoduleServerName}" "${GP_submoduleProjDirs[$i]}" "${GP_submoduleDBChangeDirs[$i]}" "${GP_submoduleI18nPreNames[$i]}" "${GP_submoduleExcludeJarNames[$i]}" "${GP_submoduleConfExtDirs[$i]}" "${GP_submoduleOtherExtDirs[$i]}"


  echo "============= end build 【${submoduleServerName}】============="
done

