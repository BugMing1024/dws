#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
from Core import Core
python_version = sys.version_info.major
if python_version == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')


SERVICE_NAME = "dosmLauncher"


class InstallDosmLauncher(Core):

    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.param = self.parameters()  # 脚本接收到的参数
        self.format_para(self.param)  # 解析脚本接收到的参数， 并初始化参数

    def run(self):
        self.out('\n *** dosmLauncher 安装进度 *** \n')
        self.out("1 {} 开始安装")

        base_dir_path = self.install_args.get("base_dir")
        data_dir_path = self.install_args.get("data_dir")
        log_dir_path = self.install_args.get("log_dir")
        username = self.install_args.get("run_user")
        # 创建通用目录
        self.check_dir()
        scripts_path = os.path.join(base_dir_path, 'bin', 'dosmLauncher')
        # 更改文件权限
        self.sys_cmd('chmod +x {}'.format(scripts_path), ignore_exception=False)
        cw_service_port = self.port.get('service_port')
        cw_metrics_port = self.port.get('metrics_port')
        cw_rpc_port = self.port.get('rpc_port')
        cw_jvm_heap_size = self.install_args.get("memory")
        cw_jvm_heap_size_min = self.install_args.get("minmemory")
        cw_service_dbname = self.install_args.get("dbname")
        cw_nacos_host = self.pub_ip_port_str('nacos', 'service_port')
        cw_nacos_username = self.pub_para_install("username", "nacos")
        cw_nacos_password = self.pub_para_install("password_enc", "nacos")
        cw_nacos_namespace = self.pub_para_install("namespace", "nacos")

        # set start script
        place_holder_script = {
            "CW_RUN_USER": username,
            "CW_LOCAL_IP": self.local_ip,
            "CW_JVM_HEAP_SIZE": cw_jvm_heap_size,
            "CW_JVM_HEAP_SIZE_MIN": cw_jvm_heap_size_min,
            "CW_INSTALL_APP_DIR": os.path.dirname(base_dir_path) ,
            "CW_INSTALL_LOGS_DIR": os.path.dirname(log_dir_path),
            "CW_INSTALL_DATA_DIR": os.path.dirname(data_dir_path),
            "CW_NACOS_SERVER": cw_nacos_host,
            "CW_NACOS_USERNAME": cw_nacos_username,
            "CW_NACOS_PASSWORD": cw_nacos_password,
            "CW_NACOS_NAMESPACE": cw_nacos_namespace,
            "CW_SERVICE_DBNAME": cw_service_dbname,
            "CW_SERVICE_PORT": cw_service_port,
            "CW_RPC_PORT": cw_rpc_port,
            "CW_METRICS_PORT": cw_metrics_port,
        }

        self.replace(scripts_path, place_holder_script)
        CW_INSTALL_PRODUCTS = self.get_config_product_value_str().split(",")
    #         init_data_path = os.path.join(
    #             base_dir_path,
    #             "conf/dosm_source_init_data.txt")
    #         if 'wisebot' in CW_INSTALL_PRODUCTS:
    #             old_str = ']}'
    #             new_dokb_str = ',{"name":"智能助理","code":"dosm_wisebot_management","type":1,"description":"智能助理","parentCode":""}]}'
    #             self.replace_str(old_str, new_dokb_str, init_data_path)
    #
    #         if 'dokb' in CW_INSTALL_PRODUCTS:
    #             old_str = ']}'
    #             new_dokb_str = ',{"name":"知识查询","code":"dosm_knowledge_search","type":1,"description":"菜单","parentCode":""},{"name":"知识管理","code":"dosm_knowledge_management","type":1,"description":"菜单","parentCode":""}]}'
    #             self.replace_str(old_str, new_dokb_str, init_data_path)

        # TODO 不确定这里的逻辑是做什么用的
        # CW_INSTALL_DATALAKECOMPUTE = self.pub_ip_port_str("serviceDeskServer", "service_port").split(",")[0].split(":")[1]
        # if 'dohd' in CW_INSTALL_PRODUCTS and CW_INSTALL_DATALAKECOMPUTE == 'serviceDeskServer':
        #     old_str = ']}'
        #     new_dohp_str = ',{"name":"服务台","code":"dosm_service_counter","type":1,"description":"菜单","parentCode":""},{"name":"服务台设置","code":"dosm_service_setting","type":1,"description":"菜单","parentCode":""},{"name":"会话记录","code":"dosm_service_session","type":1,"description":"菜单","parentCode":""},{"name":"服务台监控","code":"dosm_service_monitor","type":1,"description":"菜单","parentCode":""}]}'
        #     self.replace_str(old_str, new_dohp_str, init_data_path)

        # set register scripts
#         register_bash = os.path.join(base_dir_path, 'scripts/bash/registerService.sh')
#
#         # 替换占位符
#         CW_INSTALL_PRODUCTS = ",".join(CW_INSTALL_PRODUCTS)
#         CW_dosmLauncher_HOSTS = self.pub_ip_port_str('dosmLauncher', 'service_port').split(",")
#         CW_dosmLauncher_HOSTS = CW_dosmLauncher_HOSTS[0]
#         place_holder_register_script = {
#             "CW_INSTALL_PRODUCTS": CW_INSTALL_PRODUCTS,
#             "CW_dosmLauncher_HOSTS": CW_dosmLauncher_HOSTS
#         }
#         self.replace(register_bash, place_holder_register_script)

        # 从公共库拷贝jar 开始 ----
        # 拼接脚本路径
        common_link_script = os.path.join(self.install_args.get("base_dir"), "{}/{}".format("scripts", "link.sh"))
        # 添加执行权限
        self.sys_cmd('chmod +x {}'.format(common_link_script), ignore_exception=False)
        # 从公共库拷贝jar,并检查快照中的文件是否均可访问，如发生异常则直接退出
        self.sys_cmd('sh {} {}'.format(common_link_script, self.pub_para_install("base_dir", "comLib")),
                     ignore_exception=False)
        # 从公共库拷贝jar逻辑 结束 ----

        self.sys_cmd("chmod a+x {0}".format(scripts_path), ignore_exception=False)

        self.out("3 {} portalServer安装成功")

if __name__ == '__main__':

    wisebot = InstallDosmLauncher()
    wisebot.run()
