#!/bin/bash

CURRENT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
THIS_SCRIPT="$CURRENT_DIR/$(basename $0)"

[ -f "/etc/profile" ] && . "/etc/profile"
[ -f "${CURRENT_DIR}/../../../bash_profile" ] && . "${CURRENT_DIR}/../../../bash_profile" 

unset LD_LIBRARY_PATH

#sleep 15

function Register() {
    ProductList="${CW_INSTALL_PRODUCTS}"
    echo -e "\E[1;32m INFO registerService DOSM \E[0m"
    # 注册douc菜单权限
    curl -s -i 'http://${CW_DOSMLAUNCHER_HOSTS}/api/v2/data/registerSource' \
            -H 'userId: 2' \
            -H 'accountId: 110'
    if [ $? -eq 0 ]; then
        echo -e "\nDOSM douc菜单权限注册成功\n"
    else
        echo -e "\nDOSM douc菜单权限注册失败\n确认 dosmLauncher 相关法服务是否处于启动状态，然后手动执行 bash ./registerService.sh 进行注册(相对于 dosmLauncher 目录下的 dosmLauncher/bash/下)"
    fi
    # 初始化douc数据权限
    curl -s --location --request GET 'http://${CW_DOSMLAUNCHER_HOSTS}/api/v2/data/initMultiTypeData' \
        --header 'accountId: 110' \
        --header 'userId: 2'
    if [ $? -eq 0 ]; then
        echo -e "\nDOSM douc数据权限初始化成功\n"
    else
        echo -e "\nDOSM douc数据权限初始化失败\n确认 dosmLauncher 相关法服务是否处于启动状态，然后手动执行 bash ./registerService.sh 进行注册(相对于 dosmLauncher 目录下的 dosmLauncher/bash/下)"
    fi
    # 初始化douc数据权限
    curl -s --location --request GET 'http://${CW_DOSMLAUNCHER_HOSTS}/api/v2/data/registerMultiTypeData' \
        --header 'accountId: 110' \
        --header 'userId: 2'
    if [ $? -eq 0 ]; then
        echo -e "\nDOSM douc数据权限注册成功\n"
    else
        echo -e "\nDOSM douc数据权限注册失败\n确认 dosmLauncher 相关法服务是否处于启动状态，然后手动执行 bash ./registerService.sh 进行注册(相对于 dosmLauncher 目录下的 dosmLauncher/bash/下)"
    fi

}

Register