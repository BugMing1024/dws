#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
from Core import Core
python_version = sys.version_info.major
if python_version == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')


SERVICE_NAME = "dosmLauncher"


class DosmLauncherInit(Core):

    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.param = self.parameters()  # 脚本接收到的参数
        self.format_para(self.param)  # 解析脚本接收到的参数， 并初始化参数

    def install_init(self):
        CW_INSTALL_APP_DIR = self.install_args.get("base_dir")
        CW_RUN_USER = self.install_args.get("run_user")
        server_addresses = self.pub_ip_port_str('nacos', 'service_port')
        server_list = list()
        for server_addr in server_addresses.split(","):
            server_list.append(server_addr.strip())
        cmd_str = 'bash {}/{}  {} {} {} {} {} {} {} {} {}'.format(
        CW_INSTALL_APP_DIR,"scripts/core.sh", CW_RUN_USER, "init" , CW_INSTALL_APP_DIR,self.install_args.get("log_dir")
        , CW_INSTALL_APP_DIR ,server_list[0], self.pub_para_install('username', 'nacos'),self.pub_para_install('password_enc', 'nacos'),self.pub_para_install('namespace', 'nacos'))
        print(cmd_str)
        result = self.sys_cmd(cmd_str, ignore_exception=False)
        print("sys_cmd exec cmd_str, result: "+ result)
        if result is not None:
            if "[success]" in result:
                sys.exit(0)
            else:
                print("初始化失败")
                sys.exit(1)


if __name__ == '__main__':
    dosm = DosmLauncherInit()
    dosm.install_init()
