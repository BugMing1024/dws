# -*- coding: utf-8 -*-
import glob
import os.path
from Core import Core
from threading import RLock
import socket
import sys
import base64

try:
    from http import HTTPStatus
    from urllib.request import Request, urlopen, ProxyHandler, HTTPSHandler, build_opener
    from urllib.parse import urlencode, unquote, quote
    from urllib.error import HTTPError, URLError
except ImportError:
    import httplib as HTTPStatus
    from urllib2 import Request, urlopen, HTTPError, URLError, ProxyHandler, HTTPSHandler, build_opener
    from urllib import urlencode, unquote, quote

    base64.encodebytes = base64.encodestring
    reload(sys)
    sys.setdefaultencoding('utf8')

# 服务名称，按需修改
SERVICE_NAME = "dosmLauncher"
# 是否升级数据库 True 表示升级， False表示不升级
update_database = True
# 是否更新配置文件 True 表示升级， False表示不升级
update_config = True
"""
配置文件合并策略，暂时配置文件的合并仅支持properties格式的配置文件
none 表示使用最新的配置文件
union 表示新配置文件与老配置文件的并集，相同的配置项使用老配置文件的值
update 更新新配置文件，相同的配置项使用老配置文件的值
"""
config_merge_strategy = "none"
# 配置文件备份路径
nacos_config_back_name = "nacos_back"


def python_version_bellow(version):
    if not version:
        return False
    sp = [int(s) for s in version.split(".")]
    for i in range(len(sp) if len(sp) <= 3 else 3):
        if sp[i] == sys.version_info[i]:
            continue
        return sys.version_info[i] < sp[i]
    return False


def parse_nacos_server_addr(server_addr):
    sp = server_addr.split(":")
    port = int(sp[1]) if len(sp) > 1 else 8848
    return sp[0], port


class OriginalObject:
    def __init__(self, line, current_value):
        self.original_line = line
        self.current_value = current_value


def parse_properties(content):
    result = {}
    for line in content.split('\n'):
        if line.startswith("#"):
            continue
        kv = line.split("=")
        if len(kv) != 2:
            continue
        k = kv[0].strip()
        v = kv[1].strip()
        result[k] = OriginalObject(line, v)
    return result


VALID_CHAR = set(['_', '-', '.', ':'])


# properties配置文件更新
def update_config_properties(new_map, old_map, new_config_context):
    if config_merge_strategy == "none":
        return new_config_context
    is_change = False
    for k, v in old_map.items():
        v_new = new_map.get(k)
        if v_new is None:
            if config_merge_strategy == "union":
                new_config_context = new_config_context + "\n{} = {}".format(k, v.current_value)
            continue
        if v.current_value == v_new.current_value:
            continue
        if not is_change:
            is_change = True
        new_config_context = new_config_context.replace(v_new.original_line, "{}={}".format(k, v.current_value))
    return new_config_context, is_change


def is_valid(param):
    if not param:
        return False
    for i in param:
        if i.isalpha() or i.isdigit() or i in VALID_CHAR:
            continue
        return False
    return True


class NacosClient:

    def __init__(self, server_addresses, endpoint=None, namespace=None, ak=None, sk=None, username=None, password=None):

        self.server_list = list()
        for server_addr in server_addresses.split(","):
            self.server_list.append(server_addr.strip())
        self.current_server = parse_nacos_server_addr(self.server_list[0])
        self.endpoint = endpoint
        self.namespace = namespace
        self.ak = ak
        self.sk = sk
        self.username = username
        self.password = password
        self.server_list_lock = RLock()
        self.server_offset = 0
        self.default_timeout = 3

    def get_server(self):
        return self.current_server
    def get_namespace(self):
        return self.namespace
    def get_username(self):
        return self.username
    def get_password(self):
        return self.password

    def change_server(self):
        with self.server_list_lock:
            self.server_offset = (self.server_offset + 1) % len(self.server_list)
            self.current_server = self.server_list[self.server_offset]

    def _do_sync_req(self, url, headers=None, params=None, data=None, timeout=None, method="GET"):
        if self.username and self.password:
            if not params:
                params = {}
            params.update({"username": self.username, "password": self.password})
        url = "?".join([url, urlencode(params)]) if params else url
        all_headers = {}
        if headers:
            all_headers.update(headers)

        tries = 0
        while True:
            try:
                server_info = self.get_server()
                address, port = server_info
                server = ":".join([address, str(port)])
                server_url = "%s://%s" % ("http", server)
                if python_version_bellow("3"):
                    req = Request(url=server_url + url, data=urlencode(data).encode() if data else None,
                                  headers=all_headers)
                    req.get_method = lambda: method
                else:
                    req = Request(url=server_url + url, data=urlencode(data).encode() if data else None,
                                  headers=all_headers, method=method)
                # build a new opener that adds proxy setting so that http request go through the proxy
                # for python version compatibility
                if python_version_bellow("2.7.9"):
                    resp = urlopen(req, timeout=timeout)
                else:
                    resp = urlopen(req, timeout=timeout, context=None)
                print("[do-sync-req] info from server:%s" % server)
                return resp
            except HTTPError as e:
                print("[do-sync-req] server:%s is not available for reason:%s" % (server, e.msg))
            except socket.timeout:
                print("[do-sync-req] %s request timeout" % server)
            except URLError as e:
                print("[do-sync-req] %s connection error:%s" % (server, e.reason))
            except Exception as e:
                print(e)

            tries += 1
            if tries >= len(self.server_list):
                print("[do-sync-req] %s maybe down, no server is currently available" % server)
                return None
            self.change_server()
            print("[do-sync-req] %s maybe down, skip to next" % server)
        return None

    def get_config(self, data_id, group, timeout=None):
        print("[get-config] data_id:%s, group:%s, namespace:%s, timeout:%s" % (data_id, group, self.namespace, timeout))
        params = {
            "dataId": data_id,
            "group": group,
        }
        if self.namespace:
            params["tenant"] = self.namespace
        # get from server
        try:
            resp = self._do_sync_req("/nacos/v1/cs/configs", None, params, None, timeout or self.default_timeout)
            if resp is None:
                return None
            content = resp.read().decode("UTF-8")
            return content
        except HTTPError as e:
            if e.code == HTTPStatus.NOT_FOUND:
                print("[get-config] config not found for data_id:%s, group:%s, namespace:%s, try to delete snapshot" % (
                    data_id, group, self.namespace))
                return None
            elif e.code == HTTPStatus.CONFLICT:
                print("[get-config] config being modified concurrently for data_id:%s, group:%s, namespace:%s" % (
                    data_id, group, self.namespace))
            elif e.code == HTTPStatus.FORBIDDEN:
                print("[get-config] no right for data_id:%s, group:%s, namespace:%s" % (data_id, group, self.namespace))
            else:
                print("[get-config] error code [:%s] for data_id:%s, group:%s, namespace:%s" % (
                    e.code, data_id, group, self.namespace))
        except Exception as e:
            print("[get-config] exception %s occur" % str(e))
        return None

    def publish_config(self, data_id, group, content, timeout=None):
        if type(content) is bytes:
            content = content.decode("UTF-8")
        print("[publish] data_id:%s, group:%s, namespace:%s, timeout:%s" % (data_id, group, self.namespace, timeout))
        params = {
            "dataId": data_id,
            "group": group,
            "content": content.encode("UTF-8"),
            "tenant": self.namespace
        }
        try:
            resp = self._do_sync_req("/nacos/v1/cs/configs", None, None, params, timeout or self.default_timeout,
                                     "POST")
            c = resp.read()
            print("[publish] publish content, group:%s, data_id:%s, server response:%s" % (group, data_id, c))
            return c == b"true"
        except HTTPError as e:
            print("[publish] publish content, group:%s, data_id:%s, server response:%s error:%s" % (
                group, data_id, c, e.msg))
        except Exception as e:
            print("[publish] exception %s occur" % str(e))

        return False


class UpgradeManage(Core):

    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数

        # 从公共库拷贝jar 开始 ----
        # 拼接脚本路径
        common_link_script = os.path.join(self.install_args.get("base_dir"), "{}/{}".format("scripts", "link.sh"))
        # 添加执行权限
        self.sys_cmd('chmod +x {}'.format(common_link_script), ignore_exception=False)
        # 从公共库拷贝jar,并检查快照中的文件是否均可访问，如发生异常则直接退出
        self.sys_cmd('sh {} {}'.format(common_link_script, self.pub_para_install("base_dir", "comLib")),
                     ignore_exception=False)
        # 从公共库拷贝jar逻辑 结束 -----


        self.app_path = self.install_args.get("base_dir")
        CW_INSTALL_APP_DIR = os.path.dirname(self.app_path)

        # kafka
        #CW_KAFKA_HOST = self.pub_ip_port_str('kafka', 'service_port')

        # nacos
        CW_NACOS_HOST = self.pub_ip_port_str('nacos', 'service_port')
        CW_NACOS_USERNAME = self.pub_para_install('username', 'nacos')
        CW_NACOS_PASSWORD = self.pub_para_install('password_enc', 'nacos')
        CW_NACOS_NAMESPACE = self.pub_para_install('namespace', 'nacos')

        # set start script
        self.place_holder_script = {
            "CW_RUN_USER": self.install_args.get("run_user"),
            "CW_LOCAL_IP": self.local_ip,
            "CW_JVM_HEAP_SIZE": self.install_args.get("memory"),
            "CW_JVM_HEAP_SIZE_MIN": self.install_args.get("minmemory"),
            "CW_INSTALL_APP_DIR": os.path.dirname(self.install_args.get("base_dir")),
            "CW_INSTALL_LOGS_DIR": os.path.dirname(self.install_args.get("log_dir")),
            "CW_INSTALL_DATA_DIR": os.path.dirname(self.install_args.get("data_dir")),
            "CW_NACOS_SERVER": CW_NACOS_HOST,
            "CW_NACOS_USERNAME": CW_NACOS_USERNAME,
            "CW_NACOS_PASSWORD": CW_NACOS_PASSWORD,
            "CW_NACOS_NAMESPACE": CW_NACOS_NAMESPACE,
            "CW_SERVICE_DBNAME": self.install_args.get("dbname"),
            "CW_SERVICE_PORT": str(self.port.get("service_port")),
            "CW_METRICS_PORT": str(self.port.get("metrics_port")),
        }
        app_lib_path = os.path.join(self.app_path, "utils", "nacos-util-*.jar")
        nacos_jar_paths = glob.glob(app_lib_path)
        if len(nacos_jar_paths) == 1:
            java_path = os.path.join(CW_INSTALL_APP_DIR, "jdk", "bin", "java")
            try:
                nacos_password_plaintext = str(self.sys_cmd(
                    "{} -cp {} com.nacosutil.RSAUtils decrypt {}".format(java_path, nacos_jar_paths[0],
                                                                                       CW_NACOS_PASSWORD), ignore_exception=False)).split(
                    ':')[-1].replace("\n", "")
                if nacos_password_plaintext.endswith("'"):
                    nacos_password_plaintext = nacos_password_plaintext[:-1]
            except Exception as e:
                print("service {} parse nacos password error {}".format(SERVICE_NAME, str(e)))
                print("service {} upgrade [failed]".format(SERVICE_NAME))
                sys.exit(1)
            print("service {} found nacos decrypt jar package {}".format(SERVICE_NAME, nacos_jar_paths[0]))
        else:
            print("len(nacos_jar_paths)!=1")
            sys.exit(1)
        self.nacos_client = NacosClient(
            CW_NACOS_HOST,
            username=CW_NACOS_USERNAME,
            password=nacos_password_plaintext,
            namespace=CW_NACOS_NAMESPACE
        )
        self.data_migrate_path = os.path.join(
            CW_INSTALL_APP_DIR, "doucDataMigrate"
        )
        self.scripts_path = os.path.join(
            self.install_args.get("base_dir"), 'bin/{0}'.format(SERVICE_NAME)
        )
        self.version = self.para.version
        self.root_path = CW_INSTALL_APP_DIR

    # 停止服务
    def stop_service(self):
        return self.sys_cmd("bash {} stop".format(self.scripts_path), ignore_exception=False)

    # 启动服务
    def start_service(self):
        return self.sys_cmd("bash {} start".format(self.scripts_path), ignore_exception=False)

    def status_service(self):
        return self.sys_cmd("bash {} status".format(self.scripts_path), ignore_exception=False)

    # 备份数据库
    def back_database(self):
        # TODO 实现备份数据库逻辑
        return "success"

    # 升级数据库
    def upgrade_database(self):
        return self.sys_cmd("bash {} db update".format(self.scripts_path), ignore_exception=False)

    # 配置文件更新之更新具体的配置文件
    def upgrade_config(self, config_path, config_type, group, data_id):

        with open(config_path, 'r') as f:
            config_new = f.read()
        # 如果本地配置文件为空则打印日志不进行更新
        if config_new == "" or config_new is None:
            print("{} file content null".format(config_path))
            return False
        config_old = self.nacos_client.get_config(data_id=data_id, group=group)
        if config_old is not None and config_old != "":
            if config_old == config_new:
                return True
            # 实现nacos配置文件的备份
            with open(os.path.join(self.app_path, nacos_config_back_name, group, data_id), "wb+") as f:
                f.write(config_old.encode("utf-8"))
            is_change = False
            if config_merge_strategy == "none":
                pass
            elif config_type == ".properties":
                config_old_map = parse_properties(config_old)
                config_new_map = parse_properties(config_new)
                config_new, is_change = update_config_properties(config_new_map, config_old_map, config_new)

            if is_change:
                with open(config_path, 'w+') as f:
                    f.write(config_new)

        if self.nacos_client.publish_config(data_id=data_id, group=group, content=config_new):
            print("group:{}, dataId:{} upgrade success".format(group, data_id))
            return True
        print("group:{}, dataId:{} upgrade fail".format(group, data_id))
        return False

    # 配置文件更新之获取组下所有的配置文件并逐一更新
    def upgrade_configs(self, dir_path, group):
        nacos_back_path = os.path.join(self.app_path, nacos_config_back_name, group)
        if not os.path.isdir(nacos_back_path):
            os.makedirs(nacos_back_path)
        for name in os.listdir(dir_path):
            config_path = os.path.join(dir_path, name)
            if not (os.path.isfile(config_path) and is_valid(name)):
                print("{} not a file or not valid".format(config_path))
                continue
            if not self.upgrade_config(config_path, os.path.splitext(name)[-1], group, name):
                return False
        return True

    # 配置文件更新之获取所有的组并逐一更新
    def upgrade_group(self):
        conf_dir = os.path.join(self.app_path, "conf", "nacos")
        if not os.path.exists(conf_dir):
            return "error {} not exixts".format(conf_dir)
        nacos_config_back_path = os.path.join(self.app_path, nacos_config_back_name)
        if not os.path.join(nacos_config_back_path):
            os.mkdir(nacos_config_back_path)
        for group in os.listdir(conf_dir):
            dir_path = os.path.join(conf_dir, group)
            if not (os.path.isdir(dir_path) and is_valid(group)):
                print("{} is not a dir or not valid".format(group))
                continue
            if not self.upgrade_configs(dir_path, group):
                return False
        return

    def replace_place_holder(self):
        result = self.check_dict_none(self.place_holder_script)
        if not result:
            self.out("有占位符变量值为空")
            sys.exit(1)
        self.out("{} 配置：修改bin/portalServer文件配置")
        self.replace(self.scripts_path, self.place_holder_script)
        self.sys_cmd("chmod a+x {0}".format(self.scripts_path), ignore_exception=False)

    def run(self):
        # 替换占位符：
        self.replace_place_holder()
        # 创建相关文件夹
        self.check_dir()
        # 添加执行权限，创建软连接
        self.create_user_and_change_owner()

        # 校验版本信息
        service_info_path = os.path.join(self.app_path, "service.properties")
        if not os.path.isfile(service_info_path):
            print("service {} upgrade fail service version info file not existent")
            exit(1)
        with open(service_info_path) as f:
            data = f.read()
        service_info_map = parse_properties(data)
        current_version = service_info_map.get("service-version", "")
        if not current_version.current_value:
            print("service {} upgrade fail service version info file not existent")
            exit(1)
        if current_version.current_value < self.version:
            print("service {} upgrade fail version {} is lower than the current version {}".format(SERVICE_NAME,
                                                                                                   current_version.current_value,
                                                                                                   self.version))
            exit(1)

        CW_INSTALL_APP_DIR = self.install_args.get("base_dir")
        CW_RUN_USER = self.install_args.get("run_user")
        cmd_str = 'bash {}/{}  {} {} {} {} {} {} {} {} {}'.format(
            CW_INSTALL_APP_DIR,"scripts/core.sh", CW_RUN_USER, "upgrade" , CW_INSTALL_APP_DIR,self.install_args.get("log_dir")
            , self.para.backup_path,self.nacos_client.server_list[0], self.pub_para_install('username', 'nacos'),self.pub_para_install('password_enc', 'nacos'),self.pub_para_install('namespace', 'nacos'))
        print(cmd_str)
        result = self.sys_cmd(cmd_str,
                              ignore_exception=False)


if __name__ == "__main__":
    _ = UpgradeManage()
    _.run()
