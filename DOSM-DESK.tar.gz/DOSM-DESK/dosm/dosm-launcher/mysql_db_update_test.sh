#!/bin/bash

    export LIQUIBASE_HOME=./
    db_username='commonuser'
    db_password='A0gqdr7c(Lfsuid'
    db_url='jdbc:postgres://127.0.0.1:18126/cw_dosm_facewall?allowMultiQueries=true'
    liquibase_jar=$(ls -t lib/*.jar | grep -E 'liquibase-core' | head -n 1)
    jdbc_driver_jar='lib/postgresql-42.4.1.jar'
    db_changeLogFile="conf/postgres/mariadb/changelog.xml"
    liquibase_run_cmd_base="java -server -d64 -Xmx512m -Xms256m -Xss512K -jar ${liquibase_jar} --classpath=${jdbc_driver_jar} --driver='org.postgres.Driver' --logLevel debug --username='${db_username}' --password='${db_password}'"
    liquibase_run_cmd="$liquibase_run_cmd_base --changeLogFile=${db_changeLogFile} --url='${db_url}'"

    echo "${liquibase_run_cmd} update" >>liquibase.log
    echo "${liquibase_run_cmd} update" | bash >>liquibase.log
    result=$?
    if [[ $result -eq 0 ]]; then
        echo "liquibase update [success]" | column -t
    else
        echo "liquibase update [failed]" | column -t
        exit 1
    fi

