package com.cloudwise.dosm.conf.spring;

import org.springframework.boot.autoconfigure.web.servlet.WebMvcRegistrations;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * 提供自定义的RequestMappingHandlerMapping，解决dubbo-rpc-rest重复注册Controller
 * @author jon.lee
 * @since 2024-11-11 15:55
 **/
public class DubboRpcRestWebMvcRegistrations implements WebMvcRegistrations {

    @Override
    public RequestMappingHandlerMapping getRequestMappingHandlerMapping() {
        return new DubboRpcRestRequestMappingHandlerMapping();
    }

}
