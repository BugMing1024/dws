package com.cloudwise.dosm.conf.spring;

import org.apache.dubbo.common.compact.Dubbo2CompactUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.dubbo.config.annotation.Service;
import org.apache.dubbo.config.spring.ReferenceBean;
import org.apache.dubbo.config.spring.reference.ReferenceBeanManager;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * DubboReference.class, Reference.class
 * 如果Reference属性不一致，同一个接口会注册多个不同的DubboReference bean；
 * dubbo-rpc-rest需要在DubboService上添加@Controller注解，多个DubboReference bean引用相同的DubboService，会导致Controller重复注册，Spring不允许重复注册Controller
 *
 * @author jon.lee
 * @since 2024-11-11 15:57
 **/
public class DubboRpcRestRequestMappingHandlerMapping extends RequestMappingHandlerMapping {

    private static final Map<Class<?>, String> REGISTERED_DUBBO_CLASS_MAP = new ConcurrentHashMap<>();

    private static final List<Class<? extends Annotation>> SERVICE_ANNOTATION_TYPES = loadServiceAnnotationTypes();

    private ReferenceBeanManager referenceBeanManager;

    protected boolean isDubboBean(Class<?> beanType, String beanName) {
        try {
            if(referenceBeanManager == null) {
                referenceBeanManager = (ReferenceBeanManager) this.obtainApplicationContext().getBean(ReferenceBeanManager.BEAN_NAME);
            }
            ReferenceBean<?> referenceBean = referenceBeanManager.getById(beanName);
            if(referenceBean != null) {
                return true;
            }

            for(Class<? extends Annotation> serviceAnnotationType : SERVICE_ANNOTATION_TYPES) {
                if(AnnotatedElementUtils.hasAnnotation(beanType, serviceAnnotationType)){
                    return true;
                }
            }
        } catch(Exception e) {
            this.logger.trace("Failed to check dubbo bean for beanType '"+beanType+"' with bean name '"+beanName+"'", e);
        }

        return false;
    }

    private static List<Class<? extends Annotation>> loadServiceAnnotationTypes() {
        return Dubbo2CompactUtils.isEnabled() && Dubbo2CompactUtils.isServiceClassLoaded() ? Arrays.asList(DubboService.class, Service.class, Dubbo2CompactUtils.getServiceClass()) : Arrays.asList(DubboService.class, Service.class);
    }

    @Override
    protected void processCandidateBean(String beanName) {
        Class<?> beanType = null;

        try {
            beanType = this.obtainApplicationContext().getType(beanName);
        } catch (Throwable var4) {
            if (this.logger.isTraceEnabled()) {
                this.logger.trace("Could not resolve type for bean '" + beanName + "'", var4);
            }
        }

        boolean isDubboBean = isDubboBean(beanType, beanName);

        if (beanType != null && notRegisteredDubboServiceBean(isDubboBean, beanType, beanName) && this.isHandler(beanType)) {
            this.detectHandlerMethods(beanName);
            if(isDubboBean) {
                REGISTERED_DUBBO_CLASS_MAP.put(beanType, beanName);
            }
        }

    }

    private boolean notRegisteredDubboServiceBean(boolean isDubboBean, Class<?> beanType, String beanName) {
        if(!isDubboBean){
            return true;
        }
        if(REGISTERED_DUBBO_CLASS_MAP.containsKey(beanType)){
            if (this.logger.isTraceEnabled()) {
                this.logger.trace("Cannot register RequestMappingHandlerMapping  for beanType '" + beanType + "' with bean name '"+beanName+"',  already registered with bean name '"+REGISTERED_DUBBO_CLASS_MAP.get(beanType)+"'");
            }
            return false;
        }
        return true;
    }

}
