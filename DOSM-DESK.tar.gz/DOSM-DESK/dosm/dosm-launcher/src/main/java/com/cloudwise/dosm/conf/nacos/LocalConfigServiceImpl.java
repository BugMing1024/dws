
package com.cloudwise.dosm.conf.nacos;

import cn.hutool.core.io.FileUtil;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.config.filter.IConfigFilter;
import com.alibaba.nacos.api.config.listener.Listener;
import com.alibaba.nacos.api.exception.NacosException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;

/**
 * 覆盖nacos工具类，变成本地工具类
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-10-08 16:50; update at 2024-10-08 16:50
 */
@Primary
@Component
public class LocalConfigServiceImpl implements ConfigService {

    @Value("${local.config.path:/data/app/dosmLauncher/conf/local/}")
    private String path;

    @Override
    public String getConfig(String s, String s1, long l) throws NacosException {
        return FileUtil.readString(path + s, Charset.defaultCharset());
    }

    @Override
    public String getConfigAndSignListener(String s, String s1, long l, Listener listener) throws NacosException {
        return FileUtil.readString(path + s, Charset.defaultCharset());
    }

    @Override
    public void addListener(String s, String s1, Listener listener) throws NacosException {

    }

    @Override
    public boolean publishConfig(String s, String s1, String s2) throws NacosException {
        return false;
    }

    @Override
    public boolean publishConfig(String s, String s1, String s2, String s3) throws NacosException {
        return false;
    }

    @Override
    public boolean publishConfigCas(String s, String s1, String s2, String s3) throws NacosException {
        return false;
    }

    @Override
    public boolean publishConfigCas(String s, String s1, String s2, String s3, String s4) throws NacosException {
        return false;
    }


    @Override
    public boolean removeConfig(String s, String s1) throws NacosException {
        return false;
    }

    @Override
    public void removeListener(String s, String s1, Listener listener) {

    }

    @Override
    public String getServerStatus() {
        return "";
    }

    @Override
    public void addConfigFilter(IConfigFilter iConfigFilter) {

    }


    @Override
    public void shutDown() throws NacosException {

    }
}

    