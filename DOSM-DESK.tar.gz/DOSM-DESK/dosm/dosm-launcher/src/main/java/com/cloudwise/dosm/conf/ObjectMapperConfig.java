package com.cloudwise.dosm.conf;

import com.cloudwise.dosm.api.bean.utils.NullKeySerializer;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.commons.lang3.ClassUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class ObjectMapperConfig {

    @Bean({"dosmObjectMapper"})
    @Primary
    public ObjectMapper dosmObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        objectMapper.getSerializerProvider().setNullKeySerializer(new NullKeySerializer());

        objectMapper.registerModule(new JavaTimeModule());

        try {
            //TODO 保证启动顺序， 在项目启动类型中提前 import ，无法保证非 spring环境单测时的模块注册
            String dataTypeModuleClassName = "com.cloudwise.dosm.facewall.lowcode.engine.data.type.json.DataTypeModule";
            Class<?> dataTypeModuleClass = ClassUtils.getClass(dataTypeModuleClassName);
        } catch(ClassNotFoundException ignored) {

        }
        return objectMapper;
    }
}
