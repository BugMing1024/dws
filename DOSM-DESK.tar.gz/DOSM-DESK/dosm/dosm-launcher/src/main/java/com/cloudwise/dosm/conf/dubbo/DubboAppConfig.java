package com.cloudwise.dosm.conf.dubbo;

import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.ApplicationConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * @Author frank.zheng
 * @Date 2023-04-28
 */
@Slf4j
@Configuration
public class DubboAppConfig {

    @Value("${dubbo.application.name}")
    private String name;

    @Bean
    @Primary
    public ApplicationConfig getAppConfig() {
        return new ApplicationConfig(name);
    }
}
