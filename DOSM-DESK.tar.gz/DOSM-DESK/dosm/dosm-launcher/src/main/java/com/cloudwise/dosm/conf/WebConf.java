package com.cloudwise.dosm.conf;

import cn.keking.interceptor.OnlinePreviewInterceptor;
import com.cloudwise.dosm.biz.guidance.interceptor.NoviceGuidanceInterceptor;
import com.cloudwise.dosm.biz.instance.interceptor.AuthUrlConfig;
import com.cloudwise.dosm.biz.instance.interceptor.ProcessInfoAuthInterceptor;
import com.cloudwise.dosm.biz.instance.interceptor.WorkOrderDetailAuthInterceptor;
import com.cloudwise.dosm.bpm.core.event.EventDoSendInterceptor;
import com.cloudwise.dosm.bpm.core.flow.FlowLocalCleaner;
import com.cloudwise.dosm.core.interceptor.AuthInterceptor;
import com.cloudwise.dosm.core.interceptor.BlacklistInterceptor;
import com.cloudwise.dosm.core.interceptor.FileInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping;
import springfox.documentation.spring.web.plugins.WebFluxRequestHandlerProvider;
import springfox.documentation.spring.web.plugins.WebMvcRequestHandlerProvider;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author frank.zheng
 * @Since 2021-06-26 11:09
 */
@Slf4j
@Configuration
public class WebConf implements WebMvcConfigurer {

    @Resource
    private AuthInterceptor authInterceptor;

    @Resource
    private EventDoSendInterceptor eventDoSendInterceptor;

    @Resource
    private NoviceGuidanceInterceptor noviceGuidanceInterceptor;

    @Resource
    private FlowLocalCleaner flowLocalCleaner;

    @Resource
    private FileInterceptor fileInterceptor;

    @Resource
    private BlacklistInterceptor blacklistInterceptor;

    @Resource
    private OnlinePreviewInterceptor onlinePreviewInterceptor;

    @Resource
    private WorkOrderDetailAuthInterceptor workOrderDetailAuthInterceptor;

    @Resource
    private ProcessInfoAuthInterceptor processInfoAuthInterceptor;

    @Value("${file.upload.temp.directory:file-uploads}")
    private String tmpDir;

    @Value("${file.upload.order.directory:order}")
    private String orderDir;



    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor).addPathPatterns("/api/v2/**")
                .addPathPatterns("/api/v1/**")
                .excludePathPatterns("/api/v2/open/api/orderCreate",
                        "/api/v2/webConfig/**",
                        "/api/v2/biz/acceptanceTask/trigger",
                        "/api/v2/biz/callback/dingCard",
                        "/api/v2/swagger/export/**",
                        "/api/v2/authentication/callBack",
                        "/api/v2/dbs/**",
                        "/api/v2/file/download",
                        "/api/v2/file/bulkDownload"
                );
        log.info("authInterceptor:{}", authInterceptor);

        registry.addInterceptor(eventDoSendInterceptor).addPathPatterns("/api/v2/**");
        log.info("eventDoSendInterceptor:{}",eventDoSendInterceptor);

        registry.addInterceptor(noviceGuidanceInterceptor).addPathPatterns("/api/v2/**");
        log.info("noviceGuidanceInterceptor:{}",noviceGuidanceInterceptor);

        registry.addInterceptor(flowLocalCleaner).addPathPatterns("/api/v2/**");
        log.info("eventDoSendInterceptor:{}",flowLocalCleaner);

        registry.addInterceptor(blacklistInterceptor).addPathPatterns("/api/v2/**", "/api/v1/**").excludePathPatterns("/api/v2/open/api/orderCreate", "/api/v2/biz/callback/dingCard", "/api/v2/webConfig/**","/api/v2/biz/acceptanceTask/trigger");
        log.info("blacklistInterceptor:{}",blacklistInterceptor);

        registry.addInterceptor(fileInterceptor).addPathPatterns("/api/v2/**/upload").addPathPatterns("/api/v2/**/uploadList");

        registry.addInterceptor(onlinePreviewInterceptor)
                .addPathPatterns("/api/v2/temp/preview/**","/api/v2/online/preview/**");


        registry.addInterceptor(workOrderDetailAuthInterceptor).addPathPatterns(AuthUrlConfig.workOrderDetailRefUrlList);

        registry.addInterceptor(processInfoAuthInterceptor).addPathPatterns(AuthUrlConfig.processInfoRefUrlList);
        log.info("添加授权拦截器AuthInterceptor");

    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String staticDir = "file:" + tmpDir + "/" + orderDir;
        //访问地址：url/file/order/c3818e23ae764a307144665898c2e589/d1309cdb-b871-4f8a-b5e9-78a84fc88287.png
        /*if(!staticDir.endsWith("/")){
            staticDir = staticDir +"/";
        }*/
        log.info("staticDir:{}", staticDir);

        registry.addResourceHandler("/file/**").addResourceLocations(staticDir);

        //映射static路径的请求到static目录下
        // swagger访问配置
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
        registry.addResourceHandler("doc.html")
                .addResourceLocations("classpath:/META-INF/resources/doc.html");
    }

    @Bean
    public BeanPostProcessor springfoxHandlerProviderBeanPostProcessor() {
        return new BeanPostProcessor() {
            @Override
            public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
                if (bean instanceof WebMvcRequestHandlerProvider || bean instanceof WebFluxRequestHandlerProvider) {
                    customizeSpringfoxHandlerMappings(getHandlerMappings(bean));
                }
                return bean;
            }

            private <T extends RequestMappingInfoHandlerMapping> void customizeSpringfoxHandlerMappings(List<T> mappings) {
                List<T> copy = mappings.stream()
                        .filter(mapping -> mapping.getPatternParser() == null)
                        .collect(Collectors.toList());
                mappings.clear();
                mappings.addAll(copy);
            }

            @SuppressWarnings("unchecked")
            private List<RequestMappingInfoHandlerMapping> getHandlerMappings(Object bean) {
                try {
                    Field field = ReflectionUtils.findField(bean.getClass(), "handlerMappings");
                    field.setAccessible(true);
                    return (List<RequestMappingInfoHandlerMapping>) field.get(bean);
                } catch (IllegalArgumentException | IllegalAccessException e) {
                    throw new IllegalStateException(e);
                }
            }
        };
    }

}
