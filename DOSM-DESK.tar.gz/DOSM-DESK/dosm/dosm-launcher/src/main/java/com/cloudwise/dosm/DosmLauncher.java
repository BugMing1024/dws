package com.cloudwise.dosm;

import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;

import com.alibaba.nacos.api.annotation.NacosInjected;
import com.alibaba.nacos.api.naming.NamingService;
import com.cloudwise.cache.lettuce.annotations.EnableLettuceRedis;
import com.cloudwise.cache.redisson.annotations.EnableRedisson;
import com.cloudwise.dosm.biz.model.def.service.IModelDefService;
import com.cloudwise.dosm.core.utils.SpringContextUtils;
import com.cloudwise.dosm.init.service.InitAccountDataService;
import com.cloudwise.dosm.mybatis.ext.type.SqlConstant;
import com.cloudwise.msg.annotations.Msg;
import com.cloudwise.storage.EnableFileStorage;

import lombok.extern.slf4j.Slf4j;


/**
 * 主工程启动入口
 *
 * @author admin
 */
@Slf4j
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class})
@ServletComponentScan({"com.cloudwise.dosm.slack.resource"})
//@EnableDiscoveryClient
@EnableDubbo(multipleConfig = true)
@EnableAspectJAutoProxy(exposeProxy = true)
@EnableAsync
@EnableRedisson
@EnableLettuceRedis
@ComponentScan(basePackages = {"com.cloudwise", "cn.keking"})
@EnableFileStorage
@Msg
@MapperScan(value = {"com.cloudwise"}, annotationClass = Mapper.class, nameGenerator = SpringBeanNameGenerator.class)
public class DosmLauncher extends SpringBootServletInitializer implements CommandLineRunner {

    @NacosInjected
    private NamingService namingService;



    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(DosmLauncher.class);
    }

    public static void main(String[] args) {
        log.info("===================================starting====================================");
        initProperty();
        SqlConstant.DB_TYPE = "mariadb";
        ApplicationContext app = SpringApplication.run(DosmLauncher.class, args);
        SpringContextUtils.applicationContext = app;
        log.info("===================================start success====================================");
    }

    @Autowired
    private InitAccountDataService initAccountDataService;
    @Autowired
    private IModelDefService modelDefService;




    @Override
    public void run(String... args) throws Exception {

        //租户初始化
        initAccountDataService.accountDataHandle();
        //初始化流程配额
        modelDefService.initProcessLck();
    }

    /**
     * dubbo日志初始化名称
     */
    private final static String DUBBO_LOG_NAME = "dubbo.application.logger";
    /**
     * dubbo日志初始化类型
     * <p>
     * enum slf4j,jcl,log4j,jdk,log4j2, default slf4j
     * </p>
     */
    private final static String DUBBO_LOG_TYPE = "slf4j";

    public static void initProperty() {
        System.setProperty(DUBBO_LOG_NAME, DUBBO_LOG_TYPE);
        System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
        System.setProperty("mybatis.configuration.database-id", "mariadb");
    }


}