package com.cloudwise.dosm;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.AnnotationBeanNameGenerator;
import org.springframework.util.Assert;

public class SpringBeanNameGenerator extends AnnotationBeanNameGenerator {

    public static final SpringBeanNameGenerator INSTANCE =
            new SpringBeanNameGenerator();


    @Override
    protected String buildDefaultBeanName(BeanDefinition definition) {
        String beanClassName = definition.getBeanClassName();
        //兼容代码
        if(definition.getBeanClassName().contains("com.cloudwise.dosm.facewall.extension")){
            beanClassName +="facewall_";
        }
        Assert.state(beanClassName != null, "No bean class name set");
        return beanClassName;

        
    }
}