package com.cloudwise.dosm.duty.test;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.dao.DutyLinkWorkOrderMapper;
import com.cloudwise.dosm.pojo.vo.DutyLinkWorkOrder;
import com.cloudwise.dosm.pojo.vo.DutyLinkWorkOrderParamVo;
import com.cloudwise.dosm.service.DutyLinkWorkOrderService;
import com.cloudwise.dosm.service.impl.DutyLinkWorkOrderServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.annotation.Resource;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/8/15 上午10:55
 **/
@Slf4j
public class DutyLinkWorkOrderServiceImplTest extends BaseTest {

    @Resource
    DutyLinkWorkOrderService dutyLinkWorkOrderService;

    @Test
    public void testGetWorkOrderList() {
        DutyLinkWorkOrderParamVo dutyLinkWorkOrderParamVo = new DutyLinkWorkOrderParamVo();
        dutyLinkWorkOrderParamVo.setTopAccountId("110");
        dutyLinkWorkOrderParamVo.setCurrentPage(1);
        dutyLinkWorkOrderParamVo.setPageSize(10);
        Page<DutyLinkWorkOrder> result = dutyLinkWorkOrderService.getWorkOrderList(dutyLinkWorkOrderParamVo);
        log.info("result is:{}", JSONUtil.toJsonStr(result));
    }
}
