package com.cloudwise.dosm;

import com.cloudwise.dosm.bpm.api.action.entity.ActionMessage;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.plugin.dynamic.handler.AdvanceExecutorRuleHandler;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Author dylan.qin
 * @Since: 2022-09-28 10:52
 */
@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {DosmLauncher.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AdvanceExcutorRuleHandlerTest {
    @Autowired
    AdvanceExecutorRuleHandler advanceExecutorRuleHandler;

    @Test
    public void handleTest(){
        String str ="{\n" +
                "    \"userId\":\"3\",\n" +
                "    \"parentMsgId\":null,\n" +
                "    \"eventType\":\"WORK_COMMIT\",\n" +
                "    \"processDefId\":\"pjdivfmv:6:8df40605-2ea3-11ed-9489-566f0f440012\",\n" +
                "    \"processInstanceId\":\"00d8a09f-3e3c-11ed-991e-566f0f440012\",\n" +
                "    \"nodeId\":\"UserTask_1ua9abz\",\n" +
                "    \"nodeName\":null,\n" +
                "    \"taskId\":\"018a647d-3e3c-11ed-991e-566f0f440012\",\n" +
                "    \"beforeUserId\":null,\n" +
                "    \"message\":{\n" +
                "        \"model\":[\n" +
                "            {\n" +
                "                \"key\":\"c27482e371fdc7aad37ed0b602da9a8c\",\n" +
                "                \"children\":[\n" +
                "                    {\n" +
                "                        \"key\":\"eaf485e4717e3587977ed87a7ea901a2\",\n" +
                "                        \"ciId\":\"\",\n" +
                "                        \"ciName\":\"\",\n" +
                "                        \"modelId\":\"test\",\n" +
                "                        \"modelAttr\":[\n" +
                "\n" +
                "                        ],\n" +
                "                        \"modelName\":\"dylan-模版\",\n" +
                "                        \"dataSources\":\"NO_TABLE_COMPONENT\"\n" +
                "                    }\n" +
                "                ],\n" +
                "                \"fieldKey\":\"1560106586797613058\",\n" +
                "                \"fieldName\":\"页签测试\",\n" +
                "                \"dosmConfigId\":\"\",\n" +
                "                \"dosmConfigName\":\"\"\n" +
                "            }\n" +
                "        ],\n" +
                "        \"executeTime\":{\n" +
                "            \"plan\":\"RIGHT_NOW\",\n" +
                "            \"delay\":{\n" +
                "\n" +
                "            },\n" +
                "            \"onTime\":{\n" +
                "\n" +
                "            }\n" +
                "        },\n" +
                "        \"selectAction\":\"PATCH_MODIFY_CUSTOM_CMDB_CONFIG\"\n" +
                "    },\n" +
                "    \"ignoreRowLimit\":true,\n" +
                "    \"tableTriggerRowSet\":null,\n" +
                "    \"assigneeResult\":null\n" +
                "}";
        ActionMessage actionMessage = JsonUtils.parseObject(str,ActionMessage.class);
        advanceExecutorRuleHandler.doExecute(actionMessage);



    }
}
