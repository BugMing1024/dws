package com.cloudwise.dosm.msg;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.bpm.api.action.entity.EventMessage;
import com.cloudwise.dosm.bpm.api.action.entity.duty.DutyNotifyMessage;
import com.cloudwise.dosm.bpm.api.process.entity.UserInfo;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.eventaction.ActionHandlerExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2022/6/22
 */
public class DutyMsgNotifyConsumerTest extends BaseTest {
    @Autowired
    private ActionHandlerExecutor actionHandlerExecutor;
    @Value("${dosm.duty.notify.topic:test}")
    private String topic;

    @Value("${dosm.duty.notify.tags:test}")
    private String tags;

    @org.testng.annotations.Test
    public void onMessage(){
        List<UserInfo> userIds = new ArrayList<>();
        UserInfo userInfo = new UserInfo();
        userInfo.setUserId("3");
        userIds.add(userInfo);
        DutyNotifyMessage dutyNotifyMessage = new DutyNotifyMessage("ON_DUTY_NOTIFY",new Date(),"","",userIds);

        dutyNotifyMessage.setTopic(topic);
        dutyNotifyMessage.setTags(tags);
        dutyNotifyMessage.setTopAccountId("110");
        dutyNotifyMessage.setAccountId("110");
        EventMessage eventMessage = new EventMessage();
        eventMessage.setEventType(dutyNotifyMessage.getEventType());
        eventMessage.setAssigneeResult(dutyNotifyMessage.getUserIds());
        eventMessage.setTopic(dutyNotifyMessage.getTopic());
        eventMessage.setFormData(JsonUtils.toJsonString(dutyNotifyMessage));
        eventMessage.setTopAccountId(dutyNotifyMessage.getTopAccountId());
        eventMessage.setAccountId(dutyNotifyMessage.getAccountId());
        eventMessage.setUserId(dutyNotifyMessage.getUserId());
        actionHandlerExecutor.execute(eventMessage);

    }
}
