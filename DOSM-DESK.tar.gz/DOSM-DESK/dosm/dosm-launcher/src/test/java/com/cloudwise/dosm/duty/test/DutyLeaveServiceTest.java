package com.cloudwise.dosm.duty.test;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.pojo.page.OldPage;
import com.cloudwise.dosm.pojo.po.DutyLeave;
import com.cloudwise.dosm.service.DutyLeaveService;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.BeforeMethod;

@Slf4j
public class DutyLeaveServiceTest extends BaseTest {

    @Autowired
    private DutyLeaveService dutyLeaveService;

    @BeforeMethod
    public void setUp()
    {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }

    @Test
    public void getDutyLeaveList() {
        OldPage<DutyLeave> dutyLeaveList = dutyLeaveService.getDutyLeaveList(1, 10, 1656518400000L, 1659196800000L, 0, null);
        log.info("getDutyLeaveList:{}",dutyLeaveList);
    }

    @Test
    public void getDutyLeaveByUser(){
        System.out.println(dutyLeaveService.getDutyLeaveByUser(1662393600000L, 1662825600000L,1,"3"));
    }
}