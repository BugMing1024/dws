package com.cloudwise.dosm;

import java.lang.reflect.Type;

import com.cloudwise.dosm.bpm.api.action.entity.ActionMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class Test {

	static final ObjectMapper om = new ObjectMapper();

	static final TypeFactory typeFactory = TypeFactory.defaultInstance();

	public static void main(String[] args) {

		String value = "{\"___tag$$$\":\"TAG_MSG\",\"payload\":{\"msgId\":\"b5ca8fe690b74b44b1df1496e45f953a\",\"accountId\":\"110\",\"topAccountId\":\"110\",\"timestamp\":1713320785861,\"source\":\"dosm\",\"topic\":\"TOPIC_DOSM_BPM_EVENTACTION\",\"tags\":\"*\",\"language\":\"zh\",\"userId\":\"1\",\"parentMsgId\":\"b5cfc922605041b4b7760c4f0de4a646\",\"eventType\":\"WORK_COMMIT\",\"processId\":null,\"processDefId\":\"vgkywgry:1:bffeaa56-e772-11ee-821f-566fa02b0057\",\"processInstanceId\":\"e30b4e07-fc61-11ee-83d7-8a8ec378d4cb\",\"nodeId\":\"UserTask_14b8wvf\",\"nodeName\":null,\"taskId\":\"e349687e-fc61-11ee-83d7-8a8ec378d4cb\",\"beforeUserId\":null,\"message\":{\"topAccountId\":\"110\",\"userId\":\"1\",\"msgSource\":\"SYSTEM_MSG\",\"title\":\"创建的工单被提交\",\"body\":\"【工单消息】您创建的工单 testtest 被 Admin 提交, 查看详情\",\"additional\":{\"orderId\":\"G81LokbZA5msFrY1z5R0DWTwv75W7ld8\",\"title\":\"testtest\",\"bizKey\":\"updateCI_A2024041700002\",\"dataStatus\":\"处理中\"},\"noticeWayTargetList\":[{\"notifyWay\":\"SYSTEM\",\"target\":[\"1\"],\"appId\":\"\",\"textFormat\":\"TEXT\",\"cardId\":null,\"channelCode\":\"SYSTEM\",\"files\":[],\"hyperLinkSwitch\":1}],\"weChatConfig\":null,\"language\":\"zh\",\"assigneeResult\":null,\"replyMessageId\":null,\"emailMessageId\":null,\"extendChannelId\":null,\"extendUsers\":null,\"processId\":null,\"executeTime\":{\"plan\":\"RIGHT_NOW\",\"delay\":{\"duration\":null,\"unit\":null},\"onTime\":{\"field\":null,\"time\":null,\"num\":null,\"unit\":null}},\"detailUrl\":null,\"sendMode\":null},\"ignoreRowLimit\":false,\"tableTriggerRowSet\":null,\"assigneeResult\":[],\"ruleId\":\"db5d10e3bafc427b968eeae91d1fc5a0\",\"advTitle\":null}}";

		String value2 = "{\"___tag$$$\":\"TAG_MSG\",\"payload\":123}";

		try {

			JsonNode jn = om.readTree(value);

			value = jn.findValue("payload").toString();

			System.out.println(value);

			JavaType javaType = getT(ActionMessage.class);

			Object t = om.readValue(value, javaType);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			JsonNode jn = om.readTree(value2);

			value = jn.findValue("payload").toString();

			System.out.println(value);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			System.out.println(om.writeValueAsString(123));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static JavaType getT(Class<?> clazz) {

		Type type = clazz;

		JavaType javaType = typeFactory.constructType(type);

		return javaType;
	}

}
