package com.cloudwise.dosm;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.base.PageVo;
import com.cloudwise.dosm.domain.request.DosmSystemListRequest;
import com.cloudwise.dosm.domain.response.DosmApiBodyVo;
import com.cloudwise.dosm.domain.response.DosmApiManageVo;
import com.cloudwise.dosm.domain.response.DosmApiParamVo;
import com.cloudwise.dosm.domain.response.DosmSystemClassifyVo;
import com.cloudwise.dosm.system.DosmSystemDubboServiceImpl;
import org.apache.commons.compress.utils.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @Author dylan.qin
 * @Since: 2023-08-16 10:05
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {DosmLauncher.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DosmSystemDubboServiceTest {


    @Autowired
    DosmSystemDubboServiceImpl dosmSystemDubboService;

    @Test
    public void getSystemClassifyListTest() {
        DosmSystemListRequest request = new DosmSystemListRequest();
        request.setUserId("3");
        request.setAccountId("110");
        request.setTopAccountId("110");

        DosmDubboResponse<List<DosmSystemClassifyVo>> response = dosmSystemDubboService.getSystemClassifyList(request);
        System.out.println(response);
    }

    @Test
    public void findApisTest() {
        DosmSystemListRequest request = new DosmSystemListRequest();
        request.setUserId("3");
        request.setAccountId("110");
        request.setTopAccountId("110");
        request.setCurrentPage(1);
        request.setPageSize(20);
        DosmDubboResponse<PageVo<DosmApiManageVo>> response = dosmSystemDubboService.findApis(request);
        System.out.println(response);
    }

//    @Test
//    public void addApiTest() {
//        DosmApiManageVo request = new DosmApiManageVo();
//        request.setUserId("3");
//        request.setAccountId("110");
//        request.setTopAccountId("110");
//        request.setApiGroupId("83dc2fe9388d401fa194317a00126718");
//        request.setApiName("test");
//        request.setRequestMode("POST");
//        request.setUrlPath("WWW.baidu.com");
//
//
//        String response = dosmSystemDubboService.addApi(request);
//        System.out.println(response);
//
//    }

//    @Test
//    public void updateApi() {
//        DosmApiManageVo request = new DosmApiManageVo();
//        request.setUserId("3");
//        request.setAccountId("110");
//        request.setTopAccountId("110");
//        request.setApiGroupId("83dc2fe9388d401fa194317a00126718");
//        request.setApiName("test");
//        request.setRequestMode("POST");
//        request.setUrlPath("WWW.baidu.com");
//        request.setId("879a6325b2514621862a3e567c14f07f");
//        DosmApiBodyVo bodyVo = new DosmApiBodyVo();
//        bodyVo.setBodyType("json");
//        List<DosmApiParamVo> params = Lists.newArrayList();
//        bodyVo.setParams(params);
//        request.setBody(bodyVo);
//        DosmApiParamVo apiParamVo = new DosmApiParamVo();
//        apiParamVo.setId("root");
//        apiParamVo.setParamName("root");
//        apiParamVo.setType("object");
//        params.add(apiParamVo);
//        List<DosmApiParamVo> children = Lists.newArrayList();
//        DosmApiParamVo apiParamVoChild = new DosmApiParamVo();
//        apiParamVoChild.setId("2f5e9fdb4086f37efc4456e0134c995e");
//        apiParamVoChild.setParamName("test");
//        apiParamVoChild.setType("string");
//        apiParamVoChild.setDescription("desc");
//        apiParamVoChild.setDefaultValue("test");
//        children.add(apiParamVoChild);
//        apiParamVo.setChildren(children);
//        List<DosmApiParamVo> query = Lists.newArrayList();
//        DosmApiParamVo dosmApiParamVo = new DosmApiParamVo();
//        dosmApiParamVo.setId("4f794e0e3dff8e4d4dbbf0a4b79de447");
//        dosmApiParamVo.setType("string");
//        query.add(dosmApiParamVo);
//        request.setQuery(query);
//        List<DosmApiParamVo> headers = Lists.newArrayList();
//        DosmApiParamVo header = new DosmApiParamVo();
//        header.setId("5e018300fa96e154148f78a2a41419e7");
//        header.setType("string");
//        headers.add(header);
//        request.setHeaders(headers);
//
//        DosmApiParamVo apiParamVoR = new DosmApiParamVo();
//        apiParamVoR.setId("root");
//        apiParamVoR.setParamName("root");
//        apiParamVoR.setType("object");
//        request.setResultBody(apiParamVoR);
//
//        String response = dosmSystemDubboService.updateApi(request);
//        System.out.println(response);
//
//
//    }

    @Test
    public void deleteByIdTest() {
        List<String> ids = Lists.newArrayList();
        ids.add("c42a1a0c4ca84a6d8c1c0dded7375e94");
        dosmSystemDubboService.deleteByIds(ids);

    }

}
