package com.cloudwise.dosm.duty.test;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.bpm.api.process.entity.UserInfo;
import com.cloudwise.dosm.bpm.core.event.EventSender;
import com.cloudwise.dosm.bpm.api.action.entity.duty.DutyNotifyMessage;
import com.cloudwise.dosm.bpm.enums.DutyNotifyMsgTypeEnum;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.job.service.DutyJobHandleService;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.UUID;

@Slf4j
public class DutyCautionServiceTest extends BaseTest {

    @Autowired
    private DutyJobHandleService dutyJobHandleService;

    @Autowired
    private EventSender eventSender;

    @BeforeMethod
    public void setUp()
    {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }

    @Test
    public void sendMessage() {
        RequestDomain requestDomain = UserHolder.get();
//        CommonBo paramBo = CommonBo.buildWith(requestDomain.getTopAccountId(),requestDomain.getAccountId(), requestDomain.getUserId(), 1, 10, requestDomain.getLanguage(),
//                requestDomain.getTraceId());
//        dutyJobHandleService.handle("");
        UserInfo userInfo = new UserInfo();
        userInfo.setUserId("3");
        userInfo.setAccountId("110");
        DutyNotifyMessage dutyNotifyMessage = new DutyNotifyMessage( DutyNotifyMsgTypeEnum.WAIT_RECEIVE_SHIFT.name(),null, "测试消息发送111", null,Lists.newArrayList(userInfo));

        dutyNotifyMessage.setAccountId(requestDomain.getAccountId());
        dutyNotifyMessage.setTopAccountId(requestDomain.getTopAccountId());
        dutyNotifyMessage.setLanguage(requestDomain.getLanguage());
        dutyNotifyMessage.setTimestamp(new Date().getTime());
        String id = UUID.randomUUID().toString().replaceAll("-","");
        log.info("msgId:{}",id);
        dutyNotifyMessage.setMsgId(id);
        eventSender.sendMsg(dutyNotifyMessage);
    }
}