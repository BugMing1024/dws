package com.cloudwise.dosm.email;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.job.service.EmailTicketingJobService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/4/5 10:31
 */

@Slf4j
public class EmailTicketingJobServiceTest extends BaseTest {
    
    @Autowired
    private EmailTicketingJobService emailTicketingJobService;
    
    @Test
    public void test() {
        emailTicketingJobService.handle("");
    }
    
}
