package com.cloudwise.dosm.email;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.email.dao.EmailWorkOrderRelationMapper;
import com.cloudwise.dosm.email.dto.EmailWorkOrderRelationRecord;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/4/4 09:27
 */

@Slf4j
public class EmailWorkOrderRelationMapperTest extends BaseTest {
    
    @Autowired
    private EmailWorkOrderRelationMapper mapper;
    
    @Test
    void insert() {
        EmailWorkOrderRelationRecord dto = new EmailWorkOrderRelationRecord();
        dto.setEmailId("1");
        dto.setWorkOrderId("1");
        dto.setAccountId("110");
        dto.setTopAccountId("110");
        int insert = mapper.insert(dto);
        log.info("aaa:{}", insert);
    }
    
    @Test
    void update() {
        EmailWorkOrderRelationRecord dto = new EmailWorkOrderRelationRecord();
        dto.setEmailId("1");
        dto.setAccountId("110");
        dto.setTopAccountId("110");
        List<String> ids = new ArrayList<String>();
        ids.add("3");
        dto.setReplyEmailIds(ids);
        int insert = mapper.update(dto);
        log.info("bbb:{}", insert);
    }
    
    @Test
    void select() {
        EmailWorkOrderRelationRecord dto = new EmailWorkOrderRelationRecord();
        dto.setEmailId("1");
        dto.setAccountId("110");
        dto.setTopAccountId("110");
        EmailWorkOrderRelationRecord info = mapper.selectInfoByEmailId(dto);
        log.info("info:{}", JsonUtils.toJsonString(info));
    }
    
    @Test
    void getWorkOrderRelation() {
        EmailWorkOrderRelationRecord dto = new EmailWorkOrderRelationRecord();
        dto.setWorkOrderId("db1c62836e3b4f7faff6695598a7d4ea");
        dto.setAccountId("110");
        dto.setTopAccountId("110");
        EmailWorkOrderRelationRecord record = mapper.selectInfoByWorkOrderId(dto);
        log.info("info:{}", JsonUtils.toJsonString(record));
    }
}
