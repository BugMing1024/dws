package com.cloudwise.dosm.duty.test;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.dao.DosmDutyRecordMapper;
import com.cloudwise.dosm.dao.DutyShiftMapper;
import com.cloudwise.dosm.douc.entity.BaseExtend;
import com.cloudwise.dosm.douc.entity.user.UserInfo;
import com.cloudwise.dosm.douc.service.UserService;
import com.cloudwise.dosm.pojo.bo.DutyUserInfo;
import com.cloudwise.dosm.pojo.po.DutyShift;
import com.cloudwise.dosm.pojo.vo.*;
import com.cloudwise.dosm.service.DosmDutyLogService;
import com.cloudwise.dosm.service.impl.DosmDutyLogServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.logging.Log;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/6/13 下午4:55
 **/
@Slf4j
public class DosmDutyLogServiceImplTest extends BaseTest {

    @Autowired
    DosmDutyLogService dosmDutyLogService;

    @BeforeMethod
    public void setUp()
    {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }

    @Test
    public void testAddDutyLog() {
        DutyLogAddParamVo dutyLogAddParamVo = new DutyLogAddParamVo();
        dutyLogAddParamVo.setDutyRecordId("111");
        dutyLogAddParamVo.setLogContent("test");
        dutyLogAddParamVo.setAttachment("test");
        String result = dosmDutyLogService.addDutyLog(dutyLogAddParamVo);
        log.info("TestAddDutyLog:{}",result);
    }

    @Test
    public void testUpdateDutyLog() {
        DutyLogUpdateParamVo dutyLogAddParamVo = new DutyLogUpdateParamVo();
        dutyLogAddParamVo.setId("c398ea3a80924a00bd5a121505f05ffc");
        dutyLogAddParamVo.setLogContent("tests");
        dutyLogAddParamVo.setAttachment("test");
        boolean result = dosmDutyLogService.updateDutyLog(dutyLogAddParamVo);
        Assert.assertTrue(result);
    }

    @Test
    public void testDeleteDutyLog() {
        String id="c398ea3a80924a00bd5a121505f05ffc";
        boolean result = dosmDutyLogService.deleteDutyLog(id);
        Assert.assertTrue(result);
    }

    @Test
    public void testGetCurrentUserShiftGroupNames() {
        List<DosmDutyShiftGroupVo> result = dosmDutyLogService.getCurrentUserShiftGroupNames();
        log.info("TestGetCurrentUserShiftGroupNames:{}",result);
    }

    @Test
    public void testGetShiftNameByShiftGroupId() {
        String shiftGroupId="6bbf01ba135c4949a20b9d97bd24bbe0";
        List<DutyShiftInfoVo> result = dosmDutyLogService.getShiftNameByShiftGroupId(shiftGroupId);
        log.info("TestGetShiftNameByShiftGroupId:{}",result);
    }

    @Test
    public void testGetDutyRecordPageList() {
        DutyLogQuaryParamVo dutyLogQuaryParamVo =  new DutyLogQuaryParamVo();
        dutyLogQuaryParamVo.setShiftGroupId("6bbf01ba135c4949a20b9d97bd24bbe0");
        dutyLogQuaryParamVo.setCurrentPage(1);
        dutyLogQuaryParamVo.setPageSize(10);
        Page<DutyRecordAndLogVo> result = dosmDutyLogService.getDutyRecordPageList(dutyLogQuaryParamVo);
        log.info("TestGetDutyRecordPageList:{}",result);

    }

    @Test
    public void testGetDutyRecordLog() {
        DutyLogQuaryParamVo dutyLogQuaryParamVo =  new DutyLogQuaryParamVo();
        dutyLogQuaryParamVo.setDutyRecordId("1");
        dutyLogQuaryParamVo.setCurrentPage(1);
        dutyLogQuaryParamVo.setPageSize(10);
        Page<DutyLogVo> dutyRecordLog = dosmDutyLogService.getDutyRecordLog(dutyLogQuaryParamVo);
        log.info("TestGetDutyRecordLog:{}",dutyRecordLog);
    }

    @Test
    public void testGetShiftUserNamesByShiftGroupId() {
        String shiftGroupId = "6bbf01ba135c4949a20b9d97bd24bbe0";
        List<DutyUserInfo> result = dosmDutyLogService.getShiftUserNamesByShiftGroupId(shiftGroupId);
        log.info("TestGetShiftUserNamesByShiftGroupId:{}",result);
    }
}
