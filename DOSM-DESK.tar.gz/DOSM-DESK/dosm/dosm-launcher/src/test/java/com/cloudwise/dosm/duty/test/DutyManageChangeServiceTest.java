package com.cloudwise.dosm.duty.test;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.pojo.page.OldPage;
import com.cloudwise.dosm.pojo.vo.DutyManageChange;
import com.cloudwise.dosm.service.DutyManageChangeService;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.BeforeMethod;

@Slf4j
public class DutyManageChangeServiceTest extends BaseTest {

    @Autowired
    private DutyManageChangeService dutyManageChangeService;

    @BeforeMethod
    public void setUp()
    {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }


    @Test
    public void getDutyManageChangeList() {
        RequestDomain requestDomain = UserHolder.get();
        OldPage<DutyManageChange> dutyManageChangeList = dutyManageChangeService.getDutyManageChangeList(requestDomain.getUserId(), requestDomain.getTopAccountId(), 1, 10, 1656518400000L, 1659196800000L, 0, null);
        log.info("getDutyLeaveList:{}",dutyManageChangeList);
    }
}