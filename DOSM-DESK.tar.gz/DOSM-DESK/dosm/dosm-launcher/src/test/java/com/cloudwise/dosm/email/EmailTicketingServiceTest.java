package com.cloudwise.dosm.email;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.pojo.vo.PageVo;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.email.dto.EmailTicketingRecord;
import com.cloudwise.dosm.email.service.EmailTicketingService;
import com.cloudwise.dosm.email.vo.RuleDisableVo;
import com.cloudwise.dosm.email.vo.RuleInfoVo;
import com.cloudwise.dosm.email.vo.RuleSearchResultVo;
import com.cloudwise.dosm.email.vo.RuleSearchVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/3/30 19:40
 */
@Slf4j
public class EmailTicketingServiceTest extends BaseTest {
    
    @Autowired
    private EmailTicketingService emailTicketingService;
    
    @BeforeEach
    public void init() {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }
    
    @Test
    public void findRules() {
        RuleSearchVo vo = new RuleSearchVo();
        vo.setRuleName("");
        PageVo<RuleSearchResultVo> rules = emailTicketingService.findRules(vo , null);
        log.info("info:{}", JsonUtils.toJsonString(rules));
    }
    
    @Test
    public void insertRule() {
        RuleInfoVo vo = new RuleInfoVo();
        vo.setRuleName("qi测试1-勿动");
        vo.setChannelType("EMAIL");
        vo.setChannelId("2");
        vo.setProcessId("e9bd5aa1b1ed4288ae8172316c16130e");
        vo.setEmailContentFillField("ticketDesc");
        vo.setEmailSubjectFillField("title");
        vo.setEmailAttachmentFillField("UPLOAD_9efc2144102d5");
        vo.setSenderEmailFillField("MEMBER_a5faa9cc76d2f");
        vo.setWhitelistType("3");
        vo.setDeclarationPersonSettings("1");
        vo.setNonOrganizationUsers("qiqi.yan@cloudwise.com");
        emailTicketingService.insertRule(vo, null);
    }
    
    @Test
    public void updateIsDisable() {
        RuleDisableVo vo = new RuleDisableVo();
        vo.setRuleId(3L);
        vo.setIsDisable(0);
        emailTicketingService.updateIsDisable(vo, null);
    }
    
    @Test
    public void getRuleInfoById() {
        RuleInfoVo ruleInfoById = emailTicketingService.getRuleInfoById(3L, null);
        log.info("123:{}", JsonUtils.toJsonString(ruleInfoById));
    }
    
    
    @Test
    public void deleteRuleById() {
        emailTicketingService.deleteRuleById(3L, null);
    }
    
    @Test
    public void getProcessIdByChannelId() {
        List<EmailTicketingRecord> info = emailTicketingService.getProcessIdByChannelId("1");
        log.info("123:{}", JsonUtils.toJsonString(info));
    }
}
