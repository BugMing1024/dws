//package com.cloudwise.dosm.email;
//
//import com.cloudwise.dosm.BaseTest;
//import com.cloudwise.dosm.email.service.EmailWorkOrderService;
//import com.cloudwise.email.model.dto.EmailAttachment;
//import com.cloudwise.email.model.dto.EmailMessageDetail;
//import lombok.extern.slf4j.Slf4j;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.io.File;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * @author qiqi.yan
// * @version 1.0
// * @date 2023/3/31 16:16
// */
//@Slf4j
//public class EmailWorkOrderServiceTest extends BaseTest {
//
//    @Autowired
//    private EmailWorkOrderService emailWorkOrderService;
//
//    @Test
//    public void createWorkOrder() {
//        EmailMessageDetail detail = new EmailMessageDetail();
//        detail.setId("678");
//        detail.setBody("邮件回复正文");
//        detail.setSubject("邮件回复标题");
//        detail.setSender("qiqi.yan@cloudwise.com");
//        File file = new File("/Users/qiqiyan/Downloads/child.html");
//        List<EmailAttachment> list = new ArrayList<EmailAttachment>();
//        EmailAttachment attachment = new EmailAttachment();
//        attachment.setFile(file);
//        attachment.setName("child.html");
//        attachment.setId("file1");
//        list.add(attachment);
//        detail.setAttachments(list);
//        detail.setReplyMessageId("123");
//        emailWorkOrderService.createWorkOrder(detail, "1", null);
//    }
//}
