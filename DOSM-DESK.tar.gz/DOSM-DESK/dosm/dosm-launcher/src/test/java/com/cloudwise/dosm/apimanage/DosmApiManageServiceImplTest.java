package com.cloudwise.dosm.apimanage;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.manage.api.service.DosmApiManageService;
import com.cloudwise.dosm.manage.api.vo.ApiParamVo;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/6/13 下午4:55
 **/
@Slf4j
public class DosmApiManageServiceImplTest extends BaseTest {

    @Autowired
    DosmApiManageService dosmApiManageService;

    @BeforeMethod
    public void setUp()
    {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }

    @Test
    public void testParseNode() {
        String s = "[{\"paramName\":\"root\",\"type\":\"object\",\"children\":[{\"paramName\":\"stu\",\"type\":\"array\",\"children\":[{\"paramName\":\"Items\",\"type\":\"object\",\"children\":[{\"defaultValue\":\"cscscs\",\"paramName\":\"name\",\"type\":\"string\",\"must\":false,\"id\":\"612a90b965e2623d71bdd8b52b44e940\"},{\"paramName\":\"age\",\"type\":\"object\",\"children\":[{\"defaultValue\":1,\"paramName\":\"zs\",\"type\":\"int\",\"must\":false,\"id\":\"3c0ca96ec8f2ae0b5946f5bcee28e138\"},{\"paramName\":\"xs\",\"type\":\"object\",\"children\":[{\"defaultValue\":\"cs\",\"paramName\":\"cs\",\"type\":\"string\",\"must\":false,\"id\":\"52231e78abb878d34374cf4c174ec806\"}],\"must\":false,\"id\":\"1a385a21f546f33c62cac417ac6e0a42\"},{\"paramName\":\"arr\",\"type\":\"array\",\"children\":[{\"paramName\":\"Items\",\"type\":\"object\",\"children\":[{\"defaultValue\":\"a\",\"paramName\":\"a\",\"type\":\"string\",\"must\":false,\"id\":\"f8d9be38f257b3312c5f25352ea960cf\"}],\"must\":false,\"id\":\"94f5f424f32807f478cb6d72f3e53910\"},{\"paramName\":\"Items\",\"type\":\"object\",\"children\":[{\"defaultValue\":\"b\",\"paramName\":\"a\",\"type\":\"string\",\"must\":false,\"id\":\"f8d9be38f257b3312c5f25352ea960cf\"}],\"must\":false,\"id\":\"94f5f424f32807f478cb6d72f3e53910\"}],\"must\":false,\"id\":\"056c5fd05a2a9ed2886d7283231e4c1b\"},{\"paramName\":\"arr2\",\"type\":\"array\",\"children\":[{\"defaultValue\":\"c\",\"paramName\":\"Items\",\"type\":\"string\",\"must\":false,\"id\":\"689679c4b9cada3fa010f0b97dd6e815\"},{\"defaultValue\":\"d\",\"paramName\":\"Items\",\"type\":\"string\",\"must\":false,\"id\":\"689679c4b9cada3fa010f0b97dd6e815\"}],\"must\":false,\"id\":\"b3db8c0d753de58059da6647c4511896\"}],\"must\":false,\"id\":\"cf56bb766cf84036f91b11d1032860e3\"}],\"must\":false,\"id\":\"e98da5e1960865268d8e022d4db1a28a\"}],\"must\":false,\"id\":\"82392529c218ae215edc5d4f7a87f55b\"}],\"must\":false,\"id\":\"root\"}]";
        List<ApiParamVo> apiParamVos = JsonUtils.parseObject(s, new TypeReference<List<ApiParamVo>>() {
        });
        JsonNode jsonNode = dosmApiManageService.parseJsonNode(apiParamVos);
        System.out.println(JsonUtils.toJsonString(jsonNode));
    }
}
