package com.cloudwise.dosm.duty.test;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.CommonBo;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.dao.DutyCautionMapper;
import com.cloudwise.dosm.pojo.bo.DutyRecordParam;
import com.cloudwise.dosm.pojo.page.OldPage;
import com.cloudwise.dosm.pojo.vo.DutyConditionColumnVo;
import com.cloudwise.dosm.pojo.vo.DutyRecordVo;
import com.cloudwise.dosm.service.DutyConditionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.List;

@Slf4j
public class DutyConditionServiceTest extends BaseTest {

    @Autowired
    private DutyConditionService dutyConditionService;
    @Autowired
    private DutyCautionMapper dutyCautionMapper;

    @BeforeMethod
    public void setUp()
    {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }

    @Test
    public void getDutyConditionCount() {
        RequestDomain requestDomain = UserHolder.get();
        CommonBo paramBo = CommonBo.buildWith(requestDomain.getTopAccountId(),requestDomain.getAccountId(), requestDomain.getUserId(), 1, 10, requestDomain.getLanguage(),
                requestDomain.getTraceId());
        dutyConditionService.getDutyConditionCount(1656518400000L,1659196800000L,"",paramBo,"" );
    }

    @Test
    void getDutyRecordCount() {
        RequestDomain requestDomain = UserHolder.get();
        CommonBo paramBo = CommonBo.buildWith(requestDomain.getTopAccountId(),requestDomain.getAccountId(), requestDomain.getUserId(), 1, 10, requestDomain.getLanguage(),
                requestDomain.getTraceId());
        DutyRecordParam dutyRecordParam = new DutyRecordParam();
        dutyRecordParam.setPageSize(10);
        dutyRecordParam.setCurrentPage(1);
        dutyRecordParam.setStartTime(new Date(1656518400000L));
        dutyRecordParam.setStartTime(new Date(1659196800000L));
        OldPage<DutyRecordVo> result = dutyConditionService.getDutyRecordCount(dutyRecordParam, paramBo);
        log.info("getDutyRecordCount:{}",result);
    }

    @Test
    void getDutyConditionColumns() {
        RequestDomain requestDomain = UserHolder.get();
        CommonBo paramBo = CommonBo.buildWith(requestDomain.getTopAccountId(),requestDomain.getAccountId(), requestDomain.getUserId(), 0, 0, requestDomain.getLanguage(),
                requestDomain.getTraceId());
        List<DutyConditionColumnVo> dutyConditionColumns = dutyConditionService.getDutyConditionColumns(0L,0L,"",paramBo, "",0);
        log.info("getDutyConditionColumns:{}",dutyConditionColumns);
    }

    @Test
    void exportDutyRecordExcel() {
//        RequestDomain requestDomain = UserHolder.get();
//        CommonBo paramBo = CommonBo.buildWith(requestDomain.getTopAccountId(),requestDomain.getAccountId(), requestDomain.getUserId(), 1, 10, requestDomain.getLanguage(),
//                requestDomain.getTraceId());
//        DutyRecordParam dutyRecordParam = new DutyRecordParam();
//        dutyRecordParam.setPageSize(10);
//        dutyRecordParam.setCurrentPage(1);
//        dutyRecordParam.setStartTime(new Date(1656518400000L));
//        dutyRecordParam.setStartTime(new Date(1659196800000L));
//        dutyConditionService.exportDutyRecordExcel(dutyRecordParam, paramBo);
    }
}