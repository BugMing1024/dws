package com.cloudwise.dosm.duty.enums;

public class DutyConfigTestConstant {

    public final static String TEST_DELETE_ID = "7507a382b19c46a1b0865e5f8c56c4ec";
}
