package com.cloudwise.dosm.duty.test;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.domain.request.DosmDutyShiftRequest;
import com.cloudwise.dosm.duty.DosmDutyService;
import com.cloudwise.dosm.pojo.vo.DutyCurrentUserShiftInfoVo;
import com.cloudwise.dosm.service.DutyShiftService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/6/13 下午4:44
 **/
@Slf4j
public class DutyShiftServiceImplTest extends BaseTest {
    @Autowired
    DutyShiftService dutyShiftService;
    @Autowired
    DosmDutyService dosmDutyService;

    @Test
    public void testGetShiftByCurrentUser() {
        String configId="232420d4f5ec48a985f0f59b47533132";
        List<DutyCurrentUserShiftInfoVo> result = dutyShiftService.getShiftByCurrentUser(configId);
        log.info("TestGetShiftByCurrentUser:{}",result);
    }

    @Test
    public void testGetDutyShiftUsers(){
        DosmDutyShiftRequest dosmDutyShiftRequest = new DosmDutyShiftRequest();
        dosmDutyShiftRequest.setAccountId("110");
        dosmDutyShiftRequest.setTopAccountId("110");
        dosmDutyShiftRequest.setUserId("3");
        ArrayList<String> ids = Lists.newArrayList();
        ids.add("271aa73ea6464fe38e2c8f382232ac0a");
        dosmDutyShiftRequest.setDutyShiftIds(ids);
        dosmDutyShiftRequest.setDutyTime(new Date(1817530860000L));
        dosmDutyShiftRequest.setStatus(1);
        Object data = dosmDutyService.getDutyShiftUsers(dosmDutyShiftRequest).getData();
        System.out.println(data);
    }

    @Test
    public void testGetDutyShifts(){
        DosmDutyShiftRequest dosmDutyShiftRequest = new DosmDutyShiftRequest();
        dosmDutyShiftRequest.setAccountId("110");
        dosmDutyShiftRequest.setTopAccountId("110");
        dosmDutyShiftRequest.setUserId("3");
        dosmDutyShiftRequest.setCurrentPage(1);
        dosmDutyShiftRequest.setPageSize(10);
        Object data = dosmDutyService.getDutyShifts(dosmDutyShiftRequest).getData();
        System.out.println(data);
    }
}
