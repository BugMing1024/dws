package com.cloudwise.dosm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description: TODO
 * @Author: terrell.huang
 * @Date: 2023-11-06 16-40
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CmdbConfigItem implements Serializable {
    private String attrID;
    private String title;
    private String fieldType;
    private String cmdbFieldType;
    private String key;
}