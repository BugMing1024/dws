package com.cloudwise.dosm.email;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.biz.model.def.vo.MdlProcessGroupQueryVo;
import com.cloudwise.dosm.bpm.base.vo.ProcessInfoVo;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.pojo.vo.PageVo;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.email.service.EmailProcessService;
import com.cloudwise.dosm.email.vo.FiledInfoVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/3/30 19:47
 */
@Slf4j
public class EmailProcessServiceTest extends BaseTest {
    
    @Autowired
    private EmailProcessService emailProcessService;
    
    @BeforeEach
    public void init() {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }
    
    @Test
    public void getProcessList() {
        MdlProcessGroupQueryVo queryVo = new MdlProcessGroupQueryVo();
        queryVo.setPageSize(8);
        queryVo.setCurrentPage(2);
        PageVo<ProcessInfoVo> processList = emailProcessService.getProcessList(queryVo);
        log.info("info:{}", JsonUtils.toJsonString(processList));
    }
    
    @Test
    public void getProcessInfo() {
        List<FiledInfoVo> processInfoVo = emailProcessService.getProcessInfo("64b9864f8907409198be0a1091c58bf6", null);
        log.info("info:{}", JsonUtils.toJsonString(processInfoVo));
    }
}
