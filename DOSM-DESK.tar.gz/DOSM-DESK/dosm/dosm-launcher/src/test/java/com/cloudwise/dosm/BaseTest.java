package com.cloudwise.dosm;

//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeSuite;

@SpringBootTest(classes = DosmLauncher.class)
//@AutoConfigureMockMvc
public class BaseTest extends AbstractTestNGSpringContextTests {

    public HttpHeaders header;

    /**
     * j加载Jvm参数
     */
    public static void loadJvmParam() {
//        System.setProperty("cwNacosServer", "10.0.2.68:18117");
        System.setProperty("cwNacosServer", "10.0.9.162:18117");
        System.setProperty("cwNacosUserName", "nacos");
        System.setProperty("cwNacosPassword", "kbRmjCIED/vXbOjxUudm649N+KSUmy/JpFm53hwPH0hTwEcBYxy3jl72Hw5C4dJHeoIBKaQpa1Vp+4s/iIEQVAbRlHvZ7EATKCidTbpSbP1/ceg18fQFBeSslNmnOZ8rvmoWZkQ/NPs6WmEXCpyGr6z1/vSyJwhtdpnYt8fSlDg=");
        System.setProperty("cwNacosNamespace", "PROD");
        System.setProperty("cwServicePort", "18301");
        System.setProperty("cwDbName", "dosm_activiti");
        System.setProperty("cwServiceHostname", "127.0.0.1");
        System.setProperty("cwMetricsPort", "18302");
        System.setProperty("cwMetricsHostname", "127.0.0.1");
        System.setProperty("cwRpcPort", "20881");
        System.setProperty("spring.profiles.active", "dev");

    }

    @BeforeSuite
    public void beforeAll() {
        loadJvmParam();
        //DosmDutyApplication.decodeArgs(null);
        header = new HttpHeaders();
        header.add("accountId", "110");
        header.add("topAccountId", "110");
        header.add("userId", "3");

    }


}
