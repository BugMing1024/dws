package com.cloudwise.dosm.core.no;

import com.cloudwise.dosm.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/2/1
 */
@Slf4j
public class WorkOrderNoMakerTest extends BaseTest {
    @Autowired
    WorkOrderNoMaker workOrderNoMaker;

    @Test
    public void makeNo() {
        WorkOrderNoRule workOrderNoRule = new WorkOrderNoRule();
        workOrderNoRule.setDateFormat("yyyyMMdd");
        workOrderNoRule.setNoLength(1);
        workOrderNoRule.setPrefix("norvalxu");
        for (int i = 0; i < 200; i++) {
            String no = workOrderNoMaker.makeNo(workOrderNoRule);
            log.info("生成的编号为:{}", no);
        }

    }
}