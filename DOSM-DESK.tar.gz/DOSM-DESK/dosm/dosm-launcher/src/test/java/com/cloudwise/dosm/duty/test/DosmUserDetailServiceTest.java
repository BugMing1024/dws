package com.cloudwise.dosm.duty.test;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.job.service.DosmUserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

public class DosmUserDetailServiceTest extends BaseTest {

    @Autowired
    private DosmUserDetailService dosmUserDetailService;

    @Test
    public void testSync(){
        dosmUserDetailService.sync("");
    }

}
