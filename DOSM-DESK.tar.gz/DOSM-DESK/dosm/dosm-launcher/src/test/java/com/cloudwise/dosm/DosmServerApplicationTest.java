package com.cloudwise.dosm;

import com.cloudwise.dosm.bpm.api.action.entity.ActionMessage;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.plugin.dynamic.handler.AdvanceExecutorRuleHandler;
import com.cloudwise.dosm.sla.entity.SlaJobCollection;
import com.cloudwise.dosm.sla.service.SlaUpgradeService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 单元测试
 *
 * @author: jensen.xu
 * @since: 2021/5/12 下午6:18
 **/
@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {DosmLauncher.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DosmServerApplicationTest {
    @Test
    public void test() {
        log.info("单元测试样例");
    }

    @Autowired
    SlaUpgradeService slaUpgradeService;
    @Test
    public void handleTest(){
        SlaJobCollection slaJobCollection = new SlaJobCollection();
//        String param = "{\n" +
//                "   \"topAccountId\":\"110\",\n" +
//                "\n" +
//                "   \"accountId\":\"110\",\n" +
//                "\n" +
//                "   \"userId\":\"2\",\n" +
//                "\n" +
//                "   \"processDefinitionId\":\"poyc:1:24aa2069-2b06-11ec-833a-c6acb6ed3e18\",\n" +
//                "\n" +
//                "   \"processInstanceId\":\"8964426a-2b06-11ec-833a-c6acb6ed3e18\",\n" +
//                "\n" +
//                "   \"nodeId\":\"UserTask_1x2m570\",\n" +
//                "\n" +
//                "   \"taskId\":\"89a1e7b6-2b06-11ec-833a-c6acb6ed3e18\",\n" +
//                "\n" +
//                "   \"language\":\"zh\",\n" +
//                "\"id\":\"66sad433faf4b4ed91dd1bf23a9999\"\n" +
//                "}";
        String param = "{\"id\":null,\"topAccountId\":\"110\",\"accountId\":\"110\",\"userId\":\"2\",\"processDefinitionId\":\"19fec813-2ca0-11ec-980f-7a21e80deaeb\",\"processInstanceId\":\"1d8cd6bd6553488eb466a4077664ded6\",\"nodeId\":\"UserTask_0o9tad1\",\"taskId\":\"1a0ea698-2ca0-11ec-980f-7a21e80deaeb\",\"language\":\"zh\"}";
        param = "{\"id\":\"b7f57276060a80a\",\"topAccountId\":\"110\",\"accountId\":\"110\",\"userId\":\"3\",\"processDefinitionId\":\"dcdefkao:1:6c13b15b-17b6-11ed-b458-566f1c300116\",\"processInstanceId\":\"862805fc-17b6-11ed-b458-566f1c300116\",\"nodeId\":\"UserTask_13ye2v6\",\"taskId\":\"86287b32-17b6-11ed-b458-566f1c300116\",\"language\":\"zh\",\"mdlInstanceId\":\"1620d99f35d910f89a5e66f92546e85f\"}";
        slaJobCollection.setParam(param);
        slaJobCollection.setSlaId("50ac318273d240fb88127b4c9f8ca002");

        slaUpgradeService.handle(slaJobCollection);
    }

@Autowired
    AdvanceExecutorRuleHandler ruleHandler;
    @Test
    public void handleAdvanceTest(){
        String msg = "{\"msgId\":\"c68ebdae6c57403995298395c235e309\",\"accountId\":\"110\",\"topAccountId\":\"110\",\"timestamp\":1646654360823,\"source\":\"dosm\",\"topic\":\"TOPIC_DOSM_BPM_EVENTACTION\",\"tags\":\"*\",\"language\":\"zh\",\"userId\":\"3\",\"parentMsgId\":null,\"eventType\":\"WORK_COMMIT\",\"processDefId\":\"ofpd:1:e7182d2c-9e0c-11ec-ac1c-566f1c30004a\",\"processInstanceId\":\"177d65cd-9e0d-11ec-ac1c-566f1c30004a\",\"nodeId\":\"UserTask_1j0jv9j\",\"nodeName\":null,\"taskId\":\"a254c270-9e0d-11ec-ac1c-566f1c30004a\",\"beforeUserId\":null,\"message\":{\"selectAction\":\"MODIFY_CUSTOM_CMDB_CONFIG\",\"model\":[{\"dosmConfigName\":\"配置项\",\"dosmConfigId\":\"CMDB_CONFIG_38394386\"}],\"executeTime\":{\"plan\":\"RIGHT_NOW\",\"onTime\":{},\"delay\":{}}},\"ignoreRowLimit\":true,\"tableTriggerRowSet\":null}";
        ActionMessage actionMessage = JsonUtils.parseObject(msg,ActionMessage.class);

    }
}