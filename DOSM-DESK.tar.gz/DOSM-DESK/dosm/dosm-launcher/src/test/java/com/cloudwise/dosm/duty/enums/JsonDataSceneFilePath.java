package com.cloudwise.dosm.duty.enums;

public enum JsonDataSceneFilePath {
    /**
     * 普通添加值班表
     */
    ADD_DUTY_CONFIG_1("testjson/duty/dutyConfigAdd.json"),

    /**
     * 修改值班表
     * */
    MODIFY_DUTY_CONFIG_1("testjson/duty/dutyConfigModify.json"),


    /**
     * 新增排班
     * */
    ADD_DUTY_MANAGE_1("testjson/duty/DutyManageAdd.json");

    private String dataSceneFilePath;

    JsonDataSceneFilePath(String dataSceneFilePath) {
        this.dataSceneFilePath = dataSceneFilePath;
    }


    public String getDataSceneFilePath(){
        return dataSceneFilePath;
    }


}
