package com.cloudwise.dosm.email;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.email.dao.EmailTicketingMapper;
import com.cloudwise.dosm.email.dto.EmailTicketingRecord;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/3/29 10:40
 */

@Slf4j
public class EmailTicketingMapperTest extends BaseTest {
    
    @Autowired
    private EmailTicketingMapper mapper;
    
    @Test
    public void insertRule() {
        EmailTicketingRecord record = new EmailTicketingRecord();
        record.setRuleName("testRule");
        record.setChannelType("email");
        record.setChannelId("testChannelId");
        record.setProcessId("testProcessInstanceId");
        record.setEmailSubjectFillField("testSubject");
        record.setEmailContentFillField("testContent");
        record.setEmailAttachmentFillField("testAttachment");
        record.setSenderEmailFillField("testSenderEmail");
        record.setDeclarationPersonSettings("testDeclarationSettings");
        record.setWhitelistType("testWhitelistType");
        record.setNonOrganizationUsers("testNonOrgUsers");
        record.setCreatedBy("testUser");
        record.setCreatedTime(new Date());
        record.setUpdatedBy("testUser");
        record.setUpdatedTime(new Date());
        record.setAccountId("110");
        record.setTopAccountId("110");
        int i = mapper.insertRule(record);
    }
    
    @Test
    public void deleteRuleById() {
        EmailTicketingRecord record = new EmailTicketingRecord();
        record.setId(1L);
        record.setAccountId("110");
        record.setTopAccountId("110");
        record.setIsDisable(1);
        List<EmailTicketingRecord> rules = mapper.findRules(record);
    
        EmailTicketingRecord ticketingRecord = rules.get(0);
        mapper.deleteRuleById(ticketingRecord);
    }
    
    @Test
    public void updateRule() {
        
        EmailTicketingRecord record = new EmailTicketingRecord();
        record.setId(1L);
        record.setAccountId("110");
        record.setTopAccountId("110");
        List<EmailTicketingRecord> rules = mapper.findRules(record);
    
        EmailTicketingRecord ticketingRecord = rules.get(0);
        ticketingRecord.setRuleName("updateRuleName");
        ticketingRecord.setUpdatedBy("3");
        ticketingRecord.setUpdatedTime(new Date());
        mapper.updateRule(ticketingRecord);
    }
    
    @Test
    public void findRules() {
        EmailTicketingRecord record = new EmailTicketingRecord();
        record.setId(1L);
        record.setAccountId("110");
        record.setTopAccountId("110");
        List<EmailTicketingRecord> rules = mapper.findRules(record);
        assertNotNull(rules);
    }
    
    @Test
    public void updateIsDisable() {
        EmailTicketingRecord record = new EmailTicketingRecord();
        record.setId(1L);
        record.setAccountId("110");
        record.setTopAccountId("110");
        List<EmailTicketingRecord> rules = mapper.findRules(record);
    
        EmailTicketingRecord ticketingRecord = rules.get(0);
        ticketingRecord.setIsDisable(1);
        mapper.updateIsDisable(ticketingRecord);
    }
}