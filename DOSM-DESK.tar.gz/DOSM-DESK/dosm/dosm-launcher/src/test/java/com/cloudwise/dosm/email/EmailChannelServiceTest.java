package com.cloudwise.dosm.email;

import com.cloudwise.dosm.BaseTest;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.pojo.vo.PageVo;
import com.cloudwise.dosm.core.utils.JacksonUtils;
import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.email.service.EmailChannelService;
import com.cloudwise.dosm.email.vo.ChannelInfoVo;
import com.cloudwise.dosm.email.vo.ChannelRequestInfoVo;
import com.cloudwise.douc.dto.DubboChannelRealConfigResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author qiqi.yan
 * @version 1.0
 * @date 2023/3/30 17:39
 */
@Slf4j
public class EmailChannelServiceTest extends BaseTest {
    
    @BeforeEach
    public void init() {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("3");
        requestDomain.setLanguage("cn");
        UserHolder.set(requestDomain);
    }
    
    @Autowired
    EmailChannelService emailChannelService;
    
    @Test
    public void queryChannelList() {
        ChannelRequestInfoVo infoVo = new ChannelRequestInfoVo();
        infoVo.setChannelCode("EMAIL");
        infoVo.setChannelName("邮箱");
        PageVo<ChannelInfoVo> infoVoPageVo = emailChannelService.queryChannelList(infoVo , null);
        log.info("info:{}", infoVoPageVo);
    }
    
    @Test
    public void getInfo() {
        DubboChannelRealConfigResponse channelConfigById = emailChannelService.getChannelConfigById(1L, null);
        log.info("12:{}", JacksonUtils.toJsonString(channelConfigById));
    }
}