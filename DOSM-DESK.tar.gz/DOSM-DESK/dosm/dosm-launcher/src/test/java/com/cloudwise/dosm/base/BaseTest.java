package com.cloudwise.dosm.base;

import com.cloudwise.dosm.DosmLauncher;
import com.cloudwise.dosm.core.pojo.bo.RequestDomain;
import com.cloudwise.dosm.core.utils.UserHolder;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeSuite;

@SpringBootTest(classes = DosmLauncher.class)
//@AutoConfigureMockMvc
public class BaseTest extends AbstractTestNGSpringContextTests {

    /**
     * j加载Jvm参数
     */
    public static void loadJvmParam() {
        System.setProperty("cwNacosServer", "10.0.16.163:18117");
        System.setProperty("cwNacosUserName", "nacos");
        System.setProperty("cwNacosPassword", "Nacos_654321");
        System.setProperty("cwNacosNamespace", "PROD");
        System.setProperty("cwServicePort", "18301");
        System.setProperty("cwDbName", "dosm_activiti");
        System.setProperty("cwServiceHostname", "127.0.0.1");
        System.setProperty("cwMetricsPort", "18302");
        System.setProperty("cwMetricsHostname", "127.0.0.1");
        System.setProperty("cwRpcPort", "20881");
        System.setProperty("spring.profiles.active", "dev");
    }

    @BeforeSuite
    public void beforeAll() {
        RequestDomain requestDomain = new RequestDomain();
        requestDomain.setAccountId("110");
        requestDomain.setTopAccountId("110");
        requestDomain.setUserId("9");
        UserHolder.set(requestDomain);
        loadJvmParam();
        //DosmLauncher.decodeArgs(null);
    }


}