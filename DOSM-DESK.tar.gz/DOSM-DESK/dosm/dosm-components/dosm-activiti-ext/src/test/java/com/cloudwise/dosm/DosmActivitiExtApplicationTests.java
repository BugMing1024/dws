package com.cloudwise.dosm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DosmActivitiExtApplicationTests {

    @Test
    void contextLoads() {
    }

}
