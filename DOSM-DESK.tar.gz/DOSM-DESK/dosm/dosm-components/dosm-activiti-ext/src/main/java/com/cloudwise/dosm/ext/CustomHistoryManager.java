package com.cloudwise.dosm.ext;

import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.history.DefaultHistoryManager;
import org.activiti.engine.impl.history.HistoryLevel;
import org.activiti.engine.impl.history.HistoryManager;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.VariableInstanceEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomHistoryManager extends DefaultHistoryManager implements HistoryManager {

	private static Logger log = LoggerFactory.getLogger(CustomHistoryManager.class);

	public CustomHistoryManager(ProcessEngineConfigurationImpl processEngineConfiguration, HistoryLevel historyLevel) {

		super(processEngineConfiguration, historyLevel);

	}

	@Override
	public void recordVariableCreate(VariableInstanceEntity variable) {

		log.debug("Do not persist data . ");
	}

	@Override
	public void recordHistoricDetailVariableCreate(VariableInstanceEntity variable,
			ExecutionEntity sourceActivityExecution, boolean useActivityId) {

		log.debug("Do not persist data . ");
	}

	@Override
	public void recordVariableUpdate(VariableInstanceEntity variable) {

		log.debug("Do not persist data . ");
	}

	@Override
	public void createAttachmentComment(String taskId, String processInstanceId, String attachmentName,
			boolean create) {

		log.debug("Do not persist data . ");
	}

	@Override
	public void recordVariableRemoved(VariableInstanceEntity variable) {

		log.debug("Do not persist data . ");
	}

}
