package com.cloudwise.dosm.ext;

/**
 * 扩展Activiti支持的自定义数据库类型
 *
 * @author jensen.xu
 * @since 1.0.0
 */
public class ExtDatabaseType {
    /**
     * 国产数据库：达梦数据库
     */
    public static final String DATABASE_TYPE_DM = "dm";

    /**
     * 国产数据库：华为 GaussDB T100 OLTP 数据库
     */
    public static final String DATABASE_TYPE_ZENITH = "zenith";

    /**
     * MariaDB  按照 mysql语法处理
     */
    public static final String DATABASE_TYPE_MARIADB = "mysql";

    enum ExtDatabaseTypeEnum {
        /**
         * 达梦数据库
         */
        DM("DM DBMS", DATABASE_TYPE_DM),

        /**
         * 华为 GaussDB T100 OLTP 数据库
         */
        ZENITH("Zenith", DATABASE_TYPE_ZENITH),

        /**
         * 华为 GaussDB T100 OLTP 数据库
         */
        MARIADB("MariaDB", DATABASE_TYPE_MARIADB);


        private String databaseProductName;
        private String databaseType;

        private ExtDatabaseTypeEnum(String databaseProductName, String databaseType) {
            this.databaseProductName = databaseProductName;
            this.databaseType = databaseType;
        }

        public String getDatabaseProductName() {
            return databaseProductName;
        }

        public String getDatabaseType() {
            return databaseType;
        }
    }
}
