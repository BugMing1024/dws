package com.cloudwise.dosm.ext;

import org.activiti.engine.impl.db.DbSqlSessionFactory;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.interceptor.Session;

/**
 * @author jensen.xu
 * @since 1.0.0
 */
public class MyDbSqlSessionFactory extends DbSqlSessionFactory {

    @Override
    public Session openSession(CommandContext commandContext) {
        return new NrDbSqlSession(this, commandContext.getEntityCache());
    }

}
