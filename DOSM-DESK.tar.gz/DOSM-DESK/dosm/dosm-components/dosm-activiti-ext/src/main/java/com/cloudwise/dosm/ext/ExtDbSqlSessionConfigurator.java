package com.cloudwise.dosm.ext;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.cfg.ProcessEngineConfigurator;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.util.IoUtil;
import org.activiti.engine.impl.util.ReflectUtil;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.defaults.DefaultSqlSessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Properties;

/**
 * @author jensen.xu
 * @since 1.0.0
 */
@Component
public class ExtDbSqlSessionConfigurator implements ProcessEngineConfigurator {

//    private static final String DATABASE_GBASE = "gbase";
//
//    private static final String DATABASE_DM = "dm";
//
//    private static final String DATABASE_GAUSSDB100 = "gaussdb100";
//
//    private static final String DATABASE_OSCAR = "oscar";
//
//    private static final Set<String> DB_SET = new HashSet<>();
//
//    static {
//        DB_SET.add(DATABASE_GBASE);
//        DB_SET.add(DATABASE_DM);
//        DB_SET.add(DATABASE_GAUSSDB100);
//        DB_SET.add(DATABASE_OSCAR);
//    }



    /**
     * 此出设置重写的NrDbSqlSessionFactory是为了处理Gbase8s不支持批量插入，其他数据库可不实现该方法
     */
    @Override
    public void beforeInit(ProcessEngineConfigurationImpl processEngineConfiguration) {
        //添加重写的SqlSessionFactory
//        processEngineConfiguration.setDbSqlSessionFactory(new MyDbSqlSessionFactory());
    }

    /**
     * ProcessEngineConfigurationImpl中的configuratorsAfterInit会执行到此处
     *
     * @param processEngineConfiguration 流程引擎配置类
     */
    @Override
    public void configure(ProcessEngineConfigurationImpl processEngineConfiguration) {
        //创建SqlSessionFactory并设置ProcessEngineConfigurationImpl
        processEngineConfiguration.setSqlSessionFactory(createSqlSessionFactory(processEngineConfiguration));
        //重新执行initDbSqlSessionFactory
        processEngineConfiguration.initDbSqlSessionFactory();

    }

    private SqlSessionFactory createSqlSessionFactory(ProcessEngineConfigurationImpl processEngineConfiguration) {
        InputStream inputStream = null;
        try {
            //读取的mappings.xm为了处理gbase8s的长字符串类型错误，不是gbase可以加载activiti默认的配置
            inputStream = getResourceAsStream(ProcessEngineConfigurationImpl.DEFAULT_MYBATIS_MAPPING_FILE);

            Environment environment = new Environment("default", processEngineConfiguration.getTransactionFactory(),
                    processEngineConfiguration.getDataSource());
            Reader reader = new InputStreamReader(inputStream);
            Properties properties = new Properties();
            properties.put("prefix", processEngineConfiguration.getDatabaseTablePrefix());
            String wildcardEscapeClause = "";
            if ((processEngineConfiguration.getDatabaseWildcardEscapeCharacter() != null)
                    && (processEngineConfiguration.getDatabaseWildcardEscapeCharacter().length() != 0)) {
                wildcardEscapeClause = " escape '" + processEngineConfiguration.getDatabaseWildcardEscapeCharacter() + "'";
            }
            properties.put("wildcardEscapeClause", wildcardEscapeClause);
            // set default properties
            properties.put("limitBefore", "");
            properties.put("limitAfter", "");
            properties.put("limitBetween", "");
            properties.put("limitOuterJoinBetween", "");
            properties.put("limitBeforeNativeQuery", "");
            properties.put("orderBy", "order by ${orderByColumns}");
            properties.put("blobType", "BLOB");
            properties.put("boolValue", "TRUE");

            if (processEngineConfiguration.getDatabaseType() != null) {
                properties.load(getResourceAsStream("org/activiti/db/properties/" + processEngineConfiguration.getDatabaseType() + ".properties"));
            }

            Configuration configuration = processEngineConfiguration.initMybatisConfiguration(environment, reader, properties);
            return new DefaultSqlSessionFactory(configuration);

        } catch (Exception e) {
            throw new ActivitiException("Error while building ibatis SqlSessionFactory: " + e.getMessage(), e);
        } finally {
            IoUtil.closeSilently(inputStream);
        }

    }

    private InputStream getResourceAsStream(String resource) {
        return ReflectUtil.getResourceAsStream(resource);
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
