package com.cloudwise.dosm.ext;

import org.activiti.engine.cfg.ProcessEngineConfigurator;
import org.activiti.engine.impl.bpmn.parser.factory.AbstractBehaviorFactory;
import org.activiti.engine.impl.bpmn.parser.factory.ActivityBehaviorFactory;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.springframework.stereotype.Component;

/**
 * 自定义流程引擎配置，用于注入CustomMappingAwareActivityBehaviorFactory
 * 
 * @author jon.lee
 * @since 2022-11-18 22:43
 **/
@Component
public class CustomProcessEngineConfigurator implements ProcessEngineConfigurator {

	private final ActivityBehaviorFactory activityBehaviorFactory;

	public CustomProcessEngineConfigurator(ActivityBehaviorFactory activityBehaviorFactory) {
		this.activityBehaviorFactory = activityBehaviorFactory;
	}

	@Override
	public void beforeInit(ProcessEngineConfigurationImpl processEngineConfiguration) {

	}

	@Override
	public void configure(ProcessEngineConfigurationImpl processEngineConfiguration) {
		// 自定义行为工厂，重写task参数冒泡逻辑
		ActivityBehaviorFactory org = processEngineConfiguration.getActivityBehaviorFactory();
		if (activityBehaviorFactory instanceof AbstractBehaviorFactory && org instanceof AbstractBehaviorFactory) {
			((AbstractBehaviorFactory) activityBehaviorFactory)
					.setExpressionManager(((AbstractBehaviorFactory) org).getExpressionManager());
		}
		processEngineConfiguration.setActivityBehaviorFactory(activityBehaviorFactory);
		processEngineConfiguration.getBpmnParser().setActivityBehaviorFactory(activityBehaviorFactory);

		processEngineConfiguration.setHistoryManager(
				new CustomHistoryManager(processEngineConfiguration, processEngineConfiguration.getHistoryLevel()));
	}

	@Override
	public int getPriority() {
		return 0;
	}

}
