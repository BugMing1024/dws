package com.cloudwise.dosm.ext;

import org.activiti.core.common.spring.project.ProjectModelService;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 自定义实现Activiti配置类
 *
 * @author jensen.xu
 * @since 1.0.0
 */
public class ExtSpringProcessEngineConfiguration extends SpringProcessEngineConfiguration {
    private static Logger log = LoggerFactory.getLogger(ExtSpringProcessEngineConfiguration.class);

    public ExtSpringProcessEngineConfiguration(ProjectModelService projectModelService) {
        super(projectModelService);
    }

    public static final String DATABASE_TYPE_DM = "dm";
    public static final String DATABASE_TYPE_Zenith = "zenith";

    protected static Properties databaseTypeMappings = getDefaultDatabaseTypeMappings();

    public static Properties getDefaultDatabaseTypeMappings() {
        Properties databaseTypeMappings = ProcessEngineConfigurationImpl.getDefaultDatabaseTypeMappings();
        databaseTypeMappings.setProperty("DM DBMS", DATABASE_TYPE_DM);
        databaseTypeMappings.setProperty("Zenith", DATABASE_TYPE_Zenith);
        return databaseTypeMappings;
    }

    @Override
    public void initDatabaseType() {
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
            DatabaseMetaData databaseMetaData = connection.getMetaData();
            String databaseProductName = databaseMetaData.getDatabaseProductName();
            log.debug("database product name: '{}'", databaseProductName);
            databaseType = databaseTypeMappings.getProperty(databaseProductName);
            if (databaseType == null) {
                throw new ActivitiException("couldn't deduct database type from database product name '" + databaseProductName + "'");
            }
            log.debug("using database type: {}", databaseType);

            // Special care for MSSQL, as it has a hard limit of 2000 params per statement (incl bulk statement).
            // Especially with executions, with 100 as default, this limit is passed.
            if (DATABASE_TYPE_MSSQL.equals(databaseType)) {
                maxNrOfStatementsInBulkInsert = DEFAULT_MAX_NR_OF_STATEMENTS_BULK_INSERT_SQL_SERVER;
            }

        } catch (SQLException e) {
            log.error("Exception while initializing Database connection", e);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                log.error("Exception while closing the Database connection", e);
            }
        }
    }
}
