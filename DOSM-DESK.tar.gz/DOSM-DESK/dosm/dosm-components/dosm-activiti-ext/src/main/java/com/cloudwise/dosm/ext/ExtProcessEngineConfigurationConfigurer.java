package com.cloudwise.dosm.ext;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.cfg.ProcessEngineConfigurator;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.history.HistoryLevel;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.activiti.spring.boot.ProcessEngineConfigurationConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 扩展Activiti模式实现
 *
 * @author jensen.xu
 * @since 1.0.0
 */
@Configuration
public class ExtProcessEngineConfigurationConfigurer implements ProcessEngineConfigurationConfigurer {
    private static Logger log = LoggerFactory.getLogger(ExtProcessEngineConfigurationConfigurer.class);

    @Autowired
    private ExtDbSqlSessionConfigurator extDbSqlSessionConfigurator;

    @Autowired
    private CustomProcessEngineConfigurator customProcessEngineConfigurator;

    @Override
    public void configure(SpringProcessEngineConfiguration processEngineConfiguration) {
        log.info("扫描到Activiti扩展实现，开始执行扩展配置");
        // 设置数据库类型
        String databaseType = initDatabaseType(processEngineConfiguration.getDataSource());
        processEngineConfiguration.setDatabaseType(databaseType);
        // 设置历史记录级别
        processEngineConfiguration.setHistoryLevel(HistoryLevel.AUDIT);
        // 开始历史表
        processEngineConfiguration.setDbHistoryUsed(true);
        // 设置为关系型数据库，只执行初始检测并执行创建语句
        processEngineConfiguration.setUsingRelationalDatabase(true);
        processEngineConfiguration.setAsyncExecutorActivate(false);

        List<ProcessEngineConfigurator> configurators = new ArrayList<>();
        configurators.add(extDbSqlSessionConfigurator);
        configurators.add(customProcessEngineConfigurator);
        processEngineConfiguration.setConfigurators(configurators);
        log.info("扫描到Activiti扩展实现，扩展配置执行完成");
    }

    /**
     * 数据库类型映射表
     * 根据适配的类型自定义添加`
     */
    private static final Properties DATABASE_TYPE_MAPPINGS = getDefaultDatabaseTypeMappings();

    private static Properties getDefaultDatabaseTypeMappings() {
        Properties databaseTypeMappings = ProcessEngineConfigurationImpl.getDefaultDatabaseTypeMappings();
        databaseTypeMappings.setProperty(ExtDatabaseType.ExtDatabaseTypeEnum.DM.getDatabaseProductName(), ExtDatabaseType.ExtDatabaseTypeEnum.DM.getDatabaseType());
        databaseTypeMappings.setProperty(ExtDatabaseType.ExtDatabaseTypeEnum.ZENITH.getDatabaseProductName(), ExtDatabaseType.ExtDatabaseTypeEnum.ZENITH.getDatabaseType());
        databaseTypeMappings.setProperty(ExtDatabaseType.ExtDatabaseTypeEnum.MARIADB.getDatabaseProductName(), ExtDatabaseType.ExtDatabaseTypeEnum.MARIADB.getDatabaseType());
        return databaseTypeMappings;
    }

    private String initDatabaseType(DataSource dataSource) {
        Connection connection = null;
        String databaseType = null;
        try {
            connection = dataSource.getConnection();
            DatabaseMetaData databaseMetaData = connection.getMetaData();
            String databaseProductName = databaseMetaData.getDatabaseProductName();
            log.debug("database product name: '{}'", databaseProductName);
            databaseType = DATABASE_TYPE_MAPPINGS.getProperty(databaseProductName);
            if (databaseType == null) {
                throw new ActivitiException("couldn't deduct database type from database product name '" + databaseProductName + "'");
            }

        } catch (SQLException e) {
            log.error("Exception while initializing Database connection", e);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                log.error("Exception while closing the Database connection", e);
            }
        }
        return databaseType;
    }
}
