package com.cloudwise.dosm.ext;

import org.activiti.engine.impl.db.DbSqlSession;
import org.activiti.engine.impl.db.DbSqlSessionFactory;
import org.activiti.engine.impl.persistence.cache.EntityCache;
import org.activiti.engine.impl.persistence.entity.Entity;

import java.util.Collection;

/**
 * @author jensen.xu
 * @since 1.0.0
 */
public class NrDbSqlSession extends DbSqlSession {

//    private static final Logger log = LoggerFactory.getLogger(NrDbSqlSession.class);

    public NrDbSqlSession(DbSqlSessionFactory dbSqlSessionFactory, EntityCache entityCache) {
        super(dbSqlSessionFactory, entityCache);
    }

    /**
     * 重写此方法是为了解决gbase不支持批量插入的问题
     * @param entityClass
     * @param entitiesToInsert
     */
    @Override
    protected void flushInsertEntities(Class<? extends Entity> entityClass, Collection<Entity> entitiesToInsert) {
        if (entitiesToInsert.size() == 1) {
            flushRegularInsert(entitiesToInsert.iterator().next(), entityClass);
        }else {
            for (Entity entity : entitiesToInsert) {
                flushRegularInsert(entity, entityClass);
            }
        }
    }

}
