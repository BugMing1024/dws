package com.cloudwise.dosm.mybatis.ext.dialect;

import com.cloudwise.dosm.mybatis.ext.dialect.impl.CustomGaussDialect;
import com.cloudwise.dosm.mybatis.ext.dialect.impl.CustomMysqlDialect;
import com.cloudwise.dosm.mybatis.ext.dialect.impl.CustomPostgreSQLDialect;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @Author frank.zheng
 * @Date 2023-11-17
 */
class ICustomDialectTest {


    @Test
    void getSql4JsonColumnProperty() {
        String jsonColumn = "formData";
        String[] propertys = {"user", "suerId"};


        String gaussSql = CustomGaussDialect.INSTANCE.getSql4JsonColumnProperty(jsonColumn, propertys);
        Assertions.assertEquals(gaussSql, "JSON_VALUE(formData, '$.user.suerId')");


        String mysqlSql = CustomMysqlDialect.INSTANCE.getSql4JsonColumnProperty(jsonColumn, propertys);
        Assertions.assertEquals(mysqlSql, "JSON_VALUE(formData, '$.user.suerId')");

        String pgSql = CustomPostgreSQLDialect.INSTANCE.getSql4JsonColumnProperty(jsonColumn, propertys);
        Assertions.assertEquals(pgSql, "formData->'user'->>'suerId'");
    }

    @Test
    void testGetSql4JsonColumnProperty() {
        String jsonColumn = "formData";
        String[] propertys = {"user", "dep", "name"};
        boolean[] isFix = {false, true, false};

        String gaussSql = CustomGaussDialect.INSTANCE.getSql4JsonColumnProperty(jsonColumn, propertys, isFix);
        Assertions.assertEquals(gaussSql, "JSON_VALUE(formData, CONCAT('$', '.', #{user}, '.dep', '.', #{name}))");

        String mysqlSql = CustomMysqlDialect.INSTANCE.getSql4JsonColumnProperty(jsonColumn, propertys, isFix);
        Assertions.assertEquals(mysqlSql, "JSON_VALUE(formData, '$.${user}.dep.${name}')");

        String pgSql = CustomPostgreSQLDialect.INSTANCE.getSql4JsonColumnProperty(jsonColumn, propertys, isFix);
        Assertions.assertEquals(pgSql, "formData->#{user}->'dep'->>#{name}");
    }
}