package com.cloudwise.dosm.mybatis.ext.type;

import cn.hutool.core.map.MapUtil;
import com.baomidou.mybatisplus.annotation.DbType;
import com.cloudwise.dosm.mybatis.ext.dialect.ICustomDialect;
import com.cloudwise.dosm.mybatis.ext.dialect.impl.CustomGaussDialect;
import com.cloudwise.dosm.mybatis.ext.dialect.impl.CustomMysqlDialect;
import com.cloudwise.dosm.mybatis.ext.dialect.impl.CustomPostgreSQLDialect;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Map;

/**
 * @Author: ksana.kong
 * @Date: 2022/4/12 9:19 下午
 * @Description: 数据库类型
 */
@Getter
@AllArgsConstructor
public enum DBTypeEnum {

    ZENITH(DbType.GAUSS.getDb(), CustomGaussDialect.INSTANCE),
    POSTGRES(DbType.POSTGRE_SQL.getDb(), CustomPostgreSQLDialect.INSTANCE),
    OCEANBASE_MYSQL(DbType.MYSQL.getDb(), CustomMysqlDialect.INSTANCE),
    OTHER(DbType.OTHER.getDb(), null),
    MARIADB(DbType.MARIADB.getDb(), CustomMysqlDialect.INSTANCE);

    private String dbType;

    private ICustomDialect dialect;


    private final static Map<String, DBTypeEnum> DB_TYPE_MAP = MapUtil.newHashMap();

    public static DBTypeEnum getDBType(String dbType) {
        if(MapUtil.isEmpty(DB_TYPE_MAP)) {
            Arrays.stream(DBTypeEnum.values()).forEach(item -> DB_TYPE_MAP.put(item.getDbType(), item));
        }

        return DB_TYPE_MAP.get(dbType);
    }


}
