package com.cloudwise.dosm.mybatis.ext.dialect;

/**
 * 自定义方言
 * @Author frank.zheng
 * @Since 2023-11-17 11:40
 */
public interface ICustomDialect {

    /**
     * 获取 JSON 列中的固定属性 sql
     * <p>样例："jsonColumn->'prop0'->>'prop1'"; "jsonColumn ->> '$.prop0.prop1'"; "JSON_VALUE(jsonColumn, '$.prop0.prop1')";
     * @param sqlBuilder
     * @param jsonColumn
     * @param fixPropertys 固定属性code
     * @return
     */
    void buildSql4JsonColumnProperty(StringBuilder sqlBuilder, String jsonColumn, String... fixPropertys);

    /**
     * 获取 JSON 列中的 固定属性 与 动态变量属性 sql
     * <p>如果是动态属性在sql中需要使用 ${} 避免被添加''
     * <p> 如："jsonColumn->#{prop0}->>'prop1'"; "jsonColumn ->> '$.${prop0}.prop1'";
     * <p>     "JSON_VALUE(jsonColumn, CONCAT('$', '.', #{prop0}, '.prop1'))"; "JSON_VALUE(jsonColumn, '$.${prop0}.prop1')"
     * @param jsonColumn
     * @param propertys 属性code信息
     * @param isFixs 是否固定属性, 默认是固定属性
     * @return
     */
    void buildSql4JsonColumnProperty(StringBuilder sqlBuilder, String jsonColumn, String[] propertys, boolean[] isFixs);


    /**
     * 获取 JSON 列中的固定属性 sql
     * <p>样例："jsonColumn->'prop0'->>'prop1'"; "jsonColumn ->> '$.prop0.prop1'"; "JSON_VALUE(jsonColumn, '$.prop0.prop1')";
     * @param jsonColumn
     * @param fixPropertys 固定属性code
     * @return
     */
    default String getSql4JsonColumnProperty(String jsonColumn, String... fixPropertys) {
        StringBuilder sqlBuilder = new StringBuilder();
        buildSql4JsonColumnProperty(sqlBuilder, jsonColumn, fixPropertys);
        return sqlBuilder.toString();
    }


    /**
     * 获取 JSON 列中的 固定属性 与 动态变量属性 sql
     * <p>如果是动态属性在sql中需要使用 ${} 避免被添加''
     * <p> 如："jsonColumn->#{prop0}->>'prop1'"; "jsonColumn ->> '$.${prop0}.prop1'";
     * <p>     "JSON_VALUE(jsonColumn, CONCAT('$', '.', #{prop0}, '.prop1'))"; "JSON_VALUE(jsonColumn, '$.${prop0}.prop1')"
     * @param jsonColumn
     * @param propertys 属性code信息
     * @param isFixs 是否固定属性, 默认是固定属性
     * @return
     */
    default String getSql4JsonColumnProperty(String jsonColumn, String[] propertys, boolean[] isFixs) {
        StringBuilder sqlBuilder = new StringBuilder();
        buildSql4JsonColumnProperty(sqlBuilder, jsonColumn, propertys, isFixs);
        return sqlBuilder.toString();
    }
}