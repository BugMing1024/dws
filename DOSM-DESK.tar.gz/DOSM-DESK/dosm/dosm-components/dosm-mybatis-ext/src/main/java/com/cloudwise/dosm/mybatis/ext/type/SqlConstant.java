package com.cloudwise.dosm.mybatis.ext.type;


/**
 * @Author: ksana.kong
 * @Date: 2022/4/12 9:41 下午
 * @Description: *
 */


public class SqlConstant {

    public   static String TYPE = "type";

    public   static String VALUE = "value";

    public   static String DB_TYPE ;

    private static DBTypeEnum DB_TYPE_ENUM;

    public static DBTypeEnum getDBType() {
        return DB_TYPE_ENUM == null? DB_TYPE_ENUM = DBTypeEnum.getDBType(DB_TYPE): DB_TYPE_ENUM;
    }

}
