package com.cloudwise.dosm.mybatis.ext.type;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.TypeException;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.sql.*;
import java.sql.Date;
import java.time.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static com.cloudwise.dosm.mybatis.ext.type.DBTypeEnum.*;

/**
 * @Author frank.zheng
 * @Since 2021-06-15 17:39
 * 目前使用到这个地方 为字符串数组
 * postgres 没问题
 * gauss数据库暂且兼容字符串,其他类型会有问题 后续慎用
 */
@MappedJdbcTypes(JdbcType.ARRAY)
@Slf4j
public class ListTypeHandler extends BaseTypeHandler<List<?>> {

    private static final ConcurrentHashMap<Class<?>, String> STANDARD_MAPPING = new ConcurrentHashMap();

    private final ObjectMapper jackson = new ObjectMapper();

    @Override
    public void setNonNullParameter(PreparedStatement ps, int columnIndex, List<?> parameterList, JdbcType jdbcType) throws SQLException {
        if (parameterList == null) {

            if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
                return;
            } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
                ps.setNull(columnIndex, JdbcType.ARRAY.TYPE_CODE);
                return;
            } else {
                ps.setNull(columnIndex, JdbcType.ARRAY.TYPE_CODE);
                return;
            }

        }
        if (parameterList instanceof Array) {

            if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
                try {
                    ps.setObject(columnIndex, jackson.writeValueAsString(parameterList));
                } catch (JsonProcessingException e) {
                    throw new TypeException("Gauss ArrayType2Handler parameter handler error");
                }

            } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
                //postgres 处理
                ps.setArray(columnIndex, (Array) parameterList);
            } else {
                //默认处理
                ps.setArray(columnIndex, (Array) parameterList);
            }

        } else {

            if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
                try {
                    ps.setObject(columnIndex, jackson.writeValueAsString(parameterList));
                } catch (JsonProcessingException e) {
                    throw new TypeException("Gauss ArrayType2Handler parameter handler error");
                }

            } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
                //postgres 处理
                Array array = ps.getConnection().createArrayOf(jdbcType.name(), parameterList.toArray());
                ps.setArray(columnIndex, array);
                array.free();
            } else {
                //默认处理
                Array array = ps.getConnection().createArrayOf(jdbcType.name(), parameterList.toArray());
                ps.setArray(columnIndex, array);
                array.free();
            }

        }
    }

    @Override
    public List<?> getNullableResult(ResultSet rs, String columnName) throws SQLException {
        //目前使用到这个地方 为字符串数组 暂且兼容字符串  后续慎用
        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            List<String> result = new ArrayList<>();
            try {
                result = jackson.readValue(rs.getString(columnName), new TypeReference<List<String>>() {});
            } catch (JsonProcessingException e) {
                throw new TypeException("Gauss ArrayType2Handler parameter handler error");
            }
            return result;
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 处理
            return this.extractArray(rs.getArray(columnName));
        } else {
            //默认处理
            return this.extractArray(rs.getArray(columnName));
        }

    }

    @Override
    public List<?> getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return this.extractArray(rs.getArray(columnIndex));
    }

    @Override
    public List<?> getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return this.extractArray(cs.getArray(columnIndex));
    }

    protected String resolveTypeName(Class<?> type) {
        return STANDARD_MAPPING.getOrDefault(type, JdbcType.ARRAY.name());
    }

    protected List<?> extractArray(Array array) throws SQLException {
        if (array == null) {
            return null;
        } else {
            List<?> result = new ArrayList<>(Arrays.asList((Object[]) array.getArray()));
            array.free();
            return result;
        }
    }

    static {
        STANDARD_MAPPING.put(BigDecimal.class, JdbcType.NUMERIC.name());
        STANDARD_MAPPING.put(BigInteger.class, JdbcType.BIGINT.name());
        STANDARD_MAPPING.put(Boolean.TYPE, JdbcType.BOOLEAN.name());
        STANDARD_MAPPING.put(Boolean.class, JdbcType.BOOLEAN.name());
        STANDARD_MAPPING.put(byte[].class, JdbcType.VARBINARY.name());
        STANDARD_MAPPING.put(Byte.TYPE, JdbcType.TINYINT.name());
        STANDARD_MAPPING.put(Byte.class, JdbcType.TINYINT.name());
        STANDARD_MAPPING.put(Calendar.class, JdbcType.TIMESTAMP.name());
        STANDARD_MAPPING.put(Date.class, JdbcType.DATE.name());
        STANDARD_MAPPING.put(java.util.Date.class, JdbcType.TIMESTAMP.name());
        STANDARD_MAPPING.put(Double.TYPE, JdbcType.DOUBLE.name());
        STANDARD_MAPPING.put(Double.class, JdbcType.DOUBLE.name());
        STANDARD_MAPPING.put(Float.TYPE, JdbcType.REAL.name());
        STANDARD_MAPPING.put(Float.class, JdbcType.REAL.name());
        STANDARD_MAPPING.put(Integer.TYPE, JdbcType.INTEGER.name());
        STANDARD_MAPPING.put(Integer.class, JdbcType.INTEGER.name());
        STANDARD_MAPPING.put(LocalDate.class, JdbcType.DATE.name());
        STANDARD_MAPPING.put(LocalDateTime.class, JdbcType.TIMESTAMP.name());
        STANDARD_MAPPING.put(LocalTime.class, JdbcType.TIME.name());
        STANDARD_MAPPING.put(Long.TYPE, JdbcType.BIGINT.name());
        STANDARD_MAPPING.put(Long.class, JdbcType.BIGINT.name());
        STANDARD_MAPPING.put(OffsetDateTime.class, JdbcType.TIMESTAMP_WITH_TIMEZONE.name());
        STANDARD_MAPPING.put(OffsetTime.class, JdbcType.TIME_WITH_TIMEZONE.name());
        STANDARD_MAPPING.put(Short.class, JdbcType.SMALLINT.name());
        STANDARD_MAPPING.put(String.class, JdbcType.VARCHAR.name());
        STANDARD_MAPPING.put(Time.class, JdbcType.TIME.name());
        STANDARD_MAPPING.put(Timestamp.class, JdbcType.TIMESTAMP.name());
        STANDARD_MAPPING.put(URL.class, JdbcType.DATALINK.name());
    }
}
