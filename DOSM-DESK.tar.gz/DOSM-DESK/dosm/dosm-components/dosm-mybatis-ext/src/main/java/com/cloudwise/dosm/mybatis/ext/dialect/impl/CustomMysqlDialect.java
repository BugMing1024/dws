package com.cloudwise.dosm.mybatis.ext.dialect.impl;

import cn.hutool.core.util.ArrayUtil;
import com.cloudwise.dosm.mybatis.ext.dialect.ICustomDialect;

/**
 * mysql 方言
 * @Author frank.zheng
 * @Since 2023-11-17 11:40
 */
public class CustomMysqlDialect implements ICustomDialect {

    public final static CustomMysqlDialect INSTANCE = new CustomMysqlDialect();

    /**
     * 执行结果sql样例："JSON_VALUE(jsonColumn, '$.prop0.prop1')" 或 "jsonColumn ->> '$.prop0.prop1'"
     */
    @Override
    public void buildSql4JsonColumnProperty(StringBuilder sqlBuilder, String jsonColumn, String... propertys) {
        if(ArrayUtil.isEmpty(propertys)) {
            sqlBuilder.append(jsonColumn);
            return;
        }

        // 执行结果sql样例："JSON_VALUE(jsonColumn, '$.prop0.prop1')"
        sqlBuilder.append("JSON_VALUE(").append(jsonColumn).append(", '$.").append(ArrayUtil.join(propertys, ".")).append("')");
    }

    /**
     * 执行结果sql样例："JSON_VALUE(jsonColumn, '$.${prop0}.prop1')" 或 "jsonColumn ->> '$.${prop0}.prop1'"
     * <p> oceanbase 不支持："JSON_VALUE(jsonColumn, CONCAT('$', '.', #{prop0}, '.prop1'))"、"jsonColumn ->> CONCAT('$.', '.', #{prop0}, '.prop1')"
     */
    @Override
    public void buildSql4JsonColumnProperty(StringBuilder sqlBuilder, String jsonColumn, String[] propertys, boolean[] isFixs) {
        if(ArrayUtil.isEmpty(propertys) || ArrayUtil.isEmpty(isFixs)) {
            buildSql4JsonColumnProperty(sqlBuilder, jsonColumn, propertys);
            return;
        }

        // 是否包含参数变量属性
        boolean hasParamProp = false;
        for(int i = 0; i < propertys.length && i < isFixs.length; i++) {
            if(isFixs[i] == Boolean.FALSE) {
                hasParamProp = true;
                break;
            }
        }

        if(!hasParamProp) {
            /** 固定属性 code  */
            buildSql4JsonColumnProperty(sqlBuilder, jsonColumn, propertys);
            return;
        }

        //执行结果sql样例："JSON_VALUE(jsonColumn, '$.${prop0}.prop1')"
        sqlBuilder.append("JSON_VALUE(").append(jsonColumn).append(", '$");
        for(int i = 0; i < propertys.length; i++) {
            // 固定属性
            if(i < isFixs.length? isFixs[i]: Boolean.TRUE) {
                sqlBuilder.append(".").append(propertys[i]);
            } else {
                sqlBuilder.append(".${").append(propertys[i]).append("}");
            }
        }
        sqlBuilder.append("')");
    }
}