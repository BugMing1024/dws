//package com.cloudwise.dosm.mybatis.ext.sqlinjector;
//
//import com.baomidou.mybatisplus.core.injector.AbstractMethod;
//import com.baomidou.mybatisplus.core.injector.DefaultSqlInjector;
//import com.baomidou.mybatisplus.extension.injector.methods.LogicDeleteByIdWithFill;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//
///**
// * @author solomon.zhou
// * @Description: 逻辑删除sql注入
// * @date 2021/6/174:29 下午
// */
//@ConditionalOnClass()
//@Component("dosmLogicDeleteSqlInjector")
//public class DosmLogicDeleteSqlInjector extends DefaultSqlInjector {
//
//    @Override
//    public List<AbstractMethod> getMethodList(Class<?> mapperClass) {
//        List<AbstractMethod> methodList = super.getMethodList(mapperClass);
//        //添加逻辑删除处理
//        methodList.add(new LogicDeleteByIdWithFill());
//        return methodList;
//    }
//
//}
