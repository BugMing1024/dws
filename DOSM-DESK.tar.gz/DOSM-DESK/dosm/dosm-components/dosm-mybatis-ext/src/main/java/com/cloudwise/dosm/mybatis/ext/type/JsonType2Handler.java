package com.cloudwise.dosm.mybatis.ext.type;

import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.postgresql.util.PGobject;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import static com.cloudwise.dosm.mybatis.ext.type.DBTypeEnum.*;

/**
 * JsonTypeHandler
 *
 * @author mhy
 * @since 2021-10-18 15:38
 **/


public class JsonType2Handler extends JacksonTypeHandler {


    public JsonType2Handler(Class<?> type) {
        super(type);
    }

    @Override
    public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) throws SQLException {

        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE)) ) {
            //gauss实现
            ps.setObject(i, toJson(parameter));

        }else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)){
            //postgres 实现
            PGobject jsonObject = new PGobject();
            jsonObject.setType("json");
            jsonObject.setValue(toJson(parameter));
            ps.setObject(i, jsonObject);

        }else {
            //默认实现
            PGobject jsonObject = new PGobject();
            jsonObject.setType("json");
            jsonObject.setValue(toJson(parameter));
            ps.setObject(i, jsonObject);

        }

    }
}
