package com.cloudwise.dosm.mybatis.ext.type;

import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.TypeException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.cloudwise.dosm.mybatis.ext.type.DBTypeEnum.*;

/**
 * 类的描述
 *
 * @author: cg
 * @since: 2021-06-15 16:57
 **/
@MappedJdbcTypes(JdbcType.ARRAY)
@Slf4j
public class ArrayTypeHandler extends BaseTypeHandler<Object[]> {
    private static final String TYPE_NAME_VARCHAR = "varchar";
    private static final String TYPE_NAME_INTEGER = "integer";
    private static final String TYPE_NAME_BOOLEAN = "boolean";
    private static final String TYPE_NAME_NUMERIC = "numeric";

    private final ObjectMapper jackson = new ObjectMapper();

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, Object[] parameter, JdbcType jdbcType) throws SQLException {
        String typeName = null;
        if (parameter instanceof Integer[]) {
            typeName = TYPE_NAME_INTEGER;
        } else if (parameter instanceof String[]) {
            typeName = TYPE_NAME_VARCHAR;
        } else if (parameter instanceof Boolean[]) {
            typeName = TYPE_NAME_BOOLEAN;
        } else if (parameter instanceof Double[]) {
            typeName = TYPE_NAME_NUMERIC;
        }

        if (typeName == null) {
            throw new TypeException("ArrayType2Handler parameter typeName error, your type is " + parameter.getClass().getName());
        }

        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            try {
                ps.setObject(i, jackson.writeValueAsString(parameter));
            } catch (JsonProcessingException e) {
                throw new TypeException("Gauss ArrayType2Handler parameter handler error");
            }
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            // 这3行是关键的代码，创建Array，然后ps.setArray(i, array)就可以了
            Connection conn = ps.getConnection();
            Array array = conn.createArrayOf(typeName, parameter);
            ps.setArray(i, array);
        } else {
            // 这3行是关键的代码，创建Array，然后ps.setArray(i, array)就可以了
            Connection conn = ps.getConnection();
            Array array = conn.createArrayOf(typeName, parameter);
            ps.setArray(i, array);
        }



    }

    @Override
    public Object[] getNullableResult(ResultSet resultSet, String s) throws SQLException {

        //目前使用到这个地方 为字符串数组 暂且兼容字符串  后续慎用
        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            String resultStr = resultSet.getString(s);
            if (StrUtil.isBlank(resultStr)){
                return new ArrayList<>().toArray();
            }
            List<String> result = new ArrayList<>();
            try {
                result = jackson.readValue(resultStr, new TypeReference<List<String>>() {});
            } catch (JsonProcessingException e) {
                throw new TypeException("Gauss ArrayType2Handler parameter handler error");
            }
            return result.toArray();
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 处理
            return getArray(resultSet.getArray(s));
        } else {
            //默认处理
            return getArray(resultSet.getArray(s));
        }
    }

    @Override
    public Object[] getNullableResult(ResultSet resultSet, int i) throws SQLException {
        return getArray(resultSet.getArray(i));
    }

    @Override
    public Object[] getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        return getArray(callableStatement.getArray(i));
    }

    private Object[] getArray(Array array) {
        if (array == null) {
            return null;
        }
        try {
            return (Object[]) array.getArray();
        } catch (Exception e) {
        }
        return null;
    }
}

