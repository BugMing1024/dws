package com.cloudwise.dosm.mybatis.ext.dialect.impl;

import cn.hutool.core.util.ArrayUtil;
import com.cloudwise.dosm.mybatis.ext.dialect.ICustomDialect;

/**
 * PG 方言
 * @Author frank.zheng
 * @Since 2023-11-17 11:40
 */
public class CustomPostgreSQLDialect implements ICustomDialect {

    public final static CustomPostgreSQLDialect INSTANCE = new CustomPostgreSQLDialect();

    /**
     * 执行结果sql样例："jsonColumn->'prop0'->>'prop1'"
     */
    @Override
    public void buildSql4JsonColumnProperty(StringBuilder sqlBuilder, String jsonColumn, String... propertys) {
        if(ArrayUtil.isEmpty(propertys)) {
            sqlBuilder.append(jsonColumn);
            return;
        }

        // 执行结果sql样例："json->'prop0'->>'prop1'"
        sqlBuilder.append(jsonColumn);
        for(int i = 0; i < propertys.length; i++) {
            sqlBuilder.append(i == propertys.length - 1? "->>'": "->'").append(propertys[i]).append("'");
        }
    }

    /**
     * 执行结果sql样例："jsonColumn->#{prop0}->>'prop1'"
     */
    @Override
    public void buildSql4JsonColumnProperty(StringBuilder sqlBuilder, String jsonColumn, String[] propertys, boolean[] isFixs) {
        if(ArrayUtil.isEmpty(propertys) || ArrayUtil.isEmpty(isFixs)) {
            buildSql4JsonColumnProperty(sqlBuilder, jsonColumn, propertys);
            return;
        }

        // 是否包含参数变量属性
        boolean hasParamProp = false;
        for(int i = 0; i < propertys.length && i < isFixs.length; i++) {
            if(isFixs[i] == Boolean.FALSE) {
                hasParamProp = true;
                break;
            }
        }

        if(!hasParamProp) {
            /** 固定属性 code  */
            buildSql4JsonColumnProperty(sqlBuilder, jsonColumn, propertys);
            return;
        }

        // 执行结果sql样例："jsonColumn->#{prop0}->>'prop1'"
        sqlBuilder.append(jsonColumn);
        for(int i = 0; i < propertys.length; i++) {
            sqlBuilder.append(i == propertys.length - 1? "->>": "->");
            // 固定属性
            if(i < isFixs.length? isFixs[i]: Boolean.TRUE) {
                sqlBuilder.append("'").append(propertys[i]).append("'");
            } else {
                sqlBuilder.append("#{").append(propertys[i]).append("}");
            }
        }
    }

}