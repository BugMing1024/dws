package com.cloudwise.dosm.mybatis.ext.type;

import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.postgresql.util.PGobject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import static com.cloudwise.dosm.mybatis.ext.type.DBTypeEnum.*;

/**
 * JsonTypeHandler
 *
 * @author kensou.yuwen
 * @since 2021-07-26 15:38
 **/

public class JsonTypeHandler extends JacksonTypeHandler {

    public JsonTypeHandler(Class<?> type) {
        super(type);
    }

    @Override
    public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) throws SQLException {

        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            ps.setObject(i, toJson(parameter));
        }else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)){
            //postgres 实现
            PGobject jsonObject = new PGobject();
            jsonObject.setType("jsonb");
            jsonObject.setValue(toJson(parameter));
            ps.setObject(i, jsonObject);
        }else {
            //默认实现
            PGobject jsonObject = new PGobject();
            jsonObject.setType("jsonb");
            jsonObject.setValue(toJson(parameter));
            ps.setObject(i, jsonObject);

        }

    }
}
