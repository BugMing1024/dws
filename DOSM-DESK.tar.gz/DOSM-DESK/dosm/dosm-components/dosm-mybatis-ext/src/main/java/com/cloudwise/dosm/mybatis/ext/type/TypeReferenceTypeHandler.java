package com.cloudwise.dosm.mybatis.ext.type;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2022/4/13
 */
@MappedJdbcTypes(JdbcType.OTHER)
@MappedTypes({List.class})
@Slf4j
public abstract class TypeReferenceTypeHandler<T> extends JavaBeanTypeHandler {

    public TypeReferenceTypeHandler(Class<?> type) {
        super(type);
    }

    @Override
    public List<T> getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return this.getListByJsonArrayString(rs.getString(columnName));
    }

    @Override
    public List<T> getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return this.getListByJsonArrayString(rs.getString(columnIndex));
    }

    @Override
    public List<T> getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return this.getListByJsonArrayString(cs.getString(columnIndex));
    }


    private List<T> getListByJsonArrayString(String content) {
        try {
            return StringUtils.isBlank(content) ? new ArrayList<>() : getObjectMapper().readValue(content, this.specificType());
        } catch (JsonProcessingException e) {
            log.error("getListByJsonArrayString error:",e);
        }
        return new ArrayList<>();
    }

    /**
     * 具体类型，由子类提供
     *
     * @return 具体类型
     */
    protected abstract TypeReference<List<T>> specificType();
}
