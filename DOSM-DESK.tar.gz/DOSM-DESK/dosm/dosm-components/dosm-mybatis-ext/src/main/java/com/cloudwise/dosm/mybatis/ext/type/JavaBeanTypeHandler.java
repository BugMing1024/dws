package com.cloudwise.dosm.mybatis.ext.type;

import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.postgresql.util.PGobject;

import java.sql.*;

import static com.cloudwise.dosm.mybatis.ext.type.DBTypeEnum.*;

/**
 * <p></p>
 * json内容 转bean对象  处理
 * </p>
 *
 * @author rentingji
 * @date 2021/7/7 下午4:15
 **/
@MappedJdbcTypes(JdbcType.OTHER)
public class JavaBeanTypeHandler extends JacksonTypeHandler {


    public JavaBeanTypeHandler(Class<?> type) {
        super(type);
    }

    @Override
    public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) throws SQLException {

        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            //gauss实现
            ps.setObject(i, toJson(parameter));

        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 实现
            PGobject jsonObject = new PGobject();
            jsonObject.setType("jsonb");
            if (parameter == null) {
                jsonObject.setValue(null);
            } else {
                jsonObject.setValue(toJson(parameter));
            }
            ps.setObject(i, jsonObject);

        } else {
            //默认实现
            /*
        	PGobject jsonObject = new PGobject();
            jsonObject.setType("jsonb");
            if (parameter == null) {
                jsonObject.setValue(null);
            } else {
                jsonObject.setValue(toJson(parameter));
            }

            ps.setObject(i, jsonObject);
        }

    }

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) throws SQLException {

        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            //gauss实现
            ps.setObject(i, toJson(parameter));
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 实现
            PGobject jsonObject = new PGobject();
            jsonObject.setType("jsonb");
            jsonObject.setValue(toJson(parameter));
            ps.setObject(i, jsonObject);
        } else {
            //默认实现
            /*
        	PGobject jsonObject = new PGobject();
            jsonObject.setType("jsonb");
            jsonObject.setValue(toJson(parameter));
            ps.setObject(i, jsonObject);
            */
        	ps.setObject(i, toJson(parameter));
        }

//        super.setNonNullParameter(ps, i, parameter, jdbcType);
    }

    @Override
    public Object getNullableResult(ResultSet rs, String columnName) throws SQLException {
        Object obj = rs.getObject(columnName);
        if (obj == null) {
            return null;
        }

        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            //gauss实现 guass中为clob类型数据
            return parse(rs.getString(columnName));
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 实现
            return parse(obj.toString());
        } else {
            //默认实现
            return parse(obj.toString());

        }

    }

    @Override
    public Object getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        Object obj = rs.getObject(columnIndex);
        if (obj == null) {
            return null;
        }
        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            //gauss实现 guass中为clob类型数据
            return parse(rs.getString(columnIndex));
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 实现
            return parse(obj.toString());
        } else {
            //默认实现
            return parse(obj.toString());

        }


    }

    @Override
    public Object getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        Object obj = cs.getObject(columnIndex);
        if (obj == null) {
            return null;
        }
        if (ZENITH.getDbType().equals(SqlConstant.DB_TYPE) || OCEANBASE_MYSQL.getDbType().equals((SqlConstant.DB_TYPE)) || MARIADB.getDbType().equals((SqlConstant.DB_TYPE))) {
            //gauss实现 guass中为clob类型数据
            return parse(cs.getString(columnIndex));
        } else if (POSTGRES.getDbType().equals(SqlConstant.DB_TYPE)) {
            //postgres 实现
            return parse(obj.toString());
        } else {
            //默认实现
            return parse(obj.toString());

        }
    }

}
