# dosm-db-dynamic

动态数据源及读写分离实现，主要基于 [com.baomidou:dynamic-datasource-spring-boot-starter](https://baomidou.com/guide/dynamic-datasource.html#%E6%96%87%E6%A1%A3-documentation
) 实现。

## 使用方法

    <dependency>
        <groupId>com.cloudwise</groupId>
        <artifactId>dosm-db-dynamic</artifactId>
        <version>version</version>
    </dependency>

## 数据源配置说明

- 数据源名称配置<b>`严格区分大小写和中英文`</b>
- 使用 `@DS` 切换数据源
- 事务`@Transactional`下的数据源选择（多层事务以顶层事务为主）
  - 未使用 `@DS` 指定数据源情况，所有读写全部使用 `master` 的 `写` 数据源
  - 使用 `@DS` 指定数据源情况
    - `@DS` 指定数据源的写数据源存在，则使用写数据源。如：@DS("pg")，则先匹配名称为 `pg_write` 的数据源，如果未找到则使用 `pg`
    - 所有读写全部使用 `@DS` 指定数据源的 `写` 数据源或`@DS` 指定的数据源

### 1、单数据源读写分离
    
    使用内置特殊数据源(master、slave)实现单数据源读写分离
    
> - master: 
  >> - 动态数据源中默认主数据源（未使用 `@DS` 指定的数据源）
  >> - 读写分离数据源中默认 `写` 数据源
    
> - slave: 
  >> - 动态数据源中默认从数据源（未使用 `@DS` 指定的数据源）
  >> - 读写分离数据源中默认 `读` 数据源


### 2、动态数据源读写分离

    1、默认主从数据源（未使用 @DS 指定的数据源）：master、slave
    2、针对多数据源的读写分离配置需要在数据源名称后添加固定标识:_write、_read。
    3、同时支持多主多从库配置。

#### 样例

数据源配置如下：
  - master_write_1: master 写数据源1
  - master_write_2: master 写数据源2
  - master_read: master 读数据源
  - slave_read_1: slave 读数据源1
  - slave_read_2: slave 读数据源2

1、使用 master_write 数据源的实现

> 1.1、非事务下，方法中的写数据库操作  
> 1.2、非事务下，在方法上只有 `@DS("master")` 的写数据库操作  
> 1.3、非事务下，在方法上只有 `@DS("master_write")` 的所有数据库操作  
> 1.4、在顶层事务方法上只有 `@Transactional` 下所有数据库操作  
> 1.5、在顶层事务方法上有 `@Transactional` 和 `@DS("master")` 的所有数据库操作  
> 1.6、在顶层事务方法上有 `@Transactional` 和 `@DS("master_write")` 的所有数据库操作
   
2、使用 master_read 数据源的实现

> 2.1、非事务下，在方法上只有 `@DS("master")` 的读数据库操作  
> 2.2、非事务下，在方法上只有 `@DS("master_read")` 的所有数据库操作  
> 2.3、在顶层事务方法上有 `@Transactional` 和 `@DS("master_read")` 的所有数据库操作

3、使用 slave_read 数据源的实现

> 3.1、非事务下，方法中的读数据库操作  
> 3.2、非事务下，在方法上只有 `@DS("slave")` 的读数据库操作  
> 3.3、非事务下，在方法上只有 `@DS("slave_read")` 的所有数据库操作 
> 3.4、在顶层事务方法上有 `@Transactional` 和 `@DS("slave_read")` 的所有数据库操作  



   



    