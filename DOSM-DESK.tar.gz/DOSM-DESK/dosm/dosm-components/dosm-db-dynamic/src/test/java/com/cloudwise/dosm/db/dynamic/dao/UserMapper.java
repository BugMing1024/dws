package com.cloudwise.dosm.db.dynamic.dao;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.dosm.db.dynamic.po.UserPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

/**
 * @Author frank.zheng
 * @Since 2021-08-14 15:27
 */
@Mapper
//@DS("master")
public interface UserMapper extends BaseMapper<UserPo> {


    @DS("pg")
    @Select("select * from bpm_process_info limit 1")
    Map<String, Object> getProc();

}
