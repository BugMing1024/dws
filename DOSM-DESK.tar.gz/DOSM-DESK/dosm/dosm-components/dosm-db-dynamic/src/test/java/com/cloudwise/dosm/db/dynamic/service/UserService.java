package com.cloudwise.dosm.db.dynamic.service;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.cloudwise.dosm.db.dynamic.dao.User2Mapper;
import com.cloudwise.dosm.db.dynamic.dao.UserMapper;
import com.cloudwise.dosm.db.dynamic.po.UserPo;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * @Author frank.zheng
 * @Since 2021-08-16 11:52
 */
@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private User2Mapper user2Mapper;

    @Transactional(rollbackFor = Exception.class)
//    @DSTransactional
    @DS("master")
    public void add() {
        String id = UUID.randomUUID().toString();
        String name = "name"+ RandomUtils.nextInt();
        System.out.println("--------------user: "+ id);
        UserPo userPo = UserPo.builder().id(id).name(name).build();
//        userMapper.insert(userPo);

        user2Mapper.insert(userPo);
        System.out.println("------------------------------");

        get();
    }

    @Transactional(rollbackFor = Exception.class)
    @DS("slave")
    public void get() {
//        System.out.println("userMapper----count: "+ userMapper.selectCount(null));

        System.out.println("user2Mapper----user: "+ user2Mapper.getUser());
    }
}
