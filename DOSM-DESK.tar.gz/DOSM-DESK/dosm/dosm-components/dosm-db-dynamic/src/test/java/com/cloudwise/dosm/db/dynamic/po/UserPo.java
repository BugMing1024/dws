package com.cloudwise.dosm.db.dynamic.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author frank.zheng
 * @Since 2021-08-14 15:27
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TableName("test_user")
public class UserPo {

    @TableId
    private String id;

    @TableField
    private String name;
}
