package com.cloudwise.dosm.db.dynamic;

import com.cloudwise.dosm.db.dynamic.dao.UserMapper;
import com.cloudwise.dosm.db.dynamic.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Mapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Lazy;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Author frank.zheng
 * @Since 2021-08-14 10:53
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@SpringBootApplication
@MapperScan(value = "com.cloudwise.dosm", annotationClass = Mapper.class)
@Slf4j
public class DataSourceDynamicTest {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserService userService;

    @Test
    public void userTest() {
//        String id = UUID.randomUUID().toString();
//        String name = "name"+ RandomUtils.nextInt();
//        userMapper.insert(UserPo.builder().id(id).name(name).build());
//
////        UserPo user = userMapper.selectById(id);
////        if(user == null) {
////            System.out.println("---- user is null");
////        } else {
////            System.out.println(user.getId());
////            System.out.println(user.getName());
////        }
//
//        System.out.println("--- proc info: "+ userMapper.getProc());

        try {
            userService.add();
        } catch(Exception e) {
            log.error("测试添加用户error:",e);
        }


//        userService.get();

    }

}
