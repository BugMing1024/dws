/*
 * Copyright © 2018 organization baomidou
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cloudwise.dosm.db.dynamic;

import com.baomidou.dynamic.datasource.ds.GroupDataSource;
import com.baomidou.dynamic.datasource.strategy.DynamicDataSourceStrategy;
import com.baomidou.dynamic.datasource.strategy.LoadBalanceDynamicDataSourceStrategy;
import com.baomidou.dynamic.datasource.toolkit.DynamicDataSourceContextHolder;
import com.baomidou.dynamic.datasource.tx.ConnectionFactory;
import com.baomidou.dynamic.datasource.tx.ConnectionProxy;
import com.baomidou.dynamic.datasource.tx.TransactionContext;
import com.cloudwise.dosm.db.dynamic.constant.DBConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * 核心动态数据源组件
 * @author TaoYu Kanyuxia
 * @since 1.0.0
 */
@Slf4j
public class DynamicRoutingDataSource extends com.baomidou.dynamic.datasource.DynamicRoutingDataSource {

    private Class<? extends DynamicDataSourceStrategy> strategy = LoadBalanceDynamicDataSourceStrategy.class;

    /**
     * 添加数据源
     *
     * @param ds         数据源名称
     * @param dataSource 数据源
     */
    @Override
    public synchronized void addDataSource(String ds, DataSource dataSource) {
        super.addDataSource(ds, dataSource);
        addGroupDataSource(ds, dataSource);
    }

    /**
     * 新数据源添加到分组
     *
     * @param ds         新数据源的名字
     * @param dataSource 新数据源
     */
    private void addGroupDataSource(String ds, DataSource dataSource) {
        if (ds.contains(DBConstants.UNDERLINE)) {
            String[] groups = ds.split(DBConstants.UNDERLINE);
            if(groups.length >= 3) {
                String group = groups[0] + DBConstants.UNDERLINE + groups[1];
                GroupDataSource groupDataSource = getGroupDataSources().get(group);
                if (groupDataSource == null) {
                    try {
                        groupDataSource = new GroupDataSource(group, strategy.getDeclaredConstructor().newInstance());
                        getGroupDataSources().put(group, groupDataSource);
                    } catch (Exception e) {
                        throw new RuntimeException("dynamic-datasource - add the datasource named " + ds + " error", e);
                    }
                }
                groupDataSource.addDatasource(ds, dataSource);
            }
        }
    }

    @Override
    public Connection getConnection() throws SQLException {
        String xid = TransactionContext.getXID();
        if (StringUtils.isEmpty(xid)) {
            return determineDataSource().getConnection();
        } else {
            String ds = DynamicDataSourceContextHolder.peek();
            ds = StringUtils.isEmpty(ds)? "default": ds;
            ConnectionProxy connection = ConnectionFactory.getConnection(ds);
            if(connection != null) {
                return connection;
            }
            String dsEndStr = DBConstants.WRITE;
            DataSource dataSource = getDataSource(ds, dsEndStr);
            return getConnectionProxy(ds, dataSource.getConnection());
        }
    }

    private DataSource getDataSource(String currentDataSource, String currentDataSourceEndStr) {
        DataSource dataSource = getDataSources().get(currentDataSource + currentDataSourceEndStr);
        if(dataSource != null) {
            return dataSource;
        }

        dataSource = getDataSources().get(currentDataSource);
        if(dataSource != null) {
            return dataSource;
        }

        GroupDataSource groupDataSource = getGroupDataSources().get(currentDataSource + currentDataSourceEndStr);
        if(groupDataSource != null) {
            return groupDataSource.determineDataSource();
        }

        groupDataSource = getGroupDataSources().get(currentDataSource);
        if(groupDataSource == null) {
            return getDataSource(null);
        }
        return groupDataSource.determineDataSource();
    }

    private Connection getConnectionProxy(String ds, Connection connection) {
        ConnectionProxy connectionProxy = new ConnectionProxy(connection, ds);
        ConnectionFactory.putConnection(ds, connectionProxy);
        return connectionProxy;
    }

    @Override
    public void setStrategy(Class<? extends DynamicDataSourceStrategy> strategy) {
        super.setStrategy(strategy);
        this.strategy = strategy;
    }
}