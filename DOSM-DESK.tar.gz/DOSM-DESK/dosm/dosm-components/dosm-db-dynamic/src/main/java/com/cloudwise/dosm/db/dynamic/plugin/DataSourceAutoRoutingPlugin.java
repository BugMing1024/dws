/*
 * Copyright © 2018 organization baomidou
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cloudwise.dosm.db.dynamic.plugin;

import com.baomidou.dynamic.datasource.ds.GroupDataSource;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDataSourceProperties;
import com.baomidou.dynamic.datasource.toolkit.DynamicDataSourceContextHolder;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.cloudwise.dosm.db.dynamic.DynamicRoutingDataSource;
import com.cloudwise.dosm.db.dynamic.constant.DBConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Master-slave Separation Plugin with mybatis
 *
 * @author TaoYu
 * @since 2.5.1
 */
@Component
@ConditionalOnProperty(prefix = DynamicDataSourceProperties.PREFIX, name = "enabled", havingValue = "true", matchIfMissing = true)
@Intercepts({
        @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}),
        @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class}),
        @Signature(type = Executor.class, method = "update", args = {MappedStatement.class, Object.class})})
@Slf4j
public class DataSourceAutoRoutingPlugin implements Interceptor {

    @Autowired
    protected DataSource dynamicDataSource;

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        boolean synchronizationActive = TransactionSynchronizationManager.isSynchronizationActive();
        if(synchronizationActive) {
            return invocation.proceed();
        }
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        String pushedDataSource = null;
        try {
            // 设置数据源
            String dataSource = DynamicDataSourceContextHolder.peek();
            if(StringUtils.isBlank(dataSource)) {
                dataSource = getDataSource(ms);
            } else {
                dataSource = getDataSource(dataSource, ms);
            }
            pushedDataSource = DynamicDataSourceContextHolder.push(dataSource);
            return invocation.proceed();
        } finally {
            if (pushedDataSource != null) {
                DynamicDataSourceContextHolder.poll();
            }
        }
    }

    /**
     * 获取动态数据源名称，重写注入 DbHealthIndicator 支持数据源健康状况判断选择
     *
     * @param mappedStatement mybatis MappedStatement
     * @return 获取真实的数据源名称
     */
    public String getDataSource(MappedStatement mappedStatement) {
        boolean isSelect = SqlCommandType.SELECT == mappedStatement.getSqlCommandType();
        String currentDataSourceEndStr = isSelect? DBConstants.READ: DBConstants.WRITE;
        String currentDataSource = isSelect? DBConstants.SLAVE : DBConstants.MASTER;

        String dataSource = null;
        // 当前数据源是从库
        if (DBConstants.SLAVE.equalsIgnoreCase(currentDataSource)) {
            dataSource = getDataSource((DynamicRoutingDataSource) dynamicDataSource, DBConstants.SLAVE, currentDataSourceEndStr);
        }

        if(dataSource == null) {
            dataSource = getDataSource((DynamicRoutingDataSource) dynamicDataSource, DBConstants.MASTER, currentDataSourceEndStr);
        }
        return dataSource;
    }


    /**
     * 获取动态数据源名称，重写注入 DbHealthIndicator 支持数据源健康状况判断选择
     *
     * @param currentDataSource
     * @param mappedStatement mybatis MappedStatement
     * @return 获取真实的数据源名称
     */
    public String getDataSource(String currentDataSource, MappedStatement mappedStatement) {
        boolean isSelect = SqlCommandType.SELECT == mappedStatement.getSqlCommandType();
        String currentDataSourceEndStr = isSelect? DBConstants.READ: DBConstants.WRITE;

        String dataSource = getDataSource((DynamicRoutingDataSource) dynamicDataSource, currentDataSource, currentDataSourceEndStr);
        dataSource = StringUtils.isBlank(dataSource)? currentDataSource: dataSource;
        return dataSource;
    }

    private String getDataSource(DynamicRoutingDataSource dynamicRoutingDataSource, String currentDataSource, String currentDataSourceEndStr) {
        Map<String, DataSource> dataSourceMap = dynamicRoutingDataSource.getDataSources();
        String dataSourceStr = currentDataSource + currentDataSourceEndStr;
        DataSource dataSource = dataSourceMap.get(dataSourceStr);
        if(dataSource != null) {
            return dataSourceStr;
        }

        Map<String, GroupDataSource> currentGroupDataSources = dynamicRoutingDataSource.getGroupDataSources();
        GroupDataSource groupDataSource = currentGroupDataSources.get(currentDataSource);
        if(groupDataSource == null) {
            return null;
        }
        return groupDataSource.determineDsKey();
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

}
