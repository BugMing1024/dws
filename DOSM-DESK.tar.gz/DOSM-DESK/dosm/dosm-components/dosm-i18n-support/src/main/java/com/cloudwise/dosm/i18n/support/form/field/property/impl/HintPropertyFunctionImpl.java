package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import cn.hutool.core.util.NumberUtil;
import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;


/**
 * 字段提示 国际化
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"fieldHint":{"hintType":"1","hintContent":"国际化值"}}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "", "property_code": "hintContent", "type": "1/2", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "1"}
 * </ul>
 * </ol>
 *
 * @Author frank.zheng
 * @Date 2023-07-31
 */
public class HintPropertyFunctionImpl implements IFieldPropertyFunction {

    @Override
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.HINT;
    }

    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     * @param paramContext
     */
    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_PROPS);

        // 获取提示信息
        List<Map<String, Object>> hintMapList = (List<Map<String, Object>>) xPropsMap.get(this.getProperty().getFieldKey());
        if (CollectionUtils.isEmpty(hintMapList) || MapUtils.isEmpty(hintMapList.get(0))) {
            return;
        }

        Map<String, Object> hintMap = hintMapList.get(0);
        String hintContent = (String) hintMap.get(this.getProperty().getPropertyCode());
        if(StringUtils.isBlank(hintContent)) {
            return;
        }

        String hintType = getHitTypeByFieldSchemaConfig(hintMap);
        // 提示国际化
        Map<String, Object> hintContentI18nMap = (Map<String, Object>) paramContext.getFieldPropertyI18nContentMap().computeIfAbsent(this.getProperty().getFieldKey(), k -> Maps.newHashMap());
        hintContentI18nMap.put(FieldPropertyConstant.K_HINT_TYPE, hintType);
        hintContentI18nMap.put(this.getProperty().getPropertyCode(), hintContent);

        /** 同步其他语言国际化信息 */
        this.syncFieldPropertyI18n4Update(moduleI18nConf, paramContext, hintType, hintContent);
    }

    /**
     * 同步其他语言国际化信息
     */
    public void syncFieldPropertyI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext, String currHintType, String currHintContent) {
        Map<String, String> orgFieldHintI18nMap = null;
        // 【非当前语言的国际化】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
        Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap = null;
        if(paramContext.isPreVerField()) {
            /** 上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步 */
            orgFieldHintI18nMap = (Map<String, String>) paramContext.getDbPreVerFieldPropertyContentI18n(this.getProperty().getFieldKey());
            syncFieldPropertyContentI18nMap = paramContext.getDbPreVerFieldPropertyContentI18nMap();
        } else {
            /** 上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步 */
            orgFieldHintI18nMap = (Map<String, String>) paramContext.getDbPublicFieldPropertyContentI18n(this.getProperty().getFieldKey());
            syncFieldPropertyContentI18nMap = paramContext.getDbPublicFieldPropertyContentI18nMap();
        }
        boolean isSync = true;
        if(MapUtils.isNotEmpty(orgFieldHintI18nMap)) {
            String publicFieldHintType = orgFieldHintI18nMap.get(FieldPropertyConstant.K_HINT_TYPE);
            String publicFieldHintContent = orgFieldHintI18nMap.get(this.getProperty().getPropertyCode());
            // 提示类别 与 提示内容完全一样，则同步提示国际化
            isSync = StringUtils.equals(currHintType, publicFieldHintType) && StringUtils.equals(currHintContent, publicFieldHintContent);
        }
        this.syncPropertyContentI18n4Update(paramContext, isSync, currHintType, syncFieldPropertyContentI18nMap);

        this.mergeFieldSchemaDataSourceI18n4Update(paramContext, currHintType, currHintContent);
    }


    /**
     * 同步其他语言国际化信息
     * <p>1、上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步
     * <p>2、上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步
     */
    public void syncPropertyContentI18n4Update(FormSchema4UpdateParamBean paramContext, boolean isSync, String currHintType, Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap) {
        // 自定义选项未变更
        if(!isSync || MapUtils.isEmpty(syncFieldPropertyContentI18nMap)) {
            return;
        }
        // 【表单、字段使用】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
        for(Map.Entry<String, Map<String, Object>> syncDbPropertyContentI18nEntry: syncFieldPropertyContentI18nMap.entrySet()) {
            Map<String, Object> syncDbPropertyContentI18nMap = syncDbPropertyContentI18nEntry.getValue();
            if(MapUtils.isEmpty(syncDbPropertyContentI18nMap)) {
                continue;
            }
            Map<String, String> syncI18nContentMap = (Map<String, String>) syncDbPropertyContentI18nMap.get(this.getProperty().getFieldKey());
            if(MapUtils.isEmpty(syncI18nContentMap)) {
                continue;
            }

            String syncFieldHintType = syncI18nContentMap.get(FieldPropertyConstant.K_HINT_TYPE);
            if(StringUtils.equals(syncFieldHintType, currHintType)) {
                // 同步该语言的选项国际化信息
                Map<String, Object> syncPropertyContentI18nMap = paramContext.getSyncFieldPropertyI18nContentMap().computeIfAbsent(syncDbPropertyContentI18nEntry.getKey(), k -> Maps.newHashMap());
                syncPropertyContentI18nMap.put(this.getProperty().getFieldKey(), syncI18nContentMap);
            }
        }
    }



    /**
     * 同步其他语言国际化信息
     */
    public void mergeFieldSchemaDataSourceI18n4Update(FormSchema4UpdateParamBean paramContext, String currHintType, String hintContent) {
        Map<String, Object> hintContentI18nMap = Maps.newHashMap();
        hintContentI18nMap.put(FieldPropertyConstant.K_HINT_TYPE, currHintType);
        hintContentI18nMap.put(this.getProperty().getPropertyCode(), hintContent);

        // 属性同步的 其他语言的 国际化 content
        for(Map.Entry<String, Map<String, Object>> syncFieldPropertyI18nContentEntry: paramContext.getSyncFieldPropertyI18nContentMap().entrySet()) {
            Map<String, Object> syncPropertyI18nMergeContent = paramContext.getSyncFieldPropertyI18nMergeContentMap().computeIfAbsent(syncFieldPropertyI18nContentEntry.getKey(), k -> Maps.newHashMap());

            /** 同步的 - 其他语言 - 国际化不存 */
            if(MapUtils.isEmpty(syncFieldPropertyI18nContentEntry.getValue())) {
                syncPropertyI18nMergeContent.put(this.getProperty().getFieldKey(), hintContentI18nMap);
                continue;
            }

            Map<String, Object> syncPropertyI18nContentMap = (Map<String, Object>) syncFieldPropertyI18nContentEntry.getValue().get(this.getProperty().getFieldKey());
            /** 同步的 - 其他语言 - 国际化 content 信息未配置 */
            if(MapUtils.isEmpty(syncPropertyI18nContentMap)) {
                syncPropertyI18nMergeContent.put(this.getProperty().getFieldKey(), hintContentI18nMap);
                continue;
            }

            /** 同步的 - 其他语言 - 国际化信息存在配置 */
            syncPropertyI18nMergeContent.put(this.getProperty().getFieldKey(), syncPropertyI18nContentMap);
        }

        // 【当前语言】【merge】国际化
        paramContext.getFieldPropertyI18nMergeContentMap().put(this.getProperty().getFieldKey(), hintContentI18nMap);
    }
    
    
    
    

    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity          模块 i18n 配置
     * @param fieldSchemaConfig         表单配置
     * @param fieldPropertyI18nMap       字段国际化
     * @param publicFieldPropertyI18nMap 字段对应的公共国际化
     */
    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap,
            Map<String, Object> publicFieldPropertyI18nMap) {
        Map<String, Object> hitContentI18nMap = (Map<String, Object>) fieldPropertyI18nMap.get(this.getProperty().getFieldKey());
        if (MapUtils.isEmpty(hitContentI18nMap)) {
            return;
        }

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

        // 获取提示信息
        List<Map<String, Object>> hintMapList = (List<Map<String, Object>>) xPropsMap.get(this.getProperty().getFieldKey());
        if (CollectionUtils.isEmpty(hintMapList) || MapUtils.isEmpty(hintMapList.get(0))) {
            return;
        }
        Map<String, Object> hintMap = hintMapList.get(0);
        String hitContentI18nStr = (String) hitContentI18nMap.get(this.getProperty().getPropertyCode());
        if (StringUtils.isNotBlank(hitContentI18nStr)) {
            hintMap.put(this.getProperty().getPropertyCode(), hitContentI18nStr);
        }

        String hitType = getHitTypeByFieldSchemaConfig(hintMap);
        if(StringUtils.equals(FieldPropertyConstant.V_HINT_CONTENT_LAYOUT_1, hitType)) {
            xPropsMap.put(FieldPropertyConstant.K_PLACEHOLDER, hitContentI18nStr);
        }
    }

    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     * @return
     */
    @Override
    public void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param) {
        Map<String, List<String>> contentI18nMap = fieldI18n.getContent();

        String fieldCode = fieldI18n.getDataCode();
        // 属性 merge 后的语言内容
        String mergeContent = null;
        List<Map<String, Object>> mergeContentIsNullList = Lists.newArrayList();
        for (Map.Entry<String, List<String>> contentI18nEntry : contentI18nMap.entrySet()) {
            String language = contentI18nEntry.getKey();
            // 【某语言下字段】国际化集合,格式：Map<字段，Map<propertyCode, Object>>
            Map<String, Map<String, Object>> languageI18nMap = param.getResultI18nMap().computeIfAbsent(language, k -> Maps.newHashMap());
            // 【字段下各属性】国际化集合,格式：Map<propertyCode, Object>
            Map<String, Object> fieldI18nMap = languageI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());
            // 【提示】国际化集合,格式：Map<选项ID, "国际化">
            Map<String, Object> hitConfI18nMap = (Map<String, Object>) fieldI18nMap.computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

            Map<String, Object> hitConfMergeI18nMap = (Map<String, Object>) param.getResultMergeI18nMap().computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(fieldCode, k -> Maps.newHashMap())
                    .computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

            List<String> contentList = contentI18nEntry.getValue();
            String content = null;
            // 配置国际化为空
            if (CollectionUtils.isEmpty(contentList) || StringUtils.isBlank(content = contentList.get(0))) {
                mergeContentIsNullList.add(hitConfMergeI18nMap);
            } else {
                hitConfI18nMap.put(fieldI18n.getPropertyCode(), mergeContent = content);
                hitConfMergeI18nMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
            hitConfI18nMap.put(FieldPropertyConstant.K_HINT_TYPE, fieldI18n.getType());
            hitConfMergeI18nMap.put(FieldPropertyConstant.K_HINT_TYPE, fieldI18n.getType());
        }

        if (mergeContent != null) {
            for (Map<String, Object> mergeContentMap : mergeContentIsNullList) {
                mergeContentMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }

    }

    /**
     * 【查询】将字段 i18n 配置转为 map，格式：Map<propertyCode, MainI18nInfoVO>
     * @param moduleI18nConf
     * @param fieldI18nMap         字段国际化信息，格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
     * @param fieldPropertyI18nMap 字段 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap) {
        Map<String, String> hintMap = (Map<String, String>) fieldI18nMap.get(this.getProperty().getFieldKey());
        String hintContent = null;
        if (hintMap == null || StringUtils.isBlank(hintContent = hintMap.get(this.getProperty().getPropertyCode()))) {
            return;
        }
        String hintTypeStr = hintMap.get(FieldPropertyConstant.K_HINT_TYPE);

        // 设置语言值【模块对象中获取属性值】
        Map<String, List<String>> contentMap = fieldPropertyI18nMap.computeIfAbsent(this.getProperty().getPropertyCode(), k -> MainI18nInfoVO.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .dataCode(moduleI18nConf.getDataCode())
                .extCode(moduleI18nConf.getExtCode())
                .type(hintTypeStr)
                .propertyCode(this.getProperty().getPropertyCode())
                .content(Maps.newHashMap())
                .build()
        ).getContent();
        contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(hintContent));
    }

    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param mainI18nInfoList 字段下属性的mainI8nInfo集合【用于选项特殊情况】
     * @param fieldPropertyI18nMap 字段属性的 I8n ，格式：Map<propertyCode, MainI18nInfoVO>
     * @param publicFieldPropertyI18nMap 公共字段属性 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList, Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {
        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

        // 获取提示信息
        List<Map<String, Object>> hintMapList = (List<Map<String, Object>>) xPropsMap.get(this.getProperty().getFieldKey());
        if (CollectionUtils.isEmpty(hintMapList) || MapUtils.isEmpty(hintMapList.get(0))) {
            return null;
        }

        Map<String, Object> hintMap = hintMapList.get(0);
        String hintContent = (String) hintMap.get(this.getProperty().getPropertyCode());
        if(StringUtils.isBlank(hintContent)) {
            return null;
        }
        // hintType值为 1、2、3
        String hintType = getHitTypeByFieldSchemaConfig(hintMap);
        int hintTypeI18nIndex = NumberUtil.parseInt(hintType) -1;

        MainI18nInfoVO currMainI18nInfo = fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if (currMainI18nInfo == null) {
            // 提示国际化
            currMainI18nInfo = this.getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[hintTypeI18nIndex], null, hintType, this.getProperty().getPropertyCode(), hintContent);

//            // 公共字段国际化
//            MainI18nInfoVO publicFieldI18nInfo = publicFieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
//            if(publicFieldI18nInfo != null) {
//                // 将公共字段国际化放入字段
//                Map<String, List<String>> publicFieldI18nMap = publicFieldI18nInfo.getContent();
//                for(Map.Entry<String, List<String>> publicFieldI18nEntry: publicFieldI18nMap.entrySet()) {
//                    List<String> currI18nList = currMainI18nInfo.getContent().get(publicFieldI18nEntry.getKey());
//                    if(CollectionUtils.isEmpty(currI18nList) || StringUtils.isBlank(currI18nList.get(0))) {
//                        currMainI18nInfo.getContent().put(publicFieldI18nEntry.getKey(), publicFieldI18nEntry.getValue());
//                    }
//                }
//            }
        } else {
            currMainI18nInfo.setType(hintType);
            currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[hintTypeI18nIndex]));
        }
        mainI18nInfoList.add(currMainI18nInfo);
        return currMainI18nInfo;
    }


    /**
     * 【fieldVo - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据
     * @param moduleI18nEntity 模块 i18n 配置
     * @param fieldMap 字段信息配置（fieldVo对象）
     * @param fieldPropertyI18nMap 字段属性国际化信息
     * @param publicFieldPropertyI18nMap 公共字段属性国际化信息
     */
    @Override
    public void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {
        Map<String, Object> hitContentI18nMap = (Map<String, Object>) fieldPropertyI18nMap.get(this.getProperty().getFieldKey());
        if (MapUtils.isEmpty(hitContentI18nMap)) {
            return;
        }
        Map<String, Object> fieldRuleMap = (Map<String, Object>) fieldMap.get(FieldPropertyConstant.FN_FIELD_RULE);
        List<Map<String, Object>> hintMapList = (List<Map<String, Object>>) fieldRuleMap.get(this.getProperty().getFieldKey());
        if (CollectionUtils.isEmpty(hintMapList) || MapUtils.isEmpty(hintMapList.get(0))) {
            return;
        }
        Map<String, Object> hintMap = hintMapList.get(0);
        String hitContentI18nStr = (String) hitContentI18nMap.get(this.getProperty().getPropertyCode());
        if (StringUtils.isNotBlank(hitContentI18nStr)) {
            hintMap.put(this.getProperty().getPropertyCode(), hitContentI18nStr);
        }

        String hitType = getHitTypeByFieldSchemaConfig(hintMap);
        if(StringUtils.equals(FieldPropertyConstant.V_HINT_CONTENT_LAYOUT_1, hitType)) {
            fieldRuleMap.put(FieldPropertyConstant.K_PLACEHOLDER, hitContentI18nStr);
        }
    }

    private String getHitTypeByFieldSchemaConfig(Map<String, Object> hintMap) {
        Object hintTypeObj = hintMap.get(FieldPropertyConstant.K_HINT_TYPE);
        if(hintTypeObj  == null) {
            return "1";
        }
        return hintTypeObj.toString();
    }

}
