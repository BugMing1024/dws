package com.cloudwise.dosm.i18n.support.form.field.constant;

/**
 * 字段属性常量
 * @Author frank.zheng
 * @Date 2023-07-30
 */
public interface FieldPropertyConstant {



    /** 固定的扩展code: attr */
    String FIXED_EXT_CODE_ATTR = "attr";
    String K_DATA_TYPE_CUSTOME = "K_DATA_TYPE_CUSTOME";

    /** properties */
    String K_PROPERTIES = "properties";

    /** 字段配置属性: x-props */
    String K_X_PROPS              = "x-props";
    /** 字段配置属性: x-rules */
    String K_X_RULES              = "x-rules";
    /** 字段类型 */
    String K_X_COMPONENT          = "x-component";
    /** 公共字段定义key */
    String K_PUBLIC_FIELD_DEF_KEY = "publicFieldDefKey";
    /** 配置项模型ID */
    String K_CMDB_MODEL_ID = "cmdbModelId";
    /** firstId */
    String K_FIRST_ID = "firstId";


    /** 字段CODE：key */
    String K_FIELD_KEY = "key";

    /** 字段类型：fieldType */
    String K_FIELD_TYPE = "fieldType";

    /** 字段名称 */
    String K_TITLE = "title";
    /** 提示文字名称 */
    String K_NAME = "name";

    /** 提示:x-props.fieldHint */
    String K_HINT         = "fieldHint";
    /**
     * 提示类型：x-props.fieldHint[0].hintContent
     *  1：输入框内展示提示内容，2:悬浮窗展示提示内容，3:提示内容常显在字段下
     */
    String K_HINT_TYPE    = "hintType";
    /** 提示内容x-props.fieldHint[0].hintContent */
    String K_HINT_CONTENT = "hintContent";

    /** 提示内容类型：输入框内展示提示内容 */
    String V_HINT_CONTENT_LAYOUT_1 = "1";
    /** 提示内容格式：悬浮窗展示提示内容 */
    String V_HINT_CONTENT_LAYOUT_2 = "2";
    /** 提示内容格式：提示内容常显在字段下 */
    String V_HINT_CONTENT_LAYOUT_3 = "3";

    /** 提示内容:x-props.placeholder */
    String K_PLACEHOLDER = "placeholder";


    /** 选项值类型：x-props.dataType */
    String K_DATA_TYPE        = "dataType";
    /** 选项值类型: 自定义 */
    String V_DATA_TYPE_CUSTOM = "custom";
    /** 选项值类型: 数据字典 */
    String V_DATA_TYPE_DICT   = "dictionary";
    /** 选项值类型: api */
    String V_DATA_TYPE_API    = "api";

    /** 选项：x-props.dataSource */
    String K_DATA_SOURCE = "dataSource";
    /** 选项 - 值 */
    String K_DATA_SOURCE_VALUE = "value";
    /** 选项 - 名 */
    String K_DATA_SOURCE_LABEL = "label";
    /** 选项 - 下级 */
    String K_DATA_SOURCE_CHILDREN = "children";

    /** 选项 */
    String K_ENUM = "enum";
    /** 选项 - 值 */
    String K_ENUM_VALUE = K_DATA_SOURCE_VALUE;
    /** 选项 - 名 */
    String K_ENUM_LABEL = K_DATA_SOURCE_LABEL;


    /** 选项：x-props.toolTips */
    String K_TOOL_TIPS = "toolTips";
    /** 星级数量：x-props.count */
    String K_COUNT = "count";



    /** 默认值:x-props.defaultValue */
    String K_DEFAULT_VALUE = "defaultValue";
    /** 默认值 */
    String K_DEFAULT = "default";


    /** 单位:x-props.unit */
    String K_UNIT = "unit";

    /** 分组类型:groupType */
    String K_GROUP_TYPE = "groupType";
    /** 父级容器ID */
    String K_PARENT_ID = "parentId";
    /** 分组类型值:group_tab（标签容器） */
    String V_GROUP_TYPE_GROUP_TAB = "group_tab";
    /** 分组类型值:group_tab（标签页） */
    String V_GROUP_TYPE_GROUP_TAB_PANEL = "group_tab_panel";

    /** 表格字段 - 列配置属性: columns */
    String K_COLUMNS = "columns";




    /** 字段名 */
    String FN_FIELD_CODE       = "fieldCode";
    String FN_FIELD_NAME       = "fieldName";
    String FN_FIELD_VALUE_TYPE = "fieldValueType";
    String FN_FIELD_RULE       = "fieldRule";
    String FN_ENUM_SOURCE_TYPE = "enumSourceType";
    String FN_ENUM_LIST        = "enumList";

}
