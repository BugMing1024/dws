package com.cloudwise.dosm.i18n.support.process.bpm.convert;

import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.convert.ModuleI18nConverter;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.dosm.i18n.support.core.enums.I18nModuleCode;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * <ol>
 * <li> 流程配置XML转换
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_PROCESS_BPM", "main_id"："流程ID", "data_code"："流程定义ID", "content": "{\"节点CODE\": \"国际化值\",\"连接线CODE\":\"\"}"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_BPM", "main_id"："流程ID", "data_code"："流程定义ID", "ext_code": "节点CODE/连接线CODE", "content": {"zh_CN":["国际化", "国际化ID"]}, "leaf": "0/1", "childs": []}
 * </ul>
 * </ol>
 * @Author frank.zheng
 * @Date 2023-08-01
 */
@Slf4j
public class BpmXmlI18nConverter {

    public static final BpmXmlI18nConverter INSTANCE = new BpmXmlI18nConverter();

    /**
     * 通过数据库 i18n 配置获取集合，格式：Map<节点ID/流转线ID, MainI18nInfoVO>
     *
     * @param dbI18nList 数据库中 i18n, content格式：Map<节点ID/流转线ID, 国际化信息>
     */
    public Map<String, MainI18nInfoVO> getDBI18nMap4ConfByContent(DosmModuleI18nConf moduleI18nConf, List<DosmModuleI18nEntity> dbI18nList) {
        if(CollectionUtils.isEmpty(dbI18nList)) {
            return Maps.newHashMap();
        }

        Map<String, MainI18nInfoVO> nodeI18nMap = Maps.newHashMap();
        for(DosmModuleI18nEntity dbI18n: dbI18nList) {
            // 获取节点国际化集合
            Map<String, Object> nodeContentI18nMap = JsonUtils.parseObject(dbI18n.getContent());
            if(MapUtils.isEmpty(nodeContentI18nMap)) {
                log.warn("No node content, procId: {}", dbI18n.getMainId());
                continue;
            }

            for(Map.Entry<String, Object> nodeContentEntry: nodeContentI18nMap.entrySet()) {
                String nodeId = nodeContentEntry.getKey();
                String nodeContentI18n = (String) nodeContentEntry.getValue();
                // 每个节点国际化配置
                Map<String, List<String>> contentMap = nodeI18nMap.computeIfAbsent(nodeId, k -> MainI18nInfoVO.builder()
                                .moduleCode(moduleI18nConf.getModuleCode())
                                .mainId(moduleI18nConf.getMainId())
                                .dataCode(moduleI18nConf.getDataCode())
                                .extCode(nodeId)
                                .content(Maps.newHashMap())
                                .leaf(I18nConstant.LEAF_1)
                                .build()
                        ).getContent();
                contentMap.put(dbI18n.getLanguage(), Lists.newArrayList(nodeContentI18n));
            }
        }
        return nodeI18nMap;
    }

    /**
     * 通过多语言信息获取保存对象，最终content格式：{"节点CODE": "国际化值","连接线CODE":""}
     * @param i18nList 数据格式：{"module_code"："M_PROCESS_BPM", "main_id"："流程ID", "data_code"："流程定义ID", "ext_code": "节点CODE/连接线CODE", "content": {"zh_CN":["国际化", "国际化ID"]}, "leaf": "0/1", "childs": []}
     * @return
     */
    public List<DosmModuleI18nEntity> getI18n4EntityByContent(List<MainI18nInfoVO> i18nList) {
        if(CollectionUtils.isEmpty(i18nList)) {
            return null;
        }

        // 多语言结果，格式：Map<语言，Map<nodeId, 国际化值>>
        Map<String, Map<String, String>> resultContentMap = Maps.newHashMap();
        Map<String, Map<String, String>> resultMergeContentMap = Maps.newHashMap();
        for(MainI18nInfoVO i18nInfo: i18nList) {
            Map<String, List<String>> nodeContentMap = i18nInfo.getContent();
            if(MapUtils.isEmpty(nodeContentMap)) {
                continue;
            }

            // 单个节点 merge 后的语言内容
            String mergeContent = null;
            List<Map<String, String>> mergeContentIsNullList = Lists.newArrayList();
            for(Map.Entry<String, List<String>> nodeContentEntry: nodeContentMap.entrySet()) {
                // 获取语言对应配置
                Map<String, String> nodeI18nMap = resultContentMap.computeIfAbsent(nodeContentEntry.getKey(), k -> Maps.newHashMap());
                Map<String, String> nodeMergeI18nMap = resultMergeContentMap.computeIfAbsent(nodeContentEntry.getKey(), k -> Maps.newHashMap());
                if(CollectionUtils.isEmpty(nodeContentEntry.getValue()) || StringUtils.isEmpty(nodeContentEntry.getValue().get(0))) {
                    mergeContentIsNullList.add(nodeMergeI18nMap);
                } else {
                    nodeI18nMap.put(i18nInfo.getExtCode(), mergeContent = nodeContentEntry.getValue().get(0));
                    nodeMergeI18nMap.put(i18nInfo.getExtCode(), mergeContent);
                }
            }

            if (mergeContent != null) {
                for (Map<String, String> item : mergeContentIsNullList) {
                    item.put(i18nInfo.getExtCode(), mergeContent);
                }
            }
        }

        List<DosmModuleI18nEntity> resultList = Lists.newArrayList();
        for(Map.Entry<String, Map<String, String>> entry: resultContentMap.entrySet()) {
            DosmModuleI18nEntity entity = ModuleI18nConverter.vo2Entity(i18nList.get(0));
            entity.setModuleCode(I18nConstant.ModuleCode.M_PROCESS_BPM);
            entity.setExtCode(null);
            entity.setPropertyCode(null);
            entity.setLanguage(entry.getKey());
            entity.setContent(JsonUtils.toJsonString(entry.getValue()));
            entity.setMergeContent(JsonUtils.toJsonString(resultMergeContentMap.get(entry.getKey())));
            resultList.add(entity);
        }

        return resultList;
    }
}
