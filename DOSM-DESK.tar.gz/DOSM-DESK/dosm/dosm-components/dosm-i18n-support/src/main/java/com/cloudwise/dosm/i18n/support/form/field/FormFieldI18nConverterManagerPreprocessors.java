package com.cloudwise.dosm.i18n.support.form.field;

/**
 * 表单 schema 及字段国际化的前置处理
 * @author jon.lee
 * @since 2023-10-09 15:24
 **/
public interface FormFieldI18nConverterManagerPreprocessors {
}
