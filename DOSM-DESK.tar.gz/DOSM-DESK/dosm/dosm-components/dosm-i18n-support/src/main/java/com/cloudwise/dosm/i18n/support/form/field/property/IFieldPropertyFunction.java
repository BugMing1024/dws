package com.cloudwise.dosm.i18n.support.form.field.property;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * 字段属性配置函数
 * @Author frank.zheng
 * @Date 2023-07-30
 */
public interface IFieldPropertyFunction {

    /** 获取字段属性 */
    FieldPropertyEnum getProperty();


    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     * @param paramContext
     */
    void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext);


    /**
     * 同步其他语言国际化信息
     */
    default void syncFieldPropertyI18n4UpdateByStr(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext, String currPropertyValue, boolean setFieldValueTye) {

        String orgPropertyValueStr = null;
        // 【非当前语言的国际化】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
        Map<String, Map<String, Object>> fieldPropertyContentI18nMap = null;
        if(paramContext.isPreVerField()) {
            /** 上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步 */
            orgPropertyValueStr = (String) paramContext.getDbPreVerFieldPropertyContentI18n(this.getProperty().getPropertyCode());
            fieldPropertyContentI18nMap = paramContext.getDbPreVerFieldPropertyContentI18nMap();
        } else {
            /** 上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步 */
            orgPropertyValueStr = (String) paramContext.getDbPublicFieldPropertyContentI18n(this.getProperty().getPropertyCode());
            fieldPropertyContentI18nMap = paramContext.getDbPublicFieldPropertyContentI18nMap();
        }

        this.syncPropertyContentI18n4UpdateByStr(paramContext, StringUtils.isBlank(orgPropertyValueStr) || StringUtils.equals(currPropertyValue, orgPropertyValueStr), fieldPropertyContentI18nMap, setFieldValueTye);

        this.mergeFieldSchemaDataSourceI18n4UpdateByStr(paramContext, currPropertyValue, setFieldValueTye);
    }

    /**
     * 同步其他语言国际化信息
     * <p>1、上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步
     * <p>2、上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步
     */
    default void syncPropertyContentI18n4UpdateByStr(FormSchema4UpdateParamBean paramContext, boolean isSync, Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap, boolean setFieldValueTye) {
        // 自定义选项未变更
        if(!isSync || MapUtils.isEmpty(syncFieldPropertyContentI18nMap)) {
            return;
        }
        // 【表单、字段使用】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
        for(Map.Entry<String, Map<String, Object>> syncDbPropertyContentI18nEntry: syncFieldPropertyContentI18nMap.entrySet()) {
            Map<String, Object> syncDbPropertyContentI18nMap = syncDbPropertyContentI18nEntry.getValue();
            if(MapUtils.isEmpty(syncDbPropertyContentI18nMap)) {
                continue;
            }
            String syncI18nContentStr = (String) syncDbPropertyContentI18nMap.get(this.getProperty().getPropertyCode());
            if(StringUtils.isBlank(syncI18nContentStr)) {
                continue;
            }
            // 同步该语言的选项国际化信息
            Map<String, Object> syncPropertyContentI18nMap = paramContext.getSyncFieldPropertyI18nContentMap().computeIfAbsent(syncDbPropertyContentI18nEntry.getKey(), k -> Maps.newHashMap());
            syncPropertyContentI18nMap.put(this.getProperty().getPropertyCode(), syncI18nContentStr);

            if(setFieldValueTye) {
                syncPropertyContentI18nMap.put(FieldPropertyConstant.K_FIELD_TYPE, paramContext.getFieldValueType());
            }
        }
    }

    /**
     * 同步其他语言国际化信息
     */
    default void mergeFieldSchemaDataSourceI18n4UpdateByStr(FormSchema4UpdateParamBean paramContext, String currPropertyValue, boolean setFieldValueTye) {
        // 属性同步的 其他语言的 国际化 content
        for(Map.Entry<String, Map<String, Object>> syncFieldPropertyI18nContentEntry: paramContext.getSyncFieldPropertyI18nContentMap().entrySet()) {
            Map<String, Object> syncPropertyI18nMergeContent = paramContext.getSyncFieldPropertyI18nMergeContentMap().computeIfAbsent(syncFieldPropertyI18nContentEntry.getKey(), k -> Maps.newHashMap());

            if(setFieldValueTye) {
                syncPropertyI18nMergeContent.put(FieldPropertyConstant.K_FIELD_TYPE, paramContext.getFieldValueType());
            }

            /** 同步的 - 其他语言 - 国际化不存 */
            if(MapUtils.isEmpty(syncFieldPropertyI18nContentEntry.getValue())) {
                syncPropertyI18nMergeContent.put(this.getProperty().getPropertyCode(), currPropertyValue);
                continue;
            }

            String syncPropertyI18nContent = (String) syncFieldPropertyI18nContentEntry.getValue().get(this.getProperty().getPropertyCode());
            /** 同步的 - 其他语言 - 国际化 content 信息未配置 */
            if(StringUtils.isBlank(syncPropertyI18nContent)) {
                syncPropertyI18nMergeContent.put(this.getProperty().getPropertyCode(), currPropertyValue);
                continue;
            }

            /** 同步的 - 其他语言 - 国际化信息存在配置 */
            syncPropertyI18nMergeContent.put(this.getProperty().getPropertyCode(), syncPropertyI18nContent);
        }

        // 【当前语言】【merge】国际化
        paramContext.getFieldPropertyI18nMergeContentMap().put(this.getProperty().getPropertyCode(), currPropertyValue);
    }


    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity          模块 i18n 配置
     * @param fieldSchemaConfig         表单配置
     * @param fieldPropertyI18nMap       字段国际化
     * @param publicFieldPropertyI18nMap 字段对应的公共国际化
     */
    void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap);

    /**
     * 属性是否可以处理数据数据
     * @param fieldI18n
     * @return
     */
    default boolean isMatch(MainI18nInfoVO fieldI18n) {
        return getProperty().getPropertyCode().equals(fieldI18n.getPropertyCode());
    }

    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     * @return
     */
    void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param);

    /**
     * 【查询】将字段 i18n 配置转为 map，格式：Map<propertyCode, MainI18nInfoVO>
     * @param moduleI18nConf
     * @param fieldI18nMap         字段国际化信息，格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
     * @param fieldPropertyI18nMap 字段 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap);

    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param mainI18nInfoList 字段下属性的mainI8nInfo集合【用于选项特殊情况】
     * @param fieldPropertyI18nMap 字段属性的 I8n ，格式：Map<propertyCode, MainI18nInfoVO>
     * @param publicFieldPropertyI18nMap 公共字段属性 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList,
            Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap);


    /**
     * 默认语言 国际化
     * @param moduleI18nConf
     * @param propertyNameI18n
     * @param extCode
     * @param type
     * @param propertyCode
     * @param content
     * @return
     */
    default MainI18nInfoVO getDefaultLanguageI18nInfo(DosmModuleI18nConf moduleI18nConf, Integer propertyNameI18n, String extCode, String type, String propertyCode, String content) {

        Map<String, List<String>> contentMap = Maps.newHashMap();
        // 设置默认语言值【模块对象中获取属性值】
        contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(content));

        return MainI18nInfoVO.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .dataCode(moduleI18nConf.getDataCode())
                .extCode(extCode)
                .type(type)
                .propertyCode(propertyCode)
                .propertyCodeName(MessageUtils.get(propertyNameI18n))
                .content(contentMap)
                .build();
    }


    /**
     * 【fieldVo - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据
     * @param moduleI18nEntity 模块 i18n 配置
     * @param fieldMap 字段信息配置（fieldVo对象）
     * @param fieldPropertyI18nMap 字段属性国际化信息
     * @param publicFieldPropertyI18nMap 公共字段属性国际化信息
     */
    default void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {}

    default void buildFieldI18n4FieldList4FillAndExtend(Map<String, Object> fieldSchemaMap, Map<String, Map<String, Object>> dbFieldI18nMap){}
}
