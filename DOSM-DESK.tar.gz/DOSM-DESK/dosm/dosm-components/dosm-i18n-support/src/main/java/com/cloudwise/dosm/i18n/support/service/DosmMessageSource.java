package com.cloudwise.dosm.i18n.support.service;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.i18n.support.core.service.IMessageSource;
import org.springframework.stereotype.Component;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
@Component
public class DosmMessageSource implements IMessageSource {
    @Override
    public String get(Integer i18nCode) {
        return MessageUtils.get(i18nCode);
    }
}
