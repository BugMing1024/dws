package com.cloudwise.dosm.i18n.support.core.vo;

import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 流程国际化信息
 * @Author terrell.huang
 * @Date 2023-12-12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CatalogI18nVo {
    /** 流程基本信息 国际化信息 */
    private List<MainI18nInfoVO> catalog;

    /** 服务目录-展示设置配置 */
    private List<MainI18nInfoVO> catalogDisplayConfig;

}
