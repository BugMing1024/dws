package com.cloudwise.dosm.i18n.support.cache;

import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Maps;

import java.util.List;
import java.util.Map;

/**
 * 公共字段 国际化 缓存
 *
 * @Author frank.zheng
 * @Date 2023-08-07
 */
public interface ITranslationPublicFieldCache {

    /**
     * 【国际化配置】公共字段缓存数据，格式：Map<language, Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>>
     */
    Map<String, Map<String, Map<String, MainI18nInfoVO>>> CACHE_I18N_CONF_MAP = Maps.newHashMap();

    /**
     * 【查询专用】公共字段缓存 mergeContent 数据，格式：Map<language, Map<fieldCode, Map<propertyCode, mergeContent>>>
     */
    Map<String, Map<String, Map<String, Object>>> CACHE_MERGE_CONTENT_CONF_MAP = Maps.newHashMap();

    /**
     * 【查询专用】公共字段缓存 content 数据，格式：Map<language, Map<fieldCode, Map<propertyCode, content>>>
     */
    Map<String, Map<String, Map<String, Object>>> CACHE_CONTENT_CONF_MAP = Maps.newHashMap();

    /**
     * 【多语言设置】获取缓存的公共字段，数据格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    default Map<String, Map<String, MainI18nInfoVO>> get4I18nConf(I18nReq i18nReq) {
        Map<String, Map<String, MainI18nInfoVO>> publicFieldMap = CACHE_I18N_CONF_MAP.get(i18nReq.getDefaultLanguage());
//        if (MapUtils.isEmpty(publicFieldMap)) {
            publicFieldMap = getAllPublicFieldI18n4ConfMap(i18nReq);
//            this.set4I18nConf(i18nReq.getDefaultLanguage(), publicFieldMap);
//        }
        return publicFieldMap;
    }

    /**
     * 【多语言设置】获取缓存的公共字段，数据格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    default void set4I18nConf(String language, Map<String, Map<String, MainI18nInfoVO>> publicFieldMap) {
        Map<String, Map<String, MainI18nInfoVO>> cacheMap = CACHE_I18N_CONF_MAP.get(language);
        if(cacheMap == null) {
            CACHE_I18N_CONF_MAP.put(language, publicFieldMap);
        } else {
            cacheMap.putAll(publicFieldMap);
        }
    }

    /**
     * 【查询功能专用】获取缓存的公共字段，数据格式：Map<fieldCode, Map<propertyCode, mergeContent>>
     */
    default Map<String, Map<String, Object>> getMergeContent4Query(String language) {
        Map<String, Map<String, Object>> publicFieldMap = CACHE_MERGE_CONTENT_CONF_MAP.get(language);
//        if (MapUtils.isEmpty(publicFieldMap)) {
            publicFieldMap = getAllPublicFieldMergeContent4QueryMap(language);
//            this.setMergeContent4Query(language, publicFieldMap);
//        }
        return publicFieldMap;
    }

    /**
     * 【查询功能专用】设置缓存 - 公共字段，数据格式：Map<language, Map<fieldCode, Map<propertyCode, mergeContent>>>
     */
    default void setMergeContent4Query(String language, Map<String, Map<String, Object>> publicFieldMap) {
        Map<String, Map<String, Object>> cacheMap = CACHE_MERGE_CONTENT_CONF_MAP.get(language);
        if(cacheMap == null) {
            CACHE_MERGE_CONTENT_CONF_MAP.put(language, publicFieldMap);
        } else {
            cacheMap.putAll(publicFieldMap);
        }
    }

    /**
     * 【查询功能专用】获取缓存的公共字段，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>>
     */
    default Map<String, Map<String, Map<String, Object>>> getContent4Query(List<String> languages) {
        Map<String, Map<String, Map<String, Object>>> resultMap = Maps.newHashMap();
        for(String language: languages) {
            Map<String, Map<String, Object>> publicFieldMap = getContent4Query(language);
            resultMap.put(language, publicFieldMap);
        }
        return resultMap;
    }

    /**
     * 【查询功能专用】获取缓存的公共字段，数据格式：Map<fieldCode, Map<propertyCode, content>>
     */
    default Map<String, Map<String, Object>> getContent4Query(String language) {
        Map<String, Map<String, Object>> publicFieldMap = CACHE_CONTENT_CONF_MAP.get(language);
//        if (MapUtils.isEmpty(publicFieldMap)) {
            publicFieldMap = getAllPublicFieldMergeContent4QueryMap(language);
//            this.setContent4Query(language, publicFieldMap);
//        }
        return publicFieldMap;
    }

    /**
     * 【查询功能专用】设置缓存 - 公共字段，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>>
     */
    default void setContent4Query(String language, Map<String, Map<String, Object>> publicFieldMap) {
        Map<String, Map<String, Object>> cacheMap = CACHE_CONTENT_CONF_MAP.get(language);
        if(cacheMap == null) {
            CACHE_CONTENT_CONF_MAP.put(language, publicFieldMap);
        } else {
            cacheMap.putAll(publicFieldMap);
        }
    }

    /**
     * 【多语言设置】获取所有公共字段国际化信息
     */
    Map<String, Map<String, MainI18nInfoVO>> getAllPublicFieldI18n4ConfMap(I18nReq i18nReq);


    /**
     * 【查询功能专用】获取所有公共字段 mergeContent 国际化信息
     */
    Map<String, Map<String, Object>> getAllPublicFieldMergeContent4QueryMap(String language);

    /**
     * 【查询功能专用】获取所有公共字段 content 国际化信息
     */
    Map<String, Map<String, Object>> getAllPublicFieldContent4QueryMap(String language);

}
