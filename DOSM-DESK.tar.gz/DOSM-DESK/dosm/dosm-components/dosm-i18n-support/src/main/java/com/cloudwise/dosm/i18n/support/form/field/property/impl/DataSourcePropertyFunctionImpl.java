package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 自定义数据字典属性
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"dataSource":{"字典id1":"国际化值","字典id2":"国际化值"}}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "", "property_code": "自定义字典选项ID", "type": "dataSource", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "1"}
 * </ul>
 * </ol>
 *
 * @Author frank.zheng
 * @Date 2023-07-31
 */
@Slf4j
public class DataSourcePropertyFunctionImpl implements IFieldPropertyFunction {

    @Override
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.DATA_SOURCE;
    }

    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     * @param paramContext
     */
    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_PROPS);

        /** 自定义字典需要国际化 */
        String dataType = (String) xPropsMap.get(FieldPropertyConstant.K_DATA_TYPE);
        List<Map<String, Object>> dataSourceMapList = (List<Map<String, Object>>) xPropsMap.get(this.getProperty().getFieldKey());
        if (!FieldPropertyConstant.V_DATA_TYPE_CUSTOM.equals(dataType) && CollectionUtils.isEmpty(dataSourceMapList)) {
            return;
        }

        if (CollectionUtils.isEmpty(dataSourceMapList) || MapUtils.isEmpty(dataSourceMapList.get(0))) {
            log.warn("字段自定义选项为空：formId: {}, fieldCode: {}", moduleI18nConf.getMainId(), moduleI18nConf.getDataCode());
            return;
        }

        // 选项国际化 - content
        Map<String, String> dataSourceI18nContentMap = (Map<String, String>) paramContext.getFieldPropertyI18nContentMap().computeIfAbsent(this.getProperty().getFieldKey(), k -> Maps.newHashMap());
        this.buildFieldSchemaDataSourceI18n4Update(dataSourceMapList, dataSourceI18nContentMap);


        /** 同步其他语言国际化信息 */
        this.syncFieldPropertyI18n4Update(paramContext, dataSourceI18nContentMap);

    }


    /**
     * 同步其他语言国际化信息
     */
    private void syncFieldPropertyI18n4Update(FormSchema4UpdateParamBean paramContext, Map<String, String> dataSourceI18nContentMap) {
        Map<String, String> orgFieldDataSourceMap = null;
        // 【非当前语言的国际化】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
        Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap = null;
        if(paramContext.isPreVerField()) {
            /** 上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步 */
            orgFieldDataSourceMap = (Map<String, String>) paramContext.getDbPreVerFieldPropertyContentI18n(this.getProperty().getFieldKey());
            syncFieldPropertyContentI18nMap = paramContext.getDbPreVerFieldPropertyContentI18nMap();
        } else {
            /** 上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步 */
            orgFieldDataSourceMap = (Map<String, String>) paramContext.getDbPublicFieldPropertyContentI18n(this.getProperty().getFieldKey());
            syncFieldPropertyContentI18nMap = paramContext.getDbPublicFieldPropertyContentI18nMap();
        }

        this.syncPropertyContentI18n4UpdateByMap(paramContext, dataSourceI18nContentMap, orgFieldDataSourceMap, syncFieldPropertyContentI18nMap);

        /** 字段属性国际化信息 merge */
        mergeFieldSchemaDataSourceI18n4UpdateByMap(paramContext, dataSourceI18nContentMap);
    }

    /**
     * 获取数据字典不同级别配置信息
     * @param dataSourceMapList
     */
    private void buildFieldSchemaDataSourceI18n4Update(List<Map<String, Object>> dataSourceMapList, Map<String, String> dataSourceI18nContentMap) {

        for (Map<String, Object> optionMap : dataSourceMapList) {
            String valueStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_VALUE);
            String labelStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_LABEL);
            dataSourceI18nContentMap.put(valueStr, labelStr);

            List<Map<String, Object>> childrenOptionMapList = (List<Map<String, Object>>) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_CHILDREN);
            if(CollectionUtils.isEmpty(childrenOptionMapList)) {
                continue;
            }

            this.buildFieldSchemaDataSourceI18n4Update(childrenOptionMapList, dataSourceI18nContentMap);
        }
    }

    /**
     * 同步其他语言国际化信息
     * <p>1、上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步
     * <p>2、上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步
     */
    private void syncPropertyContentI18n4UpdateByMap(FormSchema4UpdateParamBean paramContext, Map<String, String> dataSourceI18nContentMap, Map<String, String> orgDataSourceMap, Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap) {
        if(MapUtils.isEmpty(syncFieldPropertyContentI18nMap) || MapUtils.isEmpty(dataSourceI18nContentMap)) {
            return;
        }

        boolean orgDataSourceIsEmpty = MapUtils.isEmpty(orgDataSourceMap);
        for(Map.Entry<String, String> dataSourceI18nEntry: dataSourceI18nContentMap.entrySet()) {
            String valueStr = dataSourceI18nEntry.getKey();
            String labelStr = dataSourceI18nEntry.getValue();
            String orgLabelStr = null;
            // 自定义选项未变更
            if(orgDataSourceIsEmpty || StringUtils.isBlank(orgLabelStr = orgDataSourceMap.get(valueStr)) || StringUtils.equals(orgLabelStr, labelStr)) {
                // 【表单、字段使用】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
                for(Map.Entry<String, Map<String, Object>> syncDbPropertyContentI18nEntry: syncFieldPropertyContentI18nMap.entrySet()) {
                    Map<String, Object> syncDbPropertyContentI18nMap = syncDbPropertyContentI18nEntry.getValue();
                    if(MapUtils.isEmpty(syncDbPropertyContentI18nMap)) {
                        continue;
                    }
                    Map<String, String> syncDbOptionContentI18nMap = (Map<String, String>)syncDbPropertyContentI18nMap.get(this.getProperty().getFieldKey());
                    if(MapUtils.isEmpty(syncDbOptionContentI18nMap)) {
                        continue;
                    }
                    String syncDbOptionContentI18n = syncDbOptionContentI18nMap.get(valueStr);
                    if(StringUtils.isBlank(syncDbOptionContentI18n)) {
                        continue;
                    }
                    // 同步该语言的选项国际化信息
                    Map<String, Object> syncPropertyContentI18nMap = paramContext.getSyncFieldPropertyI18nContentMap().computeIfAbsent(syncDbPropertyContentI18nEntry.getKey(), k -> Maps.newHashMap());
                    Map<String, String> syncContentI18nMap = (Map<String, String>) syncPropertyContentI18nMap.computeIfAbsent(this.getProperty().getFieldKey(), k -> Maps.newHashMap());
                    syncContentI18nMap.put(valueStr, syncDbOptionContentI18n);
                }
            }
        }
    }


    /**
     * 字段属性国际化信息 merge
     */
    private void mergeFieldSchemaDataSourceI18n4UpdateByMap(FormSchema4UpdateParamBean paramContext, Map<String, String> dataSourceI18nContentMap) {
        // 属性同步的 其他语言的 国际化 content
        for(Map.Entry<String, Map<String, Object>> syncFieldPropertyI18nContentEntry: paramContext.getSyncFieldPropertyI18nContentMap().entrySet()) {
            Map<String, String> syncOptionI18nMergeContentMap = (Map<String, String>) paramContext.getSyncFieldPropertyI18nMergeContentMap()
                    .computeIfAbsent(syncFieldPropertyI18nContentEntry.getKey(), k -> Maps.newHashMap())
                    .computeIfAbsent(this.getProperty().getFieldKey(), k -> Maps.newHashMap());

            /** 同步的 - 其他语言 - 国际化不存 */
            if(MapUtils.isEmpty(syncFieldPropertyI18nContentEntry.getValue())) {
                // 将当前语言国际化同步到其他语言的 mergeContent
                syncOptionI18nMergeContentMap.putAll(dataSourceI18nContentMap);
                continue;
            }

            Map<String, String> syncOptionI18nContentMap = (Map<String, String>) syncFieldPropertyI18nContentEntry.getValue().get(this.getProperty().getFieldKey());
            /** 同步的 - 其他语言 - 国际化 content 信息未配置 */
            if(MapUtils.isEmpty(syncOptionI18nContentMap)) {
                // 将当前语言国际化同步到其他语言的 mergeContent
                syncOptionI18nMergeContentMap.putAll(dataSourceI18nContentMap);
                continue;
            }

            /** 同步的 - 其他语言 - 国际化信息存在配置 */
            for(Map.Entry<String, String> dataSourceI18nEntry: dataSourceI18nContentMap.entrySet()) {
                String value = dataSourceI18nEntry.getKey();
                String label = dataSourceI18nEntry.getValue();
                String syncLabel = syncOptionI18nContentMap.get(value);
                if(StringUtils.isBlank(syncLabel)) {
                    syncOptionI18nMergeContentMap.put(value, label);
                } else {
                    syncOptionI18nMergeContentMap.put(value, syncLabel);
                }
            }
        }

        // 【当前语言】【merge】国际化
        paramContext.getFieldPropertyI18nMergeContentMap().put(this.getProperty().getFieldKey(), dataSourceI18nContentMap);
    }






    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity          模块 i18n 配置
     * @param fieldSchemaConfig         表单配置
     * @param fieldPropertyI18nMap       字段国际化
     * @param publicFieldPropertyI18nMap 字段对应的公共国际化
     */
    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {
        // 获取自定义字典选项
        Map<String, Object> dataSourceMap = (Map<String, Object>) fieldPropertyI18nMap.get(this.getProperty().getFieldKey());
        if (MapUtils.isEmpty(dataSourceMap)) {
            return;
        }

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

        /** 自定义字典需要国际化 */
        String dataType = (String) xPropsMap.get(FieldPropertyConstant.K_DATA_TYPE);
        if (!FieldPropertyConstant.V_DATA_TYPE_CUSTOM.equals(dataType) && MapUtils.isEmpty(dataSourceMap)) {
            return;
        }
        List<Map<String, Object>> dataSourceMapList = (List<Map<String, Object>>) xPropsMap.get(this.getProperty().getFieldKey());
        if (CollectionUtils.isEmpty(dataSourceMapList) || MapUtils.isEmpty(dataSourceMapList.get(0))) {
            log.warn("字段自定义选项为空：formId: {}, fieldCode: {}", moduleI18nEntity.getMainId(), moduleI18nEntity.getDataCode());
            return;
        }

        // 选项国际化
        this.buildFieldSchemaDataSourceI18n4Query(dataSourceMapList, dataSourceMap);
    }


    /**
     * 设置数据字典不同级别配置信息
     * @param dataSourceMapList
     * @param dataSourceMap
     */
    private void buildFieldSchemaDataSourceI18n4Query(List<Map<String, Object>> dataSourceMapList, Map<String, Object> dataSourceMap) {
        // 选项国际化
        for (Map<String, Object> optionMap : dataSourceMapList) {
            String valueStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_VALUE);
            String labelI18nStr = (String) dataSourceMap.get(valueStr);
            if (StringUtils.isNotBlank(labelI18nStr)) {
                optionMap.put(FieldPropertyConstant.K_DATA_SOURCE_LABEL, labelI18nStr);
            }

            List<Map<String, Object>> childrenOptionMapList = (List<Map<String, Object>>) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_CHILDREN);
            if(CollectionUtils.isEmpty(childrenOptionMapList)) {
                continue;
            }

            this.buildFieldSchemaDataSourceI18n4Query(childrenOptionMapList, dataSourceMap);
        }
    }





    /**
     * 属性是否可以处理数据数据
     *
     * @param fieldI18n
     * @return
     */
    @Override
    public boolean isMatch(MainI18nInfoVO fieldI18n) {
        return getProperty().getFieldKey().equals(fieldI18n.getType());
    }






    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     * @return
     */
    @Override
    public void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param) {
        Map<String, List<String>> contentI18nMap = fieldI18n.getContent();

        String fieldCode = fieldI18n.getDataCode();
        // 属性 merge 后的语言内容
        String mergeContent = null;
        List<Map<String, Object>> mergeContentIsNullList = Lists.newArrayList();
        for (Map.Entry<String, List<String>> contentI18nEntry : contentI18nMap.entrySet()) {
            String language = contentI18nEntry.getKey();
            // 【某语言下字段】国际化集合,格式：Map<字段，Map<propertyCode, Object>>
            Map<String, Map<String, Object>> languageI18nMap = param.getResultI18nMap().computeIfAbsent(language, k -> Maps.newHashMap());
            // 【字段下各属性】国际化集合,格式：Map<propertyCode, Object>
            Map<String, Object> fieldI18nMap = languageI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());
            // 【选项】国际化集合,格式：Map<选项ID, "国际化">
            Map<String, Object> dataSourceI18nMap = (Map<String, Object>) fieldI18nMap.computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

            Map<String, Object> dataSourceMergeI18nMap = (Map<String, Object>) param.getResultMergeI18nMap().computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(fieldCode, k -> Maps.newHashMap())
                    .computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

            List<String> contentList = contentI18nEntry.getValue();
            String content = null;
            // 配置国际化为空
            if (CollectionUtils.isEmpty(contentList) || StringUtils.isBlank(content = contentList.get(0))) {
                mergeContentIsNullList.add(dataSourceMergeI18nMap);
            } else {
                dataSourceI18nMap.put(fieldI18n.getPropertyCode(), mergeContent = content);
                dataSourceMergeI18nMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }

        if (mergeContent != null) {
            for (Map<String, Object> mergeContentMap : mergeContentIsNullList) {
                mergeContentMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }

    }





    /**
     * 【查询】将字段 i18n 配置转为 map，格式：Map<propertyCode, MainI18nInfoVO>
     * @param moduleI18nConf
     * @param fieldI18nMap         字段国际化信息，格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
     * @param fieldPropertyI18nMap 字段 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap) {
        // 选项值信息
        Map<String, Object> dataSourceMap = (Map<String, Object>) fieldI18nMap.get(this.getProperty().getFieldKey());
        if (MapUtils.isEmpty(dataSourceMap)) {
            log.warn("not found dataSourceMap, key: {}", this.getProperty().getFieldKey());
            return;
        }

        for (Map.Entry<String, Object> entry : dataSourceMap.entrySet()) {
            // 设置语言值【模块对象中获取属性值】
            Map<String, List<String>> contentMap = fieldPropertyI18nMap.computeIfAbsent(this.getUUID(this.getProperty().getFieldKey(), entry.getKey()), k -> MainI18nInfoVO.builder()
                    .moduleCode(moduleI18nConf.getModuleCode())
                    .mainId(moduleI18nConf.getMainId())
                    .dataCode(moduleI18nConf.getDataCode())
                    .extCode(null)
                    .type(this.getProperty().getFieldKey())
                    .propertyCode(entry.getKey())
                    .content(Maps.newHashMap())
                    .build()
            ).getContent();

            contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList((String) entry.getValue()));
        }
    }






    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param mainI18nInfoList 字段下属性的mainI8nInfo集合【用于选项特殊情况】
     * @param fieldPropertyI18nMap 字段属性的 I8n ，格式：Map<propertyCode, MainI18nInfoVO>
     * @param publicFieldPropertyI18nMap 公共字段属性 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList,
                                                              Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

        /** 自定义字典需要国际化 */
        String dataType = (String) xPropsMap.get(FieldPropertyConstant.K_DATA_TYPE);
        List<Map<String, Object>> dataSourceMapList = (List<Map<String, Object>>) xPropsMap.get(this.getProperty().getFieldKey());
        if (!FieldPropertyConstant.V_DATA_TYPE_CUSTOM.equals(dataType) && CollectionUtils.isEmpty(dataSourceMapList)) {
            return null;
        }

        // 获取自定义字典选项

        if (CollectionUtils.isEmpty(dataSourceMapList) || MapUtils.isEmpty(dataSourceMapList.get(0))) {
            log.warn("字段自定义选项为空：formId: {}, fieldCode: {}", moduleI18nConf.getMainId(), moduleI18nConf.getDataCode());
            return null;
        }

        return buildMainI18nInfoByFieldDataSourceSchema4Conf(moduleI18nConf, mainI18nInfoList, fieldPropertyI18nMap, dataSourceMapList);
    }

    private MainI18nInfoVO buildMainI18nInfoByFieldDataSourceSchema4Conf(DosmModuleI18nConf moduleI18nConf, List<MainI18nInfoVO> mainI18nInfoList, Map<String, MainI18nInfoVO> fieldPropertyI18nMap,
            List<Map<String, Object>> dataSourceMapList) {
        MainI18nInfoVO currMainI18nInfo = null;
        for (Map<String, Object> optionMap : dataSourceMapList) {
            String valueStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_VALUE);
            String labelStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_LABEL);

            String itemUUID = this.getUUID(this.getProperty().getFieldKey(), valueStr);
            currMainI18nInfo = fieldPropertyI18nMap.get(itemUUID);
            if (currMainI18nInfo == null) {
                currMainI18nInfo = this.getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[0], null, this.getProperty().getFieldKey(), valueStr, labelStr);
            } else {
                currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[0]));
            }
            mainI18nInfoList.add(currMainI18nInfo);

            List<Map<String, Object>> childrenOptionMapList = (List<Map<String, Object>>) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_CHILDREN);
            if(CollectionUtils.isEmpty(childrenOptionMapList)) {
                continue;
            }

            // 存在子集数据字典，则设置当前字典为父级
            mainI18nInfoList = Lists.newArrayList();
            currMainI18nInfo.setLeaf(0);
            currMainI18nInfo.setChilds(mainI18nInfoList);

            buildMainI18nInfoByFieldDataSourceSchema4Conf(moduleI18nConf, mainI18nInfoList, fieldPropertyI18nMap, childrenOptionMapList);
        }
        return currMainI18nInfo;
    }


    /**
     * 【fieldVo - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据
     * @param moduleI18nEntity 模块 i18n 配置
     * @param fieldMap 字段信息配置（fieldVo对象）
     * @param fieldPropertyI18nMap 字段属性国际化信息
     * @param publicFieldPropertyI18nMap 公共字段属性国际化信息
     */
    @Override
    public void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {
        if (fieldPropertyI18nMap == null) {
            return;
        }
        // 获取字段 x-props
        Map<String, Object> fieldRuleMap = (Map<String, Object>) fieldMap.get(FieldPropertyConstant.FN_FIELD_RULE);
        List<Map<String, Object>> dataSourceMapList = (List<Map<String, Object>>) fieldRuleMap.get(FieldPropertyConstant.FN_ENUM_LIST);
        /** 自定义字典需要国际化 */
        String dataType = (String) fieldRuleMap.get(FieldPropertyConstant.FN_ENUM_SOURCE_TYPE);
        if (!FieldPropertyConstant.V_DATA_TYPE_CUSTOM.equals(dataType) && CollectionUtils.isEmpty(dataSourceMapList)) {
            return;
        }

        if (CollectionUtils.isEmpty(dataSourceMapList) || MapUtils.isEmpty(dataSourceMapList.get(0))) {
            log.warn("字段自定义选项为空：formId: {}, fieldCode: {}", moduleI18nEntity.getMainId(), moduleI18nEntity.getDataCode());
            return;
        }

        // 获取自定义字典选项
        Map<String, String> dataSourceMap = (Map<String, String>) fieldPropertyI18nMap.get(this.getProperty().getFieldKey());
        if (dataSourceMap == null) {
            return;
        }

        // 选项国际化
        for (Map<String, Object> optionMap : dataSourceMapList) {
            String valueStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_VALUE);
            String labelI18nStr = dataSourceMap.get(valueStr);
            if (StringUtils.isNotBlank(labelI18nStr)) {
                optionMap.put(FieldPropertyConstant.K_DATA_SOURCE_LABEL, labelI18nStr);
            }
        }
    }

    @Override
    public void buildFieldI18n4FieldList4FillAndExtend(Map<String, Object> fieldSchemaMap, Map<String, Map<String, Object>> dbFieldI18nMap) {
        Map<String, Object> fieldRuleMap = (Map<String, Object>) fieldSchemaMap.get(FieldPropertyConstant.FN_FIELD_RULE);
        List<Map<String, Object>> dataSourceMapList = (List<Map<String, Object>>) fieldRuleMap.get(FieldPropertyConstant.FN_ENUM_LIST);
        if(CollectionUtils.isEmpty(dataSourceMapList)) {
            return;
        }

        Map<String, String> labelValueMap = new HashMap<>();
        Map<String, String> labelValueMapBefore = new HashMap<>();

        for (Map<String, Object> optionMap : dataSourceMapList) {
            String valueStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_VALUE);
            String labelStr = (String) optionMap.get(FieldPropertyConstant.K_DATA_SOURCE_LABEL);
            labelValueMapBefore.put(labelStr, valueStr);
        }
        for (Map.Entry<String, Map<String, Object>> dbEntry : dbFieldI18nMap.entrySet()) {
            Map<String, Object> value = dbEntry.getValue();
            Map<String, String> dataSourceMap = (Map<String, String>) value.get(this.getProperty().getFieldKey());
            if (dataSourceMap == null) {
                continue;
            }
            Set<Map.Entry<String, String>> entries = dataSourceMap.entrySet();
            for (Map.Entry<String, String> entry : entries) {
                if (!labelValueMapBefore.containsKey(entry.getValue())) {
                    labelValueMap.put(entry.getValue(), entry.getKey());
                }
            }
        }

        for (Map.Entry<String, String> stringStringEntry : labelValueMap.entrySet()) {
            dataSourceMapList.add(new HashMap<String, Object>() {{
                put(FieldPropertyConstant.K_DATA_SOURCE_VALUE, stringStringEntry.getValue());
                put(FieldPropertyConstant.K_DATA_SOURCE_LABEL, stringStringEntry.getKey());
            }});
        }


    }

    private String getUUID(String fieldKey, String itemValue) {
        return fieldKey + ":" + itemValue;
    }
}
