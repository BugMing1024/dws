package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * 文字描述 国际化
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"defaultValue":"提示内容"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "", "property_code": "defaultValue", "type": "2", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": []}
 * </ul>
 * </ol>
 *
 * @Author frank.zheng
 * @Date 2023-07-31
 */
@Slf4j
public class DescPropertyFunctionImpl implements IFieldPropertyFunction {

    @Override
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.DESC;
    }


    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     * @param paramContext
     */
    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_PROPS);
        String descStr = (String) xPropsMap.get(this.getProperty().getFieldKey());
        paramContext.getFieldPropertyI18nContentMap().put(this.getProperty().getPropertyCode(), descStr);

        /**  同步其他语言国际化信息  */
        this.syncFieldPropertyI18n4UpdateByStr(moduleI18nConf, paramContext, descStr, false);
    }







    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity          模块 i18n 配置
     * @param fieldSchemaConfig         表单配置
     * @param fieldPropertyI18nMap       字段国际化
     * @param publicFieldPropertyI18nMap 字段对应的公共国际化
     */
    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {
        String descI18nStr = (String) fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if(StringUtils.isBlank(descI18nStr)) {
            return;
        }

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);
        xPropsMap.put(this.getProperty().getFieldKey(), descI18nStr);
        fieldSchemaConfig.put(FieldPropertyConstant.K_DEFAULT, descI18nStr);
    }







    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     * @return
     */
    @Override
    public void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param) {
        Map<String, List<String>> contentI18nMap = fieldI18n.getContent();

        String fieldCode = fieldI18n.getDataCode();
        // 属性 merge 后的语言内容
        String mergeContent = null;
        List<Map<String, Object>> mergeContentIsNullList = Lists.newArrayList();
        for (Map.Entry<String, List<String>> contentI18nEntry : contentI18nMap.entrySet()) {
            String language = contentI18nEntry.getKey();
            // 【某语言下字段】国际化集合,格式：Map<字段，Map<propertyCode, Object>>
            Map<String, Map<String, Object>> languageI18nMap = param.getResultI18nMap().computeIfAbsent(language, k -> Maps.newHashMap());
            // 【字段下各属性】国际化集合,格式：Map<propertyCode, Object>
            Map<String, Object> fieldI18nMap = languageI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());

            Map<String, Object> fieldMergeI18nMap = param.getResultMergeI18nMap().computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(fieldCode, k -> Maps.newHashMap());

            List<String> contentList = contentI18nEntry.getValue();
            String content = null;
            // 配置国际化为空
            if (CollectionUtils.isEmpty(contentList) || StringUtils.isBlank(content = contentList.get(0))) {
                mergeContentIsNullList.add(fieldMergeI18nMap);
            } else {
                fieldI18nMap.put(fieldI18n.getPropertyCode(), mergeContent = content);
                fieldMergeI18nMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }

        if (mergeContent != null) {
            for (Map<String, Object> mergeContentMap : mergeContentIsNullList) {
                mergeContentMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }
    }







    /**
     * 【查询】将字段 i18n 配置转为 map，格式：Map<propertyCode, MainI18nInfoVO>
     * @param moduleI18nConf
     * @param fieldI18nMap         字段国际化信息，格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
     * @param fieldPropertyI18nMap 字段 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap) {
        // 设置语言值【模块对象中获取属性值】
        Map<String, List<String>> contentMap = fieldPropertyI18nMap.computeIfAbsent(this.getProperty().getPropertyCode(), k -> MainI18nInfoVO.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .dataCode(moduleI18nConf.getDataCode())
                .extCode(null)
                .type(FieldPropertyConstant.V_HINT_CONTENT_LAYOUT_2)
                .propertyCode(this.getProperty().getPropertyCode())
                .content(Maps.newHashMap())
                .build()
        ).getContent();
        String desc = (String) fieldI18nMap.get(this.getProperty().getPropertyCode());
        contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(desc));
    }





    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param mainI18nInfoList 字段下属性的mainI8nInfo集合【用于选项特殊情况】
     * @param fieldPropertyI18nMap 字段属性的 I8n ，格式：Map<propertyCode, MainI18nInfoVO>
     * @param publicFieldPropertyI18nMap 公共字段属性 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList,
            Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {
        MainI18nInfoVO currMainI18nInfo = fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if (currMainI18nInfo == null) {
            // 获取字段 x-props
            Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);
            String descStr = (String) xPropsMap.get(this.getProperty().getFieldKey());

            currMainI18nInfo = getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[0], null, FieldPropertyConstant.V_HINT_CONTENT_LAYOUT_2, this.getProperty().getPropertyCode(), descStr);

            mainI18nInfoList.add(currMainI18nInfo);
            return currMainI18nInfo;
        } else {
            currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[0]));
        }
        mainI18nInfoList.add(currMainI18nInfo);
        return currMainI18nInfo;
    }



    @Override
    public void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {

    }
}
