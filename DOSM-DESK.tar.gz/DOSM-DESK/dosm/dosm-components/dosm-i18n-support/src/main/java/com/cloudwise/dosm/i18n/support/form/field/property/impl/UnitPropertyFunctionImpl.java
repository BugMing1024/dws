package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * 单位属性国际化
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"unit":"1"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "", "property_code": "unit", "type": "", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "1"}
 * </ul>
 * </ol>
 *
 * @Author frank.zheng
 * @Date 2023-07-31
 */
public class UnitPropertyFunctionImpl implements IFieldPropertyFunction {

    @Override
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.UNIT;
    }

    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_PROPS);

        String unit = (String) xPropsMap.get(this.getProperty().getFieldKey());
        paramContext.getFieldPropertyI18nContentMap().put(getProperty().getPropertyCode(), StringUtils.isBlank(unit)? null: unit);

        /**  同步其他语言国际化信息  */
        this.syncFieldPropertyI18n4UpdateByStr(moduleI18nConf, paramContext, unit, false);
    }


    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap,
            Map<String, Object> publicFieldPropertyI18nMap) {
        String unitI18nStr = (String) fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if(StringUtils.isBlank(unitI18nStr)) {
            return;
        }
        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

        xPropsMap.put(this.getProperty().getFieldKey(), unitI18nStr);
    }

    @Override
    public void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param) {
        Map<String, List<String>> contentI18nMap = fieldI18n.getContent();

        String fieldCode = fieldI18n.getDataCode();
        // 属性 merge 后的语言内容
        String mergeContent = null;
        List<Map<String, Object>> mergeContentIsNullList = Lists.newArrayList();
        for (Map.Entry<String, List<String>> contentI18nEntry : contentI18nMap.entrySet()) {
            String language = contentI18nEntry.getKey();
            // 【某语言下字段】国际化集合,格式：Map<字段，Map<propertyCode, Object>>
            Map<String, Map<String, Object>> languageI18nMap = param.getResultI18nMap().computeIfAbsent(language, k -> Maps.newHashMap());
            // 【字段下各属性】国际化集合,格式：Map<propertyCode, Object>
            Map<String, Object> fieldI18nMap = languageI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());

            Map<String, Object> fieldMergeI18nMap = param.getResultMergeI18nMap().computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(fieldCode, k -> Maps.newHashMap());

            List<String> contentList = contentI18nEntry.getValue();
            String content = null;
            // 配置国际化为空
            if (CollectionUtils.isEmpty(contentList) || StringUtils.isBlank(content = contentList.get(0))) {
                mergeContentIsNullList.add(fieldMergeI18nMap);
            } else {
                fieldI18nMap.put(fieldI18n.getPropertyCode(), mergeContent = content);
                fieldMergeI18nMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }

        if (mergeContent != null) {
            for (Map<String, Object> mergeContentMap : mergeContentIsNullList) {
                mergeContentMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }
    }

    @Override
    public void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap) {
        // 设置语言值【模块对象中获取属性值】
        Map<String, List<String>> contentMap = fieldPropertyI18nMap.computeIfAbsent(this.getProperty().getPropertyCode(), k -> MainI18nInfoVO.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .dataCode(moduleI18nConf.getDataCode())
                .extCode(moduleI18nConf.getExtCode())
                .type(null)
                .propertyCode(this.getProperty().getPropertyCode())
                .content(Maps.newHashMap())
                .build()
        ).getContent();

        String unit = (String) fieldI18nMap.get(this.getProperty().getPropertyCode());
        contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(unit));
    }

    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList, Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {
        MainI18nInfoVO currMainI18nInfo = fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if (currMainI18nInfo == null) {
            // 获取字段 x-props
            Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

            String unit = (String) xPropsMap.get(this.getProperty().getFieldKey());
            // 单位国际化
            currMainI18nInfo = getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[0], null, null, this.getProperty().getPropertyCode(), unit);

//            // 公共字段国际化
//            MainI18nInfoVO publicFieldI18nInfo = publicFieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
//            if(publicFieldI18nInfo != null) {
//                // 将公共字段国际化放入字段
//                Map<String, List<String>> publicFieldI18nMap = publicFieldI18nInfo.getContent();
//                for(Map.Entry<String, List<String>> publicFieldI18nEntry: publicFieldI18nMap.entrySet()) {
//                    List<String> currI18nList = currMainI18nInfo.getContent().get(publicFieldI18nEntry.getKey());
//                    if(CollectionUtils.isEmpty(currI18nList) || StringUtils.isBlank(currI18nList.get(0))) {
//                        currMainI18nInfo.getContent().put(publicFieldI18nEntry.getKey(), publicFieldI18nEntry.getValue());
//                    }
//                }
//            }
        } else {
            currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[0]));
        }
        mainI18nInfoList.add(currMainI18nInfo);
        return currMainI18nInfo;
    }

    @Override
    public void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {

    }
}
