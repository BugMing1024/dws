package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;

import java.util.List;
import java.util.Map;

/**
 * 标签容器字段国际化
 * @Author frank.zheng
 * @Date 2023-07-31
 */
public class GroupTitlePropertyFunctionImpl extends FieldTitlePropertyFunctionImpl implements IFieldPropertyFunction {
    
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.GROUP_TITLE;
    }


    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList, Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {
        MainI18nInfoVO currMainI18nInfo = fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if(currMainI18nInfo == null) {
            String title = (String) fieldSchemaConfig.get(this.getProperty().getFieldKey());
            // 字段编码
            String fieldValueType = (String) fieldSchemaConfig.get(FieldPropertyConstant.K_X_COMPONENT);
            currMainI18nInfo = getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[0], fieldValueType, null, this.getProperty().getPropertyCode(), title);

            mainI18nInfoList.add(currMainI18nInfo);
            return currMainI18nInfo;
        } else {
            currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[0]));
        }
        mainI18nInfoList.add(currMainI18nInfo);
        return currMainI18nInfo;
    }
}