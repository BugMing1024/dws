package com.cloudwise.dosm.i18n.support.core.vo;

import com.cloudwise.i18n.support.core.vo.I18nReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 数据字典 i18n 请求
 * @Author frank.zheng
 * @Date 2023-07-30
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "多语言设置 - 数据字典详情查询参数")
public class DictI18nReqVo extends I18nReq {


    @ApiModelProperty(value = "层级（int类型）", example = "1", required = true)
    private Integer level = 1;

    @ApiModelProperty(value = "是否查询停用项", example = "false")
    private boolean withDisable;
}
