package com.cloudwise.dosm.i18n.support.form.field.enums;

import com.cloudwise.dosm.core.constant.ResourceCode;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;
import com.cloudwise.dosm.i18n.support.form.field.property.impl.*;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 字段属性常量
 * @Author frank.zheng
 * @Date 2023-07-30
 */
@Getter
@AllArgsConstructor
public enum FieldPropertyEnum {

    /** 字段名称 */
    FIELD_TITLE(FieldPropertyConstant.K_TITLE, FieldPropertyConstant.K_TITLE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_TITLE},
            // 属性函数
            new FieldTitlePropertyFunctionImpl()
    ),

    /** 分组名称 */
    GROUP_TITLE(FieldPropertyConstant.K_TITLE, FieldPropertyConstant.K_TITLE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.GROUP_TITLE},
            // 属性函数
            new GroupTitlePropertyFunctionImpl()
    ),

    /** 标签容器名称 */
    TAB_TITLE(FieldPropertyConstant.K_TITLE, FieldPropertyConstant.K_TITLE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.TAB_TITLE},
            // 属性函数
            new TabTitlePropertyFunctionImpl()
    ),

    /** 标签页名称 */
    TAB_PANEL_TITLE(FieldPropertyConstant.K_TITLE, FieldPropertyConstant.K_TITLE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.TAB_PANEL_TITLE},
            // 属性函数
            new TabPanelTitlePropertyFunctionImpl()
    ),

    /** 表格名称 */
    TABLE_TITLE(FieldPropertyConstant.K_TITLE, FieldPropertyConstant.K_TITLE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.TABLE_TITLE},
            // 属性函数
            new TableTitlePropertyFunctionImpl()
    ),


    /** 提示 */
    HINT(FieldPropertyConstant.K_HINT, FieldPropertyConstant.K_HINT_CONTENT,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_HINT_CONTENT_1, ResourceCode.PropertyI18n.Process.FIELD_HINT_CONTENT_2, ResourceCode.PropertyI18n.Process.FIELD_HINT_CONTENT_3, ResourceCode.PropertyI18n.Process.FIELD_HINT_CONTENT_4},
            // 属性函数
            new HintPropertyFunctionImpl()
    ),

    /** 选项 */
    DATA_SOURCE(FieldPropertyConstant.K_DATA_SOURCE, FieldPropertyConstant.K_DATA_SOURCE_LABEL,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_DATA_SOURCE},
            // 属性函数
            new DataSourcePropertyFunctionImpl()
    ),

    /** 星级选项  */
    STAR_TIP(FieldPropertyConstant.K_TOOL_TIPS, FieldPropertyConstant.K_TOOL_TIPS,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_DATA_SOURCE},
            // 属性函数
            new StarTipPropertyFunctionImpl()
    ),

    /** 文字描述 */
    DESC(FieldPropertyConstant.K_DEFAULT_VALUE, FieldPropertyConstant.K_DEFAULT_VALUE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_DESC},
            // 属性函数
            new DescPropertyFunctionImpl()
    ),

    /** 单位 */
    UNIT(FieldPropertyConstant.K_UNIT, FieldPropertyConstant.K_UNIT,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_UNIT},
            // 属性函数
            new UnitPropertyFunctionImpl()
    ),


    /** 字段名称 */
    NAME(FieldPropertyConstant.K_NAME, FieldPropertyConstant.K_TITLE,
            // 国际化
            new Integer[]{ResourceCode.PropertyI18n.Process.FIELD_TITLE},
            // 属性函数
            new NamePropertyFunctionImpl()
    ),
    ;

    /** 字段key */
    private String fieldKey;
    /** 属性编码 */
    private String propertyCode;
    /** 属性国际化编码 */
    private Integer[] propertyNameI18ns;

    private IFieldPropertyFunction function;

}
