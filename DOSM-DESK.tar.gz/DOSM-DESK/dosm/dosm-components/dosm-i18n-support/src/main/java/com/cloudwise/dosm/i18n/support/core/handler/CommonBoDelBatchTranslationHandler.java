package com.cloudwise.dosm.i18n.support.core.handler;

import com.cloudwise.dosm.core.pojo.bo.CommonBo;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.handler.simple.AbstractDelTranslationHandler;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
@Component
public class CommonBoDelBatchTranslationHandler extends AbstractDelTranslationHandler<List<String>> {
    @Override
    protected List<String> getMainIdValue(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object[] args = joinPoint.getArgs();
        return ((CommonBo) args[0]).getIdList();
    }

    @Override
    public String getType() {
        return "commonBoDelBatchTranslationHandler";
    }
}
