package com.cloudwise.dosm.i18n.support.core.resources;

import com.cloudwise.dosm.i18n.support.core.enums.I18nModuleCode;
import com.cloudwise.dosm.i18n.support.core.service.DosmTranslationI18nService;
import com.cloudwise.dosm.i18n.support.core.vo.CatalogI18nVo;
import com.cloudwise.dosm.i18n.support.core.vo.DictI18nReqVo;
import com.cloudwise.dosm.i18n.support.core.vo.ProcessI18nVo;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.LanguageVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@RestController
@RequestMapping("/api/v2/i18n")
public class DosmI18nController {
    @Autowired
    TranslationI18nService translationI18nService;
    @Autowired
    DosmTranslationI18nService dosmTranslationI18nService;


    @PostMapping("/dictionary/list")
    public List<MainI18nInfoVO> getDictionaryList(@RequestBody DictI18nReqVo dictI18nReq) {
        List<LanguageVo> languageList = translationI18nService.getLauguageList();
        LanguageVo defaultLanguage = languageList.stream().filter(LanguageVo::getIsDefault).findAny().get();

        dictI18nReq.setDefaultLanguage(defaultLanguage.getValue());
        dictI18nReq.setLanguageList(languageList);
        List<MainI18nInfoVO> dataDictI18nList = null;
        if (dictI18nReq.getLevel() == 1) {
            dictI18nReq.setModuleCode(I18nModuleCode.M_DICT.name());
            dataDictI18nList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(dictI18nReq);
            if (CollectionUtils.isEmpty(dataDictI18nList)) {
                return dataDictI18nList;
            }
        }

        dictI18nReq.setModuleCode(I18nModuleCode.M_DICT_DETAIL.name());
        List<MainI18nInfoVO> dataDictDetailI18nList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(dictI18nReq);
        if (dataDictI18nList == null) {
            return dataDictDetailI18nList;
        }

        dataDictI18nList.addAll(dataDictDetailI18nList);
        return dataDictI18nList;
    }

    @PostMapping("/process/get")
    public ProcessI18nVo getProcessInfo(@RequestBody ProcessI18nVo i18nReq) {
        List<LanguageVo> languageList = translationI18nService.getLauguageList();
        LanguageVo defaultLanguage = languageList.stream().filter(LanguageVo::getIsDefault).findAny().get();


        I18nReq processModuleI18nReq = I18nReq.builder()
                .moduleCode(I18nConstant.ModuleCode.M_PROCESS)
                .mainId(i18nReq.getProcessId())
                .dataCode(i18nReq.getProcessDefId())
                .defaultLanguage(defaultLanguage.getValue())
                .languageList(languageList)
                .build();
        List<MainI18nInfoVO> processI18nList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(processModuleI18nReq);


        I18nReq formModuleI18nReq = I18nReq.builder()
                .moduleCode(I18nConstant.ModuleCode.M_PROCESS_FORM)
                .mainId(i18nReq.getFormId())
                .defaultLanguage(defaultLanguage.getValue())
                .languageList(languageList)
                .build();
        List<MainI18nInfoVO> formI18nList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(formModuleI18nReq);

        I18nReq bpmModuleI18nReq = I18nReq.builder()
                .moduleCode(I18nConstant.ModuleCode.M_PROCESS_BPM)
                .mainId(i18nReq.getProcessId())
                .dataCode(i18nReq.getProcessDefId())
                .defaultLanguage(defaultLanguage.getValue())
                .languageList(languageList)
                .build();
        List<MainI18nInfoVO> bpmI18nList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(bpmModuleI18nReq);

        return ProcessI18nVo.builder()
                .processId(i18nReq.getProcessId())
                .processDefId(i18nReq.getProcessDefId())
                .formId(i18nReq.getFormId())
                .process(processI18nList)
                .form(formI18nList)
                .bpm(bpmI18nList)
                .build();
    }

    @PostMapping("/catalog/get")
    public CatalogI18nVo getCatalogInfo() {
        List<LanguageVo> languageList = translationI18nService.getLauguageList();
        LanguageVo defaultLanguage = languageList.stream().filter(LanguageVo::getIsDefault).findAny().get();

//        I18nReq catalogDisplayModuleI18nReq = I18nReq.builder()
//                .moduleCode(I18nConstant.ModuleCode.S_SERVICE_CATALOG_DISPLAY)
//                .defaultLanguage(defaultLanguage.getValue())
//                .languageList(languageList)
//                .build();
//        List<MainI18nInfoVO> catalogDisplayI18nInfoList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(catalogDisplayModuleI18nReq);

        I18nReq serviceCatalogI18nReq = I18nReq.builder()
                .moduleCode(I18nConstant.ModuleCode.S_SERVICE_CATALOG_TEMPLATE)
                .defaultLanguage(defaultLanguage.getValue())
                .languageList(languageList)
                .build();
        List<MainI18nInfoVO> serviceCatalogI18nList = (List<MainI18nInfoVO>) translationI18nService.getNormalList(serviceCatalogI18nReq);
        CatalogI18nVo catalogI18nVo = CatalogI18nVo.builder().catalogDisplayConfig(null)
                .catalog(serviceCatalogI18nList)
                .build();
        return catalogI18nVo;
    }

    @PostMapping("/catalog/update")
    public Boolean saveCatalogInfo(@RequestBody CatalogI18nVo catalogI18nVo) {
        return dosmTranslationI18nService.saveCatalogInfo(catalogI18nVo);
    }

    @PostMapping("/normal/update/" + I18nConstant.ModuleCode.M_DICT )
    public Boolean saveNormalList(@RequestBody List<MainI18nInfoVO> mainI18nInfos) {
        return dosmTranslationI18nService.saveDictionary(mainI18nInfos);
    }

    @PostMapping("/normal/update/" + I18nConstant.ModuleCode.M_PUBLIC_FIELD)
    public Boolean savePublicField(@RequestBody List<MainI18nInfoVO> mainI18nInfos) {
        return dosmTranslationI18nService.savePublicField(mainI18nInfos);
    }

    @PostMapping("/process/update")
    public Boolean saveProcessList(@RequestBody ProcessI18nVo processI18n) {
        return dosmTranslationI18nService.saveProcess(processI18n);
    }

}
