package com.cloudwise.dosm.i18n.support.core.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloudwise.dosm.i18n.support.core.enums.I18nModuleCode;
import com.cloudwise.dosm.i18n.support.core.service.DosmTranslationI18nService;
import com.cloudwise.dosm.i18n.support.core.vo.CatalogI18nVo;
import com.cloudwise.dosm.i18n.support.core.vo.ProcessI18nVo;
import com.cloudwise.dosm.i18n.support.form.field.FormFieldI18nConverterManager;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.dosm.i18n.support.process.bpm.convert.BpmXmlI18nConverter;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.service.DosmModuleI18nService;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.LanguageVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Sets;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
@Component
public class DosmTranslationServiceImpl implements DosmTranslationI18nService {
    @Autowired
    private FormFieldI18nConverterManager formFieldI18nConverterManager;
    @Autowired
    TranslationI18nService translationI18nService;

    @Autowired
    public DosmModuleI18nService dosmModuleI18nService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean saveDictionary(List<MainI18nInfoVO> mainI18nInfos) {
        Set<String> idSet = Sets.newHashSet();
        List<DosmModuleI18nEntity> dosmModuleI18nList = new ArrayList<>();
        for (MainI18nInfoVO mainI18nInfo : mainI18nInfos) {
            translationI18nService.converter(mainI18nInfo.getModuleCode(), mainI18nInfo, dosmModuleI18nList, idSet);
        }
        if(CollectionUtils.isNotEmpty(idSet)) {
            dosmModuleI18nService.removeBatchByIds(idSet);
        }
        translationI18nService.refreshRedis(dosmModuleI18nList);
        translationI18nService.saveBatch(dosmModuleI18nList);
        return true;
    }

    private void removeProcess(DosmModuleI18nConf moduleI18nConf) {
        dosmModuleI18nService.remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, moduleI18nConf.getModuleCode())
                .eq(DosmModuleI18nEntity::getMainId, moduleI18nConf.getMainId())
                .eq(StrUtil.isNotBlank(moduleI18nConf.getDataCode()), DosmModuleI18nEntity::getDataCode, moduleI18nConf.getDataCode())
        );
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean savePublicField(List<MainI18nInfoVO> mainI18nInfos) {
        Map<String, List<MainI18nInfoVO>> listMap = mainI18nInfos.stream().collect(Collectors.groupingBy(MainI18nInfoVO::getDataCode));
        for (List<MainI18nInfoVO> fieldI18nInfos : listMap.values()) {
            if (fieldI18nInfos == null) {
                continue;
            }
            List<MainI18nInfoVO> result = new ArrayList<>();
            for (MainI18nInfoVO mainI18nInfo : fieldI18nInfos) {
                result.add(mainI18nInfo);
                fillChilds(result, mainI18nInfo);
            }

            List<LanguageVo> lauguageList = translationI18nService.getLauguageList();

            for (MainI18nInfoVO mainI18nInfo : result) {
                Map<String, List<String>> content = mainI18nInfo.getContent();
                for (LanguageVo languageVo : lauguageList) {
                    if (!content.containsKey(languageVo.getValue())) {
                        content.put(languageVo.getValue(), new ArrayList<>());
                    } else {
                        List<String> strings = content.get(languageVo.getValue());
                        strings.remove(null);
                    }
                }
            }

            Optional<MainI18nInfoVO> mainI18nInfoVO = result.stream().filter(item -> StrUtil.isNotBlank(item.getExtCode())).findFirst();
            if (mainI18nInfoVO.isPresent()) {
                MainI18nInfoVO fieldI18nInfo = mainI18nInfoVO.get();
                DosmModuleI18nConf moduleI18nConf = DosmModuleI18nConf.builder().moduleCode(I18nModuleCode.M_PUBLIC_FIELD.name()).mainId(fieldI18nInfo.getMainId())
                        .dataCode(fieldI18nInfo.getDataCode())
                        .extCode(fieldI18nInfo.getExtCode())
                        .build();
                FieldI18nConf2EntityParam param = FieldI18nConf2EntityParam.builder()
                        .fieldCode(fieldI18nInfo.getDataCode())
                        .fieldValueType(fieldI18nInfo.getExtCode())
                        .fieldI18nList(result)
                        .build();

                List<DosmModuleI18nEntity> fieldEntityList = formFieldI18nConverterManager.getI18nConf4PublicField(moduleI18nConf, param);

                this.removeProcess(moduleI18nConf);
                if(fieldEntityList!=null) {
                    translationI18nService.refreshRedis(fieldEntityList);
                    translationI18nService.saveBatch(fieldEntityList);
                }
            }

        }
        return Boolean.TRUE;
    }

    private static void fillChilds(List<MainI18nInfoVO> mainI18nInfoVOS, MainI18nInfoVO mainI18nInfo) {
        if (mainI18nInfo.getChilds() != null && mainI18nInfo.getChilds().size() > 0) {
            mainI18nInfoVOS.addAll(mainI18nInfo.getChilds());
            for (MainI18nInfoVO child : mainI18nInfo.getChilds()) {
                fillChilds(mainI18nInfoVOS, child);
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean saveProcess(ProcessI18nVo processI18n) {
        DosmModuleI18nConf moduleI18nConf = DosmModuleI18nConf.builder().moduleCode(I18nConstant.ModuleCode.M_PROCESS).mainId(processI18n.getProcessId()).dataCode(processI18n.getProcessDefId()).build();

        /** 流程信息保存 */
        List<DosmModuleI18nEntity> dosmModuleI18nList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(processI18n.getProcess())) {
            for (MainI18nInfoVO mainI18nInfo : processI18n.getProcess()) {
                translationI18nService.converter(moduleI18nConf.getModuleCode(), mainI18nInfo, dosmModuleI18nList, Sets.newHashSet());
            }
        }
        this.removeProcess(moduleI18nConf);
        translationI18nService.refreshRedis(dosmModuleI18nList);
        translationI18nService.saveBatch(dosmModuleI18nList);

        /** 保存流程配置信息 */
        moduleI18nConf = DosmModuleI18nConf.builder().moduleCode(I18nConstant.ModuleCode.M_PROCESS_BPM).mainId(processI18n.getProcessId()).dataCode(processI18n.getProcessDefId()).build();
        List<DosmModuleI18nEntity> bpmEntityList = BpmXmlI18nConverter.INSTANCE.getI18n4EntityByContent(processI18n.getBpm());
        this.removeProcess(moduleI18nConf);
        if (CollectionUtils.isNotEmpty(bpmEntityList)) {
            translationI18nService.refreshRedis(bpmEntityList);
            translationI18nService.saveBatch(bpmEntityList);
        }


        /** 保存表单信息 */
        moduleI18nConf = DosmModuleI18nConf.builder().moduleCode(I18nConstant.ModuleCode.M_PROCESS_FORM).mainId(processI18n.getFormId()).build();
        List<DosmModuleI18nEntity> formEntityList = formFieldI18nConverterManager.getI18nConf4Form(moduleI18nConf, processI18n.getForm());
        this.removeProcess(moduleI18nConf);
        if (CollectionUtils.isNotEmpty(formEntityList)) {
            translationI18nService.refreshRedis(formEntityList);
            translationI18nService.saveBatch(formEntityList);
        }

        return Boolean.TRUE;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean saveCatalogInfo(CatalogI18nVo catalogI18nVo) {
//        DosmModuleI18nConf moduleI18nConf = DosmModuleI18nConf.builder().moduleCode(I18nConstant.ModuleCode.S_SERVICE_CATALOG_DISPLAY).build();
//        RequestDomain requestDomain = UserHolder.get();
//        if(ObjectUtil.isNull(requestDomain)){
//            moduleI18nConf.setMainId("110:110");
//        }
//        moduleI18nConf.setMainId(requestDomain.getTopAccountId()+":"+requestDomain.getAccountId());
//
//        /** 服务目录展示设置 */
//        List<DosmModuleI18nEntity> disPlayI18nList = new ArrayList<>();
//        if (CollectionUtils.isNotEmpty(catalogI18nVo.getCatalogDisplayConfig())) {
//            for (MainI18nInfoVO mainI18nInfo : catalogI18nVo.getCatalogDisplayConfig()) {
//                translationI18nService.converter(moduleI18nConf.getModuleCode(), mainI18nInfo, disPlayI18nList, Sets.newHashSet());
//            }
//        }
//        this.removeProcess(moduleI18nConf);
//        translationI18nService.refreshRedis(disPlayI18nList);
//        translationI18nService.saveBatch(disPlayI18nList);
        if (CollectionUtils.isNotEmpty(catalogI18nVo.getCatalogDisplayConfig())) {
            translationI18nService.save(I18nModuleCode.S_SERVICE_CATALOG_DISPLAY.name(), catalogI18nVo.getCatalogDisplayConfig());
        }

        /** 服务目录走标准保存方法 */
        translationI18nService.save(I18nModuleCode.S_SERVICE_CATALOG_TEMPLATE.name(), catalogI18nVo.getCatalog());
//        moduleI18nConf = DosmModuleI18nConf.builder().moduleCode(I18nConstant.ModuleCode.S_SERVICE_CATALOG_TEMPLATE).build();
//        List<DosmModuleI18nEntity> serviceCatalogI18nList = new ArrayList<>();
//        if (CollectionUtils.isNotEmpty(catalogI18nVo.getCatalog())) {
//            for (MainI18nInfoVO mainI18nInfo : catalogI18nVo.getCatalog()) {
//                translationI18nService.converter(moduleI18nConf.getModuleCode(), mainI18nInfo, serviceCatalogI18nList, Sets.newHashSet());
//            }
//        }
//        this.removeProcess(moduleI18nConf);
//        translationI18nService.refreshRedis(serviceCatalogI18nList);
//        translationI18nService.saveBatch(serviceCatalogI18nList);
        return Boolean.TRUE;
    }
}
