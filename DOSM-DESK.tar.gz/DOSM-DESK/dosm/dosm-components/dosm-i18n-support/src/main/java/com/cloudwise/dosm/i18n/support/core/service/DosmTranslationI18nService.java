package com.cloudwise.dosm.i18n.support.core.service;

import com.cloudwise.dosm.i18n.support.core.vo.CatalogI18nVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.cloudwise.dosm.i18n.support.core.vo.ProcessI18nVo;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
public interface DosmTranslationI18nService {
    Boolean saveDictionary(List<MainI18nInfoVO> mainI18nInfos);

    Boolean savePublicField(List<MainI18nInfoVO> mainI18nInfos);

    Boolean saveProcess(ProcessI18nVo processI18n);
    Boolean saveCatalogInfo(CatalogI18nVo catalogI18nVo);
}
