package com.cloudwise.dosm.i18n.support.core.enums;

import com.cloudwise.dosm.core.constant.ResourceCode;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.ClassRefPropertyI18nBean;
import com.cloudwise.i18n.support.core.dto.PropertyHiddenCondition;
import com.google.common.collect.Lists;
import lombok.Getter;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/26
 */
@Getter
public enum I18nModuleCode {
    DEFAULT("默认",null),
    M_TAB("自定义页签", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().mainIdCode(I18nConstant.DefaultPropertyCode.ID).propertyCode(I18nConstant.TabPropertyCode.TAB_NAME).propertyNameI18n(ResourceCode.PropertyI18n.TAB.TAB_NAME).build()
    )),


    M_DICT("数据字典", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.DictPropertyCode.DICT_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Dict.DICT_NAME).build(),
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.DictPropertyCode.CAPTION).propertyNameI18n(ResourceCode.PropertyI18n.Dict.DICT_DESC).build()
    )),

    M_DICT_DETAIL("数据字典选项", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.DictDetailPropertyCode.LABEL).build()
    )),

    M_BUTTON("按钮管理", Lists.newArrayList(
            // 按钮名称
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ButtonPropertyCode.NAME).propertyNameI18n(ResourceCode.PropertyI18n.Btn.BTN_NAME).build(),
            // 按钮说明
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ButtonPropertyCode.DESCRIPTION).propertyNameI18n(ResourceCode.PropertyI18n.Btn.BTN_DESC).build(),
            // 弹窗标题
            ClassRefPropertyI18nBean.builder().parentCode(I18nConstant.ButtonPropertyCode.ACTION_MODE_CONTENT).propertyCode(I18nConstant.ButtonPropertyCode.POP_UP_TITLE).propertyNameI18n(ResourceCode.PropertyI18n.Btn.POP_UP_TITLE)
                    .propertyHiddenCondition(PropertyHiddenCondition.builder()
                            .matchParentCode(I18nConstant.ButtonPropertyCode.ACTION_MODE_CONTENT).matchPropertyCode(I18nConstant.ButtonPropertyCode.POP_UP_TITLE).matchValueIsEmpty(Boolean.TRUE)
                            .build())
                    .build(),
            // 弹窗展示文字
            ClassRefPropertyI18nBean.builder().parentCode(I18nConstant.ButtonPropertyCode.ACTION_MODE_CONTENT).propertyCode(I18nConstant.ButtonPropertyCode.POP_UP_PLACE_CONTENT).propertyNameI18n(ResourceCode.PropertyI18n.Btn.POP_UP_PLACE_CONTENT)
                    .propertyHiddenCondition(PropertyHiddenCondition.builder()
                            .matchParentCode(I18nConstant.ButtonPropertyCode.ACTION_MODE_CONTENT).matchPropertyCode(I18nConstant.ButtonPropertyCode.POP_UP_TITLE).matchValueIsEmpty(Boolean.TRUE)
                            .build())
                    .build(),
            // 输入框名称
            ClassRefPropertyI18nBean.builder().parentCode(I18nConstant.ButtonPropertyCode.ACTION_MODE_CONTENT).propertyCode(I18nConstant.ButtonPropertyCode.INPUT_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Btn.POP_UP_INPUT_NAME)
                    .propertyHiddenCondition(PropertyHiddenCondition.builder()
                            .matchParentCode(I18nConstant.ButtonPropertyCode.ACTION_MODE_CONTENT).matchPropertyCode(I18nConstant.ButtonPropertyCode.POP_UP_TITLE).matchValueIsEmpty(Boolean.TRUE)
                            .build())
                    .build()
    )),

    M_PUBLIC_FIELD("公共字段", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.PublicFieldPropertyCode.FIELD_NAME).propertyNameI18n(ResourceCode.PropertyI18n.PublicField.NAME).build()
    )),
    M_PROCESS("流程管理 - 基本设置", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ProcessPropertyCode.PROCESS_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Process.PROCESS_NAME).build(),
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ProcessPropertyCode.PROCESS_DESC).propertyNameI18n(ResourceCode.PropertyI18n.Process.PROCESS_DESC).build()
    )),
    M_PROCESS_FORM("流程管理 - 表单设计", null),
    M_PROCESS_BPM("流程管理 - 流程设计", null),

    M_SLA_TEMPLATE("服务级别协议模板", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.SlaTemplatePropertyCode.NAME).propertyNameI18n(ResourceCode.PropertyI18n.PublicField.NAME).build()
    )),
    M_PROCESS_SLA("流程 - 高级设置 - SLA", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ProcessSlaPropertyCode.NAME).propertyNameI18n(ResourceCode.PropertyI18n.Process_Advanced_Settings.SLAOLA_NAME).build()
    )),
    M_PROCESS_TEMPLATE("流程 - 高级设置 - 表单模板", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ProcessTemplatePropertyCode.TEMPLETE_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Process_Advanced_Settings.TEMPLETE_NAME).build(),
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ProcessTemplatePropertyCode.TEMPLETE_DESC).propertyNameI18n(ResourceCode.PropertyI18n.Process_Advanced_Settings.TEMPLETE_DESC).build()
    )),
    S_VIEW_NAME_GLOBAL("业务设置全局视图设置", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ViewGlobalPropertyCode.VIEW_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Service_Settings.GOLBAL_NAME).build()
    )),
    S_CHANGE_VIEW_NAME_GLOBAL("业务设置变更日历视图设置", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ChangeViewGlobalPropertyCode.VIEW_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Service_Settings.CHANGE_VIEW_GOLBAL_NAME).build()
    )),
    S_SERVICE_CATALOG_TEMPLATE("服务目录",  Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ServiceCatalogPropertyCode.NAME).propertyNameI18n(ResourceCode.PropertyI18n.Service_Settings.CATALOG_NAME).build()
    )),
    M_LIST_QUERY_DEF("工单列表-列定义", null),
    S_SERVICE_CATALOG_ITEM("服务项", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ServiceCatalogItemPropertyCode.ITEM_FIELD_VALUE).propertyNameI18n(ResourceCode.PropertyI18n.Service_Settings.ITEM_FIELD_VALUE).build()
    )),
    S_SERVICE_CATALOG_DISPLAY("服务目录展示设置", Lists.newArrayList(
            ClassRefPropertyI18nBean.builder().propertyCode(I18nConstant.ServiceCatalogDisplayPropertyCode.FIELD_DISPLAY_NAME).propertyNameI18n(ResourceCode.PropertyI18n.Service_Settings.FIELD_DISPLAY_NAME).build()
    ));


    /**
     * 描述
     */
    private String desc;

    /**
     * 属性编码及名称国际化编码，格式：Map<属性编码, 属性名国际化编码>
     */
    private List<ClassRefPropertyI18nBean> propertyList;

    I18nModuleCode(String desc, List<ClassRefPropertyI18nBean> propertyList) {
        this.desc = desc;
        this.propertyList = propertyList;
    }
}
