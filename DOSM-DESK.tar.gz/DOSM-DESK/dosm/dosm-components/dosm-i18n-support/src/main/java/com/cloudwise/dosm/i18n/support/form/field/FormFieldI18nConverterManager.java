package com.cloudwise.dosm.i18n.support.form.field;

import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.i18n.support.cache.ITranslationPublicFieldCache;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.LanguageVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 字段国际化管理器
 * <ol>
 * <li>表单字段转换
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "content": "{\"fieldCode\":{\"fieldType\":\"字段类型，参考：FieldValueTypeEnum\",\"propertyCode\":\"国际化值\",\"fieldHint\":{\"hintType\":\"1\",\"hintContent\":\"国际化值\"},\"dataSource\":{\"字典id1\":\"国际化值\",\"字典id2\":\"国际化值\"},\"toolTips\":{\"1\":\"ss\",\"3\":null}}}"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "字段类型，参考：FieldValueTypeEnum", "property_code": "title:字段名称;unit:单位;自定义字典选项ID;hintContent：提示内容", "type": "1、国际化弹窗输入框类型 1 文本 2 富文本; 2、自定义数据字典：dataSource; 3、星级提示选项：toolTips", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "0/1", "childs": []}
 * </ul>
 * <li>公共字段转换
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："公共字段ID", "content": "{\"fieldType\":\"字段类型，参考：FieldValueTypeEnum\",\"propertyCode\":\"国际化值\",\"fieldHint\":{\"hintType\":\"1\",\"hintContent\":\"国际化值\"},\"dataSource\":{\"字典id1\":\"国际化值\",\"字典id2\":\"国际化值\"},\"toolTips\":{\"1\":\"ss\",\"3\":null}}"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："公共字段ID", "data_code"："fieldCode", "ext_code": "字段类型，参考：FieldValueTypeEnum", "property_code": "title:字段名称;unit:单位;自定义字典选项ID;hintContent：提示内容", "type": "1、国际化弹窗输入框类型 1 文本 2 富文本; 2、自定义数据字典：dataSource; 3、星级提示选项：toolTips", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "0/1", "childs": []}
 * </ul>
 * </ol>
 *
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Slf4j
@Component
public class FormFieldI18nConverterManager implements ApplicationContextAware {

    @Autowired
    private TranslationI18nService translationI18nService;

    @Autowired
    private AccountUtil accountUtil;

    @Autowired
    private ITranslationPublicFieldCache translationPublicFieldCache;

    private Map<FieldValueTypeEnum, IFormFieldI18nConverter> fieldI8nConverterMap = Maps.newConcurrentMap();

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        applicationContext.getBeansOfType(IFormFieldI18nConverter.class).values().forEach(item -> fieldI8nConverterMap.put(item.getFieldValueType(), item));
    }

    /**
     * 【表单设计 - 多语言设置】通过表单多语言设置页面获取表单国际化信息【DosmModuleI18nEntity存储结构参考类说明】
     *
     * @param moduleI18nConf 模块 i18n 配置
     * @param formI18nList   表单国际化配置
     */
    public List<DosmModuleI18nEntity> getI18nConf4Form(DosmModuleI18nConf moduleI18nConf, List<MainI18nInfoVO> formI18nList) {
        if (CollectionUtils.isEmpty(formI18nList)) {
            return null;
        }

        // 字段的国际化配置，格式：Map<fieldCode, List<国际化（字段标题、提示等）>>
        Map<String, FieldI18nConf2EntityParam> formFieldI18nListMap = Maps.newHashMap();
        formI18nList.forEach(item -> {
            FieldI18nConf2EntityParam param = formFieldI18nListMap.computeIfAbsent(item.getDataCode(), k -> FieldI18nConf2EntityParam.builder().fieldCode(item.getDataCode()).build());
            param.getFieldI18nList().add(item);
            if (StringUtils.equalsAny(item.getPropertyCode(), FieldPropertyConstant.K_TITLE, FieldPropertyConstant.K_NAME)) {
                param.setFieldValueType(item.getExtCode());
            }
        });

        FieldI18nConf2EntityParam formParam = FieldI18nConf2EntityParam.builder().build();
        for (Map.Entry<String, FieldI18nConf2EntityParam> formFieldI18nListEntry : formFieldI18nListMap.entrySet()) {
            FieldI18nConf2EntityParam fieldParam = formFieldI18nListEntry.getValue();
            FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldParam.getFieldValueType());
            IFormFieldI18nConverter fieldI18nConverter = null;
            if (fieldValueType == null || (fieldI18nConverter = fieldI8nConverterMap.get(fieldValueType)) == null) {
                log.warn("nonsupport fieldValueType, id: {}, fieldCode: {}", moduleI18nConf.getMainId(), fieldParam.getFieldCode());
                continue;
            }

            formParam.setFieldCode(fieldParam.getFieldCode());
            formParam.setFieldValueType(fieldParam.getFieldValueType());
            formParam.setFieldI18nList(fieldParam.getFieldI18nList());
            // 多语言设置 - 信息拼装
            fieldI18nConverter.buildI18nConf4Field(moduleI18nConf, formParam);
        }

        // 拼装国际化集合
        List<DosmModuleI18nEntity> resultList = Lists.newArrayList();
        Map<String, Map<String, Map<String, Object>>> resultI18nMap = formParam.getResultI18nMap();
        for (Map.Entry<String, Map<String, Map<String, Object>>> resultI18nEntry : resultI18nMap.entrySet()) {
            resultList.add(DosmModuleI18nEntity.builder()
                    .moduleCode(moduleI18nConf.getModuleCode())
                    .mainId(moduleI18nConf.getMainId())
                    .language(resultI18nEntry.getKey())
                    .content(JsonUtils.toJsonString(resultI18nEntry.getValue()))
                    .mergeContent(JsonUtils.toJsonString(formParam.getResultMergeI18nMap().get(resultI18nEntry.getKey())))
                    .build()
            );
        }

        return resultList;
    }

    /**
     * 【公共字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息【DosmModuleI18nEntity存储结构参考类说明】
     */
    public List<DosmModuleI18nEntity> getI18nConf4PublicField(DosmModuleI18nConf moduleI18nConf, FieldI18nConf2EntityParam param) {
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, param.getFieldValueType());
        IFormFieldI18nConverter fieldI18nConverter = null;
        if (fieldValueType == null || (fieldI18nConverter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType, id: {}, fieldCode: {}", moduleI18nConf.getMainId(), moduleI18nConf.getDataCode());
            return null;
        }

        // 多语言设置 - 信息拼装
        fieldI18nConverter.buildI18nConf4Field(moduleI18nConf, param);

        // 拼装国际化集合
        List<DosmModuleI18nEntity> resultList = Lists.newArrayList();
        Map<String, Map<String, Map<String, Object>>> resultI18nMap = param.getResultI18nMap();
        for (Map.Entry<String, Map<String, Map<String, Object>>> resultI18nEntry : resultI18nMap.entrySet()) {
            resultList.add(DosmModuleI18nEntity.builder()
                    .moduleCode(moduleI18nConf.getModuleCode())
                    .mainId(moduleI18nConf.getMainId())
                    .dataCode(moduleI18nConf.getDataCode())
                    .extCode(moduleI18nConf.getExtCode())
                    .language(resultI18nEntry.getKey())
                    .content(JsonUtils.toJsonString(resultI18nEntry.getValue().get(param.getFieldCode())))
                    .mergeContent(JsonUtils.toJsonString(param.getResultMergeI18nMap().get(resultI18nEntry.getKey()).get(param.getFieldCode())))
                    .build()
            );
        }
        return resultList;
    }

    /**
     * 【表单设计 - 多语言设置】通过表单字段 schema 获取单个字段国际化信息
     *
     * @param moduleI18nConf       模块 i18n 配置
     * @param formSchemaConfig     表单设计 schema
     * @param dbFormI18nEntityList 表单字段 i18n 配置信息， content 格式：{"fieldCode":{"fieldType":"FieldValueTypeEnum","propertyCode":"国际化值","fieldHint":{"hintType":"1","hintContent":"国际化值"},"dataSource":{"字典id1":"国际化值","字典id2":"国际化值"},"toolTips":{"1":"ss","3":""}}}
     * @param dbPublicFieldI18nMap 公共字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    public List<MainI18nInfoVO> getMainI18nByFormSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> formSchemaConfig, List<DosmModuleI18nEntity> dbFormI18nEntityList, Map<String, Map<String, MainI18nInfoVO>> dbPublicFieldI18nMap) {
        // 表单字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
        Map<String, Map<String, MainI18nInfoVO>> dbFormFieldI18nMap = getDBFormFieldI18nMapByContent(dbFormI18nEntityList);

        return getMainI18nByFormSchema4Conf(moduleI18nConf, formSchemaConfig, dbFormFieldI18nMap, dbPublicFieldI18nMap);
    }

    /**
     * 【表单设计 - 多语言设置】通过表单字段 schema 获取单个字段国际化信息
     *
     * @param moduleI18nConf       模块 i18n 配置
     * @param formSchemaConfig     表单设计 schema
     * @param dbFormFieldI18nMap   表单字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     * @param dbPublicFieldI18nMap 公共字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    public List<MainI18nInfoVO> getMainI18nByFormSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> formSchemaConfig, Map<String, Map<String, MainI18nInfoVO>> dbFormFieldI18nMap, Map<String, Map<String, MainI18nInfoVO>> dbPublicFieldI18nMap) {
        List<MainI18nInfoVO> resultFormFieldI18nInfoList = Lists.newArrayList();
        // 表单布局配置信息
        Map<String, Object> formSchemaPropertiesMap = (Map<String, Object>) formSchemaConfig.get(FieldPropertyConstant.K_PROPERTIES);
        for (Map.Entry<String, Object> formSchemaEntry : formSchemaPropertiesMap.entrySet()) {
            // 字段编码
            String fieldCode = formSchemaEntry.getKey();
            Map<String, Object> fieldSchemaMap = (Map<String, Object>) formSchemaEntry.getValue();
            this.getMainI18nByFieldSchema4Conf(moduleI18nConf, fieldCode, fieldSchemaMap, resultFormFieldI18nInfoList, dbFormFieldI18nMap, dbPublicFieldI18nMap);
        }
        return resultFormFieldI18nInfoList;
    }

    /**
     * 【单个字段 - 多语言设置】通过字段 schema 获取单个字段国际化信息
     *
     * @param moduleI18nConf          模块 i18n 配置
     * @param fieldCode               字段编码
     * @param fieldSchemaMap          字段schema
     * @param resultFieldI18nInfoList 字段多语言设置结果
     * @param dbFormFieldI18nMap      表单字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     * @param dbPublicFieldI18nMap    公共字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    public void getMainI18nByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, String fieldCode, Map<String, Object> fieldSchemaMap, List<MainI18nInfoVO> resultFieldI18nInfoList,
                                              Map<String, Map<String, MainI18nInfoVO>> dbFormFieldI18nMap, Map<String, Map<String, MainI18nInfoVO>> dbPublicFieldI18nMap) {
        String fieldValueTypeStr = (String) fieldSchemaMap.get(FieldPropertyConstant.K_X_COMPONENT);
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
        IFormFieldI18nConverter converter = null;
        if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType for fieldSchema, id: {}, fieldCode: {}", moduleI18nConf.getMainId(), fieldCode);
            return;
        }

        moduleI18nConf.setDataCode(fieldCode);
        moduleI18nConf.setExtCode(fieldValueTypeStr);
        // 通过字段 schema 获取字段多语言设置
        converter.buildMainI18nByFieldSchema4Conf(moduleI18nConf, fieldSchemaMap, resultFieldI18nInfoList, dbFormFieldI18nMap, dbPublicFieldI18nMap);
    }

    /**
     * 获取表单字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     *
     * @param dbFormI18nEntityList 表单字段 i18n 配置信息， content 格式：{"fieldCode":{"fieldType":"FieldValueTypeEnum","propertyCode":"国际化值","fieldHint":{"hintType":"1","hintContent":"国际化值"},"dataSource":{"字典id1":"国际化值","字典id2":"国际化值"},"toolTips":{"1":"ss","3":""}}}
     */
    public Map<String, Map<String, MainI18nInfoVO>> getDBFormFieldI18nMapByContent(List<DosmModuleI18nEntity> dbFormI18nEntityList) {
        if (CollectionUtils.isEmpty(dbFormI18nEntityList)) {
            return Maps.newHashMap();
        }

        Map<String, Map<String, MainI18nInfoVO>> dbFieldI18nMap = Maps.newHashMap();
        for (DosmModuleI18nEntity entity : dbFormI18nEntityList) {
            // content 格式：{"fieldCode":{"fieldType":"FieldValueTypeEnum","propertyCode":"国际化值","fieldHint":{"hintType":"1","hintContent":"国际化值"},"dataSource":{"字典id1":"国际化值","字典id2":"国际化值"},"toolTips":{"1":"ss","3":""}}}
            Map<String, Object> formContentMap = JsonUtils.parseObject(entity.getContent());
            if (MapUtils.isEmpty(formContentMap)) {
                log.warn("not found form i18n content, id: {}, language: {}", entity.getMainId(), entity.getLanguage());
                continue;
            }

            // 每个字段国际化信息
            for (Map.Entry<String, Object> formContentEntry : formContentMap.entrySet()) {
                String fieldCode = formContentEntry.getKey();
                // 字段国际化信息
                Map<String, Object> fieldContentMap = (Map<String, Object>) formContentEntry.getValue();
                String fieldValueTypeStr = (String) fieldContentMap.get(FieldPropertyConstant.K_FIELD_TYPE);

                this.getFieldI18nMap(entity, fieldCode, fieldValueTypeStr, fieldContentMap, dbFieldI18nMap);
            }
        }
        return dbFieldI18nMap;
    }

    /**
     * 获取公共字段i18n map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     *
     * @param dbPublicFieldI18nList 公共字段 i18n 配置信息， content 格式：{"propertyCode":"国际化值","fieldHint":{"hintType":"1","hintContent":"国际化值"},"dataSource":{"字典id1":"国际化值","字典id2":"国际化值"},"toolTips":{"1":"ss","3":""}}
     */
    public Map<String, Map<String, MainI18nInfoVO>> getDBPublicFieldI18nMap(List<DosmModuleI18nEntity> dbPublicFieldI18nList) {
        if (CollectionUtils.isEmpty(dbPublicFieldI18nList)) {
            return Maps.newHashMap();
        }

        Map<String, Map<String, MainI18nInfoVO>> dbPublicFieldI18nMap = Maps.newHashMap();
        for (DosmModuleI18nEntity entity : dbPublicFieldI18nList) {
            // 公共字段国际化内容，数据格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
            Map<String, Object> fieldContentMap = JsonUtils.parseObject(entity.getContent());
            this.getFieldI18nMap(entity, entity.getDataCode(), entity.getExtCode(), fieldContentMap, dbPublicFieldI18nMap);
        }
        return dbPublicFieldI18nMap;
    }

    /**
     * 获取字段 i18n 信息
     */
    private void getFieldI18nMap(DosmModuleI18nEntity entity, String fieldCode, String fieldValueTypeStr, Map<String, Object> fieldContentMap, Map<String, Map<String, MainI18nInfoVO>> dbFieldI18nMap) {
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
        IFormFieldI18nConverter converter = null;
        if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType, id: {}, language: {}, fieldCode: {}", entity.getMainId(), entity.getLanguage(), entity.getDataCode());
            return;
        }
        DosmModuleI18nConf fieldI18nConf = DosmModuleI18nConf.builder()
                .moduleCode(entity.getModuleCode())
                // 公共字段ID
                .mainId(entity.getMainId())
                // 字段编码：fieldCode
                .dataCode(fieldCode)
                // 字段类型：FieldValueTypeEnum
                .extCode(fieldValueTypeStr)
                // 语言
                .defaultLanguage(entity.getLanguage())
                .build();

        // 获取字段国际化信息
        converter.buildFieldMainI18nMapByContent(fieldI18nConf, fieldContentMap, dbFieldI18nMap);
    }






    /**
     * 【表单设计 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     *
     * @param moduleI18nConf 模块 i18n 配置
     * @param formSchemaMap  表单配置
     * @param preVerFormSchemaMap 上一个版本表单字段schema信息
     * @param resultI18nList 国际化结果
     */
    public DosmModuleI18nEntity buildModuleI18nByFormSchema4Update(DosmModuleI18nConf moduleI18nConf, Map<String, Object> formSchemaMap, String preVerMainId, Map<String, Object> preVerFormSchemaMap, List<DosmModuleI18nEntity> resultI18nList) {
        if (MapUtils.isEmpty(formSchemaMap)) {
            log.warn("formSchema is empty, id: {}", moduleI18nConf.getMainId());
            return null;
        }

        List<LanguageVo> allLanguageList = translationI18nService.getLauguageList();
        List<String> allLanguageStrList = allLanguageList.stream().map(LanguageVo::getValue).collect(Collectors.toList());


        // 字段国际化，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>>
        Map<String, Map<String, Map<String, Object>>> dbPreVerFieldContentI18nMap = Maps.newHashMap();
        Set<String> dbPreVerFieldCodes = Sets.newHashSet();
        /** 上一个版本表单字段国际化信息【不可以使用字段schema比较，中文保存后、在进行英文保存，两次schema完全不一致，导致无法同步国际化】，格式Map<fieldCode, Map<propertyCode, content>> */
        Map<String, Map<String, Object>> preVerFormContentI18nMap = Maps.newHashMap();
        // 上一个版本表单存在国际化
        if(StringUtils.isNotBlank(preVerMainId)) {
            // 表单需要同步国际化集合
            List<DosmModuleI18nEntity> preVerFormI18nList = translationI18nService.listByI18nReq4Languages(I18nReq.builder().moduleCode(I18nConstant.ModuleCode.M_PROCESS_FORM).mainId(preVerMainId).build(), allLanguageStrList);

            for(DosmModuleI18nEntity entity: preVerFormI18nList) {
                if(accountUtil.getLanguage().equals(entity.getLanguage())) {
                    preVerFormContentI18nMap = JsonUtils.parseObject(entity.getContent(), Map.class);
                    continue;
                }
                dbPreVerFieldContentI18nMap.put(entity.getLanguage(), JsonUtils.parseObject(entity.getContent(), Map.class));
            }

            /** 获取表单 chema 配置字段信息 */
            this.rebuildFormSchema(preVerFormSchemaMap, dbPreVerFieldCodes);
        }


        // 公共字段国际化，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>>
        Map<String, Map<String, Map<String, Object>>> dbPublicFieldContentI18nMap = translationPublicFieldCache.getContent4Query(allLanguageStrList);
        Map<String, Map<String, Object>> currLanguageDbPublicFieldContentI18nMap = dbPublicFieldContentI18nMap.remove(accountUtil.getLanguage());

        FormSchema4UpdateParamBean paramContext = FormSchema4UpdateParamBean.builder()
                .moduleI18nConf(moduleI18nConf)
                .dbPublicFieldContentI18nMap(dbPublicFieldContentI18nMap)
                .dbPreVerFieldContentI18nMap(dbPreVerFieldContentI18nMap)
                .formSchemaMap(formSchemaMap)
                .preVerFormFieldCodes(dbPreVerFieldCodes)
                .preVerFormContentI18nMap(preVerFormContentI18nMap)
                .currLanguageDbPublicFieldContentI18nMap(currLanguageDbPublicFieldContentI18nMap)
                .formI18nContentMap(Maps.newHashMap())
                .build();

        // 表单 i18n 集合
        // 【表单设计 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
        this.buildModuleI18nByFormSchema4Update(moduleI18nConf, paramContext);

        return paramContext.buildFormI18n(resultI18nList);
    }

    /**
     * 【表单设计 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     *
     * @param moduleI18nConf     模块 i18n 配置
     */
    public void buildModuleI18nByFormSchema4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        if (MapUtils.isEmpty(paramContext.getFormSchemaMap())) {
            log.warn("formSchema is empty, id: {}", moduleI18nConf.getMainId());
            return;
        }

        // 表单布局配置信息
        Map<String, Object> formSchemaPropertiesMap = (Map<String, Object>) paramContext.getFormSchemaMap().get(FieldPropertyConstant.K_PROPERTIES);
        for (Map.Entry<String, Object> formSchemaEntry : formSchemaPropertiesMap.entrySet()) {
            /** 重置字段信息 */
            paramContext.resetFieldConf(formSchemaEntry.getKey(), (Map<String, Object>) formSchemaEntry.getValue());

            this.buildModuleI18nByFieldSchema4Update(moduleI18nConf, paramContext);

            /** 同步字段属性国际化到表单中 */
            paramContext.syncFieldPropertyI18n2Form();
        }
    }

    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     *
     * @param moduleI18nConf      模块 i18n 配置
     */
    public void buildModuleI18nByFieldSchema4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        if (MapUtils.isEmpty(paramContext.getFieldSchemaMap())) {
            log.warn("fieldSchema is empty, id: {}, fieldCode: {}", moduleI18nConf.getMainId(), paramContext.getFieldCode());
            return;
        }

        String fieldValueTypeStr = (String) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_COMPONENT);
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
        IFormFieldI18nConverter converter = null;
        if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType for fieldSchema, id: {}, fieldCode: {}", moduleI18nConf.getMainId(), paramContext.getFieldCode());
            return;
        }
        moduleI18nConf.setDataCode(paramContext.getFieldCode());
        // 设置字段值类型
        paramContext.setFieldValueType(fieldValueTypeStr);

        // 通过字段 schema 获取字段多语言
        converter.buildFieldSchemaI18n4Update(moduleI18nConf, paramContext);
    }





    /**
     * 【表单设计 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     *
     * @param moduleI18nEntity        模块 i18n 配置
     * @param formSchemaMap           表单配置
     * @param dbFormFieldI18nMap      表单字段国际化
     * @param dbAllPublicFieldI18nMap 公共字段国际化
     */
    public void buildFormSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> formSchemaMap, Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap) {
        if (MapUtils.isEmpty(formSchemaMap)) {
            log.warn("formSchema is empty, id: {}", moduleI18nEntity.getMainId());
            return;
        }

        if (MapUtils.isEmpty(dbFormFieldI18nMap)) {
            log.warn("formI18nMap is empty, id: {}, content: {}", moduleI18nEntity.getMainId(), moduleI18nEntity.getMergeContent());
            return;
        }

        // 表单布局配置信息
        Map<String, Object> formSchemaPropertiesMap = (Map<String, Object>) formSchemaMap.get(FieldPropertyConstant.K_PROPERTIES);
        for (Map.Entry<String, Object> formSchemaEntry : formSchemaPropertiesMap.entrySet()) {
            // 字段编码
            String fieldCode = formSchemaEntry.getKey();
            // 字段 schema 信息
            Map<String, Object> fieldSchemaMap = (Map<String, Object>) formSchemaEntry.getValue();
            // 字段国际化信息
            Map<String, Object> dbFieldI18nMap = (Map<String, Object>) dbFormFieldI18nMap.get(fieldCode);
            // 公共字段国际化信息
            Map<String, Object> dbPublicFieldI18nMap = dbAllPublicFieldI18nMap == null ? null : dbAllPublicFieldI18nMap.get(fieldCode);

            this.buildFieldSchemaI18n4Query(moduleI18nEntity, fieldCode, fieldSchemaMap, dbFieldI18nMap, dbPublicFieldI18nMap, dbFormFieldI18nMap, dbAllPublicFieldI18nMap);
        }

    }

    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     *
     * @param moduleI18nEntity        模块 i18n 配置
     * @param fieldSchemaMap          表单配置
     * @param dbFieldI18nMap          字段国际化
     * @param dbPublicFieldI18nMap    字段对应的公共国际化
     * @param dbFormFieldI18nMap      表单国际化
     * @param dbAllPublicFieldI18nMap 所有公共国际化
     */
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, String fieldCode, Map<String, Object> fieldSchemaMap, Map<String, Object> dbFieldI18nMap, Map<String, Object> dbPublicFieldI18nMap,
                                           Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap) {
        if (MapUtils.isEmpty(fieldSchemaMap)) {
            log.warn("fieldSchema is empty, id: {}, fieldCode: {}", moduleI18nEntity.getMainId(), fieldCode);
            return;
        }

        String fieldValueTypeStr = (String) fieldSchemaMap.get(FieldPropertyConstant.K_X_COMPONENT);
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
        IFormFieldI18nConverter converter = null;
        if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType for fieldSchema, id: {}, fieldCode: {}", moduleI18nEntity.getMainId(), fieldCode);
            return;
        }

        // 通过字段 schema 获取字段多语言
        converter.buildFieldSchemaI18n4Query(moduleI18nEntity, fieldSchemaMap, dbFieldI18nMap, dbPublicFieldI18nMap, dbFormFieldI18nMap, dbAllPublicFieldI18nMap);
    }


    /**
     * 【fieldList - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据 【com.cloudwise.dosm.form.commons.FieldVo】
     *
     * @param moduleI18nEntity        模块 i18n 配置
     * @param formFieldMapList        字段信息配置（fieldVo对象）
     * @param dbFormFieldI18nMap      表单国际化信息
     * @param dbAllPublicFieldI18nMap 公共字段国际化信息 {"公共字段编码":{国际化数据},"公共字段编码1":{国际化数据}}
     */
    public void buildFormFieldListI18n(DosmModuleI18nEntity moduleI18nEntity, List<Map<String, Object>> formFieldMapList, Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap) {
        if (CollectionUtils.isEmpty(formFieldMapList)) {
            log.warn("formFieldMapList is empty, id: {}", moduleI18nEntity.getMainId());
            return;
        }

        if (dbFormFieldI18nMap == null && dbAllPublicFieldI18nMap == null) {
            log.warn("formFieldI18nMap is empty, id: {}, content: {}", moduleI18nEntity.getMainId(), moduleI18nEntity.getMergeContent());
            return;
        }

        if (dbFormFieldI18nMap == null) {
            dbFormFieldI18nMap = Maps.newHashMap();
        }
        for (Map<String, Object> fieldMap : formFieldMapList) {
            String fieldCode = (String) fieldMap.get(FieldPropertyConstant.FN_FIELD_CODE);

            // 字段国际化
            Map<String, Object> dbFieldI18nMap = (Map<String, Object>) dbFormFieldI18nMap.get(fieldCode);
            // 字段对应 公共字段国际化
            Map<String, Object> dbPublicFieldI18nMap = dbAllPublicFieldI18nMap == null ? null : dbAllPublicFieldI18nMap.get(fieldCode);

            this.buildFieldI18n4FieldList(moduleI18nEntity, fieldCode, fieldMap, dbFieldI18nMap, dbPublicFieldI18nMap, dbFormFieldI18nMap, dbAllPublicFieldI18nMap);
        }
    }

    /**
     * 【fieldVo - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据【com.cloudwise.dosm.form.commons.FieldVo】
     *
     * @param moduleI18nEntity        模块 i18n 配置
     * @param fieldMap                字段信息配置（fieldVo对象）
     * @param dbFieldI18nMap          字段国际化信息
     * @param dbPublicFieldI18nMap    字段对应 公共字段国际化
     * @param dbFormFieldI18nMap      表单国际化信息
     * @param dbAllPublicFieldI18nMap 公共字段国际化信息
     */
    public void buildFieldI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, String fieldCode, Map<String, Object> fieldMap, Map<String, Object> dbFieldI18nMap, Map<String, Object> dbPublicFieldI18nMap,
                                         Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap) {
        if (MapUtils.isEmpty(fieldMap)) {
            log.warn("fieldMap is empty, id: {}, fieldCode: {}", moduleI18nEntity.getMainId(), fieldCode);
            return;
        }

//        if (MapUtils.isEmpty(dbFieldI18nMap)) {
//            log.warn("fieldI18nMap is empty, id: {}, content: {}", moduleI18nEntity.getMainId(), moduleI18nEntity.getMergeContent());
//            return;
//        }

        String fieldValueTypeStr = (String) fieldMap.get(FieldPropertyConstant.FN_FIELD_VALUE_TYPE);
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
        IFormFieldI18nConverter converter = null;
        if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType for fieldSchema, id: {}, fieldCode: {}", moduleI18nEntity.getMainId(), fieldCode);
            return;
        }

        converter.buildFieldI18n4FieldList(moduleI18nEntity, fieldMap, dbFieldI18nMap, dbPublicFieldI18nMap, dbFormFieldI18nMap, dbAllPublicFieldI18nMap);
    }






    /**
     * 回填和集成专用，该方法会将所有语言的enumlist合并
     * @param formSchemaMapList
     * @param i18nEntityList
     */
    public void buildFormFieldListI18n4FillAndExtend(List<Map<String, Object>> formSchemaMapList, List<DosmModuleI18nEntity> i18nEntityList) {
        Map<String,Map<String,Map<String,Object>>> fieldListI18nMap = Maps.newHashMap();
        for (DosmModuleI18nEntity dosmModuleI18nEntity : i18nEntityList) {
            Map<String, Map<String, Object>> fieldListI18nMapOrDefault = fieldListI18nMap.getOrDefault(dosmModuleI18nEntity.getDataCode(), Maps.newHashMap());
            fieldListI18nMapOrDefault.put(dosmModuleI18nEntity.getLanguage(), JsonUtils.parseObject(dosmModuleI18nEntity.getMergeContent()));
            fieldListI18nMap.put(dosmModuleI18nEntity.getDataCode(), fieldListI18nMapOrDefault);
        }
        for (Map<String, Object> fieldSchemaMap : formSchemaMapList) {
            String fieldCode = (String) fieldSchemaMap.get(FieldPropertyConstant.FN_FIELD_CODE);

            Map<String, Map<String, Object>> dbFieldI18nMap = fieldListI18nMap.get(fieldCode);
            // 字段对应 公共字段国际化
            String fieldValueTypeStr = (String) fieldSchemaMap.get(FieldPropertyConstant.FN_FIELD_VALUE_TYPE);
            FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
            IFormFieldI18nConverter converter = null;
            if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
                log.warn("nonsupport fieldValueType for fieldSchema,  fieldCode: {}", fieldCode);
                return;
            }

            if(dbFieldI18nMap == null){
                dbFieldI18nMap = new HashMap<>();
            }

            converter.buildFieldI18n4FieldList4FillAndExtend(fieldSchemaMap, dbFieldI18nMap);

        }
    }








    /**
     * 【用于表单变更对比】获取表单 chema 配置字段信息
     * @param formSchemaMap
     * @param fieldCodes 字段编码
     */
    public void rebuildFormSchema(Map<String, Object> formSchemaMap, Set<String> fieldCodes) {
        if(MapUtils.isEmpty(formSchemaMap)) {
            log.warn("formSchema is empty");
            return;
        }

        // 表单布局配置信息
        Map<String, Object> formSchemaPropertiesMap = (Map<String, Object>) formSchemaMap.get(FieldPropertyConstant.K_PROPERTIES);
        for (Map.Entry<String, Object> formSchemaEntry : formSchemaPropertiesMap.entrySet()) {
            // 字段编码
            String fieldCode = formSchemaEntry.getKey();
            // 字段 schema 信息
            Map<String, Object> fieldSchemaMap = (Map<String, Object>) formSchemaEntry.getValue();

            this.rebuildFieldSchema(fieldCode, fieldSchemaMap, fieldCodes);
        }
    }

    /**
     * 【用于表单变更对比】获取表单 chema 配置字段信息及引用的公共字段
     * @param fieldCode
     * @param fieldSchemaMap
     * @param fieldCodes 字段编码
     */
    public void rebuildFieldSchema(String fieldCode, Map<String, Object> fieldSchemaMap, Set<String> fieldCodes) {
        if (MapUtils.isEmpty(fieldSchemaMap)) {
            log.warn("fieldSchema is empty, fieldCode: {}", fieldCode);
            return;
        }

        String fieldValueTypeStr = (String) fieldSchemaMap.get(FieldPropertyConstant.K_X_COMPONENT);
        FieldValueTypeEnum fieldValueType = EnumUtils.getEnum(FieldValueTypeEnum.class, fieldValueTypeStr);
        IFormFieldI18nConverter converter = null;
        if (fieldValueType == null || (converter = fieldI8nConverterMap.get(fieldValueType)) == null) {
            log.warn("nonsupport fieldValueType for fieldSchema, fieldCode: {}, fieldValueType: {}", fieldCode, fieldValueTypeStr);
            return;
        }
        converter.rebuildFieldSchema(fieldCode, fieldSchemaMap, fieldCodes);
    }
}
