package com.cloudwise.dosm.i18n.support.service;

import com.cloudwise.dosm.core.utils.UserHolder;
import com.cloudwise.dosm.facewall.extension.core.definition.action.AbstractActionDefinition;
import com.cloudwise.dosm.facewall.extension.core.definition.execution.AbstactExecutionDefinition;
import com.cloudwise.dosm.facewall.extension.core.definition.execution.datamapping.AbstractDataMapping;
import com.cloudwise.dosm.facewall.extension.core.definition.json.deserializer.JacksonActionDefinitionDeserializer;
import com.cloudwise.dosm.facewall.extension.core.definition.json.deserializer.JacksonDataMappingDefinitionDeserializer;
import com.cloudwise.dosm.facewall.extension.core.definition.json.deserializer.JacksonExecutionDefinitionDeserializer;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.JsonUtils;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
@Component
public class AccountUtilImpl implements AccountUtil {

    static {
        /**
         * 使 JsonUtil支持解析自定义按钮相关组件
         */
        SimpleModule module = new SimpleModule();
        module.addDeserializer(AbstactExecutionDefinition.class, new JacksonExecutionDefinitionDeserializer());
        module.addDeserializer(AbstractActionDefinition.class, new JacksonActionDefinitionDeserializer());
        module.addDeserializer(AbstractDataMapping.class, new JacksonDataMappingDefinitionDeserializer());
        JsonUtils.registerModule(module);
    }
    @Override
    public String getLanguage() {
        return UserHolder.get().getLanguage();
    }

    @Override
    public String getAccountId() {
        return UserHolder.get().getAccountId();
    }

    @Override
    public String getTopAccountId() {
        return UserHolder.get().getTopAccountId();
    }

    @Override
    public String getUserId() {
        return UserHolder.get().getUserId();
    }

    @Override
    public String getLanguageFull() {
        return UserHolder.get().getLanguageFull();
    }

    @Override
    public Date getCurrTime() {
        return UserHolder.get().getCurrTime();
    }
}
