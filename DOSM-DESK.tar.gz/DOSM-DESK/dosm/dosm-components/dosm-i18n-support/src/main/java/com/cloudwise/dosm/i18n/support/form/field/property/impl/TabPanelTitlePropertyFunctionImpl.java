package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;

/**
 * 标签页字段国际化
 * @Author frank.zheng
 * @Date 2023-07-31
 */
public class TabPanelTitlePropertyFunctionImpl extends GroupTitlePropertyFunctionImpl implements IFieldPropertyFunction {
    
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.TAB_PANEL_TITLE;
    }

}
