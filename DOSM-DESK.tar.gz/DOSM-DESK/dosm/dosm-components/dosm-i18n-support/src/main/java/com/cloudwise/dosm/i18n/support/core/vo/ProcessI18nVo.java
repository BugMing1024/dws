package com.cloudwise.dosm.i18n.support.core.vo;

import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 流程国际化信息
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessI18nVo {

    /** 流程ID */
    private String processId;

    /** 流程发布ID */
    private String processDefId;

    /** 流程ID */
    private String formId;

    /** 流程基本信息 国际化信息 */
    private List<MainI18nInfoVO> process;

    /** 流程 - 表单设计 国际化信息 */
    private List<MainI18nInfoVO> form;

    /** 流程设计 国际化信息 */
    private List<MainI18nInfoVO> bpm;
}
