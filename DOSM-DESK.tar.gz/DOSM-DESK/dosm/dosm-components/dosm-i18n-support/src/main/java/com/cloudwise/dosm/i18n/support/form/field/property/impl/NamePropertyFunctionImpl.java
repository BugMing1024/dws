package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

import static com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant.FN_FIELD_NAME;

/**
 * 标题字段国际化
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"title":"标题","fieldType": "字段类型，参考：FieldValueTypeEnum"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "字段类型，参考：FieldValueTypeEnum", "property_code": "title", "type": "", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "0", "childs": []}
 * </ul>
 * </ol>
 *
 * @Author frank.zheng
 * @Date 2023-07-31
 */
public class NamePropertyFunctionImpl extends FieldTitlePropertyFunctionImpl {

    @Override
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.NAME;
    }

    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     * @param paramContext
     */
    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {
        // 字段描述获取字段 title、name 兼容
        String titleStr = (String) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_TITLE);
        if(StringUtils.isBlank(titleStr)) {
            titleStr = (String) paramContext.getFieldSchemaMap().get(this.getProperty().getFieldKey());
        }
        paramContext.getFieldPropertyI18nContentMap().put(this.getProperty().getPropertyCode(), titleStr);
        paramContext.getFieldPropertyI18nContentMap().put(FieldPropertyConstant.K_FIELD_TYPE, paramContext.getFieldValueType());

        /**  同步其他语言国际化信息  */
        this.syncFieldPropertyI18n4UpdateByStr(moduleI18nConf, paramContext, titleStr, true);
    }




    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity          模块 i18n 配置
     * @param fieldSchemaConfig         表单配置
     * @param fieldPropertyI18nMap       字段国际化
     * @param publicFieldPropertyI18nMap 字段对应的公共国际化
     */
    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {
        String titleI18nStr = null;
        if(publicFieldPropertyI18nMap == null) {
            titleI18nStr = (String) fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        } else {
            titleI18nStr = (String) publicFieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        }
        if (StringUtils.isBlank(titleI18nStr)) {
            return;
        }
        fieldSchemaConfig.put(this.getProperty().getFieldKey(), titleI18nStr);
        fieldSchemaConfig.put(FieldPropertyConstant.K_TITLE, titleI18nStr);
    }




    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     * @return
     */
    @Override
    public void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param) {
        Map<String, List<String>> contentI18nMap = fieldI18n.getContent();

        String fieldCode = fieldI18n.getDataCode();
        // 属性 merge 后的语言内容
        String mergeContent = null;
        List<Map<String, Object>> mergeContentIsNullList = Lists.newArrayList();
        for (Map.Entry<String, List<String>> contentI18nEntry : contentI18nMap.entrySet()) {
            String language = contentI18nEntry.getKey();
            // 【某语言下字段】国际化集合,格式：Map<字段，Map<propertyCode, Object>>
            Map<String, Map<String, Object>> languageI18nMap = param.getResultI18nMap().computeIfAbsent(language, k -> Maps.newHashMap());
            // 【字段下各属性】国际化集合,格式：Map<propertyCode, Object>
            Map<String, Object> fieldI18nMap = languageI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());

            Map<String, Object> fieldMergeI18nMap = param.getResultMergeI18nMap().computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(fieldCode, k -> Maps.newHashMap());

            List<String> contentList = contentI18nEntry.getValue();
            String content = null;
            // 配置国际化为空
            if (CollectionUtils.isEmpty(contentList) || StringUtils.isBlank(content = contentList.get(0))) {
                mergeContentIsNullList.add(fieldMergeI18nMap);
            } else {
                fieldI18nMap.put(fieldI18n.getPropertyCode(), mergeContent = content);
                fieldMergeI18nMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
            fieldI18nMap.put(FieldPropertyConstant.K_FIELD_TYPE, fieldI18n.getExtCode());
            fieldMergeI18nMap.put(FieldPropertyConstant.K_FIELD_TYPE, fieldI18n.getExtCode());
        }

        if (mergeContent != null) {
            for (Map<String, Object> mergeContentMap : mergeContentIsNullList) {
                mergeContentMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }
    }

    @Override
    public void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap) {
        // 设置语言值【模块对象中获取属性值】
        Map<String, List<String>> contentMap = fieldPropertyI18nMap.computeIfAbsent(this.getProperty().getPropertyCode(), k -> MainI18nInfoVO.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .dataCode(moduleI18nConf.getDataCode())
                .extCode(moduleI18nConf.getExtCode())
                .type(null)
                .propertyCode(this.getProperty().getPropertyCode())
                .content(Maps.newHashMap())
                .build()
        ).getContent();

        String title = (String) fieldI18nMap.get(this.getProperty().getPropertyCode());
        contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(title));
    }

    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList, Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {
        MainI18nInfoVO currMainI18nInfo = fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if (currMainI18nInfo == null) {
            String title = (String) fieldSchemaConfig.get(FieldPropertyConstant.K_TITLE);
            if(StringUtils.isBlank(title)) {
                title = (String) fieldSchemaConfig.get(this.getProperty().getFieldKey());
            }
            // 字段编码
            String fieldValueType = (String) fieldSchemaConfig.get(FieldPropertyConstant.K_X_COMPONENT);
            currMainI18nInfo = getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[0], fieldValueType, null, this.getProperty().getPropertyCode(), title);

            // 设置公共字段国际化信息
            this.setPublicFieldContent(moduleI18nConf, fieldSchemaConfig, currMainI18nInfo, publicFieldPropertyI18nMap);

            mainI18nInfoList.add(currMainI18nInfo);
            return currMainI18nInfo;
        } else {
            // 设置公共字段国际化信息
            this.setPublicFieldContent(moduleI18nConf, fieldSchemaConfig, currMainI18nInfo, publicFieldPropertyI18nMap);
            currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[0]));
        }
        mainI18nInfoList.add(currMainI18nInfo);
        return currMainI18nInfo;
    }


    /**
     * 设置公共字段国际化信息
     *
     * @param publicFieldPropertyI18nMap 公共字段属性 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    private void setPublicFieldContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, MainI18nInfoVO currMainI18nInfo, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {
        // 公共字段ID
        String publicFieldDefKey = (String) fieldSchemaConfig.get(FieldPropertyConstant.K_PUBLIC_FIELD_DEF_KEY);
        if (StringUtils.isBlank(publicFieldDefKey)) {
            return;
        }
        // 是公共字段
        List<Integer> disableList = Lists.newArrayList();
        moduleI18nConf.getLanguageList().forEach(item -> disableList.add(I18nConstant.DISABLE_1));
//        currMainI18nInfo.setDisables(disableList);

        // 公共字段国际化信息为空
        MainI18nInfoVO publicFieldI18n = publicFieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        if (publicFieldI18n == null) {
            return;
        }
        // 设置字段国际化
        currMainI18nInfo.setContent(publicFieldI18n.getContent());
    }


    /**
     * 【fieldVo - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据【com.cloudwise.dosm.form.commons.FieldVo】
     */
    @Override
    public void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {
        String titleI18nStr = null;
        if(publicFieldPropertyI18nMap == null) {
            titleI18nStr = (String) fieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        } else {
            titleI18nStr = (String) publicFieldPropertyI18nMap.get(this.getProperty().getPropertyCode());
        }
        if (StringUtils.isBlank(titleI18nStr)) {
            return;
        }
        fieldMap.put(FN_FIELD_NAME, titleI18nStr);
    }
}
