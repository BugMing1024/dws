package com.cloudwise.dosm.i18n.support.aspect;


import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.dosm.i18n.support.annotation.SupportI18nQueryPageVo;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.config.I18nSupportConfig;
import com.cloudwise.i18n.support.core.handler.DefaultTranslationHandler;
import com.cloudwise.i18n.support.core.handler.TranslationHandlerManager;
import com.cloudwise.dosm.i18n.support.core.handler.SimpleQueryPageVoTranslationHandler;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Slf4j
@Aspect
@Component
public class SupportI18nQueryPageVoHandler {
    @Autowired
    TranslationHandlerManager translationHandlerManager;
    @Autowired
    I18nSupportConfig i18nSupportConfig;
    @Pointcut("@annotation(com.cloudwise.dosm.i18n.support.annotation.SupportI18nQueryPageVo)")
    public void i18nPointCut() {
    }

    @Around("i18nPointCut()")
    public Object sendLog(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info("i18nPointCut");
        if(!i18nSupportConfig.getIsSupportI18n()){
            return joinPoint.proceed();
        }
        return doTranslation(joinPoint);
    }

    private Object doTranslation(ProceedingJoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        SupportI18nQueryPageVo annotation = AnnotationUtils.findAnnotation(method, SupportI18nQueryPageVo.class);
        SupportI18n supportI18n = annotation.supportI18n();
        TranslationContext translationContext = new TranslationContext();
        translationContext.setAnnotation(supportI18n);
        if(supportI18n.handlerClass()== DefaultTranslationHandler.class) {
            translationContext.setHandlerClass(SimpleQueryPageVoTranslationHandler.class);
        }
        translationContext.setArgs(joinPoint.getArgs());
        translationContext.setMethod(method);
        translationContext.setTarget(joinPoint.getTarget());
        translationContext.setJoinPoint(joinPoint);
        return translationHandlerManager.translation(translationContext);
    }
}
