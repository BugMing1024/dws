package com.cloudwise.dosm.i18n.support.form.field.bean;

import com.cloudwise.dosm.core.utils.JsonUtils;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Author frank.zheng
 * @Date 2023-08-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormSchema4UpdateParamBean {

    private DosmModuleI18nConf moduleI18nConf;

    /*---------------------------------- 数据库中国际化信息 ----------------------------------*/
    /** 【表单、字段使用】【非当前语言的国际化】公共字段国际化，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>> */
    private Map<String, Map<String, Map<String, Object>>> dbPublicFieldContentI18nMap;

    /** 【表单、字段使用】【非当前语言的国际化】字段国际化，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>> */
    private Map<String, Map<String, Map<String, Object>>> dbPreVerFieldContentI18nMap;


    /** 【表单、字段使用】【非当前语言的国际化】公共字段国际化，数据格式：Map<language, Map<propertyCode, content>> */
    private Map<String, Map<String, Object>> dbPublicFieldPropertyContentI18nMap;

    /** 【表单、字段使用】【非当前语言的国际化】字段国际化，数据格式：Map<language, Map<propertyCode, content>> */
    private Map<String, Map<String, Object>> dbPreVerFieldPropertyContentI18nMap;






    /*----------------------------- 表单字段相关信息 ---------------------------------------*/

    /** 当前语言 - 表单字段schema信息 */
    private Map<String, Object> formSchemaMap;

    /** 【表单使用】上一个版本表单字段编码集合 */
    private Set<String> preVerFormFieldCodes;

    /** 【表单使用】上一个版本表单字段国际化信息【不可以使用字段schema比较，中文保存后、在进行英文保存，两次schema完全不一致，导致无法同步国际化】，格式Map<fieldCode, Map<propertyCode, content>> */
    private Map<String, Map<String, Object>> preVerFormContentI18nMap;

    /** 【表单使用】【当前语言】全部公共字段国际化信息 数据格式：Map<fieldCode, Map<propertyCode, content>> */
    private Map<String, Map<String, Object>> currLanguageDbPublicFieldContentI18nMap;

    /** 【表单使用】上一版本表单字段【字段信息未修改】或公共字段【字段信息未修改】同步过来的国际化信息，数据格式：Map<language, Map<fieldCode, Map<propertyCode, content>>>  */
    @Builder.Default
    private Map<String, Map<String, Map<String, Object>>> syncFormI18nContentMap = Maps.newHashMap();

    /** 【表单使用】上一版本表单字段【字段信息未修改】或公共字段【字段信息未修改】同步过来的国际化信息，数据格式：Map<language, Map<fieldCode, Map<propertyCode, mergeContent>>>  */
    @Builder.Default
    private Map<String, Map<String, Map<String, Object>>> syncFormI18nMergeContentMap = Maps.newHashMap();

    /** 【表单使用】当前语言 - 表单字段国际化信息，数据格式：Map<fieldCode, Map<propertyCode, content>>  */
    @Builder.Default
    private Map<String, Map<String, Object>> formI18nContentMap = Maps.newHashMap();

    /** 【表单使用】当前语言 - 表单字段国际化信息，数据格式：Map<fieldCode, Map<propertyCode, content>>  */
    @Builder.Default
    private Map<String, Map<String, Object>> formI18nMergeContentMap = Maps.newHashMap();






    /*----------------------------- 单个字段相关信息 ---------------------------------------*/

    /** 字段编码 */
    private String fieldCode;

    private String fieldValueType;

    private boolean preVerField;

    /** 是否公共字段 */
    private boolean publicField;

    /** 当前语言 - 字段schema信息 */
    private Map<String, Object> fieldSchemaMap;

    /** 【字段使用】上一个版本表单字段国际化信息 数据格式：Map<propertyCode, content> */
    private Map<String, Object> preVerFieldContentI18nMap;

    /** 【表单使用】【当前语言】某个公共字段国际化信息 数据格式：Map<propertyCode, content> */
    private Map<String, Object> currLanguageDbPublicFieldPorpertyContentI18nMap;

    /** 【字段使用】上一版本字段【字段信息未修改】或公共字段【字段信息未修改】同步过来的国际化信息，数据格式：Map<language, Map<propertyCode, content>>  */
    private Map<String, Map<String, Object>> syncFieldPropertyI18nContentMap;

    /** 【字段使用】上一版本字段【字段信息未修改】或公共字段【字段信息未修改】同步过来的国际化信息，数据格式：Map<language, Map<propertyCode, mergeContent>>  */
    private Map<String, Map<String, Object>> syncFieldPropertyI18nMergeContentMap;


    /** 【字段使用】当前语言 - 字段国际化信息，数据格式：Map<propertyCode, content>  */
    private Map<String, Object> fieldPropertyI18nContentMap;

    /** 【字段使用】当前语言 - 字段国际化信息，数据格式：Map<propertyCode, content>  */
    private Map<String, Object> fieldPropertyI18nMergeContentMap;


    /**
     * 重置字段信息
     * @param fieldCode
     * @param fieldSchemaMap
     */
    public void resetFieldConf(String fieldCode, Map<String, Object> fieldSchemaMap) {
        this.fieldCode = fieldCode;
        this.fieldSchemaMap = fieldSchemaMap;

        this.preVerField = this.preVerFormFieldCodes == null? false: this.preVerFormFieldCodes.contains(this.fieldCode);

        // 公共字段ID
        String publicFieldDefKey = (String) fieldSchemaMap.get(FieldPropertyConstant.K_PUBLIC_FIELD_DEF_KEY);
        // 是否公共字段
        this.publicField = StringUtils.isNotBlank(publicFieldDefKey);

        if(MapUtils.isNotEmpty(this.preVerFormContentI18nMap)) {
            this.preVerFieldContentI18nMap = this.preVerFormContentI18nMap.get(this.fieldCode);
        }

        if(MapUtils.isNotEmpty(this.currLanguageDbPublicFieldContentI18nMap)) {
            this.currLanguageDbPublicFieldPorpertyContentI18nMap = this.currLanguageDbPublicFieldContentI18nMap.get(this.fieldCode);
        }

        this.syncFieldPropertyI18nContentMap = Maps.newHashMap();
        this.syncFieldPropertyI18nMergeContentMap = Maps.newHashMap();


        this.fieldPropertyI18nContentMap = Maps.newHashMap();
        this.formI18nContentMap.put(this.fieldCode, this.fieldPropertyI18nContentMap);
        this.fieldPropertyI18nMergeContentMap = Maps.newHashMap();
        this.formI18nMergeContentMap.put(this.fieldCode, this.fieldPropertyI18nMergeContentMap);


        if(MapUtils.isNotEmpty(this.dbPublicFieldContentI18nMap)) {
            this.dbPublicFieldPropertyContentI18nMap = Maps.newHashMap();
            for(Map.Entry<String, Map<String, Map<String, Object>>> fieldContentI18nEntry: this.dbPublicFieldContentI18nMap.entrySet()) {
                Map<String, Object> fieldPropertyContentI18nMap = fieldContentI18nEntry.getValue().get(this.fieldCode);
                if(MapUtils.isNotEmpty(fieldPropertyContentI18nMap)) {
                    this.dbPublicFieldPropertyContentI18nMap.put(fieldContentI18nEntry.getKey(), fieldPropertyContentI18nMap);
                }
            }
        }


        if(MapUtils.isNotEmpty(this.dbPreVerFieldContentI18nMap)) {
            this.dbPreVerFieldPropertyContentI18nMap = Maps.newHashMap();
            for(Map.Entry<String, Map<String, Map<String, Object>>> fieldContentI18nEntry: this.dbPreVerFieldContentI18nMap.entrySet()) {
                Map<String, Object> fieldPropertyContentI18nMap = fieldContentI18nEntry.getValue().get(this.fieldCode);
                if(MapUtils.isNotEmpty(fieldPropertyContentI18nMap)) {
                    this.dbPreVerFieldPropertyContentI18nMap.put(fieldContentI18nEntry.getKey(), fieldPropertyContentI18nMap);
                }
            }
        }
    }



    public Object getDbPreVerFieldPropertyContentI18n(String propertyCode) {
        if(MapUtils.isEmpty(this.preVerFieldContentI18nMap)) {
            return null;
        }

        return this.preVerFieldContentI18nMap.get(propertyCode);
    }

    public Object getDbPublicFieldPropertyContentI18n(String propertyCode) {
        if(!this.publicField) {
            return null;
        }

        if(MapUtils.isEmpty(this.currLanguageDbPublicFieldPorpertyContentI18nMap)) {
            return null;
        }

        return this.currLanguageDbPublicFieldPorpertyContentI18nMap.get(propertyCode);
    }

    /**
     * 同步字段属性国际化到表单中
     */
    public void syncFieldPropertyI18n2Form() {
        if(MapUtils.isNotEmpty(this.syncFieldPropertyI18nContentMap)) {
            for(Map.Entry<String, Map<String, Object>> fieldPropertyI18nEntry: this.syncFieldPropertyI18nContentMap.entrySet()) {
                this.syncFormI18nContentMap.computeIfAbsent(fieldPropertyI18nEntry.getKey(), k -> Maps.newHashMap())
                        .put(this.fieldCode, fieldPropertyI18nEntry.getValue());
            }
        }

        if(MapUtils.isNotEmpty(this.syncFieldPropertyI18nMergeContentMap)) {
            for(Map.Entry<String, Map<String, Object>> fieldPropertyI18nEntry: this.syncFieldPropertyI18nMergeContentMap.entrySet()) {
                this.syncFormI18nMergeContentMap.computeIfAbsent(fieldPropertyI18nEntry.getKey(), k -> Maps.newHashMap())
                        .put(this.fieldCode, fieldPropertyI18nEntry.getValue());
            }
        }
    }

    public DosmModuleI18nEntity buildFormI18n(List<DosmModuleI18nEntity> resultI18nList) {

        DosmModuleI18nEntity i18nEntity = DosmModuleI18nEntity.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .language(moduleI18nConf.getDefaultLanguage())
                .content(JsonUtils.toJsonString(this.formI18nContentMap))
                .mergeContent(JsonUtils.toJsonString(this.formI18nMergeContentMap))
                .build();
        resultI18nList.add(i18nEntity);

        if(MapUtils.isNotEmpty(this.syncFormI18nMergeContentMap)) {
            for(Map.Entry<String, Map<String, Map<String, Object>>> formI18nEntry: this.syncFormI18nMergeContentMap.entrySet()) {
                String syncFormI18nContent = JsonUtils.toJsonString(this.syncFormI18nContentMap.get(formI18nEntry.getKey()));
                String syncFormI18nMergeContent = JsonUtils.toJsonString(formI18nEntry.getValue());

                resultI18nList.add(DosmModuleI18nEntity.builder()
                        .moduleCode(moduleI18nConf.getModuleCode())
                        .mainId(moduleI18nConf.getMainId())
                        .language(formI18nEntry.getKey())
                        .content(syncFormI18nContent)
                        .mergeContent(syncFormI18nMergeContent)
                        .build()
                );
            }
        }

        return i18nEntity;
    }

}
