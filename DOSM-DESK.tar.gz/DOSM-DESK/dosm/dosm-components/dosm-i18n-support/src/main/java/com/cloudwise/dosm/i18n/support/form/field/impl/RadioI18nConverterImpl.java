package com.cloudwise.dosm.i18n.support.form.field.impl;

import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.i18n.support.form.field.IFormFieldI18nConverter;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.google.common.collect.Lists;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 单选 字段转换
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Component
public class RadioI18nConverterImpl implements IFormFieldI18nConverter {

    public static final List<FieldPropertyEnum> PROPERTY_LIST = Lists.newArrayList(FieldPropertyEnum.FIELD_TITLE, FieldPropertyEnum.DATA_SOURCE, FieldPropertyEnum.HINT);

    @Override
    public FieldValueTypeEnum getFieldValueType() {
        return FieldValueTypeEnum.RADIO;
    }

    @Override
    public List<FieldPropertyEnum> getPropertyList() {
        return PROPERTY_LIST;
    }
}
