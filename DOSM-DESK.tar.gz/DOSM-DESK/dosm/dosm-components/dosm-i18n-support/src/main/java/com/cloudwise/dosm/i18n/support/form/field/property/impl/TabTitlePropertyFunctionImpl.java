package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;

/**
 * 标签容器字段国际化
 * @Author frank.zheng
 * @Date 2023-07-31
 */
public class TabTitlePropertyFunctionImpl extends GroupTitlePropertyFunctionImpl implements IFieldPropertyFunction {
    
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.TAB_TITLE;
    }

}
