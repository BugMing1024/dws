package com.cloudwise.dosm.i18n.support.form.field.property.dto;

import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * 字段多语言配置 到 数据存储 参数
 * @Author frank.zheng
 * @Date 2023-08-03
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldI18nConf2EntityParam {

    /** 字段编码 */
    private String fieldCode;

    /** 字段类型 */
    private String fieldValueType;

    /**
     * 【结果】字段多语言配置信息，格式：Map<语言，Map<字段，Map<propertyCode, Object>>>
     */
    @Builder.Default
    private Map<String, Map<String, Map<String, Object>>> resultI18nMap = Maps.newHashMap();

    /**
     * 【结果】字段多语言merge后配置信息，格式：Map<语言，Map<字段，Map<propertyCode, Object>>>
     */
    @Builder.Default
    private Map<String, Map<String, Map<String, Object>>> resultMergeI18nMap = Maps.newHashMap();

    /**
     * 字段多语言配置信息
     */
    @Builder.Default
    private List<MainI18nInfoVO> fieldI18nList = Lists.newArrayList();
}
