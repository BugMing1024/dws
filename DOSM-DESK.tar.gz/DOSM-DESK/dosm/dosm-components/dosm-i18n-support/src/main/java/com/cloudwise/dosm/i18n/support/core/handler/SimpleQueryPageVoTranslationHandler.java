package com.cloudwise.dosm.i18n.support.core.handler;

import com.cloudwise.dosm.core.pojo.vo.PageVo;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.handler.simple.AbstractQueryTranslationHandler;
import com.cloudwise.i18n.support.core.handler.simple.SimpleQueryListTranslationHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/3
 */
@Component
public class SimpleQueryPageVoTranslationHandler extends AbstractQueryTranslationHandler<PageVo> {

    @Autowired
    SimpleQueryListTranslationHandler simpleQueryListTranslationHandler;

    @Override
    public String getType() {
        return "simpleQueryPageTranslationHandler";
    }

    @Override
    public PageVo doTranslation(PageVo pageVo, TranslationContext translationContext) {
        List records = pageVo.getRecords();
        records = simpleQueryListTranslationHandler.doTranslation(records, translationContext);
        pageVo.setRecords(records);
        return pageVo;
    }
}
