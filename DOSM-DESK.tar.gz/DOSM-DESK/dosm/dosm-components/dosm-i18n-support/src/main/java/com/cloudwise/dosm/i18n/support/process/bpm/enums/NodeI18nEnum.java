package com.cloudwise.dosm.i18n.support.process.bpm.enums;

import com.cloudwise.dosm.core.constant.ResourceCode;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.collections4.MapUtils;

import java.util.Map;

/**
 * @Author frank.zheng
 * @Date 2023-08-02
 */
@Getter
@AllArgsConstructor
public enum NodeI18nEnum {

    // SingleApproveTask 是 UserTask 子类
    SINGLE_APPROVE_TASK("单人审批", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),
    // MultiApproveTask 是 UserTask 子类
    MULTI_APPROVE_TASK("多人审批", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),

    USER_TASK("用户任务", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),

    EXCLUSIVE_GATEWAY("单一网关", ResourceCode.PropertyI18n.Process.BPM_EXCLUSIVE_GATEWAY),
    PARALLEL_GATEWAY("并行网关", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),

    RECEIVE_TASK("同步子流程", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),
    SERVICE_TASK("异步子流程", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),

    ACCEPTANCE_TASK("接收节点", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),
    AUTOMATION_TASK("自动化节点", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),

    START_TASK("开始节点", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),
    END_TASK("结束节点", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),
    SEQUENCE_FLOW("流转线", ResourceCode.PropertyI18n.Process.BPM_SEQUENCE_FLOW),

    @Deprecated
    SUB_PROC("子流程", ResourceCode.PropertyI18n.Process.BPM_NODE_NAME),


    INCLUSIVE_GATEWAY("相容网关", ResourceCode.PropertyI18n.Process.BPM_EXCLUSIVE_GATEWAY),
    ;

    ;

    /** 说明 */
    private String desc;

    /** 属性国际化编码 */
    private Integer propertyNameI18n;

    private final static Map<String, NodeI18nEnum> NODE_I18N_MAP = Maps.newHashMap();


    public static NodeI18nEnum getNodeI18nByName(String name) {
        if(MapUtils.isEmpty(NODE_I18N_MAP)) {
            NodeI18nEnum[] nodeI18NEnums = NodeI18nEnum.values();
            for(NodeI18nEnum nodeI18NEnum: nodeI18NEnums) {
                NODE_I18N_MAP.put(nodeI18NEnum.name(), nodeI18NEnum);
            }
        }

        return NODE_I18N_MAP.get(name);
    }

}
