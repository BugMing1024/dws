package com.cloudwise.dosm.i18n.support.form.field.impl;

import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.i18n.support.form.field.FormFieldI18nConverterManager;
import com.cloudwise.dosm.i18n.support.form.field.IFormFieldI18nConverter;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 表格 字段转换
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Component
public class TableFormI18nConverterImpl implements IFormFieldI18nConverter {

    public static final List<FieldPropertyEnum> PROPERTY_LIST = Lists.newArrayList(FieldPropertyEnum.TABLE_TITLE, FieldPropertyEnum.HINT);

    @Autowired
    private FormFieldI18nConverterManager fieldI18nConverterManager;

    @Override
    public FieldValueTypeEnum getFieldValueType() {
        return FieldValueTypeEnum.TABLE_FORM;
    }

    @Override
    public List<FieldPropertyEnum> getPropertyList() {
        return PROPERTY_LIST;
    }


    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param currLevelI18nInfoList 当前字段所在级别的 i18n 信息
     * @param formFieldI18nMap  表单字段 i18n 信息，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     * @param publicFieldI18nMap 公共字段 i18n 信息，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    @Override
    public MainI18nInfoVO buildMainI18nByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> currLevelI18nInfoList,
            Map<String, Map<String, MainI18nInfoVO>> formFieldI18nMap, Map<String, Map<String, MainI18nInfoVO>> publicFieldI18nMap) {
        String fieldCode = moduleI18nConf.getDataCode();
        Map<String, MainI18nInfoVO> fieldPropertyI18nMap = formFieldI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());
        Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap = publicFieldI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());

        // 分组属性集合
        List<FieldPropertyEnum> propertyList = getPropertyList();

        FieldPropertyEnum property = propertyList.get(0);
        MainI18nInfoVO titleMainI18nInfo = property.getFunction().buildMainI18nInfoByFieldSchema4Conf(moduleI18nConf, fieldSchemaConfig, currLevelI18nInfoList, fieldPropertyI18nMap, publicFieldPropertyI18nMap);
        List<MainI18nInfoVO> childI18nList = Lists.newArrayList();
        for(int i = 1; i < propertyList.size(); i++) {
            propertyList.get(i).getFunction().buildMainI18nInfoByFieldSchema4Conf(moduleI18nConf, fieldSchemaConfig, childI18nList, fieldPropertyI18nMap, publicFieldPropertyI18nMap);
        }

        // 表格列数据
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);
        List<Map<String, Object>> columnSchemaMapList = (List<Map<String, Object>>) xPropsMap.get(FieldPropertyConstant.K_COLUMNS);
        List<MainI18nInfoVO> columnFieldI18nList = Lists.newArrayList();
        for(Map<String, Object> columnSchemaMap: columnSchemaMapList) {
            // 字段编码
            fieldCode = (String) columnSchemaMap.get(FieldPropertyConstant.K_FIELD_KEY);
            fieldI18nConverterManager.getMainI18nByFieldSchema4Conf(moduleI18nConf, fieldCode, columnSchemaMap, columnFieldI18nList, formFieldI18nMap, publicFieldI18nMap);
        }

        if(CollectionUtils.isEmpty(columnFieldI18nList)) {
            titleMainI18nInfo.setLeaf(I18nConstant.LEAF_1);
            titleMainI18nInfo.setChilds(null);
        } else {
            titleMainI18nInfo.setLeaf(I18nConstant.LEAF_0);
            titleMainI18nInfo.setChilds(childI18nList);
            childI18nList.addAll(columnFieldI18nList);
        }

        return titleMainI18nInfo;
    }





    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     */
    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext){
        List<FieldPropertyEnum> propertyList = getPropertyList();
        for(FieldPropertyEnum property: propertyList) {
            property.getFunction().buildFieldSchemaI18n4Update(moduleI18nConf, paramContext);
        }

        // 表格列数据
        Map<String, Object> xPropsMap = (Map<String, Object>) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_PROPS);
        List<Map<String, Object>> columnSchemaMapList = (List<Map<String, Object>>) xPropsMap.get(FieldPropertyConstant.K_COLUMNS);
        for(Map<String, Object> columnSchemaMap: columnSchemaMapList) {
            /** 重置字段信息 */
            paramContext.resetFieldConf((String) columnSchemaMap.get(FieldPropertyConstant.K_FIELD_KEY), columnSchemaMap);

            fieldI18nConverterManager.buildModuleI18nByFieldSchema4Update(moduleI18nConf, paramContext);

            /** 同步字段属性国际化到表单中 */
            paramContext.syncFieldPropertyI18n2Form();
        }
    }






    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity 模块 i18n 配置
     * @param fieldSchemaConfig 表单配置
     * @param fieldI18nContentMap 字段国际化
     * @param publicFieldContentI18nMap 字段对应的公共字段国际化
     * @param dbFormFieldI18nMap 表单国际化
     * @param dbAllPublicFieldI18nMap 公共字段国际化
     */
    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldI18nContentMap, Map<String, Object> publicFieldContentI18nMap,
            Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap) {
        if(MapUtils.isNotEmpty(fieldI18nContentMap)) {
            List<FieldPropertyEnum> propertyList = getPropertyList();
            for(FieldPropertyEnum property: propertyList) {
                property.getFunction().buildFieldSchemaI18n4Query(moduleI18nEntity, fieldSchemaConfig, fieldI18nContentMap, publicFieldContentI18nMap);
            }
        }
        // 表格列数据
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);
        List<Map<String, Object>> columnSchemaMapList = (List<Map<String, Object>>) xPropsMap.get(FieldPropertyConstant.K_COLUMNS);
        for(Map<String, Object> columnSchemaMap: columnSchemaMapList) {
            // 字段编码
            String fieldCode = (String) columnSchemaMap.get(FieldPropertyConstant.K_FIELD_KEY);
            // 字段国际化信息
            fieldI18nContentMap = (Map<String, Object>) dbFormFieldI18nMap.get(fieldCode);
            // 字段对应的公共字段国际化
            publicFieldContentI18nMap = dbAllPublicFieldI18nMap.get(fieldCode);

            fieldI18nConverterManager.buildFieldSchemaI18n4Query(moduleI18nEntity, fieldCode, columnSchemaMap, fieldI18nContentMap, publicFieldContentI18nMap, dbFormFieldI18nMap, dbAllPublicFieldI18nMap);
        }
    }






    /**
     * 【用于表单变更对比】获取表单 chema 配置字段信息及引用的公共字段
     * @param fieldCode
     * @param fieldSchemaConfig
     * @param fieldCodes 公共字段编码
     */
    @Override
    public void rebuildFieldSchema(String fieldCode, Map<String, Object> fieldSchemaConfig, Set<String> fieldCodes) {
        fieldCodes.add(fieldCode);

        // 表格列数据
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);
        List<Map<String, Object>> columnSchemaMapList = (List<Map<String, Object>>) xPropsMap.get(FieldPropertyConstant.K_COLUMNS);
        for(Map<String, Object> columnSchemaMap: columnSchemaMapList) {
            // 字段编码
            fieldCode = (String) columnSchemaMap.get(FieldPropertyConstant.K_FIELD_KEY);
            fieldI18nConverterManager.rebuildFieldSchema(fieldCode, columnSchemaMap, fieldCodes);
        }

    }
}
