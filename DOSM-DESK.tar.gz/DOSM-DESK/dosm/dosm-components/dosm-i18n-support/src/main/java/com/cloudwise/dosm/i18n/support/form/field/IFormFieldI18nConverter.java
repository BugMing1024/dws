package com.cloudwise.dosm.i18n.support.form.field;

import com.cloudwise.dosm.api.bean.form.enums.FieldValueTypeEnum;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 字段转换
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"fieldCode":{"fieldType":"字段类型，参考：FieldValueTypeEnum","propertyCode":"国际化值","fieldHint":{"hintType":"1","hintContent":"国际化值"},"dataSource":{"字典id1":"国际化值","字典id2":"国际化值"},"toolTips":{"1":"ss","3":null}}}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "字段类型，参考：FieldValueTypeEnum", "property_code": "title:字段名称;unit:单位;自定义字典选项ID;hintContent：提示内容", "type": "1、国际化弹窗输入框类型 1 文本 2 富文本; 2、自定义数据字典：dataSource; 3、星级提示选项：toolTips", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "0/1", "childs": []}
 * </ul>
 * </ol>
 * @Author frank.zheng
 * @Date 2023-07-28
 */
public interface IFormFieldI18nConverter {

    Logger log = LoggerFactory.getLogger(IFormFieldI18nConverter.class);

    /** 字段值类 */
    FieldValueTypeEnum getFieldValueType();

    /** 字段属性国际化关联信息 */
    List<FieldPropertyEnum> getPropertyList();

    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     */
    default void buildI18nConf4Field(DosmModuleI18nConf moduleI18nConf, FieldI18nConf2EntityParam param) {
        // 字段多语言设置页面数据
        List<MainI18nInfoVO> fieldI18nList = param.getFieldI18nList();
        // 减少匹配次数
        List<FieldPropertyEnum> tmpPropertyList = Lists.newArrayList(getPropertyList());
        for(MainI18nInfoVO fieldI18n: fieldI18nList) {
            for(int i = 0; i < tmpPropertyList.size(); i++) {
                FieldPropertyEnum fieldProperty = tmpPropertyList.get(i);
                boolean isMatch = fieldProperty.getFunction().isMatch(fieldI18n);
                if(isMatch) {
                    fieldProperty.getFunction().buildI18nConf(moduleI18nConf, fieldI18n, param);
//                    tmpPropertyList.remove(i);
                    break;
                }
            }

        }

    }

    /**
     * 【查询】字段 i18n 配置转为 map，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     * @param moduleI18nConf
     * @param fieldI18nMap 字段国际化信息，格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
     * @param fieldMainI18nMap 字段 i18n 信息，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    default void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, Map<String, MainI18nInfoVO>> fieldMainI18nMap) {
        List<FieldPropertyEnum> propertyList = getPropertyList();
        for(FieldPropertyEnum property: propertyList) {
            Map<String, MainI18nInfoVO> fieldPropertyI18nMap = fieldMainI18nMap.computeIfAbsent(moduleI18nConf.getDataCode(), k -> Maps.newHashMap());
            property.getFunction().buildFieldMainI18nMapByContent(moduleI18nConf, fieldI18nMap, fieldPropertyI18nMap);
        }
    }


    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param currLevelI18nInfoList 当前字段所在级别的 i18n 信息
     * @param formFieldI18nMap  表单字段 i18n 信息，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     * @param publicFieldI18nMap 公共字段 i18n 信息，格式：Map<fieldCode, Map<propertyCode, MainI18nInfoVO>>
     */
    default MainI18nInfoVO buildMainI18nByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> currLevelI18nInfoList,
            Map<String, Map<String, MainI18nInfoVO>> formFieldI18nMap, Map<String, Map<String, MainI18nInfoVO>> publicFieldI18nMap) {
        String fieldCode = moduleI18nConf.getDataCode();
        Map<String, MainI18nInfoVO> fieldPropertyI18nMap = formFieldI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());
        Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap = publicFieldI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());

        String cmdbModelId = (String) fieldSchemaConfig.get(FieldPropertyConstant.K_CMDB_MODEL_ID);
        String firstId = (String) fieldSchemaConfig.get(FieldPropertyConstant.K_FIRST_ID);
        if(StringUtils.isNotBlank(cmdbModelId) || StringUtils.isNotBlank(firstId)) {
            return null;
        }

        List<FieldPropertyEnum> propertyList = getPropertyList();
        FieldPropertyEnum property = propertyList.get(0);
        MainI18nInfoVO titleMainI18nInfo = property.getFunction().buildMainI18nInfoByFieldSchema4Conf(moduleI18nConf, fieldSchemaConfig, currLevelI18nInfoList, fieldPropertyI18nMap, publicFieldPropertyI18nMap);
        List<MainI18nInfoVO> childI18nList = Lists.newArrayList();
        for(int i = 1; i < propertyList.size(); i++) {
            propertyList.get(i).getFunction().buildMainI18nInfoByFieldSchema4Conf(moduleI18nConf, fieldSchemaConfig, childI18nList, fieldPropertyI18nMap, publicFieldPropertyI18nMap);
        }

        if(CollectionUtils.isEmpty(childI18nList)) {
            titleMainI18nInfo.setLeaf(I18nConstant.LEAF_1);
            titleMainI18nInfo.setChilds(null);
        } else {
            titleMainI18nInfo.setLeaf(I18nConstant.LEAF_0);
            titleMainI18nInfo.setChilds(childI18nList);
        }
        return titleMainI18nInfo;
    }





    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     */
    default void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext){
        String cmdbModelId = (String) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_CMDB_MODEL_ID);
        String firstId = (String) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_FIRST_ID);
        if(StringUtils.isNotBlank(cmdbModelId) || StringUtils.isNotBlank(firstId)) {
            return;
        }
        List<FieldPropertyEnum> propertyList = getPropertyList();
        for(FieldPropertyEnum property: propertyList) {
            property.getFunction().buildFieldSchemaI18n4Update(moduleI18nConf, paramContext);
        }
    }





    /**
     * 【表单设计/公共字段 - 查询】通过表单国际化及表单查询接口信息获取国际化后的表单数据
     * @param moduleI18nEntity 模块 i18n 配置
     * @param fieldSchemaConfig 表单配置
     * @param fieldI18nContentMap 字段国际化
     * @param publicFieldContentI18nMap 字段对应的公共字段国际化
     * @param dbFormFieldI18nMap 表单国际化
     * @param dbAllPublicFieldI18nMap 公共字段国际化
     */
    default void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldI18nContentMap, Map<String, Object> publicFieldContentI18nMap,
            Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap) {

        if (MapUtils.isEmpty(fieldI18nContentMap)) {
            log.warn("fieldI18nContentMap is empty, id: {}, content: {}", moduleI18nEntity.getMainId(), moduleI18nEntity.getMergeContent());
            return;
        }

        List<FieldPropertyEnum> propertyList = getPropertyList();
        for(FieldPropertyEnum property: propertyList) {
            property.getFunction().buildFieldSchemaI18n4Query(moduleI18nEntity, fieldSchemaConfig, fieldI18nContentMap, publicFieldContentI18nMap);
        }
    }





    /**
     * 【fieldVo - 查询】通过表单国际化及字段List接口信息获取国际化后的字段List数据【com.cloudwise.dosm.form.commons.FieldVo】
     * @param moduleI18nEntity 模块 i18n 配置
     * @param fieldMap 字段信息配置（fieldVo对象）
     * @param fieldI18nContentMap 字段国际化信息
     * @param publicFieldI18nContentMap 字段对应公共字段国际化
     * @param dbFormFieldI18nMap 表单国际化信息
     * @param dbAllPublicFieldI18nMap 公共字段国际化信息
     */
    default void buildFieldI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldI18nContentMap, Map<String, Object> publicFieldI18nContentMap,
            Map<String, Object> dbFormFieldI18nMap, Map<String, Map<String, Object>> dbAllPublicFieldI18nMap){
        if(MapUtils.isEmpty(fieldMap)){
            return;
        }

        if(fieldI18nContentMap ==null){
            fieldI18nContentMap = Maps.newHashMap();
        }

        List<FieldPropertyEnum> propertyList = getPropertyList();
        for(FieldPropertyEnum property: propertyList) {
            property.getFunction().buildI18n4FieldList(moduleI18nEntity, fieldMap, fieldI18nContentMap, publicFieldI18nContentMap);
        }
    }

   default void buildFieldI18n4FieldList4FillAndExtend(Map<String, Object> fieldSchemaMap, Map<String, Map<String, Object>> dbFieldI18nMap){

       List<FieldPropertyEnum> propertyList = getPropertyList();
       for(FieldPropertyEnum property: propertyList) {
           property.getFunction().buildFieldI18n4FieldList4FillAndExtend(fieldSchemaMap, dbFieldI18nMap);
       }
   }





    /**
     * 【用于表单变更对比】获取表单 chema 配置字段信息及引用的公共字段
     * @param fieldCode
     * @param fieldSchemaMap
     * @param fieldCodes 公共字段编码
     */
   default void rebuildFieldSchema(String fieldCode, Map<String, Object> fieldSchemaMap, Set<String> fieldCodes) {
       fieldCodes.add(fieldCode);
   }
}
