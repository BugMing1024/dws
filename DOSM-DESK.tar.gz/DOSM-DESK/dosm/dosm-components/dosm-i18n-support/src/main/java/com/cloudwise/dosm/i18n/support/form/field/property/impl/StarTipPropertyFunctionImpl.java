package com.cloudwise.dosm.i18n.support.form.field.property.impl;

import com.cloudwise.dosm.core.utils.MessageUtils;
import com.cloudwise.dosm.i18n.support.form.field.bean.FormSchema4UpdateParamBean;
import com.cloudwise.dosm.i18n.support.form.field.constant.FieldPropertyConstant;
import com.cloudwise.dosm.i18n.support.form.field.enums.FieldPropertyEnum;
import com.cloudwise.dosm.i18n.support.form.field.property.IFieldPropertyFunction;
import com.cloudwise.dosm.i18n.support.form.field.property.dto.FieldI18nConf2EntityParam;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 星级提示 属性
 * <ol>
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象content数据格式：{"toolTips":{"1":"ss","3":null}}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS_FORM", "main_id"："表单ID", "data_code"："fieldCode", "ext_code": "", "property_code": "1", "type": "toolTips", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "1"}
 * </ul>
 * </ol>
 * @Author frank.zheng
 * @Date 2023-07-31
 */
@Slf4j
public class StarTipPropertyFunctionImpl implements IFieldPropertyFunction {

    @Override
    public FieldPropertyEnum getProperty() {
        return FieldPropertyEnum.STAR_TIP;
    }


    /**
     * 【表单设计/公共字段 - 保存/更新】通过表单保存/更新接口信息获取表单国际化信息
     * @param moduleI18nConf 模块 i18n 配置
     * @param paramContext
     */
    @Override
    public void buildFieldSchemaI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext) {

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) paramContext.getFieldSchemaMap().get(FieldPropertyConstant.K_X_PROPS);

        // 获取自定义星级提示
        List<String> tipList = (List<String>) xPropsMap.get(this.getProperty().getFieldKey());
        if(CollectionUtils.isEmpty(tipList)) {
            return;
        }

        Map<String, String> starTipI18nContentMap = (Map<String, String>) paramContext.getFieldPropertyI18nContentMap().computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

        int count = (int) xPropsMap.get(FieldPropertyConstant.K_COUNT);
        List<String> tipIndexs = Lists.newArrayList();
        // 星级
        String indexStr = null;
        for(int i = 0, starNum = 1; i < count; i++, starNum++) {
            if(i >= tipList.size()){
                break;
            }
            tipIndexs.add(indexStr = "" + starNum);
            String tipStr = tipList.get(i);
            if(StringUtils.isNotBlank(tipStr)) {
                starTipI18nContentMap.put(indexStr, tipStr);
            }
        }

        /** 同步其他语言国际化信息 */
        this.syncFieldPropertyI18n4Update(moduleI18nConf, paramContext, tipIndexs, starTipI18nContentMap);
    }

    /**
     * 同步其他语言国际化信息
     */
    public void syncFieldPropertyI18n4Update(DosmModuleI18nConf moduleI18nConf, FormSchema4UpdateParamBean paramContext, List<String> currTipIndexs, Map<String, String> currStarTipI18nContentMap) {
        Map<String, String> orgFieldStarTipI18nMap = null;
        // 【非当前语言的国际化】字段国际化，数据格式：Map<language, Map<propertyCode, content>>
        Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap = null;
        if(paramContext.isPreVerField()) {
            /** 上一个版本存在该字段且是自定义数据字典，则使用上一版本字段国际化进行同步 */
            orgFieldStarTipI18nMap = (Map<String, String>) paramContext.getDbPreVerFieldPropertyContentI18n(this.getProperty().getFieldKey());
            syncFieldPropertyContentI18nMap = paramContext.getDbPreVerFieldPropertyContentI18nMap();
        } else {
            /** 上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步 */
            orgFieldStarTipI18nMap = (Map<String, String>) paramContext.getDbPublicFieldPropertyContentI18n(this.getProperty().getFieldKey());
            syncFieldPropertyContentI18nMap = paramContext.getDbPublicFieldPropertyContentI18nMap();
        }

        this.syncPropertyContentI18n4UpdateByMap(paramContext, currTipIndexs, orgFieldStarTipI18nMap, syncFieldPropertyContentI18nMap);


        this.mergeFieldSchemaDataSourceI18n4Update(paramContext, currTipIndexs, currStarTipI18nContentMap);
    }

    /**
     * 上一个版本不存在该字段，该字段如果是公共字段，则使用公共字段国际化进行同步
     */
    public void syncPropertyContentI18n4UpdateByMap(FormSchema4UpdateParamBean paramContext, List<String> currTipIndexs, Map<String, String> orgFieldStarTipI18nMap, Map<String, Map<String, Object>> syncFieldPropertyContentI18nMap) {
        if(Objects.nonNull(syncFieldPropertyContentI18nMap)) {
            for (Map.Entry<String, Map<String, Object>> syncDbPropertyContentI18nEntry : syncFieldPropertyContentI18nMap.entrySet()) {
                if (MapUtils.isEmpty(syncDbPropertyContentI18nEntry.getValue())) {
                    continue;
                }
                Map<String, String> syncDBI18nContentMap = (Map<String, String>) syncDbPropertyContentI18nEntry.getValue().get(this.getProperty().getPropertyCode());
                if (MapUtils.isEmpty(syncDBI18nContentMap)) {
                    continue;
                }

                /** 星级提示内容与上一个字段内容一致则同步到当前星级【不区分顺序】 */
                Map<String, String> syncI18nContentMap = Maps.newHashMap();
                for (String indexStr : currTipIndexs) {
                    String syncI18nContent = syncDBI18nContentMap.get(indexStr);
                    if (StringUtils.isBlank(syncI18nContent)) {
                        continue;
                    }
                    syncI18nContentMap.put(indexStr, syncDBI18nContentMap.get(indexStr));
                }

                if (MapUtils.isEmpty(syncI18nContentMap)) {
                    continue;
                }
                // 同步该语言的选项国际化信息
                Map<String, Object> syncPropertyContentI18nMap = paramContext.getSyncFieldPropertyI18nContentMap().computeIfAbsent(syncDbPropertyContentI18nEntry.getKey(), k -> Maps.newHashMap());
                syncPropertyContentI18nMap.put(this.getProperty().getPropertyCode(), syncI18nContentMap);
            }
        }
    }

    /**
     * 同步其他语言国际化信息
     */
    public void mergeFieldSchemaDataSourceI18n4Update(FormSchema4UpdateParamBean paramContext, List<String> currTipIndexs, Map<String, String> currStarTipI18nContentMap) {

        Map<String, String> mergeStarTipContentMap = Maps.newHashMap(currStarTipI18nContentMap);
        // 不同语言星级提示为空的集合，数据格式：List<Map<tipIndex, syncPropertyI18nContentMap>>
        List<Map<String, Map<String, String>>> starTipIsNullMapList = Lists.newArrayList();

        // 属性同步的 其他语言的 国际化 content
        for(Map.Entry<String, Map<String, Object>> syncFieldPropertyI18nContentEntry: paramContext.getSyncFieldPropertyI18nContentMap().entrySet()) {
            Map<String, Object> syncPropertyI18nMergeContent = paramContext.getSyncFieldPropertyI18nMergeContentMap().computeIfAbsent(syncFieldPropertyI18nContentEntry.getKey(), k -> Maps.newHashMap());

            /** 同步的 - 其他语言 - 国际化不存 */
            if(MapUtils.isEmpty(syncFieldPropertyI18nContentEntry.getValue())) {
                syncPropertyI18nMergeContent.put(this.getProperty().getPropertyCode(), currStarTipI18nContentMap);
                continue;
            }

            Map<String, String> syncPropertyI18nContentMap = (Map<String, String>) syncFieldPropertyI18nContentEntry.getValue().get(this.getProperty().getPropertyCode());
            /** 同步的 - 其他语言 - 国际化 content 信息未配置 */
            if(MapUtils.isEmpty(syncPropertyI18nContentMap)) {
                syncPropertyI18nMergeContent.put(this.getProperty().getPropertyCode(), currStarTipI18nContentMap);
                continue;
            }

            // 数据格式：Map<tipIndex, syncPropertyI18nContentMap>
            Map<String, Map<String, String>> starTipIsNullMap = Maps.newHashMap();
            starTipIsNullMapList.add(starTipIsNullMap);

            Map<String, String> syncI18nMergeContentMap = Maps.newHashMap();
            for(String tipIndex: currTipIndexs) {
                String syncI18nContent = syncPropertyI18nContentMap.get(tipIndex);
                if(StringUtils.isBlank(syncI18nContent)) {
                    // 同步的国际化信息为空，则记录
                    starTipIsNullMap.put(tipIndex, syncI18nMergeContentMap);
                } else {
                    syncI18nMergeContentMap.put(tipIndex, syncI18nContent);
                    mergeStarTipContentMap.putIfAbsent(tipIndex, syncI18nContent);
                }
            }
            /** 同步的 - 其他语言 - 国际化信息存在配置 */
            syncPropertyI18nMergeContent.put(this.getProperty().getPropertyCode(), syncI18nMergeContentMap);
        }

        for(Map<String, Map<String, String>> starTipIsNullMap: starTipIsNullMapList) {
            for(Map.Entry<String, Map<String, String>> starTipIsNullEntry: starTipIsNullMap.entrySet()) {
                String mergeStarTip = mergeStarTipContentMap.get(starTipIsNullEntry.getKey());
                if(StringUtils.isNotBlank(mergeStarTip)) {
                    starTipIsNullEntry.getValue().put(starTipIsNullEntry.getKey(), mergeStarTip);
                }
            }
        }

        // 【当前语言】【merge】国际化
        paramContext.getFieldPropertyI18nMergeContentMap().put(this.getProperty().getPropertyCode(), mergeStarTipContentMap);
    }





    @Override
    public void buildFieldSchemaI18n4Query(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldSchemaConfig, Map<String, Object> fieldPropertyI18nMap,
            Map<String, Object> publicFieldPropertyI18nMap) {
        Map<String, Object> starTipI18nContentMap = (Map<String, Object>) fieldPropertyI18nMap.get(getProperty().getFieldKey());
        if(MapUtils.isEmpty(starTipI18nContentMap)) {
            return;
        }

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);

        // 获取自定义星级提示
        List<String> tipList = (List<String>) xPropsMap.get(this.getProperty().getFieldKey());
        if(CollectionUtils.isEmpty(tipList)) {
            return;
        }

        // 星级
        for(int i = 0, starNum = 1; i < tipList.size(); i++, starNum++) {
            String tipI18nStr = (String) starTipI18nContentMap.get(""+ starNum);
            if(StringUtils.isNotBlank(tipI18nStr)) {
                tipList.set(i, tipI18nStr);
            }
        }
    }

    /**
     * 属性是否可以处理数据数据
     * @param fieldI18n
     * @return
     */
    @Override
    public boolean isMatch(MainI18nInfoVO fieldI18n) {
        return getProperty().getFieldKey().equals(fieldI18n.getType());
    }



    /**
     * 【字段 - 多语言设置】通过字段多语言设置页面获取字段国际化信息
     * @param moduleI18nConf
     * @param param
     * @return
     */
    @Override
    public void buildI18nConf(DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO fieldI18n, FieldI18nConf2EntityParam param) {
        Map<String, List<String>> contentI18nMap = fieldI18n.getContent();

        String fieldCode = fieldI18n.getDataCode();
        // 属性 merge 后的语言内容
        String mergeContent = null;
        List<Map<String, Object>> mergeContentIsNullList = Lists.newArrayList();
        for(Map.Entry<String, List<String>> contentI18nEntry: contentI18nMap.entrySet()) {
            String language = contentI18nEntry.getKey();
            // 【某语言下字段】国际化集合,格式：Map<字段，Map<propertyCode, Object>>
            Map<String, Map<String, Object>> languageI18nMap = param.getResultI18nMap().computeIfAbsent(language, k -> Maps.newHashMap());
            // 【字段下各属性】国际化集合,格式：Map<propertyCode, Object>
            Map<String, Object> fieldI18nMap = languageI18nMap.computeIfAbsent(fieldCode, k -> Maps.newHashMap());
            // 【提示】国际化集合,格式：Map<选项ID, "国际化">
            Map<String, Object> tipsI18nMap = (Map<String, Object>) fieldI18nMap.computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

            Map<String, Object> tipsMergeI18nMap = (Map<String, Object>) param.getResultMergeI18nMap().computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(fieldCode, k -> Maps.newHashMap())
                    .computeIfAbsent(getProperty().getFieldKey(), k -> Maps.newHashMap());

            List<String> contentList = contentI18nEntry.getValue();
            String content = null;
            // 配置国际化为空
            if(CollectionUtils.isEmpty(contentList) || StringUtils.isBlank(content = contentList.get(0))) {
                mergeContentIsNullList.add(tipsMergeI18nMap);
            } else {
                tipsI18nMap.put(fieldI18n.getPropertyCode(), mergeContent = content);
                tipsMergeI18nMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }

        if(mergeContent != null) {
            for(Map<String, Object> mergeContentMap: mergeContentIsNullList) {
                mergeContentMap.put(fieldI18n.getPropertyCode(), mergeContent);
            }
        }
    }

    /**
     * 【查询】将字段 i18n 配置转为 map，格式：Map<propertyCode, MainI18nInfoVO>
     * @param moduleI18nConf
     * @param fieldI18nMap         字段国际化信息，格式：{"propertyCode": "国际化值", "dataSource": {"字典id": "国际化值"}, "fieldHint": {"hintContent": "国际化值"}}
     * @param fieldPropertyI18nMap 字段 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public void buildFieldMainI18nMapByContent(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldI18nMap, Map<String, MainI18nInfoVO> fieldPropertyI18nMap) {
        // 星级提示
        Map<String, String> starTipMap = (Map<String, String>) fieldI18nMap.get(this.getProperty().getFieldKey());
        if(MapUtils.isEmpty(starTipMap)) {
            log.warn("not found starTipMap, key: {}", this.getProperty().getFieldKey());
            return;
        }
        for(Map.Entry<String, String> entry: starTipMap.entrySet()) {
            // 设置语言值【模块对象中获取属性值】
            Map<String, List<String>> contentMap = fieldPropertyI18nMap.computeIfAbsent(this.getUUID(this.getProperty().getFieldKey(), entry.getKey()), k -> MainI18nInfoVO.builder()
                    .moduleCode(moduleI18nConf.getModuleCode())
                    .mainId(moduleI18nConf.getMainId())
                    .dataCode(moduleI18nConf.getDataCode())
                    .extCode(null)
                    .type(this.getProperty().getFieldKey())
                    .propertyCode(entry.getKey())
                    .content(Maps.newHashMap())
                    .build()
            ).getContent();
            contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(entry.getValue()));
        }
    }



    /**
     * 【查询 - 多语言设置】获取字段I18n信息
     * @param moduleI18nConf 模块国际化配置
     * @param fieldSchemaConfig 字段的配置信息【字段schema信息】
     * @param mainI18nInfoList 字段下属性的mainI8nInfo集合【用于选项特殊情况】
     * @param fieldPropertyI18nMap 字段属性的 I8n ，格式：Map<propertyCode, MainI18nInfoVO>
     * @param publicFieldPropertyI18nMap 公共字段属性 i18n 信息，格式：Map<propertyCode, MainI18nInfoVO>
     */
    @Override
    public MainI18nInfoVO buildMainI18nInfoByFieldSchema4Conf(DosmModuleI18nConf moduleI18nConf, Map<String, Object> fieldSchemaConfig, List<MainI18nInfoVO> mainI18nInfoList,
            Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap) {

        // 获取字段 x-props
        Map<String, Object> xPropsMap = (Map<String, Object>) fieldSchemaConfig.get(FieldPropertyConstant.K_X_PROPS);
        // 获取自定义星级提示
        List<String> tipList = (List<String>) xPropsMap.get(this.getProperty().getFieldKey());
        int count = (int) xPropsMap.get(FieldPropertyConstant.K_COUNT);

        MainI18nInfoVO currMainI18nInfo = null;
        // 星级
        int starNum = 1;
        boolean tipListIsEmpty = CollectionUtils.isEmpty(tipList);
        for(int i = 0; i < count; i++) {
            if(i >= tipList.size()){
                break;
            }
            String tipStr = tipListIsEmpty? null: tipList.get(i);
            currMainI18nInfo = getTipMainI18nInfo(moduleI18nConf, mainI18nInfoList, fieldPropertyI18nMap, publicFieldPropertyI18nMap, "" + (starNum++), tipStr);
        }
        return currMainI18nInfo;
    }

    @Override
    public void buildI18n4FieldList(DosmModuleI18nEntity moduleI18nEntity, Map<String, Object> fieldMap, Map<String, Object> fieldPropertyI18nMap, Map<String, Object> publicFieldPropertyI18nMap) {

    }

    private MainI18nInfoVO getTipMainI18nInfo(DosmModuleI18nConf moduleI18nConf, List<MainI18nInfoVO> mainI18nInfoList, Map<String, MainI18nInfoVO> fieldPropertyI18nMap, Map<String, MainI18nInfoVO> publicFieldPropertyI18nMap, String starStr, String tipStr) {
        String itemUUID = this.getUUID(this.getProperty().getFieldKey(), starStr);
        MainI18nInfoVO currMainI18nInfo = fieldPropertyI18nMap.get(itemUUID);
        if(currMainI18nInfo == null) {
            currMainI18nInfo = this.getDefaultLanguageI18nInfo(moduleI18nConf, this.getProperty().getPropertyNameI18ns()[0], null, this.getProperty().getFieldKey(), starStr, tipStr);

//            // 公共字段国际化
//            MainI18nInfoVO publicFieldI18nInfo = publicFieldPropertyI18nMap.get(itemUUID);
//            if(publicFieldI18nInfo != null) {
//                // 将公共字段国际化放入字段
//                Map<String, List<String>> publicFieldI18nMap = publicFieldI18nInfo.getContent();
//                for(Map.Entry<String, List<String>> publicFieldI18nEntry: publicFieldI18nMap.entrySet()) {
//                    List<String> currI18nList = currMainI18nInfo.getContent().get(publicFieldI18nEntry.getKey());
//                    if(CollectionUtils.isEmpty(currI18nList) || StringUtils.isBlank(currI18nList.get(0))) {
//                        currMainI18nInfo.getContent().put(publicFieldI18nEntry.getKey(), publicFieldI18nEntry.getValue());
//                    }
//                }
//            }
        } else {
            currMainI18nInfo.setPropertyCodeName(MessageUtils.get(this.getProperty().getPropertyNameI18ns()[0]));
        }
        mainI18nInfoList.add(currMainI18nInfo);
        return currMainI18nInfo;
    }


    private String getUUID(String fieldKey, String itemValue) {
        return fieldKey +":"+ itemValue;
    }
}
