package com.cloudwise.i18n.support.core.handler.simple;

import com.cloudwise.i18n.support.core.TranslationContext;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
@Component
public final class SimpleDelBatchTranslationHandler extends AbstractDelTranslationHandler<List<String>> {
    @Override
    protected List<String> getMainIdValue(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object[] args = joinPoint.getArgs();
        return (List<String>) args[0];
    }

    @Override
    public String getType() {
        return "simpleDelBatchTranslationHandler";
    }
}
