package com.cloudwise.i18n.support.core.service.impl;

import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloudwise.i18n.support.core.TranslationCache;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.handler.TranslationHandlerManager;
import com.cloudwise.i18n.support.core.service.DosmModuleI18nService;
import com.cloudwise.i18n.support.core.service.IMessageSource;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.LanguageVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.namingconf.service.CloudwiseNamingConfService;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import jodd.util.StringUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Service
public class TranslationI18nServiceImpl implements TranslationI18nService {

    @Autowired
    public DosmModuleI18nService dosmModuleI18nService;

    @Autowired
    AccountUtil accountUtil;

    @Autowired
    TranslationCache translationCache;

    @Autowired
    TranslationHandlerManager translationHandlerManager;
    @Autowired
    IMessageSource messageSource;

    @Override
    public String translation(String language, String moduleCode, String mainId, @Nullable String dataCode,
                              String propertyCode, String content) {

        String redisKey = language + ":" + moduleCode + ":" + mainId + ":" + dataCode + ":" + propertyCode;
        List<DosmModuleI18nEntity> dosmModuleI18ns = null;
        if (translationCache.containsKey(redisKey)) {
            dosmModuleI18ns = translationCache.getCache(redisKey);
        } else {
            dosmModuleI18ns = dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                    .eq(DosmModuleI18nEntity::getModuleCode, moduleCode).eq(DosmModuleI18nEntity::getMainId, mainId)
                    .eq(dataCode != null, DosmModuleI18nEntity::getDataCode, dataCode)
                    .eq(DosmModuleI18nEntity::getPropertyCode, propertyCode)
                    .eq(DosmModuleI18nEntity::getLanguage, language));
            translationCache.add2Cache(redisKey, dosmModuleI18ns);
        }

        return dosmModuleI18ns.stream()
                .filter(dosmModuleI18n -> mainId.equals(dosmModuleI18n.getMainId()) && (dataCode == null || dataCode
                        .equals(dosmModuleI18n.getDataCode())) && propertyCode.equals(dosmModuleI18n.getPropertyCode())
                        && language.equals(dosmModuleI18n.getLanguage())).findFirst()
                .map(DosmModuleI18nEntity::getContent).orElse(content);
    }


    @Override
    public String translation(String language, String[] i18nModuleCodes, String mainId, String dataCode,
                              String propertyCode, String content) {
        List<DosmModuleI18nEntity> dosmModuleI18ns = null;
        for (String i18nModuleCode : i18nModuleCodes) {
            String redisKey =
                    language + ":" + i18nModuleCode + ":" + mainId + ":" + dataCode + ":" + propertyCode;
            if (translationCache.containsKey(redisKey)) {
                dosmModuleI18ns = translationCache.getCache(redisKey);
            } else {
                dosmModuleI18ns = dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                        .in(DosmModuleI18nEntity::getModuleCode, i18nModuleCode)
                        .eq(DosmModuleI18nEntity::getMainId, mainId)
                        .eq(dataCode != null, DosmModuleI18nEntity::getDataCode, dataCode)
                        .eq(DosmModuleI18nEntity::getPropertyCode, propertyCode)
                        .eq(DosmModuleI18nEntity::getLanguage, language));
                translationCache.add2Cache(redisKey, dosmModuleI18ns);
            }
            if (dosmModuleI18ns != null && !dosmModuleI18ns.isEmpty()) {
                break;
            }
        }
        if (dosmModuleI18ns == null || dosmModuleI18ns.isEmpty()) {
            return content;
        }
        return dosmModuleI18ns.stream()
                .filter(dosmModuleI18n -> mainId.equals(dosmModuleI18n.getMainId()) && (dataCode == null || dataCode
                        .equals(dosmModuleI18n.getDataCode())) && propertyCode.equals(dosmModuleI18n.getPropertyCode())
                        && language.equals(dosmModuleI18n.getLanguage())).findFirst()
                .map(DosmModuleI18nEntity::getContent).orElse(content);
    }

    @Override
    public Object getNormalList(I18nReq i18nReq) {
        return translationHandlerManager.getModuleCodeHandler(i18nReq.getModuleCode()).getMainI18nInfo(i18nReq, this.listByI18nReq(i18nReq));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean save(String moduleCode, List<MainI18nInfoVO> mainI18nInfos) {
        Set<String> i18nIds = Sets.newHashSet();
        List<DosmModuleI18nEntity> dosmModuleI18nList = new ArrayList<>();
        //抽出子集，对子集也进行保存
        mainI18nInfos.addAll(getAllChilds(mainI18nInfos));
        for (MainI18nInfoVO mainI18nInfo : mainI18nInfos) {
            Map<String, List<String>> content = mainI18nInfo.getContent();
            List<LanguageVo> lauguageList = getLauguageList();

            for (Map.Entry<String, List<String>> stringListEntry : content.entrySet()) {
                if (stringListEntry.getValue().size() == 2) {
                    i18nIds.add(stringListEntry.getValue().get(1));
                }
            }
            this.converter(moduleCode, mainI18nInfo, dosmModuleI18nList, Sets.newHashSet());
        }
        deleteByIds(Lists.newArrayList(i18nIds));
        refreshRedis(dosmModuleI18nList);
        saveBatch(dosmModuleI18nList);
        return true;
    }

    public List<MainI18nInfoVO> getAllChilds(List<MainI18nInfoVO> results) {
        List<MainI18nInfoVO> allChilds = new ArrayList<>();
        for (MainI18nInfoVO result : results) {
            allChilds.addAll(getChilds(result));
        }
        return allChilds;
    }

    private List<MainI18nInfoVO> getChilds(MainI18nInfoVO mainI18nInfoVOM) {
        List<MainI18nInfoVO> childs = new ArrayList<>();
        if (mainI18nInfoVOM.getChilds() != null) {
            for (MainI18nInfoVO child : mainI18nInfoVOM.getChilds()) {
                childs.add(child);
                childs.addAll(getChilds(child));
            }
        }
        return childs;
    }


    private void deleteByIds(List<String> ids) {
        if (ids.size() > 0) {
            dosmModuleI18nService.removeByIds(ids);
        }
    }


    @Override
    public void deleteByMainIds(List<String> mainIds) {
        if (mainIds == null || mainIds.isEmpty()) {
            return;
        }
        dosmModuleI18nService.remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class).in(DosmModuleI18nEntity::getMainId, mainIds));
    }

    @Override
    public void deleteByI18nReq(I18nReq i18nReq) {
        dosmModuleI18nService.remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, i18nReq.getModuleCode())
                .eq(StrUtil.isNotBlank(i18nReq.getMainId()), DosmModuleI18nEntity::getMainId, i18nReq.getMainId())
                .eq(StrUtil.isNotBlank(i18nReq.getDataCode()), DosmModuleI18nEntity::getDataCode, i18nReq.getDataCode())
                .eq(StrUtil.isNotBlank(i18nReq.getExtCode()), DosmModuleI18nEntity::getExtCode, i18nReq.getExtCode())
                .eq(StrUtil.isNotBlank(i18nReq.getDefaultLanguage()), DosmModuleI18nEntity::getLanguage, i18nReq.getDefaultLanguage())
        );
    }

    @Override
    public List<LanguageVo> getLauguageList() {
        List<LanguageVo> languageList = Lists.newArrayList();
        languageList.add(LanguageVo.builder().label(messageSource.get(807001)).value(Locale.CHINESE.toString()).isDefault(true).build());
        languageList.add(LanguageVo.builder().label(messageSource.get(807002)).value(Locale.ENGLISH.toString()).build());
        return languageList;
    }

    @Override
    public List<String> getMainIdsByContent(String i18nModuleCode, String[] propertyCodes, String content, String queryFieldCode, String applySql) {
        List<String> propertyCodeList = new ArrayList<>();
        for (String propertyCode : propertyCodes) {
            if (StrUtil.isNotBlank(propertyCode)) {
                propertyCodeList.add(propertyCode);
            }
        }
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                        .eq(DosmModuleI18nEntity::getModuleCode, i18nModuleCode)
                        .in(CollectionUtils.isNotEmpty(propertyCodeList), DosmModuleI18nEntity::getPropertyCode, propertyCodeList)
                        .apply(StrUtil.isNotBlank(applySql), applySql, content)
                        .like(StrUtil.isBlank(applySql), DosmModuleI18nEntity::getContent, "%" + content + "%"))
                .stream().map(item -> {
                    //查询item中字段名为queryFieldCode的值
                    return (String) ReflectUtil.getFieldValue(item, queryFieldCode);
                }).collect(Collectors.toList());
    }

    @Override
    public void copy(I18nReq orgI18nReq, I18nReq tarI18nReq) {
        dosmModuleI18nService.copy(orgI18nReq, tarI18nReq);
    }

    @Override
    public void refreshRedis(List<DosmModuleI18nEntity> dosmModuleI18ns) {
        translationCache.removeCache(dosmModuleI18ns);
    }

    @Override
    public List<DosmModuleI18nEntity> listByI18nReq(I18nReq i18nReq) {
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, i18nReq.getModuleCode())
                .eq(StrUtil.isNotBlank(i18nReq.getMainId()), DosmModuleI18nEntity::getMainId, i18nReq.getMainId())
                .eq(StrUtil.isNotBlank(i18nReq.getDataCode()), DosmModuleI18nEntity::getDataCode, i18nReq.getDataCode())
                .eq(StrUtil.isNotBlank(i18nReq.getExtCode()), DosmModuleI18nEntity::getExtCode, i18nReq.getExtCode())
        );
    }

    @Override
    public List<DosmModuleI18nEntity> listByI18nReq4Language(I18nReq i18nReq, String language) {
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, i18nReq.getModuleCode())
                .eq(StrUtil.isNotBlank(i18nReq.getMainId()), DosmModuleI18nEntity::getMainId, i18nReq.getMainId())
                .eq(StrUtil.isNotBlank(i18nReq.getDataCode()), DosmModuleI18nEntity::getDataCode, i18nReq.getDataCode())
                .eq(StrUtil.isNotBlank(i18nReq.getExtCode()), DosmModuleI18nEntity::getExtCode, i18nReq.getExtCode())
                .eq(DosmModuleI18nEntity::getLanguage, language)
        );
    }

    @Override
    public List<DosmModuleI18nEntity> listByI18nReq4Languages(I18nReq i18nReq, List<String> languages) {
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, i18nReq.getModuleCode())
                .eq(StrUtil.isNotBlank(i18nReq.getMainId()), DosmModuleI18nEntity::getMainId, i18nReq.getMainId())
                .eq(StrUtil.isNotBlank(i18nReq.getDataCode()), DosmModuleI18nEntity::getDataCode, i18nReq.getDataCode())
                .eq(StrUtil.isNotBlank(i18nReq.getExtCode()), DosmModuleI18nEntity::getExtCode, i18nReq.getExtCode())
                .in(DosmModuleI18nEntity::getLanguage, languages)
        );
    }

    @Override
    public List<DosmModuleI18nEntity> listByMainId(String mainId, String language) {
        return dosmModuleI18nService
                .list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class).eq(DosmModuleI18nEntity::getMainId, mainId)
                        .eq(DosmModuleI18nEntity::getLanguage, language));
    }

    @Override
    public List<DosmModuleI18nEntity> listByDataCodes(String i18nModuleCode, Collection<String> dataCodes, String language) {
        if (CollectionUtils.isEmpty(dataCodes)) {
            return new ArrayList<>();
        }
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                        .eq(DosmModuleI18nEntity::getModuleCode, i18nModuleCode)
                .and(wq -> {
                    wq.in(DosmModuleI18nEntity::getDataCode, dataCodes);
                    if(dataCodes.contains(null)) {
                        wq.or(wqisNull -> wqisNull.isNull(DosmModuleI18nEntity::getDataCode));
                    }
                })
                .eq(DosmModuleI18nEntity::getLanguage, language));
    }

    @Override
    public List<DosmModuleI18nEntity> listByModuleCodeAndMainId(String i18nModuleCode, String mainId) {
        if (StringUtil.isBlank(mainId)) {
            return new ArrayList<>();
        }
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, i18nModuleCode)
                .eq(DosmModuleI18nEntity::getMainId, mainId));
    }

    @Override
    public List<DosmModuleI18nEntity> listByDataCodesWithCache(String i18nModuleCode, Collection<String> dataCodes, String language) {
        List<DosmModuleI18nEntity> dosmModuleI18nEntities = new ArrayList<>();
        List<String> noCacheDataCodes = new ArrayList<>();
        for (String dataCode : dataCodes) {
            List<DosmModuleI18nEntity> cacheByDataCode = translationCache.getCacheByDataCode(i18nModuleCode, dataCode, language);
            if (cacheByDataCode == null || cacheByDataCode.isEmpty()) {
                noCacheDataCodes.add(dataCode);
            } else {
                dosmModuleI18nEntities.addAll(cacheByDataCode);
            }
        }
        if (CollectionUtils.isNotEmpty(noCacheDataCodes)) {
            List<DosmModuleI18nEntity> moduleI18nEntities = listByDataCodes(i18nModuleCode, noCacheDataCodes, language);
            translationCache.add2Cache(moduleI18nEntities);
            dosmModuleI18nEntities.addAll(moduleI18nEntities);
        }
        return dosmModuleI18nEntities;
    }

    @Override
    public List<DosmModuleI18nEntity> listByMainIds(Collection<String> mainIds, String language) {
        if (CollectionUtils.isEmpty(mainIds)) {
            return new ArrayList<>();
        }
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .in(DosmModuleI18nEntity::getMainId, mainIds)
                .eq(DosmModuleI18nEntity::getLanguage, language));
    }

    @Override
    public List<DosmModuleI18nEntity> listByMainIds(String moduleCode, Collection<String> mainIds) {
        if (CollectionUtils.isEmpty(mainIds)) {
            return new ArrayList<>();
        }
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .in(DosmModuleI18nEntity::getMainId, mainIds)
                .eq(DosmModuleI18nEntity::getModuleCode, moduleCode));
    }

    @Override
    public List<DosmModuleI18nEntity> listByMainIds(Collection<String> mainIds) {
        if (CollectionUtils.isEmpty(mainIds)) {
            return new ArrayList<>();
        }
        return dosmModuleI18nService.list(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .in(DosmModuleI18nEntity::getMainId, mainIds));
    }

    @Override
    public List<DosmModuleI18nEntity> listByMainIdAndDataCodes(String moduleCode, Collection<String> mainIds, Collection<String> dataCodes, String language) {
        if (CollectionUtils.isEmpty(mainIds)) {
            return listByDataCodesWithCache(moduleCode, dataCodes, language);
        }
        if (CollectionUtils.isEmpty(dataCodes)) {
            return listByMainIds(mainIds, language);
        }

        LambdaQueryWrapper<DosmModuleI18nEntity> qw = Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .in(DosmModuleI18nEntity::getMainId, mainIds)
                .and(wq -> {
                    wq.in(DosmModuleI18nEntity::getDataCode, dataCodes);
                    if(dataCodes.contains(null)) {
                        wq.or(wqisNull -> wqisNull.isNull(DosmModuleI18nEntity::getDataCode));
                    }
                })
                .eq(DosmModuleI18nEntity::getLanguage, language);
        return dosmModuleI18nService.list(qw);
    }

    @Override
    public void saveBatch(List<DosmModuleI18nEntity> dosmModuleI18ns) {
        for (DosmModuleI18nEntity dosmModuleI18n : dosmModuleI18ns) {
            dosmModuleI18n.setInsertInfo();
        }
        translationCache.removeCache(dosmModuleI18ns);
        dosmModuleI18nService.saveBatch(dosmModuleI18ns);
    }

    @Override
    public void deleteByMainId(String moduleCode, String mainId, String language) {
        dosmModuleI18nService
                .remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                        .eq(DosmModuleI18nEntity::getModuleCode, moduleCode)
                        .eq(DosmModuleI18nEntity::getMainId, mainId)
                        .eq(DosmModuleI18nEntity::getLanguage, language));
    }

    @Override
    public void deleteByMainId(String moduleCode, String mainId) {
        dosmModuleI18nService
                .remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class).eq(DosmModuleI18nEntity::getModuleCode, moduleCode).eq(DosmModuleI18nEntity::getMainId, mainId));
    }

    @Override
    public void deleteByDataCode(String moduleCode, String dataCode) {
        dosmModuleI18nService
                .remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class).eq(DosmModuleI18nEntity::getModuleCode, moduleCode).eq(DosmModuleI18nEntity::getDataCode, dataCode));
        List<LanguageVo> lauguageList = getLauguageList();
        for (LanguageVo languageVo : lauguageList) {
            translationCache.remove(moduleCode + ":dataCode:" + dataCode + ":" + languageVo.getValue());
        }

    }

    @Override
    public void deleteByMainIds(String moduleCode, List<String> mainIds) {
        if (mainIds == null || mainIds.isEmpty()) {
            return;
        }
        dosmModuleI18nService.remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, moduleCode).in(DosmModuleI18nEntity::getMainId, mainIds));
    }

    @Override
    public void deleteByDataCodes(String moduleCode, List<String> dataCodes) {
        dosmModuleI18nService.remove(Wrappers.lambdaQuery(DosmModuleI18nEntity.class)
                .eq(DosmModuleI18nEntity::getModuleCode, moduleCode).in(DosmModuleI18nEntity::getDataCode, dataCodes));
    }


    @Override
    public void converter(String moduleCode, MainI18nInfoVO mainI18nInfo, List<DosmModuleI18nEntity> dosmModuleI18nList, Set<String> idSet) {
        Map<String, List<String>> contentMap = mainI18nInfo.getContent();
        String mergeContent = null;
        List<DosmModuleI18nEntity> mergeContentIsNullList = Lists.newArrayList();
        List<LanguageVo> lauguageList = getLauguageList();
        List<LanguageVo> noInfo = lauguageList.stream().filter(item -> !contentMap.containsKey(item.getValue())).collect(Collectors.toList());
        for (LanguageVo languageVo : noInfo) {
            contentMap.put(languageVo.getValue(),new ArrayList<>());
        }
        for (Map.Entry<String, List<String>> contentEntry : contentMap.entrySet()) {
            List<String> contentList = contentEntry.getValue();
            if (contentList.size() == 2 && StrUtil.isNotBlank(contentList.get(1))) {
                // 修改数据字典国际化为空
                idSet.add(contentList.get(1));
            }

            DosmModuleI18nEntity entity = DosmModuleI18nEntity.builder()
                    .moduleCode(moduleCode)
                    .mainId(mainI18nInfo.getMainId())
                    .dataCode(mainI18nInfo.getDataCode())
                    .extCode(mainI18nInfo.getExtCode())
                    .propertyCode(mainI18nInfo.getPropertyCode())
                    .language(contentEntry.getKey())
                    .accountId(accountUtil.getAccountId())
                    .topAccountId(accountUtil.getTopAccountId())
                    .createdBy(accountUtil.getUserId())
                    .createdTime(accountUtil.getCurrTime())
                    .build();
            dosmModuleI18nList.add(entity);

            if (CollectionUtils.isEmpty(contentList) || StrUtil.isEmpty(contentList.get(0))) {
                entity.setContent(null);
                mergeContentIsNullList.add(entity);
            } else {
                entity.setContent(mergeContent = contentList.get(0));
                entity.setMergeContent(mergeContent);
            }
        }

        if (mergeContent != null) {
            for (DosmModuleI18nEntity item : mergeContentIsNullList) {
                item.setMergeContent(mergeContent);
            }
        }
    }
}
