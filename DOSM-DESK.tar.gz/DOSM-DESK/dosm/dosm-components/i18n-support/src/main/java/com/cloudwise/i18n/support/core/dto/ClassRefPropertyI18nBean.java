package com.cloudwise.i18n.support.core.dto;

import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.i18n.support.utils.JsonPathUtils;
import com.cloudwise.i18n.support.utils.JsonUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 类属性信息
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClassRefPropertyI18nBean {

    /** 属性父级编码【用于map、json字段code】 */
    private String parentCode;

    private String mainIdCode;

    /** 属性编码【parentCode为空时标识类字段；parentCode为不空时map、json字段中key】 */
    private String propertyCode;

    /** 属性名国际化编码 */
    private Integer propertyNameI18n;

    /** 属性国际化名*/
    private String propertyName;

    /** 属性隐藏条件配置 */
    private PropertyHiddenCondition propertyHiddenCondition;

    /** 类 */
    private Class<?> clazz;

    private Method getMainIdMethod;
    private Method setMainIdMethod;

    private Method getDataCodeMethod;
    private Method setDataCodeMethod;
    private Method getExtCodeMethod;
    private Method setExtCodeMethod;

    /** parentCode 或 propertyCode get方法 */
    private Method getMethod;

    /** parentCode 或 propertyCode set方法 */
    private Method setMethod;

    /**
     * 获取类属性 国际化值
     * @param moduleObj
     * @param propertyHidden
     * @return
     * @param <R>
     */
    public <R> String getContent(R moduleObj, AtomicBoolean propertyHidden) {
        PropertyHiddenCondition propertyHiddenCondition = this.getPropertyHiddenCondition();
        /** 未设置 属性隐藏条件 */
        if(propertyHiddenCondition == null) {
            propertyHidden.set(Boolean.FALSE);
            Object propertyValue = getPropertyValue(moduleObj, this.getParentCode(), this.getPropertyCode(), this.getGetMethod());
            if (propertyValue == null) {
                return null;
            }
            // 注意 强转string会报错，考虑到方案通用性,建议对于不同类型预先处理为string格式。
            return JsonUtils.toJsonString(propertyValue);
        }

        return propertyHiddenCondition.getContent(moduleObj, this, propertyHidden);
    }


    /**
     * 获取属性配置值
     * @param moduleObj
     * @return
     */
    public static <R> Object getPropertyValue(R moduleObj, String parentCode, String propertyCode, Method getMethod) {
        if(StrUtil.isBlank(parentCode)) {
            // 从对象获取配置内容
            return getMethod == null? null: ReflectUtil.invoke(moduleObj, getMethod);
        }

        Object parentCodeValueObj = getMethod == null? null: ReflectUtil.invoke(moduleObj, getMethod);
        if(parentCodeValueObj == null) {
            return null;
        }
        return StrUtil.isBlank(propertyCode)? null: JsonPathUtils.read(JsonUtils.toJsonString(parentCodeValueObj), propertyCode);
    }

}
