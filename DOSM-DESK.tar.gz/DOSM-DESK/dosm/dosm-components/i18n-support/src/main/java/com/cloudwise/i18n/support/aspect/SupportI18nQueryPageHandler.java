package com.cloudwise.i18n.support.aspect;


import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.annotation.SupportI18nQueryPage;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.config.I18nSupportConfig;
import com.cloudwise.i18n.support.core.handler.DefaultTranslationHandler;
import com.cloudwise.i18n.support.core.handler.TranslationHandlerManager;
import com.cloudwise.i18n.support.core.handler.simple.SimpleQueryPageTranslationHandler;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

import static com.cloudwise.i18n.support.core.constant.I18nConstant.SUPPORT_ASPECT_ORDER;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Slf4j
@Aspect
@Component
@Order(SUPPORT_ASPECT_ORDER)
public class SupportI18nQueryPageHandler {
    @Autowired
    TranslationHandlerManager translationHandlerManager;
    @Autowired
    I18nSupportConfig i18nSupportConfig;

    @Pointcut("@annotation(com.cloudwise.i18n.support.annotation.SupportI18nQueryPage)")
    public void i18nPointCut() {
    }

    @Around("i18nPointCut()")
    public Object sendLog(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info("i18nPointCut");
        if (!i18nSupportConfig.getIsSupportI18n()) {
            return joinPoint.proceed();
        }
        return doTranslation(joinPoint);
    }

    private Object doTranslation(ProceedingJoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        SupportI18nQueryPage annotation = AnnotationUtils.findAnnotation(method, SupportI18nQueryPage.class);
        SupportI18n supportI18n = annotation.supportI18n();
        TranslationContext translationContext = new TranslationContext();
        translationContext.setAnnotation(supportI18n);
        if (supportI18n.handlerClass() == DefaultTranslationHandler.class) {
            translationContext.setHandlerClass(SimpleQueryPageTranslationHandler.class);
        }
        translationContext.setArgs(joinPoint.getArgs());
        translationContext.setMethod(method);
        translationContext.setTarget(joinPoint.getTarget());
        translationContext.setJoinPoint(joinPoint);
        return translationHandlerManager.translation(translationContext);
    }
}
