package com.cloudwise.i18n.support.annotation;

import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.handler.DefaultFunction;
import com.cloudwise.i18n.support.core.handler.DefaultTranslationHandler;
import com.cloudwise.i18n.support.core.handler.TranslationHandler;

import java.lang.annotation.*;
import java.util.function.Function;

/**
 * <p>
 * 表示接口是否支持多语言配置
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
@Documented
@Inherited
public @interface SupportI18n {
    /**
     * 是否支持多语言
     *
     * @return
     */
    boolean value() default true;

    /**
     * type和handlerClass必须有一个
     *
     * @return
     */
    String type() default "";

    /**
     * type和handlerClass必须有一个
     *
     * @return
     */
    Class<? extends TranslationHandler> handlerClass() default DefaultTranslationHandler.class;

    String moduleCode() default "";

    String[] mainIdFieldNames() default {I18nConstant.FN_ID};

    boolean isReturnMainIdAfterProceed() default false;


    boolean deleteByDataCode() default false;


    Class<? extends Function<Object,String>> processMainId() default DefaultFunction.class;

    String[] excludePropertyCodeFieldNames() default {};
}
