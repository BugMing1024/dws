package com.cloudwise.i18n.support.utils;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Slf4j
public class JsonPathUtils {

    private static final Configuration configuration = Configuration.defaultConfiguration()
            .addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL)
            ;

    public static String read(String body, String var1) {
        try {
            return getDocumentContext(body).read(var1);
        } catch(Exception e) {
            log.error("JsonPathUtils read error:", e);
        }
        return null;
    }

    public static DocumentContext getDocumentContext(String body) {
        try {
            return JsonPath.using(configuration).parse(body);
        } catch(Exception e) {
            log.error("JsonPathUtils read error:", e);
        }
        return null;
    }

    public static String read(DocumentContext context, String var1) {
        try {
            return context.read(var1);
        } catch(Exception e) {
            log.error("JsonPathUtils read error:", e);
        }
        return null;
    }

}