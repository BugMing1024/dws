package com.cloudwise.i18n.support.core.handler;

import cn.hutool.core.util.ReflectUtil;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;

import java.util.List;
import java.util.Objects;

/**
 * 【扩展】类字段属性关联国际化处理
 * @Author frank.zheng
 * @Date 2023-08-04
 */
public interface IClassRefI18nExtHandler<T> {

    default DosmModuleI18nEntity makeI18nEntity(String language, Object o, ClassRefI18nBean classProperty) {
        DosmModuleI18nEntity nameI18n = new DosmModuleI18nEntity();
        nameI18n.setLanguage(language);
        nameI18n.setModuleCode(classProperty.getI18nModuleCode());
        nameI18n.setMainId((String) ReflectUtil.getFieldValue(o, classProperty.getMainIdCodeFieldName()));
        nameI18n.setDataCode((String) ReflectUtil.getFieldValue(o, classProperty.getDataCodeFieldName()));

        Object extCodeObj = ReflectUtil.getFieldValue(o, classProperty.getExtCodeFieldName());
        nameI18n.setExtCode(Objects.isNull(extCodeObj)? null: extCodeObj.toString());

        return nameI18n;
    }

    /**
     * 保存对象的属性国际化扩展
     * @param language 语言
     * @param obj 保存的对象
     * @param classProperty 属性配置信息
     * @param resultI18nList 最终国际化信息
     * @return
     */
    DosmModuleI18nEntity buildModuleI18n4Save(String language, T obj, ClassRefI18nBean classProperty, List<DosmModuleI18nEntity> resultI18nList);


    /**
     * 获取对象的属性国际化扩展
     * @param obj 保存的对象
     * @param classProperty 属性配置信息
     * @return
     */
    T doTranslation4Query(T obj, ClassRefI18nBean classProperty, List<DosmModuleI18nEntity> dosmModuleI18ns);

}
