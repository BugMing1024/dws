package com.cloudwise.i18n.support.core.convert;

import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;

/**
 * @Author frank.zheng
 * @Date 2023-07-28
 */
public class ModuleI18nConverter {


    public static MainI18nInfoVO entity2vo(DosmModuleI18nEntity entity) {
        return MainI18nInfoVO.builder()
                .moduleCode(entity.getModuleCode())
                .mainId(entity.getMainId())
                .dataCode(entity.getDataCode())
                .extCode(entity.getExtCode())
                .propertyCode(entity.getPropertyCode())
                .build();
    }


    public static DosmModuleI18nEntity vo2Entity(MainI18nInfoVO entity) {
        return DosmModuleI18nEntity.builder()
                .moduleCode(entity.getModuleCode())
                .mainId(entity.getMainId())
                .dataCode(entity.getDataCode())
                .extCode(entity.getExtCode())
                .propertyCode(entity.getPropertyCode())
                .build();
    }

}

