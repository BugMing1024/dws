package com.cloudwise.i18n.support.core.service;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
public interface IMessageSource {

    String get(Integer i18nCode);
}
