package com.cloudwise.i18n.support.annotation;

import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.handler.IClassRefI18nExtHandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface ClassRefI18n {

    /**
     * 存储到多语言表中的propertyCode的值
     *
     * @return
     */
    String propertyCode() default "";
    /**
     * 对应类的属性名
     *
     * @return
     */
    String propertyCodeFieldName();

    String dataCodeFieldName() default "";

    String extCodeFieldName() default "";

    String moduleCode();

    String mainIdFieldName() default I18nConstant.FN_ID;

    /**
     * 如果为true 则会生成mainId，并在新增时设置到mainIdFieldName对应的属性上
     * @return
     */
    boolean isNeedMakeMainId() default true;
    /**
     * 如果为true 则会生成dataCode，并在新增时设置到dataCodeFieldName对应的属性上
     * @return
     */
    boolean isNeedMakeDataCode() default false;



    boolean handleWithJson() default false;


    Class<? extends IClassRefI18nExtHandler> extFun() default IClassRefI18nExtHandler.class;

    /**
     * 该字段控制是否执行 ClassRefI18n 的翻译，配置对象中字段名称
     * 执行逻辑：
     *  如果配置字段名称获取的值，任意一个为空则不执行翻译
     * @return
     */
    String[] notTranslateByFieldNames() default {};

    /**
     * 与 fieldNotTranslate 配合使用
     *  true: notTranslateByFieldNames 配置字段任意为空，则不执行翻译
     *  false: notTranslateByFieldNames 配置字段全部为空，则不执行翻译
     * @return
     */
    boolean notTranslateByFieldAnyBlank() default true;


}
