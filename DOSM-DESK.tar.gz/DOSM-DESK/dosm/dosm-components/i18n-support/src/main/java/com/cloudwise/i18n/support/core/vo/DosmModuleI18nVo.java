package com.cloudwise.i18n.support.core.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DosmModuleI18nVo implements Serializable {
    private String id;
    private String language;
    private String moduleCode;
    private String mainId;
    private String dataCode;
    private String propertyCode;
    private String content;
    private String mergeContent;
}
