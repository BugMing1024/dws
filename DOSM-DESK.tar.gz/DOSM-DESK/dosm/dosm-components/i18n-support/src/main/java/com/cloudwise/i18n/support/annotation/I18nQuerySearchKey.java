package com.cloudwise.i18n.support.annotation;

import com.cloudwise.i18n.support.core.constant.I18nConstant;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/8
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
public @interface I18nQuerySearchKey {

    String moduleCode();

    /**
     * 对应参数内id参数名 或 I18nQueryIds注解修饰变量的 Param注解名称一致
     * 样例一：
     * @SupportI18nQueryList
     * public List<Object> method(
     * @I18nQuerySearchKey(moduleCode = I18nConstant.ModuleCode.M_PROCESS, propertyCode = I18nConstant.ProcessPropertyCode.PROCESS_NAME, mainIdParam = "procMainIds")
     * @Param("proceName") String proceName,
     *
     * @I18nQueryIds List<String> procMainIds
     * )
     *
     *
     * 样例二：
     * @SupportI18nQueryList
     * public List<Object> method(@I18nQueryIds  @Param("procMainIds") List<String> mainIds,
     * @I18nQuerySearchKey(moduleCode = I18nConstant.ModuleCode.M_PROCESS, propertyCode = I18nConstant.ProcessPropertyCode.PROCESS_NAME, mainIdParam = "procMainIds")
     * @Param("proceName") String proceName
     * )
     *
     *
     * 样例三：
     * @SupportI18nQueryList
     * public List<Object> method(@I18nQueryIds  @Param("procMainIds") List<String> mainIds,
     * @I18nQuerySearchKey(moduleCode = I18nConstant.ModuleCode.M_PROCESS, propertyCode = I18nConstant.ProcessPropertyCode.PROCESS_NAME, mainIdParam = "mainIds")
     * @Param("proceName") String proceName
     * )
     */
    String mainIdParam() default I18nConstant.FN_MAIN_IDS;

    String queryFieldCode() default I18nConstant.FN_MAIN_ID;

    String[] propertyCode();

    String applySql() default "";
}
