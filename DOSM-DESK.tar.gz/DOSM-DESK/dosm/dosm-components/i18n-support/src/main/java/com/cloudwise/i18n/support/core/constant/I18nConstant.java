package com.cloudwise.i18n.support.core.constant;

import org.springframework.core.Ordered;

/**
 * @Author frank.zheng
 * @Date 2023-08-02
 */
public interface I18nConstant {

    /** 可以编辑 */
    int DISABLE_0 = 0;
    /** 不可编辑 */
    int DISABLE_1 = 1;

    /** 树形结构数据：非叶子 */
    int LEAF_0 = 0;
    /** 树形结构数据：是叶子 */
    int LEAF_1 = 1;

    int SUPPORT_ASPECT_ORDER = Ordered.LOWEST_PRECEDENCE;

    /** 字段名 */
    String FN_ID = "id";
    String FN_MAIN_ID = "mainId";
    String FN_MAIN_IDS = "mainIds";
    String FN_DATA_CODE = "dataCode";
    String FN_EXT_CODE = "extCode";
    String FN_PROPERTY_CODE = "propertyCode";


    interface ModuleCode {
        /** 自定义页签 */
        String M_TAB = "M_TAB";
        /** 数据字典 */
        String M_DICT = "M_DICT";
        /** 数据字典选项 */
        String M_DICT_DETAIL = "M_DICT_DETAIL";
        /** 按钮管理 */
        String M_BUTTON = "M_BUTTON";
        /** 公共字段 */
        String M_PUBLIC_FIELD = "M_PUBLIC_FIELD";
        /** 流程管理 - 基本设置 */
        String M_PROCESS = "M_PROCESS";
        /** 流程管理 - 表单设计 */
        String M_PROCESS_FORM = "M_PROCESS_FORM";
        /** 流程管理 - 流程设计 */
        String M_PROCESS_BPM = "M_PROCESS_BPM";
        /** 服务级别协议模板 */
        String M_SLA_TEMPLATE = "M_SLA_TEMPLATE";
        /** 流程 - 高级设置 - SLA */
        String M_PROCESS_SLA = "M_PROCESS_SLA";
        /** 流程 - 高级设置 - 表单模板 */
        String M_PROCESS_TEMPLATE = "M_PROCESS_TEMPLATE";
        /** 业务设置全局视图设置 */
        String S_VIEW_NAME_GLOBAL = "S_VIEW_NAME_GLOBAL";
        /** 业务设置变更日历视图设置 */
        String S_CHANGE_VIEW_NAME_GLOBAL = "S_CHANGE_VIEW_NAME_GLOBAL";
        /** 服务目录 */
        String S_SERVICE_CATALOG_TEMPLATE = "S_SERVICE_CATALOG_TEMPLATE";
        String S_SERVICE_CATALOG_ITEM = "S_SERVICE_CATALOG_ITEM";
        String S_SERVICE_CATALOG_DISPLAY = "S_SERVICE_CATALOG_DISPLAY";
        /** 工单列表-列定义 */
        String M_LIST_QUERY_DEF = "M_LIST_QUERY_DEF";
    }


    /** 默认propertyCode */
    interface DefaultPropertyCode {
        /** id */
        String ID = "id";
    }



    /** 按钮管理 */
    interface ButtonPropertyCode {

        /** 按钮名称 */
        String NAME = "name";
        /** 按钮说明 */
        String DESCRIPTION = "description";
        /** 弹窗配置 */
        String ACTION_MODE_CONTENT = "actionModeContent";
        /** 弹窗标题 */
        String POP_UP_TITLE = "popUpTitle";
        /** 弹窗展示文字 */
        String POP_UP_PLACE_CONTENT = "popUpPlaceContent";
        /** 输入框名称 */
        String INPUT_NAME = "inputName";

    }

    /** 自定义页签 */
    interface TabPropertyCode {
        /** 自定义页签名称 */
        String TAB_NAME = "tabName";
    }

    /** 数据字典 */
    interface DictPropertyCode {
        /** 名称 */
        String DICT_NAME = "dictName";
        /** 说明 */
        String CAPTION   = "caption";
    }

    /** 数据字典 */
    interface DictDetailPropertyCode {
        /** 名称 */
        String LABEL = "label";
    }

    /** 公共字段 */
    interface PublicFieldPropertyCode {
        /** 名称 */
        String FIELD_NAME = "fieldName";
    }

    interface ProcessPropertyCode {
        /** 流程名称 */
        String PROCESS_NAME = "processName";
        /** 流程说明 */
        String PROCESS_DESC = "processDesc";
        /** 流程设计xml */
        String PROCESS_XML = "processXml";
    }

    interface FormPropertyCode {
        /** 表单字段集合 */
        String FIELD_LIST = "fieldList";
        /** 表单 schema 详情 */
        String FORM_INFO = "formInfo";
    }


    /** 流程 - 高级设置 - SLA */
    interface ProcessSlaPropertyCode {
        /** sla名称 */
        String NAME = "name";
    }

    /** 流程 - 高级设置 - 表单模板 */
    interface ProcessTemplatePropertyCode {
        /** 名称 */
        String TEMPLETE_NAME = "templeteName";
        /** 说明 */
        String TEMPLETE_DESC = "templeteDesc";
    }

    /** 服务级别协议模板 */
    interface SlaTemplatePropertyCode {
        /** 名称 */
        String NAME = "name";
    }

    /** 业务设置全局视图设置 */
    interface ViewGlobalPropertyCode {
        /** 名称 */
        String VIEW_NAME = "viewName";
    }

    /** 业务设置变更日历视图设置 */
    interface ChangeViewGlobalPropertyCode {
        /** 名称 */
        String VIEW_NAME = "viewName";
    }

    /** 服务目录 */
    interface ServiceCatalogPropertyCode {
        /** 名称 */
        String NAME = "name";
    }

    interface ServiceCatalogItemPropertyCode {
        /**
         * 自定义字段名
         */
        String ITEM_FIELD_VALUE= "fieldLabel";
        String EXTEND_FIELDS= "extendFields";
        /**
         * 服务项名称
         */
        String ITEM_DISPLAY_NAME = "processName";
        /**
         * 服务项描述
         */
        String ITEM_DESC = "processDesc";
    }

    interface ServiceCatalogDisplayPropertyCode {
        /**
         * 字段展示名称
         */
        String FIELD_DISPLAY_NAME = "fieldName";
    }
}
