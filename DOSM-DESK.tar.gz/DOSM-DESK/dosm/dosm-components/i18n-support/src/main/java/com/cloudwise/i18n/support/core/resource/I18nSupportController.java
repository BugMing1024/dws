package com.cloudwise.i18n.support.core.resource;

import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.LanguageVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@RestController
@RequestMapping("/api/v2/i18n")
public class I18nSupportController {
    @Autowired
    TranslationI18nService translationI18nService;

    @ApiOperationSupport(author = "frank.zheng")
    @ApiOperation(value = "获取支持语言", notes = "获取支持语言")
    @GetMapping(value = "/language/list", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<LanguageVo> languageList() {


        return translationI18nService.getLauguageList();
    }

    @PostMapping("/normal/list/{moduleCode}")
    public Object getNormalList(@PathVariable("moduleCode") String moduleCode,
                                @RequestParam(required = false) String mainId,
                                @RequestParam(required = false) String dataCode,
                                @RequestParam(required = false) String extCode) {
        List<LanguageVo> languageList = languageList();
        LanguageVo defaultLanguage = languageList.stream().filter(LanguageVo::getIsDefault).findAny().get();
        return translationI18nService.getNormalList(I18nReq.builder()
                .mainId(mainId)
                .moduleCode(moduleCode)
                .defaultLanguage(defaultLanguage.getValue())
                .languageList(languageList)
                .extCode(extCode)
                .dataCode(dataCode)
                .build()
        );
    }

    @PostMapping("/normal/update/{moduleCode}")
    public Boolean saveNormalList(@PathVariable("moduleCode") String moduleCode, @RequestBody List<MainI18nInfoVO> mainI18nInfos) {
        return translationI18nService.save(moduleCode, mainI18nInfos);
    }
}
