package com.cloudwise.i18n.support.core.classrefi18n;

import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
public interface IClassRefI18nManager {
    void scan();

    List<ClassRefI18nBean> getClassRefI18nBeans(Class clazz);

    void putClassRefI18nBeans(SupportI18n supportI18n, Class clazz, List<ClassRefI18nBean> classRefI18nBeanList);

    List<ClassRefI18nBean> getClassRefI18nBeans(SupportI18n supportI18n, Class clazz);
}
