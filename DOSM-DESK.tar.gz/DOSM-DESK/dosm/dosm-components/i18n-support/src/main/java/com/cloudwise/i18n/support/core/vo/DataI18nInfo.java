package com.cloudwise.i18n.support.core.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DataI18nInfo {
    private String dataCode;
    private String propertyCode;
    private String propertyCodeName;
    private Map<String,String> content;
}
