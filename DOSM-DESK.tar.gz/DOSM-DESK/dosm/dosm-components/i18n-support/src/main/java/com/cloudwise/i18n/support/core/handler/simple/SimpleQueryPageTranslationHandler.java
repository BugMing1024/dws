package com.cloudwise.i18n.support.core.handler.simple;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloudwise.i18n.support.core.TranslationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/3
 */
@Component
public final  class SimpleQueryPageTranslationHandler extends AbstractQueryTranslationHandler<Page> {

    @Autowired
    SimpleQueryListTranslationHandler simpleQueryListTranslationHandler;

    @Override
    public String getType() {
        return "simpleQueryPageTranslationHandler";
    }

    @Override
    public Page doTranslation(Page pageVo, TranslationContext translationContext) {
        List records = pageVo.getRecords();
        records = simpleQueryListTranslationHandler.doTranslation(records, translationContext);
        pageVo.setRecords(records);
        return pageVo;
    }
}
