package com.cloudwise.i18n.support.core.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "多语言设置 - 查询参数")
public class I18nReq {

    @ApiModelProperty(value = "模块编码", example = "M_TAB", required = true)
    private String moduleCode;

    @ApiModelProperty(value = "业务ID", example = "1234s")
    private String mainId;

    /** 数据编码(字段code、字典选项ID) */
    @ApiModelProperty(value = "数据CODE", example = "1234s")
    private String dataCode;

    /** 扩展编码(字段属性编码的父编码、字典选项父ID) */
    @ApiModelProperty(value = "扩展CODE", example = "1234s")
    private String extCode;

    /** 默认语言 */
    @ApiModelProperty(value = "默认语言", example = "zh_CN", hidden = true)
    private String defaultLanguage;

    /** 支持语言集合 */
    @ApiModelProperty(value = "语言集合", example = "[zh_CN]", hidden = true)
    private List<LanguageVo> languageList;

}
