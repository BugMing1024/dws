package com.cloudwise.i18n.support.core.pophandler;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.i18n.support.core.convert.ModuleI18nConverter;
import com.cloudwise.i18n.support.core.dto.ClassRefPropertyI18nBean;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.dto.PropertyHiddenCondition;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.service.IMessageSource;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.I18nSpringContextUtils;
import com.cloudwise.i18n.support.utils.ModuleI18nIdUtils;
import com.cloudwise.i18n.support.utils.StringUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * <ol>
 * <li>流程基本信息转换 管理器
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_PROCESS", "main_id"："流程ID", "data_code"："流程定义ID","property_code": "name:流程名称;流程描述", "content": "国际化"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_PROCESS", "main_id"："流程ID", "data_code"："流程定义ID", "property_code": "name:流程名称;流程描述", "content": {"zh_CN":["国际化", "国际化ID"]}}
 * </ul>
 * <li>数据字典信息转换 管理器
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_DICT", "main_id"："字典ID","property_code": "dictName：名称,caption：说明", "content": "国际化"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_DICT", "main_id"："字典ID", "property_code": "dictName：名称,caption：说明", "content": {"zh_CN":["国际化", "国际化ID"]}}
 * </ul>
 * <li>数据字典选项信息转换 管理器
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_DICT", "main_id"："字典ID", "data_code"："字典项ID", "ext_code": "字典项父ID", "property_code": "label：名称", "content": "国际化"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_DICT", "main_id"："字典ID", "data_code"："字典项ID", "ext_code": "字典项父ID", "property_code": "label：名称", "content": {"zh_CN":["国际化", "国际化ID"]}, "disable": [], "leaf": "0/1", "childs": []}
 * </ul>
 * <li>自定义按钮信息转换 管理器
 * <ul>
 *     <li type="square">
 *     DosmModuleI18nEntity 对象属性说明：{"module_code"："M_BUTTON", "main_id"："按钮ID", "property_code": "name:按钮名称; description：按钮说明; popUpTitle:弹窗标题; popUpPlaceContent:弹窗展示文字; inputName:输入框名称", "content": "国际化值"}
 *     <li type="square">
 *     MainI18nInfoVO 对象属性说明：{"module_code"："M_BUTTON", "main_id"："按钮ID", "property_code": "name:按钮名称; description：按钮说明; popUpTitle:弹窗标题; popUpPlaceContent:弹窗展示文字; inputName:输入框名称", "content": {"zh_CN":["国际化", "国际化ID"]}}
 * </ul>
 * </ol>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
public interface ModuleCodeHandler<R> extends I18nBaseHandler<R> {

    String TYPE = "i18n_list";

    @Override
    default String getType() {
        return TYPE;
    }

    List<R> getModuleDataList(I18nReq i18nReq);

    default List<ClassRefPropertyI18nBean> getPropertyList() {
        return null;
    }

    /**
     * 将数据中的 mainId，dataCode，extCode 放入 DosmModuleI18nConf
     */
    void restModuleI18nConf(DosmModuleI18nConf moduleI18nConf, R moduleObj);

    /**
     * 通过模块数据配置、国际化配置获取最终国际化信息
     *
     * @param i18nReq
     * @param dosmModuleI18ns
     * @return
     */
    default List<MainI18nInfoVO> getMainI18nInfo(I18nReq i18nReq, List<DosmModuleI18nEntity> dosmModuleI18ns) {
        List<R> moduleDataList = getModuleDataList(i18nReq);
        List<MainI18nInfoVO> mainI18nInfoList = Lists.newArrayList();
        if (CollectionUtils.isEmpty(moduleDataList)) {
            return mainI18nInfoList;
        }

        // 获取转行后的国际化配置信息
        Map<String, MainI18nInfoVO> mainI18nInfoMap = this.convert(dosmModuleI18ns);

        DosmModuleI18nConf moduleI18nConf = DosmModuleI18nConf.builder()
                .moduleCode(i18nReq.getModuleCode())
                .mainId(i18nReq.getMainId())
                .dataCode(i18nReq.getDataCode())
                .extCode(i18nReq.getExtCode())
                .defaultLanguage(i18nReq.getDefaultLanguage())
                .languageList(i18nReq.getLanguageList())
                .classPropertyList(getClassPropertyCodeNameMap(moduleDataList.get(0).getClass()))
                .build();

        moduleDataList.forEach(moduleDataObj -> {
            this.restModuleI18nConf(moduleI18nConf, moduleDataObj);
            this.buildModuleI18n4Class(mainI18nInfoMap, moduleDataObj, moduleI18nConf, mainI18nInfoList);
            this.buildModuleI18n4Ext(mainI18nInfoMap, moduleDataObj, moduleI18nConf, mainI18nInfoList);
        });

        return mainI18nInfoList;
    }

    default void buildModuleI18n4Ext(Map<String, MainI18nInfoVO> mainI18nInfoMap, R moduleDataObj, DosmModuleI18nConf moduleI18nConf, List<MainI18nInfoVO> mainI18nInfoList) {
    }


    /**
     * 将数据库中国际化转换为Map，格式：map<moduleCode:mainId:dataCode:propertyCode, MainI18nInfoVO>
     *
     * @param dosmModuleI18ns
     * @return
     */
    default Map<String, MainI18nInfoVO> convert(List<DosmModuleI18nEntity> dosmModuleI18ns) {
        if (CollectionUtils.isEmpty(dosmModuleI18ns)) {
            return Maps.newHashMap();
        }

        Map<String, MainI18nInfoVO> resultMap = Maps.newHashMap();
        dosmModuleI18ns.forEach(item -> {
            String key = ModuleI18nIdUtils.getId(item);
            MainI18nInfoVO mainI18nInfo = resultMap.computeIfAbsent(key, v -> ModuleI18nConverter.entity2vo(item));
            Map<String, List<String>> contentMap = mainI18nInfo.getContent();
            if (contentMap == null) {
                contentMap = Maps.newHashMap();
                mainI18nInfo.setContent(contentMap);
            }

            contentMap.put(item.getLanguage(), Lists.newArrayList(item.getContent(), item.getId()));
        });

        return resultMap;
    }


    /**
     * 缓存作用,格式：Map<language, 类属性信息>
     */
    Map<String, Map<Class<?>, List<ClassRefPropertyI18nBean>>> classPropertyNameI18nMap = Maps.newConcurrentMap();

    /**
     * 获取属性code及国际化名称，格式：Map<属性code, 属性国际化名称>
     */
    default List<ClassRefPropertyI18nBean> getClassPropertyCodeNameMap(Class<?> clazz) {
        if (CollectionUtils.isEmpty(getPropertyList())) {
            return Lists.newArrayList();
        }

        AccountUtil accountUtil = I18nSpringContextUtils.getBean(AccountUtil.class);
        // 获取国际化语言
        String language = accountUtil.getLanguage();
        Map<Class<?>, List<ClassRefPropertyI18nBean>> propertyNameI18nMap = classPropertyNameI18nMap.computeIfAbsent(language, item -> Maps.newConcurrentMap());
        if (MapUtils.isEmpty(propertyNameI18nMap)) {
            return buildClassPropertyBean(clazz, propertyNameI18nMap);
        }

        List<ClassRefPropertyI18nBean> propertyNameList = propertyNameI18nMap.get(clazz);
        if (CollectionUtils.isEmpty(propertyNameList)) {
            return buildClassPropertyBean(clazz, propertyNameI18nMap);
        }

        return propertyNameList;
    }

    /**
     * 构建 类属性 信息
     */
    default List<ClassRefPropertyI18nBean> buildClassPropertyBean(Class<?> clazz, Map<Class<?>, List<ClassRefPropertyI18nBean>> propertyNameI18nMap) {
        Method[] methods = clazz.getMethods();
        Map<String, Method> methodMap = Maps.newHashMap();
        for (Method method : methods) {
            methodMap.put(method.getName(), method);
        }

        List<ClassRefPropertyI18nBean> propertyNameList = Lists.newArrayList();
        getPropertyList().forEach(item -> {
            Method getMethod = null;
            Method setMethod = null;
            Method getMainIdMethod = null;
            Method setMainIdMethod = null;
            if (StrUtil.isBlank(item.getParentCode())) {
                String property = StringUtils.capitalizeFirstLetter(item.getPropertyCode());
                getMethod = methodMap.get("get" + property);
                setMethod = methodMap.get("set" + property);
            } else {
                String property = StringUtils.capitalizeFirstLetter(item.getParentCode());
                getMethod = methodMap.get("get" + property);
                setMethod = methodMap.get("set" + property);
            }

            if (StrUtil.isNotEmpty(item.getMainIdCode())) {
                getMainIdMethod = methodMap.get("get" + StringUtils.capitalizeFirstLetter(item.getMainIdCode()));
                setMainIdMethod = methodMap.get("set" + StringUtils.capitalizeFirstLetter(item.getMainIdCode()));
            } else {
                //默认为getId
                getMainIdMethod = methodMap.get("getId");
                setMainIdMethod = methodMap.get("setId");
            }

            IMessageSource messageSource = I18nSpringContextUtils.getBean(IMessageSource.class);
            // 新建对象，避免并发调用导致对象属性冲突
            ClassRefPropertyI18nBean bean = ClassRefPropertyI18nBean.builder()
                    .parentCode(item.getParentCode())
                    .propertyCode(item.getPropertyCode())
                    .propertyNameI18n(item.getPropertyNameI18n())
                    .propertyName(item.getPropertyNameI18n() == null ? null : messageSource.get(item.getPropertyNameI18n()))
                    .clazz(clazz)
                    .getMethod(getMethod)
                    .getMainIdMethod(getMainIdMethod)
                    .setMainIdMethod(setMainIdMethod)
                    .setMethod(setMethod)
                    .build();
            if (item.getPropertyHiddenCondition() != null) {
                if (StrUtil.isBlank(item.getPropertyHiddenCondition().getMatchParentCode())) {
                    String property = StringUtils.capitalizeFirstLetter(item.getPropertyHiddenCondition().getMatchPropertyCode());
                    getMethod = methodMap.get("get" + property);
                } else {
                    String property = StringUtils.capitalizeFirstLetter(item.getPropertyHiddenCondition().getMatchParentCode());
                    getMethod = methodMap.get("get" + property);
                }

                bean.setPropertyHiddenCondition(PropertyHiddenCondition.builder()
                        .parentCodeNull(item.getPropertyHiddenCondition().getParentCodeNull())
                        .propertyCodeEmpty(item.getPropertyHiddenCondition().getPropertyCodeEmpty())
                        .matchParentCode(item.getPropertyHiddenCondition().getMatchParentCode())
                        .matchPropertyCode(item.getPropertyHiddenCondition().getMatchPropertyCode())
                        .matchValue(item.getPropertyHiddenCondition().getMatchValue())
                        .getMethod(getMethod)
                        .build());
            }

            propertyNameList.add(bean);
        });
        propertyNameI18nMap.put(clazz, propertyNameList);
        return propertyNameList;
    }


}
