package com.cloudwise.i18n.support.utils;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
public interface AccountUtil {

    /**
     * 获取前端设置的语言信息 简写 zh或en
     *
     * @return 语言信息
     */
    String getLanguage();

    /**
     * 获取当前登录用户所属子租户
     *
     * @return 子租户id
     */
    String getAccountId();

    /**
     * 获取当前登录用户所属顶级租户
     *
     * @return 顶级租户id
     */
    String getTopAccountId();

    /**
     * 获取当前登录用户id
     *
     * @return 用户id
     */
    String getUserId();

    /**
     * 获取前端设置的语言信息[包含国家] 全称 zh-CN或en-US
     *
     * @return 语言信息
     */
    String getLanguageFull();

    /**
     * 获取当前时间 一般可以直接返回new Date(), 最好是设置为用户请求时的时间
     *
     * @return 当前时间
     */
    Date getCurrTime();
}
