package com.cloudwise.i18n.support.aspect;


import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.annotation.SupportI18nSave;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.config.I18nSupportConfig;
import com.cloudwise.i18n.support.core.handler.DefaultTranslationHandler;
import com.cloudwise.i18n.support.core.handler.TranslationHandlerManager;
import com.cloudwise.i18n.support.core.handler.simple.SimpleSaveTranslationHandler;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

import static com.cloudwise.i18n.support.core.constant.I18nConstant.SUPPORT_ASPECT_ORDER;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Slf4j
@Aspect
@Component
@Order(SUPPORT_ASPECT_ORDER)
public class SupportI18nSaveHandler {
    @Autowired
    TranslationHandlerManager translationHandlerManager;
    @Autowired
    I18nSupportConfig i18nSupportConfig;

    @Pointcut("@annotation(com.cloudwise.i18n.support.annotation.SupportI18nSave)")
    public void i18nPointCut() {
    }

    @Around("i18nPointCut()")
    public Object translation(ProceedingJoinPoint joinPoint) throws Throwable {
        if (!i18nSupportConfig.getIsSupportI18n()) {
            return joinPoint.proceed();
        }
        return doTranslation(joinPoint);
    }

    private Object doTranslation(ProceedingJoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        SupportI18nSave supportI18nSave = AnnotationUtils.findAnnotation(method, SupportI18nSave.class);
        TranslationContext translationContext = new TranslationContext();
        SupportI18n supportI18n = supportI18nSave.supportI18n();
        translationContext.setAnnotation(supportI18n);
        if (supportI18n.handlerClass() == DefaultTranslationHandler.class) {
            translationContext.setHandlerClass(SimpleSaveTranslationHandler.class);
        }
        translationContext.setArgs(joinPoint.getArgs());
        translationContext.setMethod(method);
        translationContext.setTarget(joinPoint.getTarget());
        translationContext.setJoinPoint(joinPoint);
        return translationHandlerManager.translation(translationContext);
    }
}
