package com.cloudwise.i18n.support.core.handler;

import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.pophandler.ModuleCodeHandler;
import com.cloudwise.i18n.support.core.TranslationContext;

import com.cloudwise.i18n.support.utils.I18nSpringContextUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Component
public class TranslationHandlerManager implements ApplicationContextAware {
    private Map<String, TranslationHandler> translationHandlerMap = new ConcurrentHashMap<>();
    private Map<String, ModuleCodeHandler> moduleCodeModuleCodeHandlerMap = new ConcurrentHashMap<>();

    public TranslationHandler getTranslationHandler(TranslationContext translationContext) {
        SupportI18n annotation = translationContext.getAnnotation();
        if (translationHandlerMap.containsKey(annotation.type())) {
            return translationHandlerMap.get(annotation.type());
        }
        if(translationContext.getHandlerClass()!=null){
            return I18nSpringContextUtils.getBean(translationContext.getHandlerClass());
        }

        Class<? extends TranslationHandler> handlerClass = annotation.handlerClass();
        return I18nSpringContextUtils.getBean(handlerClass);
    }


    public ModuleCodeHandler getModuleCodeHandler(String moduleCode) {
        return moduleCodeModuleCodeHandlerMap.get(moduleCode);
    }


    public Object translation(TranslationContext translationContext) {
        return getTranslationHandler(translationContext).translation(translationContext);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    	I18nSpringContextUtils.setApplicationContext1(applicationContext);
        applicationContext.getBeansOfType(TranslationHandler.class).values().forEach(this::addTranslationHandler);
        applicationContext.getBeansOfType(ModuleCodeHandler.class).values().forEach(this::addModuleCodeHandler);
    }

    private void addModuleCodeHandler(ModuleCodeHandler moduleCodeHandler) {
        moduleCodeModuleCodeHandlerMap.put(moduleCodeHandler.getModuleCode(), moduleCodeHandler);
    }

    private void addTranslationHandler(TranslationHandler translationHandler) {
        translationHandlerMap.put(translationHandler.getType(), translationHandler);

    }
}
