package com.cloudwise.i18n.support.core.handler;

import org.springframework.stereotype.Component;

import java.util.function.Function;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/4
 */
@Component
public class DefaultFunction implements Function<Object,String> {
    @Override
    public String apply(Object o) {
        return (String) o;
    }
}
