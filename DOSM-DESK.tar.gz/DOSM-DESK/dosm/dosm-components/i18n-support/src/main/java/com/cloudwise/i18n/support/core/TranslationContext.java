package com.cloudwise.i18n.support.core;

import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.handler.TranslationHandler;
import lombok.Data;
import org.aspectj.lang.ProceedingJoinPoint;

import java.lang.reflect.Method;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Data
public class TranslationContext {
    private SupportI18n annotation;
    private Object[] args;
    private Method method;
    private Object target;
    private ProceedingJoinPoint joinPoint;
    private Class<? extends TranslationHandler> handlerClass;

}
