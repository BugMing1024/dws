package com.cloudwise.i18n.support.core.dto;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.i18n.support.utils.JsonPathUtils;
import com.cloudwise.i18n.support.utils.JsonUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 属性隐藏条件【默认只要一个条件匹配，则隐藏属性】
 * @Author frank.zheng
 * @Date 2023-08-17
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PropertyHiddenCondition {

    /** 【parentCodeEmpty 为空时不做条件匹配】parentCode 值为 null 时(优先级高于值匹配) */
    private Boolean parentCodeNull = Boolean.FALSE;

    /** 【propertyCodeEmpty 为空时不做条件匹配】propertyCode 值为 null 时(优先级高于值匹配) */
    private Boolean propertyCodeEmpty;



    /** 【与matchValue一起使用】要匹配的属性父级编码【用于map、json字段code】 */
    private String matchParentCode;

    /** 【与matchValue一起使用】要匹配的属性编码【parentCode为空时标识类字段；parentCode为不空时map、json字段中key】 */
    private String matchPropertyCode;

    /** 要匹配的属性值 */
    private Object matchValue;

    /** 要匹配的属性值为空【默认为false】 */
    @Builder.Default
    private Boolean matchValueIsEmpty = Boolean.FALSE;

    /** matchParentCode 或 matchPropertyCode 的 get方法 */
    private Method getMethod;


    /**
     * 获取类属性 国际化值
     * @param moduleObj
     * @param classProperty
     * @param propertyHidden
     * @return
     * @param <R>
     */
    public <R> String getContent(R moduleObj, ClassRefPropertyI18nBean classProperty, AtomicBoolean propertyHidden) {
        if(StrUtil.isBlank(classProperty.getParentCode())) {
            // 从对象获取配置内容
            String content = classProperty.getGetMethod() == null? null: ReflectUtil.invoke(moduleObj, classProperty.getGetMethod());
            if(this.getPropertyCodeEmpty() == null) {
                // 匹配属性值
                propertyHidden.set(isMatchValue(moduleObj));
            } else {
                // 属性值为空则设置属性隐藏
                propertyHidden.set(Boolean.TRUE.equals(this.getPropertyCodeEmpty()) && StrUtil.isEmpty(content));
            }
            return content;
        }

        Object parentCodeValueObj = classProperty.getGetMethod() == null? null: ReflectUtil.invoke(moduleObj, classProperty.getGetMethod());
        if(parentCodeValueObj == null) {
            // 属性父级值为空则设置属性隐藏
            propertyHidden.set(this.getParentCodeNull() == null? Boolean.FALSE: this.getParentCodeNull());
            return null;
        }

        // 从对象获取配置内容
        String content = StrUtil.isBlank(classProperty.getPropertyCode())? null: JsonPathUtils.read(JsonUtils.toJsonString(parentCodeValueObj), classProperty.getPropertyCode());
        // 属性空则设置属性隐藏
        if(this.getPropertyCodeEmpty() == null) {
            propertyHidden.set(isMatchValue(moduleObj));
        } else {
            // 属性值为空则设置属性隐藏
            propertyHidden.set(Boolean.TRUE.equals(this.getPropertyCodeEmpty()) && StrUtil.isEmpty(content));
        }
        return content;
    }

    /**
     * 匹配值逻辑
     */
    private <R> boolean isMatchValue(R moduleObj) {
        if(this.getMatchValue() == null) {
            // 匹配属性的值为空
            return Boolean.TRUE.equals(this.getMatchValueIsEmpty()) && ObjectUtil.isEmpty(ClassRefPropertyI18nBean.getPropertyValue(moduleObj, this.getMatchParentCode(), this.getMatchPropertyCode(), this.getGetMethod()));
        } else {
            // 匹配属性值
            return ObjectUtil.equal(this.getMatchValue(), ClassRefPropertyI18nBean.getPropertyValue(moduleObj, this.getMatchParentCode(), this.getMatchPropertyCode(), this.getGetMethod()));
        }
    }
}
