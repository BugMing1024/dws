package com.cloudwise.i18n.support.core.handler.simple;

import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.ReflectUtil;
import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.classrefi18n.IClassRefI18nManager;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.handler.TranslationHandler;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;

import javax.annotation.Resource;
import java.util.List;
import java.util.function.Function;

/**
 * <p>
 * T 为元对象
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/1
 */
public abstract class AbstractSaveTranslationHandler<T> implements TranslationHandler {
    @Resource
    public TranslationI18nService translationI18nService;
    @Resource
    public AccountUtil accountUtil;

    @Resource
    IClassRefI18nManager classRefI18nManager;

    /**
     * 获取元对象
     * 默认为第一个参数，如果不是第一个参数，请自行处理
     *
     * @param translationContext 翻译上下文
     * @return 元对象
     */
    public T getMetaObject(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object[] args = joinPoint.getArgs();
        if (args.length > 0) {
            return (T) args[0];
        }
        return null;
    }

    public abstract List<DosmModuleI18nEntity> makeI18nEntity(T t, TranslationContext translationContext);


    @Override
    public Object translation(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object proceed = null;
        try {
            T metaObject = getMetaObject(translationContext);
            List<DosmModuleI18nEntity> dosmModuleI18ns = makeI18nEntity(metaObject, translationContext);
            proceed = joinPoint.proceed();
            SupportI18n supportI18n = translationContext.getAnnotation();
            boolean returnMainIdAfterProceed = supportI18n.isReturnMainIdAfterProceed();

            if (returnMainIdAfterProceed) {
                Class<? extends Function<Object, String>> aClass = supportI18n.processMainId();
                Function<Object, String> function = aClass.newInstance();
                for (DosmModuleI18nEntity dosmModuleI18n : dosmModuleI18ns) {
                    dosmModuleI18n.setMainId(function.apply(proceed));
                }
            }
            translationI18nService.saveBatch(dosmModuleI18ns);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
        return proceed;
    }


    protected void makI18nEntity(String language, String mainId, Object obj, List<ClassRefI18nBean> classPropertyList, List<DosmModuleI18nEntity> resultModuleI18ns) {
        for (ClassRefI18nBean classProperty : classPropertyList) {
            DosmModuleI18nEntity nameI18n = this.makeI18nEntity(language, obj, classProperty, resultModuleI18ns);
            if (nameI18n != null) {
                if (classProperty.isNeedMakeMainId()) {
                    ReflectUtil.invoke(obj, "set" + StringUtils.capitalizeFirstLetter(classProperty.getMainIdCodeFieldName()), mainId);
                    nameI18n.setMainId(mainId);
                }
                if (classProperty.isNeedMakeDataCode()) {
                    String dataCode = IdUtil.getSnowflakeNextIdStr();
                    ReflectUtil.invoke(obj, "set" + StringUtils.capitalizeFirstLetter(classProperty.getDataCodeFieldName()), dataCode);
                    nameI18n.setDataCode(dataCode);
                }
            }
        }
    }

}
