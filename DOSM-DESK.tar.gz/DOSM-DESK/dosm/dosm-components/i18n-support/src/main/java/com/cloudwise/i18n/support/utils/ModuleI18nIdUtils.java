package com.cloudwise.i18n.support.utils;

import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;

import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;

/**
 * @Author frank.zheng
 * @Date 2023-07-28
 */
public class ModuleI18nIdUtils {

    public final static String getId(DosmModuleI18nEntity info) {
        return getId(info.getModuleCode(), info.getMainId(), info.getDataCode(), info.getPropertyCode());
    }

    public final static String getId(MainI18nInfoVO info) {
        return getId(info.getModuleCode(), info.getMainId(), info.getDataCode(), info.getPropertyCode());
    }

    public final static String getId(String moduleCodeMainDataId, String propertyCode) {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(moduleCodeMainDataId).append(":").append(propertyCode);
        return strBuilder.toString();
    }

    public final static String getId(String moduleCode, String mainId, String dataId) {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(moduleCode).append(":").append(mainId).append(":").append(dataId);
        return strBuilder.toString();
    }

    public final static String getId(String moduleCode, String mainId, String dataId, String propertyCode) {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(moduleCode).append(":").append(mainId).append(":").append(dataId).append(":").append(propertyCode);
        return strBuilder.toString();
    }
}
