package com.cloudwise.i18n.support.annotation;

import com.cloudwise.i18n.support.core.handler.simple.SimpleUpdateListTranslationHandler;

import java.lang.annotation.*;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
@Documented
public @interface SupportI18nUpdateList {
    SupportI18n supportI18n() default @SupportI18n(handlerClass = SimpleUpdateListTranslationHandler.class);
}
