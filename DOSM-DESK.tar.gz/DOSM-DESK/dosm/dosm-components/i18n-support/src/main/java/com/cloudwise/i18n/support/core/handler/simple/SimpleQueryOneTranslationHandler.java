package com.cloudwise.i18n.support.core.handler.simple;

import cn.hutool.core.collection.CollectionUtil;
import com.cloudwise.i18n.support.cache.TranslationThreadCache;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.classrefi18n.IClassRefI18nManager;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/3
 */
@Component
public final  class SimpleQueryOneTranslationHandler extends AbstractQueryTranslationHandler<Object> {
    @Resource
    IClassRefI18nManager classRefI18nManager;

    @Override
    public String getType() {
        return "simpleQueryOneTranslationHandler";
    }

    @Override
    public Object doTranslation(Object record, TranslationContext translationContext) {
        if (Objects.isNull(record)) {
            //当查询结果为空时，不做处理
            return record;
        }
        List<ClassRefI18nBean> classRefI18nBeans = this.getClassPropertyBySupportI18n(classRefI18nManager, record, translationContext);
        if (CollectionUtil.isEmpty(classRefI18nBeans)) {
            return record;
        }

        for (ClassRefI18nBean classRefI18nBean : classRefI18nBeans) {
            List<DosmModuleI18nEntity> dosmModuleI18ns = TranslationThreadCache.getModuleI18n4UserLanguage(classRefI18nBean, record);
            record = doTranslation(record, dosmModuleI18ns, classRefI18nBean);
        }
        return record;
    }
}
