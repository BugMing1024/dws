package com.cloudwise.i18n.support.cache;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.I18nSpringContextUtils;
import com.cloudwise.i18n.support.utils.StringUtils;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.MapUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * 国际化 缓存
 *
 * @Author frank.zheng
 * @Date 2023-08-07
 */
public class TranslationThreadCache {

    /** 数据格式: Map<语言，Map<模块, Map<唯一id，List<国际化信息>>>> */
    private final static ThreadLocal<Map<String, Map<String, Map<String, List<DosmModuleI18nEntity>>>>> CURR_LANGUAGE_MODULE_I18N_CACHE = new ThreadLocal<>();

    /** 复制操作状态缓存 */
    private final static ThreadLocal<Boolean> COPY_STATUS_CACHE = new ThreadLocal<>();

    private static TranslationI18nService translationI18nService;

    private static AccountUtil accountUtil;

    public static Map<String, List<DosmModuleI18nEntity>> getModuleI18nList(String language, String module) {
        Map<String, Map<String, Map<String, List<DosmModuleI18nEntity>>>> moduleLanguageI18nMap = CURR_LANGUAGE_MODULE_I18N_CACHE.get();
        if (moduleLanguageI18nMap == null) {
            return null;
        }

        Map<String, Map<String, List<DosmModuleI18nEntity>>> moduleI18nMap = moduleLanguageI18nMap.get(language);
        if (moduleI18nMap == null) {
            return null;
        }

        return moduleI18nMap.get(module);
    }

    public static List<DosmModuleI18nEntity> getModuleI18nList(String language, String module, String mainId, String dataCode, String extCode, Supplier<List<DosmModuleI18nEntity>> fun) {
        Map<String, List<DosmModuleI18nEntity>> i18nMap = getModuleI18nList(language, module);
        if (i18nMap == null) {
            return getExtFun(language, module, mainId, dataCode, extCode, fun);
        }

        List<DosmModuleI18nEntity> i18nEntityList = i18nMap.get(getUUID(mainId, dataCode, extCode));
        if (CollectionUtil.isEmpty(i18nEntityList)) {
            return getExtFun(language, module, mainId, dataCode, extCode, fun);
        }
        return i18nEntityList;
    }

    private static List<DosmModuleI18nEntity> getExtFun(String language, String module, String mainId, String dataCode, String extCode, Supplier<List<DosmModuleI18nEntity>> fun) {
        if (fun == null) {
            return null;
        }
        List<DosmModuleI18nEntity> i18nEntityList = fun.get();
        if (CollectionUtil.isNotEmpty(i18nEntityList)) {
            putModuleI18nList(module, mainId, dataCode, extCode, i18nEntityList);
        }
        return i18nEntityList;
    }


    public static void putModuleI18nList(String language, String module, String mainId, String dataCode, String extCode, List<DosmModuleI18nEntity> entityList) {
        if (CollectionUtil.isEmpty(entityList)) {
            return;
        }

        Map<String, Map<String, Map<String, List<DosmModuleI18nEntity>>>> moduleLanguageI18nMap = CURR_LANGUAGE_MODULE_I18N_CACHE.get();
        if (moduleLanguageI18nMap == null) {
            moduleLanguageI18nMap = Maps.newHashMap();
            moduleLanguageI18nMap.computeIfAbsent(language, k -> Maps.newHashMap())
                    .computeIfAbsent(module, k -> Maps.newHashMap())
                    .put(getUUID(mainId, dataCode, extCode), entityList);

            CURR_LANGUAGE_MODULE_I18N_CACHE.set(moduleLanguageI18nMap);
            return;
        }

        Map<String, Map<String, List<DosmModuleI18nEntity>>> moduleI18nMap = moduleLanguageI18nMap.computeIfAbsent(language, k -> Maps.newHashMap());
        if (MapUtils.isEmpty(moduleI18nMap)) {
            moduleI18nMap.computeIfAbsent(module, k -> Maps.newHashMap()).put(getUUID(mainId, dataCode, extCode), entityList);
            return;
        }


        moduleI18nMap.computeIfAbsent(module, k -> Maps.newHashMap()).put(getUUID(mainId, dataCode, extCode), entityList);
    }


    public static Map<String, List<DosmModuleI18nEntity>> getModuleI18nList(String module) {
        AccountUtil accountUtil = getAccountUtil();
        return getModuleI18nList(accountUtil.getLanguage(), module);
    }

    public static List<DosmModuleI18nEntity> getModuleI18nList(String module, String mainId, String dataCode, String extCode, Supplier<List<DosmModuleI18nEntity>> fun) {
        AccountUtil accountUtil = getAccountUtil();
        return getModuleI18nList(accountUtil.getLanguage(), module, mainId, dataCode, extCode, fun);

    }

    public static void putModuleI18nList(String module, String mainId, String dataCode, String extCode, List<DosmModuleI18nEntity> entityList) {
        AccountUtil accountUtil = getAccountUtil();
        putModuleI18nList(accountUtil.getLanguage(), module, mainId, dataCode, extCode, entityList);
    }

    /**
     * 缓存查询数据
     *
     * @param entityList
     * @param setMainIdNull   true时 mainId 为 null
     * @param setDataCodeNull true时 dataCode 为 null
     * @param setExtCodeNull  true时 extCode 为 null
     */
    public static void putModuleI18nList(boolean setMainIdNull, boolean setDataCodeNull, boolean setExtCodeNull, List<DosmModuleI18nEntity> entityList) {
        if (CollectionUtil.isEmpty(entityList)) {
            return;
        }
        Map<String, Map<String, Map<String, List<DosmModuleI18nEntity>>>> currLanguageModuleI18nMap = CURR_LANGUAGE_MODULE_I18N_CACHE.get();
        Map<String, Map<String, Map<String, List<DosmModuleI18nEntity>>>> tmpModuleI18nMap = entityList.stream().collect(Collectors.groupingBy(DosmModuleI18nEntity::getLanguage, Collectors.groupingBy(DosmModuleI18nEntity::getModuleCode, Collectors.groupingBy(item -> getUUID(setMainIdNull ? null : item.getMainId(), setDataCodeNull ? null : item.getDataCode(), setExtCodeNull ? null : item.getExtCode())))));
        if (currLanguageModuleI18nMap == null) {
            CURR_LANGUAGE_MODULE_I18N_CACHE.set(tmpModuleI18nMap);
        } else {
            Set<String> languages = tmpModuleI18nMap.keySet();
            for (String language : languages) {
                Map<String, Map<String, List<DosmModuleI18nEntity>>> stringMapMap = currLanguageModuleI18nMap.get(language);
                if (stringMapMap == null) {
                    stringMapMap = tmpModuleI18nMap.get(language);
                } else {
                    Map<String, Map<String, List<DosmModuleI18nEntity>>> stringMapMap1 =
                            tmpModuleI18nMap.get(language);
                    for (String moduleCode : stringMapMap1.keySet()) {
                        Map<String, List<DosmModuleI18nEntity>> stringListMap = stringMapMap.get(moduleCode);
                        if(stringListMap== null){
                            stringMapMap.put(moduleCode,stringMapMap1.get(moduleCode));
                        }else{
                            stringListMap.putAll(stringMapMap1.get(moduleCode));
                            stringMapMap.put(moduleCode,stringListMap);
                        }
                    }
                }
                currLanguageModuleI18nMap.put(language, stringMapMap);
            }
//            currLanguageModuleI18nMap.putAll(tmpModuleI18nMap);
        }
    }


    /**
     * 通过 moduleCode、mainId、dataCode、extCode 缓存查询用户所在语言环境数据
     */
    public static List<DosmModuleI18nEntity> getModuleI18n4UserLanguage(String module, String mainId, String dataCode, String extCode) {
        return getModuleI18n4UserLanguage(module, mainId, dataCode, extCode, true);
    }

    public static List<DosmModuleI18nEntity> getModuleI18n4UserLanguage(String module, String mainId, String dataCode, String extCode, boolean queryDb) {
        getTranslationI18nService();
        AccountUtil accountUtil = getAccountUtil();
        return TranslationThreadCache.getModuleI18nList(module, mainId, dataCode, extCode,
                () -> {
                    if (queryDb) {
                        I18nReq i18nReq = I18nReq.builder().moduleCode(module).mainId(mainId).dataCode(dataCode).extCode(extCode).build();
                        return translationI18nService.listByI18nReq4Language(i18nReq, accountUtil.getLanguage());
                    } else {
                        return new ArrayList<>();
                    }
                });
    }

    private static AccountUtil getAccountUtil() {
        if (accountUtil == null) {
            accountUtil = I18nSpringContextUtils.getBean(AccountUtil.class);
        }
        return accountUtil;
    }

    /**
     * 通过 i18nReq 缓存查询用户所在语言环境数据
     */
    public static List<DosmModuleI18nEntity> getModuleI18n4UserLanguage(I18nReq i18nReq) {
        getTranslationI18nService();
        AccountUtil accountUtil = getAccountUtil();
        return TranslationThreadCache.getModuleI18nList(i18nReq.getModuleCode(), i18nReq.getMainId(), i18nReq.getDataCode(), i18nReq.getExtCode(),
                () -> translationI18nService.listByI18nReq4Language(i18nReq, accountUtil.getLanguage())
        );
    }

    private static void getTranslationI18nService() {
        if (translationI18nService == null) {
            translationI18nService = I18nSpringContextUtils.getBean(TranslationI18nService.class);
        }
    }

    /**
     * 通过 classProperty 与 record 缓存查询用户所在语言环境数据
     *
     * @param classProperty record 类上配置的属性信息
     * @param record        基础数据
     * @return
     */
    public static List<DosmModuleI18nEntity> getModuleI18n4UserLanguage(ClassRefI18nBean classProperty, Object record) {
        boolean mainIdIsNull = StrUtil.isBlank(classProperty.getMainIdCodeFieldName());
        String methodName_mainId = mainIdIsNull ? null : StringUtils.capitalizeFirstLetter(classProperty.getMainIdCodeFieldName());
        String mainId = mainIdIsNull ? null : ReflectUtil.invoke(record, "get" + methodName_mainId);

        boolean dataCodeIsNull = StrUtil.isBlank(classProperty.getDataCodeFieldName());
        String methodName_dataCode = dataCodeIsNull ? null : StringUtils.capitalizeFirstLetter(classProperty.getDataCodeFieldName());
        String dataCode = dataCodeIsNull ? null : ReflectUtil.invoke(record, "get" + methodName_dataCode);

        boolean extCodeIsNull = StrUtil.isBlank(classProperty.getExtCodeFieldName());
        String methodName_extCode = extCodeIsNull ? null : StringUtils.capitalizeFirstLetter(classProperty.getExtCodeFieldName());
        Object extCodeObj = extCodeIsNull ? null : ReflectUtil.invoke(record, "get" + methodName_extCode);
        String extCode = Objects.isNull(extCodeObj) ? null : extCodeObj.toString();

        return getModuleI18n4UserLanguage(classProperty.getI18nModuleCode(), mainId, dataCode, extCode);
    }

    public static void remove() {
        CURR_LANGUAGE_MODULE_I18N_CACHE.remove();
    }

    public static String getUUID(String mainId, String dataCode, String extCode) {
        return mainId + ":" + dataCode + ":" + extCode;
    }


    /**
     * 获取复制操作状态
     */
    public static boolean getCopyStatus() {
        return Boolean.TRUE.equals(COPY_STATUS_CACHE.get());
    }

    /**
     * 设置复制操作状态为：true
     */
    public static void setCopyStatus() {
        COPY_STATUS_CACHE.set(Boolean.TRUE);
    }

    /**
     * 移除复制操作状态
     */
    public static void removeCopyStatus() {
        COPY_STATUS_CACHE.remove();
    }
}
