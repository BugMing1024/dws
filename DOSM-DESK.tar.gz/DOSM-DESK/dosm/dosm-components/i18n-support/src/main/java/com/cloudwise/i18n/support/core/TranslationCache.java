package com.cloudwise.i18n.support.core;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.cloudwise.cache.utils.RedisUtils;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.j2cache.CacheChannel;
import com.cloudwise.j2cache.CacheObject;

import cn.hutool.core.util.StrUtil;

/**
 * @author moss
 */
@Component
@Scope("singleton")
public class TranslationCache {

	@Resource
	private RedisUtils redisUtil;

	@Resource
	private CacheChannel CacheChannel;

	private static final String region = "dosm:muti_language_record_cache";

	// key结构：moduleCode+:+mainId+:+dataCode:+propertyCode+:+language
	public void add2Cache(String key, List<DosmModuleI18nEntity> value) {

		redisUtil.lSet(key, value, 0, TimeUnit.SECONDS);
	}

	private void add2Cache(DosmModuleI18nEntity value) {
		synchronized (this) {
			if (StrUtil.isNotBlank(value.getDataCode())) {

				redisUtil.lLeftPush(
						value.getModuleCode() + ":dataCode:" + value.getDataCode() + ":" + value.getLanguage(), value);
			}
		}
	}

	public void add2Cache(List<DosmModuleI18nEntity> value) {
		for (DosmModuleI18nEntity dosmModuleI18nEntity : value) {
			add2Cache(dosmModuleI18nEntity);
		}
	}

	public void removeCache(List<DosmModuleI18nEntity> dosmModuleI18nEntities) {
		for (DosmModuleI18nEntity dosmModuleI18nEntity : dosmModuleI18nEntities) {
			removeCache(dosmModuleI18nEntity);
		}
	}

	public void removeCache(DosmModuleI18nEntity dosmModuleI18nEntity) {
		synchronized (this) {
			String fullKey = dosmModuleI18nEntity.getModuleCode() + ":" + dosmModuleI18nEntity.getMainId() + ":"
					+ dosmModuleI18nEntity.getDataCode() + ":" + dosmModuleI18nEntity.getPropertyCode() + ":"
					+ dosmModuleI18nEntity.getLanguage();
			redisUtil.del(fullKey);
			if (StrUtil.isNotBlank(dosmModuleI18nEntity.getDataCode())) {
				redisUtil.del(dosmModuleI18nEntity.getModuleCode() + ":dataCode:" + dosmModuleI18nEntity.getDataCode()
						+ ":" + dosmModuleI18nEntity.getLanguage());

				CacheChannel.evict(region, dosmModuleI18nEntity.getModuleCode() + ":dataCode:"
						+ dosmModuleI18nEntity.getDataCode() + ":" + dosmModuleI18nEntity.getLanguage());
			}
		}
	}

	public List<DosmModuleI18nEntity> getCache(String key) {

		CacheObject object = CacheChannel.get(region, key, (string) -> {

			return redisUtil.lGet(key, 0, -1);

		}, false);

		List<DosmModuleI18nEntity> list = (List<DosmModuleI18nEntity>) object.getValue();

		return list;
	}

	public List<DosmModuleI18nEntity> getCacheByDataCode(String i18nModuleCode, String dataCode, String language) {
		List<DosmModuleI18nEntity> cache = getCache(i18nModuleCode + ":dataCode:" + dataCode + ":" + language);
		return cache;
	}

	public boolean containsKey(String redisKey) {
		return redisUtil.hasKey(redisKey);
	}

	public void remove(String redisKey) {
		redisUtil.del(redisKey);
		CacheChannel.evict(region, redisKey);
	}
}
