package com.cloudwise.i18n.support.core.handler.simple;

import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
@Component
public final  class SimpleUpdateListTranslationHandler extends AbstractUpdateTranslationHandler<List<Object>> {

    @Override
    public List<DosmModuleI18nEntity> makeI18nEntity(List<Object> os, TranslationContext translationContext) {
        List<ClassRefI18nBean> classPropertyList = getClassPropertyBySupportI18n(classRefI18nManager, os.get(0), translationContext);
        List<DosmModuleI18nEntity> dosmModuleI18ns = new ArrayList<>();
        String language = accountUtil.getLanguage();
        for (Object o : os) {
            this.makI18nEntity(language, o, classPropertyList, dosmModuleI18ns);
        }
        return dosmModuleI18ns;
    }


    @Override
    public String getType() {
        return "simpleUpdateTranslationHandler";
    }
}
