package com.cloudwise.i18n.support.core.handler.simple;

import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.classrefi18n.IClassRefI18nManager;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.handler.TranslationHandler;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.utils.AccountUtil;
import org.aspectj.lang.ProceedingJoinPoint;

import javax.annotation.Resource;
import java.util.List;
import java.util.function.Function;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/1
 */
public abstract class AbstractUpdateTranslationHandler<T> implements TranslationHandler {
    @Resource
    public TranslationI18nService translationI18nService;
    @Resource
    public AccountUtil accountUtil;

    @Resource
    IClassRefI18nManager classRefI18nManager;

    /**
     * 获取元对象
     * 默认为第一个参数，如果不是第一个参数，请自行处理
     *
     * @param translationContext 翻译上下文
     * @return 元对象
     */
    public T getMetaObject(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object[] args = joinPoint.getArgs();
        if (args.length > 0) {
            return (T) args[0];
        }
        return null;
    }

    public abstract List<DosmModuleI18nEntity> makeI18nEntity(T t, TranslationContext translationContext);


    @Override
    public Object translation(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object proceed = null;
        try {
            T metaObject = getMetaObject(translationContext);
            List<DosmModuleI18nEntity> dosmModuleI18ns = makeI18nEntity(metaObject, translationContext);
            proceed = joinPoint.proceed();
            SupportI18n supportI18n = translationContext.getAnnotation();
            boolean returnMainIdAfterProceed = supportI18n.isReturnMainIdAfterProceed();
            Class<? extends Function<Object, String>> aClass = supportI18n.processMainId();
            Function<Object, String> function = null;
            if(returnMainIdAfterProceed && aClass!=null) {
                function = aClass.newInstance();
            }

            for (DosmModuleI18nEntity dosmModuleI18n : dosmModuleI18ns) {
                I18nReq i18nReq = I18nReq.builder()
                        .moduleCode(dosmModuleI18n.getModuleCode())
                        .mainId(dosmModuleI18n.getMainId())
                        .dataCode(dosmModuleI18n.getDataCode())
                        .extCode(dosmModuleI18n.getExtCode())
                        .defaultLanguage(dosmModuleI18n.getLanguage())
                        .build();

                if (function!=null) {
                    dosmModuleI18n.setMainId(function.apply(proceed));
                }
                translationI18nService.deleteByI18nReq(i18nReq);
            }
            translationI18nService.saveBatch(dosmModuleI18ns);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
        return proceed;
    }
}
