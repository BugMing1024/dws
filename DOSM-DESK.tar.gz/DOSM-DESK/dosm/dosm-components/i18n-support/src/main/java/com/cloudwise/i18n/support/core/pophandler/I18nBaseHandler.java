package com.cloudwise.i18n.support.core.pophandler;

import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.ClassRefPropertyI18nBean;
import com.cloudwise.i18n.support.core.dto.DosmModuleI18nConf;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;

import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;
import com.cloudwise.i18n.support.utils.ModuleI18nIdUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.MapUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @Author frank.zheng
 * @Date 2023-07-28
 */
public interface I18nBaseHandler<R> {

    String getModuleCode();

    String getType();

    default String getI18nLabel(List<DosmModuleI18nEntity> dosmModuleI18ns, String propertyCode, String defaultLabel) {
        return dosmModuleI18ns.stream().filter(dosmModuleI18n -> propertyCode.equals(dosmModuleI18n.getPropertyCode())).findFirst().map(DosmModuleI18nEntity::getContent).orElse(defaultLabel);
    }
    /**
     * 构建 moduleI18nBaseDTO 对象对应的国际化信息
     * @param moduleObj 只能为单独的类对象【不能为数组】
     */
    default List<MainI18nInfoVO> buildModuleI18n4Class(Map<String, MainI18nInfoVO> mainI18nInfoMap, R moduleObj, DosmModuleI18nConf moduleI18nConf, List<MainI18nInfoVO> mainI18nInfoList) {
        // 原数据如果为空则直接返回
        if(moduleObj == null) {
            return mainI18nInfoList;
        }

        if(MapUtils.isEmpty(mainI18nInfoMap)) {
            // 数据库中国际化为空，则直接将对象配置信息放入默认语言
            return buildModuleI18n4Class(mainI18nInfoList, moduleObj, moduleI18nConf);
        }

        for(ClassRefPropertyI18nBean classProperty: moduleI18nConf.getClassPropertyList()) {
            MainI18nInfoVO mainI18nInfo = mainI18nInfoMap.get(ModuleI18nIdUtils.getId(moduleI18nConf.getId(), classProperty.getPropertyCode()));
            if(mainI18nInfo == null) {
                // 数据库中国际化为空，则直接将对象配置信息放入默认语言
                buildModuleI18n4Class(mainI18nInfoList, moduleObj, moduleI18nConf, classProperty);
                continue;
            }
            // 设置是否可以编辑
            setDisable(moduleObj, moduleI18nConf, mainI18nInfo);
            mainI18nInfo.setPropertyCodeName(classProperty.getPropertyName());
            mainI18nInfoList.add(mainI18nInfo);
            this.buildModuleI18n4ClassExtProperty(moduleI18nConf, moduleObj, mainI18nInfo);
        }

        return mainI18nInfoList;
    }


    /**
     * 数据库中国际化为空，则直接将对象配置信息放入默认语言
     */
    default List<MainI18nInfoVO> buildModuleI18n4Class(List<MainI18nInfoVO> mainI18nInfoList, R moduleObj, DosmModuleI18nConf moduleI18nConf) {
        for(ClassRefPropertyI18nBean classProperty: moduleI18nConf.getClassPropertyList()) {
            buildModuleI18n4Class(mainI18nInfoList, moduleObj, moduleI18nConf, classProperty);
        }
        return mainI18nInfoList;
    }


    /**
     * 数据库中国际化为空，则直接将对象配置信息放入默认语言
     */
    default void buildModuleI18n4Class(List<MainI18nInfoVO> mainI18nInfoList, R moduleObj, DosmModuleI18nConf moduleI18nConf, ClassRefPropertyI18nBean classProperty) {
        AtomicBoolean propertyHidden = new AtomicBoolean(Boolean.FALSE);
        // 字段配置值
        String defaultContent = classProperty.getContent(moduleObj, propertyHidden);
        if(Boolean.TRUE.equals(propertyHidden.get())) {
            return;
        }

        Map<String, List<String>> contentMap = Maps.newHashMap();
        // 设置默认语言值【模块对象中获取属性值】
        contentMap.put(moduleI18nConf.getDefaultLanguage(), Lists.newArrayList(defaultContent));

        MainI18nInfoVO mainI18nInfo = MainI18nInfoVO.builder()
                .moduleCode(moduleI18nConf.getModuleCode())
                .mainId(moduleI18nConf.getMainId())
                .dataCode(moduleI18nConf.getDataCode())
                .extCode(moduleI18nConf.getExtCode())
                .propertyCode(classProperty.getPropertyCode())
                .propertyCodeName(classProperty.getPropertyName())
                .content(contentMap)
                .build();
        mainI18nInfoList.add(mainI18nInfo);

        // 设置是否可以编辑
        setDisable(moduleObj, moduleI18nConf, mainI18nInfo);

        this.buildModuleI18n4ClassExtProperty(moduleI18nConf, moduleObj, mainI18nInfo);
    }


    /**
     * @description: 设置是否可以编辑
     * @date: 2023/8/17 3:03 下午
     * @param: [moduleObj, moduleI18nConf, mainI18nInfo]
     * @return: void
     **/
    default void setDisable(R moduleObj, DosmModuleI18nConf moduleI18nConf, MainI18nInfoVO mainI18nInfo) {
        if(this.isDisable(moduleObj)) {
            List<Integer> disableList = Lists.newArrayList();
            moduleI18nConf.getLanguageList().forEach(item -> disableList.add(I18nConstant.DISABLE_1));
            mainI18nInfo.setDisables(disableList);
        }
    }


    /**
     * 将扩展属性放入 MainI18nInfoVO
     */
    default void buildModuleI18n4ClassExtProperty(DosmModuleI18nConf moduleI18nConf, R moduleObj, MainI18nInfoVO mainI18nInfo){

    }

    default boolean isDisable(R moduleObj) {
        return false;
    }

}
