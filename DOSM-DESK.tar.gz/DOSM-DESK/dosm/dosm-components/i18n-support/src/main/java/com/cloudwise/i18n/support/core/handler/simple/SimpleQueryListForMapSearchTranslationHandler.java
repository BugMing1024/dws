package com.cloudwise.i18n.support.core.handler.simple;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.i18n.support.cache.TranslationThreadCache;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.classrefi18n.IClassRefI18nManager;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.google.common.collect.Sets;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/3
 */
@Component
public final class SimpleQueryListForMapSearchTranslationHandler extends AbstractQueryForMapSearchTranslationHandler<List> {
    @Resource
    IClassRefI18nManager classRefI18nManager;

    @Resource
    TranslationI18nService translationI18nService;

    @Override
    public String getType() {
        return "simpleQueryListForMapSearchTranslationHandler";
    }

    @Override
    public List doTranslation(List list, TranslationContext translationContext) {
        if (CollectionUtil.isEmpty(list)) {
            return list;
        }

        List<ClassRefI18nBean> classRefI18nBeans = this.getClassPropertyBySupportI18n(classRefI18nManager, list.get(0), translationContext);
        if (CollectionUtil.isEmpty(classRefI18nBeans)) {
            return list;
        }


        String tmpModuleCode = null;
        for (ClassRefI18nBean classRefI18nBean: classRefI18nBeans) {
            if(StrUtil.equals(classRefI18nBean.getI18nModuleCode(), tmpModuleCode)) {
                continue;
            }
            tmpModuleCode = classRefI18nBean.getI18nModuleCode();
            preCacheByClassRefI18n(list, classRefI18nBean);
        }

        for (int i = 0; i < list.size(); i++) {
            Object record = list.get(i);
            for (ClassRefI18nBean classRefI18nBean : classRefI18nBeans) {
                if(isNotTranslate(record, classRefI18nBean)) {
                    continue;
                }

                String mainId = classRefI18nBean.getMainIdIsNull() ? null : ReflectUtil.invoke(record, "get" + classRefI18nBean.getMethodName_mainId());
                String dataCode = classRefI18nBean.getDataCodeIsNull() ? null : ReflectUtil.invoke(record, "get" + classRefI18nBean.getMethodName_dataCode());
                Object extCodeObj = classRefI18nBean.getExtCodeIsNull() ? null : ReflectUtil.invoke(record, "get" + classRefI18nBean.getMethodName_extCode());
                String extCode = Objects.isNull(extCodeObj) ? null : extCodeObj.toString();

                List<DosmModuleI18nEntity> dosmModuleI18nEntities = TranslationThreadCache.getModuleI18n4UserLanguage(classRefI18nBean.getI18nModuleCode(), mainId, dataCode, extCode);
                record = doTranslation(record, dosmModuleI18nEntities, classRefI18nBean);
                if (classRefI18nBean.isHandleWithJson()) {
                    list.set(i, record);
                }
            }
        }

        return list;
    }

    private void preCacheByClassRefI18n(List list, ClassRefI18nBean classProperty) {
        Set<String> maindIds = Sets.newHashSet();
        Set<String> dataCodes = Sets.newHashSet();
        for (Object record: list) {
            if(isNotTranslate(record, classProperty)) {
                continue;
            }

            if (Boolean.FALSE.equals(classProperty.getMainIdIsNull())) {
                String mainId = ReflectUtil.invoke(record, "get" + classProperty.getMethodName_mainId());
                maindIds.add(mainId);
            }
            if (Boolean.FALSE.equals(classProperty.getDataCodeIsNull())) {
                String dataCode = ReflectUtil.invoke(record, "get" + classProperty.getMethodName_dataCode());
                dataCodes.add(dataCode);
            }
        }

        TranslationThreadCache.putModuleI18nList(classProperty.getMainIdIsNull(), classProperty.getDataCodeIsNull(), classProperty.getExtCodeIsNull(), translationI18nService.listByMainIdAndDataCodes(classProperty.getI18nModuleCode(), maindIds, dataCodes, accountUtil.getLanguage()));
    }


    private boolean isNotTranslate(Object record, ClassRefI18nBean classProperty) {
        if(classProperty.getNotTranslateByFieldNamesIsEmpty()) {
            return false;
        }

        boolean isAllBlank = true;
        for(String methodName: classProperty.getMethodName_notTranslateByFieldNames()) {
            Object value = ReflectUtil.invoke(record, "get" + methodName);
            boolean isBlank = false;
            if(value instanceof String) {
                isBlank = StrUtil.isBlank((String) value);
            } else {
                isBlank = ObjectUtil.isEmpty(value);
            }
            if(isBlank && classProperty.getNotTranslateByFieldAnyBlank()) {
                return true;
            }

            if(!isBlank) {
                isAllBlank = false;
            }
        }

        return isAllBlank;
    }
}
