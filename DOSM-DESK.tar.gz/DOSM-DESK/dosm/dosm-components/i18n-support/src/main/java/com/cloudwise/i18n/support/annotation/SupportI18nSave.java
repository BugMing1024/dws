package com.cloudwise.i18n.support.annotation;

import com.cloudwise.i18n.support.core.handler.simple.SimpleSaveTranslationHandler;

import java.lang.annotation.*;

/**
 * <p>
 * 表示接口是否支持多语言配置
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
@Documented
public @interface SupportI18nSave {
    SupportI18n supportI18n() default @SupportI18n(handlerClass = SimpleSaveTranslationHandler.class);

}
