package com.cloudwise.i18n.support.core.dto;

import com.cloudwise.i18n.support.utils.ModuleI18nIdUtils;

import com.cloudwise.i18n.support.core.vo.LanguageVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 模块国际化配置信息
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DosmModuleI18nConf {

    /** 模块唯一code */
    private String moduleCode;

    /** 主业务数据ID(流程ID、数据字典ID等) */
    private String mainId;

    /** 数据编码(字段code、字典选项ID) */
    private String dataCode;

    /** 扩展编码(字段属性编码的父编码、字典选项父ID) */
    private String extCode;

    /** 默认语言 */
    private String defaultLanguage;

    /** 系统语言信息 */
    private List<LanguageVo> languageList;

    /** 类属性信息 */
    private List<ClassRefPropertyI18nBean> classPropertyList;

    public String getId() {
        return ModuleI18nIdUtils.getId(this.moduleCode, this.mainId, this.dataCode);
    }
}
