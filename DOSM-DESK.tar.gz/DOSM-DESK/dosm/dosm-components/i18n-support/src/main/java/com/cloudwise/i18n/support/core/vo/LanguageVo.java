package com.cloudwise.i18n.support.core.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 语言信息
 * @Author frank.zheng
 * @Date 2023-07-27
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LanguageVo {

    /** 语言名称 */
    private String  label;

    /** 语言枚举值: zh_CN、en_US */
    private String  value;

    /** 是否默认语言 */
    @Builder.Default
    private Boolean isDefault = false;
}
