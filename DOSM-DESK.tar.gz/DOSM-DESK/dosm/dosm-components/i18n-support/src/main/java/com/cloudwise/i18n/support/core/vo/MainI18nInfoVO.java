package com.cloudwise.i18n.support.core.vo;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MainI18nInfoVO {

    /**
     * 模块CODE
     */
    private String moduleCode;
    /**
     * 业务主ID
     */
    private String mainId;
    /**
     * 数据编码
     */
    private String dataCode;

    /**
     * 扩展code;
     * 表单字段：【attr:属性【固定名称】，dataSource:自定义数据字典【固定名称】，fieldHint:文本提示【固定名称】】
     */
    private String extCode;

    /**
     * 数据编码
     */
    private String propertyCode;

    /**
     * 属性名称【国际化翻译后的值】
     */
    private String propertyCodeName;

    /**
     * 国际化信息，格式：map<国际化编码, [国际化值， 国际化ID]>
     */
    private Map<String, List<String>> content;
    /**
     * 1、国际化弹窗输入框类型 （Constants.TYPE_TEXT） 默认为1,【1：普通文本  ，2：富文本】
     * 2、自定义数据字典时值为：dataSource
     */
    private String type;

    /** 是否不可编辑, 数据格式：[语言1编辑状态，语言2编辑状态]: 0: 可以编辑，1：不可编辑 */
    private List<Integer> disables;

    /**
     * 叶子：0: 非叶子，1：叶子
     */
    private Integer leaf;
    /**
     * 子集
     */
    @JsonProperty
    private List<MainI18nInfoVO> childs;

    public int compareTo(MainI18nInfoVO o2) {
        return this.getPropertyCode().compareTo(o2.getPropertyCode());
    }
}