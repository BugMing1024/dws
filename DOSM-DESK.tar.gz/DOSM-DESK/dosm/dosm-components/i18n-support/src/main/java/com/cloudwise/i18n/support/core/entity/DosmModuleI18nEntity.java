package com.cloudwise.i18n.support.core.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.I18nSpringContextUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TableName(value = "dosm_module_i18n", autoResultMap = true)
public class DosmModuleI18nEntity implements Serializable, Cloneable {

    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 语言(en_US:英文，zh_CN:简体中文,zh_TW:繁体中文)
     */
    private String language;
    /**
     * 模块唯一code
     */
    private String moduleCode;
    /**
     * 主业务数据ID(流程ID、数据字典ID等)
     */
    private String mainId;
    /**
     * 数据编码(字段code、字典选项ID)
     */
    private String dataCode;
    /**
     * 扩展编码(字段属性编码的父编码、字典选项父ID)
     */
    private String extCode;
    /**
     * 属性编码(字段的单位、描述等)
     */
    private String propertyCode;
    /**
     * 国际化内容
     */
    private String content;
    /**
     * 合并后的国际化内容
     */
    private String mergeContent;

    private Integer revision;

    private Integer isDel;
    private String createdBy;
    private Date createdTime;

    private String updatedBy;
    private Date updatedTime;
    private String accountId;
    private String topAccountId;

    public void setInsertInfo() {
        AccountUtil accountUtil = I18nSpringContextUtils.getBean(AccountUtil.class);
        this.createdBy = accountUtil.getUserId();
        this.createdTime = new Date();
        this.updatedBy = accountUtil.getUserId();
        this.updatedTime = new Date();
        this.setAccountId(accountUtil.getAccountId());
        this.setTopAccountId(accountUtil.getTopAccountId());
    }
}
