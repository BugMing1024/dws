package com.cloudwise.i18n.support.core.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;

import com.cloudwise.i18n.support.core.vo.I18nReq;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
public interface DosmModuleI18nService extends IService<DosmModuleI18nEntity> {

    /**
     * 合并不同国际化 content 到 merge_content 字段
     */
    long merge(String moduleCode, String mainId);


    /**
     * 复制国际化配置
     */
    long copy(I18nReq orgI18nReq, I18nReq tarI18nReq);
}
