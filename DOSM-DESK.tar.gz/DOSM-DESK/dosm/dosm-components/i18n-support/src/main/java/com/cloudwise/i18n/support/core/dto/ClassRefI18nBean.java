package com.cloudwise.i18n.support.core.dto;


import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.cloudwise.i18n.support.core.handler.IClassRefI18nExtHandler;
import com.cloudwise.i18n.support.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 类属性信息
 *
 * @Author frank.zheng
 * @Date 2023-07-28
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClassRefI18nBean {

    /**
     * 实体里标识dataCode的字段名
     */
    private String dataCodeFieldName;
    /**
     * 实体里标识mainId的字段名
     */
    private String mainIdCodeFieldName;
    /**
     * 设置是否需要生成mainId
     */
    private boolean isNeedMakeMainId = true;
    /**
     * 设置是否需要生成dataCode
     *  当id为dataCode且需要设置源数据主键时设置为true
     */
    private boolean isNeedMakeDataCode = false;

    /**
     * 属性编码【parentCode为空时标识类字段；parentCode为不空时map、json字段中key】
     */
    private String propertyCode;
    /**
     * 实体里标识propertyCode的字段名
     */
    private String propertyCodeFieldName;

    /**
     * 类
     */
    private Class<?> clazz;
    /**
     * 实体里标识extCode的字段名
     */
    private String extCodeFieldName;

    private String i18nModuleCode;
    /**
     * 为true时 按照json的处理方式
     */
    private boolean handleWithJson;

    /** 字段的扩展国际化处理 */
    private Class<? extends IClassRefI18nExtHandler> extFun;


    /**
     * 该字段控制是否执行 ClassRefI18n 的翻译，配置对象中字段名称
     * 执行逻辑：
     *  如果配置字段名称获取的值，任意一个为空则不执行翻译
     */
    private List<String> notTranslateByFieldNames;

    /**
     * 与 fieldNotTranslate 配合使用
     *  true: notTranslateByFieldNames 配置字段任意为空，则不执行翻译
     *  false: notTranslateByFieldNames 配置字段全部为空，则不执行翻译
     * @return
     */
    private Boolean notTranslateByFieldAnyBlank = Boolean.TRUE;


    private Boolean mainIdIsNull = Boolean.TRUE;
    private Boolean dataCodeIsNull = Boolean.TRUE;
    private Boolean extCodeIsNull = Boolean.TRUE;
    private Boolean notTranslateByFieldNamesIsEmpty = Boolean.TRUE;

    private String methodName_mainId;
    private String methodName_dataCode;
    private String methodName_extCode;
    private List<String> methodName_notTranslateByFieldNames;

    public void setMainIdCodeFieldName(String mainIdCodeFieldName) {
        this.mainIdCodeFieldName = mainIdCodeFieldName;
        this.mainIdIsNull = StrUtil.isBlank(this.mainIdCodeFieldName);
        this.methodName_mainId = StringUtils.capitalizeFirstLetter(this.mainIdCodeFieldName);
    }

    public void setDataCodeFieldName(String dataCodeFieldName) {
        this.dataCodeFieldName = dataCodeFieldName;
        this.dataCodeIsNull = StrUtil.isBlank(this.dataCodeFieldName);
        this.methodName_dataCode = StringUtils.capitalizeFirstLetter(this.dataCodeFieldName);
    }

    public void setExtCodeFieldName(String extCodeFieldName) {
        this.extCodeFieldName = extCodeFieldName;
        this.extCodeIsNull = StrUtil.isBlank(this.extCodeFieldName);
        this.methodName_extCode = StringUtils.capitalizeFirstLetter(this.extCodeFieldName);
    }

    public void setNotTranslateByFieldNames(String[] notTranslateByFieldNames) {
        if(notTranslateByFieldNames == null || notTranslateByFieldNames.length == 0 || StrUtil.isBlank(notTranslateByFieldNames[0])) {
            this.notTranslateByFieldNames = null;
            this.notTranslateByFieldNamesIsEmpty = Boolean.TRUE;
            this.methodName_notTranslateByFieldNames = null;
            return;
        }

        this.notTranslateByFieldNames = Lists.newArrayList(notTranslateByFieldNames);
        this.notTranslateByFieldNamesIsEmpty = Boolean.FALSE;
        this.methodName_notTranslateByFieldNames = this.notTranslateByFieldNames.stream().map(item -> StringUtils.capitalizeFirstLetter(item)).collect(Collectors.toList());
    }


}
