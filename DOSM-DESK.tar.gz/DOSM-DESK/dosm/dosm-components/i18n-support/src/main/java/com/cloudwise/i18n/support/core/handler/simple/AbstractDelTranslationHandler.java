package com.cloudwise.i18n.support.core.handler.simple;

import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.handler.TranslationHandler;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import org.aspectj.lang.ProceedingJoinPoint;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
public abstract class AbstractDelTranslationHandler<M> implements TranslationHandler {
    @Resource
    TranslationI18nService translationI18nService;

    @Override
    public Object translation(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        Object proceed = null;
        try {
            proceed = joinPoint.proceed();
            M mainId = getMainIdValue(translationContext);
            SupportI18n supportI18n = translationContext.getAnnotation();
            if(supportI18n.deleteByDataCode()){
                if (mainId instanceof String) {
                    translationI18nService.deleteByDataCode(supportI18n.moduleCode(),(String) mainId);
                } else if (mainId instanceof List) {
                    translationI18nService.deleteByDataCodes(supportI18n.moduleCode(),(List<String>) mainId);
                }
            }else {
                if (mainId instanceof String) {
                    translationI18nService.deleteByMainId(supportI18n.moduleCode(),(String) mainId);
                } else if (mainId instanceof List) {
                    translationI18nService.deleteByMainIds(supportI18n.moduleCode(),(List<String>) mainId);
                }
            }
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }

        return proceed;
    }

    protected abstract M getMainIdValue(TranslationContext translationContext);
}
