package com.cloudwise.i18n.support.core.classrefi18n;

import cn.hutool.core.annotation.AnnotationUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.i18n.support.annotation.ClassRefI18n;
import com.cloudwise.i18n.support.annotation.ClassRefI18ns;
import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.config.I18nSupportConfig;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.handler.IClassRefI18nExtHandler;
import com.cloudwise.i18n.support.utils.DosmI18nReflections;
import com.google.common.collect.Maps;
import io.github.classgraph.ClassGraph;
import io.github.classgraph.ClassInfo;
import io.github.classgraph.ClassInfoList;
import io.github.classgraph.ScanResult;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.ehcache.impl.internal.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
@Component
public class ClassRefI18nManager implements IClassRefI18nManager {
    private static final Map<Class, List<ClassRefI18nBean>> CLASS_REF_I18N_BEAN_MAP = new ConcurrentHashMap<>();

    private static final Map<Class, Map<SupportI18n, List<ClassRefI18nBean>>> SUPPORT_I18N_CLASS_REF_I18N_BEAN_MAP = new ConcurrentHashMap<>();
    @Autowired
    private I18nSupportConfig i18nSupportConfig;
    @Autowired
    private DosmI18nReflections dosmI18nReflections;

    /**
     * 1.扫描所有类找出注解为ClassRefI18ns的类
     * 2.将类的属性和注解的属性对应起来
     * 3.将类和属性的对应关系放入CLASS_REF_I18N_BEAN_MAP
     */
    @PostConstruct
    @Override
    public void scan() {
        Set<Class<?>> typesAnnotatedWith = dosmI18nReflections.getTypesAnnotatedWith(ClassRefI18ns.class);
        for (Class<?> classInfo : typesAnnotatedWith) {
            ClassRefI18ns classRefI18ns = AnnotationUtil.getAnnotation(classInfo, ClassRefI18ns.class);
            List<ClassRefI18nBean> classPropertyCodeNameList = new ArrayList<>();
            for (ClassRefI18n classRefI18n : classRefI18ns.value()) {
                ClassRefI18nBean classRefPropertyI18nBean = new ClassRefI18nBean();
                classRefPropertyI18nBean.setClazz(classInfo);
                if (StrUtil.isBlank(classRefI18n.propertyCode())) {
                    classRefPropertyI18nBean.setPropertyCode(classRefI18n.propertyCodeFieldName());
                } else {
                    classRefPropertyI18nBean.setPropertyCode(classRefI18n.propertyCode());
                }
                classRefPropertyI18nBean.setPropertyCodeFieldName(classRefI18n.propertyCodeFieldName());
                classRefPropertyI18nBean.setDataCodeFieldName(classRefI18n.dataCodeFieldName());
                classRefPropertyI18nBean.setExtCodeFieldName(classRefI18n.extCodeFieldName());
                classRefPropertyI18nBean.setI18nModuleCode(classRefI18n.moduleCode());
                classRefPropertyI18nBean.setMainIdCodeFieldName(classRefI18n.mainIdFieldName());
                classRefPropertyI18nBean.setNeedMakeMainId(classRefI18n.isNeedMakeMainId());
                classRefPropertyI18nBean.setNeedMakeDataCode(classRefI18n.isNeedMakeDataCode());
                classRefPropertyI18nBean.setHandleWithJson(classRefI18n.handleWithJson());
                classRefPropertyI18nBean.setExtFun(classRefI18n.extFun() == IClassRefI18nExtHandler.class ? null : classRefI18n.extFun());
                classRefPropertyI18nBean.setNotTranslateByFieldNames(classRefI18n.notTranslateByFieldNames());
                classRefPropertyI18nBean.setNotTranslateByFieldAnyBlank(classRefI18n.notTranslateByFieldAnyBlank());
                classPropertyCodeNameList.add(classRefPropertyI18nBean);

            }
            CLASS_REF_I18N_BEAN_MAP.put(classInfo, classPropertyCodeNameList);
        }

//        try (ScanResult scanResult = new ClassGraph().enableAllInfo().acceptPackages(i18nSupportConfig.getScanPackage())// packageName为指定路径，如com.xx.yy
//                .scan()) {
//            ClassInfoList classesWithAnnotation = scanResult.getClassesWithAnnotation(ClassRefI18ns.class);
//            for (ClassInfo classInfo : classesWithAnnotation) {
//                Class<?> loadClass = classInfo.loadClass();
//                ClassRefI18ns classRefI18ns = AnnotationUtil.getAnnotation(loadClass, ClassRefI18ns.class);
//                List<ClassRefI18nBean> classPropertyCodeNameList = new ArrayList<>();
//                for (ClassRefI18n classRefI18n : classRefI18ns.value()) {
//                    ClassRefI18nBean classRefPropertyI18nBean = new ClassRefI18nBean();
//                    classRefPropertyI18nBean.setClazz(loadClass);
//                    if (StrUtil.isBlank(classRefI18n.propertyCode())) {
//                        classRefPropertyI18nBean.setPropertyCode(classRefI18n.propertyCodeFieldName());
//                    } else {
//                        classRefPropertyI18nBean.setPropertyCode(classRefI18n.propertyCode());
//                    }
//                    classRefPropertyI18nBean.setPropertyCodeFieldName(classRefI18n.propertyCodeFieldName());
//                    classRefPropertyI18nBean.setDataCodeFieldName(classRefI18n.dataCodeFieldName());
//                    classRefPropertyI18nBean.setExtCodeFieldName(classRefI18n.extCodeFieldName());
//                    classRefPropertyI18nBean.setI18nModuleCode(classRefI18n.moduleCode());
//                    classRefPropertyI18nBean.setMainIdCodeFieldName(classRefI18n.mainIdFieldName());
//                    classRefPropertyI18nBean.setNeedMakeMainId(classRefI18n.isNeedMakeMainId());
//                    classRefPropertyI18nBean.setNeedMakeDataCode(classRefI18n.isNeedMakeDataCode());
//                    classRefPropertyI18nBean.setHandleWithJson(classRefI18n.handleWithJson());
//                    classRefPropertyI18nBean.setExtFun(classRefI18n.extFun() == IClassRefI18nExtHandler.class ? null : classRefI18n.extFun());
//                    classRefPropertyI18nBean.setNotTranslateByFieldNames(classRefI18n.notTranslateByFieldNames());
//                    classRefPropertyI18nBean.setNotTranslateByFieldAnyBlank(classRefI18n.notTranslateByFieldAnyBlank());
//                    classPropertyCodeNameList.add(classRefPropertyI18nBean);
//
//                }
//                CLASS_REF_I18N_BEAN_MAP.put(loadClass, classPropertyCodeNameList);
//            }
//        } catch (Throwable e) {
//            throw e;
//        }
    }

    @Override
    public List<ClassRefI18nBean> getClassRefI18nBeans(Class clazz) {
        return CLASS_REF_I18N_BEAN_MAP.getOrDefault(clazz, new ArrayList<>());
    }

    @Override
    public void putClassRefI18nBeans(SupportI18n supportI18n, Class clazz, List<ClassRefI18nBean> classRefI18nBeanList) {
        if (CollectionUtils.isEmpty(classRefI18nBeanList)) {
            return;
        }
        SUPPORT_I18N_CLASS_REF_I18N_BEAN_MAP.computeIfAbsent(clazz, k -> Maps.newHashMap()).put(supportI18n, classRefI18nBeanList);
    }

    @Override
    public List<ClassRefI18nBean> getClassRefI18nBeans(SupportI18n supportI18n, Class clazz) {
        Map<SupportI18n, List<ClassRefI18nBean>> classPropertyListMap = SUPPORT_I18N_CLASS_REF_I18N_BEAN_MAP.get(clazz);
        if (MapUtils.isEmpty(classPropertyListMap)) {
            return null;
        }

        return classPropertyListMap.get(supportI18n);
    }


}
