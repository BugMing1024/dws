package com.cloudwise.i18n.support.utils;

import org.reflections.scanners.Scanners;
import org.reflections.util.ConfigurationBuilder;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/10/25
 */
public class DosmI18nReflections {
    private org.reflections.Reflections reflections;

    public DosmI18nReflections(String[] packageNamePrefixs) {

        ConfigurationBuilder reflectionsConfigurationBuilder = new ConfigurationBuilder()
                .forPackages(packageNamePrefixs).addScanners(Scanners.SubTypes).addScanners(Scanners.TypesAnnotated)
                .addScanners(Scanners.MethodsParameter).addScanners(Scanners.MethodsAnnotated)
                .addScanners(Scanners.FieldsAnnotated).addScanners(Scanners.Resources);

        reflections = new org.reflections.Reflections(reflectionsConfigurationBuilder);
    }

    public <T> Set<Class<? extends T>> getSubTypesOf(Class<T> type) {

        return reflections.getSubTypesOf(type);
    }

    public Set<Method> getMethodsAnnotatedWith(Class<? extends Annotation> annotation) {

        return reflections.getMethodsAnnotatedWith(annotation);
    }

    public Set<Class<?>> getTypesAnnotatedWith(Class<? extends Annotation> annotation) {

        return reflections.getTypesAnnotatedWith(annotation);
    }

    public Set<Method> getMethodsWithParameter(AnnotatedElement type) {

        return reflections.getMethodsWithParameter(type);
    }

    public Set<Method> getMethodsReturn(Class<?> type) {

        return reflections.getMethodsReturn(type);
    }

    public Set<Field> getFieldsAnnotatedWith(Class<? extends Annotation> annotation) {

        return reflections.getFieldsAnnotatedWith(annotation);
    }

    public Set<String> getResources(String pattern) {

        return reflections.getResources(pattern);
    }

}
