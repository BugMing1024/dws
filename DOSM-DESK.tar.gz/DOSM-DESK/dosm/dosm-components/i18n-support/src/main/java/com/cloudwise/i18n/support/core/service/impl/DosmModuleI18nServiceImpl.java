package com.cloudwise.i18n.support.core.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;

import com.cloudwise.i18n.support.core.service.DosmModuleI18nService;
import com.cloudwise.i18n.support.core.dao.DosmModuleI18nMapper;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import org.springframework.stereotype.Service;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@Service
public class DosmModuleI18nServiceImpl extends ServiceImpl<DosmModuleI18nMapper, DosmModuleI18nEntity> implements DosmModuleI18nService {

    @Override
    public long merge(String moduleCode, String mainId) {
        return 0;
    }

    @Override
    public long copy(I18nReq orgI18nReq, I18nReq tarI18nReq) {
        return this.baseMapper.copy(orgI18nReq, tarI18nReq);
    }
}
