package com.cloudwise.i18n.support.core.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;

import com.cloudwise.i18n.support.core.vo.I18nReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/27
 */
@Mapper
public interface DosmModuleI18nMapper extends BaseMapper<DosmModuleI18nEntity> {

    @Update({
            "<script>",
            "update dosm_module_i18n m1 set merge_content=m2.content",
            "   from dosm_module_i18n m2",
            "      where m1.module_code=m2.module_code and m1.main_id=m2.main_id and m1.data_code=m2.data_code and m1.property_code=m2.property_code",
            "         and m1.module_code=#{moduleCode}",
            "         <if test=\"mainId != null\">",
            "            and m1.main_id=#{mainId}",
            "         </if>",
            "         and m1.language=#{toLanguage} and m2.language=#{formLanguage}",
            "         and m1.content is null and m2.content is not null",
            "</script>"
    })
    long merge(@Param("moduleCode") String moduleCode, @Param("mainId") String mainId, @Param("formLanguage") String formLanguage, @Param("toLanguage")String toLanguage);


    long copy(@Param("orgI18n") I18nReq orgI18nReq, @Param("tarI18n") I18nReq tarI18nReq);

}
