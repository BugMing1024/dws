package com.cloudwise.i18n.support.annotation;

import com.cloudwise.i18n.support.core.constant.I18nConstant;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * 要求参数必须为对象
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/7
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface I18nQueryCondition {
    //对应参数内id字段名称
    String mainIdField() default I18nConstant.FN_MAIN_IDS;

    //对应参数内 搜索内容
    String queryContentField();

    //对应模块名称
    String moduleCode();

    // i18n 属性编码
    String propertyCode() default "";

    /**
     * 多语言表中的字段编码
     * select main_id from dosm_module_i18n where ...
     * 可选值
     * id
     * dataCode
     * extCode
     * propertyCode
     * mainId
     *
     * @return
     */
    String queryFieldCode() default I18nConstant.FN_MAIN_ID;


    String applySql() default "";
}
