package com.cloudwise.i18n.support.core.handler;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.ReflectUtil;
import com.cloudwise.i18n.support.annotation.SupportI18n;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.classrefi18n.IClassRefI18nManager;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.I18nSpringContextUtils;
import com.cloudwise.i18n.support.utils.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
public interface TranslationHandler {

    String getType();

    Object translation(TranslationContext translationContext);


    default String getI18nLabel(List<DosmModuleI18nEntity> dosmModuleI18ns, String propertyCode, String defaultLabel) {
        List<DosmModuleI18nEntity> dosmModuleI18nsPropertyCodeList =  dosmModuleI18ns.stream().filter(dosmModuleI18n -> propertyCode.equals(dosmModuleI18n.getPropertyCode())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(dosmModuleI18nsPropertyCodeList)) {
            return defaultLabel == null ? "" : defaultLabel;
        }
        AccountUtil accountUtil = I18nSpringContextUtils.getBean(AccountUtil.class);
        return dosmModuleI18nsPropertyCodeList.stream().filter(dosmModuleI18n -> dosmModuleI18n.getLanguage().equals(accountUtil.getLanguage())
                )
                .findFirst().map(item -> {
                    String content = item.getContent();
                    if (content == null) {
                        return item.getMergeContent();
                    }
                    return content;
                })
                .orElse(CollectionUtil.isNotEmpty(dosmModuleI18ns) ? (dosmModuleI18ns.get(0).getMergeContent() == null ? (defaultLabel == null ? "" : defaultLabel) : dosmModuleI18ns.get(0).getMergeContent()) : (defaultLabel == null ? "" : defaultLabel)
                );
    }

    default String getI18nLabel(List<DosmModuleI18nEntity> dosmModuleI18ns, String dataCode, String propertyCode, String defaultLabel) {
        return dosmModuleI18ns.stream().filter(dosmModuleI18n -> propertyCode.equals(dosmModuleI18n.getPropertyCode()) && dataCode.equals(dosmModuleI18n.getDataCode())).findFirst().map(DosmModuleI18nEntity::getContent).orElse(defaultLabel == null ? "" : defaultLabel);
    }

    default DosmModuleI18nEntity makeI18nEntity(String language, Object o, ClassRefI18nBean classProperty) {
        DosmModuleI18nEntity nameI18n = new DosmModuleI18nEntity();
        nameI18n.setLanguage(language);
        nameI18n.setContent((String) ReflectUtil.getFieldValue(o, classProperty.getPropertyCodeFieldName()));
        nameI18n.setMergeContent((String) ReflectUtil.getFieldValue(o, classProperty.getPropertyCodeFieldName()));
        nameI18n.setPropertyCode(classProperty.getPropertyCode());
        nameI18n.setModuleCode(classProperty.getI18nModuleCode());
        Object extCodeObj = ReflectUtil.getFieldValue(o, classProperty.getExtCodeFieldName());
        nameI18n.setExtCode(Objects.isNull(extCodeObj) ? null : extCodeObj.toString());
        nameI18n.setDataCode((String) ReflectUtil.getFieldValue(o, classProperty.getDataCodeFieldName()));
        nameI18n.setMainId((String) ReflectUtil.getFieldValue(o, classProperty.getMainIdCodeFieldName()));
        return nameI18n;
    }

    default void makI18nEntity(String language, Object obj, List<ClassRefI18nBean> classPropertyList, List<DosmModuleI18nEntity> resultModuleI18ns) {
        for (ClassRefI18nBean classProperty : classPropertyList) {
            this.makeI18nEntity(language, obj, classProperty, resultModuleI18ns);
        }
    }

    default DosmModuleI18nEntity makeI18nEntity(String language, Object obj, ClassRefI18nBean classProperty, List<DosmModuleI18nEntity> resultModuleI18ns) {
        if (classProperty.getExtFun() != null) {
            IClassRefI18nExtHandler extHandler = I18nSpringContextUtils.getBean(classProperty.getExtFun());
            return extHandler.buildModuleI18n4Save(language, obj, classProperty, resultModuleI18ns);
        }

        DosmModuleI18nEntity nameI18n = null;
        if (!classProperty.isHandleWithJson()) {
            nameI18n = makeI18nEntity(language, obj, classProperty);
        } else {
            //按照json的方式去处理
            nameI18n = makeI18nEntityWithJson(language, obj, classProperty);
        }
        if (nameI18n != null) {
            resultModuleI18ns.add(nameI18n);
        }
        return nameI18n;

    }

    default DosmModuleI18nEntity makeI18nEntityWithJson(String language, Object o, ClassRefI18nBean classProperty) {
        DosmModuleI18nEntity dosmModuleI18nEntity = makeI18nEntity(language, o, classProperty);
        JsonNode parsed = JsonUtils.parseJsonNode(o);
        JsonNode node = parsed.findValue(classProperty.getPropertyCodeFieldName());
        if (node != null) {
            dosmModuleI18nEntity.setContent(node.asText());
            dosmModuleI18nEntity.setMergeContent(node.asText());
        }
        return dosmModuleI18nEntity;
    }

    default List<ClassRefI18nBean> getClassPropertyBySupportI18n(IClassRefI18nManager classRefI18nManager, Object record, TranslationContext translationContext) {
        Class clazz = record.getClass();
        SupportI18n supportI18n = translationContext.getAnnotation();

        List<ClassRefI18nBean> classRefI18nBeans = classRefI18nManager.getClassRefI18nBeans(supportI18n, clazz);
        if (CollectionUtil.isNotEmpty(classRefI18nBeans)) {
            return classRefI18nBeans;
        }

        classRefI18nBeans = classRefI18nManager.getClassRefI18nBeans(clazz);
        if (CollectionUtil.isEmpty(classRefI18nBeans)) {
            return null;
        }

        String[] excludePropertyCodeFieldNames = supportI18n.excludePropertyCodeFieldNames();
        if (ArrayUtil.isEmpty(excludePropertyCodeFieldNames)) {
            classRefI18nManager.putClassRefI18nBeans(supportI18n, clazz, classRefI18nBeans);
            return classRefI18nBeans;
        }

        List<String> excludePropertyCodeFieldNameList = Lists.newArrayList(excludePropertyCodeFieldNames);
        classRefI18nBeans = classRefI18nBeans.stream().filter(item -> !excludePropertyCodeFieldNameList.contains(item.getPropertyCodeFieldName())).collect(Collectors.toList());
        classRefI18nManager.putClassRefI18nBeans(supportI18n, clazz, classRefI18nBeans);
        return classRefI18nBeans;
    }
}
