package com.cloudwise.i18n.support.core.service;

import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.vo.I18nReq;
import com.cloudwise.i18n.support.core.vo.LanguageVo;
import com.cloudwise.i18n.support.core.vo.MainI18nInfoVO;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/7/25
 */
public interface TranslationI18nService {
    /**
     * 翻译
     *
     * @param language     语言
     * @param moduleCode   模块code
     * @param mainId       主业务数据ID
     * @param dataCode     数据编码
     * @param propertyCode 属性编码
     * @param content      国际化内容
     * @return 合并后的国际化内容
     */
    String translation(String language, String moduleCode, String mainId, String dataCode, String propertyCode, String content);

    void refreshRedis(List<DosmModuleI18nEntity> dosmModuleI18ns);

    /**
     * 根据i18nReq查询
     * <p>
     * 支持mainId
     * 支持dataCode
     * 支持moduleCode
     * 支持language
     * 支持propertyCode
     * 支持extCode
     * </p>
     *
     * @param i18nReq i18nReq
     * @return List<DosmModuleI18nEntity>
     */
    List<DosmModuleI18nEntity> listByI18nReq(I18nReq i18nReq);

    List<DosmModuleI18nEntity> listByI18nReq4Language(I18nReq i18nReq, String language);

    List<DosmModuleI18nEntity> listByI18nReq4Languages(I18nReq i18nReq, List<String> languages);

    List<DosmModuleI18nEntity> listByMainId(String mainId, String language);

    List<DosmModuleI18nEntity> listByDataCodes(String i18nModuleCode,Collection<String> dataCodes, String language);

    List<DosmModuleI18nEntity> listByModuleCodeAndMainId(String i18nModuleCode, String mainId);

    List<DosmModuleI18nEntity> listByDataCodesWithCache(String i18nModuleCode, Collection<String> dataCodes, String language);


    List<DosmModuleI18nEntity> listByMainIds(Collection<String> mainIds, String language);

    List<DosmModuleI18nEntity> listByMainIds(String i18nModuleCode, Collection<String> mainIds);

    List<DosmModuleI18nEntity> listByMainIds(Collection<String> mainIds);

    List<DosmModuleI18nEntity> listByMainIdAndDataCodes(String moduleCode, Collection<String> mainIds, Collection<String> dataCodes, String language);

    void saveBatch(List<DosmModuleI18nEntity> dosmModuleI18ns);

    void deleteByMainId(String moduleCode, String mainId, String language);

    void deleteByMainId(String moduleCode, String mainId);

    void deleteByDataCode(String moduleCode, String dataCode);

    void deleteByMainIds(String moduleCode, List<String> mainIds);

    void deleteByDataCodes(String moduleCode, List<String> dataCodes);

    String translation(String language, String[] i18nModuleCodes, String mainId, String dataCode, String propertyCode, String content);

    Object getNormalList(I18nReq i18nReq);

    Boolean save(String moduleCode, List<MainI18nInfoVO> mainI18nInfos);


    void deleteByMainIds(List<String> mainIds);

    void deleteByI18nReq(I18nReq i18nReq);

    List<LanguageVo> getLauguageList();

    List<String> getMainIdsByContent(String i18nModuleCode, String[] propertyCodes, String content, String queryFieldCode, String applySql);

    /**
     * 将 orgI18nReq 数据复制到 tarI18nReq
     *
     * @param orgI18nReq 原国际化信息
     * @param tarI18nReq 目标国际化信息
     */
    void copy(I18nReq orgI18nReq, I18nReq tarI18nReq);

    void converter(String moduleCode, MainI18nInfoVO mainI18nInfo, List<DosmModuleI18nEntity> dosmModuleI18nList, Set<String> idSet);
}
