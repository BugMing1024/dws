package com.cloudwise.i18n.support.core.config;

import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.DosmI18nReflections;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/21
 */
@Component
@Getter
@RefreshScope
public class I18nSupportConfig {

    @Value("${dosm.support.i18n:true}")
    private Boolean isSupportI18n;
    @Value("${support.i18n.scan.package:com.cloudwise.dosm}")
    private String scanPackage;

    @Value("${dosm.btn.support.i18n:true}")
    private Boolean isControlBtn;

    @Bean
    DosmI18nReflections dosmI18nReflections() {
        String[] packageNamePrefixs = scanPackage.split(",");
        return new DosmI18nReflections(packageNamePrefixs);
    }

    @Bean
    @ConditionalOnMissingBean(AccountUtil.class)
    public AccountUtil accountUtil() {
        return new AccountUtil() {
            @Override
            public String getLanguage() {
                return "zh";
            }

            @Override
            public String getAccountId() {
                return "110";
            }

            @Override
            public String getTopAccountId() {
                return "110";
            }

            @Override
            public String getUserId() {
                return "1";
            }

            @Override
            public String getLanguageFull() {
                return "zh_CN";
            }

            @Override
            public Date getCurrTime() {
                return new Date();
            }
        };
    }
}
