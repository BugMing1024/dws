package com.cloudwise.i18n.support.core.handler.simple;

import cn.hutool.core.util.IdUtil;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 适配场景：简单的对象，只有一个主键，且主键为String类型
 * 且业务逻辑内没有对主键进行修改
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/1
 */
@Component
public final class SimpleSaveTranslationHandler extends AbstractSaveTranslationHandler<Object> {
    @Override
    public List<DosmModuleI18nEntity> makeI18nEntity(Object o, TranslationContext translationContext) {
        List<ClassRefI18nBean> classPropertyList = getClassPropertyBySupportI18n(classRefI18nManager, o, translationContext);
        List<DosmModuleI18nEntity> dosmModuleI18ns = new ArrayList<>();
        String language = accountUtil.getLanguage();
        makI18nEntity(language, IdUtil.getSnowflakeNextIdStr(), o, classPropertyList, dosmModuleI18ns);
        return dosmModuleI18ns;
    }

    @Override
    public String getType() {
        return "simpleSaveTranslationHandler";
    }
}
