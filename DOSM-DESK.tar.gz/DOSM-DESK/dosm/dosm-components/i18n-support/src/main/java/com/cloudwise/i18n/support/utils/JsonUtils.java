

package com.cloudwise.i18n.support.utils;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.node.*;
import com.fasterxml.jackson.databind.type.MapType;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.*;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.ALWAYS;
import static com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS;
import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.SerializationFeature.FAIL_ON_EMPTY_BEANS;
import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;

/**
 * @author admin
 */
@Slf4j
public class JsonUtils {

	public static final ObjectMapper mapper = new ObjectMapper()
			.configure(FAIL_ON_UNKNOWN_PROPERTIES, false)
			.configure(WRITE_DATES_AS_TIMESTAMPS, false)
			.configure(FAIL_ON_EMPTY_BEANS, false)
			.setSerializationInclusion(ALWAYS);

	private static final ObjectMapper mapperSnake = new ObjectMapper()
			.configure(FAIL_ON_UNKNOWN_PROPERTIES, false)
			.configure(WRITE_DATES_AS_TIMESTAMPS, false)
			.configure(FAIL_ON_EMPTY_BEANS, false)
			.setSerializationInclusion(ALWAYS)
			.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);


	static {
		JacksonTypeHandler.setObjectMapper(mapper);
	}

	/**
	 * 提供额外的解析器
	 * @param module
	 */
	public static void registerModule(com.fasterxml.jackson.databind.Module module) {
		mapper.registerModule(module);
		mapperSnake.registerModule(module);
	}


	/**
	 * 外部api调用,变量替换的参数存在回车、换行，json转换存在错误，加ALLOW_UNQUOTED_CONTROL_CHARS配置解决，允许回车换行
	 */
	private static final ObjectMapper mapperRequest = new ObjectMapper()
			.configure(FAIL_ON_UNKNOWN_PROPERTIES, false)
			.configure(WRITE_DATES_AS_TIMESTAMPS, false)
			.configure(FAIL_ON_EMPTY_BEANS, false)
			.configure(ALLOW_UNQUOTED_CONTROL_CHARS, true)
			.setSerializationInclusion(ALWAYS);


	/**
	 * 对象转化字符串
	 * 与toJsonString的区别为，当入参为 String时，会直接返回
	 * @param object 对象
	 * @return String
	 */
	public static String toJsonString(Object object) {
		try {
			if(object == null) {
				return null;
			}
			if(object instanceof String) {
				return (String) object;
			}
			return mapper.writeValueAsString(object);
		} catch(Exception e) {
			log.debug("Object conversion String failed", e);
		}
		return null;
	}

	/**
	 * 对象转化JSON串
	 * 与toJsonString的区别为，当入参为 String时，会在外层添加引号，构造为 TextNode
	 * @param object 对象
	 * @return String
	 */
	public static String toJsonValueString(Object object) {
		try {
			if(object == null) {
				return null;
			}
			return mapper.writeValueAsString(object);
		} catch(Exception e) {
			log.debug("Object conversion JSON String failed", e);
		}
		return null;
	}

	/**
	 * 给jsonNode使用的，防止各种引号
	 * @param jsonNode
	 * @return
	 */
	public static String toPrettyString(JsonNode jsonNode) {
		if(jsonNode == null) {
			return null;
		}
		if(jsonNode instanceof NullNode) {
			return null;
		}
		if(jsonNode instanceof ValueNode) {
			return jsonNode.asText();
		}

		return jsonNode.toString();
	}

	public static <T> T parseObject(String json, Class<T> clazz) {
		return tryParseAsPossible(json, clazz);
	}

	/**
	 * object转化对象
	 * @param object object可能是JSON字符串或者其他对象类型
	 * @param clazz  class
	 * @param <T>    泛型
	 * @return 返回对象
	 */
	public static <T> T parseObject(Object object, Class<T> clazz) {
		if(clazz == String.class) {
			return (T) toJsonString(object);
		}
		return tryParseAsPossible(object, clazz);
	}

	/**
	 * 尝试将入参object转换为clazz对应的类型，
	 * 如果object为String类型，在某些情况下转换目标类失败时，会尝试将入参转为 json 串再次尝试：
	 *   例： object = "abc", clazz = com.fasterxml.jackson.databind.node.TextNode.class时，直接转换会失败，需要
	 *   调用JsonUtils.toJsonValueString将"abc"先转换为"\"abc\""才能成功转换为TextNode
	 *
	 * @param object
	 * @param clazz
	 * @param <T>
	 * @return
	 */
	private static <T> T tryParseAsPossible(Object object, Class<T> clazz) {
		try {
			if(object == null) {
				return null;
			}
			if(clazz.isInstance(object)) {
				return (T) object;
			}
			if(object instanceof String) {
				try {
					return mapper.readValue((String) object, clazz);
				} catch(Exception e) {
					log.error("parse string to object error, param:{}", object, e);
				}
			}
			return mapper.readValue(JsonUtils.toJsonValueString(object), clazz);
		} catch(Exception e) {
			log.error("parse object to object error, param:{}", JsonUtils.toJsonString(object), e);
		}
		return null;
	}


	/**
	 * 通过 mapper.convertValue 将 object 转为 clazz
	 */
	@Deprecated
	public static <T> T convertObject(Object object, Class<T> clazz) {
		if(object == null) {
			return null;
		}
		return mapper.convertValue(object, clazz);
	}

	/**
	 * 【writeObjectToNode】 将 object 转为 JsonNode
	 * <p> 样例1："11" 转为 TextNode, 值为 "11"
	 * <p> 样例2："\"a\"" 转为 TextNode, 值为 "\"a\""
	 * <p> 样例3："a" 转为 TextNode, 值为 "a"
	 * <p> 样例4："{\"a\": 1}" 转为 TextNode, 值为 "{\"a\": 1}"
	 * <p> 样例5：{"a": 1} 转为 ObjectNode, 值为 {"a": 1}
	 * <p>
	 * <p>
	 * 【parseJsonNode】  将 object 转为 JsonNode
	 * <p> 样例1："11" 转为 TextNode, 值为 "11"
	 * <p> 样例2："\"a\"" 转为 TextNode, 值为 "a"
	 * <p> 样例3："a" 转为 TextNode, 值为 "a"
	 * <p> 样例4："{\"a\": 1}" 转为 ObjectNode, 值为 {"a": 1}
	 * <p> 样例5：{"a": 1} 转为 ObjectNode, 值为 {"a": 1}
	 */
	@Deprecated
	public static JsonNode writeObjectToNode(Object object) {
		try {
			if(object == null) {
				return null;
			}
			return mapper.convertValue(object, JsonNode.class);
		} catch(Exception e) {
			log.error("Object 转换成 JsonNode 失败", e);
		}
		return null;
	}

	/**
	 * JSON字符串转化 List<Map<String, Object>>
	 * @param object
	 * @return 返回对象
	 */
	public static List<Map<String, Object>> parseMapList(Object object) {
		try {
			if(object == null) {
				return null;
			}
			if(object instanceof String) {
				try {
					return mapper.readValue((String) object, new TypeReference<List<Map<String, Object>>>() {});
				} catch(Exception e) {
					log.error("parse string to list error, param:{}", object, e);
				}
			}
			return mapper.readValue(toJsonValueString(object), new TypeReference<List<Map<String, Object>>>() {});
		} catch(Exception e) {
			log.error("parse object to list error, param:{}", object, e);
		}
		return null;
	}


	/**
	 * 【writeObjectToNode】 将 object 转为 JsonNode
	 * <p> 样例1："11" 转为 TextNode, 值为 "11"
	 * <p> 样例2："\"a\"" 转为 TextNode, 值为 "\"a\""
	 * <p> 样例3："a" 转为 TextNode, 值为 "a"
	 * <p> 样例4："{\"a\": 1}" 转为 TextNode, 值为 "{\"a\": 1}"
	 * <p> 样例5：{"a": 1} 转为 ObjectNode, 值为 {"a": 1}
	 * <p>
	 * <p>
	 * 【parseJsonNode】  将 object 转为 JsonNode
	 * <p> 样例1："11" 转为 TextNode, 值为 "11"
	 * <p> 样例2："\"a\"" 转为 TextNode, 值为 "a"
	 * <p> 样例3："a" 转为 TextNode, 值为 "a"
	 * <p> 样例4："{\"a\": 1}" 转为 ObjectNode, 值为 {"a": 1}
	 * <p> 样例5：{"a": 1} 转为 ObjectNode, 值为 {"a": 1}
	 */
	public static JsonNode parseJsonNode(Object object) {
		try {
			if(object == null) {
				return null;
			}
//			if(object instanceof JsonNode) {
//				return (JsonNode) object;
//			}
			if(object instanceof String) {
				try {
					// 禁止出现，"11" 转为 IntNode
					Double.parseDouble((String)object);
					return new TextNode((String)object);
				} catch(Exception e) {
				}
				try {
					return mapper.readTree((String) object);
				} catch(Exception e) {
					log.error("parse string to json error, param:{}", object, e);
				}
			}
			return mapper.readTree(toJsonValueString(object));
		} catch(Exception e) {
			log.error("parse object to json error, param:{}", object, e);
		}
		return null;
	}


	/**
	 * 解决json体中存在回车换行的问题
	 * @param json
	 * @return
	 */
	public static JsonNode parseRequestJsonNode(String json) {
		try {
			if(StrUtil.isBlank(json)) {
				return null;
			}
			return mapperRequest.readTree(json);
		} catch(Exception e) {
			log.error("parse string to json error, param:{}", json, e);
		}
		return null;
	}

	/**
	 * 转为审批字段量身打造，兼容审批字段存入的值有可能是单纯的字符串，也有可能是 json 串的情况
	 * @param json
	 * @return
	 */
	public static JsonNode tryParseApproveFieldNode(String json) {
		if(json == null) {
			return null;
		}
		JsonNode n = parseJsonNode(json);
//		"123" IntNode
		if(n != null && !(n instanceof ObjectNode || n instanceof TextNode)) {
			return new TextNode(n.asText());
		}
		return n == null? new TextNode(json): n;
	}


	/**
	 * object转为Map对象
	 * @param object
	 * @return Map对象
	 */
	public static <T> Map<String, T> parseMap(Object object, Class<T> clazz) {
		try {
			if(object == null) {
				return null;
			}

			MapType mapType = mapper.getTypeFactory().constructMapType(Map.class, String.class, clazz);
			if(object instanceof String) {
				try {
					return mapper.readValue((String) object, mapType);
				} catch(Exception e) {
					log.error("parse string to map error, param:{}", object, e);
				}
			}

			return mapper.readValue(mapper.writeValueAsString(object), mapType);
		} catch(Exception e) {
			log.error("parse object to map error, param:{}", object, e);
			return null;
		}
	}

	/**
	 * Json字符串转为Map对象
	 * @param object bean 对象
	 * @return Map对象
	 */
	public static Map<String, Object> parseObject(Object object) {
		try {
			if(object == null) {
				return null;
			}

			TypeReference<Map<String, Object>> typeReference = new TypeReference<Map<String, Object>>() {};
			if(object instanceof String) {
				try {
					return mapper.readValue((String) object, typeReference);
				} catch(Exception e) {
					log.error("parse string to map error, param:{}", object, e);
				}
			}
			return mapper.readValue(toJsonValueString(object), typeReference);
		} catch(Exception e) {
			log.error("parse object to map error, param:{}", object, e);
			return null;
		}
	}

	/**
	 * Json字符串转为Map对象
	 * @param json Json字符串
	 * @return Map对象
	 * @throws IOException 异常信息
	 */
	@Deprecated
	public static Map<String, Object> parseObjectThrow(String json) throws IOException {
		if(StrUtil.isBlank(json)) {
			return null;
		}
		return mapper.readValue(json, new TypeReference<Map<String, Object>>() {
		});
	}

	/**
	 * Object对象转为指定类型对象
	 * @param object       Object对象
	 * @param valueTypeRef 类型
	 * @return 对象
	 */
	public static <T> T parseObject(Object object, TypeReference<T> valueTypeRef) {
		try {
			if(object == null) {
				return null;
			}

			if(object instanceof String) {
				try {
					return mapper.readValue((String) object, valueTypeRef);
				} catch(Exception e) {
					log.error("parse string to object error, param:{}", object, e);
				}
			}
			return mapper.readValue(mapper.writeValueAsString(object), valueTypeRef);
		} catch(Exception e) {
			log.error("parse object to object error, param:{}", object, e);
			return null;
		}
	}

	/**
	 * @param object    Object对象
	 * @param valueType 需转化类型
	 * @param <T>       范形
	 * @return 范形列表
	 */
	@Deprecated
	public static <T> List<T> convertList(Object object, Class<T> valueType) {
		return parseArray(object, valueType);
	}

	public static <T> List<T> parseArray(Object object, Class<T> clazz) {
		try {
			if(object == null) {
				return null;
			}
			JavaType javaType = mapper.getTypeFactory().constructParametricType(ArrayList.class, clazz);
			if(object instanceof String) {
				try {
					return mapper.readValue((String) object, javaType);
				} catch(Exception e) {
					log.error("parse string to list error, param:{}", object, e);
				}
			}

			return mapper.readValue(mapper.writeValueAsString(object), javaType);
		} catch(Exception e) {
			log.error("parse object to list error, param:{}", object, e);
			return null;
		}
	}

	/**
	 * @param json      需要转化的json字符串
	 * @param valueType 需转化类型
	 * @param <T>       范形
	 * @return 范形列表
	 */
	@Deprecated
	public static <T> List<T> convertListWithSnake(String json, Class<T> valueType) {
		try {
			if(StrUtil.isBlank(json)) {
				return null;
			}
			JavaType javaType = mapperSnake.getTypeFactory().constructParametricType(ArrayList.class, valueType);
			return mapperSnake.readValue(json, javaType);
		} catch(Exception e) {
			log.error("parse string to list error, param:{}", json, e);
			return null;
		}
	}

	public static ObjectNode createObjectNode() {
		return mapper.createObjectNode();
	}

	public static ArrayNode createArrayNode() {
		return mapper.createArrayNode();
	}

	/**
	 * 判断是一个非空的数组类型 json
	 * @param node json 节点
	 * @return
	 */
	public static boolean isArrayNotEmpty(JsonNode node) {
		return Objects.nonNull(node) && !node.isNull() && node.isArray() && !node.isEmpty();
	}

	/**
	 * 判断是一个非空的ObjectNode json
	 * @param node json 节点
	 * @return
	 */
	public static boolean isObjectNotEmpty(JsonNode node) {
		return Objects.nonNull(node) && !node.isNull() && node.isObject() && !node.isEmpty();
	}


	public static ArrayNode getArrayNode(JsonNode valueJson, String key) {
		JsonNode jsonNode = valueJson.get(key);
		if(jsonNode instanceof NullNode || jsonNode == null) {
			return null;
		}
		if(Boolean.FALSE.equals(jsonNode.isArray())) {
			return null;
		}
		return (ArrayNode) jsonNode;
	}

	public static String getText(JsonNode node, String key) {
		return getText(node, key, null);
	}


	public static String getText(JsonNode node, String key, String defaultVal) {
		return Optional.ofNullable(node).map(n -> n.get(key)).map(JsonNode::asText).orElse(defaultVal);
	}

	public static Long getLong(JsonNode node, String key) {
		return getLong(node, key, null);
	}

	public static Long getLong(JsonNode node, String key, Long defaultVal) {
		// 从json中获取数字并转换成Long类型
		JsonNode jsonNode = node.get(key);
		if(jsonNode instanceof NullNode || jsonNode == null)
			return defaultVal;
		return jsonNode.asLong();
	}

	public static boolean isNotEmpty(JsonNode node) {
		if(Objects.isNull(node)) {
			return false;
		}
		if(node.isArray() || node.isObject()) {
			return isNotEmptyNode(node);
		}
		return isNotNull(node) && StrUtil.isNotBlank(JsonUtils.toPrettyString(node));
	}

	public static boolean isEmpty(JsonNode node) {
		if(Objects.isNull(node)) {
			return true;
		}
		if(node.isArray() || node.isObject()) {
			return isEmptyNode(node);
		}
		return isNull(node) || StrUtil.isBlank(JsonUtils.toPrettyString(node));
	}

	private static boolean isEmptyNode(JsonNode node) {
		return isNull(node) || node.isEmpty();
	}

	private static boolean isNotEmptyNode(JsonNode node) {
		return Boolean.FALSE.equals(isEmptyNode(node));
	}

	public static boolean isNull(JsonNode node) {
		return ObjectUtil.isNull(node) || node.isNull();
	}

	public static boolean isNotNull(JsonNode node) {
		return Boolean.FALSE.equals(isNull(node));
	}
}
