package com.cloudwise.i18n.support.core.handler;

/**
 * <p>
 * 空实现
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/8/2
 */
public abstract class DefaultTranslationHandler implements TranslationHandler {
}
