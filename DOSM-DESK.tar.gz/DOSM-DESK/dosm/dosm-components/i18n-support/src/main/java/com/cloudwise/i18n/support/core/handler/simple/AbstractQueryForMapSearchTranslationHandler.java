package com.cloudwise.i18n.support.core.handler.simple;

import cn.hutool.core.annotation.AnnotationUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Maps;
import com.cloudwise.i18n.support.annotation.I18nQueryCondition;
import com.cloudwise.i18n.support.annotation.I18nQueryConditions;
import com.cloudwise.i18n.support.annotation.I18nQueryIds;
import com.cloudwise.i18n.support.annotation.I18nQuerySearchKey;
import com.cloudwise.i18n.support.cache.TranslationThreadCache;
import com.cloudwise.i18n.support.core.TranslationContext;
import com.cloudwise.i18n.support.core.constant.I18nConstant;
import com.cloudwise.i18n.support.core.dto.ClassRefI18nBean;
import com.cloudwise.i18n.support.core.entity.DosmModuleI18nEntity;
import com.cloudwise.i18n.support.core.handler.IClassRefI18nExtHandler;
import com.cloudwise.i18n.support.core.handler.TranslationHandler;
import com.cloudwise.i18n.support.core.service.TranslationI18nService;
import com.cloudwise.i18n.support.utils.AccountUtil;
import com.cloudwise.i18n.support.utils.I18nSpringContextUtils;
import com.cloudwise.i18n.support.utils.JsonUtils;
import com.cloudwise.i18n.support.utils.StringUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.MapUtils;
import org.apache.ibatis.annotations.Param;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author 支持map键值对搜索条件
 * @since 2023/8/1
 */
public abstract class AbstractQueryForMapSearchTranslationHandler<R> implements TranslationHandler {

    @Autowired
    public TranslationI18nService translationI18nService;
    @Autowired
    public AccountUtil accountUtil;

    @Override
    public Object translation(TranslationContext translationContext) {
        ProceedingJoinPoint joinPoint = translationContext.getJoinPoint();
        R proceed = null;
        try {

            Object[] args = joinPoint.getArgs();
            if (args.length > 0) {
                // mainId 参数位置信息，格式: map<mainIdParamName, args中下标>
                Map<String, Integer> mainIdParamPositionMap = Maps.newHashMap();
                // mainId 集合信息，格式: map<mainIdParamName, List<mainId>>
                Map<String, List<String>> mainIdListMap = Maps.newHashMap();

                MethodSignature signature = (MethodSignature) joinPoint.getSignature();
                Method method = signature.getMethod();
                Parameter[] parameters = method.getParameters();
                for (int i = 0; i < parameters.length; i++) {
                    Parameter parameter = parameters[i];
                    I18nQuerySearchKey i18nQuerySearchKey = parameter.getAnnotation(I18nQuerySearchKey.class);
                    if (i18nQuerySearchKey != null) {
                        Object arg = args[i];
                        if (ObjectUtil.isNotNull(arg)) {
                            if (arg instanceof String) {
                                String searchKey = (String) arg;
                                if (StrUtil.isNotBlank(searchKey)) {
                                    List<String> mainIds = translationI18nService.getMainIdsByContent(i18nQuerySearchKey.moduleCode(), i18nQuerySearchKey.propertyCode(), searchKey, i18nQuerySearchKey.queryFieldCode(), i18nQuerySearchKey.applySql());
                                    mainIdListMap.put(i18nQuerySearchKey.mainIdParam(), mainIds);
                                }
                            }
                        }
                    }

                    I18nQueryIds i18nQueryIds = parameter.getAnnotation(I18nQueryIds.class);
                    if (i18nQueryIds != null) {
                        String paramName = parameter.getName();
                        mainIdParamPositionMap.put(paramName, i);
                        Param param = parameter.getAnnotation(Param.class);
                        if(param != null && !StrUtil.equals(param.value(), paramName)) {
                            mainIdParamPositionMap.put(param.value(), i);
                        }
                    }
                }

                if (MapUtils.isNotEmpty(mainIdListMap)) {
                    for(Map.Entry<String, List<String>> mainIdListEntry: mainIdListMap.entrySet()) {
                        args[mainIdParamPositionMap.get(mainIdListEntry.getKey())] = mainIdListEntry.getValue();
                    }
                }


                Object arg = args[0];
                if (ObjectUtil.isNotNull(arg)) {
                    I18nQueryConditions annotation = AnnotationUtil.getAnnotation(arg.getClass(), I18nQueryConditions.class);
                    if (annotation != null) {
                        String mainIdsFieldName = I18nConstant.FN_MAIN_IDS;
                        List<String> mainIds = Lists.newArrayList();
                        I18nQueryCondition[] value = annotation.value();
                        for (I18nQueryCondition i18nQueryCondition : value) {
                            String fieldName = i18nQueryCondition.queryContentField();
                            Object fieldValue = ReflectUtil.getFieldValue(arg, fieldName);
                            if (fieldValue != null && StrUtil.isNotBlank(fieldValue.toString())) {
                                mainIds.addAll(translationI18nService.getMainIdsByContent(i18nQueryCondition.moduleCode(),
                                        new String[]{i18nQueryCondition.propertyCode()},
                                        fieldValue.toString(), i18nQueryCondition.queryFieldCode(),
                                        i18nQueryCondition.applySql()));
                            }
                            mainIdsFieldName = i18nQueryCondition.mainIdField();
                        }
                        if (mainIds.size() > 0) {
                            ReflectUtil.setFieldValue(arg, mainIdsFieldName, mainIds);
                        }
                    }
                }
            }
            proceed = (R) joinPoint.proceed(args);
            return doTranslation(proceed, translationContext);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } finally {
//            TranslationThreadCache.remove();
        }
    }

    public abstract R doTranslation(R r, TranslationContext translationContext);


    protected Object doTranslation(Object record, List<DosmModuleI18nEntity> dosmModuleI18ns, ClassRefI18nBean classProperty) {

        String i18nCode = classProperty.getPropertyCodeFieldName();
        if (classProperty.getExtFun() != null) {
            IClassRefI18nExtHandler extHandler = I18nSpringContextUtils.getBean(classProperty.getExtFun());
            return extHandler.doTranslation4Query(record, classProperty, dosmModuleI18ns);
        }
        if (CollectionUtil.isEmpty(dosmModuleI18ns)) {
            return record;
        }
        if (classProperty.isHandleWithJson()) {
            JsonNode recordNode = JsonUtils.parseJsonNode(record);
            JsonNode parent = recordNode.findParent(classProperty.getPropertyCodeFieldName());
            if (parent instanceof ObjectNode) {
                ObjectNode objectNode = (ObjectNode) parent;
                JsonNode jsonNode = objectNode.get(classProperty.getPropertyCodeFieldName());
                if (jsonNode instanceof TextNode) {
                    String i18nCodeValue = jsonNode.asText();
                    objectNode.put(classProperty.getPropertyCodeFieldName(), getI18nLabel(dosmModuleI18ns, classProperty.getPropertyCode(), i18nCodeValue));
                }
            }
            record = JsonUtils.parseObject(recordNode, record.getClass());
        } else {
            String fieldI18nCode = StringUtils.capitalizeFirstLetter(i18nCode);
            String i18nCodeValue = ReflectUtil.invoke(record, "get" + fieldI18nCode);
            ReflectUtil.invoke(record, "set" + fieldI18nCode, getI18nLabel(dosmModuleI18ns, classProperty.getPropertyCode(), i18nCodeValue));
        }
        return record;
    }
}
