package com.cloudwise.dosm.beetl.utils;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.beetl.core.Template;

import java.util.Map;

/**
 * @author solomon.zhou
 * @Description: 模版占位符操作  占位变量${} 需要严格按照 Java 变量命名规则，可以 .
 * @date 2021/7/110:38 下午
 */
public class BpmTemplateUtil {

    public static String patchPlaceHolder(String content) {
        if (StringUtils.isEmpty(content)) {
            return null;
        }
        return String.format("%s%s%s", "${ticket.", content, "}");
    }
    /**
     * 优化占位符  如：${ticket.name&id} --> ${name}${id}
     *
     * @param content
     */
    public static String optimizePlaceHolder(String content) {
        if (StringUtils.isEmpty(content)) {
            return null;
        }
        return content.replace("&", "}${").replace("ticket.", "");
    }

    /**
     * 解析工单变量占位符  如：占位符${name}${id} ， map{name:名称，id：123} --》 占位符名称123
     *
     * @param key             占位符内容
     * @param templateBindMap 占位符替换内容
     * @return
     */
    public static String render(String key, Map<String, Object> templateBindMap) {
        if (StringUtils.isEmpty(key)) {
            return StringUtils.EMPTY;
        }
        key = optimizePlaceHolder(key);
        if(MapUtils.isEmpty(templateBindMap)) {
            return key;
        }

        Template template = BeetlTemplateFactory.getInstance()
                .getGroupTemplate()
                .getTemplate(key);
        template.binding(templateBindMap);
        return template.render();
    }

    public static String renderNoSpecial(String key, Map<String, Object> templateBindMap) {
        if (StringUtils.isEmpty(key)) {
            return StringUtils.EMPTY;
        }
        key =  key.replace("ticket.", "");

        Template template = BeetlTemplateFactory.getInstance()
                .getGroupTemplate()
                .getTemplate(key);
        template.binding(templateBindMap);
        return template.render();
    }

}
