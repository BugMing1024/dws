package com.cloudwise.dosm.sample.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloudwise.dosm.sample.entity.Sample;

import java.util.List;

/**
 * 样例service
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:12
 **/
public interface SampleService extends IService<Sample> {
    /**
     * 获取单个对象
     *
     * @param id 实体id
     * @return
     */
    Sample getOne(String id);

    /**
     * 查询sample列表数据
     *
     * @param sampleQuery 查询条件
     * @return 查询结果
     */
    List<Sample> getSampleList(Sample sampleQuery);
}
