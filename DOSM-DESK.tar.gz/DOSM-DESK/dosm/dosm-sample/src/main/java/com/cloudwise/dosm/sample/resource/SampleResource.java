package com.cloudwise.dosm.sample.resource;

import com.cloudwise.dosm.core.annotation.ResponseResult;
import com.cloudwise.dosm.core.exception.BaseException;
import com.cloudwise.dosm.sample.converter.SampleConverter;
import com.cloudwise.dosm.sample.converter.SampleListConverter;
import com.cloudwise.dosm.sample.entity.Sample;
import com.cloudwise.dosm.sample.service.SampleService;
import com.cloudwise.dosm.sample.vo.SampleListRequestVo;
import com.cloudwise.dosm.sample.vo.SampleListResponseVo;
import com.cloudwise.dosm.sample.vo.SampleResponseVo;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 样例
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:11
 **/
@Slf4j
@Api(tags = "样例")
@ResponseResult
@RestController
@RequestMapping("/api/v2/sample")
public class SampleResource {
    @Autowired
    private SampleService sampleService;

    @Autowired
    private SampleConverter sampleConverter;

    @Autowired
    private SampleListConverter sampleListConverter;

    /**
     * 根据id获取单个实体
     *
     * @param id 实体唯一标识
     * @return
     */
    @ApiOperationSupport(author = "jensen.xu")
    @ApiOperation("根据id获取单个实体")
    @GetMapping(value = "/get/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public SampleResponseVo getSample(@ApiParam(value = "id", name = "唯一标识") @PathVariable(value = "id") String id) {
        BaseException my = new BaseException(200000);
        if (true) {
            throw my;
        }
        return sampleConverter.entity2vo(sampleService.getOne(id));
    }

    @ApiOperationSupport(author = "jensen.xu")
    @ApiOperation("异常校验")
    @GetMapping(value = "/exception/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public SampleResponseVo getException(@ApiParam(value = "id", name = "唯一标识") @PathVariable(value = "id") String id) {
        BaseException my = new BaseException(200000);
        if (true) {
            throw my;
        }
        return sampleConverter.entity2vo(sampleService.getOne(id));
    }

    /**
     * 列表查询样例
     *
     * @param sampleListRequestVo 查询请求
     * @return 列表数据
     */
    @ApiOperationSupport(author = "jensen.xu")
    @ApiOperation("list")
    @GetMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<SampleListResponseVo> updateSample(@RequestBody SampleListRequestVo sampleListRequestVo) {
        // 1. 转换请求vo到service的实体
        Sample sampleQuery = sampleListConverter.vo2entity(sampleListRequestVo);

        // 2. 执行service调用
        List<Sample> sampleList = sampleService.getSampleList(sampleQuery);

        // 3. 转换service的实体到响应vo
        List<SampleListResponseVo> listResponseVos = sampleListConverter.entity2voList(sampleList);

        log.trace("查询成功，获取到数据为：{}", listResponseVos);
        return listResponseVos;
    }

}
