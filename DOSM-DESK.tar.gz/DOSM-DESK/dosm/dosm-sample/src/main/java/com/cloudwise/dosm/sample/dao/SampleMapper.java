package com.cloudwise.dosm.sample.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudwise.dosm.sample.entity.Sample;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 样例Mapper文件
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:12
 **/
@Mapper
public interface SampleMapper extends BaseMapper<Sample> {
    /**
     * 获取单个Sample对象
     *
     * @param id 唯一主键
     * @return 返回单个实体
     */
    Sample findSample(@Param(value = "id") String id);

    String getAllById(@Param(value = "id") String id);
}
