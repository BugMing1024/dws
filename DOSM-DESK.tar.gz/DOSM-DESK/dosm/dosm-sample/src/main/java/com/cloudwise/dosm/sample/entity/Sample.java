package com.cloudwise.dosm.sample.entity;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 填写具体类的描述
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:42
 **/
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Sample extends Model implements Serializable {
    /**
     * id
     */
    private String id;

    /**
     * 描述
     */
    private String desc;
}
