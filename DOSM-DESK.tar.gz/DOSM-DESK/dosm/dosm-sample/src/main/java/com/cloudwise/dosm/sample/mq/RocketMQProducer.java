package com.cloudwise.dosm.sample.mq;

import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

@Service
public class RocketMQProducer {

	@Autowired
	private RocketMQTemplate rocketMQTemplate;
	
	private Integer messageTimeOut = 3000;

	/**
	 * 发送普通消息
	 */
	public void sendMsg(String msgBody) {
		
		rocketMQTemplate.syncSend("queue_test_topic", MessageBuilder.withPayload(msgBody).build());
	}

	/**
	 * 发送异步消息 在SendCallback中可处理相关成功失败时的逻辑
	 */
	public void sendAsyncMsg(String msgBody) {
		rocketMQTemplate.asyncSend("queue_test_topic", MessageBuilder.withPayload(msgBody).build(), new SendCallback() {
			@Override
			public void onSuccess(SendResult sendResult) {
				// 处理消息发送成功逻辑
			}

			@Override
			public void onException(Throwable e) {
				// 处理消息发送异常逻辑
			}
		});
	}

	/**
	 * 发送带tag的消息,直接在topic后面加上":tag"
	 */
	public void sendTagMsg(String msgBody) {
		rocketMQTemplate.syncSend("queue_test_topic:tag1", MessageBuilder.withPayload(msgBody).build());
	}

}
