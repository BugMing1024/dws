package com.cloudwise.dosm.sample.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloudwise.dosm.sample.dao.SampleMapper;
import com.cloudwise.dosm.sample.entity.Sample;
import com.cloudwise.dosm.sample.service.SampleService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 样例service实现类
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:12
 **/
@Service
public class SampleServiceImpl  extends ServiceImpl<SampleMapper, Sample> implements SampleService {
    @Override
    public Sample getOne(String id) {
        return new Sample();
    }

    @Override
    public List<Sample> getSampleList(Sample sampleQuery) {
        return null;
    }
}
