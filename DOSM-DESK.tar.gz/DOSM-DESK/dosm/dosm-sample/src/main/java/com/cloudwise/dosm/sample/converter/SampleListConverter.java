package com.cloudwise.dosm.sample.converter;

import com.cloudwise.dosm.core.converter.BaseEntity2RespVoConverter;
import com.cloudwise.dosm.core.converter.BaseReqVo2EntityConverter;
import com.cloudwise.dosm.sample.entity.Sample;
import com.cloudwise.dosm.sample.vo.SampleListRequestVo;
import com.cloudwise.dosm.sample.vo.SampleListResponseVo;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

/**
 * Sample列表查询实体转换服务类
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:38
 **/
@Mapper(componentModel = "spring",builder = @Builder(disableBuilder = true))
public interface SampleListConverter extends BaseReqVo2EntityConverter<SampleListRequestVo, Sample>, BaseEntity2RespVoConverter<Sample, SampleListResponseVo> {
}
