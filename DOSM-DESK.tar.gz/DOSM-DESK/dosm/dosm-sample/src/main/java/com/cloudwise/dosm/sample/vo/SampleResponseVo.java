package com.cloudwise.dosm.sample.vo;

import lombok.Data;

/**
 * 填写具体类的描述
 *
 * @author: jensen.xu
 * @since: 2021-06-04 21:37
 **/
@Data
public class SampleResponseVo {
}
