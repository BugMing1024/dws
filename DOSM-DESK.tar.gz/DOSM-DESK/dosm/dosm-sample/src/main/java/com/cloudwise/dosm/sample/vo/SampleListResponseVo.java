package com.cloudwise.dosm.sample.vo;

import java.io.Serializable;

/**
 * 填写具体类的描述
 *
 * @author: jensen.xu
 * @since: 2021-06-25 10:40
 **/
public class SampleListResponseVo implements Serializable {
}
