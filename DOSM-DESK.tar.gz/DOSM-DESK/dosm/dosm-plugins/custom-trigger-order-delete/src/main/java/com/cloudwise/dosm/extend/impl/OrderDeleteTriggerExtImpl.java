package com.cloudwise.dosm.extend.impl;

import com.cloudwise.dosm.api.adv.extend.ITriggerExt;
import com.cloudwise.dosm.api.bean.instance.entity.WorkOrderBean;
import com.cloudwise.dosm.api.bean.trigger.entity.ResultBean;
import com.cloudwise.dosm.bpm.api.adv.extend.InnerExtendConfig;
import com.cloudwise.dosm.bpm.extension.advanced.service.INoticeExternalService;
import com.cloudwise.dosm.bpm.extension.advanced.vo.WorkOrderInfoBo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.annotation.Resource;

/**
 * 处理人改变触发器扩展类
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/18
 */
@Slf4j
@InnerExtendConfig(id = "order-delete-trigger-notice", name = "工单删除通知事件中心", desc = "工单删除通知事件中心")
public class OrderDeleteTriggerExtImpl implements ITriggerExt {

    @Resource
    private INoticeExternalService noticeService;

    /**
     * 触发器扩展调用方法
     *
     * @param workOrder 工单相关信息
     * @param result    触发器执行结果信息
     */
    @Override
    public void handler(WorkOrderBean workOrder, ResultBean result) {
        try {
            log.info("[order-delete-trigger-notice(工单删除通知事件中心)] start, workOrderId: {}", workOrder.getId());
            WorkOrderInfoBo bo = WorkOrderInfoBo.builder()
                    .accountId(workOrder.getAccountId())
                    .orderId(workOrder.getId())
                    .build();

            log.info("[order-delete-trigger-notice(工单删除通知事件中心)] start, Request: {}", bo);
            // 处理人变化通知事件中心
            noticeService.deleteOrderNotice(bo);
            log.info("[handler-change-trigger-notice(事件处理人改变通知事件中心)] end.");
        } catch (Exception e) {
            log.info("[order-delete-trigger-notice(工单删除通知事件中心)] found ERROR, error: {}",
                    ExceptionUtils.getStackTrace(e));
        }
    }

}
