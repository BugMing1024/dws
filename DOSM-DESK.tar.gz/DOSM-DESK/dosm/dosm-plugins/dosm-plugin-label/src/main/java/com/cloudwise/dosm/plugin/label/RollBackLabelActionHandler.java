package com.cloudwise.dosm.plugin.label;

import com.cloudwise.dosm.bpm.api.action.AbstractActionHandler;
import com.cloudwise.dosm.bpm.api.action.annotation.ActionHandlerType;
import com.cloudwise.dosm.bpm.api.action.entity.EventMessage;
import com.cloudwise.dosm.bpm.api.action.enums.EventTypeEnum;
import com.cloudwise.dosm.bpm.api.action.enums.FilterModeEnum;
import com.cloudwise.dosm.plugin.label.service.RollBackLabelService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Map;

/**
 * @description: 回退/驳回打标签
 * @author: Janet
 * @create: 2022-09-05 14:11
 **/
@Component
@ActionHandlerType(filterMode = FilterModeEnum.PART, eventTypes = {EventTypeEnum.WORK_COMMIT,
        EventTypeEnum.WORK_ROLLBACK,EventTypeEnum.WORK_CLOSE})
@Slf4j
public class RollBackLabelActionHandler extends AbstractActionHandler {

    @Autowired
    private ApplicationContext applicationContext;

    @Override
    public void execute(EventMessage eventMessage) {

        log.info("回退/驳回消息接收：{}",eventMessage.toString());

        //调用处理方法
        Map<String, RollBackLabelService> beansOfType = applicationContext.getBeansOfType(RollBackLabelService.class);
        if (MapUtils.isNotEmpty(beansOfType)){
            beansOfType.forEach((name,jobService) -> {
                String serviceName = name.substring(0, name.length()-16).toUpperCase(Locale.ROOT);
                String eventType = eventMessage.getEventType().replace("_", "");
                log.info("RollBackLabelActionHandler类型：{},{}",serviceName,eventType);
                if(eventType.equals(serviceName)){
                    jobService.handle(eventMessage);
                }
            });
        }

    }
}
