package com.cloudwise.dosm.plugin.label.enums;

import java.util.Arrays;

public enum MdlInstanceBackStatusEnum {

    /**
    * 回退标签
    * */
    BACK("BACK","ROLLBACK","回退"),

    /**
     * 驳回标签
     */
    REJECT("REJECT","APPROVE_REJECT","驳回");

    private String code;
    private String desc;
    private String name;

    MdlInstanceBackStatusEnum(String code,String name,String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static String getCode(String name) {
        MdlInstanceBackStatusEnum mdlInstanceBackStatusEnum = Arrays.stream(MdlInstanceBackStatusEnum.values())
                .filter(btnEnum -> btnEnum.getName().equals(name))
                .findAny().orElse(null);
        if(null == mdlInstanceBackStatusEnum){
            return null;
        }else{
            return mdlInstanceBackStatusEnum.getCode();
        }

    }

}
