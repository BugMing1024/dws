package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Rhyme
 * @date Create in 15:31 2022/5/25
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("自定义视图设置查询对象")
public class DosmQueryViewSettingRequest extends DosmDubboRequest {
    /**
     * 全局视图，0全局，1个人+全局
     */
    @ApiModelProperty(value = "全局视图，0全局，1个人")
    private Integer type;
    private Integer status;
}
