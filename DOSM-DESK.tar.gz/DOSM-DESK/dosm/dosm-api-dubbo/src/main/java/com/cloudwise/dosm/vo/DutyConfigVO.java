package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class DutyConfigVO implements Serializable{

    @ApiModelProperty("主键")
    private String id;

    @ApiModelProperty("值班名称")
    private String name;


}
