package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/9/14 上午11:12
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DosmDataDictRequest extends DosmDubboRequest {

    private String code;
}
