package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

/**
 * 填写具体类的描述
 *
 * @author: turbo.wu
 * @since: 2022-06-21 18:52
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormDataTableTemplate implements Serializable {
    private String rowId;
    private Integer rowNum;
    private Map<String, FormDataTemplate> columnDataMap;
}