package com.cloudwise.dosm.domain.base;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import java.io.Serializable;

import static com.cloudwise.dosm.domain.base.DosmStatusEnum.FAIL;
import static com.cloudwise.dosm.domain.base.DosmStatusEnum.SUCCESS;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.ALWAYS;

/**
 * DOSM dubbo response
 *
 * @author: abell.wu
 * @since: 2021-09-28 09:47
 **/
@Data
public class DosmDubboResponse<T> implements Serializable {

    public static final String LANGUAGE = "language";
    public static final String EN = "en";
    public static final String ZH_ERROR_MESSAGE = "无权获取用户信息";
    public static final String EN_ERROR_MESSAGE = "You have no permissions to obtain the user information";
    public static final ThreadLocal<String> TRACE_ID_THREAD_LOCAL = new ThreadLocal<>();
    public static final String NO_TRACE_ID = "no_traceId";
    public static final int SUCCESS_CODE = 100000;
    public static final int FAIL_CODE = 100001;

    protected DosmStatusEnum status;
    protected String msg;
    protected Integer code;
    private Long rtnTime=System.currentTimeMillis();

    @JsonInclude(ALWAYS)
    private T data;

    public Boolean isSuccess() {
        return code == 100000;
    }

    public DosmDubboResponse(DosmStatusEnum status, Integer code, T data) {
        this.code = code;
        this.setData(data);
        this.status = status;
    }

    public DosmDubboResponse(DosmStatusEnum fail, Integer code, String msg, T data) {
        this.status = fail;
        this.code = code;
        this.msg = msg;
        this.setData(data);
    }

    public DosmDubboResponse(DosmStatusEnum status, Integer code, String msg) {
        this.status = status;
        this.msg = msg;
        this.code = code;
    }


    public static <T> DosmDubboResponse<T> success(T data) {
        return new DosmDubboResponse<>(SUCCESS, SUCCESS_CODE, data);
    }

    public static <T> DosmDubboResponse<T> success(T data, String msg) {
        return new DosmDubboResponse<>(SUCCESS, SUCCESS_CODE, msg, data);
    }

    public static DosmDubboResponse fail(String msg) {
        return new DosmDubboResponse(FAIL, FAIL_CODE, msg, msg);
    }

    public static DosmDubboResponse fail(int code, String msg) {
        return new DosmDubboResponse(FAIL, code, msg, msg);
    }

}
