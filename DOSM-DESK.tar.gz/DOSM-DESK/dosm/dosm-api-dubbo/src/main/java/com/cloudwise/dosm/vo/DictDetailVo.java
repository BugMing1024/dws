package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Isaiah.Wang
 * @date 2021年06月15日 下午5:16
 */
@ApiModel(value = "数据字典详情显示参数", description = "数据字典详情前端显示字段")
@Data
public class DictDetailVo implements Serializable {

    /**
     * 数据字典子表id
     */
    @ApiModelProperty(value = "数据字典详情主键（string类型）")
    private String id;

    /**
     * 账户id
     */
    @ApiModelProperty(value = "账户主键（string类型）")
    private String accountId;

    /**
     * 顶级账户id
     */
    @ApiModelProperty(value = "顶级账户主键（string类型）")
    private String topAccountId;

    /**
     * 数据字典表id
     */
    @ApiModelProperty(value = "数据字典主键（string类型）")
    private String dictId;

    /**
     * 标签
     */
    @ApiModelProperty(value = "标签（string类型）")
    private String label;

    /**
     * 数据集
     */
    @ApiModelProperty(value = "数据集（string类型）")
    private String data;

    /**
     * 父节点
     */
    @ApiModelProperty(value = "父节点主键（string类型）")
    private String parentId;
    /**
     * 父节点
     */
    @ApiModelProperty(value = "来自导入的父节点主键（string类型）")
    private String excelParentId;
    /**
     * 层级
     */
    @ApiModelProperty(value = "层级（int类型）")
    private Integer level;

    /**
     * 子节点
     */
    @ApiModelProperty(value = "数据字典详情子节点（list类型）")
    private List<DictDetailVo> children;
    /**
     * 是否可改变 0 可改变，1不可改变
     */
    @ApiModelProperty(value = "是否可变")
    private Integer canChange;
    /**
     * 是否可改变 0 可改变，1不可改变
     */
    @ApiModelProperty(value = "是否可变")
    private Boolean isImport = false;
}
