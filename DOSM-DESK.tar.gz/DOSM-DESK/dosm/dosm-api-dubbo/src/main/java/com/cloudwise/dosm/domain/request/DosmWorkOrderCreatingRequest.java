package com.cloudwise.dosm.domain.request;


import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Getter;
import lombok.Setter;

/**
 * @author: abell.wu
 * @since: 2021-09-28 09:39
 **/
public class DosmWorkOrderCreatingRequest extends DosmDubboRequest {

    /**
     * 工单流程key
     */
    @Setter
    @Getter
    private String processDefkey;


    public DosmWorkOrderCreatingRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
    }

    public DosmWorkOrderCreatingRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String language) {
        super(userId, accountId, topAccountId, currentPage, pageSize, language);
    }

    public DosmWorkOrderCreatingRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String language, String processDefkey) {
        super(userId, accountId, topAccountId, currentPage, pageSize, language);
        this.processDefkey = processDefkey;
    }

}
