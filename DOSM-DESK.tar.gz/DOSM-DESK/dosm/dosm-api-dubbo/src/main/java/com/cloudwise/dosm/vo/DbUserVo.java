package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * amos
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DbUserVo implements Serializable, Cloneable {
    protected String id;
    private String accountId;
    private String name;
    private String mobile;
    private String email;
    private String status;
    private String roleId;
    private List<String> roleIds;
    private String deletedFlag;
    private String userId;
    private String weChat;
    private String telephone;
    private String departmentId;
    private String departmentName;
    private String departmentLevel;
    private List<SimpleRoleVo> roleList;
    private String dingtalkAccount;
    private String workgroup;
    /**
     * 用户是否为VIP用户
     */
    private boolean vip;

    /**
     * 职位
     */
    private String position;
    /**
     * 工位
     */
    private String region;
    /**
     * 用户名
     */
    private String userAlias;

    /**
     * 用户组id
     */
    private List<String> groupIds;
    /**
     * douc扩展字段
     */
    private List<UserExtendVo> extend;

    /**
     * sso 1为启动2为停用
     */
    public static final String SSO_DISABLED_USER = "2";
    public static final String SSO_ABLE_USER = "1";



}
