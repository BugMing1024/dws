package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 数据字典(DataDict)Vo类
 *
 * @author ming.ma
 * @since 2021-06-15 16:48:31
 */
@ApiModel(value = "数据字典显示参数", description = "数据字典前端显示字段")
@Data
public class DataDictVo implements Serializable{

    /**
     * 数据字典id
     */
    @ApiModelProperty(value = "数据字典主键（string类型）")
    private String id;

    /**
     * 数据字典编码
     */
    @ApiModelProperty(value = "数据字典编码（string类型）")
    private String dictCode;

    /**
     * 层级
     */
    @ApiModelProperty(value = "层级（int类型）")
    private Integer level;

    /**
     * 数据字典名称
     */
    @ApiModelProperty(value = "数据字典名称（string类型）")
    private String dictName;

    /**
     * 字典说明
     */
    @ApiModelProperty(value = "字典说明（string类型）")
    private String caption;

    /**
     * 判断是否内置，INSIDE内置，MYSELF自定义
     */
    @ApiModelProperty(value = "内置状态（string类型）")
    private String dictType;

    /**
     * 更新字典用户id
     */
    @ApiModelProperty(value = "修改人主键（string类型）")
    private String updatedBy;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "修改时间（date类型）")
    private Date updatedTime;

    /**
     * 数据字典属性内容信息
     */
    @ApiModelProperty(value = "数据字典属性内容信息（list类型）")
    private List<DictDetailVo> fieldContent;

}
