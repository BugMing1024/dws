package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

/**
 * 数据字典编辑结果
 * @author jon.lee
 * @since 2022-11-29 17:20
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataDictEditResultVo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 字典id
     */
    private String dictId;

    /**
     * 参数id与入库id的映射
     */
    private Map<String, String> insertIdMapping;

}
