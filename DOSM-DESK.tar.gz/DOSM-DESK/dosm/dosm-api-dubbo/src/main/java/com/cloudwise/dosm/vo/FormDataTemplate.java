package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * formData模版
 *
 * @author: turbo.wu
 * @since: 2022-06-21 13:37
 *
 * formData模版主要用于外部进行调用工单创建接口时
 * formData的封装非常麻烦，
 * 在创建工单时，外部可以先调用 根据流程名查询流程详细信息{@link com.cloudwise.dosm.desk.controller.DosmOpenApiController#getProcessInfoByName(java.lang.String)}
 * 拿到formData模版后，直接修改fieldValue，填入自己的值就可以
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormDataTemplate implements Serializable {
    private String fieldCode;
    private String fieldName;
    private String fieldType;
    private Object fieldValue;
}