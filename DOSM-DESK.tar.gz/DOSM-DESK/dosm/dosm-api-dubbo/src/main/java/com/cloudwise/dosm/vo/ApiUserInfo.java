package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ming.ma
 * @since 2024-03-08  17:02
 **/
@Data
@ApiModel(value = "ApiUserInfo ", description = "用户对象")
@NoArgsConstructor
public class ApiUserInfo implements Serializable {
    @ApiModelProperty(value = "用户id", name = "userId", example = "237517")
    private String userId;

    @ApiModelProperty(value = "姓名", name = "userName", example = "明明")
    private String userName;

    @ApiModelProperty(value = "用户名/登录名", name = "userAlias", example = "ming")
    private String userAlias;

    public ApiUserInfo(DubboUserInfo userInfo) {
        this.userId = userInfo.getUserId();
        this.userName = userInfo.getName();
        this.userAlias = userInfo.getUserAlias();
    }
}
