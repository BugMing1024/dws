package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * 下一节点的需要弹窗的结构，包括网关
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/3/10
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApiNodeAssignDto implements Serializable {

    /**
     * 节点信息
     */
    private List<ApiNodeInfoVo> nodeInfoVoList;

    /**
     * 是否需要弹窗
     */
    private boolean manualFlag;

}
