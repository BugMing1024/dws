package com.cloudwise.dosm.domain.request;


import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * @author: abell.wu
 * @since: 2021-09-28 09:39
 **/
public class DosmWorkOrderRequest extends DosmDubboRequest {

    /**
     * 工单id
     */
    private String workOrderId;

    public DosmWorkOrderRequest(String workOrderId) {
        this.workOrderId = workOrderId;
    }

    public DosmWorkOrderRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String workOrderId) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.workOrderId = workOrderId;
    }

    public DosmWorkOrderRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String language, String workOrderId) {
        super(userId, accountId, topAccountId, currentPage, pageSize, language);
        this.workOrderId = workOrderId;
    }


    public String getWorkOrderId() {
        return workOrderId;
    }

    public void setWorkOrderId(String workOrderId) {
        this.workOrderId = workOrderId;
    }
}
