package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>
 * </p>
 *
 * @author rentingji
 * @date 2022/2/15 下午2:42
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class DosmOrderRequest extends DosmDubboRequest {

    /** 工单ID, 如: list["11", "22"] */
    private List<String> workOrderIdArray;
}
