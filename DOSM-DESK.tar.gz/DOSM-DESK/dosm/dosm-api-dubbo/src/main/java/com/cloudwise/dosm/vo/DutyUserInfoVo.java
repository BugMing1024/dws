package com.cloudwise.dosm.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author Kelvin.Wang
 * @date 2022-04-05 10:45 上午
 * @description
 */
@Data
public class DutyUserInfoVo implements Serializable {
    private String userId;
    private String userName;
    private String userAlias;

    private String linkStr;

    public String getLinkStr() {
        return userId + userName + linkStr;
    }

    public void setLinkStr(String linkStr) {
        this.linkStr = linkStr;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DutyUserInfoVo that = (DutyUserInfoVo) o;
        return Objects.equals(linkStr, that.linkStr);
    }

    @Override
    public int hashCode() {
        return Objects.hash(linkStr);
    }
}
