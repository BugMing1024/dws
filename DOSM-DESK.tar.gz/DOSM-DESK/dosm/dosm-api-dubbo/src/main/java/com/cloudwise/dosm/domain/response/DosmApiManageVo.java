package com.cloudwise.dosm.domain.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @author ming.ma
 * @since 2022/11/29 上午11:39
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "Api管理模块实体类")
public class DosmApiManageVo extends DubboBaseModel{

    @ApiModelProperty(value = "接口id")
    private String id;

    @ApiModelProperty(value = "接口分类id")
    private String apiGroupId;

    @ApiModelProperty(value = "接口分类名称")
    private String apiGroupName;

    @ApiModelProperty(value = "接口分类枚举值")
    private String apiGroupEnum;

    @ApiModelProperty(value = "接口名称")
    private String apiName;

    @ApiModelProperty(value = "url路径")
    private String urlPath;

    @ApiModelProperty(value = "url路径参数")
    private List<DosmApiParamVo> urlParamSetting;

    @ApiModelProperty(value = "请求方式:GET、POST、PUT")
    private String requestMode;

    @ApiModelProperty(value = "请求body")
    private DosmApiBodyVo body;

    @ApiModelProperty(value = "请求query")
    private List<DosmApiParamVo> query;

    @ApiModelProperty(value = "请求头")
    private List<DosmApiParamVo> headers;

    @ApiModelProperty(value = "返回结果")
    private DosmApiParamVo resultBody;

    @ApiModelProperty(value = "0-启用，1-停用")
    private Integer status;

    @ApiModelProperty(value = "地址栏参数")
    private Map<String,Object> urlParams;

}
