package com.cloudwise.dosm.domain.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ming.ma
 * @since 2022/11/29 上午11:39
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "Api管理模块请求参数实体类")
public class DosmApiParamVo implements Serializable {

    @ApiModelProperty(value = "id")
    private String id;

    @ApiModelProperty(value = "参数名称")
    private String paramName;

    @ApiModelProperty(value = "是否必须 true-必须/false-不是")
    private Boolean must = false;

    @ApiModelProperty(value = "参数类型 包括 string、number、array、object、boolean、date、datetime，默认值为 string")
    private String type;

    @ApiModelProperty(value = "描述")
    private String description;

    @ApiModelProperty(value = "默认值")
    private Object defaultValue;

    @ApiModelProperty(value = "子级")
    private List<DosmApiParamVo> children;
}
