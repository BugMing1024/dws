package com.cloudwise.dosm.vo;

import lombok.Data;

@Data
public class Result {
    private String status;

    private String msg;

    private Long code;

    private Object data;
}
