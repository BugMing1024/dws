package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import com.cloudwise.dosm.vo.ApiInstanceCreateVO;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;


/**
 * 创建工单实例需要参数
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/3/8
 */
@Getter
@Setter
@ToString
public class DosmInstanceCreateRequest extends DosmDubboRequest {

    /** 表单信息 */
    private List<ApiInstanceCreateVO> formData;

    /** 来源id */
    private String sourceId;

    /** 流程定义Key */
    private String processKey;

    /** 接入系统的主键 */
    private String eventId;

    /** 拓展字段 */
    private List<JsonNode> extendData;

}
