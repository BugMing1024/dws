package com.cloudwise.dosm.order.transfer;

import com.cloudwise.dosm.domain.request.DosmOrderTransferRequest;
import com.cloudwise.dosm.domain.request.DosmWorkOrderCreateRequest;
import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DosmWorkOrderRequest;
import com.cloudwise.dosm.vo.TaskInfoVo;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author scott 2021/8/25
 */

@RequestMapping("/dosm/dubbo/process/transfer")
public interface DosmProcessTransfer {

    /**
     * 根据工单id和处理人获取表单详情和
     */
    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/getCurrentTaskInfo",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<TaskInfoVo> getCurrentTaskInfo(@RequestBody  DosmWorkOrderRequest request);



    /**
     * 执行转派逻辑
     *
     * @param request
     * @return
     */
    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/doTransfer",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Object> doTransfer(@RequestBody  DosmWorkOrderCreateRequest request);



    @RequestMapping(method = RequestMethod.POST, value = "/orderTransfer",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> orderTransfer(@RequestBody  DosmOrderTransferRequest request);




}
