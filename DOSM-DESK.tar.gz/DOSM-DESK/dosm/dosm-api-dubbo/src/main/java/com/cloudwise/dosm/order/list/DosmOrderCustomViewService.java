package com.cloudwise.dosm.order.list;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.WorkOrderQueryInputRequest;
import com.cloudwise.dosm.vo.MdlInstanceCustomViewVo;
import com.cloudwise.dosm.vo.PageVO;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author ming.ma
 * @since 2022/9/9 下午3:41
 **/
@RequestMapping("/dosm/dubbo/customView")
public interface DosmOrderCustomViewService {


    @RequestMapping(method = RequestMethod.POST, value = "/getCustomViewOrderList",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<PageVO<MdlInstanceCustomViewVo>> getCustomViewOrderList(@RequestBody  WorkOrderQueryInputRequest request);



}