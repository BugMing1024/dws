package com.cloudwise.dosm.domain.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 数据字典更新参数
 * @author jon.lee
 * @date 2022-11-24 18:16
 */
@ApiModel(value = "数据字典更新参数", description = "数据字典更新参数")
@Data
public class DataDictEditRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 数据字典id
     */
    @ApiModelProperty(value = "数据字典主键（string类型）", example = "b8104d3de2534f898e8df131f5775ca1", required = true)
    private String id;
    /**
     * 乐观锁
     */
    @ApiModelProperty(value = "乐观锁", required = true)
    private Integer revision;
    /**
     * 数据字典编码
     */
    @ApiModelProperty(value = "数据字典编码（string类型）", example = "TTUY66778899", required = true)
    private String dictCode;
    /**
     * 层级
     */
    @ApiModelProperty(value = "层级（int类型）", example = "1")
    private Integer level;
    /**
     * 数据字典名称
     */
    @ApiModelProperty(value = "数据字典名称（string类型）", example = "厂家测试")
    private String dictName;
    /**
     * 字典说明
     */
    @ApiModelProperty(value = "数据字典说明（string类型）", example = "你好")
    private String caption;
    /**
     * 选项是否开启颜色
     */
    @ApiModelProperty(value = "选项是否开启颜色", example = "true")
    private boolean useColor;
    /**
     * 数据字典新增项
     */
    @ApiModelProperty(value = "数据字典新增项（list类型）")
    private List<DataDictDetailEditRequest> insertObjects;
    /**
     * 数据字典修改项
     */
    @ApiModelProperty(value = "数据字典修改项（list类型）")
    private List<DataDictDetailEditRequest> updateObjects;
    /**
     * 数据字典删除项
     */
    @ApiModelProperty(value = "数据字典删除项（list类型）")
    private List<DataDictDetailEditRequest> deleteObjects;


}
