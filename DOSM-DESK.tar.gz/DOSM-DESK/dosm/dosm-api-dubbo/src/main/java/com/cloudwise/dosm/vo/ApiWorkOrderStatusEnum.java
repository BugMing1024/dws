package com.cloudwise.dosm.vo;


/**
 * 工单状态枚举类
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/23
 */
public enum ApiWorkOrderStatusEnum {

    PENDING(0, "PENDING", "待处理"),
    PROCESSING(10, "PROCESSING", "处理中"),
    CLOSED(20, "CLOSED", "已解决");

    private int code;
    private String value;
    private String desc;

    ApiWorkOrderStatusEnum(int code, String value, String desc) {
        this.code = code;
        this.value = value;
        this.desc = desc;
    }

    public static ApiWorkOrderStatusEnum ofNullable(int code) {
        // 10 待领取
        if (isContain(10, code)) {
            return ApiWorkOrderStatusEnum.PENDING;
        }
        // [0, 50] 处理中
        else if (isContain(new int[]{0, 50}, code)) {
            return ApiWorkOrderStatusEnum.PROCESSING;
        }
        // [-10, 20, 30, 40] 已解决
        else {
            return ApiWorkOrderStatusEnum.CLOSED;
        }
    }

    public static boolean isContain(int num, int target) {
        return num == target;
    }

    public static boolean isContain(int[] nums, int target) {
        if (nums == null || nums.length == 0) {
            return false;
        }
        for (int num : nums) {
            if (num == target) {
                return true;
            }
        }
        return false;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
