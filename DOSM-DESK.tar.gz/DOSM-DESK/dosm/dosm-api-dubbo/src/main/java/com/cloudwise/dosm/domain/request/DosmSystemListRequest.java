package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Data;

/**
 * @Author dylan.qin
 * @Since: 2023-08-15 15:18
 */
@Data
public class DosmSystemListRequest extends DosmDubboRequest {

    private String name;

    private Integer state;

    private String groupId;

    private String searchKey;

    private int currentPage;

    private int pageSize;
}
