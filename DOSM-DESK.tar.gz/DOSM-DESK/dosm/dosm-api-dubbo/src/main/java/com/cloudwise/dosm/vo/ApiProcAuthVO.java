package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * doem流程权限校验信息
 *
 * @author: turbo.wu
 * @since: 2022-08-24 18:19
 **/
@Data
public class ApiProcAuthVO implements Serializable {

    private static final long serialVersionUID = 3374255681045960555L;

    @ApiModelProperty(value = "用户流程权限校验结果")
    private ProcAuthEnum authResult;

    public ApiProcAuthVO(ProcAuthEnum authResult) {
        this.authResult = authResult;
    }

    public ApiProcAuthVO() {}
}