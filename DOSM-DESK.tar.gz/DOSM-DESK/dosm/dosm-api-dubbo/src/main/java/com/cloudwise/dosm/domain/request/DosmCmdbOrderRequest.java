package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author dylan.qin
 * @Since: 2022-04-06 15:20
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("cmdb配置项工单列表请求参数")
public class DosmCmdbOrderRequest extends DosmDubboRequest implements Serializable {
    @ApiModelProperty(value = "模型ID", example = "xxx", required = true)
    private String  modelId;
    @ApiModelProperty(value = "当前页码", example = "1", required = true)
    private Integer pageNum;
    @ApiModelProperty(value = "配置项Id", example = "xxx", required = true)
    private String  ciId;
    @ApiModelProperty(value = "工单类型", example = "xxx", required = false)
    private String  type;

    @ApiModelProperty(value = "流程名称")
    private String processName;

    @ApiModelProperty(value = "任务状态", example = "0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭 50 挂起", required = false)
    private Integer dataStatus;
    @ApiModelProperty(value = "更新开始时间", example = "10位时间戳", required = false)
    private Long  startTime;
    @ApiModelProperty(value = "更新结束时间", example = "10位时间戳", required = false)
    private Long  endTime;

    /**
     * 页大小
     */
    private int pageSize;
}
