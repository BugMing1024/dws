package com.cloudwise.dosm.domain.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @description:
 * @author: Janet
 * @create: 2022-11-29 15:02
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DosmSystemClassifyVo extends DubboBaseModel implements Serializable {

    @ApiModelProperty("ID")
    private String id;

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("描述")
    private String remark;

    @ApiModelProperty("系统模板")
    private String apiTemplateId;

    @ApiModelProperty("鉴权")
    private String authenticationId;

    @ApiModelProperty("服务器地址")
    private String serverPath;

    @ApiModelProperty("父级ID")
    private String parentId;

    @ApiModelProperty("类型 0-内置 1-自定义")
    private Integer state;

    @ApiModelProperty("子集")
    private List<DosmSystemClassifyVo> children;

}
