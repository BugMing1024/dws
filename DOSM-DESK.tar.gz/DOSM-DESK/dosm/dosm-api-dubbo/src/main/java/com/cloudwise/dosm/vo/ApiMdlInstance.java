package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 流程实例VO
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/3/8
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiMdlInstance implements Serializable {
    /**
     * 主键ID
     */
    private String id;
    /**
     * 顶级租户ID
     */
    private String topAccountId;
    /**
     * 租户ID
     */
    private String accountId;
    /**
     * 模型编码
     */
    private String mdlDefCode;
    /**
     * 模型定义def_key
     */
    private String mdlDefKey;
    /**
     * 流程实例ID
     */
    private String processInstanceId;
    /**
     * 归属服务目录列表
     */
    private String serviceIds;

    /**
     * 标题
     */
    private String title;
    /**
     * 工单编号
     */
    private String bizKey;
    /**
     * 业务描述
     */
    private String bizDesc;
    /**
     * 优先级 0低,1中,2高,紧急
     */
    private long urgentLevel;
    /**
     * 是否测试 0否,1是
     */
    private long isTest;
    /**
     * 工单来源
     */
    private String sourceId;
    /**
     * 状态 0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭  50 挂起
     */
    private int dataStatus;
    /**
     * 催办时间
     */
    private Timestamp urgedTime;
    /**
     * 表单业务数据
     */
    private Object formData;
    /**
     * 计划开始时间
     */
    private Timestamp planStartTime;
    /**
     * 计划结束时间
     */
    private Timestamp planEndTime;
    /**
     * 乐观锁
     */
    private long revision;
    /**
     * 创建人ID
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Timestamp createdTime;
    /**
     * 修改人ID
     */
    private String updatedBy;
    /**
     * 修改时间
     */
    private Timestamp updatedTime;
    /**
     * 指派用户
     */
    private Object appointUser;
    /**
     * 0有效1删除
     */
    private long isDel;
    /**
     * 节点id
     */
    private String nodeId;
    /**
     * taskId
     */
    private String taskId;
    /**
         * code 是否逾期  逾期 OVERDUE  即将逾期 WILL_OVERDUE
     */
    private String code;
    /**
     * 服务项ID
     */
    private String serviceItemId;
}
