package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ming.ma
 * @since 2022/8/11 下午4:30
 **/
@Data
public class DutyLinkWorkOrderVo implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty(value = "工单ID", example = "")
    private String id;

    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID", example = "")
    private String processInstanceId;

    /**
     * 标题
     */
    @ApiModelProperty(value = "标题", example = "")
    private String title;

    @ApiModelProperty(value = "优先级", example = "0低,1中,2高,3紧急", required = true)
    private long urgentLevel;

    /**
     * 工单编号
     */
    @ApiModelProperty(value = "工单编号", example = "")
    private String bizKey;

    @ApiModelProperty(value = "模型编码", example = "", required = true)
    private String mdlDefCode;

    @ApiModelProperty(value = "模型定义def_key", example = "", required = true)
    private String mdlDefKey;

    @ApiModelProperty(value = "工单状态", example = "")
    private Integer dataStatus;

    @ApiModelProperty(value = "创建时间", example = "")
    private Date createdTime;
}
