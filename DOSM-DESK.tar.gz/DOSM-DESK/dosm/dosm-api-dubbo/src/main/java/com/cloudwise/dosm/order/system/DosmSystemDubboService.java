package com.cloudwise.dosm.order.system;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.base.PageVo;
import com.cloudwise.dosm.domain.request.DosmApiRunInfoRequest;
import com.cloudwise.dosm.domain.request.DosmSystemListRequest;
import com.cloudwise.dosm.domain.response.DosmApiManageVo;
import com.cloudwise.dosm.domain.response.DosmSystemClassifyVo;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * @Author dylan.qin
 * @Since: 2023-08-15 15:12
 */

@RequestMapping("/dosm/dubbo/system")
public interface DosmSystemDubboService {



    @RequestMapping(method = RequestMethod.POST, value = "/getSystemClassifyList",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<DosmSystemClassifyVo>> getSystemClassifyList(@RequestBody  DosmSystemListRequest request);

    @RequestMapping(method = RequestMethod.POST, value = "/findApis",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<PageVo<DosmApiManageVo>> findApis(@RequestBody   DosmSystemListRequest request);

    @RequestMapping(method = RequestMethod.POST, value = "/saveOrUpdateApi",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> saveOrUpdateApi(@RequestBody   DosmApiManageVo request);

    @RequestMapping(method = RequestMethod.POST, value = "/deleteByIds",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<String>> deleteByIds(@RequestBody   List<String> ids);

    @RequestMapping(method = RequestMethod.POST, value = "/queryById",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<DosmApiManageVo> queryById(@RequestBody   String id);

    @RequestMapping(method = RequestMethod.POST, value = "/runApi",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Object> runApi(@RequestBody   DosmApiRunInfoRequest apiRunInfoParam);

}
