package com.cloudwise.dosm.domain.request;


import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import com.cloudwise.dosm.vo.ApiQueryAssigneeParam;
import lombok.Getter;
import lombok.Setter;

/**
 * 查询流程模版信息
 *
 * @author: abell.wu
 * @since: 2021-09-28 09:39
 **/
public class DosmQueryAssigneeRequest extends DosmDubboRequest {

    /**
     * 查询指派
     */
    @Setter
    @Getter
    private ApiQueryAssigneeParam queryAssigneeParam;


    public DosmQueryAssigneeRequest(String userId, String accountId, String topAccountId,
                                    int currentPage, int pageSize, String language,
                                    ApiQueryAssigneeParam queryAssigneeParam) {
        super(userId, accountId, topAccountId, currentPage, pageSize, language);
        this.queryAssigneeParam = queryAssigneeParam;
    }
}
