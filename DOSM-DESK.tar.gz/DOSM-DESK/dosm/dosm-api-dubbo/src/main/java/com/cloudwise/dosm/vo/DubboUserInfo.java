package com.cloudwise.dosm.vo;

import lombok.Data;

/**
 * <p>
 * </p>
 *
 * @author rentingji
 * @date 2024/5/11 下午3:41
 **/
@Data
public class DubboUserInfo {

    private String userId;
    private String name;
    private String userAlias;



}
