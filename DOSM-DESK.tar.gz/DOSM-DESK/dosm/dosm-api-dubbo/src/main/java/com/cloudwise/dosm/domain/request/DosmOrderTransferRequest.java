package com.cloudwise.dosm.domain.request;
import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import com.cloudwise.dosm.vo.ApiAssigneeInfoBO;
import lombok.Getter;
import lombok.ToString;


/**
 * @author scott 2021/11/25
 */
@ToString
public class DosmOrderTransferRequest extends DosmDubboRequest {

    @Getter
    private String orderId;

    @Getter
    private String originalPerson;

    @Getter
    private ApiAssigneeInfoBO targetPerson;

    @Getter
    private String transferReason;

    /**
     * 非必填，如果传递，则转派指定任务，否则尝试随机转派一个当前处理人的任务
     */
    @Getter
    private String taskId;

    public DosmOrderTransferRequest(String userId, String accountId, String topAccountId,
                                    int currentPage, int pageSize,
                                    String orderId,String originalPerson,
                                    ApiAssigneeInfoBO targetPerson,
                                    String transferReason, String taskId) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.orderId = orderId;
        this.originalPerson = originalPerson;
        this.targetPerson = targetPerson;
        this.transferReason = transferReason;
        this.taskId = taskId;
    }
}
