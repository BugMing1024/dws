package com.cloudwise.dosm.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "OrderServiceCatalogOpenApiVO对外Api服务目录前端显示内容", description = "OrderServiceCatalogOpenApiVO对外Api服务目录前端显示内容")
public class OrderServiceCatalogOpenApiVO implements Serializable {
    private static final long serialVersionUID = -6084537547657021708L;
    /**
     * 主键ID
     */
    @ApiModelProperty(value = "主键ID", example = "123", hidden = true)
    private String id;
    @ApiModelProperty(value = "序号", example = "1")
    private Long sort;

    @ApiModelProperty(value = "目录层级,默认0,最多5", example = "1")
    private Integer level;

    @ApiModelProperty(value = "父ID", example = "0")
    private String parentId;

    @ApiModelProperty(value = "父名称", example = "zhangsan")
    private String parentName;

    @ApiModelProperty(value = "服务目录名称", example = "服务目录名称")
    private String name;

    @ApiModelProperty(value = "服务目录类型", example = "CUSTOM")
    private String type;

    /**
     * 工单服务目录下的子目录
     */
    @ApiModelProperty(value = "服务目录子目录")
    private List<OrderServiceCatalogOpenApiVO> childrenList = null;
    @ApiModelProperty(value = "服务模型ID列表", example = "[1,2]")
    private List<String>                orderModelIdList;

    /**
     * 服务目录下对应的工单模型
     */
    @ApiModelProperty(value = "服务目录模型列表")
    private List<WorkOrderModelOpenApiVO> tileModelList = new LinkedList<>();
}
