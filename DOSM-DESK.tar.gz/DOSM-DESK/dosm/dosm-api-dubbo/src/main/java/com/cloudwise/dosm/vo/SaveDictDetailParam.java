package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SaveDictDetailParam {
    private String dictCode;
    private String data;
    private String label;
    private String parentId;
    private String id;
    @ApiModelProperty(value = "操作人人id（string类型）", example = "2")
    private String operatId;
    /**
     * 账户id
     */
    @ApiModelProperty(value = "账户id（string类型）", example = "110")
    private String accountId;
    /**
     * 顶级账户id
     */
    @ApiModelProperty(value = "顶级账户id（string类型）", example = "110")
    private String topAccountId;
}
