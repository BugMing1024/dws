package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 *
 * douc扩展字段
 */
@Data
public class UserExtendVo implements Serializable {
    @ApiModelProperty("扩展字段id")
    private String extendId;

    @ApiModelProperty("是否必须")
    private boolean isMust;

    @ApiModelProperty("数据类型")
    private String dataType;

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("别名")
    private String alias;
    private String value;

}
