package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DosmCatalogRequest extends DosmDubboRequest {
    /**
     *服务目录名称
     */
    private String catalogName;
    /**
     *服务项名称或者描述
     */
    private String serviceOrDescName;


    private  Map<String, String> headers;
}
