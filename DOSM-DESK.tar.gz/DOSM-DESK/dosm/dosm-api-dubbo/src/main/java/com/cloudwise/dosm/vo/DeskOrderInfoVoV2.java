package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * </p>
 *
 * @author rentingji
 * @date 2022/2/19 下午4:24
 **/
@Data
public class DeskOrderInfoVoV2 implements Serializable {
    private String id;
    @ApiModelProperty(value="工单编号", example = "", required = true)
    private String label;
    @ApiModelProperty(value="题目", example = "", required = true)
    private String title;
    @ApiModelProperty(value="创建时间", example = "", required = true)
    private Long createdTime;
    @ApiModelProperty(value="工单状态", example = "", required = true)
    private String orderStatus;
    @ApiModelProperty(value="优先级", example = "", required = true)
    private String urgentLevel;
    @ApiModelProperty(value="activiti 实例Id", example = "", required = true)
    private String processInstanceId;
    @ApiModelProperty(value="当前节点名字", example = "", required = true)
    private String nodeName;
    @ApiModelProperty(value="当前处理人", example = "", required = true)
    private String handleName;
    @ApiModelProperty(value="工单状态值", example = "", required = true)
    private Integer orderStatusValue;

}
