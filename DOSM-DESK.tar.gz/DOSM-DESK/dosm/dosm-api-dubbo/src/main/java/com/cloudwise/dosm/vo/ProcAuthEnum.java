package com.cloudwise.dosm.vo;

/**
 * 流程权限校验返回枚举
 *
 * @author: turbo.wu
 * @since: 2022-08-24 10:06
 **/
public enum ProcAuthEnum {
    NOT_AUTH(false, "not_auth", "用户没有流程权限"),
    NOT_NEWEST(false, "not_newest", "流程版本不是最新"),
    TRUE(true, "true", "用户权限校验通过");

    private boolean result;
    private String value;
    private String desc;

    ProcAuthEnum(boolean result, String value, String desc) {
        this.result = result;
        this.value = value;
        this.desc = desc;
    }

    public boolean isResult() {
        return result;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
