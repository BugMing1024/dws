package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 流程节点信息
 *
 * @author: turbo.wu
 * @since: 2022-06-21 13:39
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessNodeApiPo implements Serializable {
    /**
     * 流程id
     */
    private String processId;
    /**
     * 节点id
     */
    private String actNodeId;
    /**
     * 节点名称
     */
    private String actNodeName;
    /**
     * 节点类型
     */
    private String actNodeType;
}