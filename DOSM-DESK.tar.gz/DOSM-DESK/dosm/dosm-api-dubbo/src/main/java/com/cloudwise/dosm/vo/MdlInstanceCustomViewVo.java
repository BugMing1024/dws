package com.cloudwise.dosm.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 业务模型实例VO
 *
 * @author ming.ma
 */
@Data
@JsonIgnoreProperties({"formData", "isDel", "depId", "depLevel", "revision"})
public class MdlInstanceCustomViewVo implements Serializable {
    /**
     * 主键ID
     */
    @ApiModelProperty(value = "主键ID", example = "", required = true)
    private String id;
    /**
     * 租户ID
     */
    @ApiModelProperty(value = "租户ID", example = "", required = true)
    private String accountId;

    @ApiModelProperty(value = "模型编码", example = "", required = true)
    private String mdlDefCode;

    @ApiModelProperty(value = "模型名称", example = "", required = true)
    private String mdlDefName;
    /**
     * 模型定义def_key
     */
    @ApiModelProperty(value = "模型定义def_key", example = "", required = true)
    private String mdlDefKey;
    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID", example = "", required = true)
    private String processInstanceId;

    /**
     * 标题
     */
    @ApiModelProperty(value = "标题", example = "", required = true)
    private String title;
    /**
     * 工单编号
     */
    @ApiModelProperty(value = "工单编号", example = "", required = true)
    private String bizKey;
    /**
     * 业务描述
     */
    @ApiModelProperty(value = "业务描述", example = "", required = true)
    private String bizDesc;
    /**
     * 优先级 0低,1中,2高,3紧急
     */
    @ApiModelProperty(value = "优先级", example = "0低,1中,2高,3紧急", required = true)
    private long urgentLevel;
    /**
     * 是否测试 0否,1是
     */
    @ApiModelProperty(value = "是否测试", example = "0否,1是", required = true)
    private long isTest;
    /**
     * 工单来源
     */
    @ApiModelProperty(value = "工单来源id", example = "工单来源  1 WEB 网页表单 ，2 EMIAL 邮件 3 DOME 监控系统 4 INTELLIGENT_ROBOT 智能机器人 5 WE_CHAT 微信小程序 6 DING_DING 钉钉小程序  7 OA_AUTO 呼叫系统 8 h5 h5  9 ROUTINE_WORK 例行工作", required = true)
    private String sourceId;

    /**
     * 状态 0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭
     */
    @ApiModelProperty(value = "状态", example = "0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭 50 挂起", required = true)
    private Integer dataStatus;
    /**
     * 催办时间
     */
    @ApiModelProperty(value = "催办时间", example = "", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date urgedTime;
    /**
     * 表单业务数据
     */
    @ApiModelProperty(value = "表单业务数据", example = "", required = true)
    private Object formData;

    /**
     * 创建人ID
     */
    @ApiModelProperty(value = "创建人ID", example = "", required = true)
    private String createdBy;

    @ApiModelProperty(value = "创建人名称", example = "")
    private String createByName;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", example = "", required = true)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createdTime;
    /**
     * 修改人ID
     */
    @ApiModelProperty(value = "修改人ID", example = "", required = true)
    private String updatedBy;
    /**
     * 修改人名称
     */
    @ApiModelProperty(value = "修改人名称", example = "")
    private String updatedByName;
    /**
     * 修改时间
     */
    @ApiModelProperty(value = "修改时间", example = "", required = true)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updatedTime;
    /**
     * 0有效1删除
     */
    @ApiModelProperty(value = "是否删除", example = "0有效1删除", required = true)
    private long isDel;
    /**
     * 工单类型
     */
    @ApiModelProperty(value = "工单类型", example = "", required = true)
    private String orderType;

    @ApiModelProperty(value = "自定义列数据", example = "", required = true)
    private List<ApiCustomQueryContentVo> customQueryContentVoList;


    /**
     * 处理人ID
     */
    @ApiModelProperty(value = "处理人ID", example = "", required = true)
    private List<String> handlerPersonIds;

    @ApiModelProperty(value = "处理人名称", example = "", required = true)
    private List<String> handlerPersonNames;

    /**
     * 委托人ID
     */
    @ApiModelProperty(value = "委托人ID", example = "", required = true)
    private List<String> entrustPersonId;

    @ApiModelProperty(value = "委托人", example = "", required = true)
    private List<String> entrustPersonName;

    /**
     * 处理组ID
     */
    @ApiModelProperty(value = "处理组ID", example = "", required = true)
    private List<String> handlerGroupId;

    @ApiModelProperty(value = "处理组名称", example = "", required = true)
    private List<String> handlerGroupIdName;

    @ApiModelProperty(value = "历史处理组ID", example = "", required = true)
    private List<Long> HistoryHandlerGroupIds;

    @ApiModelProperty(value = "历史处理组名称", example = "", required = true)
    private List<String> HistoryHandlerGroupIdsName;

    @ApiModelProperty(value = "历史人处理ID", example = "", required = true)
    private List<Long> HistoryHandlerPersonIds;

    @ApiModelProperty(value = "历史处理人名称", example = "", required = true)
    private List<String> HistoryHandlerPersonIdsName;

    /**
     * 节点名称
     */
    @ApiModelProperty(value = "当前节点名称", example = "", required = true)
    private List<String> currentNodeNames;

    @ApiModelProperty(value = "当前节点类型", example = "", required = true)
    private List<String> currentNodeTypes;

    @ApiModelProperty(value = "当前节点id", example = "", required = true)
    private List<String> currentNodeIds;

    @ApiModelProperty(value = "vip标识", example = "true", required = true)
    private Boolean vip;

    @ApiModelProperty(value = "审批字段是否存在", example = "true", required = true)
    private Boolean approvalFieldExist;


    @ApiModelProperty(value = "是否加签", example = "true", required = true)
    private Boolean signStatus;

    @ApiModelProperty(value = "标签名称", example = "true", required = true)
    private List<String> tagList;

    @ApiModelProperty(value = "sla是否逾期 20 逾期 10 即将逾期 0 未逾期", example = "true", required = true)
    private Integer slaStatus;
    @ApiModelProperty(value = "是否已经被当前工单绑定", example = "false", required = true)
    private Boolean binded = Boolean.FALSE;

    /**
     * 子流程类型
     */
    @ApiModelProperty(value = "子流程类型", example = "false", required = true)
    private String subProcessType;

    @ApiModelProperty(value = "当前节点挂起时长", example = "false", required = true)
    private String hangUpDuration;
    @ApiModelProperty(value = "挂起描述", example = "false", required = true)
    private List<String> hangUpReason;
    private List<String> approvePersonName;
    private List<String> approvePersonIds;

}
