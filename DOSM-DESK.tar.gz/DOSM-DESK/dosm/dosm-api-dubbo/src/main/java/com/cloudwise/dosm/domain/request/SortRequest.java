package com.cloudwise.dosm.domain.request;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author ming.ma
 * @since 2022/4/21
 */
@Data
public class SortRequest implements Serializable {
    private String key;
    private String type;
    private String componentType;
}
