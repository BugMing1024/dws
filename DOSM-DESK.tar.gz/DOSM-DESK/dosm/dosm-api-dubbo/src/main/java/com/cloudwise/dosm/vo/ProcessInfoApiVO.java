package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 流程信息
 *
 * @author rentingji
 * @date 2021/8/27 下午4:52
 **/
@Data
@ApiModel(value = "ProcessInfoApiVO对象 ", description = "流程对外API对象")
@NoArgsConstructor
public class ProcessInfoApiVO implements Serializable {

    @ApiModelProperty(value = "工单模板名字", name = "name", example = "流程1")
    private String name;

    @ApiModelProperty(value = "工单模板id", name = "id", example = "abc")
    private String id;

    @ApiModelProperty(value = "表单id", name = "id", example = "bbb")
    private String formId;

    @ApiModelProperty(value = "模板首节点id", name = "firstNodeId", example = "aaa")
    private String firstNodeId;

    @ApiModelProperty(value = "工单模板pre num", name = "preNum", example = "abc")
    private String preNum;
    @ApiModelProperty(value = "工单模板processId", name = "processId", example = "abc")
    private String processId;

    public ProcessInfoApiVO(String name, String id ,String preNum ,String processId) {
        this.name = name;
        this.id = id;
        this.preNum = preNum;
        this.processId = processId;
    }

}
