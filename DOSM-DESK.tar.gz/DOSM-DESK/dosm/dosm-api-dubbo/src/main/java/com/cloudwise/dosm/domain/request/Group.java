package com.cloudwise.dosm.domain.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class Group implements Serializable, Cloneable {
    //(value = "用户分组id", example = "1")
    private String groupId;

    //(value = "分组名称", example = "1")
    private String groupName;

    @Override
    public Group clone() {
        try {
            Group clone = (Group) super.clone();
            return clone;
        } catch(CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
