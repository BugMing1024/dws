package com.cloudwise.dosm.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Kelvin.Wang
 * @date 2022-04-12 2:49 下午
 * @description
 */
@Data
public class DutyUserExtInfo implements Serializable {
    private String accountId;
    private String name;
    private String mobile;
    private String email;
    private String userId;
    private String weChat;
    private String telephone;
    private String departmentId;
    private String departmentName;
    private String departmentLevel;
    private String dingtalkAccount;
    private String workgroup;

    /**
     * 职位
     */
    private String position;
    /**
     * 用户名
     */
    private String userAlias;

    /**
     * 用户组id
     */
    private List<String> groupIds;
}
