package com.cloudwise.dosm.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(value = "对外Api服务目录最外层VO", description = "对外Api服务目录最外层VO")
public class CatalogUserListOpenApiVO {
    List<OrderServiceCatalogOpenApiVO> catalogList;
}
