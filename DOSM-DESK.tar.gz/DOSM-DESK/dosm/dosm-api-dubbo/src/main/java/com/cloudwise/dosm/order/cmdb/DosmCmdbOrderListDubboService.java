package com.cloudwise.dosm.order.cmdb;


import com.cloudwise.dosm.domain.base.PageVo;
import com.cloudwise.dosm.domain.request.DosmCmdbOrdeListView;
import com.cloudwise.dosm.domain.request.DosmCmdbOrderRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @Author dylan.qin
 * @Since: 2022-09-27 17:54
 */

@RequestMapping("/dosm/dubbo/cmdb/order")
public interface DosmCmdbOrderListDubboService {

     @RequestMapping(method = RequestMethod.POST, value = "/pageList",consumes = MediaType.APPLICATION_JSON_VALUE)
     PageVo<DosmCmdbOrdeListView> pageList(@RequestBody  DosmCmdbOrderRequest cmdbOrderRequest);
}
