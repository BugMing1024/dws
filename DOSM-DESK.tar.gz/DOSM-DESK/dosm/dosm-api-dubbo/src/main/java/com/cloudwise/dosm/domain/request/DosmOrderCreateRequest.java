package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.vo.ApiOrderCreateVo;
import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author scott 2021/11/4
 */
@Getter
@Setter
@ToString
public class DosmOrderCreateRequest extends DosmDubboRequest {

    private static final long serialVersionUID = -8431801738488247493L;

    private ApiOrderCreateVo orderCreateVo;

    public DosmOrderCreateRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, ApiOrderCreateVo orderCreateVo) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.orderCreateVo = orderCreateVo;
    }

    public DosmOrderCreateRequest(String userId, String accountId, String topAccountId, ApiOrderCreateVo orderCreateVo) {
        super(userId, accountId, topAccountId);
        this.orderCreateVo = orderCreateVo;
    }


}
