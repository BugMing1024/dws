package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 流程节点配置信息VO
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/16
 */
@ApiModel("流程节点配置信息")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NodeFormInfoApiVO implements Serializable {

    @ApiModelProperty(value = "必填字段说明", example = "title:工单标题")
    private List<Field> requiredFields;

    @ApiModelProperty(value = "是否存在必填字段没有默认值,true存在,false不存在", example = "true")
    private Boolean requiredFieldsNoDefValue;

    @ApiModel("字段说明")
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Field implements Serializable {
        @ApiModelProperty(value = "字段code", example = "title")
        private String code;

        @ApiModelProperty(value = "字段name", example = "工单标题")
        private String name;
    }

}
