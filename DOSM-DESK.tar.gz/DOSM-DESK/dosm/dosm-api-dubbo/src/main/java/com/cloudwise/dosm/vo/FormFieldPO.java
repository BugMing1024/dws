package com.cloudwise.dosm.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 表单字段信息
 *
 * @author: turbo.wu
 * @since: 2022-06-21 13:29
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormFieldPO implements Serializable {
    private String fieldCode;
    private String fieldName;
    private String fieldValueType;
    private List<String> modelIds;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<FormFieldPO> colFieldList;
}