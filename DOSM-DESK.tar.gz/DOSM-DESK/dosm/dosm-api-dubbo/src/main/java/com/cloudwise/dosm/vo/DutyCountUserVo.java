package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author janet.fu
 * @description 值班次数、值班时长
 * @since 2022/9/21 下午3:02
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DutyCountUserVo implements Serializable {

    @ApiModelProperty("人员")
    private String userId;
    @ApiModelProperty("值班时长")
    private Long dutyTime;
    @ApiModelProperty("值班数量")
    private Integer dutyCount;
    @ApiModelProperty("待值班次数")
    private Integer waitDutyCount;
    @ApiModelProperty("换班次数")
    private Integer changeDutyCount;
}
