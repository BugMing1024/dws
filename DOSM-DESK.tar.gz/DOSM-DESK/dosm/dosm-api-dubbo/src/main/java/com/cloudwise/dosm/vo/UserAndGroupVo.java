package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author: ksana.kong
 * @Date: 2021/7/12 3:03 下午
 * @Description: *
 */

@Data
@NoArgsConstructor
public class UserAndGroupVo implements Serializable {

    @ApiModelProperty("用户ID")
    private String userId;

    @ApiModelProperty("用户组ID")
    private String groupId;

    public UserAndGroupVo(String userId) {
        this.userId = userId;
    }
}
