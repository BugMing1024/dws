package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 分页vo
 * @author ming.ma
 */
@Data
@Accessors(chain = true)
@ApiModel("分页返回对象")
public class PageVO<T> implements Serializable {
    /**
     * 当前页码
     */
    @ApiModelProperty("当前页码")
    private long currentPage;

    /**
     * 每页数据条数
     */
    @ApiModelProperty("每页数据条数")
    private long pageSize;

    /**
     * 总页数
     */
    @ApiModelProperty("总页数")
    private long pages;

    /**
     * 总数据条数
     */
    @ApiModelProperty("总数据条数")
    private long total;

    /**
     * 数据集合
     */
    @ApiModelProperty("数据集合")
    private List<T> records;

    public PageVO() {
        super();
        setRecords(new ArrayList<>());
    }
}
