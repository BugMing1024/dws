package com.cloudwise.dosm.order.list;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DosmCmdbOrderListRequest;
import com.cloudwise.dosm.domain.request.DosmQueryViewSettingRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2022/8/10
 */
@RequestMapping("/dosm/dubbo/list")
public interface ApiDosmWorkOrderListService {

    /**
     * 根据工单id查询
     *
     * @param dosmQueryViewSettingRequest ids
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getCmdbOrderlist",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> getCmdbOrderlist(@RequestBody  DosmCmdbOrderListRequest dosmCmdbOrderListRequest);

}
