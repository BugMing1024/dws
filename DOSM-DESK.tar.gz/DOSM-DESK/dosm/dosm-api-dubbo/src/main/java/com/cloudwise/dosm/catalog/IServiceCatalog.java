package com.cloudwise.dosm.catalog;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DosmCatalogRequest;
import com.cloudwise.dosm.vo.CatalogUserListOpenApiVO;
import com.cloudwise.dosm.vo.DataDictVo;
import com.cloudwise.dosm.vo.ServiceCatalogOpenApiVO;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;


@RequestMapping("/dosm/dubbo/service/catalog")
public interface IServiceCatalog {

    @RequestMapping(method = RequestMethod.POST, value = "/list",  consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<CatalogUserListOpenApiVO>  list(@RequestBody DosmCatalogRequest request );
}
