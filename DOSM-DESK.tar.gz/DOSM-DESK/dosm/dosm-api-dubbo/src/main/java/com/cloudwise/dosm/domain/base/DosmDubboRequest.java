package com.cloudwise.dosm.domain.base;

import lombok.*;

import java.io.Serializable;

/**
 * 类的描述
 *
 * @author: abell.wu
 * @since: 2021-09-28 09:37
 **/
@Data
@Builder
public class DosmDubboRequest implements Serializable {


    /**
     * 用户id
     */
    private String userId;

    /**
     * 子租户id
     */
    private String accountId;

    /**
     * 顶级租户id
     */
    private String topAccountId;

    /**
     * 当前页
     */
    private int currentPage;

    /**
     * 页大小
     */
    private int pageSize;


    private String language;


    public DosmDubboRequest() {
    }

    public DosmDubboRequest(String userId, String accountId, String topAccountId) {
        this.userId = userId;
        this.accountId = accountId;
        this.topAccountId = topAccountId;
    }

    public DosmDubboRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize) {
        this.userId = userId;
        this.accountId = accountId;
        this.topAccountId = topAccountId;
        this.currentPage = currentPage;
        this.pageSize = pageSize;
    }

    public DosmDubboRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String language) {
        this.userId = userId;
        this.accountId = accountId;
        this.topAccountId = topAccountId;
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.language = language;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getTopAccountId() {
        return topAccountId;
    }

    public void setTopAccountId(String topAccountId) {
        this.topAccountId = topAccountId;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }


    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
