package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/9/21 下午3:02
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DutyRecordCountVo implements Serializable {

    @ApiModelProperty("值班时长")
    private Long dutyTime;
    @ApiModelProperty("值班数量")
    private Long dutyCount;
}
