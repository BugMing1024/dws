package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import com.cloudwise.dosm.vo.ApiBtnActionVo;
import lombok.Getter;
import lombok.Setter;

/**
 * 类的描述
 *
 * @author: abell.wu
 * @since: 2021-09-29 11:00
 **/
public class DosmWorkOrderCreateRequest extends DosmDubboRequest {


    /**
     * 创建工单对象
     */
    @Setter
    @Getter
    private ApiBtnActionVo btnActionVo;


    public DosmWorkOrderCreateRequest(String userId, String accountId, String topAccountId,
                                      int currentPage, int pageSize,
                                      ApiBtnActionVo btnActionVo) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.btnActionVo = btnActionVo;
    }
}


