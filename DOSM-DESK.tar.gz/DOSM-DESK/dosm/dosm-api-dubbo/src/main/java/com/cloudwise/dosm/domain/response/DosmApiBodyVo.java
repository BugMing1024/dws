package com.cloudwise.dosm.domain.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ming.ma
 * @since 2022/11/29 上午11:44
 **/

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "Api管理模块请求body实体类")
public class DosmApiBodyVo implements Serializable {

    @ApiModelProperty(value = "body类型 form/json")
    private String bodyType;

    @ApiModelProperty(value = "参数")
    private List<DosmApiParamVo> params;
}
