package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 工单状态所需参数
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/23
 */
@Getter
@Setter
@ToString
public class DosmOrderStatusRequest extends DosmDubboRequest {

    /** 工单id */
    private String orderId;

    public DosmOrderStatusRequest(String userId, String accountId, String topAccountId,
                                 int currentPage, int pageSize, String orderId) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.orderId = orderId;
    }

    public DosmOrderStatusRequest(String userId, String accountId, String topAccountId, String orderId) {
        super(userId, accountId, topAccountId);
        this.orderId = orderId;
    }

}
