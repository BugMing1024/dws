package com.cloudwise.dosm.domain.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * cmdb关联列表实例VO
 *
 * @author frankie
 */
@Data
@JsonIgnoreProperties({"processInstanceId"})
public class DosmCmdbOrdeListView implements Serializable {
    /**
     * 主键ID
     */
    @ApiModelProperty(value = "主键ID", example = "")
    private String orderId;
    /**
     * 租户ID
     */
    @ApiModelProperty(value = "租户ID", example = "")
    private String accountId;

    /**
     * 标题
     */
    @ApiModelProperty(value = "标题", example = "")
    private String orderTitle;
    /**
     * 工单编号
     */
    @ApiModelProperty(value = "工单编号", example = "")
    private String bizKey;

    /**
     * 是否测试 0否,1是
     */
    @ApiModelProperty(value = "是否测试", example = "0否,1是")
    private long isTest;

    /**
     * 状态 0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭
     */
    @ApiModelProperty(value = "状态", example = "0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭 50 挂起")
    private Integer dataStatus;
    @ApiModelProperty(value = "状态名称", example = "0 处理中 10 待领取  20 已完成  30 驳回 40 已关闭 50 挂起")
    private String  statusContent;

    /**
     * 创建人ID
     */
    @ApiModelProperty(value = "创建人ID", example = "")
    private String createdBy;

    @ApiModelProperty(value = "创建人名称", example = "")
    private String createUser;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", example = "")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date   createdTime;

    private Long createTime;

    /**
     * 工单类型
     */
    @ApiModelProperty(value = "工单类型", example = "")
    private String       orderTypeContent;
    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID", example = "")
    private String       processInstanceId;
    /**
     * 处理人ID
     */
    @ApiModelProperty(value = "处理人ID", example = "")
    private List<String> handlerPersonIds;

    @ApiModelProperty(value = "处理人名称", example = "")
    private List<String> handlerPersonNames;
    /**
     * 处理组ID
     */
    @ApiModelProperty(value = "处理组ID", example = "")
    private List<String> handlerGroupId;

    @ApiModelProperty(value = "处理组名称", example = "")
    private List<String> handlerGroupIdName;
    /**
     * 节点名称
     */
    @ApiModelProperty(value = "当前节点名称", example = "")
    private List<String> currentNodeNames;

    @ApiModelProperty(value = "当前节点id", example = "")
    private List<String> currentNodeIds;

    private String nodeName;

    @ApiModelProperty(value = "流程名称",example = "测试流程")
    private String processName;

    @ApiModelProperty(value="优先级", example = "高")
    private String urgentLevel;


}
