package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author scott 2021/11/4
 */
@Getter
@Setter
@ToString
public class DosmOrderDeleteRequest extends DosmDubboRequest {

    private String orderId;

    public DosmOrderDeleteRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize,String orderId) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.orderId = orderId;
    }

    public DosmOrderDeleteRequest(String userId, String accountId, String topAccountId, String orderId) {
        super(userId, accountId, topAccountId);
        this.orderId = orderId;
    }
}
