package com.cloudwise.dosm.customeview;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DosmQueryViewSettingRequest;
import com.cloudwise.dosm.vo.ApiViewSettingListVo;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2022/8/10
 */
@RequestMapping("/dosm/dubbo/customView")
public interface ApiDosmCustomViewService {

    /**
     * 根据工单id查询
     *
     * @param dosmQueryViewSettingRequest ids
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getCustomViewByUserId",  consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<ApiViewSettingListVo>> getCustomViewByUserId(@RequestBody  DosmQueryViewSettingRequest dosmQueryViewSettingRequest);

}
