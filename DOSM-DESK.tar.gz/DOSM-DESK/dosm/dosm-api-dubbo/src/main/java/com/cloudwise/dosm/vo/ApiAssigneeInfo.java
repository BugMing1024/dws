package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 转派人信息
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/22
 */
@ApiModel(value = "转派人信息")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiAssigneeInfo implements Serializable {

    @ApiModelProperty(value = "指派人ID", example = "指派人ID")
    private String userId;

    @ApiModelProperty(value = "指派组ID", example = "指派组ID")
    private String groupId;

    @ApiModelProperty(value = "租户ID", example = "租户ID")
    private String accountId;

    @ApiModelProperty(value = "部门ID", example = "部门ID")
    private String departmentId;

}
