package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author scott 2021/8/24
 */
@Data
@Builder
public class DosmProcessConfigParam implements Serializable {

    /**
     * 流程定义id
     */
    @ApiModelProperty(value="节点定义id", example = "", required = true)
    private String processDefId;

    /**
     * 节点信息
     */
    @ApiModelProperty(value="节点信息", example = "", required = true)
    private List<ApiNodeInfoVo> nodeInfoList;

    /**
     * 流程类型
     */
    @ApiModelProperty(value="流程类型", example = "", required = true)
    private String processType;


}
