package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * <p>
 *     列表查询的入参
 * </p>
 *
 * @author rentingji
 * @date 2021/6/23 下午4:37
 **/
@Data
@ApiModel("工单列表筛选项")
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrderQueryInputRequest extends DosmDubboRequest {

    @ApiModelProperty(value = "筛选查询数据", example = "[\n" +
            "        {\n" +
            "            \"fieldKey\":\"bizDesc\",\n" +
            "            \"mdfKey\":null,\n" +
            "            \"value\":[\n" +
            "                \"123\"\n" +
            "            ],\n" +
            "            \"type\":\"INPUT\"\n" +
            "        }\n" +
            "    ]", required = true)
    private List<WorkOrderQueryRequest> queryData;
    @ApiModelProperty(value = "展示列数据", example = "[\n" +
            "        {\n" +
            "            \"key\":\"bizDesc\",\n" +
            "            \"preNum\":\"流程编码\",\n" +
            "            \"componentType\":\"INPUT\"\n" +
            "        }\n" +
            "    ]", required = true)
    private List<ShowFieldInfoRequest> showFieldInfoRequests;

    @ApiModelProperty(value = "排序字段", example = "[{\"key\":\"字段名\",\"type\":\"排序方式\"}]", required = true)
    private List<SortRequest> sortList;

    @ApiModelProperty(value = "自定义列表展示类型", example = "", required = true)
    private String showFormFieldType;
    @ApiModelProperty(value = "是否需要保存查询条件", example = "false", required = false)
    private Boolean isNeedSaveQuery =  false;

    private String viewId;

}
