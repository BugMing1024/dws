package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 领取工单参数
 * @author jon.lee
 * @since 2023-07-25 17:34
 **/
@Data
@ApiModel(description= "领取工单参数")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiClaimVo {

    /**
     * 节点id
     */
    @ApiModelProperty(value = "节点id", name = "nodeId", required = true)
    private String nodeId;

    /**
     * 工单id
     */
    @ApiModelProperty(value = "工单id", name = "workOrderId", required = true)
    private String workOrderId;

}
