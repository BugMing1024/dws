package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Rhyme
 * @date Create in 15:31 2022/5/25
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("自定义视图设置查询对象")
public class DosmCmdbOrderListRequest extends DosmDubboRequest {
    @ApiModelProperty(value = "模型ID", example = "xxx", required = true)
    private String  modelId;
    @ApiModelProperty(value = "当前页码", example = "1", required = true)
    private Integer pageNum;
    @ApiModelProperty(value = "配置项Id", example = "xxx", required = true)
    private String  ciId;
    @ApiModelProperty(value = "工单类型", example = "xxx", required = false)
    private String  type;
}
