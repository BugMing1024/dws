package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author Isaiah.Wang
 * @date 2021年06月15日 下午5:16
 */
@ApiModel(value = "数据字典详情修改参数", description = "获取数据字典详情信息的修改字段")
@Data
public class DictDetailUpdateRequest extends DosmDubboRequest {

    /**
     * 数据字典子表id
     */
    @ApiModelProperty(value = "数据字典详情主键（string类型）", example = "b8104d3de2534f898e8df131f5775ca1", required = true)
    private String id;

    /**
     * 子租户ID
     */
    @ApiModelProperty(value ="子租户ID")
    private  String accountId;
    /**
     * 顶级租户ID
     */
    @ApiModelProperty(value ="顶级租户ID")
    private String topAccountId;
    /**
     * 字典ID
     */
    @ApiModelProperty(value ="字典ID")
    private String dictId;
    /**
     * 父节点
     */
    @ApiModelProperty(value ="父节点")
    private  String parentId;
    /**
     * 标签
     */
    @ApiModelProperty(value = "标签（string类型）", example = "测试")
    private String label;

    /**
     * 数据集
     */
    @ApiModelProperty(value = "数据集（string类型）", example = "测试A")
    private String data;

    /**
     * 层级
     */
    @ApiModelProperty(value = "层级（int类型）", example = "1")
    private Integer level;

    @ApiModelProperty(value= "是否可改变 0可改变 1 不可改变",example = "1")
    private Integer canChange;


    /**
     * 子节点
     */
    @ApiModelProperty(value = "数据字典详情子节点（list类型）")
    private List<DictDetailUpdateRequest> children;

}
