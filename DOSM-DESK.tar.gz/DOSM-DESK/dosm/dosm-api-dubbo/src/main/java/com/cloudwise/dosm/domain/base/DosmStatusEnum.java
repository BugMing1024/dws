package com.cloudwise.dosm.domain.base;

import lombok.Getter;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * dosm 响应状态枚举
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/22
 */
@Getter
public enum DosmStatusEnum {

    SUCCESS,
    FAIL;

    public static Optional<DosmStatusEnum> ofNullable(String status) {
        return Stream.of(values())
                .filter(bean -> Objects.equals(status, bean.name()))
                .findAny();
    }
}
