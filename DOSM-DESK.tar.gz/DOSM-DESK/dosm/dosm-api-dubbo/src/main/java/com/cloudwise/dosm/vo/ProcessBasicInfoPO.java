package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 流程基本信息
 *
 * @author: turbo.wu
 * @since: 2022-06-21 13:24
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessBasicInfoPO implements Serializable {
    /**
     * 流程主键id
     */
    @ApiModelProperty(value = "流程id", example = "abc", required = true)
    private String id;

    /**
     * 流程名称
     */
    @ApiModelProperty(value="流程名称", example = "", required = true)
    private String processName;

    /**
     * 流程类型
     */
    @ApiModelProperty(value="流程类型", example = "", required = true)
    private String processType;


    /**
     * 流程key
     */
    @ApiModelProperty(value="流程key", example = "", required = true)
    private String preNum;

    /**
     * 编号前缀
     */
    @ApiModelProperty(value="流程前缀", example = "", required = true)
    private String prefix;

    /**
     * 描述信息
     */
    @ApiModelProperty(value="描述信息", example = "", required = true)
    private String processDesc;

    /**
     * 模型ID（mdl_del表）
     */
    @ApiModelProperty(value="表单id", example = "", required = true)
    private String mdlFormId;

    /**
     * 外部调用 默认 0不允许 1允许
     */
    @ApiModelProperty(value = "是否允许被外部调用",example = "",required = true)
    private int allowCall;

    private String createdBy;
    private Date createdTime;
    private String updatedBy;
    private Date updatedTime;

}