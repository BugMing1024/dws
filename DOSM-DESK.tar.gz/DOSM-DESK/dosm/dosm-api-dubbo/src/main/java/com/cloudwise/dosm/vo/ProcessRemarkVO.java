package com.cloudwise.dosm.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * 流程信息备注
 *
 * @author: turbo.wu
 * @since: 2022-06-21 11:43
 **/
@Data
public class ProcessRemarkVO implements Serializable {
    private String processBasicInfo;
    private String fieldList;
    private String formDataTemplate;
    private String NodeList;

    private ProcessRemarkVO(String processBasicInfo, String fieldList, String formDataTemplate, String nodeList) {
        this.processBasicInfo = processBasicInfo;
        this.fieldList = fieldList;
        this.formDataTemplate = formDataTemplate;
        NodeList = nodeList;
    }

    private ProcessRemarkVO() {}

    private static ProcessRemarkVO processRemarkVO = null;

    public static ProcessRemarkVO getInstance() {
        if (processRemarkVO == null) {
            processRemarkVO = new ProcessRemarkVO(
                    ProcessInfoConstant.PROCESS_BASIC_INFO,
                    ProcessInfoConstant.PROCESS_FIELD_LIST,
                    ProcessInfoConstant.PROCESS_FIELD_TEMPLATE,
                    ProcessInfoConstant.PROCESS_NODE_LIST
            );
            return processRemarkVO;
        }
        return processRemarkVO;
    }

    class ProcessInfoConstant {

        public static final String PROCESS_BASIC_INFO = "流程基础信息";
        public static final String PROCESS_FIELD_LIST = "表单字段信息";
        public static final String PROCESS_FIELD_TEMPLATE = "表单信息模版";
        public static final String PROCESS_NODE_LIST = "流程节点信息";

    }
}