package com.cloudwise.dosm.domain.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.Date;

/**
 * @author amos
 */
@Data
@SuperBuilder
@NoArgsConstructor
public abstract class DubboBaseModel implements Serializable {

    @ApiModelProperty("id")
    protected String id;

    @ApiModelProperty("序号")
    protected String sequence;

    @ApiModelProperty("顶级租户id")
    protected String topAccountId;

    @ApiModelProperty("当前租户id")
    protected String accountId;

    @ApiModelProperty("删除标志")
    protected Integer isDel;

    @ApiModelProperty("创建时间")
    protected Date createdTime;

    @ApiModelProperty("更新时间")
    protected Date updatedTime;

    @ApiModelProperty("创建人")
    private String createdBy;

    @ApiModelProperty("更新人")
    private String updatedBy;

    private String userId;

    public static final Integer DELETE = 1;
    public static final Integer NO_DELETE = 0;

    public static final String BUILTIN = "BUILTIN";
    public static final String CUSTOM = "CUSTOM";
    public static final Integer ENABLE = 0;
    public static final Integer PROHIBIT = 1;
    public static final Integer COMPLETE = 1;
    public static final Integer NO_COMPLETE = 0;
    public static final String CAN_COMPLETE = "0";
    public static final String CAN_NOT_COMPLETE = "1";
    public static final Integer UN_READ = 0;
    public static final Integer READ = 1;

}
