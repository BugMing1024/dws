package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ming.ma
 * @description 查询值班日志参数
 * @since 2022/6/7 下午3:27
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DutyLogRecordRequest extends DosmDubboRequest {

    @ApiModelProperty("值班记录id")
    private String dutyRecordId;

    @ApiModelProperty("班次分组id")
    private String shiftGroupId;

    @ApiModelProperty("记录人id")
    private String recordeUserId;

    @ApiModelProperty("开始时间")
    private String startTime;

    @ApiModelProperty("结束时间")
    private String endTime;

    @ApiModelProperty("值班状态")
    private String dutyStatus;

    @ApiModelProperty("页码")
    private int currentPage;

    @ApiModelProperty("页面大小")
    private int pageSize;

}
