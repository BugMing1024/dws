package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 类的描述
 *
 * @author: abell.wu
 * @since: 2021-06-25 16:01
 **/
@Data
@ApiModel("自定义列展示")
public class ApiCustomQueryContentVo {


    @ApiModelProperty(value = "列名称", example = "", required = true)
    private String label;

    @ApiModelProperty(value = "列key", example = "", required = true)
    private String key;

    @ApiModelProperty(value = "流程key", example = "", required = true)
    private String preNum;

    @ApiModelProperty(value = "列的具体值", example = "", required = true)
    private List<String> value;

    @ApiModelProperty(value = "用户状态（1:启用，2:停用）", example = "1")
    private List<Integer> userStatus;

    private String componentType;


}



