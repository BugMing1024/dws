package com.cloudwise.dosm.domain.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2023/11/22
 */
@Data
public class ShowFieldInfoRequest {
    @ApiModelProperty(value = "字段编码",required = true,example = "当是流程字段时格式【formId|字段编码】")
    private String key;
    @ApiModelProperty(value = "字段类型",required = true,allowableValues = "NUMBER,INPUT,TEXTAREA,RADIO,CHECKBOX,SELECT_MANY,SELECT,MULTI_SELECT,TIME,DATE,MEMBER")
    private String componentType;
    @ApiModelProperty(value = "所属流程编码",required = false,example = "当是流程字段时必填")
    private String preNum;
}
