package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "WorkOrderModelOpenApiVO对外Api服务目录前端显示内容", description = "WorkOrderModelOpenApiVO对外Api服务目录前端显示内容")
public class WorkOrderModelOpenApiVO implements Serializable {
    @ApiModelProperty(value = "服务目录ID", example = "12312")
    private String catalogId;
    @ApiModelProperty(value = "流程ID", example = "sdcon232")
    private String processId;
    @ApiModelProperty(value = "流程前缀", example = "asii")
    private String preNum;
    @ApiModelProperty(value = "流程名称", example = "demo")
    private String processName;

    @ApiModelProperty(value = "流程类型列表", example = "jhasiudhaushd")
    private String processType;
    //流程发布id
    @ApiModelProperty(value = "流程发布ID", example = "sdcf:1:1123sarfgf")
    private String processDefId;
    @ApiModelProperty(value = "流程描述", example = "描述信息")
    private String processDesc;
    @ApiModelProperty(value = "流程前缀", example = "asdf")
    private String processPrefix;
    @ApiModelProperty(value = "流程状态", example = "1")
    private Integer status;
    @ApiModelProperty(value = "存储的模版id", example = "1ssdf")
    private String modelTemplateId;
    @ApiModelProperty(value = "顺序", example = "1")
    private Integer sortInt;
    private String sort;
    /**
     * 服务项自定义字段值
     */
    private Object extendFields;
    /**
     * 服务项唯一id
     */
    private String id;

    private String modelId;

    /**
     * 服务项名称
     */
    private String modelName;



}
