package com.cloudwise.dosm.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 创建工单所需参数
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/3/8
 */
@Data
@ApiModel(description= "创建工单所需参数")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiBtnActionVo implements Serializable {

    @ApiModelProperty(value = "原因", name = "remark", required = false)
    private String remark;

    @ApiModelProperty(value = "工单id", name = "workOrderId", required = true)
    private String workOrderId;

    @ApiModelProperty(value = "工单编号", name = "bizKey", required = true)
    private String bizKey;

    @ApiModelProperty(value = "流程实例id", name = "processInstanceId", required = true)
    private String processInstanceId;

    @ApiModelProperty(value = "流程defid", name = "processDefId", required = true)
    private String processDefId;

    @ApiModelProperty(value = "节点id", name = "nodeId", required = true)
    private String nodeId;

    @ApiModelProperty(value = "流程表单id", name = "formId")
    private String formId;

    @ApiModelProperty(value = "节点名字", name = "nodeName", required = true)
    private String nodeName;

    @ApiModelProperty(value = "转派任务id", name = "taskId", required = false)
    private String taskId;

    @ApiModelProperty(value = "转派用户id", name = "assignUser", required = false)
    private List<Map<String,Object>> assignUser;

    @ApiModelProperty(value = "指派用户信息", name = "appointUser", required = false)
    private Map<String,List<Object>> appointUser;

    @ApiModelProperty(value = "各个按钮单独部分", name = "other", required = true)
    private ApiMdlInstance data;

    @ApiModelProperty(value = "是否授权", name = "other", required = true)
    private boolean authorized = Boolean.FALSE;

    @ApiModelProperty(value = "临时工单ID",name = "tempWorkOrderId",required = false)
    private String tempWorkOrderId;

    @ApiModelProperty(value = "表单defCode", name = "mdlDefCode", required = true)
    private String mdlDefCode;

    @ApiModelProperty(value = "第三方系统id", name = "eventId", required = true)
    private String eventId;

    @ApiModelProperty(value = "是否需要校验 true需要 false页面传参", name = "isCheckFlag")
    private Boolean isCheckFlag = true;

    @ApiModelProperty(value = "测试参数", name = "testDate")
    private Date testDate;

    @ApiModelProperty(value = "工单来源,{网页表单:WEB_FORM,监控系统:MONITOR_SYSTEM,例行工作:ROUTINE_WORK}",example = "MONITOR_SYSTEM",required = true)
    private String sourceId;
}
