package com.cloudwise.dosm.vo;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @author scott 2021/8/25
 */
@Data
@Builder
public class ApiNodeInfoVo implements Serializable {


    private String nodeId;

    private String nodeName;
    /**
     * 服务台自动建单使用
     */
    private String bindedFieldKey;
}
