package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @auther Dave Liu
 * @date 2021/7/12 下午6:48
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value="DutyManageVo对象 ", description="值班选择dutyShiftUserVo对象")
public class DutyManageVo implements Serializable {
    @ApiModelProperty(value = "值班时间")
    private Date dutyTime;
    @ApiModelProperty(value = "值班人列表集合")
    private List<DutyManageUserViewVo> dutyManageUserList;
    @ApiModelProperty("是否展示休息日，1：展示休息日 2：重保日 0：不展示")
    private String restOrNot;
}
