package com.cloudwise.dosm.domain.request;


import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

@Data
public class Members implements Serializable, Cloneable{

    //(value = "部门列表", example = "俱乐部")
    private Set<String> dep;

    //(value = "用户组列表", example = "俱乐部")
    private List<Group> group;

    //(value = "角色列表", example = "俱乐部")
    private Set<String> role;

    //(value = "用户列表", example = "[2]")
    private Set<String> user;

    //(value = "租户列表", example = "[2]")
    private Set<String> account;


    @Override
    public Members clone() {
        try {
            Members clone = (Members) super.clone();
            return clone;
        } catch(CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
