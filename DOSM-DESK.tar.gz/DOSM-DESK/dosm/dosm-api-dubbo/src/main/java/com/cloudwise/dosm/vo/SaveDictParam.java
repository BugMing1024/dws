package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SaveDictParam {
    /**
     * 数据字典编码
     */
    @ApiModelProperty(value = "数据字典编码（string类型）", example = "TTUY66778899")
    private String dictCode;

    /**
     * 层级
     */
    @ApiModelProperty(value = "层级（int类型）", example = "1")
    private Integer level;

    /**
     * 数据字典名称
     */
    @ApiModelProperty(value = "数据字典名称（string类型）", example = "厂家测试")
    private String dictName;

    /**
     * 字典说明
     */
    @ApiModelProperty(value = "字典说明（string类型）", example = "厂家测试")
    private String caption;

    /**
     * 判断是否内置，INSIDE内置，MYSELF自定义
     */
    @ApiModelProperty(value = "内置状态（string类型）", example = "INSIDE")
    private String dictType;

    @ApiModelProperty(value = "操作人人id（string类型）", example = "2")
    private String operatId;
    /**
     * 账户id
     */
    @ApiModelProperty(value = "账户id（string类型）", example = "110")
    private String accountId;
    /**
     * 顶级账户id
     */
    @ApiModelProperty(value = "顶级账户id（string类型）", example = "110")
    private String topAccountId;

}
