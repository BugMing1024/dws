package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 固定处理人
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/3/8
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiAssigneeInfoBO implements Serializable {

    /**
     * 指派到这里时的用户id
     */
    private String userId;

    /**
     * 一个用户可以属于多个组，但是到流转的时候只有一个组
     */
    private String groupId;

}
