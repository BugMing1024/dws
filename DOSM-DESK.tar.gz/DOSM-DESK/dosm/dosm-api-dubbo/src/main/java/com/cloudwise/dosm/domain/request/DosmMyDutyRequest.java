package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author ming.ma
 * @description todo
 * @since 2022/9/14 上午11:12
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DosmMyDutyRequest extends DosmDubboRequest {

    private Long startTime;
    private Long endTime;
    private List<String> dutyConfigIdList;
    private Members members;
}
