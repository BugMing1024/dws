package com.cloudwise.dosm.duty;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.*;
import com.cloudwise.dosm.vo.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * @author ming.ma
 * @since 2022/9/9 下午3:41
 **/

@RequestMapping("/dosm/dubbo/duty")
public interface DosmDutyService {

    @RequestMapping(method = RequestMethod.POST, value = "/createDutyLeave",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> createDutyLeave(@RequestBody  DosmDutyLeaveRequest request);


    @RequestMapping(method = RequestMethod.POST, value = "/getDutyShifts",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Object> getDutyShifts(@RequestBody DosmDutyShiftRequest request);

    @RequestMapping(method = RequestMethod.POST, value = "/getDutyShiftGroups",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<DutyShiftGroupVo>> getDutyShiftGroups(@RequestBody DosmDubboRequest request);

    /**
     * 获取所有值班表
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getDutyConfigs",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<DutyConfigVO>> getDutyConfigs(@RequestBody DosmDubboRequest request);

    /**
     * 获取我的值班日历视图
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getMyDuty",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<DutyManageVo>> getMyDuty(@RequestBody DosmMyDutyRequest request);

    /**
     * 获取值班记录
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getMyDutyRecord",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<PageVO<DutyRecordVO>> getMyDutyRecord(@RequestBody DutyLogRecordRequest request);

    /**
     * 获取值班日志
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getMyDutyRecordLog",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<PageVO<DutyLogVO>> getMyDutyRecordLog(@RequestBody DutyLogRecordRequest request);

    /**
     * 获取值班数量和值班时长统计
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getDutyRecordCount",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<DutyRecordCountVo> getDutyRecordCount(@RequestBody DutyRecordCountRequest request);


    @RequestMapping(method = RequestMethod.POST, value = "/getDutyShiftUsers",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Object> getDutyShiftUsers(@RequestBody DosmDutyShiftRequest request);


    /**
     * 获取值班数量和值班时长、待值班次数、换班次数
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getDutyCountByUsers",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<DutyCountUserVo>> getDutyCountByUsers(@RequestBody DutyRecordCountRequest request);

}