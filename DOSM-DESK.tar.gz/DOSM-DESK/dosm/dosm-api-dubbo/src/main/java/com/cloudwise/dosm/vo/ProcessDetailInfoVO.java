package com.cloudwise.dosm.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 流程详细信息
 *
 * @author: turbo.wu
 * @since: 2022-06-21 11:38
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessDetailInfoVO implements Serializable {
    /**
     * 流程详细信息备注
     */
    private ProcessRemarkVO processRemarks;
    /**
     * 流程基本信息
     */
    private ProcessBasicInfoPO processBasicInfo;
    /**
     * 表单字段信息
     */
    private List<FormFieldPO> fieldList;
    /**
     * 表单信息模版
     */
    private List<FormDataTemplate> formDataTemplate;
    /**
     * 流程节点信息
     */
    private List<ProcessNodeApiPo> nodeList;
}