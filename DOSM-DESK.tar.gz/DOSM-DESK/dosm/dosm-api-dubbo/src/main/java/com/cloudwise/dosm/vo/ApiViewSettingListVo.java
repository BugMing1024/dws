package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Rhyme
 * @date Create in 15:35 2022/5/25
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("自定义视图设置列表")
public class ApiViewSettingListVo  implements Serializable {
    @ApiModelProperty("id")
    private String id;
    @ApiModelProperty("视图名称")
    private String viewName;
}
