package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ming.ma
 * @date 2022-06-01 17:31
 * @description
 */
@Data
public class DutyShiftGroupVo implements Serializable {
    /**
     * 班次分组id
     */
    @ApiModelProperty(value = "班次分组id", example = "1648742400000")
    private String id;

    /**
     * 班次分组名称
     */
    @ApiModelProperty(value = "班次分组名称", example = "1648742400000")
    private String name;
}
