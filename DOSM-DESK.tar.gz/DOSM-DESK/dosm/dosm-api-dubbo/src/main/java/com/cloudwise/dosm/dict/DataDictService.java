package com.cloudwise.dosm.dict;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DataDictEditRequest;
import com.cloudwise.dosm.domain.request.DictDetailUpdateRequest;
import com.cloudwise.dosm.domain.request.DosmDataDictRequest;
import com.cloudwise.dosm.vo.DataDictEditResultVo;
import com.cloudwise.dosm.vo.DataDictVo;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author ming.ma
 * @since 2022/9/9 下午3:41
 **/

@RequestMapping("/dosm/dubbo/dict")
public interface DataDictService {

    /**
     * 获取数据字典
     * @param requset
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getDictByCode",  consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<DataDictVo> getDictByCode(@RequestBody  DosmDataDictRequest requset);

    /**
     * 更新数据字典(更新数据字典-流程类型)
     * @param request
     * @return
     */
    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/updateDict",  consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> updateDict(@RequestBody  DictDetailUpdateRequest request);

    /**
     * 更新数据字典
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/update" ,consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<DataDictEditResultVo> update(@RequestBody  DataDictEditRequest request);

}