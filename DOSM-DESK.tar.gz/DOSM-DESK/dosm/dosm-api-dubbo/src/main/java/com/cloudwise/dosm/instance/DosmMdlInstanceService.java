package com.cloudwise.dosm.instance;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DosmInstanceCreateRequest;
import com.cloudwise.dosm.vo.ApiMdlInstance;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * @author wuzhaoyi
 */

@RequestMapping("/dosm/dubbo/instance")
public interface DosmMdlInstanceService {


    /**
     * 其他系统创建工单缓存数据
     *
     */

    @RequestMapping(method = RequestMethod.POST, value = "/cacheCreateData",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> cacheCreateData(@RequestBody  DosmInstanceCreateRequest request);

    /**
     * 根据工单id查询
     *
     * @param workOrderIdList ids
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getOrderByIds",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<ApiMdlInstance>> getOrderByIds(List<String> workOrderIdList);

}
