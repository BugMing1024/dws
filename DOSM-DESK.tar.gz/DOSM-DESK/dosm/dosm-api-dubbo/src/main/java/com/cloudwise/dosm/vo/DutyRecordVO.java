package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ming.ma
 * @description 值班日志
 * @since 2022/6/10 上午9:45
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DutyRecordVO implements Serializable {
    @ApiModelProperty("值班记录id")
    private String id;
    @ApiModelProperty("开始时间")
    private Date startTime;
    @ApiModelProperty("交班时间")
    private Date shiftHandoverTime;
    @ApiModelProperty("值班时长")
    private String dutyHours;
    @ApiModelProperty("值班人员")
    private String dutyUsers;
    @ApiModelProperty("值班班次")
    private String dutyShiftName;
    @ApiModelProperty("接班班次")
    private String successionShiftName;
    @ApiModelProperty("接班人")
    private String successors;
    @ApiModelProperty("班次分组")
    private String dutyShiftGroupName;
    @ApiModelProperty("交班类型")
    private String changeShiftType;
    @ApiModelProperty("值班状态")
    private String dutyStatus;
    @ApiModelProperty("接班时间")
    private Date successionTime;
    @ApiModelProperty("交班人")
    private String shiftHandoverUserId;
    @ApiModelProperty("值班表id")
    private String configId;
 }
