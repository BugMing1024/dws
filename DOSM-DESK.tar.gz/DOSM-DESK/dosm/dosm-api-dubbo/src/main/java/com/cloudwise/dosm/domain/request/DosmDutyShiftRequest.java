package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * @auther ming.ma
 * @date 2021/7/8 下午4:47
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DosmDutyShiftRequest extends DosmDubboRequest {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("班次分组ids列表")
    private List<String> dutyShiftGroupIds;

    /*@ApiModelProperty("当前页数")
    private Integer currentPage;

    @ApiModelProperty("页容量")
    private Integer pageSize;*/

    @ApiModelProperty("是否展示删除")
    private String showDel;

    @ApiModelProperty("班次名称")
    private String dutyShiftName;

    /**
     * 查询值班人员所需
     */
    @ApiModelProperty("是否值班 0全部  1已值班")
    private Integer status;

    @ApiModelProperty("班次ids列表")
    private List<String> dutyShiftIds;

    @ApiModelProperty("值班时间(status为0不需要传)")
    private Date dutyTime;

}
