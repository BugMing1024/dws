package com.cloudwise.dosm.vo;

import com.cloudwise.dosm.duty.enums.DutyLogStatusEnums;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @auther ming.ma
 * @date 2021/7/12 下午6:42
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value="DutyManageUserViewVo对象 ", description="创建班次dutyManageUserViewVo对象")
public class DutyManageUserViewVo implements Serializable {
    @ApiModelProperty(value = "班次ID")
    private String id;
    @ApiModelProperty(value = "租户名称")
    private String accountName;
    @ApiModelProperty(value = "值班用户ID")
    private UserAndGroupVo dutyUserId;
    @ApiModelProperty(value = "值班用户名")
    private String dutyUserName;
    @ApiModelProperty(value = "班次ID")
    private String dutyShiftId;
    @ApiModelProperty(value = "班次内容ID")
    private String dutyShiftContentId;
    @ApiModelProperty(value = "班次名")
    private String dutyShiftName;
    @ApiModelProperty(value = "班次值班开始时间")
    private JsonNode startTime;
    @ApiModelProperty(value = "班次值班结束时间")
    private JsonNode endTime;
    @ApiModelProperty(value = "班次开始时间分钟")
    private int dutyShiftStartMinute;

    private String dutyConfigId;

    private String dutyConfigName;

    private String batchRepeat;

    /**
     * 用户名
     */
    @ApiModelProperty(value = "用户别名")
    private String dutyUserAlias;

    /**
     * 额外用户信息
     */
    @ApiModelProperty(value = "额外用户信息")
    private DutyUserExtInfo extUserInfo;

    @ApiModelProperty(value = "班次分组id")
    private String shiftGroupId;

    @ApiModelProperty(value = "班次分组名称")
    private String shiftGroupName;

    @ApiModelProperty(value = "班组长")
    private List<DbUserVo> shiftLeaders;

    @ApiModelProperty("是否开启消息提醒")
    private Integer isRemind;

    @ApiModelProperty("是否开启自动交接班")
    private Integer autoOpen;

    @ApiModelProperty("自动交接班配置")
    private String autoConfig;

    @ApiModelProperty("值班日志标识")
    private DutyLogStatusEnums dutyLogStatus;

    @ApiModelProperty("班次属性 0-普通 1-领导")
    private Integer shiftAttribute;



}
