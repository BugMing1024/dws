package com.cloudwise.dosm.domain.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpMethod;

import java.io.Serializable;
import java.util.Map;

/**
 * @description: 运行api信息
 * @author: Janet
 * @create: 2022-11-30 15:35
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DosmApiRunInfoRequest implements Serializable {

    // 接口id
    private String id;

    // url路径
    private String urlPath;

    // 请求方式 GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE
    private HttpMethod requestMode;

    // 请求body
    private Object body;

    // 请求query
    private Map<String,Object> query;

    // 请求header
    private Map<String,Object> headers;

    // 请求地址栏参数
    private Map<String,Object> urlParams;

}
