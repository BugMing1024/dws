package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>
 * </p>
 *
 * @author rentingji
 * @date 2022/2/14 下午4:48
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderAuthInfoVo implements Serializable {

    @ApiModelProperty(value="是否有可见权限", example = "", required = true)
    private boolean isWorkOrderVisible;

    @ApiModelProperty(value="工单Id", example = "", required = true)
    private String workOrderId;

    public OrderAuthInfoVo(String workOrderId , boolean isWorkOrderVisible){
        this.isWorkOrderVisible = isWorkOrderVisible;
        this.workOrderId = workOrderId;
    }

    /**
     * 请不要改变此方法
     * 需要提供{"isWorkOrderVisible":false,"workOrderId":null}格式的结果返回
     */
    public boolean getIsWorkOrderVisible() {
        return isWorkOrderVisible;
    }

    public void setWorkOrderVisible(boolean workOrderVisible) {
        isWorkOrderVisible = workOrderVisible;
    }

}
