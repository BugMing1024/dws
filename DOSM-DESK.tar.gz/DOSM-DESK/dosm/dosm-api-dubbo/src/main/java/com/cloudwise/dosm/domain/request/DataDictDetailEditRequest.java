package com.cloudwise.dosm.domain.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author jon.lee
 * @date 2022-11-28 18:16
 */
@ApiModel(value = "数据字典详情更新参数", description = "数据字典详情更新参数")
@Data
public class DataDictDetailEditRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据字典子表id
     */
    @ApiModelProperty(value = "数据字典详情主键（string类型）")
    private String id;
    /**
     * 标签
     */
    @ApiModelProperty(value = "标签（string类型）")
    private String label;
    /**
     * 数据集
     */
    @ApiModelProperty(value = "数据集（string类型）")
    private String data;
    /**
     * 颜色
     */
    @ApiModelProperty(value = "颜色")
    private String color;
    /**
     * 选项是否开启颜色
     */
    private boolean useColor;
    /**
     * 父节点
     */
    @ApiModelProperty(value = "父节点主键（string类型）")
    private String parentId;
    /**
     * 层级
     */
    @ApiModelProperty(value = "层级（int类型）")
    private Integer level;
    /**
     * 排序优先级
     */
    @ApiModelProperty(value = "排序优先级")
    private Integer priority;


}
