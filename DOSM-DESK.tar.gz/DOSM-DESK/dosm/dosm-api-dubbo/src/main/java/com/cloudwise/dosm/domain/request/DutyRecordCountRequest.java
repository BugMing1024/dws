package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * @description: 值班记录查询条件
 * @author: Janet
 * @create: 2022-06-01 21:16
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DutyRecordCountRequest extends DosmDubboRequest {

    @ApiModelProperty("开始时间")
    private Date startTime;

    @ApiModelProperty("结束时间")
    private Date endTime;

    @ApiModelProperty("值班人")
    private List<String> userIds;

    @ApiModelProperty("班次ID")
    private List<String> dutyShiftIds;

    @ApiModelProperty("班次分组ID")
    private List<String> dutyShiftGroupIds;

    @ApiModelProperty("值班表ID")
    private List<String> dutyConfigIds;
}
