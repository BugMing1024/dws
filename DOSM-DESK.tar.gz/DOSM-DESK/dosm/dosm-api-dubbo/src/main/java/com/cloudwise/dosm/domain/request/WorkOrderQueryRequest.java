package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

/**
 * <p>
 * </p>
 *
 * @author ming.ma
 * @date 2021/6/23 下午4:50
 **/
@ApiModel("工单筛选项vo")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class WorkOrderQueryRequest implements Serializable {
    @ApiModelProperty(value = "字段Key", example = "desc", required = true)
    private String fieldKey ;
    @ApiModelProperty(value = "流程key[为空则为固定类查询]", example = "addagasgddg:1", required = true)
    private String mdfKey;
    @ApiModelProperty(value = "流程key", example = "addagasgddg:1", required = true)
    private String preNum;
    @ApiModelProperty(value = "字段类型", example = "INPUT", required = true)
    private String type;
    @ApiModelProperty(value = "字段筛选值", example = "[\"我是一个筛选值\"]", required = true)
    private Object value;
    @ApiModelProperty(value = "租户Id", example = "110", required = false)
    private String accountId;
}
