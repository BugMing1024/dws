package com.cloudwise.dosm.domain.request;


import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 查询流程模版信息
 *
 * @author: abell.wu
 * @since: 2021-09-28 09:39
 **/
@Getter
@Setter
@ToString
public class DosmProcessInfoRequest extends DosmDubboRequest {

    /**
     * 流程定义id
     */
    private String procDefId;

    /**
     * 流程类型
     */
    @Setter
    @Getter
    private String type;

    /**
     * 流程前缀
     */
    @Setter
    @Getter
    private String preNum;

    /** 无默认值的必填字段过滤, 默认不过滤 */
    @Setter
    @Getter
    private Boolean filterIfNotDefValueReqField = Boolean.FALSE;

    public DosmProcessInfoRequest() {
    }

    public DosmProcessInfoRequest(String procDefId, String userId, String accountId, String topAccountId) {
        super(userId, accountId, topAccountId, 0, 0);
        this.procDefId = procDefId;
    }

    public DosmProcessInfoRequest(String type, String preNum) {
        this.type = type;
        this.preNum = preNum;
    }

    public DosmProcessInfoRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String type, String preNum) {
        super(userId, accountId, topAccountId, currentPage, pageSize);
        this.type = type;
        this.preNum = preNum;
    }

    public DosmProcessInfoRequest(String userId, String accountId, String topAccountId, int currentPage, int pageSize, String language, String type, String preNum) {
        super(userId, accountId, topAccountId, currentPage, pageSize, language);
        this.type = type;
        this.preNum = preNum;
    }
}
