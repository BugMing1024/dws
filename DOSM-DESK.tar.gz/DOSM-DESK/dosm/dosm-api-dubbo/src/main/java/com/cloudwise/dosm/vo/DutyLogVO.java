package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author ming.ma
 * @description 添加值班日志参数
 * @since 2022/6/7 下午3:27
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DutyLogVO implements Serializable {

    @ApiModelProperty("值班日志id")
    private String id;

    @ApiModelProperty("值班记录id")
    private String dutyRecordId;

    @ApiModelProperty("值班内容d")
    private String logContent;

    @ApiModelProperty("附件")
    private String attachment;

    @ApiModelProperty("记录人")
    private String recordUser;

    @ApiModelProperty("记录时间")
    private Date recordTime;

    @ApiModelProperty("记录人名称")
    private String recordUserName;

    @ApiModelProperty("记录用户信息")
    private DutyUserInfoVo recordUserInfo;

    @ApiModelProperty("关联工单列表")
    private List<DutyLinkWorkOrderVo> linkWorkOrders;

}
