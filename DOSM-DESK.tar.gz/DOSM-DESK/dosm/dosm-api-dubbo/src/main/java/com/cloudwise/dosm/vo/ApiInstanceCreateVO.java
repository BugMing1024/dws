package com.cloudwise.dosm.vo;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 字段VO
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/3/8
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiInstanceCreateVO implements Serializable {

    /** 字段Key */
    private String fieldKey;

    /** 字段数据值 */
    private Object fieldValue;

    /** 字段数据值数组 */
    private List<JsonNode> fieldValueList;

}
