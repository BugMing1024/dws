package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author ming.ma
 * @since 2022/9/9 下午3:43
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DosmDutyLeaveRequest extends DosmDubboRequest  {

    @ApiModelProperty("请假人id")
    private String createUserId;

    @ApiModelProperty("请假开始时间")
    private Date leaveDate;

    @ApiModelProperty("请假结束时间")
    private Date leaveEndTime;

    @ApiModelProperty("请假原因")
    private String leaveReason;

    @ApiModelProperty("顶班人id")
    private String replaceUserId;

    @ApiModelProperty("是否审批通过 0-否 1-是")
    private Integer isPass;


}
