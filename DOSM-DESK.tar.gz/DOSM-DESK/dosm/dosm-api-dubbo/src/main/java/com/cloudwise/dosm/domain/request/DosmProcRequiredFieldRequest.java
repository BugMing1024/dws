package com.cloudwise.dosm.domain.request;

import com.cloudwise.dosm.domain.base.DosmDubboRequest;
import lombok.Getter;
import lombok.Setter;

/**
 * 流程必填字段接口请求参数信息
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2022/2/17
 */
@Getter
@Setter
public class DosmProcRequiredFieldRequest extends DosmDubboRequest {

    /** 表单id */
    private String formId;

    /** 节点id */
    private String nodeId;

}
