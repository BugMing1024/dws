package com.cloudwise.dosm;


import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.DosmOrderRequest;
import com.cloudwise.dosm.domain.request.DosmProcRequiredFieldRequest;
import com.cloudwise.dosm.domain.request.DosmProcessInfoRequest;
import com.cloudwise.dosm.vo.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * <p>
 * 模板信息对外业务
 * </p>
 *
 * @author rentingji
 * @since 2021/8/27 下午5:22
 **/
@RequestMapping("/dosm/dubbo/process")
public interface DosmProcessInfoService {

    /**
     * 流程启用
     */
    String PROCESS_ENABLE = "1";

    /**
     * 根据类型获取流程模板信息
     *
     * @param request
     * @return
     */

    @RequestMapping(method = RequestMethod.POST, value = "/getByType",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<ProcessInfoApiVO>> getByType(@RequestBody  DosmProcessInfoRequest request);

    /**
     * 根据PreNum获取流程模板名字
     *
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getNameByPreNum",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> getNameByPreNum(@RequestBody  DosmProcessInfoRequest request);

    /**
     * 根据工单id获取工单权限
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getAuthWorkOrderList",consumes = MediaType.APPLICATION_JSON_VALUE)
    List<OrderAuthInfoVo> getAuthWorkOrderList(@RequestBody DosmOrderRequest request);
    /**
     * 获取流程列表
     *
     * @param request 请求参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/pageList",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<ProcessInfoApiVO>> pageList(@RequestBody DosmProcessInfoRequest request);

    /**
     * 根据流程名获取流程信息
     * @param name
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getProcessDetailByName",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<ProcessDetailInfoVO> getProcessDetailByName(@RequestBody DosmProcessInfoRequest request, String name);

    /**
     * 获取流程列表
     *
     * @param request 请求参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getModelList",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<List<ProcessInfoApiVO>> getModelList(@RequestBody DosmProcessInfoRequest request);

    /**
     * 校验流程用户是否有创建工单权限
     */
    @RequestMapping(method = RequestMethod.POST, value = "/checkProcAuth",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Boolean> checkProcAuth(@RequestBody DosmProcessInfoRequest request);

    @RequestMapping(method = RequestMethod.POST, value = "/checkProcAuth4DOEM",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<ApiProcAuthVO> checkProcAuth4DOEM(@RequestBody DosmProcessInfoRequest request);

    /**
     * 获取流程必填字段
     *
     * @param request 请求参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getRequiredFields",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<NodeFormInfoApiVO> getRequiredFields(@RequestBody DosmProcRequiredFieldRequest request);


    /**
     * 根据工单id获取工单详情
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getWorkOrderDetailById",consumes = MediaType.APPLICATION_JSON_VALUE)
    List<DeskOrderInfoVoV2> getWorkOrderDetailById(@RequestBody DosmOrderRequest request);

    /**
     * 根据流程名获取流程前缀不区分租户
     * @param name
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getProcessPreNumName",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> getProcessPreNumName(@RequestBody DosmProcessInfoRequest request, String name);
}
