package com.cloudwise.dosm.duty.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Janet.Fu
 * @date 2022-08-11 10:34 上午
 * @description 值班日志标识
 */
@Getter
@AllArgsConstructor
public enum DutyLogStatusEnums {

    COMPLETE("已提交日志"),
    WARN("警告"),
    NO("值班未开始或值班中");

    private String code;
}
