package com.cloudwise.dosm.order.create;

import com.cloudwise.dosm.domain.base.DosmDubboResponse;
import com.cloudwise.dosm.domain.request.*;
import com.cloudwise.dosm.vo.ApiNodeAssignDto;
import com.cloudwise.dosm.vo.ApiWorkOrderStatusEnum;
import com.cloudwise.dosm.vo.DosmProcessConfigParam;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author scott 2021/8/24
 */

@RequestMapping("/dosm/dubbo/process")
public interface DosmWorkOrderProcessService {

    /**
     * 获取创建页详情
     */
    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/getCreatingInfo",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<DosmProcessConfigParam> getCreatingInfo(@RequestBody  DosmWorkOrderCreatingRequest request);

    /**
     * 获取下一节点处理方式
     *
     * @param request
     * @return
     */
    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/getAssigneeInfo",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<ApiNodeAssignDto> getAssigneeInfo(@RequestBody  DosmQueryAssigneeRequest request);

    /**
     * 执行创建工单逻辑
     *
     * @param request
     * @return
     */
    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/doCreateOrder",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Object> doCreateOrder(@RequestBody  DosmWorkOrderCreateRequest request);




    /**
     * 创建工单接口
     *
     * @param request 所需要参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/createOrder",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<String> createOrder(@RequestBody  DosmOrderCreateRequest request);

    @RequestMapping(method = RequestMethod.POST, value = "/orderCreateWithReturnInfo",consumes = MediaType.APPLICATION_JSON_VALUE)
    Object orderCreateWithReturnInfo(@RequestBody  DosmOrderCreateRequest request);

    /**
     * 删除工单接口
     *
     * @param request 所需要参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/deleteOrder",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Boolean> deleteOrder(@RequestBody  DosmOrderDeleteRequest request);

    /**
     * 关闭工单接口
     *
     * @param request 所需要参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/closeOrder",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<Boolean> closeOrder(@RequestBody  DosmOrderCloseRequest request);

    /**
     * 获取工单状态接口
     *
     * @param request 所需要参数
     */
    @RequestMapping(method = RequestMethod.POST, value = "/orderStatus",consumes = MediaType.APPLICATION_JSON_VALUE)
    DosmDubboResponse<ApiWorkOrderStatusEnum> orderStatus(@RequestBody  DosmOrderStatusRequest request);
}
