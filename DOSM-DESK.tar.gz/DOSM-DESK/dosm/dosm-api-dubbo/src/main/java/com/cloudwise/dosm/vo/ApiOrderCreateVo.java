package com.cloudwise.dosm.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author scott 2021/11/4
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiOrderCreateVo implements Serializable {

    @ApiModelProperty(value = "流程定义key")
    private String processDefKey;

    /**
     * 优化外部简单传参体验
     * 现在formData可能是任意类型，使用时需要仔细甄别
     */
    @ApiModelProperty(value = "表单数据")
    private Object formData;

    private Boolean testFlag = Boolean.TRUE;

    @ApiModelProperty(value = "工单来源,{网页表单:WEB_FORM,监控系统:MONITOR_SYSTEM,例行工作:ROUTINE_WORK}",example = "MONITOR_SYSTEM",required = true)
    private String sourceId;

    /**
     * 备选处理人，用于api创建工单时，节点处理人找不到的情况，必填
     */
    @ApiModelProperty(value = "备选处理人，用于api创建工单时，节点处理人找不到的情况", required = true)
    private List<ApiAssigneeInfo> candidateList;
    @ApiModelProperty(value = "服务项ID")
    private String serviceItemId;
    @ApiModelProperty(value = "服务目录ID")
    private String catalogId;
    @ApiModelProperty(value = "工单id,需要保证全局唯一")
    private String workOrderId;
}
