alter table mdl_form_templete add column personal bool default false;
alter table mdl_form_templete add column service_item_id varchar(255);
alter table mdl_form_templete add column service_item_name varchar(255);