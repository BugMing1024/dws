-- dosm_activiti.kafka_consumer definition

CREATE TABLE if not exists `kafka_consumer` (
  `id` varchar(100) NOT NULL,
  `topic` varchar(100) DEFAULT NULL,
  `message_model` varchar(100) DEFAULT NULL,
  `consume_mode` varchar(100) DEFAULT NULL,
  `selector_type` varchar(100) DEFAULT NULL,
  `tag_wildcard` varchar(100) DEFAULT NULL,
  `group_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- dosm_activiti.kafka_consumer_client definition

CREATE TABLE if not exists `kafka_consumer_client` (
  `id` varchar(100) NOT NULL,
  `consumer_id` varchar(100) DEFAULT NULL,
  `group_id` varchar(100) DEFAULT NULL,
  `client_ip` varchar(100) DEFAULT NULL,
  `last_fetch_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


