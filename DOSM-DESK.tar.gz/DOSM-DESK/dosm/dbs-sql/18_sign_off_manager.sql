CREATE TABLE if not exists sign_off_manager
(
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    created_time        timestamp default CURRENT_TIMESTAMP,
    updated_time        timestamp default CURRENT_TIMESTAMP,
    status              VARCHAR(255),
    top_account_id      VARCHAR(255),
    account_id          VARCHAR(255),
    sign_off_type       json,
    sign_off_group      VARCHAR(512),
    sign_off_user_group json,
    sign_off_user       json,
    artifact            json,
    case_id             json,
    work_order_id       VARCHAR(255)
);