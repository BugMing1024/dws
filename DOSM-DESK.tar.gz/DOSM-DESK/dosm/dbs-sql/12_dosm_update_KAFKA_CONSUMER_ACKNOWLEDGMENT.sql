drop procedure if exists `KAFKA_CONSUMER_ACKNOWLEDGMENT`;
DELIMITER $$
CREATE PROCEDURE `KAFKA_CONSUMER_ACKNOWLEDGMENT`(in topic varchar(100), in ids text, in status varchar(100))
begin

start transaction;

if ids is not null then

if status = 'COMPLETED' then

set
@insertsqlcmd = concat(
'
call `KAFKA_CONSUMER_MOVE2HISTORY`(''',topic,''', ''',ids,''',''COMPLETED'');
');

prepare stmt_acknowledgment
from
@insertsqlcmd;

execute stmt_acknowledgment;

deallocate prepare stmt_acknowledgment;

elseif status = 'FAILED' then

set
@failedsqlcmd = concat(
'
SET @ids_ = (
SELECT GROUP_CONCAT(id SEPARATOR '','')
        FROM (
			select
				id
			from
				kafka_ru_data_', topic, 
' where
		id in (', ids, ')
	and remaining_retry_times <= 1
			) AS subquery
    )');

prepare stmt_acknowledgment
from
@failedsqlcmd;

execute stmt_acknowledgment;

deallocate prepare stmt_acknowledgment;

if @ids IS NOT NULL then

set
@historysqlcmd = concat(
'call `KAFKA_CONSUMER_MOVE2HISTORY`(''',topic,''', @ids_,''FAILED'');');

prepare stmt_acknowledgment
from
@historysqlcmd;

execute stmt_acknowledgment;

deallocate prepare stmt_acknowledgment;

end if;


set
@updatesqlcmd = concat(
'
update kafka_ru_data_', topic, 
' set status = ''FAILED'', last_failure_time = NOW(3), remaining_retry_times = remaining_retry_times-1 
where 
	id in (', ids, ') and remaining_retry_times > 0');

prepare stmt_acknowledgment
from
@updatesqlcmd;

execute stmt_acknowledgment;

deallocate prepare stmt_acknowledgment;


else 

set
@updatesqlcmd = concat(
'
update kafka_ru_data_', topic, 
' set status = ''WAITING'' 
where 
	id in (', ids, ') ');

prepare stmt_acknowledgment
from
@updatesqlcmd;

execute stmt_acknowledgment;

deallocate prepare stmt_acknowledgment;


end if;

end if;

commit;

end$$
DELIMITER ;