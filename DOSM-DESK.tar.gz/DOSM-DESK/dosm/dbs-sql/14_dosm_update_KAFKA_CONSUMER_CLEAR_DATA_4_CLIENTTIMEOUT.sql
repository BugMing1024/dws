drop procedure if exists `KAFKA_CONSUMER_CLEAR_DATA_4_CLIENTTIMEOUT`;
DELIMITER $$
CREATE PROCEDURE `KAFKA_CONSUMER_CLEAR_DATA_4_CLIENTTIMEOUT`(in topic varchar(100), in clientTimeout INT)
begin
	
start transaction;

set
@selectrusqlcmd = concat(
'SET @ids = (
SELECT GROUP_CONCAT( id SEPARATOR '','')
        FROM ( select
		id
		from
		kafka_ru_data_', topic,'
		where
		group_id in (
		select client.group_id
		from
		kafka_consumer_client
		client
		join kafka_consumer consumer on
		client.consumer_id = consumer.id
		where
		topic = ''', topic,'''
		and (client.last_fetch_time is null or NOW(3) -
		client.last_fetch_time >=
		', clientTimeout, '))) AS subquery )');
prepare stmt_cleardata
from
@selectrusqlcmd;

execute stmt_cleardata;

deallocate prepare stmt_cleardata;

select @ids;

if @ids is not null then

set
@insertsqlcmd = concat(
'
call `KAFKA_CONSUMER_MOVE2HISTORY`(''',topic,''', @ids,''FAILED'');
');

prepare stmt_cleardata
from
@insertsqlcmd;

execute stmt_cleardata;

deallocate prepare stmt_cleardata;

end if;

commit;

end$$
DELIMITER ;