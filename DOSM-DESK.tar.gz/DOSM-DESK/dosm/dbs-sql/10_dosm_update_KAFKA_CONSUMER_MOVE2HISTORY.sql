drop procedure if exists `KAFKA_CONSUMER_MOVE2HISTORY`;

DELIMITER $$
CREATE PROCEDURE `KAFKA_CONSUMER_MOVE2HISTORY`(in topic varchar(100), in ids text, in status varchar(100))
begin
	
	if ids is not null then
	
set
@inserthisqlcmd = concat(
'
insert
	into
	kafka_hi_data_', topic, 
' (data_id,
	payload,
	tag,
	`key`,
	`partition`,
	message_time,
	group_id,
	status,
	handle_time,
	handler_client_id)
select
	id,
	payload,
	tag,
	`key`,
	`partition`,
	message_time,
	group_id,
	''', status,''',
	NOW(3),
	handler_client_id
from
	kafka_ru_data_', topic,
' where
	id in (', ids, ') ');

prepare stmt_move2history
from
@inserthisqlcmd;

execute stmt_move2history;

deallocate prepare stmt_move2history;

set
@deleterusqlcmd = concat(
'
delete from 
	kafka_ru_data_', topic, 
' where
	id in (', ids, ') ');

prepare stmt_move2history
from
@deleterusqlcmd;

execute stmt_move2history;

deallocate prepare stmt_move2history;

end if;

end$$
DELIMITER ;