CREATE TABLE if not exists dbs_rca_application_pending
(
    created_time      timestamp default CURRENT_TIMESTAMP,
    last_pending_time timestamp,
    application_name  VARCHAR(255),
    cr_work_order_id  VARCHAR(255),
    rca_work_order_id VARCHAR(255),
    is_pending        bool      default false
);