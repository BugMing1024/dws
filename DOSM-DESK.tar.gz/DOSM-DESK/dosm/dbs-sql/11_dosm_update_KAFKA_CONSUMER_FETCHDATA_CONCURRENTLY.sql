drop procedure if exists `KAFKA_CONSUMER_FETCHDATA_CONCURRENTLY`;
DELIMITER $$
CREATE PROCEDURE `KAFKA_CONSUMER_FETCHDATA_CONCURRENTLY`(in topic varchar(100), in group_id varchar(100), in limit_num INT, in client_id varchar(100), in timeout INT)
begin
	start transaction;

set
@sqlcmd = concat(
'
SET @ids = (
SELECT GROUP_CONCAT( id SEPARATOR '','')
        FROM (
			select
				id
			from
				kafka_ru_data_', topic, 
			' where
				status = ''WAITING''
				or (status = ''PROCESSING''
				and (NOW(3) - last_fetch_time) > ', timeout, ')
				or (status = ''FAILED''
				and remaining_retry_times > 0)
				and group_id = ''', group_id, ''' 
			 order by message_time 
			 limit ', limit_num, '
			) AS subquery
    )');

prepare stmt
from
@sqlcmd;

execute stmt;

deallocate prepare stmt;

if @ids IS NOT NULL then

set
@selectsqlcmd = concat(
'
select
	*
from
	kafka_ru_data_', topic, 
' where
	id in (', @ids, ')');

prepare stmt
from
@selectsqlcmd;

execute stmt;

deallocate prepare stmt;

set
@updatesqlcmd = concat(
'
update
	kafka_ru_data_', topic, 
' set status = ''PROCESSING'', last_fetch_time = NOW(3), handler_client_id = ''', client_id, '''
 where
	id in (', @ids, ')');

prepare stmt
from
@updatesqlcmd;

execute stmt;

deallocate prepare stmt;

end if;

set
@updatesqlcmd = concat(
'
update kafka_consumer_client set last_fetch_time = NOW(3) where id = ''', client_id, '''');

prepare stmt
from
@updatesqlcmd;

execute stmt;

deallocate prepare stmt;

commit;
end$$
DELIMITER ;