CREATE TABLE heighten_app_country
(
    app_code          varchar(100) NULL,
    country_of_origin varchar(100) NULL,
    country_impact    varchar(100) NULL,
    freeze_system     varchar(100) NULL,
    freeze_date       DATETIME     NULL,
    changed_date      DATETIME     NULL,
    description       varchar(100) NULL,
    freeze_type       varchar(100) NULL,
    freeze_reason     varchar(100) NULL,
    created_date      varchar(100) NULL,
    id                varchar(100) NULL COMMENT '惟一id，由app_code,country_impact,freeze_system,freeze_date,freeze_type拼接组成',
    save_date         DATETIME     NULL COMMENT '数据入库保存时间',
    CONSTRAINT heighten_app_country_pk PRIMARY KEY (id)
)
    ENGINE = InnoDB
    DEFAULT CHARSET = utf8mb3
    COLLATE = utf8mb3_general_ci
    COMMENT ='Heighten APP、Heighten Country';

CREATE TABLE freezed_holidays
(
    app_code     varchar(100)       NULL,
    freeze_date  DATETIME           NULL,
    changed_date varchar(100)       NULL,
    created_time DATETIME           NULL,
    freeze_type  varchar(100)       NULL,
    save_date    DATETIME           NULL COMMENT '数据入库保存时间',
    description  varchar(100)       NULL,
    id           INT auto_increment NULL,
    CONSTRAINT public_holidays_pk PRIMARY KEY (id)
)
    ENGINE = InnoDB
    DEFAULT CHARSET = utf8mb3
    COLLATE = utf8mb3_general_ci
    COMMENT ='freezed_holidays';
