-- cw_dosm072.dbs_api_log definition

CREATE TABLE if not exists `dbs_api_log` (
                               `id` bigint(20) NOT NULL,
                               `request_url` varchar(500) DEFAULT NULL,
                               `request_body` longtext DEFAULT NULL,
                               `response_body` longtext DEFAULT NULL,
                               `work_order_no` varchar(100) DEFAULT NULL,
                               `created_time` datetime DEFAULT CURRENT_TIME(),
                               `updated_time` datetime DEFAULT NULL,
                               `retry_time` int(11) DEFAULT NULL,
                               `api_module` varchar(100) DEFAULT NULL,
                               `request_status` tinyint(4) DEFAULT NULL,
                               PRIMARY KEY (`id`),
                               KEY `custom_api_log_api_module_IDX` (`api_module`) USING BTREE,
                               KEY `custom_api_log_work_order_no_IDX` (`work_order_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;