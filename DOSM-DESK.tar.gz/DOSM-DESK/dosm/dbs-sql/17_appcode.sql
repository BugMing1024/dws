DROP TABLE IF EXISTS `ic_appcode`;
CREATE TABLE IF NOT EXISTS `ic_appcode`
(
    `app_id`                    varchar(100) NOT NULL DEFAULT '',
    `app_name`                  varchar(100)          DEFAULT NULL,
    `app_owner`                 varchar(100)          DEFAULT NULL,
    `app_cat_level`             varchar(100)          DEFAULT NULL,
    `location`                  varchar(100)          DEFAULT NULL,
    `supplier`                  varchar(100)          DEFAULT NULL,
    `life_cycle_state`          varchar(100)          DEFAULT NULL,
    `sme1`                      varchar(100)          DEFAULT NULL,
    `sme2`                      varchar(100)          DEFAULT NULL,
    `hosting_loc`               varchar(100)          DEFAULT NULL,
    `info_type`                 varchar(100)          DEFAULT NULL,
    `support_unit`              varchar(100)          DEFAULT NULL,
    `techmd_email`              varchar(100)          DEFAULT NULL,
    `sme1_email`                varchar(100)          DEFAULT NULL,
    `sme2_email`                varchar(100)          DEFAULT NULL,
    `app_owner_email`           varchar(100)          DEFAULT NULL,
    `plat_form`                 varchar(100)          DEFAULT NULL,
    `plat_form_supplier`        varchar(100)          DEFAULT NULL,
    `mas`                       varchar(100)          DEFAULT NULL,
    `cll`                       varchar(100)          DEFAULT NULL,
    `cac`                       varchar(100)          DEFAULT NULL,
    `app_handover`              varchar(100)          DEFAULT NULL,
    `data_class`                varchar(100)          DEFAULT NULL,
    `secondary_app_owner`       varchar(100)          DEFAULT NULL,
    `secondary_app_owner_email` varchar(100)          DEFAULT NULL,
    `resiliency`                varchar(100)          DEFAULT NULL,
    `save_date`                 datetime              DEFAULT NULL,
    `id`                        int(11)      NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb3
  COLLATE = utf8mb3_general_ci COMMENT ='Get App Code Info';

DROP TABLE IF EXISTS `ic_server_detatils_t`;
CREATE TABLE IF NOT EXISTS `ic_server_detatils_t`
(
    `hostname`             varchar(500) NOT NULL DEFAULT '',
    `frame_name`           varchar(500)          DEFAULT NULL,
    `partition_type`       varchar(500)          DEFAULT NULL,
    `ipaddress`            varchar(500)          DEFAULT NULL,
    `network_zone`         varchar(500)          DEFAULT NULL,
    `infra_type`           varchar(500)          DEFAULT NULL,
    `platform`             varchar(500)          DEFAULT NULL,
    `environment`          varchar(500)          DEFAULT NULL,
    `system_type`          varchar(100)          DEFAULT NULL,
    `application_code`     varchar(100)          DEFAULT NULL,
    `application_category` varchar(100)          DEFAULT NULL,
    `lob`                  varchar(100)          DEFAULT NULL,
    `country`              varchar(100)          DEFAULT NULL,
    `status`               varchar(100)          DEFAULT NULL,
    `save_date`            datetime              DEFAULT NULL,
    `id`                   int(11)      NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb3
  COLLATE = utf8mb3_general_ci COMMENT ='invensys app details';
DROP TABLE IF EXISTS `ic_application_code_mapping_t`;
CREATE TABLE IF NOT EXISTS `ic_application_code_mapping_t`
(
    `app_code`                  varchar(100) DEFAULT NULL,
    `ichamp_lob`                varchar(100) DEFAULT NULL,
    `ichamp_country`            varchar(100) DEFAULT NULL,
    `overdue_ecr_or_rca_status` varchar(100) DEFAULT NULL,
    `id`                        int(11) NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 2
  DEFAULT CHARSET = utf8mb3
  COLLATE = utf8mb3_general_ci COMMENT ='mapping with lob country';

DROP TABLE IF EXISTS `ic_application_code_pending_project_list_t`;

CREATE TABLE IF NOT EXISTS `ic_application_code_pending_project_list_t`
(
    `cutover_cr`          varchar(100) DEFAULT NULL,
    `cutover_description` varchar(100) DEFAULT NULL,
    `cutover_status`      varchar(100) DEFAULT NULL,
    `app_code`            varchar(100) DEFAULT NULL,
    `id`                  int(11) NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 2
  DEFAULT CHARSET = utf8mb3
  COLLATE = utf8mb3_general_ci COMMENT ='App Codes Pending Project list';