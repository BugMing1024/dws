package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.metadata.mapper.IGroupDao;
import com.cloudwise.douc.metadata.mapper.IGroupDataDao;
import com.cloudwise.douc.metadata.mapper.IGroupDataGroupDao;
import com.cloudwise.douc.metadata.mapper.IMenuDao;
import com.cloudwise.douc.metadata.mapper.IModuleDao;
import com.cloudwise.douc.metadata.mapper.IResourceDataDao;
import com.cloudwise.douc.metadata.mapper.IResourceDataGroupDao;
import com.cloudwise.douc.metadata.mapper.IResourceMenuDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.mapper.IUserDataDao;
import com.cloudwise.douc.metadata.model.data.DataCodes;
import com.cloudwise.douc.metadata.model.data.GroupDataGroup;
import com.cloudwise.douc.metadata.model.data.RegisterDataGroup;
import com.cloudwise.douc.metadata.model.data.RegisterDataGroupRequestObject;
import com.cloudwise.douc.metadata.model.data.RemoveDataGroupRequestObject;
import com.cloudwise.douc.metadata.model.data.ResourceData;
import com.cloudwise.douc.metadata.model.data.ResourceDataGroup;
import com.cloudwise.douc.metadata.model.group.Group;
import com.cloudwise.douc.metadata.model.menu.Menu;
import com.cloudwise.douc.metadata.model.user.User;
import com.cloudwise.douc.service.model.data.RegisterDataItemObject;
import com.cloudwise.douc.service.model.data.RegisterDataItemRequestObject;
import com.cloudwise.douc.service.model.data.RemoveDataItemRequestObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 数据资源
 *
 * @author leakey.li
 * @description:
 * @date Created in 6:33 下午 2021/6/11.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({DataServiceImpl.class})
@PowerMockIgnore({"javax.management.*"})
public class DataServiceImplImplTest {

    @Mock
    private IMenuDao menuDao;
    @Mock
    private IModuleDao moduleDao;
    @Mock
    private IResourceDataGroupDao resourceDataGroupDao;
    @Mock
    private IResourceDataDao resourceDataDao;
    @Mock
    private IGroupDataGroupDao groupDataGroupDao;
    @Mock
    private IUserDao userDao;
    @Mock
    private IUserDataDao userDataDao;
    @Mock
    private IGroupDao groupDao;
    @Mock
    private IGroupDataDao groupDataDao;
    @Mock
    private IResourceMenuDao resourceMenuDao;
    @InjectMocks
    private DataServiceImpl dataServiceImpl;

    /**
     * @param
     * @return
     * @description 注册资源接口
     * @author leakey.li
     * @date 2021/6/11
     * @time 6:22 上午
     */
    @Test
    public void registerDataItem() throws Exception {
        //入参
        RegisterDataItemRequestObject registerDataItemRequestObject = new RegisterDataItemRequestObject();
        registerDataItemRequestObject.setAccountId(110L);
        registerDataItemRequestObject.setModuleCode("modudle1");
        List<RegisterDataItemObject> dataItems = new ArrayList<>();
        RegisterDataItemObject registerDataItemObject = new RegisterDataItemObject();
        registerDataItemObject.setDataItemCode("1002");
        List<Long> userIds = Lists.newArrayList();
        userIds.add(2L);
        registerDataItemObject.setUserIds(userIds);
        List<Long> groupIds = Lists.newArrayList();
        groupIds.add(2L);
        registerDataItemObject.setUserGroupIds(groupIds);
        registerDataItemObject.setDataTypeCode("100");
        registerDataItemObject.setDataGroupCode("");
        registerDataItemObject.setCreator("admin");
        registerDataItemObject.setName("test1");
        registerDataItemObject.setAccountId(110L);
        RegisterDataItemObject registerDataItemObject2 = new RegisterDataItemObject();
        registerDataItemObject2.setDataItemCode("1003");
        registerDataItemObject2.setUserIds(userIds);
        registerDataItemObject2.setUserGroupIds(groupIds);
        registerDataItemObject2.setDataTypeCode("100");
        registerDataItemObject2.setDataGroupCode("");
        registerDataItemObject2.setCreator("admin");
        registerDataItemObject2.setName("test2");
        registerDataItemObject2.setDescription("test2");
        dataItems.add(registerDataItemObject);
        dataItems.add(registerDataItemObject2);
        registerDataItemRequestObject.setDataItems(dataItems);

        //打桩
        //私有方法打桩 void
        DataServiceImpl privateDataServiceImpl = PowerMockito.spy(this.dataServiceImpl);
        PowerMockito.doNothing().when(privateDataServiceImpl, "registerSpecialDataItem", Mockito.any());

        //测试方法
        privateDataServiceImpl.registerDataItem(registerDataItemRequestObject);

        //验证
        PowerMockito.verifyPrivate(privateDataServiceImpl, Mockito.times(2)).invoke("registerSpecialDataItem", Mockito.any());

        //断言
        Assert.assertEquals(true, registerDataItemRequestObject.getDataItems().size() == 2);
    }

    /**
     * @param
     * @return
     * @description 注册数据资源菜单方法
     * @author leakey.li
     * @date 2021/6/15
     * @time 10:47 上午
     */
    @Test
    public void registerDataItemRegisterSpecialDataItem() throws Exception {
        //入参
        RegisterDataItemObject registerDataItemObject = new RegisterDataItemObject();
        registerDataItemObject.setDataItemCode("1002");
        List<Long> userIds = Lists.newArrayList();
        userIds.add(2L);
        registerDataItemObject.setUserIds(userIds);
        List<Long> groupIds = Lists.newArrayList();
        groupIds.add(2L);

        registerDataItemObject.setUserGroupIds(groupIds);
        registerDataItemObject.setDataTypeCode("100");
        registerDataItemObject.setDataGroupCode("120");
        registerDataItemObject.setCreator("admin");
        registerDataItemObject.setName("test1");
        registerDataItemObject.setAccountId(110L);
        registerDataItemObject.setModuleCode("modudle1");
        //打桩 //DAO打桩
        Menu dataTypeByAccountIdAndModuleCodeAndDataTypeCode = new Menu();
        dataTypeByAccountIdAndModuleCodeAndDataTypeCode.setCode("1002");
        dataTypeByAccountIdAndModuleCodeAndDataTypeCode.setAccountId(110L);
        dataTypeByAccountIdAndModuleCodeAndDataTypeCode.setModuleCode("modudle1");
        Mockito.when(menuDao.getDataTypeByAccountIdAndModuleCodeAndDataTypeCode(Mockito.any())).thenReturn(dataTypeByAccountIdAndModuleCodeAndDataTypeCode);

        ResourceDataGroup resourceDataGroup = new ResourceDataGroup();
        resourceDataGroup.setAccountId(registerDataItemObject.getAccountId());
        resourceDataGroup.setCode(registerDataItemObject.getDataGroupCode());
        resourceDataGroup.setModuleCode(registerDataItemObject.getModuleCode());
        resourceDataGroup.setLevel("0");
        resourceDataGroup.setDataTypeCode(registerDataItemObject.getDataTypeCode());
        Mockito.when(resourceDataGroupDao.getGroupByModuleCodeAndGroupCodeAndAccountId(Mockito.any())).thenReturn(resourceDataGroup);

        //判断数据code是否已经存在
        ResourceData resourceDataByModuleCodeAndDataTypeCodeAndDataCode = null;
        Mockito.when(resourceDataDao.getResourceDataByModuleCodeAndDataTypeCodeAndDataCode(Mockito.any())).thenReturn(resourceDataByModuleCodeAndDataTypeCodeAndDataCode);

        Integer maxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode = 2;
        Mockito.when(resourceDataDao.getMaxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode(Mockito.any())).thenReturn(maxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode);

        //addResourceData
        Mockito.when(resourceDataDao.addResourceData(Mockito.any())).thenReturn(1);

        //userId非空,判定是否合法 建立用户和数据的直接关系
        if (CollectionUtils.isNotEmpty(registerDataItemObject.getUserIds())) {

            List<User> databaseUserList = new ArrayList<>();
            User user = new User();
            user.setId(2L);
            user.setAccountId(110L);
            databaseUserList.add(user);
            Mockito.when(userDao.getMultiUser(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(databaseUserList);

            Mockito.when(userDataDao.addUserData(Mockito.any())).thenReturn(1);
        }

        //userGroupIds非空
        List<Long> userGroupIds = registerDataItemObject.getUserGroupIds();
        if (CollectionUtils.isNotEmpty(userGroupIds)) {

            List<Group> groups = new ArrayList<>();
            Group group = new Group();
            group.setId(2L);
            group.setAccountId(110L);
            group.setLevel("0");
            groups.add(group);
            Mockito.when(groupDao.listGroupByIds(Mockito.anyList(), Mockito.anyLong())).thenReturn(groups);

            //用户组和数据组关系
            Mockito.when(groupDataDao.addGroupData(Mockito.any())).thenReturn(1);

            List<GroupDataGroup> databaseGroupDataGroupList = new ArrayList<>();
            GroupDataGroup groupDataGroup = new GroupDataGroup(110L, 2L, "120", "modudle1", "100", 1, 1);
            databaseGroupDataGroupList.add(groupDataGroup);
            Mockito.when(groupDataGroupDao.listGroupDataGroupByCondition(Mockito.any())).thenReturn(databaseGroupDataGroupList);

            Mockito.when(groupDataGroupDao.addGroupDataGroupByList(Mockito.any())).thenReturn(3);

        }
        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "registerSpecialDataItem", registerDataItemObject);

        //校验打桩接口执行
        Mockito.verify(menuDao, Mockito.atLeastOnce()).getDataTypeByAccountIdAndModuleCodeAndDataTypeCode(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).getGroupByModuleCodeAndGroupCodeAndAccountId(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).getMaxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).addResourceData(Mockito.any());

        Mockito.verify(userDao, Mockito.atLeastOnce()).getMultiUser(Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.verify(userDataDao, Mockito.atLeastOnce()).addUserData(Mockito.any());

        Mockito.verify(groupDao, Mockito.atLeastOnce()).listGroupByIds(Mockito.anyList(), Mockito.anyLong());
        //用户组和数据组关系
        Mockito.verify(groupDataDao, Mockito.atLeastOnce()).addGroupData(Mockito.any());
        Mockito.verify(groupDataDao, Mockito.atLeastOnce()).addGroupData(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).listGroupDataGroupByCondition(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).addGroupDataGroupByList(Mockito.any());

    }

    /**
     * @param
     * @return
     * @description 注册数据资源菜单方法 用户名和groupId是空
     * @author leakey.li
     * @date 2021/6/15
     * @time 10:47 上午
     */
    @Test
    public void registerDataItemRegisterSpecialDataItem2UserIsAndGroupIdIsEmpty() throws Exception {
        //入参
        RegisterDataItemObject registerDataItemObject = new RegisterDataItemObject();
        registerDataItemObject.setDataItemCode("1002");

        registerDataItemObject.setDataTypeCode("100");
        registerDataItemObject.setDataGroupCode("120");
        registerDataItemObject.setCreator("admin");
        registerDataItemObject.setName("test1");
        registerDataItemObject.setAccountId(110L);
        registerDataItemObject.setModuleCode("modudle1");
        //打桩 //DAO打桩
        Menu dataTypeByAccountIdAndModuleCodeAndDataTypeCode = new Menu();
        dataTypeByAccountIdAndModuleCodeAndDataTypeCode.setCode("1002");
        dataTypeByAccountIdAndModuleCodeAndDataTypeCode.setAccountId(110L);
        dataTypeByAccountIdAndModuleCodeAndDataTypeCode.setModuleCode("modudle1");
        Mockito.when(menuDao.getDataTypeByAccountIdAndModuleCodeAndDataTypeCode(Mockito.any())).thenReturn(dataTypeByAccountIdAndModuleCodeAndDataTypeCode);

        ResourceDataGroup resourceDataGroup = new ResourceDataGroup();
        resourceDataGroup.setAccountId(registerDataItemObject.getAccountId());
        resourceDataGroup.setCode(registerDataItemObject.getDataGroupCode());
        resourceDataGroup.setModuleCode(registerDataItemObject.getModuleCode());
        resourceDataGroup.setLevel("0");
        resourceDataGroup.setDataTypeCode(registerDataItemObject.getDataTypeCode());
        Mockito.when(resourceDataGroupDao.getGroupByModuleCodeAndGroupCodeAndAccountId(Mockito.any())).thenReturn(resourceDataGroup);

        //判断数据code是否已经存在
        ResourceData resourceDataByModuleCodeAndDataTypeCodeAndDataCode = null;
        Mockito.when(resourceDataDao.getResourceDataByModuleCodeAndDataTypeCodeAndDataCode(Mockito.any())).thenReturn(resourceDataByModuleCodeAndDataTypeCodeAndDataCode);

        Integer maxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode = 2;
        Mockito.when(resourceDataDao.getMaxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode(Mockito.any())).thenReturn(maxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode);

        //addResourceData
        Mockito.when(resourceDataDao.addResourceData(Mockito.any())).thenReturn(1);


        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "registerSpecialDataItem", registerDataItemObject);

        //校验打桩接口执行
        Mockito.verify(menuDao, Mockito.atLeastOnce()).getDataTypeByAccountIdAndModuleCodeAndDataTypeCode(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).getGroupByModuleCodeAndGroupCodeAndAccountId(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).getMaxSequenceByModuleCodeAndDataTypeCodeAndDataGroupCode(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).addResourceData(Mockito.any());

    }

    /**
     * {@link DataServiceImpl#registerDataGroup(RegisterDataGroupRequestObject)}
     *
     * @return
     * @description 数据资源组注册
     * @author leakey.li
     * @date 2021/6/15
     * @time 7:33 下午
     */
    @Test
    public void registerDataGroup() throws Exception {
        //入参
        RegisterDataGroupRequestObject registerDataGroupRequestObject = new RegisterDataGroupRequestObject();
        registerDataGroupRequestObject.setAccountId(110L);
        registerDataGroupRequestObject.setModuleCode("module1");
        List<RegisterDataGroup> dataGroups = new ArrayList<>();
        RegisterDataGroup registerDataGroup = new RegisterDataGroup();
        registerDataGroup.setName("分组1");
        registerDataGroup.setDataTypeCode("1002");
        registerDataGroup.setAccountId(110L);
        registerDataGroup.setCode("1000");
        RegisterDataGroup registerDataGroup1 = new RegisterDataGroup();
        registerDataGroup1.setName("分组1-1");
        registerDataGroup1.setDataTypeCode("1002");
        registerDataGroup1.setAccountId(110L);
        registerDataGroup1.setCode("1001");
        registerDataGroup1.setParentCode("1000");
        dataGroups.add(registerDataGroup);
        dataGroups.add(registerDataGroup1);
        registerDataGroupRequestObject.setDataGroups(dataGroups);
        Set<String> dataTypeCodeSet = Sets.newHashSet();

        for (RegisterDataGroup register : registerDataGroupRequestObject.getDataGroups()) {
            dataTypeCodeSet.add(register.getDataTypeCode());
        }
        //打桩
        Mockito.when(moduleDao.countModuleByCode(Mockito.anyString())).thenReturn(1);
        Mockito.when(resourceDataGroupDao.countDataGroup(Mockito.any())).thenReturn(0);
        Mockito.when(resourceMenuDao.countDataTypeCode(Mockito.any())).thenReturn(dataTypeCodeSet.size());

        List<GroupDataGroup> groupDataGroups = new ArrayList<>();
        Mockito.when(groupDataGroupDao.getParentGroupRelation(Mockito.any())).thenReturn(groupDataGroups);

        RegisterDataGroup parent = new RegisterDataGroup();
        parent.setCode("1000");
        parent.setAccountId(110L);
        parent.setParentCode("");
        parent.setModuleCode("module1");
        Mockito.when(resourceDataGroupDao.getDataGroupInfo(Mockito.any())).thenReturn(parent);
        Mockito.when(resourceDataGroupDao.getMaxSequenceByParentCode(Mockito.any())).thenReturn(2);
        List<GroupDataGroup> parentRelations = new ArrayList<>();
        GroupDataGroup groupDataGroup = new GroupDataGroup();
        groupDataGroup.setGroupId(2L);
        groupDataGroup.setAccountId(110L);
        groupDataGroup.setDataTypeCode("1002");
        groupDataGroup.setModuleCode("module1");
        groupDataGroup.setDataGroupCode("1004");
        groupDataGroup.setIncludeFuture(1);
        parentRelations.add(groupDataGroup);
        Mockito.when(groupDataGroupDao.getParentGroupRelation(Mockito.any())).thenReturn(parentRelations);
        Mockito.when(groupDataGroupDao.addGroupDataGroupByList(Mockito.anyList())).thenReturn(2);

        Mockito.when(resourceDataGroupDao.countGroupDataByParentCode(Mockito.any())).thenReturn(1);
        Mockito.when(resourceDataGroupDao.addGroupDataGroup(Mockito.any())).thenReturn(registerDataGroupRequestObject.getDataGroups().size());

        //测试调用的方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "registerDataGroup", registerDataGroupRequestObject);

        //验证打桩执行
        Mockito.verify(moduleDao, Mockito.atLeastOnce()).countModuleByCode(Mockito.anyString());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).countDataGroup(Mockito.any());
        Mockito.verify(resourceMenuDao, Mockito.atLeastOnce()).countDataTypeCode(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).getParentGroupRelation(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).getDataGroupInfo(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).getMaxSequenceByParentCode(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).getParentGroupRelation(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).addGroupDataGroupByList(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).addGroupDataGroup(Mockito.any());

    }

    /**
     * {@link DataServiceImpl#removeDataItem(RemoveDataItemRequestObject)}
     *
     * @return
     * @description 取消数据资源组注册
     * @author leakey.li
     * @date 2021/6/16
     * @time 10:51 上午
     */
    @Test
    public void removeDataItem() throws Exception {
        //入参
        RemoveDataItemRequestObject removeDataItemRequestObject = new RemoveDataItemRequestObject();
        removeDataItemRequestObject.setModuleCode("module1");
        removeDataItemRequestObject.setAccountId(110L);
        List<DataCodes> dataItems = new ArrayList<>();
        DataCodes dataCodes = new DataCodes();
        dataCodes.setDataTypeCode("1002");
        dataCodes.setDataGroupCode("1111");
        List<String> dataItemCodes = new ArrayList<>();
        dataItemCodes.add("10000");
        dataItemCodes.add("20000");
        dataItemCodes.add("30000");
        dataCodes.setDataItemCodes(dataItemCodes);
        dataItems.add(dataCodes);
        removeDataItemRequestObject.setDataItems(dataItems);

        //打桩
        Mockito.when(resourceDataDao.backupResourceData(Mockito.any())).thenReturn(dataItemCodes.size());
        Mockito.when(resourceDataDao.deleteResourceData(Mockito.any())).thenReturn(dataItemCodes.size());
        Mockito.when(userDataDao.backupUserData(Mockito.any())).thenReturn(1);
        Mockito.when(userDataDao.deleteUserData(Mockito.any())).thenReturn(1);
        Mockito.when(groupDataDao.backupGroupData(Mockito.any())).thenReturn(1);
        Mockito.when(groupDataDao.deleteGroupData(Mockito.any())).thenReturn(1);

        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "removeDataItem", removeDataItemRequestObject);

        //校验
        Mockito.verify(this.resourceDataDao, Mockito.atLeastOnce()).backupResourceData(Mockito.any());
        Mockito.verify(this.resourceDataDao, Mockito.atLeastOnce()).deleteResourceData(Mockito.any());
        Mockito.verify(this.userDataDao, Mockito.atLeastOnce()).backupUserData(Mockito.any());
        Mockito.verify(this.userDataDao, Mockito.atLeastOnce()).deleteUserData(Mockito.any());
        Mockito.verify(this.groupDataDao, Mockito.atLeastOnce()).backupGroupData(Mockito.any());
        Mockito.verify(this.groupDataDao, Mockito.atLeastOnce()).deleteGroupData(Mockito.any());
    }

    /**
     * {@link DataServiceImpl#updateDataGroup(RegisterDataGroup)}
     *
     * @return
     * @description 取消数据资源组注册
     * @author leakey.li
     * @date 2021/6/16
     * @time 11:51 上午
     */
    @Test
    public void updateDataGroup() throws Exception {
        //入参
        RegisterDataGroup registerDataGroup = new RegisterDataGroup();
        registerDataGroup.setModuleCode("module1");
        registerDataGroup.setAccountId(110L);
        registerDataGroup.setName("test110");
        registerDataGroup.setCode("1002");
        registerDataGroup.setDataTypeCode("1000");

        //打桩
        Mockito.when(resourceDataGroupDao.updateDataGroup(Mockito.any())).thenReturn(1);

        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "updateDataGroup", registerDataGroup);
        //校验
        Mockito.verify(this.resourceDataGroupDao, Mockito.atLeastOnce()).updateDataGroup(Mockito.any());

    }

    /**
     * {@link DataServiceImpl#updateDataItem(RegisterDataItemObject)}
     *
     * @return
     * @description 更新数据资源
     * @author leakey.li
     * @date 2021/6/16
     * @time 13:51 上午
     */
    @Test
    public void updateDataItem() throws Exception {
        //入参
        RegisterDataItemObject registerDataItemObject = new RegisterDataItemObject();
        registerDataItemObject.setDataItemCode("1111");
        registerDataItemObject.setModuleCode("module1");
        registerDataItemObject.setName("test333");
        registerDataItemObject.setAccountId(110L);
        registerDataItemObject.setDataTypeCode("1002");
        registerDataItemObject.setDataGroupCode("1000");

        //打桩
        Mockito.when(resourceDataDao.updateResourceData(Mockito.any())).thenReturn(1);

        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "updateDataItem", registerDataItemObject);

        //校验
        Mockito.verify(this.resourceDataDao, Mockito.atLeastOnce()).updateResourceData(Mockito.any());

    }

    /**
     * {@link DataServiceImpl#removeDataGroup(RemoveDataGroupRequestObject)}
     *
     * @return
     * @description 据资源组取消注册
     * @author leakey.li
     * @date 2021/6/16
     * @time 14:51 上午
     */
    @Test
    public void removeDataGroup() throws Exception {
        RemoveDataGroupRequestObject removeDataGroupRequestObject = new RemoveDataGroupRequestObject();
        removeDataGroupRequestObject.setAccountId(110L);
        removeDataGroupRequestObject.setModuleCode("module1");
        List<DataCodes> dataGroups = new ArrayList<>();
        DataCodes dataCodes = new DataCodes();
        dataCodes.setDataTypeCode("1002");
        List<String> dataGroupCodes = new ArrayList<>();
        dataGroupCodes.add("10001");
        dataGroupCodes.add("10002");
        dataGroupCodes.add("10003");
        dataCodes.setDataGroupCodes(dataGroupCodes);
        DataCodes dataCodes1 = new DataCodes();
        dataCodes1.setDataTypeCode("1002");
        List<String> dataGroupCodes1 = new ArrayList<>();
        dataGroupCodes1.add("10001");
        dataGroupCodes1.add("10002");
        dataGroupCodes1.add("10003");
        dataCodes1.setDataGroupCodes(dataGroupCodes1);
        DataCodes dataCodes2 = new DataCodes();
        dataCodes2.setDataTypeCode("1002");
        List<String> dataGroupCodes2 = new ArrayList<>();
        dataGroupCodes2.add("10001");
        dataGroupCodes2.add("10002");
        dataGroupCodes2.add("10003");
        dataCodes2.setDataGroupCodes(dataGroupCodes2);
        dataGroups.add(dataCodes);
        dataGroups.add(dataCodes1);
        dataGroups.add(dataCodes2);
        removeDataGroupRequestObject.setDataGroups(dataGroups);

        //打桩
        List<RegisterDataGroup> registerDataGroup = new ArrayList<>();
        RegisterDataGroup registerDataGroup1 = new RegisterDataGroup();
        registerDataGroup1.setAccountId(110L);
        registerDataGroup1.setDataTypeCode("1002");
        registerDataGroup1.setModuleCode("module1");
        registerDataGroup.add(registerDataGroup1);
        Mockito.when(resourceDataGroupDao.getOldInGroupDatas(Mockito.any())).thenReturn(registerDataGroup);

        List<RegisterDataGroup> allRegisterDataGroup = new ArrayList<>();
        RegisterDataGroup registerDataGroup2 = new RegisterDataGroup();
        registerDataGroup2.setAccountId(110L);
        registerDataGroup2.setDataTypeCode("1003");
        registerDataGroup2.setModuleCode("module1");
        allRegisterDataGroup.add(registerDataGroup2);
        Mockito.when(resourceDataGroupDao.getChildInGroupDatas(Mockito.any())).thenReturn(allRegisterDataGroup);

        List<ResourceData> resourceDataList = new ArrayList<>();
        ResourceData resourceData = new ResourceData();
        resourceData.setDataGroupCode("10002");
        resourceData.setDataTypeCode("1002");
        resourceData.setCode("10003");
        resourceData.setModuleCode("module1");
        resourceDataList.add(resourceData);
        Mockito.when(resourceDataDao.getDataByDataGroup(Mockito.any())).thenReturn(resourceDataList);

        Mockito.when(resourceDataDao.backupResourceData(Mockito.any())).thenReturn(1);
        Mockito.when(resourceDataDao.deleteResourceData(Mockito.any())).thenReturn(1);
        Mockito.when(groupDataDao.backupGroupData(Mockito.any())).thenReturn(1);
        Mockito.when(groupDataDao.deleteGroupData(Mockito.any())).thenReturn(1);
        Mockito.when(userDataDao.backupUserData(Mockito.any())).thenReturn(1);
        Mockito.when(userDataDao.deleteUserData(Mockito.any())).thenReturn(1);
        Mockito.when(resourceDataGroupDao.backupGroupDataGroup(Mockito.any())).thenReturn(1);
        Mockito.when(resourceDataGroupDao.deleteGroupDataGroup(Mockito.any())).thenReturn(1);
        Mockito.when(groupDataGroupDao.backupGroupRelationByGroupList(Mockito.any())).thenReturn(1);
        Mockito.when(groupDataGroupDao.deleteGroupRelationByGroupList(Mockito.any())).thenReturn(1);

        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "removeDataGroup", removeDataGroupRequestObject);

        //校验
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).getOldInGroupDatas(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).getChildInGroupDatas(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).getDataByDataGroup(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).backupResourceData(Mockito.any());
        Mockito.verify(resourceDataDao, Mockito.atLeastOnce()).deleteResourceData(Mockito.any());
        Mockito.verify(groupDataDao, Mockito.atLeastOnce()).backupGroupData(Mockito.any());
        Mockito.verify(groupDataDao, Mockito.atLeastOnce()).deleteGroupData(Mockito.any());
        Mockito.verify(userDataDao, Mockito.atLeastOnce()).backupUserData(Mockito.any());
        Mockito.verify(userDataDao, Mockito.atLeastOnce()).deleteUserData(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).backupGroupDataGroup(Mockito.any());
        Mockito.verify(resourceDataGroupDao, Mockito.atLeastOnce()).deleteGroupDataGroup(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).backupGroupRelationByGroupList(Mockito.any());
        Mockito.verify(groupDataGroupDao, Mockito.atLeastOnce()).deleteGroupRelationByGroupList(Mockito.any());

    }

    /**
     * {@link //DataService.buildTreeAndAddLevel(List<RegisterDataGroup>,Map<String,RegisterDataGroup>,List<RegisterDataGroup>)}
     *
     * @return
     * @description 建立数据树
     * @author leakey.li
     * @date 2021/6/16
     * @time 14:51 上午
     */
    @Test
    public void registerDataGroupBuildTreeAndAddLevel() throws Exception {
        //入参
        List<RegisterDataGroup> rootRegisterDataGroupList = new ArrayList<>();
        RegisterDataGroup registerDataGroup = new RegisterDataGroup();
        registerDataGroup.setName("分组1");
        registerDataGroup.setDataTypeCode("1002");
        registerDataGroup.setAccountId(110L);
        registerDataGroup.setCode("1000");
        rootRegisterDataGroupList.add(registerDataGroup);

        Map<String, RegisterDataGroup> registerDataGroupMap = new HashMap<>();

        List<RegisterDataGroup> registerDataGroupList = new ArrayList<>();
        RegisterDataGroup registerDataGroup3 = new RegisterDataGroup();
        registerDataGroup3.setName("分组1");
        registerDataGroup3.setDataTypeCode("1002");
        registerDataGroup3.setAccountId(110L);
        registerDataGroup3.setCode("1000");
        registerDataGroupMap.put("1000", registerDataGroup3);

        RegisterDataGroup registerDataGroup4 = new RegisterDataGroup();
        registerDataGroup4.setName("分组1-1");
        registerDataGroup4.setDataTypeCode("1002");
        registerDataGroup4.setAccountId(110L);
        registerDataGroup4.setCode("1001");
        registerDataGroup4.setParentCode("1000");
        registerDataGroup4.setLevel("1000.1001");
        registerDataGroupMap.put("1001", registerDataGroup4);
        registerDataGroupList.add(registerDataGroup3);
        registerDataGroupList.add(registerDataGroup4);

        //调用测试方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "buildTreeAndAddLevel", rootRegisterDataGroupList, registerDataGroupMap, registerDataGroupList);

    }

    /**
     * {@link //DataService.traverseAndAddLevel(RegisterDataGroup)}
     *
     * @return
     * @description 树转换添加level
     * @author leakey.li
     * @date 2021/6/16
     * @time 14:51 上午
     */
    @Test
    public void buildTreeAndAddLevelTraverseAndAddLevel() throws Exception {
        //入参
        RegisterDataGroup registerDataGroup = new RegisterDataGroup();
        registerDataGroup.setAccountId(110L);
        registerDataGroup.setModuleCode("module1");
        List<RegisterDataGroup> registerDataGroupList = new ArrayList<>();
        RegisterDataGroup registerDataGroup3 = new RegisterDataGroup();
        registerDataGroup3.setName("分组1");
        registerDataGroup3.setDataTypeCode("1002");
        registerDataGroup3.setAccountId(110L);
        registerDataGroup3.setCode("1000");
        RegisterDataGroup registerDataGroup4 = new RegisterDataGroup();
        registerDataGroup4.setName("分组2");
        registerDataGroup4.setDataTypeCode("1002");
        registerDataGroup4.setAccountId(110L);
        registerDataGroup4.setCode("1003");
        registerDataGroupList.add(registerDataGroup3);
        registerDataGroupList.add(registerDataGroup4);
        registerDataGroup.setDataGroups(registerDataGroupList);
        //打桩

        //调用方法
        Whitebox.invokeMethod(this.dataServiceImpl,
                "traverseAndAddLevel", registerDataGroup);
    }

    /**
     * {@link //DataService.traverseAndAddLevel(RegisterDataGroup)}
     *
     * @return
     * @description 设置父级的inFuture字段
     * @author leakey.li
     * @date 2021/6/16
     * @time 14:51 上午
     */
    @Test
    public void registerDataGroupSetInFutureByParent() throws Exception {
        //入参
        RegisterDataGroup registerDataGroup = new RegisterDataGroup();
        registerDataGroup.setAccountId(110L);
        registerDataGroup.setModuleCode("module1");
        List<RegisterDataGroup> registerDataGroupList = new ArrayList<>();
        RegisterDataGroup registerDataGroup3 = new RegisterDataGroup();
        registerDataGroup3.setName("分组1");
        registerDataGroup3.setDataTypeCode("1002");
        registerDataGroup3.setAccountId(110L);
        registerDataGroup3.setCode("1000");
        RegisterDataGroup registerDataGroup4 = new RegisterDataGroup();
        registerDataGroup4.setName("分组2");
        registerDataGroup4.setDataTypeCode("1003");
        registerDataGroup4.setAccountId(110L);
        registerDataGroup4.setCode("1003");
        registerDataGroupList.add(registerDataGroup3);
        registerDataGroupList.add(registerDataGroup4);
        registerDataGroup.setDataGroups(registerDataGroupList);
        //打桩
        List<GroupDataGroup> parentRelations = new ArrayList<>();
        GroupDataGroup groupDataGroup = new GroupDataGroup();
        groupDataGroup.setType(1);
        groupDataGroup.setDataGroupCode("10002");
        groupDataGroup.setGroupId(2L);
        groupDataGroup.setAccountId(110L);
        groupDataGroup.setIncludeFuture(1);
        groupDataGroup.setDataTypeCode("1002");
        groupDataGroup.setModuleCode("module1");
        parentRelations.add(groupDataGroup);
        Mockito.when(groupDataGroupDao.getParentGroupRelation(Mockito.any())).thenReturn(parentRelations);
        //调用测试方法
        List<GroupDataGroup> groupDataGroups = Whitebox.invokeMethod(this.dataServiceImpl,
                "setInFutureByParent", registerDataGroup);
        //校验
        Mockito.verify(this.groupDataGroupDao, Mockito.atLeastOnce()).getParentGroupRelation(Mockito.any());
        //断言
        boolean result = groupDataGroups.size() > 0 && groupDataGroups.get(0).getDataTypeCode().equals(groupDataGroup.getDataTypeCode());
        Assert.assertEquals(true, result);
    }


}
