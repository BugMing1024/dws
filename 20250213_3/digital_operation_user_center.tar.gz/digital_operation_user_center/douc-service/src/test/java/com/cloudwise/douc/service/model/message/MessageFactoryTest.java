package com.cloudwise.douc.service.model.message;

import lombok.extern.slf4j.Slf4j;

/**
 * @author leakey.li
 * @description: 创建短信模板类工厂
 * @date Created in 3:29 下午 2022/2/21.
 */
@Slf4j
public class MessageFactoryTest {

    public static void main(String[] args) {
        AbstractMessageTemplate template = MessageFactory.getMessageTemplate("86", "11111", "3323", "34.00,12.0", "XING_YE");
        log.info("{}", template);
    }

}