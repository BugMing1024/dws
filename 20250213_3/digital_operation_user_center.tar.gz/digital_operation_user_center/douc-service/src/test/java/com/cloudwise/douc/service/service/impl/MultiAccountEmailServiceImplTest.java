package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.metadata.mapper.IMultiAccountEmailRecordDao;
import com.cloudwise.douc.service.model.multi.email.BatchMsgInfoBo;
import com.cloudwise.douc.service.model.multi.email.SingleMsgInfoBo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.support.membermodification.MemberModifier;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * 邮件UT
 * case中的邮件如果失效,替换成一个有效的即可
 *
 * @author maker.wang
 * @date 2021-07-16 14:07
 **/
@RunWith(PowerMockRunner.class)
@PrepareForTest({DataV2ServiceImpl.class})
@PowerMockIgnore({"javax.management.*", "javax.script.*"})
public class MultiAccountEmailServiceImplTest {

    @Mock
    private IMultiAccountEmailRecordDao iMultiAccountEmailRecordDao;

    @InjectMocks
    private MultiAccountEmailServiceImpl multiAccountEmailService;

    /**
     * 可正常发送邮件
     *
     * @author maker.wang
     * @date 2021-07-17 10:51
     **/
    @Test
    public void sendSingleEmail() throws IllegalAccessException {
        SingleMsgInfoBo singleMsgInfoBo = new SingleMsgInfoBo();
        singleMsgInfoBo.setMsgTitle("邀请");
        singleMsgInfoBo.setMsgContent("aliali");
        singleMsgInfoBo.setReceiveEmail("xyw10051@126.com");
        singleMsgInfoBo.setSendAccountId(9999L);
        singleMsgInfoBo.setSendUserId(1L);

        MemberModifier.field(MultiAccountEmailServiceImpl.class, "emailHost").set(this.multiAccountEmailService, "smtp.163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "emailPort").set(this.multiAccountEmailService, 25);
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "fromEmail").set(this.multiAccountEmailService, "cloudwise_douc@163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "username").set(this.multiAccountEmailService, "cloudwise_douc@163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "password").set(this.multiAccountEmailService, "IJBJCDJFJBUTXPIC");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "authentication").set(this.multiAccountEmailService, true);

        Mockito.doReturn(1).when(this.iMultiAccountEmailRecordDao).addEmailRecord(Mockito.any());
        int result = this.multiAccountEmailService.sendSingleEmail(singleMsgInfoBo);
        Assert.assertEquals(1, result);
    }

    /**
     * 可正常发送邮件
     *
     * @author maker.wang
     * @date 2021-07-17 10:51
     **/
    @Test
    public void sendSingleEmailErrorEmail() throws IllegalAccessException {
        SingleMsgInfoBo singleMsgInfoBo = new SingleMsgInfoBo();
        singleMsgInfoBo.setMsgTitle("邀请");
        singleMsgInfoBo.setMsgContent("aliali");
        singleMsgInfoBo.setReceiveEmail("xyw1005@12888.com");
        singleMsgInfoBo.setSendAccountId(9999L);
        singleMsgInfoBo.setSendUserId(1L);

        MemberModifier.field(MultiAccountEmailServiceImpl.class, "emailHost").set(this.multiAccountEmailService, "smtp.163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "emailPort").set(this.multiAccountEmailService, 25);
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "fromEmail").set(this.multiAccountEmailService, "cloudwise_douc@163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "username").set(this.multiAccountEmailService, "cloudwise_douc@163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "password").set(this.multiAccountEmailService, "IJBJCDJFJBUTXPIC");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "authentication").set(this.multiAccountEmailService, true);
        try {
            this.multiAccountEmailService.sendSingleEmail(singleMsgInfoBo);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_SEND_ERROR, e.getCode());
        }
    }

    @Test
    public void sendBatchEmail() throws IllegalAccessException {
        BatchMsgInfoBo batchMsgInfoBo = new BatchMsgInfoBo();
        batchMsgInfoBo.setMsgTitle("邀请");
        batchMsgInfoBo.setMsgContent("批量发送单元测试");
        batchMsgInfoBo.setReceiveEmailList(new String[]{"xyw1005@126.com", "maker.wang@yunzhihui.com"});
        batchMsgInfoBo.setSendAccountId(9999L);
        batchMsgInfoBo.setSendUserId(1L);

        MemberModifier.field(MultiAccountEmailServiceImpl.class, "emailHost").set(this.multiAccountEmailService, "smtp.163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "emailPort").set(this.multiAccountEmailService, 25);
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "fromEmail").set(this.multiAccountEmailService, "cloudwise_douc@163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "username").set(this.multiAccountEmailService, "cloudwise_douc@163.com");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "password").set(this.multiAccountEmailService, "IJBJCDJFJBUTXPIC");
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "authentication").set(this.multiAccountEmailService, true);

        Mockito.doReturn(1).when(this.iMultiAccountEmailRecordDao).addEmailRecord(Mockito.any());
        int result = this.multiAccountEmailService.sendBatchEmail(batchMsgInfoBo);
        Assert.assertEquals(1, result);
    }

    @Test
    public void deleteEmailRecordInterval() throws IllegalAccessException {
        MemberModifier.field(MultiAccountEmailServiceImpl.class, "saveEmailRecordDay").set(this.multiAccountEmailService, 30);
        Mockito.doReturn(1).when(this.iMultiAccountEmailRecordDao).deleteExpireEmailRecord(Mockito.any());
        int result = this.multiAccountEmailService.deleteEmailRecordInterval();
        Assert.assertEquals(1, result);
    }
}