package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.enums.MultiAccountInvitationEnum;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.metadata.mapper.IAccountInviteDao;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.mapper.IUserRoleGroupRelationDao;
import com.cloudwise.douc.metadata.model.department.DepartmentResponseObject;
import com.cloudwise.douc.metadata.model.multi.invitation.InvitationInfo;
import com.cloudwise.douc.metadata.model.multi.invitation.InviteInfoByUuid;
import com.cloudwise.douc.metadata.model.role.Role;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;
import com.cloudwise.douc.service.cache.IUserCache;
import com.cloudwise.douc.service.model.multi.invitation.InvitationStatusVo;
import lombok.SneakyThrows;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.support.membermodification.MemberModifier;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 外链UT
 *
 * @author maker.wang
 * @date 2021-07-16 17:27
 **/
@RunWith(PowerMockRunner.class)
@PrepareForTest({DataV2ServiceImpl.class})
@PowerMockIgnore({"javax.management.*", "javax.script.*"})
public class MultiAccountInvitationServiceImplTest {

    @Mock
    IAccountInviteDao iAccountInviteDao;

    @Mock
    IMultiAccountUserDao iMultiAccountUserDao;

    @Mock
    IRoleDao iRoleDao;

    @Mock
    IUserRoleGroupRelationDao iUserRoleGroupRelationDao;

    @Mock
    IDepartmentDao iDepartmentDao;

    @Mock
    IUserDao iUserDao;

    @Mock
    private IUserCache iUserCache;

    @InjectMocks
    MultiAccountInvitationServiceImpl multiAccountInvitationService;

    @SneakyThrows
    @Test
    public void getInvitationStatus() {
        InvitationInfo invitationInfo = new InvitationInfo();
        invitationInfo.setInvitationStatus(MultiAccountInvitationEnum.WAIT_REPLY.getCode());
        invitationInfo.setAccountId(9999L);
        invitationInfo.setCreateTime("2021-07-16 20:20:00");
        invitationInfo.setInviteeEmail("xyw1005@126.com");
        invitationInfo.setInviteeName("maker");
        invitationInfo.setInviterEmail("cloudwise_douc@163.com");
        invitationInfo.setInviterEnterpriseName("enterpriseName");
        invitationInfo.setJoinDepartmentName("大部");
        invitationInfo.setJoinParentDepartmentId(998L);
        invitationInfo.setJoinDepartmentLevel("0.1");
        invitationInfo.setJoinDepartmentStartTime("2021.07.16");
        invitationInfo.setJoinDepartmentEndTime("2021.07.26");
        invitationInfo.setOrigin(2);

        DepartmentResponseObject departmentInformation = new DepartmentResponseObject();
        departmentInformation.setName("军部");
        departmentInformation.setParentId(null);

        String externalLinkUuid = "llTFOdCyfRDabCcQyAx";
        MemberModifier.field(MultiAccountInvitationServiceImpl.class, "invitationEffectiveDay").set(this.multiAccountInvitationService, 7);

        Mockito.doReturn(invitationInfo).when(this.iAccountInviteDao).getInvitationInfo(ArgumentMatchers.any());
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(Mockito.anyLong())).thenReturn(departmentInformation).thenReturn(null);


        InvitationStatusVo invitationStatus = this.multiAccountInvitationService.getInvitationStatus(externalLinkUuid);

        Mockito.verify(this.iAccountInviteDao, Mockito.times(1)).getInvitationInfo(ArgumentMatchers.any());
        Mockito.verify(this.iDepartmentDao, Mockito.times(1)).getDepartmentInformation(998L);
        Assert.assertEquals(MultiAccountInvitationEnum.WAIT_REPLY.getCode(), invitationStatus.getInvitationStatus());
        Assert.assertEquals("军部/大部", invitationStatus.getInvitationInfo().getJoinDepartmentName());

    }

    @SneakyThrows
    @Test
    public void getInvitationStatusThreeDepartment() {
        InvitationInfo invitationInfo = new InvitationInfo();
        invitationInfo.setInvitationStatus(MultiAccountInvitationEnum.WAIT_REPLY.getCode());
        invitationInfo.setAccountId(9999L);
        invitationInfo.setCreateTime("2021-07-16 20:20:00");
        invitationInfo.setInviteeEmail("xyw1005@126.com");
        invitationInfo.setInviteeName("maker");
        invitationInfo.setInviterEmail("cloudwise_douc@163.com");
        invitationInfo.setInviterEnterpriseName("enterpriseName");
        invitationInfo.setJoinDepartmentName("大部");
        invitationInfo.setJoinParentDepartmentId(998L);
        invitationInfo.setJoinDepartmentLevel("0.1.2");
        invitationInfo.setJoinDepartmentStartTime("2021.07.16");
        invitationInfo.setJoinDepartmentEndTime("2021.07.26");
        invitationInfo.setOrigin(2);

        DepartmentResponseObject departmentInformation1 = new DepartmentResponseObject();
        departmentInformation1.setName("军部");
        departmentInformation1.setParentId(90L);
        DepartmentResponseObject departmentInformation2 = new DepartmentResponseObject();
        departmentInformation2.setName("师部");

        String externalLinkUuid = "llTFOdCyfRDabCcQyAx";
        MemberModifier.field(MultiAccountInvitationServiceImpl.class, "invitationEffectiveDay").set(this.multiAccountInvitationService, 7);

        Mockito.doReturn(invitationInfo).when(this.iAccountInviteDao).getInvitationInfo(ArgumentMatchers.any());
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(998L)).thenReturn(departmentInformation1);
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(90L)).thenReturn(departmentInformation2);

        InvitationStatusVo invitationStatus = this.multiAccountInvitationService.getInvitationStatus(externalLinkUuid);

        Mockito.verify(this.iAccountInviteDao, Mockito.times(1)).getInvitationInfo(ArgumentMatchers.any());
        Mockito.verify(this.iDepartmentDao, Mockito.times(2)).getDepartmentInformation(Mockito.anyLong());
        Assert.assertEquals(MultiAccountInvitationEnum.WAIT_REPLY.getCode(), invitationStatus.getInvitationStatus());
        Assert.assertEquals("军部/师部/大部", invitationStatus.getInvitationInfo().getJoinDepartmentName());

    }

    @SneakyThrows
    @Test
    public void getInvitationStatusInvitationExpire() {
        InvitationInfo invitationInfo = new InvitationInfo();
        invitationInfo.setInvitationStatus(MultiAccountInvitationEnum.WAIT_REPLY.getCode());
        invitationInfo.setAccountId(9999L);
        invitationInfo.setCreateTime("2021-07-08 20:20:00");
        invitationInfo.setInviteeEmail("xyw1005@126.com");
        invitationInfo.setInviteeName("maker");
        invitationInfo.setInviterEmail("cloudwise_douc@163.com");
        invitationInfo.setInviterEnterpriseName("enterpriseName");
        invitationInfo.setJoinDepartmentName("大部");
        invitationInfo.setJoinParentDepartmentId(998L);
        invitationInfo.setJoinDepartmentLevel("0.1.2");
        invitationInfo.setJoinDepartmentStartTime("2021.07.16");
        invitationInfo.setJoinDepartmentEndTime("2021.07.26");
        invitationInfo.setOrigin(2);

        DepartmentResponseObject departmentInformation1 = new DepartmentResponseObject();
        departmentInformation1.setName("军部");
        departmentInformation1.setParentId(90L);
        DepartmentResponseObject departmentInformation2 = new DepartmentResponseObject();
        departmentInformation2.setName("师部");

        String externalLinkUuid = "llTFOdCyfRDabCcQyAx";
        MemberModifier.field(MultiAccountInvitationServiceImpl.class, "invitationEffectiveDay").set(this.multiAccountInvitationService, 7);

        Mockito.doReturn(invitationInfo).when(this.iAccountInviteDao).getInvitationInfo(ArgumentMatchers.any());
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(998L)).thenReturn(departmentInformation1);
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(90L)).thenReturn(departmentInformation2);

        InvitationStatusVo invitationStatus = this.multiAccountInvitationService.getInvitationStatus(externalLinkUuid);

        Mockito.verify(this.iAccountInviteDao, Mockito.times(1)).getInvitationInfo(ArgumentMatchers.any());
        Mockito.verify(this.iDepartmentDao, Mockito.times(2)).getDepartmentInformation(Mockito.anyLong());
        Assert.assertEquals("军部/师部/大部", invitationStatus.getInvitationInfo().getJoinDepartmentName());
        Assert.assertEquals(MultiAccountInvitationEnum.EXPIRE.getCode(), invitationStatus.getInvitationStatus());

    }

    @SneakyThrows
    @Test
    public void getInvitationStatusTimeRangeExpire() {
        InvitationInfo invitationInfo = new InvitationInfo();
        invitationInfo.setInvitationStatus(MultiAccountInvitationEnum.WAIT_REPLY.getCode());
        invitationInfo.setAccountId(9999L);
        invitationInfo.setCreateTime("2021-07-16 20:20:00");
        invitationInfo.setInviteeEmail("xyw1005@126.com");
        invitationInfo.setInviteeName("maker");
        invitationInfo.setInviterEmail("cloudwise_douc@163.com");
        invitationInfo.setInviterEnterpriseName("enterpriseName");
        invitationInfo.setJoinDepartmentName("大部");
        invitationInfo.setJoinParentDepartmentId(998L);
        invitationInfo.setJoinDepartmentLevel("0.1.2");
        invitationInfo.setJoinDepartmentStartTime("2021.07.16");
        invitationInfo.setJoinDepartmentEndTime("2021.07.16");
        invitationInfo.setOrigin(2);

        DepartmentResponseObject departmentInformation1 = new DepartmentResponseObject();
        departmentInformation1.setName("军部");
        departmentInformation1.setParentId(90L);
        DepartmentResponseObject departmentInformation2 = new DepartmentResponseObject();
        departmentInformation2.setName("师部");

        String externalLinkUuid = "llTFOdCyfRDabCcQyAx";
        MemberModifier.field(MultiAccountInvitationServiceImpl.class, "invitationEffectiveDay").set(this.multiAccountInvitationService, 7);

        Mockito.doReturn(invitationInfo).when(this.iAccountInviteDao).getInvitationInfo(ArgumentMatchers.any());
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(998L)).thenReturn(departmentInformation1);
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(90L)).thenReturn(departmentInformation2);

        InvitationStatusVo invitationStatus = this.multiAccountInvitationService.getInvitationStatus(externalLinkUuid);

        Mockito.verify(this.iAccountInviteDao, Mockito.times(1)).getInvitationInfo(ArgumentMatchers.any());
        Mockito.verify(this.iDepartmentDao, Mockito.times(2)).getDepartmentInformation(Mockito.anyLong());
        Assert.assertEquals(MultiAccountInvitationEnum.EXPIRE.getCode(), invitationStatus.getInvitationStatus());

    }

    @SneakyThrows
    @Test
    public void getInvitationStatusNecessaryParams() {

        String externalLinkUuid = "";
        InvitationStatusVo invitationStatus = null;
        try {
            invitationStatus = this.multiAccountInvitationService.getInvitationStatus(externalLinkUuid);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_EXTERNAL_LINK_UUID_NULL, e.getCode());
        }
    }

    @Test
    public void updateInvitationAndCreateUserRelationNecessaryParams() {
        String externalLinkUuid = "";
        try {
            this.multiAccountInvitationService.updateInvitationAndCreateUserRelation(externalLinkUuid, true);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_EXTERNAL_LINK_UUID_NULL, e.getCode());
        }
    }

    @Test
    public void updateInvitationAndCreateUserRelation() {
        InviteInfoByUuid inviteInfoByUuid = new InviteInfoByUuid();
        inviteInfoByUuid.setAccountId(9999L);
        inviteInfoByUuid.setInviteId(1L);
        inviteInfoByUuid.setInviteeUserId(10L);
        inviteInfoByUuid.setTargetDepartmentId(33L);
        inviteInfoByUuid.setStartTime(new Date());
        inviteInfoByUuid.setEndTime(new Date());

        List<Role> allRole = new ArrayList<>();
        Role role = new Role();
        role.setId(1L);
        role.setType(3);
        allRole.add(role);

        DepartmentResponseObject departmentInformation = new DepartmentResponseObject();
        UserBaseInfoCacheDTO userBaseInfoCacheDTO = new UserBaseInfoCacheDTO();
        String externalLinkUuid = "llTFOdCyfRDabCcQyAx";

        Mockito.doReturn(inviteInfoByUuid).when(this.iAccountInviteDao).getInvitePartInfoByUuid(externalLinkUuid);
        Mockito.doReturn(allRole).when(this.iRoleDao).getBasisRoles(9999L);
        Mockito.doReturn(1).when(this.iUserRoleGroupRelationDao).addUserRoleRelation(ArgumentMatchers.any());

        Mockito.doReturn(null).when(this.iMultiAccountUserDao).getUserDetailByUserId(9999L, 10L);
        Mockito.doReturn(1).when(this.iMultiAccountUserDao).addUser(ArgumentMatchers.any());
        Mockito.doReturn(1).when(this.iAccountInviteDao).updateInvitationStatus(1L, 2, new Date());
        Mockito.when(this.iDepartmentDao.getDepartmentInformation(33L)).thenReturn(departmentInformation).thenReturn(departmentInformation);
        Mockito.doReturn(userBaseInfoCacheDTO).when(this.iUserDao).getUserInfoDetailByUserId(10L);
        Mockito.doNothing().when(this.iUserCache).addOrUpdateSingleUserBasedToCache(ArgumentMatchers.any());

        int result = this.multiAccountInvitationService.updateInvitationAndCreateUserRelation(externalLinkUuid, true);

        Mockito.verify(this.iAccountInviteDao, Mockito.atLeastOnce()).getInvitePartInfoByUuid(externalLinkUuid);
        Mockito.verify(this.iRoleDao, Mockito.atLeastOnce()).getBasisRoles(9999L);
        Mockito.verify(this.iUserRoleGroupRelationDao, Mockito.atLeastOnce()).addUserRoleRelation(ArgumentMatchers.any());

        Mockito.verify(this.iMultiAccountUserDao).getUserDetailByUserId(9999L, 10L);
        Mockito.verify(this.iMultiAccountUserDao).addUser(ArgumentMatchers.any());
        Mockito.verify(this.iAccountInviteDao, Mockito.atLeastOnce()).updateInvitationStatus(1L, 2, new Date());

        Assert.assertEquals(1, result);

    }

    @Test
    public void generateExternalLink() throws IllegalAccessException {
        String externalLinkUuid = "llTFOdCyfRDabCcQyAx";
        MemberModifier.field(MultiAccountInvitationServiceImpl.class, "domainName").set(this.multiAccountInvitationService, "www.maker.com");
        MemberModifier.field(MultiAccountInvitationServiceImpl.class, "externalLinkWebPath").set(this.multiAccountInvitationService, "invite-email");
        String s = this.multiAccountInvitationService.generateExternalLink(externalLinkUuid);
        Assert.assertEquals("http://www.maker.com/invite-email?id=llTFOdCyfRDabCcQyAx", s);
    }

    @Test
    public void generateExternalLinkNecessaryParams() {
        String externalLinkUuid = "";
        try {
            this.multiAccountInvitationService.generateExternalLink(externalLinkUuid);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_EXTERNAL_LINK_UUID_NULL, e.getCode());
        }
    }

}