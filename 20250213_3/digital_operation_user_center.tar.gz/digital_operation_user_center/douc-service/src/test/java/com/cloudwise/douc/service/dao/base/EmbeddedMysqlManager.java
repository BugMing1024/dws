package com.cloudwise.douc.service.dao.base;

import com.wix.mysql.EmbeddedMysql;
import com.wix.mysql.ScriptResolver;
import com.wix.mysql.config.Charset;
import com.wix.mysql.config.MysqldConfig;
import com.wix.mysql.config.SchemaConfig;
import com.wix.mysql.distribution.Version;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 初始化内存MySQL
 *
 * @Author maker.wang
 * @Date 2021-05-13 17:54
 **/
public class EmbeddedMysqlManager {

    private static EmbeddedMysqlManager instance;

    private EmbeddedMysqlManager() {
        this.startDatabase();
    }

    private final Logger logger = LoggerFactory.getLogger(EmbeddedMysqlManager.class);

    private EmbeddedMysql embeddedMysql;
    private SchemaConfig schemaConfig;

    // use "root"is not allowed.
    private static final String DB_USER = "Rootmaster";
    
    private static final String DB = "Rootmaster@777";

    private static final int DB_PORT = 13308;
    private static final String DB_SCHEMA_NAME = "douc_102";

    public void reloadSchema() {
        embeddedMysql.reloadSchema(schemaConfig);
    }

    private void startDatabase() {
        MysqldConfig dbConfig = MysqldConfig.aMysqldConfig(Version.v5_7_17).withCharset(Charset.UTF8).withPort(DB_PORT).withUser(DB_USER, DB)
                .build();

        schemaConfig = SchemaConfig.aSchemaConfig(DB_SCHEMA_NAME)
                .withScripts(ScriptResolver.classPathScript("db/douc_database_init.sql")).withCharset(Charset.UTF8).build();
        logger.info("embedded mysql starting ...");
        embeddedMysql = EmbeddedMysql.anEmbeddedMysql(dbConfig).addSchema(schemaConfig).start();
        logger.info("embedded mysql started.");
    }

    public static EmbeddedMysqlManager getInstance() {
        if (instance == null) {
            instance = new EmbeddedMysqlManager();
        }
        return instance;
    }

    String getDbUrl() {
        return "jdbc:mysql://localhost:" + DB_PORT + "/" + DB_SCHEMA_NAME;
    }

    String getDbUser() {
        return DB_USER;
    }
    
    String getDb() {
        return DB;
    }
}
