package com.cloudwise.douc.service.util;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.util.Date;

/**
 * @author elsa.yang
 * @date 2020/6/11 10:57 上午
 */
@Slf4j
public class DateUtilTest {

    @Test
    public void main1() {
        Date date = DateUtil.parseStringToDateByTimeZone("2021-02-22 18:25:00", null, "GMT-8");
        log.info("{}", date);
        Date date2 = DateUtil.makeResultDate(new Date(), -1);
        log.info("{}", date2);
    }

}
