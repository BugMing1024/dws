package com.cloudwise.douc.service.dao.impl;

import com.cloudwise.douc.commons.model.DataPage;
import com.cloudwise.douc.commons.utils.ShortUUID;
import com.cloudwise.douc.metadata.mapper.IAccountInviteDao;
import com.cloudwise.douc.metadata.model.multi.invitation.InvitationInfo;
import com.cloudwise.douc.metadata.model.multi.invitation.InviteInfoByUuid;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountInviteDO;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.metadata.model.multi.tenant.UserInfoDO;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import com.cloudwise.douc.service.model.multi.tenant.AccountInviteQueryDTO;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author bradyliu
 * @description:
 * @date Created in 21:03 2021/7/17.
 */
public class AccountInviteDaoImplTest extends UnitTestBaseDao {
    @Resource
    static IAccountInviteDao accountInviteDaoImpl;

    /**
     * @description 测试getAccountInviteList方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getAccountInviteList() {
        AccountInviteQueryDTO accountInviteQueryDTO = new AccountInviteQueryDTO();
        accountInviteQueryDTO.setDateSort("asc");
        accountInviteQueryDTO.setInviteeEmail("xyw1005@126.com");
        accountInviteQueryDTO.setCurrent(1);
        accountInviteQueryDTO.setSize(1);
        accountInviteQueryDTO.setStatus(1);
        DataPage<AccountInviteDO> accountInviteList = null;
        // 提交事务
        sqlSession.commit();
        boolean flag = Objects.nonNull(accountInviteList);
        Assert.assertEquals(true, flag);
    }

    /**
     * @description 测试getAccountInvite方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getAccountInvite() {
        Long accountId = 101L;
        Long userId = 170L;
        Long inviteId = 56L;

        AccountInviteDO accountInvite = this.accountInviteDaoImpl.getAccountInvite(accountId, userId, inviteId);
        sqlSession.commit();
        boolean flag = Objects.nonNull(accountInvite);
        Assert.assertEquals(true, flag);
    }

    /**
     * @description 测试getInvitationInfo方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getInvitationInfo() {
        String externalLinkUuid = "m1IG6Vtp7jXC1OJQoVyl";
        InvitationInfo invitationInfo = this.accountInviteDaoImpl.getInvitationInfo(externalLinkUuid);
        sqlSession.commit();
        boolean flag = Objects.nonNull(invitationInfo);
        Assert.assertEquals(true, flag);
    }

    /**
     * @description 测试getInvitePartInfoByUuid方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getInvitePartInfoByUuid() {
        String externalLinkUuid = "m1IG6Vtp7jXC1OJQoVyl";
        InviteInfoByUuid inviteInfoByUuid = this.accountInviteDaoImpl.getInvitePartInfoByUuid(externalLinkUuid);
        sqlSession.commit();
        boolean flag = Objects.nonNull(inviteInfoByUuid);
        Assert.assertEquals(true, flag);
    }

    /**
     * @description 测试updateInvitationStatus方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void updateInvitationStatus() {

        Long accountId = 101L;
        Long userId = 170L;
        Long inviteId = 56L;
        int i = this.accountInviteDaoImpl.updateInvitationStatus(56L, 4, new Date());
        sqlSession.commit();
        Assert.assertEquals(1, i);
    }

    /**
     * @description 测试updateAccountInviteStatus方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void updateAccountInviteStatus() {
        int i = this.accountInviteDaoImpl.updateAccountInviteStatus(101L, 170L, 56L, 4, new Date());
        sqlSession.commit();
        Assert.assertEquals(1, i);
    }

    /**
     * @description 测试getUserInfoByEmail方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getUserInfoByEmail() {
        UserInfoDO userInfoByEmail = this.accountInviteDaoImpl.getUserInfoByEmail("bjs@yunzhihui.com");
        sqlSession.commit();
        boolean b = Objects.nonNull(userInfoByEmail);
        Assert.assertEquals(true, b);
    }

    /**
     * @description 测试backupAccountInvite方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void backupAccountInvite() {
        Long accountId = 101L;
        Long userId = 170L;
        Long inviteId = 56L;
        int i = this.accountInviteDaoImpl.backupAccountInvite(accountId, userId, inviteId, new Date());
        sqlSession.commit();
        Assert.assertEquals(1, i);
    }

    /**
     * @description 测试deleteAccountInvite方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void deleteAccountInvite() {
        Long accountId = 101L;
        Long userId = 170L;
        Long inviteId = 56L;
        int i = this.accountInviteDaoImpl.deleteAccountInvite(accountId, userId, inviteId);
        sqlSession.commit();
        Assert.assertEquals(1, i);
    }

    /**
     * @description 测试getUserCountDO方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getUserCountDO() {
        Long accountId = 1L;
        Long userId = 2L;
        UserCountDO userCountDO = this.accountInviteDaoImpl.getUserCountDO(userId, accountId);
        sqlSession.commit();
        boolean b = Objects.nonNull(userCountDO);
        Assert.assertEquals(true, b);
    }

    /**
     * @description 测试getAccountInviteByEmail方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void getAccountInviteByEmail() {
        List<AccountInviteDO> accountInviteByEmail = this.accountInviteDaoImpl.getAccountInviteByEmail("bjs@yunzhihui.com", 1L);
        sqlSession.commit();
        boolean b = Objects.nonNull(accountInviteByEmail);
        Assert.assertEquals(true, b);
    }

    /**
     * @description 测试saveAccountInvite方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 21:15
     */
    @Test
    @Rollback(false)
    public void saveAccountInvite() {

        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setName("name");
        accountInviteDO.setAccountId(1L);

        accountInviteDO.setStartTime(new Date());
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("ken888@cloudwise.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        accountInviteDO.setOrigin(2);
        accountInviteDO.setTopAccountId(1L);

        accountInviteDO.setModifyUserId(1L);
        accountInviteDO.setCreateUserId(1L);
        accountInviteDO.setModifyTime(new Date());
        accountInviteDO.setCreateTime(new Date());
        int integer = this.accountInviteDaoImpl.saveAccountInvite(accountInviteDO);
        sqlSession.commit();
        Assert.assertEquals(1, integer);
    }


}
