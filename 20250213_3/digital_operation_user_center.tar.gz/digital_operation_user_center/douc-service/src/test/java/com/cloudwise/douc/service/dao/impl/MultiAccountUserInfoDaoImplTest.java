package com.cloudwise.douc.service.dao.impl;

import com.cloudwise.douc.commons.utils.sm2.Sm2Utils;
import com.cloudwise.douc.commons.utils.sm2.Sm3Digest;
import com.cloudwise.douc.commons.utils.sm2.SmsecurityService;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserInfoDao;
import com.cloudwise.douc.metadata.mapper.IUserRoleGroupRelationDao;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserInfoDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserInfoDO;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * 添加用户信息
 *
 * @author maker.wang
 * @date 2021-07-03 15:48
 **/
public class MultiAccountUserInfoDaoImplTest extends UnitTestBaseDao {

    @Resource
    static IMultiAccountUserInfoDao accountUserInfoDao;
    @Resource
    static IUserRoleGroupRelationDao userRoleGroupRelationDao;
    static IAccountDao accountDao;

    @Test
    @Rollback(false)
    public void addUserInfo() {
        String secret = "==defaultPWD==";
        String sm3 = Sm3Digest.SMCEncryption(secret);
        //sm3(sm3(明文密码))
        String sm3Sm3 = Sm3Digest.SMCEncryption(sm3);
        //sm2(sm3(sm3(明文密码)))
        String sm2Sm3Sm3 = Sm2Utils.SMBEncryption(sm3Sm3, SmsecurityService.pubkey);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setDefaultAccountId(1L);
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setCreateUserId(1L);
        userInfoDetail.setSmPasswordCpd(sm3Sm3);
        userInfoDetail.setSmPasswordBpd(sm2Sm3Sm3);
        userInfoDetail.setEmail("Cloudwise@yunzhihui.com");
        userInfoDetail.setName("系统管理员");
        userInfoDetail.setCreateTime(new Date());
        userInfoDetail.setModifyTime(new Date());
        int update = this.accountUserInfoDao.addUserInfo(userInfoDetail);
        //提交事务
        sqlSession.commit();
        Assert.assertEquals(1, update);
    }

    @Test
    public void addUserInfoByList() {
        String secret = "==defaultPWD==";
        String sm3 = Sm3Digest.SMCEncryption(secret);
        //sm3(sm3(明文密码))
        String sm3Sm3 = Sm3Digest.SMCEncryption(sm3);
        //sm2(sm3(sm3(明文密码)))
        String sm2Sm3Sm3 = Sm2Utils.SMBEncryption(sm3Sm3, SmsecurityService.pubkey);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setDefaultAccountId(1L);
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setCreateUserId(1L);
        userInfoDetail.setSmPasswordCpd(sm3Sm3);
        userInfoDetail.setSmPasswordBpd(sm2Sm3Sm3);
        userInfoDetail.setEmail("Cloudwise@yunzhihui.com");
        userInfoDetail.setName("系统管理员");
        userInfoDetail.setCreateTime(new Date());
        userInfoDetail.setModifyTime(new Date());
        List<MultiAccountUserInfoDetail> userInfoDetailList = new ArrayList<>();
        userInfoDetailList.add(userInfoDetail);
        int result = this.accountUserInfoDao.addUserInfoByList(userInfoDetailList);
        Assert.assertEquals(1, result);
    }

    @Test
    public void getTenantUserInfo() {
        String secret = "==defaultPWD==";
        String sm3 = Sm3Digest.SMCEncryption(secret);
        //sm3(sm3(明文密码))
        String sm3Sm3 = Sm3Digest.SMCEncryption(sm3);
        //sm2(sm3(sm3(明文密码)))
        String sm2Sm3Sm3 = Sm2Utils.SMBEncryption(sm3Sm3, SmsecurityService.pubkey);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setDefaultAccountId(1L);
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setCreateUserId(1L);
        userInfoDetail.setSmPasswordCpd(sm3Sm3);
        userInfoDetail.setSmPasswordBpd(sm2Sm3Sm3);
        userInfoDetail.setEmail("Cloudwise@yunzhihui.com");
        userInfoDetail.setName("系统管理员");
        userInfoDetail.setCreateTime(new Date());
        userInfoDetail.setModifyTime(new Date());
        int update = this.accountUserInfoDao.addUserInfo(userInfoDetail);
        //提交事务
        sqlSession.commit();
        Assert.assertEquals(1, update);

        UserInfoDO userInfoDO = this.accountUserInfoDao.getTenantUserInfo(userInfoDetail.getId());
        Assert.assertEquals("系统管理员", userInfoDO.getName());

    }

    @Test
    public void updateUserInfo() {
        String secret = "==defaultPWD==";
        String sm3 = Sm3Digest.SMCEncryption(secret);
        //sm3(sm3(明文密码))
        String sm3Sm3 = Sm3Digest.SMCEncryption(sm3);
        //sm2(sm3(sm3(明文密码)))
        String sm2Sm3Sm3 = Sm2Utils.SMBEncryption(sm3Sm3, SmsecurityService.pubkey);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setDefaultAccountId(1L);
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setCreateUserId(1L);
        userInfoDetail.setSmPasswordCpd(sm3Sm3);
        userInfoDetail.setSmPasswordBpd(sm2Sm3Sm3);
        userInfoDetail.setEmail("Cloudwise@yunzhihui.com");
        userInfoDetail.setName("系统管理员");
        userInfoDetail.setCreateTime(new Date());
        userInfoDetail.setModifyTime(new Date());
        int update = this.accountUserInfoDao.addUserInfo(userInfoDetail);
        //提交事务
        sqlSession.commit();
        Assert.assertEquals(1, update);
        userInfoDetail.setName("系统管理员2");
        update = this.accountUserInfoDao.addUserInfo(userInfoDetail);
        Assert.assertEquals(1, update);

    }

    @Test
    public void countEmailNum() {
        String secret = "==defaultPWD==";
        String sm3 = Sm3Digest.SMCEncryption(secret);
        //sm3(sm3(明文密码))
        String sm3Sm3 = Sm3Digest.SMCEncryption(sm3);
        //sm2(sm3(sm3(明文密码)))
        String sm2Sm3Sm3 = Sm2Utils.SMBEncryption(sm3Sm3, SmsecurityService.pubkey);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setDefaultAccountId(1L);
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setCreateUserId(1L);
        userInfoDetail.setSmPasswordCpd(sm3Sm3);
        userInfoDetail.setSmPasswordBpd(sm2Sm3Sm3);
        userInfoDetail.setEmail("Cloudwise222@yunzhihui.com");
        userInfoDetail.setName("系统管理员");
        userInfoDetail.setCreateTime(new Date());
        userInfoDetail.setModifyTime(new Date());
        int update = this.accountUserInfoDao.addUserInfo(userInfoDetail);
        //提交事务
        sqlSession.commit();
        Assert.assertEquals(1, update);
        int result = this.accountUserInfoDao.countEmailNum("Cloudwise222@yunzhihui.com");
        Assert.assertEquals(1, result);

    }


    @Test
    public void checkUserAliasUnique() {
        String secret = "==defaultPWD==";
        String sm3 = Sm3Digest.SMCEncryption(secret);
        //sm3(sm3(明文密码))
        String sm3Sm3 = Sm3Digest.SMCEncryption(sm3);
        //sm2(sm3(sm3(明文密码)))
        String sm2Sm3Sm3 = Sm2Utils.SMBEncryption(sm3Sm3, SmsecurityService.pubkey);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setDefaultAccountId(1L);
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setCreateUserId(1L);
        userInfoDetail.setSmPasswordCpd(sm3Sm3);
        userInfoDetail.setSmPasswordBpd(sm2Sm3Sm3);
        userInfoDetail.setEmail("Cloudwise2@yunzhihui.com");
        userInfoDetail.setName("系统管理员");
        userInfoDetail.setUserAlias("Maker.wang");
        userInfoDetail.setCreateTime(new Date());
        userInfoDetail.setModifyTime(new Date());
        this.accountUserInfoDao.addUserInfo(userInfoDetail);
        sqlSession.commit();
        int result = this.accountUserInfoDao.checkUserAliasUnique("Maker.wang", 1L);
        Assert.assertEquals(1, result);
    }


    @Test
    public void getUserIdsByNameOrEmail() {

        Long id = 13L;
        String userAlias = "cd_122bsj";
        String email = "bssjwsswwss22@yunzhihui.com";

        List<Long> userIds = this.accountUserInfoDao.getUserIdsByNameOrEmail(id, userAlias, email);
        //提交事务
        sqlSession.commit();
        boolean flag = Objects.nonNull(userIds);
        Assert.assertEquals(true, flag);
    }
}