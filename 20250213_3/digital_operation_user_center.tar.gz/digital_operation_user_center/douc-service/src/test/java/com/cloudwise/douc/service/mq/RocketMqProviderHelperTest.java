package com.cloudwise.douc.service.mq;

import org.junit.Test;

/**
 * @author maker.wang
 * @description:
 * @date Created in 11:30 上午 2021/8/17.
 */
public class RocketMqProviderHelperTest {

    @Test
    public void init() {
    }

    @Test
    public void asyncSend() {
    }

    @Test
    public void testAsyncSend() {
    }

    @Test
    public void testAsyncSend1() {
    }

    @Test
    public void testAsyncSend2() {
    }

    @Test
    public void testAsyncSend3() {
    }

    @Test
    public void testAsyncSend4() {
    }

    @Test
    public void syncSendOrderly() {
    }

    @Test
    public void testSyncSendOrderly() {
    }

    @Test
    public void testSyncSendOrderly1() {
    }
}