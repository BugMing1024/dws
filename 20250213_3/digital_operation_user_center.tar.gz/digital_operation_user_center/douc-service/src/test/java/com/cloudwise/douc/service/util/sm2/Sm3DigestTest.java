package com.cloudwise.douc.service.util.sm2;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

/**
 * Copyright
 *
 * @author junyuan
 * @version 1.0
 * @ClassName: Sm3Digest
 * @date 2019年5月6日 下午22:30:09
 */
@Slf4j
public class Sm3DigestTest {

    @Test
    public void main1() {
    }
}