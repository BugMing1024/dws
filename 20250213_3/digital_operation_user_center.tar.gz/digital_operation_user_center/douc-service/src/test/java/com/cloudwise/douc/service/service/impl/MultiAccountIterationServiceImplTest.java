package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IDepartmentUserRelationDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.mapper.IUserRoleGroupRelationDao;
import com.cloudwise.douc.metadata.model.department.Department;
import com.cloudwise.douc.metadata.model.multi.iteration.SearchUserDetail;
import com.cloudwise.douc.metadata.model.multi.iteration.SubAccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.SubAccountAdminUserInfo;
import com.cloudwise.douc.service.dataflow.IAccountDataFlow;
import com.cloudwise.douc.service.service.IAccountService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MultiAccountIterationServiceImpl.class})
@PowerMockIgnore({"javax.management.*", "javax.script.*"})
public class MultiAccountIterationServiceImplTest {

    @Mock
    private IMultiAccountUserDao iMultiAccountUserDao;

    @Mock
    private IAccountService accountService;

    @InjectMocks
    private MultiAccountIterationServiceImpl multiAccountIterationService;
    @Mock
    private IUserRoleGroupRelationDao iUserRoleGroupRelationDao;
    @Mock
    private IDepartmentUserRelationDao iDepartmentUserRelationDao;
    @Mock
    private IAccountDataFlow accountDataFlow;
    @Mock
    private IDepartmentDao iDepartmentDao;
    @Mock
    private IRoleDao iRoleDao;

    @Test
    public void getSubAccountAllUser() {
        List<SubAccountDetail> list = new ArrayList<>(2);
        for (int i = 0; i < 2; i++) {
            SubAccountDetail subAccountDetail = new SubAccountDetail();
            subAccountDetail.setId(Long.valueOf("311" + i));
            subAccountDetail.setName("maker" + i);
            subAccountDetail.setAdminType(2);
            list.add(subAccountDetail);
        }
        Mockito.doReturn(list).when(this.iMultiAccountUserDao).getSubAccountAllUser(111L);
        List<SubAccountDetail> subAccountAllUser = this.multiAccountIterationService.getSubAccountAllUser(111L);
        Assert.assertEquals(2, subAccountAllUser.size());
    }

    @Test
    public void updateSubAccountAllUser() {
        Long subAccountId = 110L;
        Long topAccountId = 111L;
        Long createUserId = 3156L;
        Long userId = 3156L;

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setTopId(topAccountId);

        SubAccountAdminUserInfo subAccountAdminUserInfo = new SubAccountAdminUserInfo();
        subAccountAdminUserInfo.setInnerAdminUserId(userId);

        Department topDepartment = new Department();
        topDepartment.setId(1L);
        List<Long> userIdList = new ArrayList<>();
        userIdList.add(3113L);
        userIdList.add(3117L);

        Mockito.doReturn(accountDetail).when(this.accountService).getAccountDetailById(subAccountId);
        Mockito.doReturn(subAccountAdminUserInfo).when(this.iUserRoleGroupRelationDao).getSubAccountAdminUserInfo(subAccountId);
        Mockito.doReturn(1).when(this.iMultiAccountUserDao).deleteSubAccountAllUser(subAccountId, Mockito.any());
        Mockito.doReturn(1).when(this.iDepartmentUserRelationDao).deleteDepartmentUserRelation(subAccountId, Mockito.any(), Mockito.any(), null);
        Mockito.doReturn(1).when(this.iUserRoleGroupRelationDao).deleteUserRoleRelation(subAccountId, Mockito.any());
        Mockito.doReturn(topDepartment).when(this.iDepartmentDao).getTopDepartmentByAccountId(subAccountId);
        Mockito.doReturn(1L).when(this.iRoleDao).getSystemCommonRoleId(subAccountId);

        Mockito.doReturn(2).when(this.iMultiAccountUserDao).deleteSubAccountAllUser(subAccountId, Mockito.any());
        Mockito.doReturn(2).when(this.iMultiAccountUserDao).addUserByList(Mockito.anyList());
        Mockito.doNothing().when(this.accountDataFlow).setUserCountCacheByTopAccountId(topAccountId);
        Map<String, String> resultMap = new HashMap<>();
        int result = this.multiAccountIterationService.updateSubAccountAllUser(subAccountId, userIdList, createUserId, resultMap);
        Assert.assertEquals(2, result);

    }

    /**
     * 必传参数 UT
     *
     * @author maker.wang
     * @date 2021-09-04 18:17
     **/
    @Test
    public void updateSubAccountAllUserParams() {
        Long subAccountId = 110L;
        Long topAccountId = 111L;
        Long createUserId = 3156L;

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setTopId(topAccountId);

        //参数空
        List<Long> userIdList = new ArrayList<>();

        Mockito.doReturn(accountDetail).when(this.accountService).getAccountDetailById(subAccountId);
        Mockito.doReturn(2).when(this.iMultiAccountUserDao).deleteSubAccountAllUser(subAccountId, Mockito.any());
        Mockito.doReturn(2).when(this.iMultiAccountUserDao).addUserByList(Mockito.anyList());
        try {
            Map<String, String> resultMap = new HashMap<>();
            int result = this.multiAccountIterationService.updateSubAccountAllUser(subAccountId, userIdList, createUserId, resultMap);
            Assert.assertEquals(2, result);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_USER_ID_LIST_NULL, e.getCode());
        }

    }

    @Test
    public void searchUserFromTopAccount() {
        Long subAccountId = 110L;
        Long topAccountId = 111L;
        String name = "maker";

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setTopId(topAccountId);

        List<SearchUserDetail> searchUserDetails = new ArrayList<>(2);
        for (int i = 0; i < 2; i++) {
            SearchUserDetail subAccountDetail = new SearchUserDetail();
            subAccountDetail.setUserId(Long.valueOf("311" + i));
            subAccountDetail.setName("maker" + i);
            subAccountDetail.setUserAlias("maker" + i);
            searchUserDetails.add(subAccountDetail);
        }

        Mockito.doReturn(accountDetail).when(this.accountService).getAccountDetailById(subAccountId);
    }

    /**
     * 必传参数 UT
     *
     * @author maker.wang
     * @date 2021-09-04 18:12
     **/
    @Test
    public void searchUserFromTopAccountParams() {
        Long topAccountId = 111L;

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setTopId(topAccountId);

        List<SearchUserDetail> searchUserDetails = new ArrayList<>(2);
        for (int i = 0; i < 2; i++) {
            SearchUserDetail subAccountDetail = new SearchUserDetail();
            subAccountDetail.setUserId(Long.valueOf("311" + i));
            subAccountDetail.setName("maker" + i);
            subAccountDetail.setUserAlias("maker" + i);
            searchUserDetails.add(subAccountDetail);
        }

    }
}