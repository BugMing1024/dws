package com.cloudwise.douc.service.util.rsa;


import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

@Slf4j
public class RSAUtil2Test {

    /**
     * 打印公钥信息
     *
     * @param publicKey
     */
    public static void printPublicKeyInfo(PublicKey publicKey) {
        RSAPublicKey rsaPublicKey = (RSAPublicKey) publicKey;
        log.info("{}", "----------RSAPublicKey----------");
        log.info("{}", "Modulus.length=" + rsaPublicKey.getModulus().bitLength());
        log.info("{}", "Modulus=" + rsaPublicKey.getModulus().toString());
        log.info("{}", "PublicExponent.length=" + rsaPublicKey.getPublicExponent().bitLength());
        log.info("{}", "PublicExponent=" + rsaPublicKey.getPublicExponent().toString());
    }

    public static void printPrivateKeyInfo(PrivateKey privateKey) {
        RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) privateKey;
        log.info("{}", "----------RSAPrivateKey ----------");
        log.info("{}", "Modulus.length=" + rsaPrivateKey.getModulus().bitLength());
        log.info("{}", "Modulus=" + rsaPrivateKey.getModulus().toString());
        log.info("{}", "PrivateExponent.length=" + rsaPrivateKey.getPrivateExponent().bitLength());
        log.info("{}", "PrivatecExponent=" + rsaPrivateKey.getPrivateExponent().toString());

    }

    @Test
    public void main1() throws Exception {
        //log.info("{}", "解密：" + RSAUtil2.decrypt("EUcdvzNVzgtqC9b/7Ha+u88kijmWfWmaFHgskTjMIbONOkBOb2UEVtyPqF4kpry9pUQhPzCEBhXY/mzWdFM1bFYQgOX3CPxyzL0YPOXM8dkyTADxDax0TT8iqOrZ9Bzv99pqinF/AuA4T8GBULYRr98wBGeF6yGJf7VRi+4DEwN0CcpWooQkSsQBLVH6kQlWjbzD/nM5czCHOSWXl7GH4d+V07jtvYyIwvQoLZ6L3P9ot2xbDkC/dIKrDxPS10qo6yIP/nttyY0aOZ3cFdWqyGxYzpI2JNxf8NO/w10BEeSa/K1pn/LtoyocQZkcWeUEdqBGC/jxqxrBPNNjT24WYA==", RSAUtil2.DEFAULT_PRIVATE_KEY_STRING));
    }


}