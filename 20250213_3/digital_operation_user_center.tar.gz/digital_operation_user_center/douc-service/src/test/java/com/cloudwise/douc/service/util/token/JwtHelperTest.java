package com.cloudwise.douc.service.util.token;

import com.cloudwise.douc.commons.utils.token.JwtHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * 生成jwt的工具类，基于auth0.java-jwt封装
 * 证书放在了resources/sm下,其中有公钥、私钥
 * 签名算法使用SM3WithSM2
 * payload统一使用Map<String, String>类型
 *
 * @author maker.wang
 * @date Created in 10:40 上午 2021/6/2.
 **/
@Slf4j
public class JwtHelperTest {

    /**
     * token生成、解析测试
     *
     * @param args
     * @return void
     * @description
     * @author maker.wang
     * @date 2021-06-02
     * @time 11:35
     */
    public static void main(String[] args) throws JsonProcessingException {
        //生成token
        HashMap<String, String> map = new HashMap<>(3);
        map.put("test", "test");
        map.put("test4", "test");
        map.put("test5", "test");
        ///String token = JwtHelper.genToken(map);
        ///log.info("{}",token);
        //解析token
        Map<String, String> map1 = JwtHelper.verifyToken("");
        log.info("{}", new ObjectMapper().writeValueAsString(map1));
    }

}