package com.cloudwise.douc.service.dao.impl;

import com.cloudwise.douc.metadata.mapper.IDataResourceDao;
import com.cloudwise.douc.metadata.model.data.ResourceMultiTypeTreeData;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * DataResourceDao UT
 *
 * @author maker.wang
 * @date 2021-06-28 16:36
 **/
public class DataResourceDaoImplTest extends UnitTestBaseDao {

    @Resource
    static IDataResourceDao dataResourceDaoImpl;

    @Test
    @Rollback(false)
    public void updateMultiTypeTreeData() {
        List<ResourceMultiTypeTreeData> multiTypeDataList = new ArrayList<>();
        ResourceMultiTypeTreeData updateData = new ResourceMultiTypeTreeData();
        updateData.setDataType("rpc_auth");
        updateData.setCode("4219002");
        updateData.setName("ut_修改名称4111");
        updateData.setAccountId(110L);
        multiTypeDataList.add(updateData);
        int update = dataResourceDaoImpl.updateMultiTypeTreeData(multiTypeDataList);
        //提交事务
        sqlSession.commit();
        Assert.assertEquals(1, update);

    }
}