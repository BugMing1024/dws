package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.enums.MultiAccountStatusEnum;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.commons.utils.sm2.Sm2Utils;
import com.cloudwise.douc.commons.utils.sm2.Sm3Digest;
import com.cloudwise.douc.commons.utils.sm2.SmsecurityService;
import com.cloudwise.douc.metadata.mapper.AccountMapper;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IDepartmentDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IDicDataDao;
import com.cloudwise.douc.metadata.mapper.ILogoDao;
import com.cloudwise.douc.metadata.mapper.IModuleAccountDao;
import com.cloudwise.douc.metadata.mapper.IModuleDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserInfoDao;
import com.cloudwise.douc.metadata.mapper.ISystemSettingDao;
import com.cloudwise.douc.metadata.mapper.IUserRoleGroupRelationDao;
import com.cloudwise.douc.metadata.model.department.Department;
import com.cloudwise.douc.metadata.model.logo.LogoEntity;
import com.cloudwise.douc.metadata.model.menu.Module;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserInfoDetail;
import com.cloudwise.douc.service.cache.IUserCache;
import com.cloudwise.douc.service.model.multi.tenant.SubTenantInitInfoBo;
import com.cloudwise.douc.service.model.multi.tenant.TenantDefaultRoleInfoVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantDefaultUserInfoVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantInitInfoVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantInitResultVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantSystemAdministratorInfoBo;
import com.cloudwise.douc.service.model.multi.tenant.TenantUserSecretSm2Info;
import com.cloudwise.douc.service.model.multi.tenant.TopTenantInitInfoBo;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.service.IRoleService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.api.support.membermodification.MemberModifier;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * 多租户-租户初始化接口UT
 *
 * @author maker.wang
 * @date 2021-07-02 18:55
 **/
@Slf4j
@RunWith(PowerMockRunner.class)
@PrepareForTest({MultiAccountServiceImpl.class, RedisTools.class})
@PowerMockIgnore({"javax.management.*", "javax.script.*"})
public class MultiAccountServiceImplTest {

    @Mock
    private AccountMapper accountMapper;
    @Mock
    private IAccountService accountService;
    @Mock
    private IDepartmentDao departmentDao;

    @Mock
    private IMultiAccountUserDao iMultiAccountUserDao;

    @Mock
    private IMultiAccountUserInfoDao iMultiAccountUserInfoDao;

    @Mock
    private IRoleService roleService;

    @Mock
    private IDepartmentDataResourceDao iDepartmentDataResourceDao;

    @Mock
    private IDicDataDao iDicDataDao;

    @Mock
    private IModuleDao iModuleDao;

    @Mock
    private IModuleAccountDao iModuleAccountDao;

    @Mock
    private ISystemSettingDao iSystemSettingDao;

    @Mock
    private ILogoDao iLogoDao;

    @Mock
    private IUserRoleGroupRelationDao iUserRoleGroupRelationDao;

    @Mock
    private IUserCache iUserCache;

    @InjectMocks
    private MultiAccountServiceImpl multiAccountService;

    @Data
    class UserInfo {
        String userName;
    }

    @Test
    public void objectToJsonString() throws Exception {
        UserInfo userInfo = new UserInfo();
        userInfo.setUserName("cloud");
        String json = "{\"userName\":\"cloud\"}";
        String objectToJsonString = Whitebox.invokeMethod(this.multiAccountService, "objectToJsonString", userInfo);
        Assert.assertEquals(json, objectToJsonString);
    }

    @Test
    public void validateTopTenantParams() throws Exception {

        String accountName = "云智慧";
        TopTenantInitInfoBo tenantInfo = new TopTenantInitInfoBo();
        tenantInfo.setName(accountName);


        boolean result = Whitebox.invokeMethod(this.multiAccountService, "validateTopTenantParams", tenantInfo);

        Assert.assertEquals(true, result);
    }

    @Test(expected = BaseException.class)
    public void validateTopTenantParamsException() throws Exception {

        String accountName = "云智慧";
        TopTenantInitInfoBo tenantInfo = new TopTenantInitInfoBo();
        tenantInfo.setName(accountName);
        AccountDetail topAccountDetail = new AccountDetail();
        topAccountDetail.setId(1L);

        Whitebox.invokeMethod(this.multiAccountService, "validateTopTenantParams", tenantInfo);
    }

    @Test(expected = BaseException.class)
    public void validateTopTenantParamsException1() throws Exception {

        TopTenantInitInfoBo tenantInfo = new TopTenantInitInfoBo();
        AccountDetail topAccountDetail = new AccountDetail();
        topAccountDetail.setId(1L);

        Whitebox.invokeMethod(this.multiAccountService, "validateTopTenantParams", tenantInfo);
    }

    @Test(expected = BaseException.class)
    public void validateTopTenantParamsException2() throws Exception {

        String accountName = "云智慧";
        TopTenantInitInfoBo tenantInfo = new TopTenantInitInfoBo();
        tenantInfo.setName(accountName);
        AccountDetail topAccountDetail = new AccountDetail();
        topAccountDetail.setId(1L);

        Whitebox.invokeMethod(this.multiAccountService, "validateTopTenantParams", tenantInfo);
    }

    @Test
    public void validateSubTenantParams() throws Exception {
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setName("云智慧");
        accountDetail.setId(1L);

        String userSecret = "==defaultPWD==-";
        String sm3Secret = Sm3Digest.SMCEncryption(userSecret);
        String sm2Secret = Sm2Utils.SMBEncryption(userSecret + "--" + sm3Secret, SmsecurityService.pubkey);
        TenantSystemAdministratorInfoBo adminInfo = new TenantSystemAdministratorInfoBo();
        adminInfo.setUserName("中海油");
        adminInfo.setEmail("chengweiliao@yunzhihui.com");
        adminInfo.setUserSecret(sm2Secret);

        SubTenantInitInfoBo tenantInfo = new SubTenantInitInfoBo();
        tenantInfo.setName("云智慧北京");
        tenantInfo.setParentId(1L);
        tenantInfo.setCreateUserId(2L);

        Mockito.doReturn(accountDetail).when(this.accountService).getAccountDetailById(Mockito.anyLong());
        Mockito.doReturn(0).when(this.iMultiAccountUserInfoDao).countEmailNum(Mockito.anyString());

        boolean result = Whitebox.invokeMethod(this.multiAccountService, "validateSubTenantParams", tenantInfo);
        Assert.assertEquals(true, result);
    }

    @Test(expected = BaseException.class)
    public void validateSubTenantParamsNameVerify() throws Exception {
        SubTenantInitInfoBo tenantInfo = new SubTenantInitInfoBo();
        //tenantInfo.setName("云智慧北京");
        tenantInfo.setParentId(1L);
        tenantInfo.setCreateUserId(2L);
        Whitebox.invokeMethod(this.multiAccountService, "validateSubTenantParams", tenantInfo);
    }

    @Test
    public void validateSubTenantParamsParentIdVerify() throws Exception {
        SubTenantInitInfoBo tenantInfo = new SubTenantInitInfoBo();
        tenantInfo.setName("云智慧北京");
        //tenantInfo.setParentId(1L);
        tenantInfo.setCreateUserId(2L);
        try {
            Whitebox.invokeMethod(this.multiAccountService, "validateSubTenantParams", tenantInfo);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_PARENT_ID_NOT_BLANK, e.getCode());
        }
    }

    @Test
    public void validateSubTenantParamsVisibleScopeVerify() throws Exception {
        SubTenantInitInfoBo tenantInfo = new SubTenantInitInfoBo();
        tenantInfo.setName("云智慧北京");
        tenantInfo.setParentId(1L);
        //tenantInfo.setCreateUserId(2L);
        try {
            Whitebox.invokeMethod(this.multiAccountService, "validateSubTenantParams", tenantInfo);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_CREATE_USER_NOT_BLANK, e.getCode());
        }
    }

    /**
     * {@link MultiAccountServiceImpl#getUserSecret }
     **/
    @Test
    public void getUserSecret() throws Exception {
        String secret = "==defaultPWD==";
        String originUserSecret = "04F20171E0A901D8C9DA12550667F2D039B741158FA09D2473094019B88611D88F108942B9854186D84D5984095E02C9FC700E45E0ADA0BBB0E774E9DBF35B57A0E1933D7817474AD8207D8D1488AA419FF2395DBFB80E6C51A0B859DC0A620D9C6B3A9237AD184BA2F9A30A89CCF7165ACD84E79C0E07034A012D1174ADB999316261F1C0DFEBA7504E33DBD8AA45BA3F6DE6EA1AC86B5656C6D872FBB2EBDF2AB57EAD65C789D998E31578DF374804ECA86D";
        TenantUserSecretSm2Info tenantUserSecretSm2Info = Whitebox.invokeMethod(this.multiAccountService, "getUserSecret", originUserSecret);
        Assert.assertEquals(secret, tenantUserSecretSm2Info.getClearTextUserSecret());
    }

    /**
     * 租户
     *
     * @author maker.wang
     * @date 2021-07-02 20:24
     **/
    @Test
    public void topTenantInit() throws Exception {
        String accountName = "云智慧";
        TopTenantInitInfoBo tenantInfo = new TopTenantInitInfoBo();
        tenantInfo.setName(accountName);
        //打桩
        Mockito.when(this.accountMapper.insert(Mockito.any(AccountDetail.class))).thenReturn(1);
        TenantInitInfoVo tenantInitInfoVo = Whitebox.invokeMethod(this.multiAccountService, "topTenantInit", tenantInfo);
        //断言
        Assert.assertEquals(accountName, tenantInitInfoVo.getName());
        Assert.assertEquals("0", tenantInitInfoVo.getLevel());
        Assert.assertEquals(MultiAccountStatusEnum.NORMAL.getCode(), tenantInitInfoVo.getStatus());
    }

    @Test
    public void subTenantInit() throws Exception {
        String userSecret = "==defaultPWD==-";
        String sm3Secret = Sm3Digest.SMCEncryption(userSecret);
        String sm2Secret = Sm2Utils.SMBEncryption(userSecret + "--" + sm3Secret, SmsecurityService.pubkey);
        TenantSystemAdministratorInfoBo adminInfo = new TenantSystemAdministratorInfoBo();
        adminInfo.setUserName("中海油");
        adminInfo.setEmail("chengweiliao@yunzhihui.com");
        adminInfo.setUserSecret(sm2Secret);

        SubTenantInitInfoBo tenantInfo = new SubTenantInitInfoBo();
        tenantInfo.setName("中海油");
        tenantInfo.setParentId(1L);
        tenantInfo.setCreateUserId(2L);

        tenantInfo.setParentLevel("0");

        TenantInitInfoVo tenantInitInfoVo = Whitebox.invokeMethod(this.multiAccountService, "subTenantInit", tenantInfo);
        Assert.assertEquals("中海油", tenantInitInfoVo.getName());
        Mockito.verify(this.accountMapper, Mockito.times(1)).insert(Mockito.any(AccountDetail.class));
    }

    /**
     * 部门
     *
     * @author maker.wang
     * @date 2021-07-02 20:24
     **/
    @Test
    public void topDepartmentInit() throws Exception {
        String accountName = "云智慧";
        Long accountId = 2L;

        //打桩
        Mockito.when(this.departmentDao.addSubDepartment(ArgumentMatchers.any())).thenReturn(1);
        Department department = Whitebox.invokeMethod(this.multiAccountService, "topDepartmentInit", accountId, accountName);
        //断言
        Assert.assertEquals(accountName, department.getName());
        Assert.assertEquals("0", department.getLevel());
        Assert.assertEquals(accountId, department.getAccountId());
    }

    /**
     * 部门资源及角色
     *
     * @author maker.wang
     * @date 2021-07-02 20:28
     **/
    @Test
    public void topDepartmentResourceRoleInit() throws Exception {
        Long accountId = 2L;
        Long departmentId = 2L;
        Long userId = 2L;
        Long roleId = 2L;
        //打桩
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "topDepartmentResourceRoleInit", accountId, departmentId, userId, roleId);
        //断言
        Assert.assertEquals(true, result);
    }

    /**
     * 系统管理员初始化
     *
     * @author maker.wang
     * @date 2021-07-02 20:31
     **/
    @Test
    public void topTenantSystemAdministratorInit() throws Exception {
        Long accountId = 2L;
        //打桩
        MemberModifier.field(MultiAccountServiceImpl.class, "systemAdminEmail")
                .set(this.multiAccountService, "cloudwise@yunzhihui.com");
        MemberModifier.field(MultiAccountServiceImpl.class, "systemAdminName")
                .set(this.multiAccountService, "Admin");
        MemberModifier.field(MultiAccountServiceImpl.class, "systemAdminSecret")
                .set(this.multiAccountService, "04E42E13A1D1F2506917700E0E7AE18121B9B87F78F150BE0A10CCA18C7034FC9BFA358815C56DE7BC563DBD0C4F906E11B217A9C6E20C32DC13E8F6D18C7B6E3740840FA3499199EA1B6FB4E4AA475BE5985C16FD32CFA6CC6ACA59348693C49C80A306BBB1E4C3692FC3D36D8D96B7D9");
        Mockito.when(this.iMultiAccountUserInfoDao.addUserInfo(ArgumentMatchers.any())).thenReturn(1);
        Mockito.when(this.iMultiAccountUserDao.addUser(ArgumentMatchers.any())).thenReturn(1);
        TenantDefaultUserInfoVo defaultUserInfoVo = Whitebox.invokeMethod(this.multiAccountService, "topTenantSystemAdministratorInit", accountId);
        //断言
        MultiAccountUserInfoDetail userInfoDetail = defaultUserInfoVo.getUserInfoDetail();
        MultiAccountUserDetail userDetail = defaultUserInfoVo.getUserDetail();
        Assert.assertEquals(accountId, userInfoDetail.getDefaultAccountId());
        Assert.assertEquals(accountId, userInfoDetail.getTopAccountId());
        Assert.assertEquals(accountId, userDetail.getAccountId());
    }

    @Test
    public void departmentResourceInit() throws Exception {
        Long accountId = 1L;
        Mockito.doReturn(1).when(this.iDepartmentDataResourceDao).batchAddDepartmentResource(ArgumentMatchers.any());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "departmentResourceInit", accountId, accountId, accountId);
        Mockito.verify(this.iDepartmentDataResourceDao, Mockito.times(1)).batchAddDepartmentResource((ArgumentMatchers.any()));
        //断言
        Assert.assertEquals(true, result);

    }

    @Test
    public void innerSystemInit() throws Exception {

        Long topAccountId = 1L;
        Long accountId = 1L;
        //打桩
        MemberModifier.field(MultiAccountServiceImpl.class, "MULTI_SPLIT_THREE_HORIZONTAL_LINE")
                .set(this.multiAccountService, "--");
        MemberModifier.field(MultiAccountServiceImpl.class, "systemAdminSecret")
                .set(this.multiAccountService, "04E42E13A1D1F2506917700E0E7AE18121B9B87F78F150BE0A10CCA18C7034FC9BFA358815C56DE7BC563DBD0C4F906E11B217A9C6E20C32DC13E8F6D18C7B6E3740840FA3499199EA1B6FB4E4AA475BE5985C16FD32CFA6CC6ACA59348693C49C80A306BBB1E4C3692FC3D36D8D96B7D9");
        Mockito.doReturn(1).when(this.iMultiAccountUserInfoDao).addUserInfo(ArgumentMatchers.any());
        Mockito.doReturn(1).when(this.iMultiAccountUserDao).addUser(ArgumentMatchers.any());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "innerSystemInit", topAccountId, accountId);
        Mockito.verify(this.iMultiAccountUserInfoDao, Mockito.times(1)).addUserInfo(ArgumentMatchers.any());
        Mockito.verify(this.iMultiAccountUserDao, Mockito.times(1)).addUser(ArgumentMatchers.any());
        Assert.assertEquals(true, result);

    }

    @Test
    public void checkUserAliasUnique() throws Exception {
        String userAlias = "zhy";
        Long topAccountId = 100000L;
        Mockito.when(this.iMultiAccountUserInfoDao.checkUserAliasUnique(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(1);
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "checkUserAliasUnique", userAlias, topAccountId);
        Assert.assertEquals(false, result);

    }

    @Test
    public void checkUserAliasUniqueNormal() throws Exception {
        String userAlias = "zhy";
        Long topAccountId = 100000L;
        Mockito.when(this.iMultiAccountUserInfoDao.checkUserAliasUnique(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(0);
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "checkUserAliasUnique", userAlias, topAccountId);
        Assert.assertEquals(true, result);

    }

    @Test
    public void tenantSystemAdministratorRoleInit() throws Exception {
        Long accountId = 1L;
        Long userId = 1L;
        Mockito.doReturn(1).when(this.iUserRoleGroupRelationDao).addUserRoleRelation(ArgumentMatchers.any());
        Mockito.doNothing().when(this.roleService).addRoleGroup(ArgumentMatchers.any());
        Mockito.doNothing().when(this.roleService).addRole(ArgumentMatchers.any());
        TenantDefaultRoleInfoVo roleInfo = Whitebox.invokeMethod(this.multiAccountService, "tenantSystemAdministratorRoleInit", accountId, userId);
        Mockito.verify(this.iUserRoleGroupRelationDao, Mockito.times(1)).addUserRoleRelation(ArgumentMatchers.any());
        Assert.assertEquals(true, null != roleInfo);

    }

    @Test
    public void tenantDictionaryInit() throws Exception {
        Long accountId = 1L;

        Mockito.doReturn(1).when(this.iDicDataDao).batchAddDicType(ArgumentMatchers.any());
        Mockito.doReturn(1).when(this.iDicDataDao).batchAddDicData(ArgumentMatchers.any());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "tenantDictionaryInit", accountId);

        Mockito.verify(this.iDicDataDao, Mockito.times(1)).batchAddDicData(ArgumentMatchers.any());
        Mockito.verify(this.iDicDataDao, Mockito.times(1)).batchAddDicData(ArgumentMatchers.any());
        Assert.assertEquals(true, result);

    }

    @Test
    public void accountModuleInit() throws Exception {
        Long accountId = 1L;
        List<Module> moduleList = new ArrayList<>();
        Module module = new Module();
        module.setName("用户中心");
        moduleList.add(module);
        Mockito.doReturn(0).when(this.iModuleAccountDao).countAccountModuleNum(ArgumentMatchers.any());
        Mockito.doReturn(moduleList).when(this.iModuleDao).getModuleList();
        Mockito.doReturn(1).when(this.iModuleAccountDao).addNewModuleAccount(ArgumentMatchers.any());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "accountModuleInit", accountId);
        Mockito.verify(this.iModuleAccountDao, Mockito.times(1)).countAccountModuleNum(ArgumentMatchers.any());
        Mockito.verify(this.iModuleDao, Mockito.times(1)).getModuleList();
        Mockito.verify(this.iModuleAccountDao, Mockito.times(1)).addNewModuleAccount(ArgumentMatchers.any());
        Assert.assertEquals(true, result);
    }

    @Test
    public void accountModuleInitException() throws Exception {
        Long accountId = 1L;
        List<Module> moduleList = new ArrayList<>();
        Module module = new Module();
        module.setName("用户中心");
        moduleList.add(module);
        Mockito.doReturn(1).when(this.iModuleAccountDao).countAccountModuleNum(ArgumentMatchers.any());
        Boolean result = false;
        try {
            result = Whitebox.invokeMethod(this.multiAccountService, "accountModuleInit", accountId);
        } catch (BaseException e) {
            Assert.assertEquals(IBaseExceptionCode.MULTI_ACCOUNT_MODULE_INIT_FINISH, e.getCode());
        }
        Mockito.verify(this.iModuleAccountDao, Mockito.times(1)).countAccountModuleNum(ArgumentMatchers.any());
        Assert.assertEquals(false, result);
    }

    @Test
    public void tenantSystemSettingInit() throws Exception {
        Long accountId = 1L;
        doReturn(1).when(this.iSystemSettingDao).insertSystemSetting(anyList(), any(), anyLong());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "tenantSystemSettingInit", accountId);
        verify(this.iSystemSettingDao, times(1)).insertSystemSetting(anyList(), any(), anyLong());
        Assert.assertEquals(true, result);
    }

    @Test
    public void tenantLogoInit() throws Exception {
        Long accountId = 1L;
        Mockito.doReturn(1).when(this.iLogoDao).batchAddLogoConfig(ArgumentMatchers.any());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "tenantLogoInit", accountId);
        Mockito.verify(this.iLogoDao, Mockito.times(1)).batchAddLogoConfig(ArgumentMatchers.any());
        Assert.assertEquals(true, result);
    }

    @Test
    public void subTenantLogoInit() throws Exception {
        Long accountId = 2L;
        Long parentId = 1L;
        List<LogoEntity> parentAccountLogoList = new ArrayList<>();
        LogoEntity logoEntity = new LogoEntity();
        logoEntity.setAccountId(1L);
        parentAccountLogoList.add(logoEntity);
        Mockito.doReturn(parentAccountLogoList).when(this.iLogoDao).getAllLogoByAccountId(ArgumentMatchers.any());
        Mockito.doReturn(1).when(this.iLogoDao).batchAddLogoConfig(ArgumentMatchers.any());
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "subTenantLogoInit", accountId, parentId);
        Mockito.verify(this.iLogoDao, Mockito.times(1)).batchAddLogoConfig(ArgumentMatchers.any());
        Mockito.verify(this.iLogoDao, Mockito.times(1)).getAllLogoByAccountId(ArgumentMatchers.any());
        Assert.assertEquals(true, result);
    }

    @Test
    public void accountInitUpdateCache() throws Exception {
        TenantInitResultVo tenantInitResultVo = new TenantInitResultVo();

        TenantInitInfoVo tenantInfo = new TenantInitInfoVo();
        TenantDefaultUserInfoVo defaultUserInfo = new TenantDefaultUserInfoVo();
        Department department = new Department();

        MultiAccountUserDetail userDetail = new MultiAccountUserDetail();
        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();

        defaultUserInfo.setUserInfoDetail(userInfoDetail);
        defaultUserInfo.setUserDetail(userDetail);

        tenantInitResultVo.setDepartment(department);
        tenantInitResultVo.setTenantInfo(tenantInfo);
        tenantInitResultVo.setDefaultUserInfo(defaultUserInfo);
        Mockito.doNothing().when(this.iUserCache).addOrUpdateSingleUserBasedToCache(ArgumentMatchers.any());
        PowerMockito.mockStatic(RedisTools.class);
        PowerMockito.when(RedisTools.hmset(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(true);
        boolean result = Whitebox.invokeMethod(this.multiAccountService, "accountInitUpdateCache", tenantInitResultVo);
        Mockito.verify(this.iUserCache).addOrUpdateSingleUserBasedToCache(ArgumentMatchers.any());
        Assert.assertTrue(result);
    }

    @Test
    public void main1() {
        String str = "abc--bcd--efg";
        int i = str.lastIndexOf("--");
        String substring = str.substring(0, i);
        log.info("{}", substring);
    }

}