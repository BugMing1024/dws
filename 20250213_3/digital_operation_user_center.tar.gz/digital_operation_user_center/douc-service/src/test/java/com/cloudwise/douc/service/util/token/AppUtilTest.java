package com.cloudwise.douc.service.util.token;

import com.cloudwise.douc.commons.utils.sm2.Sm2Utils;
import com.cloudwise.douc.commons.utils.sm2.Sm3Digest;
import com.cloudwise.douc.commons.utils.sm2.SmsecurityService;
import lombok.extern.slf4j.Slf4j;

/**
 * @author maker.wang
 * @description: 随机产生唯一的app_key和app_secret
 * @date Created in 10:40 上午 2021/6/2.
 */
@Slf4j
public class AppUtilTest {

    /**
     * 生成测试
     *
     * @param args
     * @return void
     * @author maker.wang
     * @date 2021-06-02
     * @time 10:47
     */
    public static void main(String[] args) {
        ///String appId = getAppId();
        ///String appSecret = getAppSecret(appId);
        String appId = "Kg2RjXEj";
        String appSecret = "3b625909bc94a4a051a0c7c7c39b77fa23285808";
        log.info("{}", "appId: " + appId);
        log.info("{}", "appSecret: " + appSecret);
        //生成sm2加密appSecret
        String appSecretSm2 = AppUtil.sm2GenerateAppSecretWithTimeStamp(appSecret);
        log.error("sm2加密后:{}", appSecretSm2);
        //解压sm2加密的appSecret
        String appSecretDecryPtSm2 = Sm2Utils.SMBDecrypt(appSecretSm2, SmsecurityService.prikey);
        //log.error("sm2解密后:{}", appSecretDecryPtSm2);

        //sm2加密
        String secret = "==defaultPWD==";
        secret = Sm2Utils.SMBEncryption(secret, SmsecurityService.pubkey);
        /// 04E42E13A1D1F2506917700E0E7AE18121B9B87F78F150BE0A10CCA18C7034FC9BFA358815C56DE7BC563DBD0C4F906E11B217A9C6E20C32DC13E8F6D18C7B6E3740840FA3499199EA1B6FB4E4AA475BE5985C16FD32CFA6CC6ACA59348693C49C80A306BBB1E4C3692FC3D36D8D96B7D9
        log.error("系统管理员：{}", secret);
        secret = Sm2Utils.SMBDecrypt("046db5b5c4be2d4a677cb41db179f494ddbfaec1cc0e449ed3db6c0d4b2bfb06433a9f2c8e42035e8e85a62fa056e9b9da7c4241e47b0aa94dc6c3ec47d0a87570ce1ac1b1bfcee8d10453dd94a8f1d50a9d9d1140940ade96a9efa70672446c25acae802b668ade1a3f88568bd4", SmsecurityService.prikey);
        //log.error("系统管理员：{}", secret);
        
        //log.error("sm3加密：{}", Sm3Digest.SMCEncryption("Cloudwise_123"));
        String sm2jie = Sm2Utils.SMBDecrypt("0496CBB7E52CC0C9F6062308AFB97D48C57E1AA73622613BD3DCCB55C25FDF66FAD3B4E41483B7E26DFCA456A987E69DCF7DBF685A17E7E0762B2E343A888CFB9D24E51DA7313EA8A9B3AC07FFAE41096599652402BA7C2C689F36E65E5685AB6BA85B5EF936E14CD0F0D60DF96DE6ABEED06402A59ACC92AD0BB89F422B74863D96DB3E088043643DBD33BC30B80B800B71322B212C325B84F55F977BEF8F4BC51271A83C980C655A84D52E9BFA24599301A67A", SmsecurityService.prikey);
        //log.error("sm2解密：：{}", sm2jie);
        //sm2(明文密码---sm3(明文密码))
        secret = "==defaultPWD==";
        secret = secret + "--" + Sm3Digest.SMCEncryption(secret);
        secret = Sm2Utils.SMBEncryption(secret, SmsecurityService.pubkey);
        //log.error("sm2(明文密码---sm3(明文密码)):{}", secret);
    }

}
