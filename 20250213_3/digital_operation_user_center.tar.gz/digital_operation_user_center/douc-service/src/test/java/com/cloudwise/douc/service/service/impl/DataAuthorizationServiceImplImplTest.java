package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.model.DataPage;
import com.cloudwise.douc.metadata.mapper.IDataAuthorizationDao;
import com.cloudwise.douc.metadata.mapper.IResourceDataDao;
import com.cloudwise.douc.metadata.model.data.GroupDataNode;
import com.cloudwise.douc.metadata.model.dataauthorization.DataAndGroupRelationPo;
import com.cloudwise.douc.metadata.model.dataauthorization.DataSearchVo;
import com.cloudwise.douc.metadata.model.dataauthorization.DataTypeRequestObject;
import com.cloudwise.douc.metadata.model.dataauthorization.DataTypeVo;
import com.cloudwise.douc.metadata.model.dataauthorization.GroupDataGroup2AddBo;
import com.cloudwise.douc.service.model.dataauthorization.DataAuthUpdateParam;
import com.cloudwise.douc.service.model.dataauthorization.DataAuthUpdateParamFromSearchList;
import com.cloudwise.douc.service.model.dataauthorization.DataSearchParam;
import com.cloudwise.douc.service.service.IGroupDataService;
import com.cloudwise.douc.service.service.IGroupService;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author leakey.li
 * @description:资源权限单元测试
 * @date Created in 5:25 下午 2021/6/16.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({DataAuthorizationServiceImpl.class})
@PowerMockIgnore({"javax.management.*"})
public class DataAuthorizationServiceImplImplTest {
    @Mock
    private IDataAuthorizationDao dataAuthorizationDao;
    @Mock
    private IResourceDataDao resourceDataDao;
    @Mock
    private IGroupService groupService;
    @Mock
    private IGroupDataService groupDataService;
    @InjectMocks
    private DataAuthorizationServiceImpl dataAuthorizationServiceImpl;


    /**
     * {@link DataAuthorizationServiceImpl#getParentGroupIdById(long)}
     *
     * @return
     * @description 获取父id
     * @author leakey.li
     * @date 2021/6/16
     * @time 5:33 下午
     */
    @Test
    public void getParentGroupIdById() throws Exception {
        //入参
        Long id = 2L;
        //打桩
        Mockito.when(dataAuthorizationDao.getParentGroupIdById(Mockito.anyLong())).thenReturn(1L);
        //调用测试方法
        Long parentId = Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "getParentGroupIdById", id);
        //校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getParentGroupIdById(Mockito.anyLong());
        //断言
        Assert.assertEquals(true, parentId == 1L);
    }

    /**
     * {@link DataAuthorizationServiceImpl#//updateAuth(DataAuthUpdateParam,long,long)}
     *
     * @return
     * @description 其它——全量的权限编辑
     * @author leakey.li
     * @date 2021/6/17
     * @time 1:33 下午
     */
    @Test
    public void updateAuthOther() throws Exception {
        //入参
        Long userId = 2L;
        Long accountId = 110L;
        DataAuthUpdateParam param = getDataAuthUpdateParam("other_module");
        //打桩
        //私有方法打桩
        DataAuthorizationServiceImpl privateMethod = PowerMockito.spy(this.dataAuthorizationServiceImpl);
        PowerMockito.doNothing().when(privateMethod, "deleteChildrenGroupDataAuthFromTree", Mockito.any());

        //DAO 打桩

        Mockito.when(dataAuthorizationDao.deleteGroupDataGroupRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.deleteGroupDataRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.addGroupDataGroupRelations(Mockito.anyList())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.addGroupDataRelations(Mockito.anyList())).thenReturn(1);

        //调执行的测试方法
        Whitebox.invokeMethod(privateMethod,
                "updateAuth", param, userId, accountId);
        //验证
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("deleteChildrenGroupDataAuthFromTree", Mockito.any());

        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteGroupDataGroupRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteGroupDataRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString());

        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addGroupDataGroupRelations(Mockito.anyList());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addGroupDataRelations(Mockito.anyList());

        //断言

    }

    /**
     * {@link DataAuthorizationServiceImpl#//updateAuth(DataAuthUpdateParam,long,long)}
     *
     * @return
     * @description 用户中心——全量的权限编辑
     * @author leakey.li
     * @date 2021/6/17
     * @time 10:33 下午
     */
    @Test
    public void updateAuthUserCenter() throws Exception {
        //入参
        Long userId = 2L;
        Long accountId = 110L;
        DataAuthUpdateParam param = getDataAuthUpdateParam("100");
        //打桩
        //私有方法打桩
        DataAuthorizationServiceImpl privateMethod = PowerMockito.spy(this.dataAuthorizationServiceImpl);
        PowerMockito.doNothing().when(privateMethod, "deleteChildrenGroupDataAuthFromTree", Mockito.any());

        //DAO 打桩
        List<DataAndGroupRelationPo> specialDepartmentRelations = new ArrayList<>();
        DataAndGroupRelationPo po = new DataAndGroupRelationPo();
        po.setDataTypeCode("dtc");
        po.setAccountId(110L);
        po.setModuleCode("100");
        po.setType(1);
        specialDepartmentRelations.add(po);

        Mockito.when(dataAuthorizationDao.getDataByDataGroup(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(specialDepartmentRelations);
        List<DataAndGroupRelationPo> specialGroupRelations = new ArrayList<>();
        DataAndGroupRelationPo po1 = new DataAndGroupRelationPo();
        po1.setDataTypeCode("dtc");
        po1.setAccountId(110L);
        po1.setGroupId(2L);
        po1.setModuleCode("100");
        po1.setType(1);
        specialGroupRelations.add(po1);
        Mockito.when(dataAuthorizationDao.getDataByDataGroup(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(specialGroupRelations);
        Mockito.when(dataAuthorizationDao.deleteGroupDataGroupRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.deleteGroupDataRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(1);
        List<String> codes = new ArrayList<>();
        codes.add("111");
        Mockito.when(dataAuthorizationDao.getDataByDataCodes(Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(codes);
        Mockito.when(dataAuthorizationDao.getDataByDataCodes(Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(codes);
        Mockito.when(resourceDataDao.deleteResourceData(Mockito.any())).thenReturn(1);
        Mockito.when(resourceDataDao.addResourceDataList(Mockito.anyList())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.addGroupDataGroupRelations(Mockito.anyList())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.addGroupDataRelations(Mockito.anyList())).thenReturn(1);


        //调执行的测试方法
        Whitebox.invokeMethod(privateMethod,
                "updateAuth", param, userId, accountId);
        //验证
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("deleteChildrenGroupDataAuthFromTree", Mockito.any());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataByDataGroup(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataByDataGroup(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteGroupDataGroupRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteGroupDataRelations(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataByDataCodes(Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataByDataCodes(Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList());
        Mockito.verify(this.resourceDataDao, Mockito.atLeastOnce()).deleteResourceData(Mockito.any());
        Mockito.verify(this.resourceDataDao, Mockito.atLeastOnce()).addResourceDataList(Mockito.anyList());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addGroupDataGroupRelations(Mockito.anyList());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addGroupDataRelations(Mockito.anyList());

        //断言

    }


    /**
     * @return
     * @description 级联删除子用户组的权限 _UT
     * @author leakey.li
     * @date 2021/6/17
     * @time 3:08 下午
     */
    @Test
    public void updateAuthDeleteChildrenGroupDataAuthFromTree() throws Exception {
        //入参
        DataAuthUpdateParam param = getDataAuthUpdateParam("100");

        //打桩
        Set<Long> chidrenGroupIdSet = new HashSet<>();
        chidrenGroupIdSet.add(2L);
        Mockito.when(groupService.getIdChainSet(Mockito.anyLong(), Mockito.anyLong())).thenReturn(chidrenGroupIdSet);
        List<GroupDataNode> groupIncloudeFutureNodeList = new ArrayList<>();
        Mockito.when(groupDataService.getGroupIncludeFutureDataNode(Mockito.any())).thenReturn(groupIncloudeFutureNodeList);
        List<GroupDataNode> dataNodeList = new ArrayList<>();
        GroupDataNode groupDataNode = new GroupDataNode();
        groupDataNode.setAccountId(110L);
        groupDataNode.setModuleCode("100");
        groupDataNode.setNodeCode("123");
        dataNodeList.add(groupDataNode);
        Mockito.when(groupDataService.getSelectedDataNode(Mockito.any())).thenReturn(dataNodeList);

        Mockito.doNothing().when(dataAuthorizationDao).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.doNothing().when(dataAuthorizationDao).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.doNothing().when(dataAuthorizationDao).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        //调用测试方法
        Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "deleteChildrenGroupDataAuthFromTree", param);
        //验证
        Mockito.verify(this.groupService, Mockito.atLeastOnce()).getIdChainSet(Mockito.anyLong(), Mockito.anyLong());
        Mockito.verify(this.groupDataService, Mockito.atLeastOnce()).getGroupIncludeFutureDataNode(Mockito.any());
        Mockito.verify(this.groupDataService, Mockito.atLeastOnce()).getSelectedDataNode(Mockito.any());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
    }

    /**
     * @return
     * @description
     * @author leakey.li
     * @date 2021/6/17
     * @time 3:59 下午
     */
    @Test
    public void updateAuthFromSearchList() throws Exception {
        //入参
        DataAuthUpdateParamFromSearchList param = getDataAuthUpdateParamFromSearchList();
        //打桩
        DataAuthorizationServiceImpl privateMethod = PowerMockito.spy(this.dataAuthorizationServiceImpl);

        // 查询出所有节点的 "包含新增"的父级节点
        List<DataAndGroupRelationPo> includeFutureRelations = new ArrayList<>();
        DataAndGroupRelationPo po = new DataAndGroupRelationPo();
        po.setDataGroupCode("10000");
        po.setGroupId(2L);
        po.setAccountId(110L);
        po.setDataTypeCode("10013");
        includeFutureRelations.add(po);
        Mockito.when(dataAuthorizationDao.listGroupIncludeFutureRelations(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet())).thenReturn(includeFutureRelations);

        PowerMockito.doNothing().when(privateMethod, "handleRealDeletingNodeWithIncludeFuturePatent", Mockito.any(), Mockito.anyList(), ArgumentMatchers.anySet());
        Mockito.when(dataAuthorizationDao.deleteGroupDataRelationsFromSearchList(Mockito.anyLong(), Collections.singleton(Mockito.anyLong()), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet())).thenReturn(1);
        Mockito.when(dataAuthorizationDao.addGroupDataRelations(Mockito.anyList())).thenReturn(2);
        PowerMockito.doNothing().when(privateMethod, "deleteChildrenGroupDataAuth", Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList());
        Set<Long> groupIdSet = new HashSet<>();
        groupIdSet.add(3L);
        Mockito.when(groupService.getIdChainSet(Mockito.anyLong(), Mockito.anyLong())).thenReturn(groupIdSet);

        Mockito.doNothing().when(dataAuthorizationDao).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.doNothing().when(dataAuthorizationDao).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.doNothing().when(dataAuthorizationDao).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());

        PowerMockito.doNothing().when(privateMethod, "addGroupDataGroupRelations", Mockito.any(), ArgumentMatchers.anySet());

        //调用测试方法
        Whitebox.invokeMethod(privateMethod,
                "updateAuthFromSearchList", param);
        //校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).listGroupIncludeFutureRelations(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("handleRealDeletingNodeWithIncludeFuturePatent", Mockito.any(), Mockito.anyList(), ArgumentMatchers.anySet());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteGroupDataRelationsFromSearchList(Mockito.anyLong(), Collections.singleton(Mockito.anyLong()), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addGroupDataRelations(Mockito.anyList());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("deleteChildrenGroupDataAuth", Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList());
        Mockito.verify(this.groupService, Mockito.atLeastOnce()).getIdChainSet(Mockito.anyLong(), Mockito.anyLong());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteEmptyDataGroupRelations(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), Mockito.anyInt());

        //断言

    }

    /**
     * @return
     * @description找到删除节点中,父节点是"包含新增"的,然后: * 1. 把该节点的层层父级的include_future设为2
     * * 2. 把该节点所在分组下的其他兄弟姐妹数据添加进来
     * @author leakey.li
     * @date 2021/6/17
     * @time 5:48 下午
     */
    @Test
    public void handleRealDeletingNodeWithIncludeFuturePatent() throws Exception {
        //入参
        DataAuthUpdateParamFromSearchList param = getDataAuthUpdateParamFromSearchList();
        List<DataAndGroupRelationPo> dataRelations2Delete = getDataAndGroupRelationPos();
        Set<String> includeFutureNodeIdSet = new HashSet<>();
        includeFutureNodeIdSet.add("1:test:2:233:");
        includeFutureNodeIdSet.add("14");

        //打桩

        Set<Long> groupIdSet = new HashSet<>();
        groupIdSet.add(3L);
        Mockito.when(groupService.getIdChainSet(Mockito.anyLong(), Mockito.anyLong())).thenReturn(groupIdSet);
        List<String> dataCodeList = new ArrayList<>();
        dataCodeList.add("111");
        dataCodeList.add("222");
        Mockito.when(resourceDataDao.listDataCodeByDataGroup(Mockito.any())).thenReturn(dataCodeList);
        List<Long> groupIdList = new ArrayList<>();
        groupIdList.add(2L);
        Mockito.when(dataAuthorizationDao.listIncludeFutureGroupId(Mockito.any(), ArgumentMatchers.anySet())).thenReturn(groupIdList);
        Mockito.when(dataAuthorizationDao.addMultiGroupDataRelations(Mockito.anyList(), Mockito.anyCollection())).thenReturn(2);
        Mockito.when(dataAuthorizationDao.updateBranchNodes2NotIncludeFuture(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet())).thenReturn(2);

        //调用测试方法
        Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "handleRealDeletingNodeWithIncludeFuturePatent", param, dataRelations2Delete, includeFutureNodeIdSet);
        //校验
        Mockito.verify(this.groupService, Mockito.atLeastOnce()).getIdChainSet(Mockito.anyLong(), Mockito.anyLong());
        Mockito.verify(this.resourceDataDao, Mockito.atLeastOnce()).listDataCodeByDataGroup(Mockito.any());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).listIncludeFutureGroupId(Mockito.any(), ArgumentMatchers.anySet());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addMultiGroupDataRelations(Mockito.anyList(), Mockito.anyCollection());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).updateBranchNodes2NotIncludeFuture(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet());
        //断言

    }


    /**
     * @return
     * @description 如果所需添加的节点的父节点(可能是数据类型或者数据分组)是包含新增的, 那么就不再添加了
     * @author leakey.li
     * @date 2021/6/18
     * @time 2:55 下午
     */
    @Test
    public void removeFakeAddingNodeWithIncludeFuturePatent() throws Exception {
        //入参
        List<DataAndGroupRelationPo> dataRelations2Add = new ArrayList<>();
        DataAndGroupRelationPo po = new DataAndGroupRelationPo();
        po.setIncludeFuture(2);
        po.setDataCode("111");
        po.setModuleCode("100");
        po.setDataTypeCode("112");
        po.setAccountId(110L);
        po.setType(1);
        po.setGroupId(2L);

        dataRelations2Add.add(po);
        Set<String> includeFutureNodeIdSet = new HashSet<>();
        includeFutureNodeIdSet.add("1:100");
        //调用测试方法
        Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "removeFakeAddingNodeWithIncludeFuturePatent", dataRelations2Add, includeFutureNodeIdSet);

    }

    /**
     * @return
     * @description* 即如果添加了子节点, 也要级联添加父节点
     * 如果用户组-数据关系表中的一个数据类型,在用户组-数据组关系表中找不到与之对应的模块/数据类型/数据分组,则新增
     * @author leakey.li
     * @date 2021/6/18
     * @time 3:11 下午
     */
    @Test
    public void addGroupDataGroupRelations() throws Exception {
        //入参
        DataAuthUpdateParamFromSearchList param = getDataAuthUpdateParamFromSearchList();
        Set<String> moduleCodeSet = new HashSet<>();
        moduleCodeSet.add("100");
        moduleCodeSet.add("110");

        //打桩
        List<GroupDataGroup2AddBo> groupDataGroup2Add = new ArrayList<>();
        GroupDataGroup2AddBo groupDataGroup2AddBo = new GroupDataGroup2AddBo();
        groupDataGroup2AddBo.setDataGroupCode("3344");
        groupDataGroup2AddBo.setDataGroupCode2Add("123");
        groupDataGroup2AddBo.setDataCode("111");
        groupDataGroup2AddBo.setDataTypeCode("1234");
        groupDataGroup2AddBo.setModuleCode("100");
        groupDataGroup2AddBo.setModuleCode2Add("1211");
        groupDataGroup2Add.add(groupDataGroup2AddBo);
        Mockito.when(dataAuthorizationDao.getGroupDataGroup2Add(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anySet())).thenReturn(groupDataGroup2Add);
        Mockito.when(dataAuthorizationDao.addGroupDataGroupRelations(Mockito.anyList())).thenReturn(2);

        //调用测试方法
        Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "addGroupDataGroupRelations", param, moduleCodeSet);
        //校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getGroupDataGroup2Add(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anySet());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).addGroupDataGroupRelations(Mockito.anyList());

    }

    /**
     * @return
     * @description 删除目标用户组的子孙用户组的对应的数据权限
     * @author leakey.li
     * @date 2021/6/18
     * @time 3:33 下午
     */
    @Test
    public void deleteChildrenGroupDataAuth() throws Exception {
        //入参
        Long accountId = 110L;
        Long groupId = 2L;
        List<DataAndGroupRelationPo> dataRelations2Delete = getDataAndGroupRelationPos();
        //打桩
        Set<Long> groupIdSet = new HashSet<>();
        groupIdSet.add(3L);
        Mockito.when(groupService.getIdChainSet(Mockito.anyLong(), Mockito.anyLong())).thenReturn(groupIdSet);
        Mockito.when(dataAuthorizationDao.deleteGroupDataRelationsFromSearchList(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet())).thenReturn(2);
        //调用测试方法
        Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "deleteChildrenGroupDataAuth", accountId, groupId, dataRelations2Delete);
        //校验
        Mockito.verify(this.groupService, Mockito.atLeastOnce()).getIdChainSet(Mockito.anyLong(), Mockito.anyLong());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).deleteGroupDataRelationsFromSearchList(Mockito.anyLong(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet(), ArgumentMatchers.anySet());

    }

    /**
     * @return
     * @description 查询用户组在某个模块下的数据类型
     * @author leakey.li
     * @date 2021/6/18
     * @time 3:50 下午
     */
    @Test
    public void getDataTypeListByModule() throws Exception {
        //入参
        DataTypeRequestObject param = new DataTypeRequestObject();
        param.setModuleCode("100");
        param.setAccountId(110L);
        param.setGroupId(2L);
        Set<String> excledeDataTypeCodeSet = new HashSet<>();
        excledeDataTypeCodeSet.add("112");
        param.setExcledeDataTypeCodeSet(excledeDataTypeCodeSet);
        //打桩
        Long parentGroupId = 1L;
        Mockito.when(dataAuthorizationDao.getParentGroupIdById(Mockito.anyLong())).thenReturn(parentGroupId);
        List<DataTypeVo> dataTypeVoList = new ArrayList<>();
        DataTypeVo vo = new DataTypeVo();
        vo.setCode("110012");
        vo.setName("组织机构管理");
        vo.setId(2L);
        dataTypeVoList.add(vo);
        Mockito.when(dataAuthorizationDao.getDataTypeListByModule(Mockito.any())).thenReturn(dataTypeVoList);

        //调用测试方法
        List<DataTypeVo> dataTypeVoResultList = Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "getDataTypeListByModule", param);
        //校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getParentGroupIdById(Mockito.anyLong());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataTypeListByModule(Mockito.any());
        //断言
        boolean result = dataTypeVoResultList.size() == 1 && dataTypeVoResultList.get(0).getCode().equals("110012");
        Assert.assertEquals(true, result);
    }

    /**
     * @return
     * @description 搜索
     * @author leakey.li
     * @date 2021/6/18
     * @time 4:26 下午
     */
    @Test
    public void getDataListBySearchGetModuleCodeArrayIsNull() throws Exception {
        //入参
        DataSearchParam param = new DataSearchParam();
        param.setDataTypeCode("112");
        param.setAccountId(110L);
        param.setModuleCode("100");
        param.setCurrent(1);
        param.setSize(1);
        param.setGroupId(2L);
        param.setName("用户中心");

        // 打桩
        Long parentGroupId = 1L;
        Mockito.when(dataAuthorizationDao.getParentGroupIdById(Mockito.anyLong())).thenReturn(parentGroupId);
        DataPage<DataSearchVo> pGroupDataPage = new DataPage<>();
        List<DataSearchVo> list = new ArrayList<>();
        DataSearchVo vo = new DataSearchVo();
        vo.setDataType("10");
        vo.setDataGroupCode("132");
        vo.setSelected(true);
        vo.setDataTypeCode("112");
        vo.setModuleCode("user");
        vo.setType(1);
        vo.setModuleName("用户管理");
        vo.setCode("110011");
        list.add(vo);
        DataSearchVo vo3 = new DataSearchVo();
        vo3.setDataType("40");
        vo3.setDataGroupCode("152");
        vo3.setSelected(true);
        vo3.setDataTypeCode("142");
        vo3.setModuleCode("dict");
        vo3.setType(1);
        vo3.setModuleName("字典管理");
        vo3.setCode("110015");
        vo3.setGroup("44433");
        list.add(vo3);
        pGroupDataPage.setList(list);
        List<DataTypeVo> dataTypeVoList = new ArrayList<>();
        DataTypeVo vo2 = new DataTypeVo();
        vo2.setCode("110012");
        vo2.setName("组织机构管理");
        vo2.setId(2L);
        dataTypeVoList.add(vo2);
        Mockito.when(dataAuthorizationDao.getDataGroupByCode(Mockito.any())).thenReturn(dataTypeVoList);

        //调用测试方法
        DataPage<DataSearchVo> pGroupDataPageResult = Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "getDataListBySearch", param);
        //校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getParentGroupIdById(Mockito.anyLong());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataGroupByCode(Mockito.any());
        //断言
        boolean result = pGroupDataPageResult.getList().size() > 0;
        Assert.assertEquals(true, result);
    }

    /**
     * @return
     * @description 搜索
     * @author leakey.li
     * @date 2021/6/18
     * @time 4:26 下午
     */
    @Test
    public void getDataListBySearchGetModuleCodeArrayIsNotNull() throws Exception {
        //入参
        DataSearchParam param = new DataSearchParam();
        param.setDataTypeCode("112");
        param.setAccountId(110L);
        param.setModuleCode("100");
        param.setCurrent(1);
        param.setSize(1);
        param.setGroupId(2L);
        param.setName("用户中心");
        param.setModuleCodeArray(new String[]{"232", "4333"});
        // 打桩
        Long parentGroupId = 1L;
        Mockito.when(dataAuthorizationDao.getParentGroupIdById(Mockito.anyLong())).thenReturn(parentGroupId);
        DataPage<DataSearchVo> pGroupDataPage = new DataPage<>();
        List<DataSearchVo> list = new ArrayList<>();
        DataSearchVo vo = new DataSearchVo();
        vo.setDataType("10");
        vo.setDataGroupCode("132");
        vo.setSelected(true);
        vo.setDataTypeCode("112");
        vo.setModuleCode("user");
        vo.setType(1);
        vo.setModuleName("用户管理");
        vo.setCode("110011");
        list.add(vo);
        DataSearchVo vo3 = new DataSearchVo();
        vo3.setDataType("40");
        vo3.setDataGroupCode("152");
        vo3.setSelected(true);
        vo3.setDataTypeCode("142");
        vo3.setModuleCode("dict");
        vo3.setType(1);
        vo3.setModuleName("字典管理");
        vo3.setCode("110015");
        vo3.setGroup("44433");
        list.add(vo3);
        pGroupDataPage.setList(list);
        List<DataTypeVo> dataTypeVoList = new ArrayList<>();
        DataTypeVo vo2 = new DataTypeVo();
        vo2.setCode("110012");
        vo2.setName("组织机构管理");
        vo2.setId(2L);
        dataTypeVoList.add(vo2);
        Mockito.when(dataAuthorizationDao.getDataGroupByCode(Mockito.any())).thenReturn(dataTypeVoList);

        //调用测试方法
        DataPage<DataSearchVo> pGroupDataPageResult = Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "getDataListBySearch", param);
        //校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getParentGroupIdById(Mockito.anyLong());
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataGroupByCode(Mockito.any());
        //断言
        boolean result = pGroupDataPageResult.getList().size() > 0;
        Assert.assertEquals(true, result);
    }

    /**
     * @return
     * @description 根据数据分组的level信息 查询数据分组的名字,拼接后复制到"所属分组"字段
     * @author leakey.li
     * @date 2021/6/18
     * @time 5:29 下午
     */
    @Test
    public void putGroupByLevel() throws Exception {
        // 入参
        DataPage<DataSearchVo> pGroupDataPage = new DataPage<>();
        List<DataSearchVo> list = new ArrayList<>();
        DataSearchVo vo = new DataSearchVo();
        vo.setDataType("10");
        vo.setDataGroupCode("132");
        vo.setSelected(true);
        vo.setDataTypeCode("112");
        vo.setModuleCode("user");
        vo.setType(1);
        vo.setModuleName("用户管理");
        vo.setCode("110011");
        list.add(vo);
        DataSearchVo vo3 = new DataSearchVo();
        vo3.setDataType("40");
        vo3.setDataGroupCode("152");
        vo3.setSelected(true);
        vo3.setDataTypeCode("142");
        vo3.setModuleCode("dict");
        vo3.setType(1);
        vo3.setModuleName("字典管理");
        vo3.setCode("110015");
        vo3.setGroup("44433");
        list.add(vo3);
        pGroupDataPage.setList(list);
        Map<String, Object> dataGroupParam = new HashMap<>();
        dataGroupParam.put("accountId", 110);
        dataGroupParam.put("groupId", 1L);

        // 打桩
        List<DataTypeVo> dataTypeVoList = new ArrayList<>();
        DataTypeVo vo2 = new DataTypeVo();
        vo2.setCode("110012");
        vo2.setName("组织机构管理");
        vo2.setId(2L);
        dataTypeVoList.add(vo2);
        Mockito.when(dataAuthorizationDao.getDataGroupByCode(Mockito.any())).thenReturn(dataTypeVoList);

        // 调用测试方法
        Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "putGroupByLevel", pGroupDataPage, dataGroupParam);
        // 校验
        Mockito.verify(this.dataAuthorizationDao, Mockito.atLeastOnce()).getDataGroupByCode(Mockito.any());

    }

    /**
     * @return
     * @description
     * @author leakey.li
     * @date 2021/6/18
     * @time 5:39 下午
     */
    @Test
    public void findDataNodes2Delete() throws Exception {
        //入参
        List<GroupDataNode> dataNodeList = new ArrayList<>();
        GroupDataNode groupDataNode = new GroupDataNode();
        groupDataNode.setAccountId(110L);
        groupDataNode.setModuleCode("100");
        groupDataNode.setNodeCode("123");
        groupDataNode.setDataTypeCode("1243");
        groupDataNode.setCode("3232");
        dataNodeList.add(groupDataNode);
        Set<String> nowNodeIdSet = new HashSet<>();
        nowNodeIdSet.add("123");

        //调用测试方法
        List<DataAndGroupRelationPo> dataAndGroupRelationPos = Whitebox.invokeMethod(this.dataAuthorizationServiceImpl,
                "findDataNodes2Delete", dataNodeList, nowNodeIdSet);

        //断言
        boolean result = dataAndGroupRelationPos.size() == 1 && dataAndGroupRelationPos.get(0).getModuleCode().equals("100");
        Assert.assertEquals(true, result);
    }

    private List<DataAndGroupRelationPo> getDataAndGroupRelationPos() {
        List<DataAndGroupRelationPo> dataRelations2Delete = new ArrayList<>();
        DataAndGroupRelationPo po = new DataAndGroupRelationPo();
        po.setAccountId(110L);
        po.setGroupId(2L);
        po.setType(4);
        po.setModuleCode("test");
        po.setDataTypeCode("233");
        dataRelations2Delete.add(po);
        return dataRelations2Delete;
    }

    private DataAuthUpdateParamFromSearchList getDataAuthUpdateParamFromSearchList() {
        DataAuthUpdateParamFromSearchList param = new DataAuthUpdateParamFromSearchList();
        param.setAccountId(110L);
        param.setCurrentUserId(2L);
        param.setGroupId(1L);
        List<DataAuthUpdateParamFromSearchList.DataNode> list = new ArrayList<>();
        DataAuthUpdateParamFromSearchList.DataNode node = new DataAuthUpdateParamFromSearchList.DataNode();
        node.setCode("10009");
        node.setDataTypeCode("10013");
        node.setDataGroupCode("10001");
        node.setModuleCode("weizhi-module");
        node.setSelected(true);
        list.add(node);
        DataAuthUpdateParamFromSearchList.DataNode node1 = new DataAuthUpdateParamFromSearchList.DataNode();
        node1.setCode("10008");
        node1.setDataTypeCode("10013");
        node1.setDataGroupCode("10002");
        node1.setModuleCode("weizhi-module1");
        node1.setSelected(false);
        list.add(node1);
        param.setList(list);
        return param;
    }

    private DataAuthUpdateParam getDataAuthUpdateParam(String modubleCode) {
        DataAuthUpdateParam param = new DataAuthUpdateParam();
        param.setAccountId(110L);
        param.setCurrentUserId(2L);
        param.setGroupId(1L);
        List<DataAuthUpdateParam.ModuleTypeNode> moduleTypeNodes = new ArrayList<>();
        DataAuthUpdateParam.ModuleTypeNode moduleTypeNode = new DataAuthUpdateParam.ModuleTypeNode();
        moduleTypeNode.setModuleCode(modubleCode);
        List<DataAuthUpdateParam.Node> nodes = Lists.newArrayList();
        DataAuthUpdateParam.Node node = new DataAuthUpdateParam.Node();
        node.setIncludeFuture(2);
        node.setType(1);
        nodes.add(node);
        DataAuthUpdateParam.Node node1 = new DataAuthUpdateParam.Node();
        node1.setDataTypeCode("dtc");
        node1.setIncludeFuture(2);
        node1.setType(2);
        nodes.add(node1);
        DataAuthUpdateParam.Node node2 = new DataAuthUpdateParam.Node();
        node2.setDataTypeCode("dtc");
        node2.setDataGroupCode("dgg");
        node2.setSelected(false);
        node2.setIncludeFuture(2);
        node2.setType(3);
        nodes.add(node2);
        DataAuthUpdateParam.Node node3 = new DataAuthUpdateParam.Node();
        node3.setDataTypeCode("dtc");
        node3.setDataGroupCode("dgg");
        node3.setDataCode("ddd");
        node3.setSelected(true);
        node3.setIncludeFuture(2);
        node3.setType(4);
        nodes.add(node3);
        DataAuthUpdateParam.Node node4 = new DataAuthUpdateParam.Node();
        node4.setDataTypeCode(Constant.DOUC_DATATYPECODE_GROUP);
        node4.setDataGroupCode(Constant.DOUC_DATACODE_GROUP_SPECIAL);
        node4.setDataCode("223");
        node4.setSelected(true);
        node4.setIncludeFuture(2);
        node4.setType(4);
        nodes.add(node4);
        DataAuthUpdateParam.Node node5 = new DataAuthUpdateParam.Node();
        node5.setDataTypeCode(Constant.DOUC_DATATYPECODE_DEPARTMENT);
        node5.setDataGroupCode(Constant.DOUC_DATACODE_DEPARTMENT_SPECIAL);
        node5.setDataCode("2253");
        node5.setSelected(true);
        node5.setIncludeFuture(2);
        node5.setType(4);
        nodes.add(node5);
        DataAuthUpdateParam.Node node6 = new DataAuthUpdateParam.Node();
        node6.setDataTypeCode(Constant.DOUC_DATATYPECODE_GROUP);
        node6.setDataGroupCode(Constant.DOUC_DATACODE_GROUP_SPECIAL);
        node6.setDataCode("2235");
        node6.setSelected(false);
        node6.setIncludeFuture(2);
        node6.setType(4);
        nodes.add(node6);
        DataAuthUpdateParam.Node node7 = new DataAuthUpdateParam.Node();
        node7.setDataTypeCode(Constant.DOUC_DATATYPECODE_DEPARTMENT);
        node7.setDataGroupCode(Constant.DOUC_DATACODE_DEPARTMENT_SPECIAL);
        node7.setDataCode("22453");
        node7.setSelected(false);
        node7.setIncludeFuture(2);
        node7.setType(4);
        nodes.add(node7);
        moduleTypeNode.setNodes(nodes);
        moduleTypeNodes.add(moduleTypeNode);
        param.setModuleTypeNodes(moduleTypeNodes);
        return param;
    }


}
