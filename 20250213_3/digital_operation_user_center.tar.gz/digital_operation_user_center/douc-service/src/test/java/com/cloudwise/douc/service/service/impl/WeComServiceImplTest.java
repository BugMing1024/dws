package com.cloudwise.douc.service.service.impl;

import cn.hutool.core.util.IdUtil;
import com.cloudwise.douc.commons.utils.ShortUUID;
import com.cloudwise.douc.service.model.identitysource.WeComIdentitySourceBaseInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.junit.Test;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class WeComServiceImplTest {

    @Test
    public void main1() {
        WeComIdentitySourceBaseInfo weComIdentitySourceBaseInfo = new WeComIdentitySourceBaseInfo();
        weComIdentitySourceBaseInfo.setCorpId("wwcb14e71da6281c47");
        weComIdentitySourceBaseInfo.setCorpSecret("fwii2KqdnYl0FbHC5_zWDtaBI-3-9nqatJ6WhfD90WM");
        weComIdentitySourceBaseInfo.setSyncNodeId("1");
        String token = ShortUUID.generate();
        String uuid = IdUtil.fastSimpleUUID();
        log.info("{}", token);
        log.info("{}", uuid.length());
        String s = Base64.encodeBase64String(IdUtil.fastSimpleUUID().getBytes()).substring(0, 43);
        log.info("{}", s);

    }

}