package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.enums.MultiAccountRoleTypeEnum;
import com.cloudwise.douc.commons.utils.BeanDeepCopyUtil;
import com.cloudwise.douc.metadata.activerecord.VisibleAccountDO;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserInfoDao;
import com.cloudwise.douc.metadata.model.department.Department;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserInfoDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserInfoDO;
import com.cloudwise.douc.service.dataflow.IAccountDataFlow;
import com.cloudwise.douc.service.dataflow.IUserDataFlow;
import com.cloudwise.douc.service.model.department.AccountNode;
import com.cloudwise.douc.service.model.multi.tenant.AccountAndUserInfo;
import com.cloudwise.douc.service.model.multi.tenant.AccountDTO;
import com.cloudwise.douc.service.model.multi.tenant.SubTenantInitInfoBo;
import com.cloudwise.douc.service.model.multi.tenant.TenantDefaultUserInfoVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantInitInfoVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantInitResultVo;
import com.cloudwise.douc.service.model.multi.tenant.TenantSystemAdministratorInfoBo;
import com.cloudwise.douc.service.model.multi.tenant.TenantUserSecretSm2Info;
import com.cloudwise.douc.service.util.Constant;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author brady.liu
 * @description {@link AccountServiceImpl} 单元测试
 * @date 2021/7/6
 * @time 11:31
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({AccountServiceImpl.class, BeanDeepCopyUtil.class})
@PowerMockIgnore({"javax.management.*"})
public class AccountServiceImplTest {

    @Mock
    private IAccountDao accountDao;
    @Mock
    private IMultiAccountUserInfoDao multiAccountUserInfoDaoImpl;
    @Mock
    private IMultiAccountUserDao multiAccountUserDaoImpl;
    @Mock
    private IAccountDataFlow accountDataFlow;
    @Mock
    private MultiAccountServiceImpl multiAccountServiceImpl;
    @Mock
    private UserServiceImpl userServiceImpl;
    @Mock
    private IUserDataFlow userDataFlow;
    @InjectMocks
    private AccountServiceImpl accountService;

    @Test
    public void getAccountsTest() throws Exception {
        List<AccountDetail> accountDetailLis = new ArrayList();
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);

        accountDetailLis.add(accountDetail);
        accountDetailLis.add(childAccountDetail);

        Map<String, Set<String>> userCountCache = new HashMap();
        Set treeSet = new TreeSet();
        treeSet.add("userCount");
        userCountCache.put("1", treeSet);
        userCountCache.put("2", treeSet);

        Mockito.when(this.accountService.getAccountDetailList(ArgumentMatchers.anyLong())).thenReturn(accountDetailLis);
        Mockito.when(this.accountDataFlow.getUserCountCache(ArgumentMatchers.anyLong())).thenReturn(userCountCache);
        // 待测试方法
        List<AccountNode> accounts = this.accountService.getAccounts(1L, 1L);
        Mockito.verify(this.accountService, Mockito.atLeastOnce()).getAccountDetailList(ArgumentMatchers.anyLong());
        Mockito.verify(this.accountDataFlow, Mockito.atLeastOnce()).getUserCountCache(ArgumentMatchers.anyLong());
        Boolean flag = CollectionUtils.isNotEmpty(accounts);
        Assert.assertEquals(true, flag);
    }

    @Test
    public void addAccount() throws Exception {
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);
        childAccountDetail.setCreateUserId(1L);
        MultiAccountUserDetail multiAccountUserDetail = new MultiAccountUserDetail();
        multiAccountUserDetail.setUserId(2L);
        multiAccountUserDetail.setStatus(1);
        multiAccountUserDetail.setId(4L);
        multiAccountUserDetail.setAccountId(1L);

        MultiAccountUserInfoDetail userInfoDetail = new MultiAccountUserInfoDetail();
        userInfoDetail.setTopAccountId(1L);
        userInfoDetail.setId(1L);
        userInfoDetail.setAdminType(1);

        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");
        userInfoDO.setEmail("admin@163.com");
        userInfoDO.setPassword("04d51ff5655d527c9685127a711ad6f8dc875e5ebed17d60a7ae819d6c773996622451cc0831a9012a2fe99bd2c3e6e154948b36fb4357315942185d053202f21798b1a966f4f8e32c4d7851d224e70984cba7d7686f1265eca313640e1884ae5482f0688a63439a68487641e4a9d727b128c57820682acd0ae69694ee2efa1bae4b03a5f126ad1f640759d20c659c5d273a66e31ad71276704823950dea7f7e9c6cd0a3e90e3ad35868ce5795d66e222b8334");
        TenantDefaultUserInfoVo tenantDefaultUserInfoVo = new TenantDefaultUserInfoVo();
        tenantDefaultUserInfoVo.setId(1L);
        tenantDefaultUserInfoVo.setUserDetail(multiAccountUserDetail);
        tenantDefaultUserInfoVo.setUserInfoDetail(userInfoDetail);
        TenantInitResultVo tenantInitResultVo = new TenantInitResultVo();
        TenantInitInfoVo tenantInfo = new TenantInitInfoVo();
        tenantInfo.setId(2L);

        tenantInitResultVo.setTenantInfo(tenantInfo);
        tenantInitResultVo.setDefaultUserInfo(tenantDefaultUserInfoVo);

        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setAccountDetail(childAccountDetail);
        accountDTO.setVisibleAccountId(Arrays.asList(1L, 2L));
        accountDTO.setUserInfoDO(userInfoDO);

        SubTenantInitInfoBo subTenantInitInfoBo = BeanDeepCopyUtil.copyProperties(childAccountDetail, SubTenantInitInfoBo.class);
        TenantSystemAdministratorInfoBo adminInfo = BeanDeepCopyUtil.copyProperties(userInfoDO, TenantSystemAdministratorInfoBo.class);
        adminInfo.setUserSecret(userInfoDO.getPassword());
        adminInfo.setUserName(userInfoDO.getName());

        Department department = new Department();
        department.setParentId(1L);
        department.setAccountId(1L);
        department.setId(1L);
        department.setLevel("0.1");
        tenantInitResultVo.setDepartment(department);


        //打桩
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);

        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(childAccountDetail);
        Mockito.when(this.accountService.getAccountDetailByAccountIdAndName(ArgumentMatchers.anyLong(), Mockito.anyString())).thenReturn(null);
        Mockito.doNothing().when(this.userServiceImpl).updateCachePerNum(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), Mockito.anyInt(), Mockito.anyInt());
        Mockito.doNothing().when(this.userDataFlow).addOrUpdateSingleUserBasedToCache(ArgumentMatchers.any());
        Mockito.doNothing().when(this.userDataFlow).deleteUsersCountByAccountId(ArgumentMatchers.anyLong());

        // doReturn Spies对象,才会走虚拟的方法
        Mockito.doReturn(tenantInitResultVo).when(multiAccountServiceImpl).multiTenantSubTenantInit(ArgumentMatchers.any());
        Whitebox.invokeMethod(accountService, "addAccount", accountDTO, 1L, 1L);

        Mockito.verify(this.accountService, Mockito.atLeastOnce()).getAccountDetailById(ArgumentMatchers.anyLong());
        Mockito.verify(this.accountService, Mockito.atLeastOnce()).getAccountDetailByAccountIdAndName(ArgumentMatchers.anyLong(), Mockito.anyString());

    }


    @Test
    public void updateAccountStatus() {
        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(childAccountDetail);

        this.accountService.updateAccountStatus(childAccountDetail, 1L, 1L);
        Mockito.verify(this.accountService, Mockito.atLeastOnce()).getAccountDetailById(ArgumentMatchers.anyLong());

    }

    //    getAccountInformation
    @Test
    public void getAccountInformation() throws Exception {

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);

        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");
        MultiAccountUserDetail multiAccountUserDetail = new MultiAccountUserDetail();
        multiAccountUserDetail.setUserId(2L);
        multiAccountUserDetail.setStatus(1);
        multiAccountUserDetail.setId(4L);
        //打桩
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        PowerMockito.doReturn(childAccountDetail).when(accountService, "getAccountDetail", ArgumentMatchers.anyLong());
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(childAccountDetail);
        PowerMockito.doReturn(multiAccountUserDetail).when(accountService, "getMultiAccountUserDetail", ArgumentMatchers.anyLong());
        Mockito.when(this.multiAccountUserDaoImpl.getUserDetail(ArgumentMatchers.anyLong())).thenReturn(multiAccountUserDetail);
        PowerMockito.doReturn(userInfoDO).when(accountService, "getUserInfoDO", ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());
        Mockito.when(this.multiAccountUserInfoDaoImpl.getTenantUserInfo(ArgumentMatchers.anyLong())).thenReturn(userInfoDO);

        Whitebox.invokeMethod(accountService, "getAccountInformation", childAccountDetail, 1L, 1L);

        PowerMockito.verifyPrivate(accountService, Mockito.atLeastOnce()).invoke("getUserInfoDO", ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());

    }


    //  updateAccount

    @Test
    public void updateAccount() throws Exception {
        AccountDTO accountDTO = new AccountDTO();
        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");
        userInfoDO.setEmail("admin@163.com");
        userInfoDO.setPassword("04d51ff5655d527c9685127a711ad6f8dc875e5ebed17d60a7ae819d6c773996622451cc0831a9012a2fe99bd2c3e6e154948b36fb4357315942185d053202f21798b1a966f4f8e32c4d7851d224e70984cba7d7686f1265eca313640e1884ae5482f0688a63439a68487641e4a9d727b128c57820682acd0ae69694ee2efa1bae4b03a5f126ad1f640759d20c659c5d273a66e31ad71276704823950dea7f7e9c6cd0a3e90e3ad35868ce5795d66e222b8334");


        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(3);

        accountDTO.setAccountDetail(childAccountDetail);
        accountDTO.setUserInfoDO(userInfoDO);
        accountDTO.setVisibleAccountId(Arrays.asList(1L, 2L));

        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(childAccountDetail);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);

        PowerMockito.doNothing().when(accountService, "checkParentChildAccountExchange", ArgumentMatchers.any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());

        PowerMockito.doNothing().when(accountService, "updateUserInfo", ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());
        PowerMockito.doNothing().when(accountService, "updateVisibleAccount", ArgumentMatchers.anyLong(), ArgumentMatchers.any(), Mockito.anyList());

        Whitebox.invokeMethod(accountService, "updateAccount", accountDTO, 1L, 1L);
        Mockito.verify(this.accountService, Mockito.atLeastOnce()).getAccountDetailById(ArgumentMatchers.anyLong());
    }


    //    authentication
    @Test
    public void authentication() throws Exception {

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setIsTop(Constant.MULTI_ACCOUNT_IS_TOP);
        Mockito.when(this.accountDataFlow.getAccountDetailByAccountId(ArgumentMatchers.anyLong())).thenReturn(accountDetail);
        Mockito.when(this.userServiceImpl.isSuperAdmin(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(true);
        this.accountService.authentication(1L, 1L);
    }

    /**
     * @description getUserInfo 接口测试
     * @author brady.liu
     * @date 2021/7/23
     * @time 10:18
     */
    @Test
    public void getUserInfo() {
        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");

        Mockito.when(this.multiAccountUserInfoDaoImpl.getTenantUserInfo(ArgumentMatchers.anyLong())).thenReturn(userInfoDO);
        UserInfoDO userInfo = this.accountService.getUserInfo(1L, 1L);
        Mockito.verify(this.multiAccountUserInfoDaoImpl, Mockito.atLeastOnce()).getTenantUserInfo(ArgumentMatchers.anyLong());
        boolean b = Objects.nonNull(userInfo);
        Assert.assertEquals(true, b);
    }

    /**
     * @description getAccountAndUserInfo接口测试
     * @author brady.liu
     * @date 2021/7/23
     * @time 10:17
     */
    @Test
    public void getAccountAndUserInfo() {
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setIsTop(Constant.MULTI_ACCOUNT_IS_TOP);
        Mockito.when(this.accountDataFlow.getAccountDetailByAccountId(ArgumentMatchers.anyLong())).thenReturn(accountDetail);
        Mockito.when(this.userServiceImpl.isSuperAdmin(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(true);
        AccountAndUserInfo accountAndUserInfo = this.accountService.getAccountAndUserInfo(1L, 1L);
        boolean b = Objects.nonNull(accountAndUserInfo);
        Assert.assertEquals(true, b);
        Assert.assertEquals(accountAndUserInfo.getIsTop(), Constant.MULTI_ACCOUNT_IS_TOP);
        Assert.assertEquals(accountAndUserInfo.getAdminType(), MultiAccountRoleTypeEnum.ADMIN.getCode());
    }

    @Test
    public void checkParentChildAccountExchange() throws Exception {

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(1);
        childAccountDetail.setTopId(null);
        childAccountDetail.setVisibleScope(1);

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(childAccountDetail);

        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        PowerMockito.doReturn(accountDetail).when(accountService, "getAccountDetail", ArgumentMatchers.anyLong());
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(childAccountDetail);
        Mockito.when(this.accountService.getAccountDetailByAccountIdAndName(ArgumentMatchers.anyLong(), Mockito.anyString())).thenReturn(null);

        PowerMockito.doNothing().when(accountService, "exchangeParentAccount", ArgumentMatchers.any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());

        //调用待测试方法
        Whitebox.invokeMethod(accountService, "checkParentChildAccountExchange", childAccountDetail, 1L, 1L);
        PowerMockito.verifyPrivate(accountService, Mockito.atLeastOnce()).invoke("getAccountDetail", ArgumentMatchers.anyLong());
        Mockito.verify(this.accountService).getAccountDetailById(ArgumentMatchers.anyLong());
        Mockito.verify(this.accountService).getAccountDetailByAccountIdAndName(ArgumentMatchers.anyLong(), Mockito.anyString());
        PowerMockito.verifyPrivate(accountService, Mockito.atLeastOnce()).invoke("exchangeParentAccount", ArgumentMatchers.any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());
    }


    @Test
    public void exchangeParentAccount() throws Exception {
        List<AccountDetail> accountDetailLis = new ArrayList();
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);


        PowerMockito.doNothing().when(accountService, "setSubAccountLevel", Mockito.anyList(), Mockito.anyMap(), ArgumentMatchers.any());

        Whitebox.invokeMethod(accountService, "exchangeParentAccount", childAccountDetail, 1L, 1L);


    }

    @Test
    public void setSubAccountLevel() throws Exception {
        List<AccountDetail> accountDetailLis = new ArrayList();
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);
        accountDetailLis.add(childAccountDetail);

        AccountDetail childAccountDetail2 = new AccountDetail();
        childAccountDetail2.setId(3L);
        childAccountDetail2.setParentId(1L);
        childAccountDetail2.setName("test13");
        childAccountDetail2.setLevel("0.1");
        childAccountDetail2.setStatus(1);
        childAccountDetail2.setIsTop(2);
        childAccountDetail2.setTopId(1L);
        childAccountDetail2.setVisibleScope(1);
        accountDetailLis.add(childAccountDetail2);

        Map<Long, AccountDetail> accountMap = new HashMap();

        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        PowerMockito.doNothing().when(accountService, "sortAccountLevel", Mockito.anyList(), Mockito.anyMap(), Mockito.anyMap(), ArgumentMatchers.any());
        PowerMockito.doNothing().when(accountService, "updateSubAccountLevel", Mockito.anyMap(), Mockito.anyMap(), ArgumentMatchers.any());
        Whitebox.invokeMethod(accountService, "setSubAccountLevel", accountDetailLis, accountMap, accountDetail);

        PowerMockito.verifyPrivate(accountService, Mockito.atLeastOnce()).invoke("sortAccountLevel", Mockito.anyList(), Mockito.anyMap(), Mockito.anyMap(), ArgumentMatchers.any());
        PowerMockito.verifyPrivate(accountService, Mockito.atLeastOnce()).invoke("updateSubAccountLevel", Mockito.anyMap(), Mockito.anyMap(), ArgumentMatchers.any());
    }

    @Test
    public void updateSubAccountLevel() throws Exception {
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);

        AccountDetail childAccountDetail2 = new AccountDetail();
        childAccountDetail2.setId(3L);
        childAccountDetail2.setParentId(1L);
        childAccountDetail2.setName("test13");
        childAccountDetail2.setLevel("0.1");
        childAccountDetail2.setStatus(1);
        childAccountDetail2.setIsTop(2);
        childAccountDetail2.setTopId(1L);
        childAccountDetail2.setVisibleScope(1);

        Map<Integer, Set<Long>> departmentSortMap = new HashMap();
        Set<Long> sortSet1 = new TreeSet();
        sortSet1.add(childAccountDetail.getId());
        sortSet1.add(childAccountDetail2.getId());
        departmentSortMap.put(1, sortSet1);

        Map<Long, AccountDetail> accountMap = new HashMap();
        accountMap.put(childAccountDetail.getId(), childAccountDetail);
        accountMap.put(childAccountDetail2.getId(), childAccountDetail2);

        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);

        Whitebox.invokeMethod(accountService, "updateSubAccountLevel", departmentSortMap, accountMap, accountDetail);
    }

    @Test
    public void sortAccountLevel() throws Exception {

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);

        AccountDetail childAccountDetail2 = new AccountDetail();
        childAccountDetail2.setId(3L);
        childAccountDetail2.setParentId(1L);
        childAccountDetail2.setName("test13");
        childAccountDetail2.setLevel("0.1");
        childAccountDetail2.setStatus(1);
        childAccountDetail2.setIsTop(2);
        childAccountDetail2.setTopId(1L);
        childAccountDetail2.setVisibleScope(1);
        List accountDetailList = new ArrayList();
        accountDetailList.add(childAccountDetail);
        accountDetailList.add(childAccountDetail2);

        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        Map<Long, AccountDetail> accountMap = new HashMap<>();
        Map<Integer, Set<Long>> departmentSortMap = new HashMap<>();
        Whitebox.invokeMethod(accountService, "sortAccountLevel", accountDetailList, accountMap, departmentSortMap, accountDetail);
        boolean b = Objects.nonNull(departmentSortMap);
        Assert.assertEquals(true, b);
    }

    //
    @Test
    public void updateUserInfo() throws Exception {

        AccountDetail childAccountDetail = new AccountDetail();
        childAccountDetail.setId(2L);
        childAccountDetail.setParentId(1L);
        childAccountDetail.setName("test12");
        childAccountDetail.setLevel("0.1");
        childAccountDetail.setStatus(1);
        childAccountDetail.setIsTop(2);
        childAccountDetail.setTopId(1L);
        childAccountDetail.setVisibleScope(1);

        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");
        userInfoDO.setPassword("043EEFB1B421F46831397367A6BC8BC7ED188543D3080353FF0EE81CD13C34A2900D008F0CC0CA40CA5E1C9A1C6C70100C9A0AC2876DB5E3B539AF18637460C7C25CEB75BB2B039F83520113DA4C2AEF58F244BC202EB371A9DA471E79668B92331E975DE1E94F15EFB36B76E6422C97B37227EE209AB2DB2273D7DDA5CB4ECF8A810225362F3814A46981B334A3015515D1C2D012ADBD319AD69455E0B8626B68A021BD45F31C357B978F8940D85DCF12FA8DCE");
        userInfoDO.setEmail("admin@163.com");

        TenantUserSecretSm2Info userSecret = new TenantUserSecretSm2Info();
        userSecret.setClearTextUserSecret("==defaultPWD==-");
        userSecret.setOriginUserSecret("043EEFB1B421F46831397367A6BC8BC7ED188543D3080353FF0EE81CD13C34A2900D008F0CC0CA40CA5E1C9A1C6C70100C9A0AC2876DB5E3B539AF18637460C7C25CEB75BB2B039F83520113DA4C2AEF58F244BC202EB371A9DA471E79668B92331E975DE1E94F15EFB36B76E6422C97B37227EE209AB2DB2273D7DDA5CB4ECF8A810225362F3814A46981B334A3015515D1C2D012ADBD319AD69455E0B8626B68A021BD45F31C357B978F8940D85DCF12FA8DCE");
        userSecret.setSmPasswordBpd("041AD2AC4850664EC582045E94DDD7E2E6442277D274CF4A3B16FA025516695A68015ACB1FFCE36287E358BFC8AB56F82FA6E378E5B2E472C4F32903714035680CBB4CE4C6B9F6EDE4678CDDC000FC27D20F5A24C1A59BFA247755DE28C5EA39AFFAE1B85AE7B4EFE45E577A1E86BEF93DA271427E453BAC97D497700E82E5AD81CC4A2EDB83A6CFDCB4DD068E970EE90D9FAA8F9EC86BDDEF47417EC0D210EABC");
        userSecret.setSmPasswordCpd("18aa29ea954e061a1ec532dc6285cad235ee3277aa28ec179a8d6ee15e64f5de");


        MultiAccountUserDetail multiAccountUserDetail = new MultiAccountUserDetail();
        multiAccountUserDetail.setUserId(2L);
        multiAccountUserDetail.setStatus(1);
        multiAccountUserDetail.setId(4L);

        Mockito.when(this.multiAccountUserInfoDaoImpl.getTenantUserInfo(ArgumentMatchers.anyLong())).thenReturn(userInfoDO);
        Mockito.when(this.multiAccountUserInfoDaoImpl.getUserIdsByNameOrEmail(ArgumentMatchers.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(null);


        Mockito.when(this.multiAccountServiceImpl.getUserSecret(Mockito.anyString(), Mockito.anyString())).thenReturn(userSecret);
        Mockito.when(this.multiAccountUserInfoDaoImpl.updateUserInfo(ArgumentMatchers.any())).thenReturn(1);

        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        // PowerMockito.Mockito.doNothing().Mockito.when(accountService, "updateUserInfo", childAccountDetail, userInfoDO, 1L, 1L);
        // PowerMockito.Mockito.doNothing().Mockito.when(accountService, "updateUserInfo", childAccountDetail, userInfoDO, 1L, 1L);
        Whitebox.invokeMethod(accountService, "updateUserInfo", childAccountDetail, userInfoDO, 1L, 1L);
        Mockito.verify(this.multiAccountUserInfoDaoImpl).getTenantUserInfo(ArgumentMatchers.anyLong());
        Mockito.verify(this.multiAccountUserInfoDaoImpl).getUserIdsByNameOrEmail(ArgumentMatchers.anyLong(), Mockito.anyString(), Mockito.anyString());
        Mockito.verify(this.multiAccountServiceImpl).getUserSecret(Mockito.anyString(), Mockito.anyString());
        Mockito.verify(this.multiAccountUserInfoDaoImpl).updateUserInfo(ArgumentMatchers.any());


    }


    /**
     * @description updateVisibleAccount 接口测试
     * @author brady.liu
     * @date 2021/7/23
     * @time 10:26
     */
    @Test
    public void updateVisibleAccountUpdate() throws Exception {
        List<VisibleAccountDO> visibleAccountDOList = new ArrayList();
        VisibleAccountDO visibleAccountDO = new VisibleAccountDO();
        visibleAccountDO.setId(1L);
        visibleAccountDO.setAccountId(2L);
        visibleAccountDO.setVisibleAccountId(3L);
        visibleAccountDOList.add(visibleAccountDO);
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(2L);
        accountDetail.setVisibleScope(3);

        List<Long> visibleAccountIds = new ArrayList();
        visibleAccountIds.add(3L);
        visibleAccountIds.add(4L);

        Mockito.when(this.accountDao.getVisibleAccountList(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.any())).thenReturn(visibleAccountDOList);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        Whitebox.invokeMethod(accountService, "updateVisibleAccount", 1L, accountDetail, visibleAccountIds);

        Mockito.verify(this.accountDao).getVisibleAccountList(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.any());
    }


    @Test
    public void updateVisibleAccountDelete() throws Exception {
        List<VisibleAccountDO> visibleAccountDOList = new ArrayList();
        VisibleAccountDO visibleAccountDO = new VisibleAccountDO();
        visibleAccountDO.setId(1L);
        visibleAccountDO.setAccountId(2L);
        visibleAccountDO.setVisibleAccountId(3L);
        visibleAccountDOList.add(visibleAccountDO);
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(2L);
        accountDetail.setVisibleScope(1);

        List<Long> visibleAccountIds = new ArrayList();
        visibleAccountIds.add(3L);
        visibleAccountIds.add(4L);

        Mockito.when(this.accountDao.getVisibleAccountList(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.any())).thenReturn(visibleAccountDOList);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        Whitebox.invokeMethod(accountService, "updateVisibleAccount", 1L, accountDetail, visibleAccountIds);

    }

    //    addMultiAccountUserDetail
    @Test
    public void addMultiAccountUserDetail() throws Exception {

        MultiAccountUserDetail accountUserDetail = new MultiAccountUserDetail();
        accountUserDetail.setAccountId(5L);
        accountUserDetail.setUserId(6L);
        accountUserDetail.setCreateTime(new Date());
        accountUserDetail.setCreateUserId(1L);
        accountUserDetail.setModifyTime(new Date());
        accountUserDetail.setModifyUserId(1L);
        accountUserDetail.setStatus(1);
        accountUserDetail.setOrigin(1);

        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");
        userInfoDO.setPassword("043EEFB1B421F46831397367A6BC8BC7ED188543D3080353FF0EE81CD13C34A2900D008F0CC0CA40CA5E1C9A1C6C70100C9A0AC2876DB5E3B539AF18637460C7C25CEB75BB2B039F83520113DA4C2AEF58F244BC202EB371A9DA471E79668B92331E975DE1E94F15EFB36B76E6422C97B37227EE209AB2DB2273D7DDA5CB4ECF8A810225362F3814A46981B334A3015515D1C2D012ADBD319AD69455E0B8626B68A021BD45F31C357B978F8940D85DCF12FA8DCE");
        userInfoDO.setEmail("admin@163.com");

        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);

        Mockito.when(this.multiAccountUserDaoImpl.getUserDetailByUserId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(null);
        Mockito.when(this.multiAccountUserDaoImpl.addUser(ArgumentMatchers.any())).thenReturn(1);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        Whitebox.invokeMethod(accountService, "addMultiAccountUserDetail", accountDetail, userInfoDO, 1L);
        Mockito.verify(this.multiAccountUserDaoImpl).addUser(ArgumentMatchers.any());

    }

    //            getAccountDetail
    @Test
    public void getAccountDetail() throws Exception {
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setId(1L);
        accountDetail.setParentId(null);
        accountDetail.setName("test1");
        accountDetail.setLevel("0");
        accountDetail.setStatus(1);
        accountDetail.setIsTop(1);
        accountDetail.setTopId(null);
        accountDetail.setVisibleScope(2);
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(accountDetail);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        AccountDetail getAccountDetail = Whitebox.invokeMethod(accountService, "getAccountDetail", 1L);
        Boolean flag = Objects.nonNull(getAccountDetail);
        Assert.assertEquals(true, flag);
    }

    //    getMultiAccountUserDetail
    @Test
    public void getMultiAccountUserDetail() throws Exception {

        MultiAccountUserDetail accountUserDetail = new MultiAccountUserDetail();
        accountUserDetail.setAccountId(5L);
        accountUserDetail.setUserId(6L);
        accountUserDetail.setCreateTime(new Date());
        accountUserDetail.setCreateUserId(1L);
        accountUserDetail.setModifyTime(new Date());
        accountUserDetail.setModifyUserId(1L);
        accountUserDetail.setStatus(1);
        accountUserDetail.setOrigin(1);

        Mockito.when(this.multiAccountUserDaoImpl.getUserDetail(ArgumentMatchers.anyLong())).thenReturn(accountUserDetail);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        MultiAccountUserDetail getUserDetail = Whitebox.invokeMethod(accountService, "getMultiAccountUserDetail", 1L);
        Boolean flag = Objects.nonNull(getUserDetail);
        Assert.assertEquals(true, flag);
    }


    @Test
    public void getUserInfoDO() throws Exception {
        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setName("test");
        userInfoDO.setId(3L);
        userInfoDO.setTopAccountId(1L);
        userInfoDO.setUserAlias("test");
        userInfoDO.setPassword("043EEFB1B421F46831397367A6BC8BC7ED188543D3080353FF0EE81CD13C34A2900D008F0CC0CA40CA5E1C9A1C6C70100C9A0AC2876DB5E3B539AF18637460C7C25CEB75BB2B039F83520113DA4C2AEF58F244BC202EB371A9DA471E79668B92331E975DE1E94F15EFB36B76E6422C97B37227EE209AB2DB2273D7DDA5CB4ECF8A810225362F3814A46981B334A3015515D1C2D012ADBD319AD69455E0B8626B68A021BD45F31C357B978F8940D85DCF12FA8DCE");
        userInfoDO.setEmail("admin@163.com");
        Mockito.when(this.multiAccountUserInfoDaoImpl.getTenantUserInfo(ArgumentMatchers.anyLong())).thenReturn(userInfoDO);
        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        UserInfoDO userInfo = Whitebox.invokeMethod(accountService, "getUserInfoDO", 1L, 1L);
        Boolean flag = Objects.nonNull(userInfo);
        Assert.assertEquals(true, flag);
    }


    //    getVisibleAccount
    @Test
    public void getVisibleAccount() throws Exception {

        List<VisibleAccountDO> visibleAccountDOList = new ArrayList();
        VisibleAccountDO visibleAccountDO = new VisibleAccountDO();
        visibleAccountDO.setId(1L);
        visibleAccountDO.setAccountId(2L);
        visibleAccountDO.setVisibleAccountId(3L);
        visibleAccountDOList.add(visibleAccountDO);

        AccountServiceImpl accountService = PowerMockito.spy(this.accountService);
        List<VisibleAccountDO> visibleAccounts = Whitebox.invokeMethod(accountService, "getVisibleAccount", 1L);
        Boolean flag = CollectionUtils.isNotEmpty(visibleAccounts);
        Assert.assertEquals(true, flag);
    }

    /**
     * @description getVisibleAccountInfoList 接口测试
     * @author brady.liu
     * @date 2021/7/20
     * @time 16:49
     */
    @Test
    public void getVisibleAccountInfoList() {

        List<AccountDetail> accountDetailList = new ArrayList();
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setName("test");
        accountDetail.setId(30L);
        accountDetail.setIsTop(2);
        accountDetailList.add(accountDetail);
        Mockito.when(this.accountDao.getVisibleAccountInfoList(ArgumentMatchers.anyLong())).thenReturn(accountDetailList);
        List<AccountDetail> visibleAccountInfoList = this.accountService.getVisibleAccountInfoList(30L, 1L);

        boolean notEmpty = CollectionUtils.isNotEmpty(visibleAccountInfoList);
        Assert.assertEquals(true, notEmpty);

    }

    /**
     * 测试获取顶级租户id方法
     *
     * @Param
     * @Return
     * @Auth bernie
     * @Date 5:11 PM 2021/9/3
     */
    @Test
    public void getTopAccountIdByAccountId() {
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setName("test");
        accountDetail.setId(30L);
        accountDetail.setIsTop(2);
        accountDetail.setTopId(110L);
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(accountDetail);
        Long topAccountId = this.accountService.getTopAccountIdByAccountId(30L);
        Assert.assertEquals(Long.valueOf("110"), topAccountId);
    }


}
