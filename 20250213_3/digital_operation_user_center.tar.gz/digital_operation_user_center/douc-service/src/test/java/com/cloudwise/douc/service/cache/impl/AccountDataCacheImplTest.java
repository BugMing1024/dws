package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.service.service.IAccountService;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import redis.embedded.RedisServer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author bradyliu
 * @description:
 * @date Created in 14:53 2021/7/22.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({AccountDataCacheImpl.class, RedisTools.class})
@PowerMockIgnore({"javax.management.*"})
public class AccountDataCacheImplTest {
    @Mock
    private IAccountDao accountDao;
    @Mock
    private IAccountService accountService;
    @InjectMocks
    private AccountDataCacheImpl accountDataCacheImpl;

    private static RedisServer redisServer;

    @BeforeAll
    static void startRedis() {
        redisServer = RedisServer.builder()
                .port(6379)
                .setting("maxmemory 128M") //maxheap 128M
                .build();

        redisServer.start();
    }

    /**
     * 析构方法之后执行，停止Redis.
     */
    @AfterAll
    static void stopRedis() {
        redisServer.stop();
    }

    /**
     * @description 初始化缓存
     * @author brady.liu
     * @date 2021/7/22
     * @time 15:57
     */
    @Test
    public void getAllTopAccountIdList() {
        List<Long> topAccountIdList = new ArrayList();
        topAccountIdList.add(1L);
        Mockito.when(this.accountService.getAllTopAccountIdList()).thenReturn(topAccountIdList);
        this.accountDataCacheImpl.loadAllUserCountCache();
        Mockito.verify(this.accountService).getAllTopAccountIdList();
    }

    /**
     * @description 测试添加指定用户缓存接口
     * @author brady.liu
     * @date 2021/7/22
     * @time 17:09
     */
    @Test
    public void setUserCountCacheIncrease() throws Exception {
        Set<String> hashSet = new HashSet();
        hashSet.add("1");
        hashSet.add("2");

        Map<String, Set<String>> userCountMap = new HashMap();
        userCountMap.put("1", hashSet);
        userCountMap.put("2", hashSet);

        Map<String, Set<String>> userCountMapReq = new HashMap();
        userCountMapReq.put("3", hashSet);

        AccountDataCacheImpl accountDataCacheImpl = PowerMockito.spy(this.accountDataCacheImpl);
        PowerMockito.doReturn(userCountMap).when(accountDataCacheImpl, "getUserCountCache", ArgumentMatchers.anyLong());
        Whitebox.invokeMethod(accountDataCacheImpl, "setUserCountCacheIncrease", 1L, userCountMapReq);
        PowerMockito.verifyPrivate(accountDataCacheImpl, Mockito.atLeastOnce()).invoke("getUserCountCache", ArgumentMatchers.anyLong());
    }

    /**
     * @description 测试删除指定用户缓存接口
     * @author brady.liu
     * @date 2021/7/22
     * @time 17:09
     */
    @Test
    public void setUserCountCacheDecrease() throws Exception {
        Set<String> hashSet = new HashSet();
        hashSet.add("1");
        hashSet.add("2");

        Map<String, Set<String>> userCountMap = new HashMap();
        userCountMap.put("1", hashSet);
        userCountMap.put("2", hashSet);

        Map<String, Set<String>> userCountMapReq = new HashMap();
        userCountMapReq.put("1", hashSet);

        AccountDataCacheImpl accountDataCacheImpl = PowerMockito.spy(this.accountDataCacheImpl);
        PowerMockito.doReturn(userCountMap).when(accountDataCacheImpl, "getUserCountCache", ArgumentMatchers.anyLong());
        Whitebox.invokeMethod(accountDataCacheImpl, "setUserCountCacheDecrease", 1L, userCountMapReq);
        PowerMockito.verifyPrivate(accountDataCacheImpl, Mockito.atLeastOnce()).invoke("getUserCountCache", ArgumentMatchers.anyLong());

    }


    /**
     * @description 测试初始化更新租户用户量到缓存中
     * @author brady.liu
     * @date 2021/7/22
     * @time 17:15
     */
    @Test
    public void setUserCountCache() throws Exception {
        List<UserCountDO> userIdAndUserLevelList = new ArrayList();
        UserCountDO userCountDO = new UserCountDO();
        userCountDO.setAccountId(1L);
        userCountDO.setLevel("0.1");
        userCountDO.setUserId(1L);
        UserCountDO userCountDO2 = new UserCountDO();
        userCountDO2.setAccountId(1L);
        userCountDO2.setLevel("0.1.2");
        userCountDO2.setUserId(2L);

        userIdAndUserLevelList.add(userCountDO);
        userIdAndUserLevelList.add(userCountDO2);

        AccountDataCacheImpl accountDataCacheImpl = PowerMockito.spy(this.accountDataCacheImpl);
        Mockito.when(this.accountDao.getUserIdAndUserLevelList(ArgumentMatchers.anyLong())).thenReturn(userIdAndUserLevelList);
        Whitebox.invokeMethod(accountDataCacheImpl, "setUserCountCache", 1L);
        Mockito.verify(this.accountDao, Mockito.atLeastOnce()).getUserIdAndUserLevelList(ArgumentMatchers.anyLong());
    }

    /**
     * @description 测试初始化
     * @author brady.liu
     * @date 2021/7/22
     * @time 17:13
     */
    @Test
    public void setUserCountCacheByTopAccountId() throws Exception {

        AccountDataCacheImpl accountDataCacheImpl = PowerMockito.spy(this.accountDataCacheImpl);
        PowerMockito.doNothing().when(accountDataCacheImpl, "setUserCountCache", ArgumentMatchers.anyLong());
        Whitebox.invokeMethod(accountDataCacheImpl, "setUserCountCacheByTopAccountId", 1L);
        PowerMockito.verifyPrivate(accountDataCacheImpl, Mockito.atLeastOnce()).invoke("setUserCountCache", ArgumentMatchers.anyLong());
    }
}
