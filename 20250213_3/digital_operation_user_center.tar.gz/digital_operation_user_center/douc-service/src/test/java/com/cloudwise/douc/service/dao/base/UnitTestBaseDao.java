package com.cloudwise.douc.service.dao.base;

import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.BeforeClass;
import org.mybatis.spring.SqlSessionTemplate;

import java.io.IOException;
import java.io.InputStream;

/**
 * dao层 父类,不使用spring容器版本
 *
 * @author maker.wang
 * @date 2021-06-28 11:04
 **/
@Slf4j
public class UnitTestBaseDao {

    private static final EmbeddedMysqlManager EMBEDDED_MYSQL_MANAGER = EmbeddedMysqlManager.getInstance();
    protected static SqlSessionTemplate sqlSession;

    static {
        try {
            /*
             * 初始化mybatis、sqlSession
             * @author maker.wang
             * @date 2021-06-28 11:07
             **/
            String resource = "mybatis/mybatis-config-ut.xml";
            InputStream inputStream = Resources.getResourceAsStream(resource);
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            sqlSession = new SqlSessionTemplate(sqlSessionFactory);
        } catch (IOException e) {
            log.error("Unit Test Init error,detail:", e.getMessage(), e);
        }
    }

    @BeforeClass
    public static void setup() {
        /*
         * 初始化内存数据库
         * @author maker.wang
         * @date 2021-06-28 11:06
         **/
        EMBEDDED_MYSQL_MANAGER.reloadSchema();
    }
}
