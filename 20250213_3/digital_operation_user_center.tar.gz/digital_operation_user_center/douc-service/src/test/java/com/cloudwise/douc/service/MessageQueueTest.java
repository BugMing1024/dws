package com.cloudwise.douc.service;

import com.cloudwise.douc.commons.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.consumer.store.OffsetSerializeWrapper;
import org.apache.rocketmq.common.message.MessageQueue;
import org.junit.Test;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author zafir.zhong
 * @description
 * @date Created in 18:25 2023/3/14.
 */
@Slf4j
public class MessageQueueTest {

    @Test
    public void main1() throws Exception {
        OffsetSerializeWrapper wrapper = new OffsetSerializeWrapper();
        ConcurrentHashMap<MessageQueue, AtomicLong> offsetTable = new ConcurrentHashMap<>();
        MessageQueue key = new MessageQueue();
        key.setTopic("TOPIC_CHANNEL_REAL_CONFIG_MODIFY");
        key.setBrokerName("broker-0");
        key.setQueueId(6);
        offsetTable.put(key, new AtomicLong(33));
        wrapper.setOffsetTable(offsetTable);
        HashMap<Object, Object> objectObjectHashMap = new HashMap<>();
        String s = JsonUtils.prettyEncode(wrapper);
        log.info("{}", s);
        OffsetSerializeWrapper decode = JsonUtils.decode(s, OffsetSerializeWrapper.class);
        log.info("{}", JsonUtils.encode(decode));
    }
}
