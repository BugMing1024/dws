package com.cloudwise.douc.service.model.logaudit;

import lombok.extern.slf4j.Slf4j;

/**
 * @author elsa.yang
 * @date 2020/6/11 3:10 下午
 */
@Slf4j
public class LogTypeMenuTest {

    public static void main(String[] args) {
        log.info("{}", "获得的结果是" + LogTypeMenu.getTypeId("operateLog"));
        LogTypeMenu.getTypeId("loginLog");
    }

}
