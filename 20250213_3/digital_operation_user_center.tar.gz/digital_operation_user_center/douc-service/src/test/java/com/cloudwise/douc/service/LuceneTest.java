package com.cloudwise.douc.service;

import com.cloudwise.douc.service.plugin.lucene.Pinyin4jUtils;
import org.junit.Assert;
import org.junit.Test;

import java.util.Set;

/**
 * 验证单元测试
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/12/13 16:01; update at 2023/12/13 16:01
 */
public class LuceneTest {
    
    @Test
    public void pinyin1(){
        Set<String> result = Pinyin4jUtils.mode("沈老师", true, true, 100);
        System.out.println(result);
        Assert.assertNotNull(result);
    }
    
    
}
