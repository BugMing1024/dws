package com.cloudwise.douc.service;

import cn.hutool.core.text.StrPool;
import com.cloudwise.cwop.security.RSAUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

/**
 * @author KenLiang
 * @description:
 * @date Created in 11:32 AM 2020/12/4.
 */
@Slf4j
public class ConfigListenerTest {
    
    public static void main(String[] args) throws Exception {
        String a = RSAUtils.encrypt("Nacos_654321");
        log.info(a);
        //log.info(RSAUtils.decrypt("WKYRAP+H8R+R0oelHpHwbdG4y5YcpRob6pM2jNt+rYU7/Ot72s09d2U/a/c8St1OzKwbHochzoSSyh/dJhHXcI2KgJiv9GM6es7HooYEsapvs9H20IipX6GPzvqYhVDdlBc88IC18zDClr9ymeQp58rtQb9fYSEXQT0O930wwLc="));
        //log.error("{}", RSAUtils.decrypt(URLDecoder.decode("bpMFp5ozqfg3T5/IjiJBNniHfoS2C7Knrdqy4v7GSP34yQj370VuJIZgyvCIDtPYyNMryuka4BFEZet0V41v6nKemBquM8dsWSO/KHgjCCsH1YYENQPMtpkbUJWog4HtRiIx1ef36IFOQM+DxMLr83VFiBfXew3E6DGmunTICDM=")));
    }
    
    @Test
    public void main1() throws Exception {
        String json = "{\n" +
                "\t\n" +
                "\t\"IntegratedType\":\"Web\",\n" +
                "\t\"ProductModule\":\"112\",\n" +
                "\t\"ChannelName\":\"maker-wecom\",\n" +
                "\t\"EnterpriseId\":\"wwb703c0d99152d4f4\",\n" +
                "\t\"AgentId\":\"1000004\",\n" +
                "\t\"Secret\":\"0XHqJK3n0cm9L8-5Me8dYIff6joEO5zWqxpNuvc4xfQ\",\n" +
                "\t\"AssociateSourceAttribute\":\"mobile\",\n" +
                "\t\"AssociateUserAttribute\":\"mobile\"\n" +
                StrPool.C_DELIM_END;
        log.error("json:{}", com.cloudwise.douc.commons.utils.JsonUtils.encode(json));

        String a = RSAUtils.encrypt("yunzhihui123");
        log.info("{}", a);
        //log.error("解密：{}", RSAUtils.decrypt(URLDecoder.decode("CdO5gb+X09o0tJ6r0XjzuZgB4KaVBXQTziuIZ4Kdn+VQWsrNwcwN/+JCnm1MH386UG/ockpwmIoaK1TMLHGyEfjqDsC0vN7GA+m344Of3AYBncKmeWbfjsIHmY9pocBwsqZms17mcqon80MWUoRjlgn0OsrWpciRwxTe3wSeCcc=")));

        String secondLevelDomain = "cloud.cloudwise-douc.com";
        //log.error("{}", SpecialCharUtil.replaceSpecialChar(secondLevelDomain));
        log.info("{}", 1638113771000L - (180L * 24 * 60 * 60 * 1000));
    }
}