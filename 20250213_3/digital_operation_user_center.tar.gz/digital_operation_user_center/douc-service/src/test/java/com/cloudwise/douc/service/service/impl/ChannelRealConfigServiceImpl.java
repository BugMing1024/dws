package com.cloudwise.douc.service.service.impl;


import com.cloudwise.douc.service.service.ChannelRealConfigService;
import lombok.extern.slf4j.Slf4j;

import java.net.URLDecoder;

/**
 * 渠道实际配置表 {@link ChannelRealConfigService}的实际实现
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2022-05-05 11:27:36; update at 2022-05-05 11:27:36
 */
@Slf4j
public class ChannelRealConfigServiceImpl {

    public static void main(String[] args) {
        URLDecoder.decode("fZY%2FqgrXdGZR1BwPnkzJYA9BKsPPdS8L41gUt3MvggTFJfpqtRVy12kVw4MxAmf7VxgQJKzY4gkGqOxPBPeRf3%2Big5H4vaGI3CiAamXoBzvwNBOzL67BdyqiwC%2FKIek1pcRV%2BLi6wh5dZTHnEzBmyIBUJ8Bdv1dXBIPu4frkxN4%3D");
    }

}