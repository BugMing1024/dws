package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.metadata.mapper.IDepartmentV2Dao;
import com.cloudwise.douc.metadata.mapper.IDicDataDao;
import com.cloudwise.douc.metadata.model.department.Department;
import org.apache.ibatis.io.Resources;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * 数据资源
 *
 * @author bruce.liu
 * @description:
 * @date Created in 6:33 下午 2021/6/11.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({DepartmentV2ServiceImpl.class})
@PowerMockIgnore({"javax.management.*"})
public class DepartmentV2ServiceImplTest {

    @InjectMocks
    DepartmentV2ServiceImpl departmentV2Service;

    @Mock
    IDicDataDao dicDataDao;

    @Mock
    IDepartmentV2Dao departmentV2Dao;

    @Test
    public void uploadByExcel() throws Exception {
        String resource = "excel/departmentInfoTemplate.xlsx";
        File file = Resources.getResourceAsFile(resource);
        FileInputStream fileInputStream = new FileInputStream(file);
        //打桩
        List<String> typeInDB = new ArrayList<>();
        typeInDB.add("中心");
        typeInDB.add("部门");
        typeInDB.add("处室");
        typeInDB.add("小组");
        typeInDB.add("分公司");
        Mockito.when(dicDataDao.getMenuByType(Collections.singletonList("orgtype"), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);

        Department department = new Department();
        department.setCode("110118");
        department.setModifyUserId(2);
        department.setCreateUserId(2);
        department.setModifyTime(new Date());
        department.setCreateTime(new Date());
        department.setName("testName");
        department.setStatus(1);
        department.setAccountId(Long.valueOf(110));
        department.setLevel("0");
        department.setSequence(1);
        department.setId(1L);
        department.setParentId(1L);
        List<Department> departmentList = new ArrayList<>();
        departmentList.add(department);
        Mockito.when(departmentV2Dao.getDepartmentCodeInfo(ArgumentMatchers.any())).thenReturn(departmentList);

        Department department1 = new Department();
        department.setCode("110118");
        department.setName("顶级组织");
        List<Department> departmentList1 = new ArrayList<>();
        departmentList1.add(department1);
        Mockito.when(departmentV2Dao.getParentCodeAndName(ArgumentMatchers.any())).thenReturn(departmentList1);

        Mockito.when(departmentV2Dao.insertBatchDepartment(ArgumentMatchers.any())).thenReturn(1);

        Mockito.when(departmentV2Dao.updateDepartment(ArgumentMatchers.any())).thenReturn(1);

        //方法
        departmentV2Service.uploadByExcel("departmentInfoTemplate.xlsx", fileInputStream, 110L, 2L, 110L);

        Mockito.verify(this.departmentV2Dao, Mockito.atLeastOnce()).getDepartmentCodeInfo(ArgumentMatchers.any());
        Mockito.verify(this.departmentV2Dao, Mockito.atLeastOnce()).getParentCodeAndName(ArgumentMatchers.any());
        Mockito.verify(this.departmentV2Dao, Mockito.atLeastOnce()).insertBatchDepartment(ArgumentMatchers.any());
        Mockito.verify(this.departmentV2Dao, Mockito.atLeastOnce()).updateDepartment(ArgumentMatchers.any());
    }


}
