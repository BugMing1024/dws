package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.metadata.mapper.IMenuDao;
import com.cloudwise.douc.metadata.mapper.IModuleDao;
import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import com.cloudwise.douc.metadata.model.menu.Menu;
import com.cloudwise.douc.metadata.model.menu.Module;
import com.cloudwise.douc.service.cache.IMenuResourceCache;
import com.cloudwise.douc.service.model.auth.MenuAuthRequest;
import com.cloudwise.douc.service.model.auth.MenuAuthResponse;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author leakey.li
 * @description: 菜单资源鉴权 单元测试
 * @date Created in 10:29 上午 2021/5/28.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthServiceImpl.class})
@PowerMockIgnore({"javax.management.*"})
public class AuthServiceImplTest {
    @Mock
    private IModuleDao moduleDao;

    @Mock
    private IMenuDao menuDao;

    @Mock
    private IMenuResourceCache menuResourceCache;
    @InjectMocks
    private AuthServiceImpl authService;

    /**
     * @return void
     * @descrition 菜单资源鉴权 test
     * @auhor leakey.li
     * @date 2021/5/28
     * @time 10:45 上午
     */
    @Test
    public void getMenuAuthInfo() throws Exception {
        //入参
        MenuAuthRequest menuAuthRequest = new MenuAuthRequest();
        menuAuthRequest.setAccountId(110L);
        menuAuthRequest.setModuleCode("100");
        menuAuthRequest.setUserId(2L);
        boolean isAllType = false;
        //打桩返回值
        Module module = new Module();
        module.setEnName("User Administration");
        module.setName("用户中心");
        module.setCode("100");

        //打桩
        AuthServiceImpl privateMethod = PowerMockito.spy(this.authService);
        //打桩
        Mockito.when(this.moduleDao.getModuleInfo(Mockito.any())).thenReturn(module);
        Mockito.when(this.menuResourceCache.getMenuAuthFromCache(Mockito.any())).thenReturn(null);

        List<MenuResponse> menus = new ArrayList<>();
        MenuResponse menuResponse = new MenuResponse();
        menuResponse.setCode("1011000101");
        menuResponse.setName("组织机构管理");
        menuResponse.setModuleCode("100");
        menuResponse.setAuthId("system:desensitization:dept");
        menus.add(menuResponse);
        Set<String> interfaceAuthIds = new HashSet<>();
        interfaceAuthIds.add("123");
        MenuAuthResponse menuAuthResponse = new MenuAuthResponse("100", "用户中心", menus, interfaceAuthIds);
        PowerMockito.doReturn(menuAuthResponse).when(privateMethod, "getMenuAuthFromDB", Mockito.any(), Mockito.anyBoolean(), Mockito.any());
        Mockito.doNothing().when(this.menuResourceCache).setMenuBasedAccountIdUserIdModuleCodeToCache(Mockito.any(), Mockito.any());
        //调用待测试方法
        MenuAuthResponse menuAuthResponse2 = Whitebox.invokeMethod(privateMethod,
                "getMenuAuthInfo", menuAuthRequest, isAllType);
        //验证
        Mockito.verify(this.moduleDao, Mockito.atLeastOnce()).getModuleInfo(Mockito.any());
        Mockito.verify(this.menuResourceCache, Mockito.atLeastOnce()).getMenuAuthFromCache(Mockito.any());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("getMenuAuthFromDB", Mockito.any(), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(this.menuResourceCache, Mockito.atLeastOnce()).setMenuBasedAccountIdUserIdModuleCodeToCache(Mockito.any(), Mockito.any());
        //断言
        boolean moduleResult = menuAuthResponse2 != null && menuAuthResponse2.getModuleCode().equals("100");
        Assert.assertTrue(moduleResult);

    }

    /**
     * @return void
     * @descrition 菜单资源鉴权 test
     * @auhor leakey.li
     * @date 2021/5/28
     * @time 10:45 上午
     */
    @Test
    public void getMenuAuthInfoGetModuleInfo() throws Exception {
        //入参
        MenuAuthRequest menuAuthRequest = new MenuAuthRequest();
        menuAuthRequest.setAccountId(110L);
        menuAuthRequest.setModuleCode("110");
        menuAuthRequest.setUserId(2L);
        //打桩返回值
        Module module = new Module();
        module.setEnName("User Administration");
        module.setName("用户中心");
        module.setCode("110");

        //打桩
        Mockito.when(this.moduleDao.getModuleInfo(new Module(menuAuthRequest.getModuleCode(), menuAuthRequest.getAccountId(), "", true))).thenReturn(module);

        //调用待测试方法
        Module module2 = Whitebox.invokeMethod(this.authService,
                "getModuleInfo", menuAuthRequest);
        //验证
        Mockito.verify(this.moduleDao, Mockito.atLeastOnce()).getModuleInfo(Mockito.any());
        //断言
        boolean moduleResult = module2 == null ? false : true;
        Assert.assertEquals(true, moduleResult);

    }

    /**
     * @param
     * @return
     * @dscription 获取管理员角色用户的功能权限
     * @author leakey.li
     * @date 2021/5/31
     * @time 11:10 上午
     */
    @Test
    public void getMenuAuthInfoGetSystemRoleMenuAuthFromDB() throws Exception {
        //入参
        Module module = getModule("100");
        boolean isAllType = true;
        //打桩返回值
        List<Menu> menus = Lists.newArrayList();
        Menu menu = new Menu();
        menu.setCode("1011000101");
        menu.setName("组织机构管理");
        menu.setModuleCode("100");
        menu.setSelected(true);
        menu.setAuthId("system:desensitization:dept");
        menus.add(menu);

        //返回

        //打桩
        if (isAllType) {
            Mockito.when(this.menuDao.getMenusByModuleCode(Mockito.any(Module.class))).thenReturn(menus);
        } else {
            Mockito.when(this.menuDao.getMenusByModuleCodeInMenuType(Mockito.any(Module.class))).thenReturn(menus);
        }

        //调用待测试方法
        MenuAuthResponse menuResponse = Whitebox.invokeMethod(this.authService,
                "getSystemRoleMenuAuthFromDB", module, isAllType);
        //验证
        if (isAllType) {
            Mockito.verify(this.menuDao, Mockito.atLeastOnce()).getMenusByModuleCode(Mockito.any());
        } else {
            Mockito.verify(this.menuDao, Mockito.atLeastOnce()).getMenusByModuleCodeInMenuType(Mockito.any());
        }
        //断言
        Assert.assertEquals(true, "100".equals(menuResponse.getModuleCode()) && menuResponse.getMenus().get(0).getCode().equals("1011000101"));
    }

    /**
     * @param
     * @return
     * @dscription 提取菜单中的接口权限标示到set
     * @author leakey.li
     * @date 2021/5/31
     * @time 2:25 下午
     */
    @Test
    public void getMenuAuthInfoExtractInterfaceAuthIdsToSet() throws Exception {
        //入参
        List<MenuResponse> menuList = Lists.newArrayList();
        MenuResponse menuResponse = new MenuResponse("1011000101", "110", "组织机构管理", "", 1, "2", "");
        MenuResponse menuResponse2 = new MenuResponse("1011000102", "110", "用户管理", "", 1, "2", "");
        menuList.add(menuResponse);
        menuList.add(menuResponse2);
        //打桩

        //调用待测试方法
        Set<String> interfaceAuthIds = Whitebox.invokeMethod(this.authService,
                "extractInterfaceAuthIdsToSet", menuList);
        //验证

        //断言
        Assert.assertEquals(true, interfaceAuthIds.size() > 0);
    }


    /**
     * @param
     * @return
     * @dscription 获取菜单通过moduleCode
     * @author leakey.li
     * @date 2021/5/31
     * @time 11:10 上午
     */
    @Test
    public void getMenuAuthInfoGetMenusByModuleCode() throws Exception {
        //入参
        Module module = getModule("110");
        Boolean isTypeAll = false;

        //打桩返回值
        List<Menu> menus = Lists.newArrayList();
        Menu menu = new Menu();
        menu.setCode("1011000101");
        menu.setName("组织机构管理");
        menu.setSelected(true);
        menus.add(menu);
        //打桩
        if (isTypeAll) {
            Mockito.when(this.menuDao.getMenusByModuleCode(Mockito.any(Module.class))).thenReturn(menus);
        } else {
            Mockito.when(this.menuDao.getMenusByModuleCodeInMenuType(Mockito.any(Module.class))).thenReturn(menus);
        }

        //调用待测试方法
        List<Menu> menuList = Whitebox.invokeMethod(this.authService,
                "getMenusByModuleCode", module, isTypeAll);
        //验证
        if (isTypeAll) {
            Mockito.verify(this.menuDao, Mockito.atLeastOnce()).getMenusByModuleCode(Mockito.any());
        } else {
            Mockito.verify(this.menuDao, Mockito.atLeastOnce()).getMenusByModuleCodeInMenuType(Mockito.any());
        }
        //断言
        boolean isResult = CollectionUtils.isNotEmpty(menuList) ? true : false;
        Assert.assertEquals(true, isResult);
    }


    /**
     * @param
     * @return 这个方法已经测各个方法不写总的了
     * @dscription 从数据库中查询菜单权限
     * @author leakey.li
     * @date 2021/5/31
     * @time 9:56 上午
     */
    @Test
    public void getMenuAuthInfoGetMenuAuthFromDB() throws Exception {
        //调用待测试方法


        //验证

        //断言
    }

    /**
     * 测试获取普通角色用户的功能权限
     *
     * @return null
     * @decription a
     * @Param: null
     * @author leakey.li
     * @date 2021/6/3
     * @time 2:55 下午
     */
    @Test
    public void getMenuAuthInfoGetCustomRoleMenuAuthFromDB() throws Exception {
        //入参
        Module module = getModule("112");
        MenuAuthRequest menuAuthRequest = getMenuAuthRequest();
        boolean isAllType = true;

        List<MenuResponse> menuResponseList = new ArrayList<>();
        MenuResponse menuResponse = new MenuResponse();
        menuResponse.setCode("dosm_message_center");
        menuResponse.setName("消息中心");
        menuResponse.setModuleCode("112");
        MenuResponse menuResponse2 = new MenuResponse();
        menuResponse2.setCode("dosm_order_check");
        menuResponse2.setParentCode("dosm_all_work_order");
        menuResponse2.setName("查看工单");
        menuResponse2.setModuleCode("112");
        MenuResponse menuResponse3 = new MenuResponse();
        menuResponse3.setCode("dosm_all_work_order");
        menuResponse3.setName("所有工单");
        menuResponse3.setModuleCode("112");
        menuResponseList.add(menuResponse);
        menuResponseList.add(menuResponse2);
        menuResponseList.add(menuResponse3);
        //打桩
        if (isAllType) {
            Mockito.when(menuDao.getMenuByModuleCodeInAllType(Mockito.any())).thenReturn(menuResponseList);
        } else {
            Mockito.when(menuDao.getMenuByModuleMenuCode(Mockito.any())).thenReturn(menuResponseList);
        }

        //调用待测试方法
        MenuAuthResponse menuAuthResponse = Whitebox.invokeMethod(this.authService,
                "getCustomRoleMenuAuthFromDB", module, isAllType, menuAuthRequest);
        //验证
        if (isAllType) {
            Mockito.verify(this.menuDao, Mockito.atLeastOnce()).getMenuByModuleCodeInAllType(Mockito.any());
        } else {
            Mockito.verify(this.menuDao, Mockito.atLeastOnce()).getMenuByModuleMenuCode(Mockito.any());
        }
        //断言
        String moduleCode = menuAuthResponse.getModuleCode();
        boolean isResult = (moduleCode.equals("112") && menuAuthResponse.getMenus().size() > 0) ? true : false;
        Assert.assertEquals(true, isResult);

    }


    /**
     * @dscription 用户中心菜单资源鉴权
     * @author leakey.li
     * @date 2021/6/10
     * @time 5:42 下午
     */
    @Test
    public void getDOUCMenuAuthInfo() throws Exception {
        //入参
        Long accountId = 110L;
        Long userId = 2L;
        List<MenuResponse> menus = new ArrayList<>();
        menus.add(new MenuResponse("1011000101", "100"));
        menus.add(new MenuResponse("1011000102", "100"));

        //私有方法打桩
        AuthServiceImpl privateMethod = PowerMockito.spy(this.authService);
        PowerMockito.doReturn(menus).when(privateMethod, "getDOUCPlatMenuAuthInfo", Mockito.anyLong(), Mockito.anyLong());

        //DAO打桩
        List<Menu> allMenus = new ArrayList<>();
        Menu menu1 = new Menu("1011000101", "100");
        Menu menu2 = new Menu("1011000102", "100");
        Menu menu3 = new Menu("1011000103", "100");
        allMenus.add(menu1);
        allMenus.add(menu2);
        allMenus.add(menu3);
        Mockito.when(menuDao.getMenusByModuleCodeAndAccountId(Mockito.any())).thenReturn(allMenus);

        //调用待测试方法
        List<Menu> menuList = privateMethod.getDOUCMenuAuthInfo(accountId, userId, null);

        //验证
        Menu menuExp = new Menu();
        menuExp.setAccountId(accountId);
        menuExp.setModuleCode(Constant.DOUC_MODULE_CODE);
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("getDOUCPlatMenuAuthInfo", Mockito.anyLong(), Mockito.anyLong());
        Mockito.verify(menuDao).getMenusByModuleCodeAndAccountId(menuExp);

        //断言
        Assert.assertEquals(true, menuList != null && menuList.size() == 3);
    }

    /**
     * @decription 获取douc菜单，有缓存的未写
     * author leakey.li
     * @date 2021/6/11
     * @time 5:58 下午
     */
    @Test
    public void getDOUCMenuAuthInfoGetDOUCPlatMenuAuthInfo() throws Exception {
        //入参
        Long accountId = 110L;
        Long userId = 2L;

        //打桩
        List<MenuResponse> menus = new ArrayList<>();
        MenuResponse menuResponse = new MenuResponse();
        menuResponse.setCode("1011000101");
        menuResponse.setName("组织机构管理");
        menuResponse.setModuleCode("100");
        menuResponse.setAuthId("system:desensitization:dept");
        menus.add(menuResponse);
        Set<String> interfaceAuthIds = new HashSet<>();
        interfaceAuthIds.add("123");
        MenuAuthResponse menuAuthResponse = new MenuAuthResponse("100", "用户中心", menus, interfaceAuthIds);
        AuthServiceImpl privateMethod = PowerMockito.spy(this.authService);
        PowerMockito.doReturn(menuAuthResponse).when(privateMethod, "getMenuAuthInfo", Mockito.any(), Mockito.anyBoolean());

        //调用测试方法
        List<MenuResponse> menusResult = Whitebox.invokeMethod(privateMethod,
                "getDOUCPlatMenuAuthInfo", accountId, userId);

        //校验
        Mockito.verify(privateMethod, Mockito.atLeastOnce()).getMenuAuthInfo(Mockito.any());

        Assert.assertEquals(true, menusResult != null && menusResult.size() > 0);

    }

    /**
     * @decription 判断是否有douc菜单权限
     * author leakey.li
     * @date 2021/6/11
     * @time 5:58 下午
     */
    @Test
    public void ifAuthedTheDOUCMenu() throws Exception {
        //入参
        String menuCode = "1011000101";
        Long accountId = 110L;
        Long userId = 2L;
        //打桩
        List<MenuResponse> menus = new ArrayList<>();
        menus.add(new MenuResponse("1011000101", "100"));
        menus.add(new MenuResponse("1011000102", "100"));
        AuthServiceImpl privateMethod = PowerMockito.spy(this.authService);
        PowerMockito.doReturn(menus).when(privateMethod, "getDOUCPlatMenuAuthInfo", Mockito.anyLong(), Mockito.anyLong());

        //调用测试方法
        boolean result = privateMethod.ifAuthedTheDOUCMenu(menuCode, accountId, userId);
        //验证
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("getDOUCPlatMenuAuthInfo", Mockito.anyLong(), Mockito.anyLong());
        //断言
        Assert.assertEquals(true, result);
    }


    private Module getModule(String code) {
        Module module = new Module();
        module.setCode(code);
        return module;
    }

    private MenuAuthRequest getMenuAuthRequest() {
        MenuAuthRequest menuAuthRequest = new MenuAuthRequest();
        menuAuthRequest.setAccountId(110L);
        menuAuthRequest.setUserId(2L);
        menuAuthRequest.setModuleCode("112");
        return menuAuthRequest;
    }


}
