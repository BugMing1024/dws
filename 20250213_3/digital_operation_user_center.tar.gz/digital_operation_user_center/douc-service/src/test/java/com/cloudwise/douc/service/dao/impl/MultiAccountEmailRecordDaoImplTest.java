package com.cloudwise.douc.service.dao.impl;

import cn.hutool.core.date.DatePattern;
import com.cloudwise.douc.metadata.mapper.IMultiAccountEmailRecordDao;
import com.cloudwise.douc.metadata.model.multi.email.SysEmailRecord;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Test;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.Date;

/**
 * 邀请记录表UT
 *
 * @author maker.wang
 * @date 2021-07-17 11:07
 **/
public class MultiAccountEmailRecordDaoImplTest extends UnitTestBaseDao {

    @Resource
    private IMultiAccountEmailRecordDao multiAccountEmailRecordDao;

    @Test
    public void addEmailRecord() {
        SysEmailRecord emailRecord = new SysEmailRecord();
        emailRecord.setTitle("邀请");
        emailRecord.setContent("到军部");
        emailRecord.setSendUserId(1L);
        emailRecord.setStatus(1);
        emailRecord.setSendEmail("cloudwise_douc@163.com");
        emailRecord.setReceiveEmail("xyw1005@126.com");
        emailRecord.setAccountId(9999L);
        emailRecord.setCreateUserId(1L);
        int i = multiAccountEmailRecordDao.addEmailRecord(emailRecord);
        Assert.assertEquals(1, i);
    }

    @Test
    public void deleteExpireEmailRecord() throws ParseException {
        SysEmailRecord emailRecord = new SysEmailRecord();
        emailRecord.setTitle("邀请");
        emailRecord.setContent("到军部");
        emailRecord.setSendUserId(1L);
        emailRecord.setStatus(1);
        emailRecord.setSendEmail("cloudwise_douc@163.com");
        emailRecord.setReceiveEmail("xyw1005@126.com");
        emailRecord.setAccountId(9999L);
        emailRecord.setCreateUserId(1L);
        int i = multiAccountEmailRecordDao.addEmailRecord(emailRecord);
        Assert.assertEquals(1, i);
        sqlSession.commit();

        Date deadline = DateUtils.parseDate("3000-07-17 11:22:12", DatePattern.NORM_DATETIME_PATTERN);
        Integer result = multiAccountEmailRecordDao.deleteExpireEmailRecord(deadline);
        Assert.assertEquals(true, result >= 1);
    }
}