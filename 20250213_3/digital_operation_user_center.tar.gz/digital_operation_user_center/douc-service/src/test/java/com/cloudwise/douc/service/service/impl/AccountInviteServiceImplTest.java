package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.commons.model.DataPage;
import com.cloudwise.douc.commons.utils.BeanDeepCopyUtil;
import com.cloudwise.douc.commons.utils.ShortUUID;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.mapper.IAccountInviteDao;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IDicDataDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserInfoDao;
import com.cloudwise.douc.metadata.model.department.DepartmentResponseObject;
import com.cloudwise.douc.metadata.model.dicdata.DicDataPo;
import com.cloudwise.douc.metadata.model.dicdata.DicTypePo;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountInviteDO;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.metadata.model.multi.tenant.UserInfoDO;
import com.cloudwise.douc.metadata.model.user.User;
import com.cloudwise.douc.service.event.BasicMsgEvent;
import com.cloudwise.douc.service.model.multi.UserInviteVerifyDTO;
import com.cloudwise.douc.service.model.multi.email.SingleMsgInfoBo;
import com.cloudwise.douc.service.model.multi.tenant.AccountInviteDTO;
import com.cloudwise.douc.service.model.multi.tenant.AccountInviteQueryDTO;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.service.IMultiAccountInvitationService;
import com.cloudwise.douc.service.util.DateUtil;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author bradyliu
 * @description: AccountInviteServiceImpl测试类
 * @date Created in 12:40 2021/7/17.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({AccountInviteServiceImpl.class, DateUtil.class, DateUtils.class})
@PowerMockIgnore({"javax.management.*"})
public class AccountInviteServiceImplTest {


    @Mock
    private IAccountInviteDao accountInviteDao;
    @Mock
    private IMultiAccountInvitationService multiAccountInvitationService;
    @Mock
    private UserServiceImpl userServiceImpl;
    @Mock
    private IDepartmentDao departmentDao;
    @Mock
    private ApplicationContext publisher;
    @Mock
    private IMultiAccountUserInfoDao multiAccountUserInfoDaoImpl;
    @Mock
    private IAccountDao accountDao;
    @Mock
    private IAccountService accountService;
    @Mock
    private IDicDataDao dicDataDao;
    @InjectMocks
    private AccountInviteServiceImpl accountInviteServiceImpl;

    /**
     * @description 测试 getAccountInviteList
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:46
     */
    @Test
    public void getAccountInviteList() throws Exception {
        AccountInviteQueryDTO accountInviteQueryDTO = new AccountInviteQueryDTO();
        accountInviteQueryDTO.setDateSort("asc");
        accountInviteQueryDTO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteQueryDTO.setCurrent(1);
        accountInviteQueryDTO.setSize(1);
        accountInviteQueryDTO.setStatus(1);
        DataPage<AccountInviteDO> accountInviteDTOList = new DataPage<AccountInviteDO>();
        List<AccountInviteDO> list = new ArrayList();
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        accountInviteDO.setPosition("section_chief");
        list.add(accountInviteDO);
        accountInviteDTOList.setPageSize(1);
        accountInviteDTOList.setStart(1);
        accountInviteDTOList.setTotalCount(1);
        accountInviteDTOList.setList(list);

        DataPage<AccountInviteDTO> accountInviteDTODataPage = new DataPage<AccountInviteDTO>();
        List<AccountInviteDTO> list2 = new ArrayList();
        AccountInviteDTO accountInviteDTO = new AccountInviteDTO();
        accountInviteDTO.setStatus(1);
        accountInviteDTO.setAccountId(1L);
        accountInviteDTO.setEndTime(new Date());
        accountInviteDTO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDTO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDTO.setTargetDepartment("test");
        accountInviteDTO.setTargetDepartmentId(1L);
        list2.add(accountInviteDTO);
        accountInviteDTODataPage.setPageSize(1);
        accountInviteDTODataPage.setStart(1);
        accountInviteDTODataPage.setTotalCount(1);
        accountInviteDTODataPage.setList(list2);


        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        Mockito.when(null).thenReturn(accountInviteDTOList);
        PowerMockito.doReturn(accountInviteDTODataPage).when(accountInviteServiceImpl, "dataPageCopy", Mockito.any(), Mockito.any());
        PowerMockito.doReturn(accountInviteDTOList).when(accountInviteServiceImpl, "setDataPagePosition", Mockito.any());

        DataPage<AccountInviteDTO> getAccountInviteList = Whitebox.invokeMethod(accountInviteServiceImpl, "getAccountInviteList", 1L, 1L, accountInviteQueryDTO);

        boolean flag = Objects.nonNull(getAccountInviteList);
        Assert.assertTrue(flag);

    }

    /**
     * @description 测试revokeAccountInvite
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:50
     */
    @Test
    public void revokeAccountInvite() {
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);

        Mockito.when(this.accountInviteDao.getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(accountInviteDO);
        Mockito.when(this.accountInviteDao.updateAccountInviteStatus(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyInt(), new Date())).thenReturn(1);
        this.accountInviteServiceImpl.revokeAccountInvite(1L, 1L, 1L);
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).updateAccountInviteStatus(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyInt(), new Date());
    }


    /**
     * @description 测试getAccountInvite
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:42
     */
    @Test
    public void getAccountInvite() throws Exception {
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        DepartmentResponseObject departmentInformation = new DepartmentResponseObject();
        departmentInformation.setLevel("0.1.2");
        departmentInformation.setName("test");
        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        PowerMockito.doNothing().when(accountInviteServiceImpl, "setAccountInviteDOPosition", Mockito.any());

        Mockito.when(this.accountInviteDao.getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(accountInviteDO);
        Mockito.when(this.departmentDao.getDepartmentInformation(ArgumentMatchers.anyLong())).thenReturn(departmentInformation);

        AccountInviteDTO accountInvite = Whitebox.invokeMethod(accountInviteServiceImpl, "getAccountInvite", 1L, 1L, 1L);

        boolean flag = Objects.nonNull(accountInvite);
        Assert.assertTrue(flag);
    }


    /**
     * @return
     * @description 测试重发方法 retransmissionAccountInvite
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:58
     */
    @Test
    public void retransmissionAccountInvite() throws Exception {
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        SingleMsgInfoBo singleMsgInfoBo = new SingleMsgInfoBo();
        singleMsgInfoBo.setMsgContent("邮件内容");
        singleMsgInfoBo.setMsgTitle("邮件标题");
        singleMsgInfoBo.setReceiveEmail("bss@yunzhihui.com");
        singleMsgInfoBo.setSendAccountId(1L);
        singleMsgInfoBo.setSendUserId(1L);

        BasicMsgEvent basicMsgEvent = new BasicMsgEvent(this, singleMsgInfoBo);

        AccountDetail accountDetailById = new AccountDetail();
        accountDetailById.setName("租户名称");

        Mockito.when(this.accountInviteDao.getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(accountInviteDO);
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(accountDetailById);
        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        ApplicationContext publisher = PowerMockito.spy(this.publisher);
        PowerMockito.doReturn(singleMsgInfoBo).when(accountInviteServiceImpl, "generateSingleEmailInfoBo", ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), Mockito.any());
        Mockito.when(this.accountInviteDao.updateAccountInviteStatus(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyInt(), new Date())).thenReturn(1);
        Mockito.when(this.accountInviteDao.updateAccountInviteStatus(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyInt(), new Date())).thenReturn(1);

        Whitebox.invokeMethod(accountInviteServiceImpl, "retransmissionAccountInvite", 1L, 1L, 1L);

        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());
        PowerMockito.verifyPrivate(accountInviteServiceImpl, Mockito.atLeastOnce()).invoke("generateSingleEmailInfoBo", ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), Mockito.any());

    }

    /**
     * @description deleteAccountInvite测试
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:51
     */
    @Test
    public void deleteAccountInvite() {
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        Mockito.when(this.accountInviteDao.getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(accountInviteDO);
        Mockito.when(this.accountInviteDao.backupAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), new Date())).thenReturn(1);
        Mockito.when(this.accountInviteDao.deleteAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(1);
        this.accountInviteServiceImpl.deleteAccountInvite(1L, 1L, 1L);
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).getAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).backupAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), new Date());
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).deleteAccountInvite(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong());

    }

    /**
     * @description verifyInviteeEmail 方法测试
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:51
     */
    @Test
    public void verifyInviteeEmail() {
        AccountInviteQueryDTO accountInviteQueryDTO = new AccountInviteQueryDTO();
        accountInviteQueryDTO.setDateSort("asc");
        accountInviteQueryDTO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteQueryDTO.setCurrent(1);
        accountInviteQueryDTO.setSize(1);
        accountInviteQueryDTO.setStatus(1);
        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setId(1L);
        userInfoDO.setEmail("bss@yunzhihui.com");
        userInfoDO.setName("testname");
        UserCountDO userCountDO = new UserCountDO();
        Mockito.when(this.accountInviteDao.getUserInfoByEmail(ArgumentMatchers.anyString())).thenReturn(userInfoDO);
        Mockito.when(this.accountInviteDao.getUserCountDO(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(null);
        Mockito.when(this.accountInviteDao.getAccountInviteByEmail(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(null);
        UserInviteVerifyDTO userInviteVerifyDTO = this.accountInviteServiceImpl.verifyInviteeEmail(1L, 1L, "bss@yunzhihui.com");

        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).getUserInfoByEmail("bss@yunzhihui.com");
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).getUserCountDO(1L, 1L);
        Mockito.verify(this.accountInviteDao, Mockito.atLeastOnce()).getAccountInviteByEmail("bss@yunzhihui.com", 1L);
        boolean flag = Objects.nonNull(userInviteVerifyDTO);
        Assert.assertTrue(flag);

    }

    /**
     * @description saveAccountInvite保存方法测试
     * @author brady.liu
     * @date 2021/7/17
     * @time 17:05
     */
    @Test
    public void saveAccountInvite() throws Exception {

        AccountInviteDTO accountInviteDTO = new AccountInviteDTO();
        accountInviteDTO.setStatus(1);
        accountInviteDTO.setName("name");
        accountInviteDTO.setAccountId(1L);

        accountInviteDTO.setStartTime(new Date());
        accountInviteDTO.setEndTime(new Date());
        accountInviteDTO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDTO.setInviteeEmail("ken888@cloudwise.com");
        accountInviteDTO.setTargetDepartment("test");
        accountInviteDTO.setTargetDepartmentId(1L);
        accountInviteDTO.setOrigin(2);
        accountInviteDTO.setTopAccountId(1L);

        AccountInviteDO accountInviteDO = BeanDeepCopyUtil.copyProperties(accountInviteDTO, AccountInviteDO.class);
        accountInviteDO.setModifyUserId(1L);
        accountInviteDO.setCreateUserId(1L);
        accountInviteDO.setModifyTime(new Date());
        accountInviteDO.setCreateTime(new Date());

        SingleMsgInfoBo singleMsgInfoBo = new SingleMsgInfoBo();
        singleMsgInfoBo.setMsgContent("邮件内容");
        singleMsgInfoBo.setMsgTitle("邮件标题");
        singleMsgInfoBo.setReceiveEmail("bss@yunzhihui.com");
        singleMsgInfoBo.setSendAccountId(1L);
        singleMsgInfoBo.setSendUserId(1L);

        BasicMsgEvent basicMsgEvent = new BasicMsgEvent(this, singleMsgInfoBo);

        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setId(1L);
        userInfoDO.setEmail("bss@yunzhihui.com");
        userInfoDO.setName("testname");
        userInfoDO.setTopAccountId(1L);
        UserInviteVerifyDTO userInviteVerifyDTO = new UserInviteVerifyDTO();
        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);

        Mockito.when(this.multiAccountUserInfoDaoImpl.getTenantUserInfo(ArgumentMatchers.anyLong())).thenReturn(userInfoDO);

        Mockito.doReturn(userInviteVerifyDTO).when(accountInviteServiceImpl).verifyInviteeEmail(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyString());
        Mockito.when(this.accountInviteDao.getUserInfoByEmail(ArgumentMatchers.anyString())).thenReturn(userInfoDO);
        Mockito.when(this.accountInviteDao.getUserCountDO(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(null);
        Mockito.when(this.accountInviteDao.getAccountInviteByEmail(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(null);
        PowerMockito.mockStatic(DateUtil.class);
        PowerMockito.when(DateUtil.daysOfDateDifference(Mockito.any(), Mockito.any())).thenReturn(30L);

        PowerMockito.doReturn(singleMsgInfoBo).when(accountInviteServiceImpl, "generateSingleEmailInfoBo", ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), Mockito.any());

        Mockito.when(this.accountInviteDao.saveAccountInvite(Mockito.any())).thenReturn(1);


        Integer saveAccountInvite = Whitebox.invokeMethod(accountInviteServiceImpl, "saveAccountInvite", 1L, 1L, accountInviteDTO);
        Mockito.verify(this.multiAccountUserInfoDaoImpl, Mockito.atLeastOnce()).getTenantUserInfo(ArgumentMatchers.anyLong());
        PowerMockito.verifyPrivate(accountInviteServiceImpl, Mockito.atLeastOnce()).invoke("generateSingleEmailInfoBo", ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), Mockito.any());
    }

    /**
     * @description generateSingleEmailInfoBo 测试拼接邮件方法
     * @author brady.liu
     * @date 2021/7/17
     * @time 17:26
     */
    @Test
    public void generateSingleEmailInfoBo() throws Exception {
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        accountInviteDO.setOrigin(1);
        accountInviteDO.setStartTime(new Date());
        UserInfoDO userInfoDO = new UserInfoDO();
        userInfoDO.setId(1L);
        userInfoDO.setEmail("bss@yunzhihui.com");
        userInfoDO.setName("testname");

        User user = new User();
        user.setName("邀请人");
        user.setEmail("yaoqingren@yunzhihui.com");
        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        AccountDetail accountDetailById = new AccountDetail();
        accountDetailById.setName("租户名称");

        DepartmentResponseObject departmentInformation = new DepartmentResponseObject();
        departmentInformation.setName("邀请单位");
        departmentInformation.setLevel("0.1.2");
        Mockito.when(this.accountInviteDao.getUserInfoByEmail(ArgumentMatchers.anyString())).thenReturn(userInfoDO);
        Mockito.when(this.userServiceImpl.getUser(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(user);
        Mockito.when(this.departmentDao.getDepartmentInformation(ArgumentMatchers.anyLong())).thenReturn(departmentInformation);
        Mockito.doNothing().when(this.userServiceImpl).setDepartmentDetail(ArgumentMatchers.anyLong(), Mockito.any());
        Mockito.when(this.accountService.getAccountDetailById(ArgumentMatchers.anyLong())).thenReturn(accountDetailById);
        Mockito.when(this.multiAccountInvitationService.generateExternalLink(ArgumentMatchers.anyString())).thenReturn("http://lianjie");

        SingleMsgInfoBo generateSingleEmailInfoBo = Whitebox.invokeMethod(accountInviteServiceImpl, "generateSingleEmailInfoBo", 1L, 1L, accountInviteDO);

        boolean flag = Objects.nonNull(generateSingleEmailInfoBo);
        Assert.assertTrue(flag);
    }

    /**
     * @description dataPageCopy 数据拷贝类测试
     * @author brady.liu
     * @date 2021/7/17
     * @time 17:46
     */
    @Test
    public void dataPageCopy() throws Exception {

        DataPage<AccountInviteDO> accountInviteDTOList = new DataPage<AccountInviteDO>();
        List<AccountInviteDO> list = new ArrayList();
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        list.add(accountInviteDO);
        accountInviteDTOList.setPageSize(1);
        accountInviteDTOList.setStart(1);
        accountInviteDTOList.setTotalCount(10);
        accountInviteDTOList.setList(list);

        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        DataPage<AccountInviteDTO> dataPageCopy = Whitebox.invokeMethod(accountInviteServiceImpl, "dataPageCopy", accountInviteDTOList, AccountInviteDTO.class);

        boolean flag = Objects.nonNull(dataPageCopy);
        Assert.assertTrue(flag);
    }

    /**
     * @description 测试setDataPagePosition
     * @author brady.liu
     * @date 2021/7/19
     * @time 15:25
     */
    @Test
    public void setDataPagePosition() throws Exception {
        DataPage<AccountInviteDO> accountInviteDTOList = new DataPage<AccountInviteDO>();
        List<AccountInviteDO> list = new ArrayList();
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        list.add(accountInviteDO);
        accountInviteDTOList.setPageSize(1);
        accountInviteDTOList.setStart(1);
        accountInviteDTOList.setTotalCount(10);
        accountInviteDTOList.setList(list);

        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        PowerMockito.doNothing().when(accountInviteServiceImpl, "setAccountInviteDOPosition", Mockito.any());

        DataPage<AccountInviteDO> datapage = Whitebox.invokeMethod(accountInviteServiceImpl, "setDataPagePosition", accountInviteDTOList);
        boolean b = Objects.nonNull(datapage);
        Assert.assertTrue(b);
    }

    @Test
    public void setAccountInviteDOPosition() throws Exception {
        AccountInviteDO accountInviteDO = new AccountInviteDO();
        accountInviteDO.setStatus(1);
        accountInviteDO.setAccountId(1L);
        accountInviteDO.setEndTime(new Date());
        accountInviteDO.setExternalLinkUUID(ShortUUID.generate());
        accountInviteDO.setInviteeEmail("bss@yunzhihui.com");
        accountInviteDO.setTargetDepartment("test");
        accountInviteDO.setTargetDepartmentId(1L);
        accountInviteDO.setPosition("chief_inspector");
        DicTypePo dicTypePo = new DicTypePo();
        dicTypePo.setId(3L);
        List<DicTypePo> dicTypePoList = new ArrayList<>();
        dicTypePoList.add(dicTypePo);
        DicDataPo dicDataPo = new DicDataPo();
        dicDataPo.setCode("section_chief");
        dicDataPo.setName("总监");
        List<DicDataPo> dicDataPoList = new ArrayList<>();
        dicDataPoList.add(dicDataPo);
        AccountInviteServiceImpl accountInviteServiceImpl = PowerMockito.spy(this.accountInviteServiceImpl);
        Mockito.when(this.dicDataDao.getDicType(ArgumentMatchers.anyLong(), ArgumentMatchers.anyString())).thenReturn(new ArrayList<DicTypePo>(dicTypePoList));
        Mockito.when(this.dicDataDao.getDicData(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(dicDataPoList);
        Whitebox.invokeMethod(accountInviteServiceImpl, "setAccountInviteDOPosition", accountInviteDO);
        Mockito.verify(this.dicDataDao, Mockito.atLeastOnce()).getDicType(ArgumentMatchers.anyLong(), ArgumentMatchers.anyString());
        Mockito.verify(this.dicDataDao, Mockito.atLeastOnce()).getDicData(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
    }
}

