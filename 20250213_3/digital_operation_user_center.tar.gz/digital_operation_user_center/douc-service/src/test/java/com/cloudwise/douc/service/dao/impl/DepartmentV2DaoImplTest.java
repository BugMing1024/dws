package com.cloudwise.douc.service.dao.impl;

import com.cloudwise.douc.metadata.mapper.IDepartmentV2Dao;
import com.cloudwise.douc.metadata.model.department.Department;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * 添加用户信息
 *
 * @author maker.wang
 * @date 2021-07-03 15:48
 **/
public class DepartmentV2DaoImplTest extends UnitTestBaseDao {

    @Resource
    static IDepartmentV2Dao departmentV2Dao;

    @Test
    @Rollback(true)
    public void batchAddDepartment() {
        List<Department> departmentList = new ArrayList<>();
        Department department = new Department();
        Department departmentOne = new Department();
        department.setCode("testCodeOne");
        department.setModifyUserId(2);
        department.setCreateUserId(2);
        department.setModifyTime(new Date());
        department.setCreateTime(new Date());
        department.setName("testName");
        department.setStatus(1);
        department.setAccountId(Long.valueOf(110));
        department.setLevel("0");
        department.setSequence(1);


        departmentOne.setCode("testCodeTwo");
        departmentOne.setModifyUserId(2);
        departmentOne.setCreateUserId(2);
        departmentOne.setModifyTime(new Date());
        departmentOne.setCreateTime(new Date());
        departmentOne.setName("testName");
        departmentOne.setStatus(1);
        departmentOne.setAccountId(Long.valueOf(110));

        departmentList.add(department);
        departmentList.add(departmentOne);
        int addRow = departmentV2Dao.insertBatchDepartment(departmentList);
        //提交事务
        sqlSession.commit();
        Assert.assertEquals(2, addRow);
    }

    @Test
    @Rollback(true)
    public void getTopIdByAccountId() {
        List<Department> departmentList = new ArrayList<>();
        Department department = new Department();
        Department departmentOne = new Department();
        department.setCode("testCodeOne");
        department.setModifyUserId(2);
        department.setCreateUserId(2);
        department.setModifyTime(new Date());
        department.setCreateTime(new Date());
        department.setName("testName");
        department.setStatus(1);
        department.setAccountId(Long.valueOf(110));
        department.setLevel("0");
        department.setSequence(1);


        departmentOne.setCode("testCodeTwo");
        departmentOne.setModifyUserId(2);
        departmentOne.setCreateUserId(2);
        departmentOne.setModifyTime(new Date());
        departmentOne.setCreateTime(new Date());
        departmentOne.setName("testName");
        departmentOne.setStatus(1);
        departmentOne.setAccountId(Long.valueOf(110));

        departmentList.add(department);
        departmentList.add(departmentOne);
        int addRow = departmentV2Dao.insertBatchDepartment(departmentList);

        Long accountId = 110L;
        Long topIdByAccountId = departmentV2Dao.getTopIdByAccountId(accountId);
        sqlSession.commit();
        boolean flag = Objects.nonNull(topIdByAccountId);
        Assert.assertEquals(true, flag);
    }

    @Test
    @Rollback(true)
    public void getMaxSequenceByParentIdAndIds() {

        List<Department> departmentList = new ArrayList<>();
        Department department = new Department();
        Department departmentOne = new Department();
        department.setCode("testCodeOne");
        department.setModifyUserId(2);
        department.setCreateUserId(2);
        department.setModifyTime(new Date());
        department.setCreateTime(new Date());
        department.setName("testName");
        department.setStatus(1);
        department.setAccountId(Long.valueOf(110));
        department.setLevel("0");
        department.setSequence(1);

        department.setId(1L);
        department.setParentId(1L);
        departmentOne.setCode("testCodeTwo");
        departmentOne.setModifyUserId(2);
        departmentOne.setCreateUserId(2);
        departmentOne.setModifyTime(new Date());
        departmentOne.setCreateTime(new Date());
        departmentOne.setName("testName");
        departmentOne.setStatus(1);
        departmentOne.setAccountId(Long.valueOf(110));

        departmentList.add(department);
        departmentList.add(departmentOne);
        int addRow = departmentV2Dao.insertBatchDepartment(departmentList);

        Long accountId = 110L;
        List<Long> ids = new ArrayList<>();
        ids.add(accountId);
        List<Department> list = departmentV2Dao.getMaxSequenceByParentIdAndIds(1L);
        boolean flag = Objects.nonNull(list);
        Assert.assertEquals(true, flag);
    }


}
