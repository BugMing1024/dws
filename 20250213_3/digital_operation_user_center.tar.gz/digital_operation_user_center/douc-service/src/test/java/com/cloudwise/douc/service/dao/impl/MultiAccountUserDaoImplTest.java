package com.cloudwise.douc.service.dao.impl;

import com.cloudwise.douc.metadata.mapper.IMultiAccountUserDao;
import com.cloudwise.douc.metadata.model.multi.iteration.SubAccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserDetail;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 添加用户 UT
 *
 * @author maker.wang
 * @date 2021-07-03 15:47
 **/
public class MultiAccountUserDaoImplTest extends UnitTestBaseDao {

    @Resource
    static IMultiAccountUserDao multiAccountUserDao;

    @Test
    @Rollback(false)
    public void addUser() {
        MultiAccountUserDetail userDetail = new MultiAccountUserDetail();
        userDetail.setUserId(1L);
        userDetail.setAccountId(1L);
        userDetail.setStatus(1);
        userDetail.setOrigin(1);
        userDetail.setCreateUserId(222L);
        int result = this.multiAccountUserDao.addUser(userDetail);
        Assert.assertEquals(1, result);
    }

    @Test
    @Rollback(false)
    public void addUserByList() {
        List<MultiAccountUserDetail> userDetailList = new ArrayList<>(1);
        for (int i = 0; i < 2; i++) {
            MultiAccountUserDetail userDetail = new MultiAccountUserDetail();
            userDetail.setUserId(1L + 1);
            userDetail.setAccountId(1L);
            userDetail.setStatus(1);
            userDetail.setOrigin(1);
            userDetail.setCreateUserId(222L);
            userDetailList.add(userDetail);
        }
        int result = this.multiAccountUserDao.addUserByList(userDetailList);
        Assert.assertEquals(2, result);
    }

    @Test
    @Rollback(false)
    public void getUserDetail() {
        MultiAccountUserDetail userDetail = new MultiAccountUserDetail();
        userDetail.setUserId(1001L);
        userDetail.setAccountId(12345L);
        userDetail.setStatus(1);
        userDetail.setOrigin(1);
        userDetail.setCreateUserId(222L);
        int result = this.multiAccountUserDao.addUser(userDetail);
        sqlSession.commit();
        Assert.assertEquals(1, result);
        MultiAccountUserDetail accountUserDetail = this.multiAccountUserDao.getUserDetail(userDetail.getAccountId());
        Assert.assertEquals(true, accountUserDetail.getAccountId() == 12345L);
        Assert.assertEquals(true, accountUserDetail.getCreateUserId() == 222L);
    }

    @Test
    @Rollback(false)
    public void getUserDetailByUserId() {
        MultiAccountUserDetail userDetail = new MultiAccountUserDetail();
        userDetail.setUserId(1001L);
        userDetail.setAccountId(12345L);
        userDetail.setStatus(1);
        userDetail.setOrigin(1);
        userDetail.setCreateUserId(222L);
        int result = this.multiAccountUserDao.addUser(userDetail);
        sqlSession.commit();
        Assert.assertEquals(1, result);

        MultiAccountUserDetail accountUserDetail = this.multiAccountUserDao.getUserDetailByUserId(12345L, 1001L);
        Assert.assertEquals(true, accountUserDetail.getAccountId() == 12345L);

    }


    @Test
    @Rollback(false)
    public void getSubAccountAllUser() {
        //数据放在SQL脚本中初始化了
        Long accountId = 1115L;
        List<SubAccountDetail> list = this.multiAccountUserDao.getSubAccountAllUser(accountId);
        Assert.assertEquals(1, list.size());

    }

    @Test
    @Rollback(false)
    public void deleteSubAccountAllUser() {
        //数据放在SQL脚本中初始化了
        Long accountId = 1115L;
        List<Long> list = new ArrayList<>();
        list.add(1L);
        int result = this.multiAccountUserDao.deleteSubAccountAllUser(accountId, list);
        Assert.assertEquals(1, result);

    }

    @Test
    @Rollback(false)
    public void searchUserFromTopAccount() {
        //数据放在SQL脚本中初始化了
        Long accountId = 1115L;
        String name = "maker";
    }

}