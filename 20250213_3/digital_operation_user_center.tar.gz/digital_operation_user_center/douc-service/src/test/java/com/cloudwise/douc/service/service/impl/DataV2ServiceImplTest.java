package com.cloudwise.douc.service.service.impl;

import com.cloudwise.douc.metadata.mapper.IDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IDepartmentDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IGroupRoleRelationDao;
import com.cloudwise.douc.metadata.mapper.ILogDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IModelDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IMultiTypeDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IRoleResourceBizDataRelationDao;
import com.cloudwise.douc.metadata.mapper.IRoleResourceModelDataRelationDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.model.data.DataAuthentication;
import com.cloudwise.douc.metadata.model.data.DataV2ListBizRequestObject;
import com.cloudwise.douc.metadata.model.data.ModelDataVO;
import com.cloudwise.douc.metadata.model.data.ResourceBizData;
import com.cloudwise.douc.metadata.model.data.ResourceMultiTypeData;
import com.cloudwise.douc.metadata.model.data.ResourceMultiTypeTreeData;
import com.cloudwise.douc.metadata.model.data.RoleDepartmentDataResourceVO;
import com.cloudwise.douc.metadata.model.data.RoleResourceBizDataRelation;
import com.cloudwise.douc.metadata.model.data.RoleResourceModelDataRelation;
import com.cloudwise.douc.metadata.model.data.RoleResourceMultiTypeDataRelation;
import com.cloudwise.douc.metadata.model.department.DepartmentNode;
import com.cloudwise.douc.metadata.model.role.Role;
import com.cloudwise.douc.metadata.model.user.User;
import com.cloudwise.douc.service.cache.IDataResourceCache;
import com.cloudwise.douc.service.model.data.DataV2UpdateAuthRequestObject;
import com.cloudwise.douc.service.model.data.ResourceBizDataAuthVO;
import com.cloudwise.douc.service.model.data.ResourceMultiTypeDataVO;
import com.cloudwise.douc.service.service.IUserService;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anySet;
import static org.mockito.Mockito.when;

/**
 * 私有方法打桩示例
 *
 * @Author maker.wang
 * @Date 2021-05-06 10:45
 **/
@Slf4j
@RunWith(PowerMockRunner.class)
@PrepareForTest({DataV2ServiceImpl.class})
@PowerMockIgnore({"javax.management.*"})
public class DataV2ServiceImplTest {

    @Mock
    private IDataResourceDao dataResourceDao;
    @Mock
    private IRoleResourceBizDataRelationDao roleResourceBizDataRelationDao;
    @Mock
    private IModelDataResourceDao modelDataResourceDao;
    @Mock
    private IRoleResourceModelDataRelationDao roleResourceModelDataRelationDao;
    @Mock
    private IMultiTypeDataResourceDao multiTypeDataResourceDao;
    @Mock
    private IDepartmentDataResourceDao departmentDataResourceDao;
    @Mock
    private IDepartmentDao departmentDao;
    @Mock
    private IUserDao userDao;
    @Mock
    private ILogDataResourceDao logDataResourceDao;
    @Mock
    private IGroupRoleRelationDao groupRoleRelationDao;
    @Mock
    private IUserService userService;
    @Mock
    private IDataResourceCache dataResourceCache;

    @InjectMocks
    DataV2ServiceImpl dataV2ServiceImpl;

    /**
     * 私有方法UT-getCodeAndSubCodes
     *
     * @Author maker.wang
     * @Date 2021-05-16 18:11
     **/
    @Test
    public void getCodeAndSubCodes() throws Exception {
        ///DataV2Service dataV2Service = new DataV2Service();
        List<ResourceMultiTypeTreeData> allTreeCode = new ArrayList<>();
        ResourceMultiTypeTreeData data = new ResourceMultiTypeTreeData();
        data.setCode("1001");
        data.setParentCode("");
        allTreeCode.add(data);
        data = new ResourceMultiTypeTreeData();
        data.setCode("1002");
        data.setParentCode("1001");
        allTreeCode.add(data);
        data = new ResourceMultiTypeTreeData();
        data.setCode("1003");
        data.setParentCode("1002");
        allTreeCode.add(data);
        data = new ResourceMultiTypeTreeData();
        data.setCode("2001");
        data.setParentCode("");
        allTreeCode.add(data);
        Mockito.when(this.multiTypeDataResourceDao.getAllTreeCode(anyLong(), anyString())).thenReturn(allTreeCode);
        Map<String, Set<String>> result = Whitebox.invokeMethod(this.dataV2ServiceImpl, "getCodeAndSubCodes", anyString(), anyString());
        log.error("{}", result);
        Assert.assertEquals(result.size(), 4);
    }

    /**
     * 树权限修改UT
     *
     * @Author maker.wang
     * @Date 2021-05-16 18:13
     **/
    @Test
    public void resourceMultiTypeDataMap() throws Exception {

        Map<String, List<ResourceMultiTypeData>> request = new HashMap<>();
        List<ResourceMultiTypeData> allTreeCode = new ArrayList<>();
        ResourceMultiTypeData data = new ResourceMultiTypeData();
        data.setCode("1001");
        data.setIsMaintenance(true);
        data.setIsRead(true);
        allTreeCode.add(data);
        request.put("rpc_auth", allTreeCode);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(new DataV2ServiceImpl());
        ///{2001=[], 1003=[], 1002=[1003], 1001=[1003, 1002]}
        Map<String, Set<String>> treeToMap = new HashMap<>();
        Set<String> s = new HashSet<>();
        s.add("1002");
        s.add("1003");
        treeToMap.put("1001", s);
        s = new HashSet<>();
        s.add("1003");
        treeToMap.put("1002", s);
        s = new HashSet<>();
        treeToMap.put("1003", s);
        s = new HashSet<>();
        treeToMap.put("2001", s);

    }

    @Test
    public void listBizTop3Tree() throws Exception {
        //入参
        String accountId = "110";
        String roleId = "2";
        List<ResourceBizData> resourceBizDataList = new ArrayList<>();
        ResourceBizData resourceBizData = new ResourceBizData();
        resourceBizData.setDescription("aaa");
        resourceBizData.setCode("111");
        resourceBizData.setAccountId("222");
        resourceBizDataList.add(resourceBizData);

        List<ResourceBizData> resourceBizDataResultList = new ArrayList<>();
        resourceBizDataResultList.add(resourceBizData);
        Map<String, List<ResourceBizData>> sameCodeResourceBizDataList = Maps.newHashMap();
        //打桩
        when(this.dataResourceDao.listBizTop3NodeByRoleId(anyString(), anyString())).thenReturn(resourceBizDataList);
        //私有方法打桩
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doNothing().when(privateMethod, "buildBizDataTree", resourceBizDataResultList, sameCodeResourceBizDataList);

        PowerMockito.doReturn(true).when(privateMethod, "checkResourceBizDataMapListNoHaveResourceBizDataByCode", resourceBizDataResultList, resourceBizData.getCode());


        when(this.dataResourceDao.listBizTop3NodeByRoleId(anyString(), anyString())).thenReturn(resourceBizDataList);
        Whitebox.invokeMethod(this.dataV2ServiceImpl,
                "listBizTop3Tree", accountId, roleId);
        //verify(this.dataV2Service,atLeastOnce()).listBizTop3Tree(anyString(),anyString());
        assertEquals(true, resourceBizDataResultList.size() > 0);

    }

    /**
     * @Description:
     * @Author: zack.gao
     * @Date: 2021/6/17 2:02 下午
     * @return: null
     **/
    @Test
    public void listBizList() throws Exception {
        DataV2ListBizRequestObject dataV2ListBizRequestObject = new DataV2ListBizRequestObject();
        dataV2ListBizRequestObject.setRoleId("1");
        dataV2ListBizRequestObject.setAccountId(110L);
        dataV2ListBizRequestObject.setParentCode("111");
        List<ResourceBizData> resourceBizDataList = new ArrayList<>();
        ResourceBizData resourceBizData = new ResourceBizData();
        resourceBizData.setAccountId("110");
        resourceBizData.setId("1");
        resourceBizData.setCode("234");
        resourceBizDataList.add(resourceBizData);

        //打桩
        Mockito.when(this.dataResourceDao.listBizByParentCodeAndRoleId(dataV2ListBizRequestObject)).thenReturn(resourceBizDataList);

        Whitebox.invokeMethod(this.dataV2ServiceImpl,
                "listBizList", dataV2ListBizRequestObject);
        Assert.assertTrue(resourceBizDataList.size() > 0);
    }


    @Test
    public void listModelTree() throws Exception {
        String roleId = "2";
        String accountId = "110";

        List<ModelDataVO> modelDataVOS = new ArrayList<>();
        ModelDataVO modelDataVO = new ModelDataVO();
        modelDataVO.setCode("12");
        modelDataVO.setId("234");
        modelDataVO.setParentCode("1");
        modelDataVO.setName("哈哈");
        modelDataVO.setTag("1");
        modelDataVOS.add(modelDataVO);
        
        

        //dao 打桩
        Mockito.when(this.modelDataResourceDao.listAllModelResource(accountId, roleId)).thenReturn(modelDataVOS);

        List<ModelDataVO> resourceDataResultList = new ArrayList<>();
        resourceDataResultList.add(modelDataVO);
        Map<String, List<ModelDataVO>> sameCodeResourceDataList = Maps.newHashMap();
        sameCodeResourceDataList.put(modelDataVO.getParentCode(), resourceDataResultList);
        //私有方法打桩
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doNothing().when(privateMethod, "buildModelDataTree", resourceDataResultList, sameCodeResourceDataList);

        //执行方法
        Whitebox.invokeMethod(this.dataV2ServiceImpl,
                "listModelTree", roleId, accountId);

        Assert.assertTrue(resourceDataResultList.size() > 0);
    }

    @Test
    public void listOtherTree() throws Exception {
        Long roleId = 1L;
        Long accountId = 110L;
        String dateType = "1";
        List<ResourceMultiTypeData> resourceMultiTypeDataList = new ArrayList<>();

        Mockito.when(this.multiTypeDataResourceDao.listMultiTypeDataByRoleId(roleId, Lists.newArrayList(accountId), dateType, "", true)).thenReturn(resourceMultiTypeDataList);
        ResourceMultiTypeData resourceMultiTypeData = new ResourceMultiTypeData();
        resourceMultiTypeData.setDataType(dateType);
        resourceMultiTypeData.setId("2");
        resourceMultiTypeData.setAccountId(accountId);
        resourceMultiTypeDataList.add(resourceMultiTypeData);
        //执行方法
        Whitebox.invokeMethod(this.dataV2ServiceImpl,
                "listOtherTree", roleId, accountId, dateType);

        Assert.assertTrue(resourceMultiTypeDataList.size() == 1);
    }

    /**
     * 测试 {@link}
     *
     * @throws Exception
     */
    @Test
    public void listDepartmentTree() throws Exception {
        Long roleId = 1L;
        Long accountId = 110L;
        String language = "CH";

        Map<String, List<RoleDepartmentDataResourceVO>> departmentDataResourceVOMap = Maps.newHashMap();
        List<RoleDepartmentDataResourceVO> departmentDataResources = new ArrayList<>();
        //dao打桩
        Mockito.when(departmentDataResourceDao.listDepartmentDataByRoleId(accountId, roleId)).thenReturn(departmentDataResources);
        RoleDepartmentDataResourceVO roleDepartmentDataResourceVO = new RoleDepartmentDataResourceVO();
        roleDepartmentDataResourceVO.setCode("1");
        roleDepartmentDataResourceVO.setDataStr("1111111");
        roleDepartmentDataResourceVO.setName("aaaa");
        roleDepartmentDataResourceVO.setIsSelected(true);
        roleDepartmentDataResourceVO.setIsMultiSelect(true);
        departmentDataResources.add(roleDepartmentDataResourceVO);
        departmentDataResourceVOMap.put(roleDepartmentDataResourceVO.getDataType(), departmentDataResources);
        //私有方法
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);

        //国际化转换打桩
        PowerMockito.doNothing().when(privateMethod, "thransEnglishName", roleDepartmentDataResourceVO, language);
        List<RoleDepartmentDataResourceVO> roleDepartmentDataResourceVOList = new ArrayList<>();
        roleDepartmentDataResourceVOList.add(roleDepartmentDataResourceVO);
        List<DepartmentNode> departmentByIds = new ArrayList<>();
        List<Long> departmentIdList = Lists.newArrayList();
        departmentIdList.add(0L);
        DepartmentNode departmentNode = new DepartmentNode();
        departmentNode.setAccountId(110L);
        departmentNode.setCode("100");
        departmentNode.setId(1L);
        departmentNode.setName("haha");
        departmentByIds.add(departmentNode);
        Mockito.when(departmentDao.getDepartmentByIds(Mockito.anyList(), Mockito.anyLong(), Mockito.anyInt())).thenReturn(departmentByIds);


        Whitebox.invokeMethod(privateMethod,
                "listDepartmentTree", roleId, accountId, language);
        Assert.assertTrue(!departmentDataResourceVOMap.isEmpty());
    }

    @Test
    public void updateDataAuth() throws Exception {
        List<ResourceBizDataAuthVO> resourceBizDataAuthVOList = new ArrayList<>();
        Map<String, List<RoleDepartmentDataResourceVO>> department = new HashMap<>();
        Map<String, List<ResourceMultiTypeData>> multiType = new HashMap<>();
        List<ModelDataVO> modelList = new ArrayList<>();
        DataV2UpdateAuthRequestObject dataV2UpdateAuthRequestObject = new DataV2UpdateAuthRequestObject();
        dataV2UpdateAuthRequestObject.setAccountId("110");
        dataV2UpdateAuthRequestObject.setRoleId("1");
        dataV2UpdateAuthRequestObject.setBiz(resourceBizDataAuthVOList);
        dataV2UpdateAuthRequestObject.setDepartment(department);
        dataV2UpdateAuthRequestObject.setUserId("1");
        dataV2UpdateAuthRequestObject.setModel(modelList);
        dataV2UpdateAuthRequestObject.setMultiType(multiType);

        //私有方法
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doNothing().when(privateMethod, "updateBizDataAuth", dataV2UpdateAuthRequestObject.getAccountId(), dataV2UpdateAuthRequestObject.getUserId(), dataV2UpdateAuthRequestObject.getRoleId(), dataV2UpdateAuthRequestObject.getBiz());
        PowerMockito.doNothing().when(privateMethod, "updateModelDataAuth", dataV2UpdateAuthRequestObject.getUserId(), dataV2UpdateAuthRequestObject.getRoleId(), dataV2UpdateAuthRequestObject.getModel());
        PowerMockito.doNothing().when(privateMethod, "updateMultiTypeDataAuth", dataV2UpdateAuthRequestObject.getUserId(), dataV2UpdateAuthRequestObject.getRoleId(), dataV2UpdateAuthRequestObject.getMultiType());
        PowerMockito.doNothing().when(privateMethod, "updateDepartmentDataAuth", dataV2UpdateAuthRequestObject.getUserId(), dataV2UpdateAuthRequestObject.getRoleId(), dataV2UpdateAuthRequestObject.getDepartment());


        Whitebox.invokeMethod(privateMethod, "updateDataAuth", dataV2UpdateAuthRequestObject);

        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("updateBizDataAuth", ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), Mockito.anyCollection());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("updateModelDataAuth", ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), Mockito.anyCollection());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("updateMultiTypeDataAuth", ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), Mockito.anyMap());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("updateDepartmentDataAuth", ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), Mockito.anyMap());

    }

    @Test
    public void updateBizDataAuth() throws Exception {
        Long accountId = 110L;
        Long userId = 1L;
        String roleId = "1";
        List<ResourceBizDataAuthVO> resourceBizDataList = new ArrayList<>();
        ResourceBizDataAuthVO resourceBizDataAuthVO = new ResourceBizDataAuthVO();
        resourceBizDataAuthVO.setCode("111");
        resourceBizDataAuthVO.setTag("modelParent");
        resourceBizDataAuthVO.setIsMaintenance(true);
        resourceBizDataAuthVO.setIsRead(true);
        resourceBizDataAuthVO.setIsLoaded(false);
        List<String> changedKey = new ArrayList<>();
        changedKey.add("isMaintenance");
        changedKey.add("isRead");
        resourceBizDataAuthVO.setChangedKeys(changedKey);
        resourceBizDataList.add(resourceBizDataAuthVO);
        List<ResourceBizData> modelBizDatas = new ArrayList<>();
        DataV2ListBizRequestObject dataV2ListBizRequestObject = new DataV2ListBizRequestObject();
        dataV2ListBizRequestObject.setRoleId(roleId);
        dataV2ListBizRequestObject.setTag(Constant.BIZ_RESOURCE_DATA_TAG_MODELPARENT);
        dataV2ListBizRequestObject.setParentCode(resourceBizDataAuthVO.getCode());
        dataV2ListBizRequestObject.setAccountId(accountId);


        ResourceBizData resourceBizData = new ResourceBizData();
        resourceBizData.setCode("222");
        resourceBizData.setIsRead(true);
        resourceBizData.setId("222");
        resourceBizData.setAccountId(accountId + "");
        modelBizDatas.add(resourceBizData);

        //私有方法
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        // dao
        Mockito.when(dataResourceDao.listBizByParentCodeAndRoleId(dataV2ListBizRequestObject)).thenReturn(modelBizDatas);

        List<RoleResourceBizDataRelation> roleResourceBizDataRelations = Lists.newArrayList();
        RoleResourceBizDataRelation modelRoleResourceBizDataRelation = new RoleResourceBizDataRelation();
        modelRoleResourceBizDataRelation.setRoleId(roleId);
        modelRoleResourceBizDataRelation.setTag(Constant.BIZ_RESOURCE_DATA_TAG_MODEL);
        modelRoleResourceBizDataRelation.setBizResourceCode(resourceBizData.getCode());
        modelRoleResourceBizDataRelation.setBizResourceParentCode(resourceBizData.getParentCode());
        modelRoleResourceBizDataRelation.setIsCurrentRead(true);
        Mockito.when(roleResourceBizDataRelationDao.backupRelationByCode(Mockito.anyList(), ArgumentMatchers.anyString(), Mockito.any(Date.class))).thenReturn(2);
        Mockito.when(roleResourceBizDataRelationDao.deleteRelationByCode(Mockito.anyList())).thenReturn(2);
        Mockito.when(roleResourceBizDataRelationDao.insertRelation(Mockito.anyList())).thenReturn(2);

        //执行
        Whitebox.invokeMethod(privateMethod, "updateBizDataAuth", accountId, userId, roleId, resourceBizDataList);
    }

    @Test
    public void updateModelDataAuth() throws Exception {
        String userId = "2";
        String roleId = "1";
        List<ModelDataVO> modelDataVOS = new ArrayList<>();
        ModelDataVO modelDataVO = new ModelDataVO();
        modelDataVO.setName("111");
        modelDataVO.setIsRead(true);
        modelDataVO.setIsMaintenance(true);
        modelDataVO.setParentCode("111");
        modelDataVO.setId("211");
        modelDataVOS.add(modelDataVO);

        List<RoleResourceModelDataRelation> roleResourceModelDataRelations = Lists.newArrayList();
        RoleResourceModelDataRelation roleResourceModelDataRelation = new RoleResourceModelDataRelation();
        roleResourceModelDataRelation.setRoleId(roleId);
        roleResourceModelDataRelation.setModelResourceCode(modelDataVO.getCode());
        roleResourceModelDataRelation.setIsMaintenance(modelDataVO.getIsMaintenance());
        roleResourceModelDataRelation.setIsRead(modelDataVO.getIsRead());
        roleResourceModelDataRelations.add(roleResourceModelDataRelation);

        Mockito.when(roleResourceModelDataRelationDao.backupRelationByCode(Mockito.anyList(), ArgumentMatchers.anyString(), Mockito.any(Date.class))).thenReturn(1);
        Mockito.when(roleResourceModelDataRelationDao.deleteRelationByCode(Mockito.anyList())).thenReturn(1);
        Mockito.when(roleResourceModelDataRelationDao.insertRelation(Mockito.anyList())).thenReturn(1);
        //私有方法
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        Whitebox.invokeMethod(privateMethod, "updateModelDataAuth", userId, roleId, modelDataVOS);
    }

    @Test
    public void checkDataDisplayTypeIsTree() throws Exception {
        String accountId = "110";
        String dataType = "1";
        when(multiTypeDataResourceDao.checkDataDisplayTypeIsTree(anyLong(), anyString())).thenReturn("2");
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        boolean result = Whitebox.invokeMethod(privateMethod, "checkDataDisplayTypeIsTree", accountId, dataType);
        Assert.assertTrue(result);
    }

    @Test
    public void updateTreeDataAuthRefactoring() throws Exception {
        String roleId = "1";
        Map<String, List<ResourceMultiTypeData>> resourceMultiTypeDataMap = new HashMap<>();
        List<ResourceMultiTypeData> resourceMultiTypeDataList = new ArrayList<>();
        ResourceMultiTypeData resourceMultiTypeData = new ResourceMultiTypeData();
        resourceMultiTypeData.setDataType("111");
        resourceMultiTypeData.setIsRead(true);
        resourceMultiTypeData.setAccountId(110L);
        resourceMultiTypeData.setId("11");
        resourceMultiTypeData.setCode("1");
        resourceMultiTypeDataList.add(resourceMultiTypeData);
        resourceMultiTypeDataMap.put("111", resourceMultiTypeDataList);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(true).when(privateMethod, "checkDataDisplayTypeIsTree", ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
        List<String> subCodes = new ArrayList<>();
        subCodes.add("1");
        subCodes.add("2");
        PowerMockito.doReturn(subCodes).when(privateMethod, "listAllSubCodes", Mockito.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
        Map<String, List<ResourceMultiTypeData>> newResourceMultiTypeDataMap = Whitebox.invokeMethod(privateMethod, "updateTreeDataAuthRefactoring", roleId, resourceMultiTypeDataMap);

        Assert.assertTrue(newResourceMultiTypeDataMap.size() != 0);
    }

    @Test
    public void listAllSubCodes() throws Exception {
        List<String> codes = new ArrayList<>();
        String dataType = "1";
        String accountId = "110";
        codes.add("111");
        codes.add("222");
        List<String> subCodes = new ArrayList<>();
        subCodes.add("111");
        //打桩
        when(dataResourceDao.getSubMultiTypeDataByParentCodes(anyList(), anyString(), anyList())).thenReturn(subCodes);

        subCodes = Whitebox.invokeMethod(dataV2ServiceImpl, "listAllSubCodes", codes, dataType, accountId);
        Assert.assertTrue(subCodes.size() != 0);
    }


    @Test
    public void updateTreeDataAuth() throws Exception {
        String roleId = "1";
        Map<String, List<ResourceMultiTypeData>> resourceMultiTypeDataMap = new HashMap<>();
        List<ResourceMultiTypeData> resourceMultiTypeDataList = new ArrayList<>();
        ResourceMultiTypeData resourceMultiTypeData = new ResourceMultiTypeData();
        resourceMultiTypeData.setDataType("1");
        resourceMultiTypeData.setCode("2");
        resourceMultiTypeData.setTag("1");
        resourceMultiTypeData.setIsRead(true);
        resourceMultiTypeData.setAccountId(110L);
        resourceMultiTypeData.setSequence(1);
        resourceMultiTypeDataList.add(resourceMultiTypeData);
        resourceMultiTypeDataMap.put("1", resourceMultiTypeDataList);
        ResourceMultiTypeData resourceMultiTypeData1 = new ResourceMultiTypeData();
        resourceMultiTypeData1.setDataType("1");
        resourceMultiTypeData1.setCode("22");
        resourceMultiTypeData1.setTag("1");
        resourceMultiTypeData1.setIsRead(true);
        resourceMultiTypeData1.setAccountId(110L);
        resourceMultiTypeData1.setSequence(2);
        resourceMultiTypeDataList.add(resourceMultiTypeData1);
        Map<String, Set<String>> codeAndSubCodes = new HashMap<>();
        Set<String> stringSet = new HashSet<>();
        stringSet.add("1");
        stringSet.add("2");
        codeAndSubCodes.put("22", stringSet);
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(false).when(privateMethod, "checkDataDisplayTypeIsTree", ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
        PowerMockito.doReturn(codeAndSubCodes).when(privateMethod, "getCodeAndSubCodes", ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
        RoleResourceMultiTypeDataRelation detail = new RoleResourceMultiTypeDataRelation();
        detail.setIsMaintenance(true);
        detail.setIsRead(true);
        when(multiTypeDataResourceDao.getRoleMultiTypeRelationDetail(anyLong(), anyString(), anyString())).thenReturn(detail);
        Map<String, List<ResourceMultiTypeData>> resourceMultiTypeDataMaNew = Whitebox.invokeMethod(privateMethod, "updateTreeDataAuth", roleId, resourceMultiTypeDataMap);

        Assert.assertTrue(resourceMultiTypeDataMaNew.size() != 0);

        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("checkDataDisplayTypeIsTree", ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
        PowerMockito.verifyPrivate(privateMethod, Mockito.times(1)).invoke("getCodeAndSubCodes", ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
    }

    @Test
    public void mapToList() throws Exception {
        Map<String, ResourceMultiTypeData> distinctData = new HashMap<>();
        ResourceMultiTypeData resourceMultiTypeData = new ResourceMultiTypeData();

        resourceMultiTypeData.setDataType("1");
        resourceMultiTypeData.setAccountId(110L);
        resourceMultiTypeData.setIsRead(true);
        resourceMultiTypeData.setId("1");
        resourceMultiTypeData.setName("232");
        distinctData.put("111", resourceMultiTypeData);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);

        List<ResourceMultiTypeData> dataList = Whitebox.invokeMethod(privateMethod, "mapToList", distinctData);

        Assert.assertTrue(dataList.size() != 0);
    }


    @Test
    public void listAllChild() throws Exception {
        String code = "1";
        Map<String, Set<String>> parentCodeAndCode = new HashMap<>();
        Set<String> stringSet = new HashSet<>();
        stringSet.add("111");
        stringSet.add("222");
        parentCodeAndCode.put("1", stringSet);

        Set<String> subCodes = Whitebox.invokeMethod(dataV2ServiceImpl.listAllChild(code, parentCodeAndCode));

        Assert.assertTrue(subCodes.size() != 0);
    }


    @Test
    public void updateMultiTypeDataAuth() throws Exception {
        String userId = "1";
        String roleId = "2";

        Map<String, List<ResourceMultiTypeData>> resourceMultiTypeDataMap = new HashMap<>();
        List<ResourceMultiTypeData> resourceMultiTypeDataList = new ArrayList<>();
        ResourceMultiTypeData resourceMultiTypeData = new ResourceMultiTypeData();
        resourceMultiTypeData.setName("111");
        resourceMultiTypeData.setDataType("1");
        resourceMultiTypeData.setCode("1");
        resourceMultiTypeData.setSequence(1);
        resourceMultiTypeData.setAccountId(110L);
        resourceMultiTypeData.setIsRead(true);
        resourceMultiTypeDataList.add(resourceMultiTypeData);
        resourceMultiTypeDataMap.put("", resourceMultiTypeDataList);
        //私有方法打桩
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        Map<String, List<ResourceMultiTypeData>> treeData = new HashMap<>();
        PowerMockito.doReturn(treeData).when(privateMethod, "updateTreeDataAuthRefactoring", ArgumentMatchers.anyString(), Mockito.anyMap());
        treeData.put("111", resourceMultiTypeDataList);

        when(multiTypeDataResourceDao.backupMultiTypeDataRelationByCodes(anyLong(), anyList(), new Date(), "1")).thenReturn(1);
        when(multiTypeDataResourceDao.removeMultiTypeDataRelationByCodes(anyList(),
                "0", "0")).thenReturn(1);
        Mockito.when(multiTypeDataResourceDao.insertRelation(Mockito.anyList())).thenReturn(1);

        Whitebox.invokeMethod(privateMethod, "updateMultiTypeDataAuth", userId, roleId, resourceMultiTypeDataMap);

    }


    @Test
    public void updateDepartmentDataAuth() throws Exception {
        String userId = "1";
        String roleId = "2";
        Map<String, List<RoleDepartmentDataResourceVO>> roleDepartmentDataResourceVOListMap = new HashMap<>();
        List<RoleDepartmentDataResourceVO> roleDepartmentDataResourceVOS = new ArrayList<>();
        RoleDepartmentDataResourceVO roleDepartmentDataResourceVO = new RoleDepartmentDataResourceVO();
        roleDepartmentDataResourceVO.setId("1");
        roleDepartmentDataResourceVO.setName("111");
        roleDepartmentDataResourceVO.setCode("11");
        roleDepartmentDataResourceVO.setIsMultiSelect(true);
        roleDepartmentDataResourceVO.setIsSelected(true);
        Map<String, String> data = new HashMap<>();
        data.put("1", "11");
        data.put("2", "22");
        roleDepartmentDataResourceVO.setData(data);
        roleDepartmentDataResourceVOS.add(roleDepartmentDataResourceVO);
        roleDepartmentDataResourceVOListMap.put("111", roleDepartmentDataResourceVOS);

        when(departmentDataResourceDao.backupDepartmentDataRelationByCodes(anyLong(), anyList(), 1L, null)).thenReturn(1);
        when(departmentDataResourceDao.removeDepartmentDataRelationByCodes(anyLong(), anyList(), 1L, null)).thenReturn(1);
        when(departmentDataResourceDao.insertRelation(anyList())).thenReturn(1);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        Whitebox.invokeMethod(privateMethod, "updateDepartmentDataAuth", userId, roleId, roleDepartmentDataResourceVOListMap);
    }


    @Test
    public void listMultiTypeTreeDataByRoleId() throws Exception {
        String roleId = "1";
        String dataType = "1";
        String parentCode = "2";
        Long accountId = 110L;
        List<ResourceMultiTypeTreeData> list = new ArrayList<>();
        ResourceMultiTypeTreeData resourceMultiTypeTreeData = new ResourceMultiTypeTreeData();
        resourceMultiTypeTreeData.setDataType("1");
        resourceMultiTypeTreeData.setAccountId(accountId);
        resourceMultiTypeTreeData.setRoleId(roleId);
        resourceMultiTypeTreeData.setId("1");
        resourceMultiTypeTreeData.setIsMaintenance(true);
        resourceMultiTypeTreeData.setName("21");

        list.add(resourceMultiTypeTreeData);
        when(multiTypeDataResourceDao.listMultiTypeTreeDataByRoleId(anyLong(), anyString(), anyString(), anyList())).thenReturn(list);


        List<ResourceMultiTypeDataVO> listTreeResult = Whitebox.invokeMethod(dataV2ServiceImpl.listMultiTypeTreeDataByRoleId(roleId, dataType, parentCode, accountId + ""));

        Assert.assertTrue(listTreeResult.size() != 0);
    }


    @Test
    public void checkCodeIsChild() throws Exception {
        String dataType = "1";
        String accountId = "110";
        List<ResourceMultiTypeTreeData> list = new ArrayList<>();
        ResourceMultiTypeTreeData resourceMultiTypeTreeData = new ResourceMultiTypeTreeData();
        resourceMultiTypeTreeData.setName("111");
        resourceMultiTypeTreeData.setDataType(dataType);
        resourceMultiTypeTreeData.setCode("11");
        resourceMultiTypeTreeData.setIsRead(true);
        resourceMultiTypeTreeData.setIsMaintenance(true);
        list.add(resourceMultiTypeTreeData);

        List<String> childCodes = new ArrayList<>();
        when(multiTypeDataResourceDao.checkCodesIsChild(anyString(), anyList(), anyList())).thenReturn(childCodes);
        childCodes.add("111");

        Set<String> isChildCodes = Whitebox.invokeMethod(dataV2ServiceImpl, "checkCodeIsChild", list, dataType, accountId);
        Assert.assertTrue(isChildCodes.size() != 0);
    }

    @Test
    public void getTopDepartmentsAuthed() throws Exception {
        Long accountId = 110L;
        Long userId = 1L;
        Integer status = 1;

        List<RoleDepartmentDataResourceVO> roleDepartmentDataResourceVOS = new ArrayList<>();
        RoleDepartmentDataResourceVO roleDepartmentDataResourceVO = new RoleDepartmentDataResourceVO();
        roleDepartmentDataResourceVO.setCode("current");
        roleDepartmentDataResourceVO.setName("2232");
        roleDepartmentDataResourceVOS.add(roleDepartmentDataResourceVO);
        List<Role> userRoles = new ArrayList<>();
        Role role = new Role();
        role.setAccountId(accountId);
        role.setName("111");

        List<DepartmentNode> topDepartment = new ArrayList<>();
        DepartmentNode departmentNode = new DepartmentNode();
        departmentNode.setName("aaaa");
        departmentNode.setId(1L);
        departmentNode.setLevel("0");
        topDepartment.add(departmentNode);
        when(departmentDataResourceDao.listDepartmentDataByUserId(anyLong(), anyLong())).thenReturn(roleDepartmentDataResourceVOS);
        when(departmentDao.getTopDepartments(anyLong(), anyLong(), anyInt())).thenReturn(topDepartment);
        List<DepartmentNode> departments = new ArrayList<>();
        departments.add(departmentNode);
        Mockito.when(departmentDao.getDepartmentByIds(Mockito.anyList(), Mockito.anyLong(), Mockito.anyInt())).thenReturn(departments);
        User user = new User();
        user.setDepartmentId(1L);
        Mockito.when(userDao.getUser(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyBoolean())).thenReturn(user);
        List<DepartmentNode> departmentNodes = Whitebox.invokeMethod(dataV2ServiceImpl, "getTopDepartmentsAuthed", accountId, userId, status);

        Assert.assertTrue(departmentNodes.size() != 0);
    }


    @Test
    public void getDataAuthInfoByRoles() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        String dataType = "0";

        Mockito.when(userService.isExistSuperAdminByRoleIds(Mockito.anyList())).thenReturn(true);


        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthenticationByRole", Mockito.anyLong(), Mockito.anySet(), ArgumentMatchers.anyString(), Mockito.anyBoolean());
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthenticationByRole", Mockito.anyLong(), Mockito.anySet(), ArgumentMatchers.anyString(), Mockito.anyBoolean());

        List<Map<String, String>> allMultiType = new ArrayList<>();
        Map<String, String> multiType = new HashMap<>();
        multiType.put("data_type", "1");
        allMultiType.add(multiType);
        Mockito.when(multiTypeDataResourceDao.getAllMultiType("", true)).thenReturn(allMultiType);


        Map<String, List<DataAuthentication>> retData = Whitebox.invokeMethod(privateMethod, "getDataAuthInfoByRoles", accountId, roleIdSet, dataType);
        Assert.assertTrue(retData.size() != 0);
    }


    @Test
    public void getDataAuthInfo() throws Exception {
        Long accountId = 110L;
        Long userId = 1L;
        String dataType = "0";
        List<String> roleIdList = new ArrayList<>();

        Mockito.when(groupRoleRelationDao.listRoleIdByUserId(Mockito.anyLong(), Mockito.anyLong())).thenReturn(roleIdList);
        Mockito.when(userService.isSuperAdmin(Mockito.anyLong(), Mockito.anyLong())).thenReturn(true);
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthenticationByRole", Mockito.anyLong(), Mockito.anySet(), ArgumentMatchers.anyString(), Mockito.anyBoolean());
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthenticationByRole", Mockito.anyLong(), Mockito.anySet(), ArgumentMatchers.anyString(), Mockito.anyBoolean());


        Map<String, List<DataAuthentication>> retData = Whitebox.invokeMethod(privateMethod, "getDataAuthInfo", accountId, userId, dataType);
        Assert.assertTrue(retData.size() != 0);
    }

    @Test
    public void getDataAuthenticationByRole() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        roleIdSet.add("1111");
        String model = "bizData";
        boolean isAdmin = true;
        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setAuth("122");
        dataAuthentication.setCode("111");
        dataAuthentication.setName("2343");
        dataAuthentication.setCurrentRead(true);
        dataAuthentication.setMaintenance(true);
        dataAuthentications.add(dataAuthentication);
        Mockito.when(dataResourceDao.listDataAuthentication(Mockito.anyList())).thenReturn(dataAuthentications);
        Mockito.when(dataResourceDao.listDataAuthenticationByRoles(Mockito.anyString(), Mockito.anySet())).thenReturn(dataAuthentications);
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthentications", Mockito.anyList(), Mockito.anyInt());

        List<DataAuthentication> result = Whitebox.invokeMethod(privateMethod, "getDataAuthenticationByRole", accountId, roleIdSet, model, isAdmin);

        Assert.assertTrue(result.size() != 0);
    }

    @Test
    public void getDataAuthenticationByRoleModelData() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        roleIdSet.add("1111");
        String model = "modelData";
        boolean isAdmin = false;

        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setAuth("122");
        dataAuthentication.setCode("111");
        dataAuthentication.setName("2343");
        dataAuthentication.setCurrentRead(true);
        dataAuthentication.setMaintenance(true);
        dataAuthentications.add(dataAuthentication);
        Mockito.when(dataResourceDao.listDataAuthentication(Mockito.anyList())).thenReturn(dataAuthentications);
        Mockito.when(dataResourceDao.listDataAuthenticationByRoles(Mockito.anyString(), Mockito.anySet())).thenReturn(dataAuthentications);
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthentications", Mockito.anyList(), Mockito.anyInt());

        List<DataAuthentication> result = Whitebox.invokeMethod(privateMethod, "getDataAuthenticationByRole", accountId, roleIdSet, model, isAdmin);

        Assert.assertTrue(result.size() != 0);
    }

    @Test
    public void getDataAuthenticationByRoleModelDataAdmin() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        roleIdSet.add("1111");
        String model = "modelData";
        boolean isAdmin = true;

        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setAuth("122");
        dataAuthentication.setCode("111");
        dataAuthentication.setName("2343");
        dataAuthentication.setCurrentRead(true);
        dataAuthentication.setMaintenance(true);
        dataAuthentications.add(dataAuthentication);
        Mockito.when(dataResourceDao.listDataAuthentication(Mockito.anyList())).thenReturn(dataAuthentications);
        Mockito.when(dataResourceDao.listDataAuthenticationByRoles(Mockito.anyString(), Mockito.anySet())).thenReturn(dataAuthentications);
        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthentications", Mockito.anyList(), Mockito.anyInt());

        List<DataAuthentication> result = Whitebox.invokeMethod(privateMethod, "getDataAuthenticationByRole", accountId, roleIdSet, model, isAdmin);

        Assert.assertTrue(result.size() != 0);
    }

    @Test
    public void getModelDataAuthentication() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        Long userId = 1L;
        String dataType = "1";
        boolean superAdmin = true;


        List<DataAuthentication> cachedRetData = null;
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setMaintenance(true);
        dataAuthentication.setAuth("21");
        dataAuthentication.setName("23");
        Mockito.when(dataResourceCache.getDataAuthByUserIdAndTypeFromCache(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anyString())).thenReturn(cachedRetData);

        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        dataAuthentications.add(dataAuthentication);
        when(modelDataResourceDao.listDataAuthentication(anyString())).thenReturn(dataAuthentications);
        when(modelDataResourceDao.listDataAuthenticationByRoles(anyString(), anySet())).thenReturn(dataAuthentications);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthentications", Mockito.anyList(), Mockito.anyInt());
        PowerMockito.doNothing().when(privateMethod, "setAllAuth", Mockito.anyList(), Mockito.anyInt());

        List<DataAuthentication> result = Whitebox.invokeMethod(privateMethod, "getModelDataAuthentication", accountId, roleIdSet, userId, dataType, superAdmin);

        Assert.assertTrue(result.size() != 0);
    }


    @Test
    public void getBizDataAuthentication() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        Long userId = 1L;
        String dataType = "2";
        boolean superAdmin = true;

        List<DataAuthentication> cachedRetData = null;
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setMaintenance(true);
        dataAuthentication.setAuth("21");
        dataAuthentication.setName("23");
        Mockito.when(dataResourceCache.getDataAuthByUserIdAndTypeFromCache(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anyString())).thenReturn(cachedRetData);

        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        dataAuthentications.add(dataAuthentication);
        Mockito.when(dataResourceDao.listDataAuthentication(Mockito.anyList())).thenReturn(dataAuthentications);
        Mockito.when(dataResourceDao.listDataAuthenticationByRoles(Mockito.anyString(), Mockito.anySet())).thenReturn(dataAuthentications);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthentications", Mockito.anyList(), Mockito.anyInt());
        PowerMockito.doNothing().when(privateMethod, "setAllAuth", Mockito.anyList(), Mockito.anyInt());
        List<DataAuthentication> result = Whitebox.invokeMethod(privateMethod, "getBizDataAuthentication", accountId, roleIdSet, userId, dataType, superAdmin);

        Assert.assertTrue(result.size() != 0);
    }

    @Test
    public void getOtherAuthentication() throws Exception {
        Long accountId = 110L;
        HashSet<String> roleIdSet = new HashSet<>();
        Long userId = 1L;
        String dataType = "2";
        boolean superAdmin = true;

        List<DataAuthentication> cachedRetData = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setMaintenance(true);
        dataAuthentication.setAuth("21");
        dataAuthentication.setName("23");
        Mockito.when(dataResourceCache.getDataAuthByUserIdAndTypeFromCache(Mockito.anyLong(), Mockito.anyLong(), ArgumentMatchers.anyString())).thenReturn(cachedRetData);

        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        dataAuthentications.add(dataAuthentication);
        Mockito.when(logDataResourceDao.listDataAuthentication(Mockito.anyList(), ArgumentMatchers.anyString())).thenReturn(dataAuthentications);

        DataV2ServiceImpl privateMethod = PowerMockito.spy(this.dataV2ServiceImpl);
        PowerMockito.doReturn(dataAuthentications).when(privateMethod, "getDataAuthentications", Mockito.anyList(), Mockito.anyInt());
        PowerMockito.doNothing().when(privateMethod, "setAllAuth", Mockito.anyList(), Mockito.anyInt());
        List<DataAuthentication> result = Whitebox.invokeMethod(privateMethod, "getOtherAuthentication", accountId, roleIdSet, userId, dataType, superAdmin);

        Assert.assertTrue(result.size() != 0);
    }


    @Test
    public void setAllAuth() throws Exception {
        List<DataAuthentication> authenticationList = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setName("1qe");
        authenticationList.add(dataAuthentication);

        Whitebox.invokeMethod(dataV2ServiceImpl, "setAllAuth", authenticationList, 1);

        Assert.assertEquals("1111", authenticationList.get(0).getAuth());
    }


    @Test
    public void removeEmptyAuth() throws Exception {
        List<DataAuthentication> dataAuthentications = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setAuth("0000");
        dataAuthentications.add(dataAuthentication);

        Whitebox.invokeMethod(dataV2ServiceImpl, "removeEmptyAuth", dataAuthentications);
        Assert.assertEquals(0, dataAuthentications.size());
    }

    @Test
    public void getDataAuthentications() throws Exception {

        List<DataAuthentication> data = new ArrayList<>();
        DataAuthentication dataAuthentication = new DataAuthentication();
        dataAuthentication.setParentCode("1");
        dataAuthentication.setCode("222");
        data.add(dataAuthentication);
        int type = 1;


        Whitebox.invokeMethod(dataV2ServiceImpl, "getDataAuthentications", data, type);

        Assert.assertEquals(1, data.size());
    }


    @Test
    public void checkResourceBizDataMapListNoHaveResourceBizDataByCode() throws Exception {
        List<ResourceBizData> resourceBizDataMapList = new ArrayList<>();
        String code = "12";
        ResourceBizData resourceBizData = new ResourceBizData();
        resourceBizData.setAccountId("110");
        resourceBizData.setCode(code);
        resourceBizData.setId("1");
        resourceBizDataMapList.add(resourceBizData);
        boolean result = Whitebox.invokeMethod(dataV2ServiceImpl, "checkResourceBizDataMapListNoHaveResourceBizDataByCode", resourceBizDataMapList, code);
        Assert.assertFalse(result);
    }


    @Test
    public void buildBizDataTree() throws Exception {
        List<ResourceBizData> resourceBizDataList = new ArrayList<>();
        Map<String, List<ResourceBizData>> sameCodeResourceBizDataList = new HashMap<>();

        ResourceBizData resourceBizData = new ResourceBizData();
        resourceBizData.setId("1");
        resourceBizData.setCode("22");
        resourceBizData.setDescription("哈哈哈");
        resourceBizData.setIsRead(true);
        resourceBizDataList.add(resourceBizData);
        sameCodeResourceBizDataList.put("33", resourceBizDataList);
        ResourceBizData resourceBizData1 = new ResourceBizData();
        resourceBizData1.setId("2");
        resourceBizData1.setCode("331");
        resourceBizData1.setDescription("xixi");
        resourceBizData1.setIsRead(true);
        resourceBizDataList.add(resourceBizData1);
        Whitebox.invokeMethod(dataV2ServiceImpl, "buildBizDataTree", resourceBizDataList, sameCodeResourceBizDataList);
        Assert.assertTrue(resourceBizDataList.size() != 0);
    }


    @Test
    public void buildModelDataTree() throws Exception {
        List<ModelDataVO> resourceDataResultList = new ArrayList<>();
        Map<String, List<ModelDataVO>> sameCodeResourceDataList = new HashMap<>();
        ModelDataVO modelDataVO = new ModelDataVO();
        modelDataVO.setCode("11");
        resourceDataResultList.add(modelDataVO);

        sameCodeResourceDataList.put("2", resourceDataResultList);
        Whitebox.invokeMethod(dataV2ServiceImpl, "buildModelDataTree", resourceDataResultList, sameCodeResourceDataList);

        Assert.assertTrue(resourceDataResultList.size() != 0);
    }

    @Test
    public void getAllMultiType() throws Exception {
        Long accountId = 110L;
        List<Map<String, String>> allMultiType = new ArrayList<>();
        Map<String, String> multiType = new HashMap<>();
        multiType.put("1", "11");
        multiType.put("2", "22");
        allMultiType.add(multiType);
        Mockito.when(multiTypeDataResourceDao.getAllMultiType("", true)).thenReturn(allMultiType);

        List<Map<String, String>> result = Whitebox.invokeMethod(dataV2ServiceImpl, "getAllMultiType", accountId);
        Assert.assertTrue(result.size() != 0);
    }

    @Test
    public void thransEnglishName() throws Exception {
        RoleDepartmentDataResourceVO departmentDataResource = new RoleDepartmentDataResourceVO();
        String language = "EN";
        departmentDataResource.setCode("1");
        Whitebox.invokeMethod(dataV2ServiceImpl, "thransEnglishName", departmentDataResource, language);

    }
}
