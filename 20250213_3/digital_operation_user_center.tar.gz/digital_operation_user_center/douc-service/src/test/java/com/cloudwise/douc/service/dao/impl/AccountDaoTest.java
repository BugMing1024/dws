package com.cloudwise.douc.service.dao.impl;

import com.cloudwise.douc.metadata.activerecord.VisibleAccountDO;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.metadata.model.quota.AccountQuotaInfo;
import com.cloudwise.douc.service.dao.base.UnitTestBaseDao;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author bradyliu
 * @description: 测试 IAccountDao内容
 * @date Created in 15:34 2021/7/7.
 */
public class AccountDaoTest extends UnitTestBaseDao {
    @Resource
    static IAccountDao accountDaoImpl;

    @Test
    @Rollback(false)
    public void getAccountDetailList() {
        Long id = 1L;
    }

    @Test
    @Rollback(false)
    public void getUserIdAndUserLevelList() {

        Long accountId = 1L;
        List<UserCountDO> userIdAndUserLevelList = this.accountDaoImpl.getUserIdAndUserLevelList(accountId);
        boolean notEmpty = CollectionUtils.isNotEmpty(userIdAndUserLevelList);
        Assert.assertEquals(true, notEmpty);

    }

    @Test
    @Rollback(false)
    public void getVisibleAccountList() {
        Long tenantId = 1L;
        Long accountId = 32L;
        List<Long> visibleAccountIds = new ArrayList();
        visibleAccountIds.add(10L); // 可见租户accountId
        List<VisibleAccountDO> visibleAccountList = this.accountDaoImpl.getVisibleAccountList(tenantId, accountId, visibleAccountIds);

        boolean notEmpty = CollectionUtils.isNotEmpty(visibleAccountList) && visibleAccountList.size() == 1;
        Assert.assertEquals(true, notEmpty);
    }


    /**
     * @description 测试getVisibleAccountInfoList接口，通过accountId租户获取到可见租户详细信息
     * @author brady.liu
     * @date 2021/7/20
     * @time 16:58
     */
    @Test
    @Rollback(false)
    public void getVisibleAccountInfoList() {
        Long accountId = 30L;
        List<AccountDetail> visibleAccountInfoList = this.accountDaoImpl.getVisibleAccountInfoList(accountId);
        boolean notEmpty = CollectionUtils.isNotEmpty(visibleAccountInfoList);
        Assert.assertEquals(true, notEmpty);
    }

    @Test
    @Rollback(false)
    public void updateAccountList() {
        List<AccountDetail> accounts = new ArrayList();
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setName("test");
        accountDetail.setParentId(1L);
        accountDetail.setTopId(1L);
        accountDetail.setLevel("0.1");
        accountDetail.setVisibleScope(1);
        accountDetail.setIsTop(2);
        accountDetail.setStatus(1);
        accountDetail.setId(32L);
        accounts.add(accountDetail);
        Integer integer = this.accountDaoImpl.updateAccountList(accounts);

        Assert.assertEquals(1, integer.intValue());
    }

    @Test
    @Rollback(false)
    public void getUpdateStatusAccountIds() {

        List<Long> accoutIds = this.accountDaoImpl.getUpdateStatusAccountIds(Arrays.asList(2L), 110L);
        boolean b = Objects.nonNull(accoutIds);
        Assert.assertEquals(true, b);
    }

    @Test
    @Rollback(false)
    public void getUserAccountRelation() {

        List<UserCountDO> userCountDO = this.accountDaoImpl.getUserAccountRelation(32L, Arrays.asList(44L));
        boolean b = Objects.nonNull(userCountDO);
        Assert.assertEquals(true, b);
    }


    /**
     * @description 查询配额信息内容
     * @author brady.liu
     * @date 2021/10/9
     * @time 18:10
     */
    @Test
    @Rollback(false)
    public void getAccountQuotaInfo() {

        AccountQuotaInfo aqi = this.accountDaoImpl.getAccountQuotaInfo(110L);
        boolean b = Objects.nonNull(aqi);
        Assert.assertEquals(true, b);
    }

    /**
     * 新增配额内容
     *
     * @return
     */
    @Test
    @Rollback(false)
    public void addAccountQuotaInfo() {
        AccountQuotaInfo aqi = new AccountQuotaInfo();
        aqi.setIssued(new Date());
        aqi.setCreateUserId(2L);
        aqi.setModifyUserId(2L);
        aqi.setCreateTime(new Date());
        aqi.setModifyTime(new Date());
        aqi.setAccountName("yunzhihui");
        aqi.setAccountId(110L);
        Integer count = this.accountDaoImpl.addAccountQuotaInfo(aqi);
        boolean b = Objects.nonNull(count);
        Assert.assertEquals(true, b);
    }

    /**
     * @description 修改配额内容
     * @author brady.liu
     * @date 2021/10/11
     * @time 11:09
     */
    @Test
    @Rollback(false)
    public void updateAccountQuotaInfo() {
        AccountQuotaInfo aqi = new AccountQuotaInfo();
        aqi.setIssued(new Date());
        aqi.setCreateUserId(2L);
        aqi.setModifyUserId(2L);
        aqi.setCreateTime(new Date());
        aqi.setModifyTime(new Date());
        aqi.setAccountName("yunzhihui");
        aqi.setAccountId(110L);
        aqi.setId(1L);
        Integer count = this.accountDaoImpl.updateAccountQuotaInfo(aqi);
        boolean b = Objects.nonNull(count);
        Assert.assertEquals(true, b);
    }

    /**
     * @description 查询所有租户的配额缓存
     * @author brady.liu
     * @date 2021/10/12
     * @time 16:25
     */
    @Test
    @Rollback(false)
    public void getAllAccountQuotaInfo() {

        List<AccountQuotaInfo> aqis = this.accountDaoImpl.getAllAccountQuotaInfo();
        boolean b = Objects.nonNull(aqis);
        Assert.assertEquals(true, b);
    }

}
