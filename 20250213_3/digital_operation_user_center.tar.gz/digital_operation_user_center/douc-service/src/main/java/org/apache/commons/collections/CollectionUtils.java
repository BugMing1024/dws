package org.apache.commons.collections;

import java.util.Collection;

/**
 * @author bernie.wang
 * @description: 兼容rocketmq AbstractAllocateMessageQueueStrategy
 * @date Created in 14:37 2023/5/22.
 */
public class CollectionUtils {

    public static boolean isEmpty(Collection<?> coll) {
        return coll == null || coll.isEmpty();
    }

}
