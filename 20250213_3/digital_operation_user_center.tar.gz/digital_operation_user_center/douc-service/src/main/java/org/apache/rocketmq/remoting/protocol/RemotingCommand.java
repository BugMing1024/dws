package org.apache.rocketmq.remoting.protocol;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.rocketmq.logging.InternalLogger;
import org.apache.rocketmq.logging.InternalLoggerFactory;
import org.apache.rocketmq.remoting.CommandCustomHeader;
import org.apache.rocketmq.remoting.annotation.CFNotNull;
import org.apache.rocketmq.remoting.exception.RemotingCommandException;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class RemotingCommand {
    public static final String SERIALIZE_TYPE_PROPERTY = "rocketmq.serialize.type";
    public static final String SERIALIZE_TYPE_ENV = "ROCKETMQ_SERIALIZE_TYPE";
    public static final String REMOTING_VERSION_KEY = "rocketmq.remoting.version";
    static final InternalLogger log = InternalLoggerFactory.getLogger("RocketmqRemoting");
    private static final int RPC_TYPE = 0;
    private static final int RPC_ONEWAY = 1;
    private static final Map<Class<? extends CommandCustomHeader>, Field[]> CLASS_HASH_MAP = new HashMap();
    private static final Map<Class, String> CANONICAL_NAME_CACHE = new HashMap();
    private static final Map<Field, Boolean> NULLABLE_FIELD_CACHE = new HashMap();
    private static final String STRING_CANONICAL_NAME = String.class.getCanonicalName();
    private static final String DOUBLE_CANONICAL_NAME_1 = Double.class.getCanonicalName();
    private static final String DOUBLE_CANONICAL_NAME_2;
    private static final String INTEGER_CANONICAL_NAME_1;
    private static final String INTEGER_CANONICAL_NAME_2;
    private static final String LONG_CANONICAL_NAME_1;
    private static final String LONG_CANONICAL_NAME_2;
    private static final String BOOLEAN_CANONICAL_NAME_1;
    private static final String BOOLEAN_CANONICAL_NAME_2;
    private static volatile int configVersion;
    private static AtomicInteger requestId;
    private static SerializeType serializeTypeConfigInThisServer;
    private int code;
    private LanguageCode language;
    private int version;
    private int opaque;
    private int flag;
    private String remark;
    private HashMap<String, String> extFields;
    private transient CommandCustomHeader customHeader;
    private SerializeType serializeTypeCurrentRPC;
    private transient byte[] body;

    protected RemotingCommand() {
        this.language = LanguageCode.JAVA;
        this.version = 0;
        this.opaque = requestId.getAndIncrement();
        this.flag = 0;
        this.serializeTypeCurrentRPC = serializeTypeConfigInThisServer;
    }

    public static RemotingCommand createRequestCommand(int code, CommandCustomHeader customHeader) {
        RemotingCommand cmd = new RemotingCommand();
        cmd.setCode(code);
        cmd.customHeader = customHeader;
        setCmdVersion(cmd);
        return cmd;
    }

    private static void setCmdVersion(RemotingCommand cmd) {
        if (configVersion >= 0) {
            cmd.setVersion(configVersion);
        } else {
            String v = System.getProperty("rocketmq.remoting.version");
            if (v != null) {
                int value = Integer.parseInt(v);
                cmd.setVersion(value);
                configVersion = value;
            }
        }

    }

    public static RemotingCommand createResponseCommand(Class<? extends CommandCustomHeader> classHeader) {
        return createResponseCommand(1, "not set any response code", classHeader);
    }

    public static RemotingCommand createResponseCommand(int code, String remark, Class<? extends CommandCustomHeader> classHeader) {
        RemotingCommand cmd = new RemotingCommand();
        cmd.markResponseType();
        cmd.setCode(code);
        cmd.setRemark(remark);
        setCmdVersion(cmd);
        if (classHeader != null) {
            try {
                CommandCustomHeader objectHeader = (CommandCustomHeader)classHeader.getDeclaredConstructor().newInstance();
                cmd.customHeader = objectHeader;
            } catch (InstantiationException var5) {
                return null;
            } catch (IllegalAccessException var6) {
                return null;
            } catch (InvocationTargetException var7) {
                return null;
            } catch (NoSuchMethodException var8) {
                return null;
            }
        }

        return cmd;
    }

    public static RemotingCommand createResponseCommand(int code, String remark) {
        return createResponseCommand(code, remark, (Class)null);
    }

    public static RemotingCommand decode(byte[] array) throws RemotingCommandException {
        ByteBuffer byteBuffer = ByteBuffer.wrap(array);
        return decode(byteBuffer);
    }

    public static RemotingCommand decode(ByteBuffer byteBuffer) throws RemotingCommandException {
        return decode(Unpooled.wrappedBuffer(byteBuffer));
    }

    public static RemotingCommand decode(ByteBuf byteBuffer) throws RemotingCommandException {
        int length = byteBuffer.readableBytes();
        int oriHeaderLen = byteBuffer.readInt();
        int headerLength = getHeaderLength(oriHeaderLen);
        if (headerLength > length - 4) {
            throw new RemotingCommandException("decode error, bad header length: " + headerLength);
        } else {
            RemotingCommand cmd = headerDecode(byteBuffer, headerLength, getProtocolType(oriHeaderLen));
            int bodyLength = length - 4 - headerLength;
            byte[] bodyData = null;
            if (bodyLength > 0) {
                bodyData = new byte[bodyLength];
                byteBuffer.readBytes(bodyData);
            }

            cmd.body = bodyData;
            return cmd;
        }
    }

    public static int getHeaderLength(int length) {
        return length & 16777215;
    }

    private static RemotingCommand headerDecode(ByteBuf byteBuffer, int len, SerializeType type) throws RemotingCommandException {
        switch(type) {
            case JSON:
                byte[] headerData = new byte[len];
                byteBuffer.readBytes(headerData);
                RemotingCommand resultJson = (RemotingCommand)RemotingSerializable.decode(headerData, RemotingCommand.class);
                resultJson.setSerializeTypeCurrentRPC(type);
                return resultJson;
            case ROCKETMQ:
                RemotingCommand resultRMQ = RocketMQSerializable.rocketMQProtocolDecode(byteBuffer, len);
                resultRMQ.setSerializeTypeCurrentRPC(type);
                return resultRMQ;
            default:
                return null;
        }
    }

    public static SerializeType getProtocolType(int source) {
        return SerializeType.valueOf((byte)(source >> 24 & 255));
    }

    public static int createNewRequestId() {
        return requestId.getAndIncrement();
    }

    public static SerializeType getSerializeTypeConfigInThisServer() {
        return serializeTypeConfigInThisServer;
    }

    private static boolean isBlank(String str) {
        int strLen;
        if (str != null && (strLen = str.length()) != 0) {
            for(int i = 0; i < strLen; ++i) {
                if (!Character.isWhitespace(str.charAt(i))) {
                    return false;
                }
            }

            return true;
        } else {
            return true;
        }
    }

    public static int markProtocolType(int source, SerializeType type) {
        return type.getCode() << 24 | source & 16777215;
    }

    public void markResponseType() {
        int bits = 1;
        this.flag |= bits;
    }

    public CommandCustomHeader readCustomHeader() {
        return this.customHeader;
    }

    public void writeCustomHeader(CommandCustomHeader customHeader) {
        this.customHeader = customHeader;
    }

    public CommandCustomHeader decodeCommandCustomHeader(Class<? extends CommandCustomHeader> classHeader) throws RemotingCommandException {
        return this.decodeCommandCustomHeader(classHeader, true);
    }

    public CommandCustomHeader decodeCommandCustomHeader(Class<? extends CommandCustomHeader> classHeader, boolean useFastEncode) throws RemotingCommandException {
        CommandCustomHeader objectHeader;
        try {
            objectHeader = (CommandCustomHeader)classHeader.getDeclaredConstructor().newInstance();
        } catch (InstantiationException var13) {
            return null;
        } catch (IllegalAccessException var14) {
            return null;
        } catch (InvocationTargetException var15) {
            return null;
        } catch (NoSuchMethodException var16) {
            return null;
        }

        if (this.extFields != null) {
            if (objectHeader instanceof FastCodesHeader && useFastEncode) {
                ((FastCodesHeader)objectHeader).decode(this.extFields);
                objectHeader.checkFields();
                return objectHeader;
            }

            Field[] fields = this.getClazzFields(classHeader);
            Field[] var5 = fields;
            int var6 = fields.length;

            for(int var7 = 0; var7 < var6; ++var7) {
                Field field = var5[var7];
                if (!Modifier.isStatic(field.getModifiers())) {
                    String fieldName = field.getName();
                    if (!fieldName.startsWith("this")) {
                        try {
                            String value = (String)this.extFields.get(fieldName);
                            if (null == value) {
                                if (!this.isFieldNullable(field)) {
                                    throw new RemotingCommandException("the custom field <" + fieldName + "> is null");
                                }
                            } else {
                                field.setAccessible(true);
                                String type = this.getCanonicalName(field.getType());
                                Object valueParsed;
                                if (type.equals(STRING_CANONICAL_NAME)) {
                                    valueParsed = value;
                                } else if (!type.equals(INTEGER_CANONICAL_NAME_1) && !type.equals(INTEGER_CANONICAL_NAME_2)) {
                                    if (!type.equals(LONG_CANONICAL_NAME_1) && !type.equals(LONG_CANONICAL_NAME_2)) {
                                        if (!type.equals(BOOLEAN_CANONICAL_NAME_1) && !type.equals(BOOLEAN_CANONICAL_NAME_2)) {
                                            if (!type.equals(DOUBLE_CANONICAL_NAME_1) && !type.equals(DOUBLE_CANONICAL_NAME_2)) {
                                                throw new RemotingCommandException("the custom field <" + fieldName + "> type is not supported");
                                            }

                                            valueParsed = Double.valueOf(value);
                                        } else {
                                            valueParsed = Boolean.valueOf(value);
                                        }
                                    } else {
                                        valueParsed = Long.valueOf(value);
                                    }
                                } else {
                                    valueParsed = Integer.valueOf(value);
                                }

                                field.set(objectHeader, valueParsed);
                            }
                        } catch (Throwable var17) {
                            log.error("Failed field [{}] decoding", fieldName, var17);
                        }
                    }
                }
            }

            objectHeader.checkFields();
        }

        return objectHeader;
    }

    private Field[] getClazzFields(Class<? extends CommandCustomHeader> classHeader) {
        Field[] field = (Field[])CLASS_HASH_MAP.get(classHeader);
        if (field == null) {
            field = classHeader.getDeclaredFields();
            synchronized(CLASS_HASH_MAP) {
                CLASS_HASH_MAP.put(classHeader, field);
            }
        }

        return field;
    }

    private boolean isFieldNullable(Field field) {
        if (!NULLABLE_FIELD_CACHE.containsKey(field)) {
            Annotation annotation = field.getAnnotation(CFNotNull.class);
            synchronized(NULLABLE_FIELD_CACHE) {
                NULLABLE_FIELD_CACHE.put(field, annotation == null);
            }
        }

        return (Boolean)NULLABLE_FIELD_CACHE.get(field);
    }

    private String getCanonicalName(Class clazz) {
        String name = (String)CANONICAL_NAME_CACHE.get(clazz);
        if (name == null) {
            name = clazz.getCanonicalName();
            synchronized(CANONICAL_NAME_CACHE) {
                CANONICAL_NAME_CACHE.put(clazz, name);
            }
        }

        return name;
    }

    public ByteBuffer encode() {
        int length = 4;
        byte[] headerData = this.headerEncode();
        length = length + headerData.length;
        if (this.body != null) {
            length += this.body.length;
        }

        ByteBuffer result = ByteBuffer.allocate(4 + length);
        result.putInt(length);
        result.putInt(markProtocolType(headerData.length, this.serializeTypeCurrentRPC));
        result.put(headerData);
        if (this.body != null) {
            result.put(this.body);
        }

        result.flip();
        return result;
    }

    private byte[] headerEncode() {
        this.makeCustomHeaderToNet();
        return SerializeType.ROCKETMQ == this.serializeTypeCurrentRPC ? RocketMQSerializable.rocketMQProtocolEncode(this) : RemotingSerializable.encode(this);
    }

    public void makeCustomHeaderToNet() {
        if (this.customHeader != null) {
            Field[] fields = this.getClazzFields(this.customHeader.getClass());
            if (null == this.extFields) {
                this.extFields = new HashMap();
            }

            Field[] var2 = fields;
            int var3 = fields.length;

            for(int var4 = 0; var4 < var3; ++var4) {
                Field field = var2[var4];
                if (!Modifier.isStatic(field.getModifiers())) {
                    String name = field.getName();
                    if (!name.startsWith("this")) {
                        Object value = null;

                        try {
                            field.setAccessible(true);
                            value = field.get(this.customHeader);
                        } catch (Exception var9) {
                            log.error("Failed to access field [{}]", name, var9);
                        }

                        if (value != null) {
                            this.extFields.put(name, value.toString());
                        }
                    }
                }
            }
        }

    }

    public void fastEncodeHeader(ByteBuf out) {
        int bodySize = this.body != null ? this.body.length : 0;
        int beginIndex = out.writerIndex();
        out.writeLong(0L);
        int headerSize;
        if (SerializeType.ROCKETMQ == this.serializeTypeCurrentRPC) {
            if (this.customHeader != null && !(this.customHeader instanceof FastCodesHeader)) {
                this.makeCustomHeaderToNet();
            }

            headerSize = RocketMQSerializable.rocketMQProtocolEncode(this, out);
        } else {
            this.makeCustomHeaderToNet();
            byte[] header = RemotingSerializable.encode(this);
            headerSize = header.length;
            out.writeBytes(header);
        }

        out.setInt(beginIndex, 4 + headerSize + bodySize);
        out.setInt(beginIndex + 4, markProtocolType(headerSize, this.serializeTypeCurrentRPC));
    }

    public ByteBuffer encodeHeader() {
        return this.encodeHeader(this.body != null ? this.body.length : 0);
    }

    public ByteBuffer encodeHeader(int bodyLength) {
        int length = 4;
        byte[] headerData = this.headerEncode();
        length = length + headerData.length;
        length += bodyLength;
        ByteBuffer result = ByteBuffer.allocate(4 + length - bodyLength);
        result.putInt(length);
        result.putInt(markProtocolType(headerData.length, this.serializeTypeCurrentRPC));
        result.put(headerData);
        result.flip();
        return result;
    }

    public void markOnewayRPC() {
        int bits = 2;
        this.flag |= bits;
    }


    @JsonIgnore
    public boolean isOnewayRPC() {
        int bits = 2;
        return (this.flag & bits) == bits;
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @JsonIgnore
    public RemotingCommandType getType() {
        return this.isResponseType() ? RemotingCommandType.RESPONSE_COMMAND : RemotingCommandType.REQUEST_COMMAND;
    }

    @JsonIgnore
    public boolean isResponseType() {
        int bits = 1;
        return (this.flag & bits) == bits;
    }

    public LanguageCode getLanguage() {
        return this.language;
    }

    public void setLanguage(LanguageCode language) {
        this.language = language;
    }

    public int getVersion() {
        return this.version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getOpaque() {
        return this.opaque;
    }

    public void setOpaque(int opaque) {
        this.opaque = opaque;
    }

    public int getFlag() {
        return this.flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public byte[] getBody() {
        return this.body;
    }

    public void setBody(byte[] body) {
        this.body = body;
    }

    public HashMap<String, String> getExtFields() {
        return this.extFields;
    }

    public void setExtFields(HashMap<String, String> extFields) {
        this.extFields = extFields;
    }

    public void addExtField(String key, String value) {
        if (null == this.extFields) {
            this.extFields = new HashMap();
        }

        this.extFields.put(key, value);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }

    public SerializeType getSerializeTypeCurrentRPC() {
        return this.serializeTypeCurrentRPC;
    }

    public void setSerializeTypeCurrentRPC(SerializeType serializeTypeCurrentRPC) {
        this.serializeTypeCurrentRPC = serializeTypeCurrentRPC;
    }

    static {
        DOUBLE_CANONICAL_NAME_2 = Double.TYPE.getCanonicalName();
        INTEGER_CANONICAL_NAME_1 = Integer.class.getCanonicalName();
        INTEGER_CANONICAL_NAME_2 = Integer.TYPE.getCanonicalName();
        LONG_CANONICAL_NAME_1 = Long.class.getCanonicalName();
        LONG_CANONICAL_NAME_2 = Long.TYPE.getCanonicalName();
        BOOLEAN_CANONICAL_NAME_1 = Boolean.class.getCanonicalName();
        BOOLEAN_CANONICAL_NAME_2 = Boolean.TYPE.getCanonicalName();
        configVersion = -1;
        requestId = new AtomicInteger(0);
        serializeTypeConfigInThisServer = SerializeType.JSON;
        String protocol = System.getProperty("rocketmq.serialize.type", System.getenv("ROCKETMQ_SERIALIZE_TYPE"));
        if (!isBlank(protocol)) {
            try {
                serializeTypeConfigInThisServer = SerializeType.valueOf(protocol);
            } catch (IllegalArgumentException var2) {
                throw new RuntimeException("parser specified protocol error. protocol=" + protocol, var2);
            }
        }

    }
}
