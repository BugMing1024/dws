package org.apache.rocketmq.client.consumer.store;

import com.cloudwise.douc.commons.utils.JsonUtils;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.KeyDeserializer;
import org.apache.rocketmq.common.message.MessageQueue;

import java.io.IOException;

/**
 * @author zafir.zhong
 * @description 专门给MessageQueue做的序反列化
 * @date Created in 17:33 2023/3/14.
 */
public class MapKeyDeserializer extends KeyDeserializer {

    @Override
    public Object deserializeKey(String s, DeserializationContext deserializationContext) throws IOException {
        return JsonUtils.decode(s, MessageQueue.class);
    }
}
