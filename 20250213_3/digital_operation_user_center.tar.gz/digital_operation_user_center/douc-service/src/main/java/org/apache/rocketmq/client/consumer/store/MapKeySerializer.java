package org.apache.rocketmq.client.consumer.store;

import com.cloudwise.douc.commons.utils.JsonUtils;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.rocketmq.common.message.MessageQueue;

import java.io.IOException;

/**
 * @author zafir.zhong
 * @description 专门给MessageQueue做的序列化
 * @date Created in 17:21 2023/3/14.
 */
public class MapKeySerializer extends JsonSerializer<MessageQueue> {
    @Override
    public void serialize(MessageQueue value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
        if (null == value) {
            throw new JsonGenerationException("Could not serialize object to json, input object to serialize is null");
        }
        jgen.writeFieldName(JsonUtils.encode(value));
    }
}
