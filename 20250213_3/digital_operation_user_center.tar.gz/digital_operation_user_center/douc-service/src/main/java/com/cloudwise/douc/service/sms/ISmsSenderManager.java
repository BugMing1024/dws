package com.cloudwise.douc.service.sms;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2021/8/6
 */
public interface ISmsSenderManager {

    ISmsSender getSmsSender(String id);

    void register(ISmsSender smsSender);
}
