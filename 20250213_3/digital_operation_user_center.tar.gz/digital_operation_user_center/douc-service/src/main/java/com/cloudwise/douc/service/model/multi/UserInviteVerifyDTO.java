package com.cloudwise.douc.service.model.multi;

import lombok.Data;

import java.io.Serializable;

/**
 * @author bradyliu
 * @description:
 * @date Created in 11:37 2021/7/16.
 */
@Data
public class UserInviteVerifyDTO implements Serializable {
    private String userName;
    private String inviteeEmail;
    private Long inviteeUserId;
}
