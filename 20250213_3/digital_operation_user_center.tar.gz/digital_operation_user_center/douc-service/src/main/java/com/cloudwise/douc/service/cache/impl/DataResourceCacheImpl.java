package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.model.data.DataAuthentication;
import com.cloudwise.douc.service.cache.IDataResourceCache;
import com.cloudwise.douc.service.util.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @description: 数据资源缓存
 * @author: jasonlee
 * @date: 2021-01-29 23:48
 **/
@Component
@Slf4j
public class DataResourceCacheImpl implements IDataResourceCache {

    @Override
    public List<DataAuthentication> getDataAuthByUserIdAndTypeFromCache(Long accountId, Long userId, String dataType) {
        String dataAuthCacheKey = getDataAuthCacheKey(accountId, userId.toString(), dataType);
        String dataAuthDirtyCacheKey = this.getDataAuthDirtyCacheKeyByDataType(accountId, dataType);
        Map<String, Object> map = RedisTools.getByte(dataAuthCacheKey, Map.class);
        Long dataAuthDirtyTime = RedisTools.getByte(dataAuthDirtyCacheKey, Long.class);
        if (map == null) {
            return null;
        }
        long dataTime = (Long) map.get("timestamp");
        List<DataAuthentication> dataAuthenticationList = (List<DataAuthentication>) map.get("data");
        if (dataAuthDirtyTime != null && dataAuthDirtyTime > dataTime) {
            return null;
        }
        return dataAuthenticationList;

    }

    @Override
    public void setDataAuthByUserIdAndTypeCacheDirty(Long accountId, String dataType) {
        //脏标识过期时间为数据缓存时间的1.1倍
        long dataAuthDirtyExpireTimeByDataType = (long) (Math.ceil(this.getDataAuthExpireTimeByDataType(dataType) * 1.1));
        long dirtyTime = System.currentTimeMillis();
        boolean ifSuccess = RedisTools.setByteWithTime(this.getDataAuthDirtyCacheKeyByDataType(accountId, dataType), dirtyTime, dataAuthDirtyExpireTimeByDataType);
        if (!ifSuccess) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }

    /**
     * description:生成数据权限根据类型的脏标识缓存key
     */
    private String getDataAuthDirtyCacheKeyByDataType(Long accountId, String dataType) {
        StringBuilder dataAuthDirtyCacheKey = new StringBuilder();
        dataAuthDirtyCacheKey.append(CacheConstant.DATA_AUTH_DIRTY_CACHE_PRE)
                .append(accountId)
                .append(StrPool.C_COLON)
                .append(dataType);
        return dataAuthDirtyCacheKey.toString();
    }


    /**
     * description:生成基于数据权限缓存key
     */
    private String getDataAuthCacheKey(Long accountId, String baseInfo, String dataType) {
        StringBuilder dataAuthCacheKey = new StringBuilder();
        dataAuthCacheKey.append(CacheConstant.DATA_AUTH_CACHE_PRE)
                .append(accountId)
                .append(StrPool.C_COLON)
                .append(baseInfo)
                .append(StrPool.C_COLON)
                .append(dataType);
        return dataAuthCacheKey.toString();
    }


    //获取数据权限对应数据类型过期时间
    private long getDataAuthExpireTimeByDataType(String dataType) {
        long cmdbTTL = ConfigUtils.getLong("auth.cache.data-cmdb-ttl", CacheConstant.DATA_AUTH_CMDB_DEFAULT_TTL);
        long otherTTL = ConfigUtils.getLong("auth.cache.data-other-ttl", CacheConstant.DATA_AUTH_OTHER_DEFAULT_TTL);
        long ddl = otherTTL;
        if (dataType.equals(Constant.DATAAUTH_DATATYPE_CMDB_BIZ) || dataType.equals(Constant.DATAAUTH_DATATYPE_CMDB_MODEL)) {
            ddl = cmdbTTL;
        }
        return ddl;
    }
}

