package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.google.common.collect.Maps;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author KenLiang
 * @description:
 * @date Created in 8:36 PM 2020/2/17.
 */
@Data
public class UserListRequestObject implements Serializable {
    private static final long serialVersionUID = 4718479074468814905L;

    public UserListRequestObject() {
        this.onlyDisplayMainDepartment = Boolean.TRUE;
        this.size = 20;
        this.current = 1;
    }

    private Long accountId;
    private Long userId;
    private Long departmentId;
    private String departmentLevel;
    private String aliasOrNameOrEmail;
    private String aliasOrName;
    private String extendValue;
    private String extendField;
    private Integer status;
    private Long roleId;
    private Long projectId;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;
    private Map<Long, String> departmentIdLevelMap = Maps.newHashMap();

    private String position;
    /**
     * 主次部门标记 1主部门
     */
    private Integer isMain;
    /**
     * 是否只显示主部门 true:只显示主部门
     **/
    private Boolean onlyDisplayMainDepartment;

    /**
     * 是否跨租户
     * 类型  all:查顶级租户 current或者null:查本租户的
     **/
    private String accountScope;

    private List<Long> userIdList;

    @ApiModelProperty("手机号 模糊搜索")
    private String mobile;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }

}
