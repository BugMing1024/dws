package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;


/**
 * @author maker.wang
 * @description:
 * @date Created in 6:32 下午 2022/1/6.
 */

@Component
@RefreshScope
@ConfigurationProperties(prefix = "login.wecom")
@Data
public class WeComConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    private String address;

    private List<LoginWeComConfig> config;

    @Data
    @ApiModel(value = "企业微信配置信息")
    public static class LoginWeComConfig implements Serializable {
        private static final long serialVersionUID = 1710470019121004269L;

        @ApiModelProperty(value = "租户id")
        private Long accountId;

        @ApiModelProperty(value = "企业微信企业id")
        private String corpId;

        @ApiModelProperty(value = "从企业微信中获取哪个字段的值 email/mobile/extattr.name")
        private String weComField;

        @ApiModelProperty(value = "weComField对应的字段在douc中是什么")
        private String doucField;

        @ApiModelProperty(value = "企业微信应用配置")
        private List<LoginWeComApp> appList;
    }

    @Data
    @ApiModel(value = "企业微信配置信息")
    public static class LoginWeComApp implements Serializable {
        private static final long serialVersionUID = 1710470019121004269L;

        @ApiModelProperty(value = "企业微信应用id")
        private String appId;

        @ApiModelProperty(value = "企业微信应用秘钥")
        private String appSecret;

        @ApiModelProperty(value = "从企业微信中获取哪个字段的值 email/mobile/extattr.name")
        private String appUri;

        @ApiModelProperty(value = "weComField对应的字段在douc中是什么")
        private String appType;

    }

}