package com.cloudwise.douc.service.constants.data;

/**
 * @author liweizhi
 * @date 2020/4/11 11:19
 */
public enum DataTreeType {
    /**
     * 以下分别是 根节点,数据类型,数据分组,数据
     */
    ROOT(1),
    DATA_TYPE(2),
    DATA_GROUP(3),
    DATA(4);
    private final int value;

    public int getValue() {
        return value;
    }

    DataTreeType(int value) {
        this.value = value;
    }
}
