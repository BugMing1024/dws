package com.cloudwise.douc.service.model.user;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class GroupAndRoleDto {

    private String group;

    private String role;

    private String positionRole;

    private String positionGroup;

    private String groupDepartment;

    private String roleDepartment;

    private String groupRole;

    private String userGroup;

    private String userDepartmentRole;

    private String userConditionGroupRole;

    private String userConditionGroup;

    public String getUserConditionGroupRole() {
        return StringUtils.isBlank(userConditionGroupRole) ? "" : userConditionGroupRole;
    }

    public String getUserConditionGroup() {
        return StringUtils.isBlank(userConditionGroup) ? "" : userConditionGroup;
    }

    public String getUserDepartmentRole() {
        return StringUtils.isBlank(userDepartmentRole) ? "" : userDepartmentRole;
    }

    public String getPositionRole() {
        return StringUtils.isBlank(positionRole) ? "" : positionRole;
    }

    public String getPositionGroup() {
        return StringUtils.isBlank(positionGroup) ? "" : positionGroup;
    }

    public String getGroupDepartment() {
        return StringUtils.isBlank(groupDepartment) ? "" : groupDepartment;
    }

    public String getRoleDepartment() {
        return StringUtils.isBlank(roleDepartment) ? "" : roleDepartment;
    }

    public String getGroupRole() {
        return StringUtils.isBlank(groupRole) ? "" : groupRole;
    }

    public String getUserGroup() {
        return StringUtils.isBlank(userGroup) ? "" : userGroup;
    }
}
