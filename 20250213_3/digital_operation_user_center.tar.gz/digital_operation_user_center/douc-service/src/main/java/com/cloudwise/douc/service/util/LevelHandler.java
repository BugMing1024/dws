package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.metadata.model.level.LevelComponent;

public class LevelHandler {

    public static String getLevel(LevelComponent levelComponent) {
        if (levelComponent == null) {
            return null;
        }
        Long id = levelComponent.getId();
        String level = levelComponent.getLevel();
        return level + StrPool.DOT + id;
    }

    public static String getLevel(String level, long id) {
        return level + StrPool.DOT + id;
    }

    public static String getNewLevel(String levelPrefix, String level, String levelOriginal) {
        String levelSuffix = level.substring(levelOriginal.length());
        return levelPrefix + levelSuffix;
    }

    public static int getLevelNum(String level) {
        int levelNum = level.split("\\.").length;
        return levelNum;
    }

}
