package com.cloudwise.douc.service.util;

import com.cloudwise.douc.commons.utils.JsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;

/**
 * @author
 * @date 2021-09-08 17:17
 */
@Slf4j
public class ApiUtils {


    /**
     * @Param LdapEntity ldapEntity
     * @Return
     * @Auth
     * @Date 2021-09-08 17:17
     */
    public static JsonNode getApiResponse() throws JsonProcessingException {
        String response = "{\"response\":[{\"parentCode\":\"105001\",\"name\":\"sql\",\"type\":\"string\",\"remark\":\"查询语句\",\"remarkEn\":\"Query statement\",\"code\":\"10500101\"},{\"parentCode\":\"105001\",\"name\":\"metaDataList\",\"type\":\"list\",\"remark\":\"元数据列表\",\"remarkEn\":\"Metadata list\",\"code\":\"10500102\",\"children\":[{\"parentCode\":\"10500102\",\"name\":\"metaDataList\",\"type\":\"string\",\"remark\":\"字段名\",\"remarkEn\":\"Field name\",\"code\":\"1050010201\"},{\"parentCode\":\"10500102\",\"name\":\"columnType\",\"type\":\"string\",\"remark\":\"字段类型\",\"remarkEn\":\"Field type\",\"code\":\"1050010202\"}]},{\"parentCode\":\"105001\",\"name\":\"results\",\"type\":\"list\",\"remark\":\"结果集\",\"remarkEn\":\"Result set\",\"code\":\"10500103\"},{\"parentCode\":\"105001\",\"name\":\"execTime\",\"type\":\"long\",\"remark\":\"执行时间（毫秒）\",\"remarkEn\":\"Execution time (ms)\",\"code\":\"10500104\"},{\"parentCode\":\"105001\",\"name\":\"select\",\"type\":\"boolean\",\"remark\":\"是否为查询语句\",\"remarkEn\":\"Query statement or not\",\"code\":\"10500105\"}]}";
        return JsonUtils.getJsonNode(response);
    }
}
