package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import com.cloudwise.douc.metadata.model.data.DataAuthentication;

import java.util.List;
import java.util.Map;

/**
 * @author ken.liang
 * @description:鉴权数据流类
 * @date Created in 11:11 AM 2021/6/24.
 */
public interface IAuthDataFlow {

    /**
     * @param accountId
     * @param moduleCode
     * @param roleIdTypeMapByUserIdAndAccountId
     * @return java.util.List<com.cloudwise.douc.service.model.auth.MenuResponse>
     * @description 查询多个角色id拥有的指定模块的菜单权限
     * @author ken.liang
     * @date 2021/6/23
     * @time 4:27 PM
     */
    List<MenuResponse> getMenuAuthedByModuleCodeAndRoleIds(Long accountId, String moduleCode, Map<Long, Integer> roleIdTypeMap, String language);

    /**
     * @param accountId
     * @param moduleCode
     * @param roleIds
     * @return void
     * @description 删除角色菜单权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:45 PM
     */
    void deleteMenuAuthedByRoleIds(Long accountId, List<String> moduleCodeList, List<Long> roleIds);

    /**
     * @param accountId
     * @param appCode
     * @param roleIds
     * @description 删除角色菜单权限
     */
    void deleteViewMenuAuthedByRoleIds(Long accountId, List<String> appCodeList, List<Long> roleIds);

    /**
     * @param accountId
     * @param moduleCodeList
     * @return void
     * @description 缓存角色菜单权限失效标记
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:45 PM
     */
    void setMenuAuthedByRoleIdsDirty(Long accountId, List<String> moduleCodeList);

    /**
     * @param accountId
     * @param appCodeList
     * @return void
     * @description 缓存角色菜单视图权限失效标记
     * @author bruce.liu
     * @date 2022/10/10
     * @time 7:45 PM
     */
    void setViewMenuAuthedByRoleIdsDirty(Long accountId, List<String> appCodeList);

    /**
     * @param accountId
     * @param roleIdTypeMap
     * @return java.util.List<com.cloudwise.douc.service.model.data.DataAuthentication>
     * @description 查询多个角色id拥有的业务数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 5:58 PM
     */
    List<DataAuthentication> getBizDataAuthedByRoleIds(Long accountId, Map<Long, Integer> roleIdTypeMap);

    /**
     * @param accountId
     * @param roleIdTypeMap
     * @return java.util.List<com.cloudwise.douc.service.model.data.DataAuthentication>
     * @description 查询多个角色id拥有的模型数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 5:58 PM
     */
    List<DataAuthentication> getModelDataAuthedByRoleIds(Long accountId, Map<Long, Integer> roleIdTypeMap);

    /**
     * @param accountId
     * @param dataType      数据类型
     * @param roleIdTypeMap
     * @return java.util.List<com.cloudwise.douc.service.model.data.DataAuthentication>
     * @description 查询多个角色id拥有的对应数据类型的其他数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 5:59 PM
     */
    List<DataAuthentication> getOtherDataAuthedByRoleIds(Long accountId, String dataType, Map<Long, Integer> roleIdTypeMap);

    /**
     * @param accountId
     * @param roleIds
     * @return void
     * @description 删除角色数据权限缓存
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:45 PM
     */
    void deleteDataAuthedByRoleIds(Long accountId, List<String> dataTypeList, List<Long> roleIds);

    /**
     * @param accountId
     * @param dataTypeList
     * @return void
     * @description 缓存角色数据权限失效标记
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:45 PM
     */
    void setDataAuthedByRoleIdsDirty(Long accountId, List<String> dataTypeList);

    /**
     * @param accountId
     * @param dataType  数据类型
     * @return java.util.List<com.cloudwise.douc.service.model.data.DataAuthentication>
     * @description 查询数据创建者拥有的对应数据类型的其他数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 5:59 PM
     */
    List<DataAuthentication> getCreatorOtherDataAuthed(Long accountId, Long userId, String dataType);

    /**
     * @param accountId
     * @param dataType
     * @param userIdList
     * @return void
     * @description 删除创建者数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:45 PM
     */
    void deleteCreatorDataAuthed(Long accountId, String dataType, List<Long> userIdList);

    List<MenuResponse> getViewMenuAuthedByAppCodeAndRoleIds(Long accountId, String appCode, Map<Long, Integer> roleIdTypeMap);
}
