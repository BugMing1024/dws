package com.cloudwise.douc.service.model.dingding;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class DingDingDeptBaseRespInfo {

    @JsonProperty("errcode")
    private String errcode;

    @JsonProperty("sub_code")
    private String subCode;

    @JsonProperty("errmsg")
    private String errmsg;

    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("result")
    private DingDingDepartment result;


}
