package com.cloudwise.douc.service.sms.zhhl;

import com.cloudwise.douc.commons.constant.StrConstant;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.model.ResultEntity;
import com.cloudwise.douc.commons.utils.LogUtil;
import com.cloudwise.douc.service.sms.ISmsSender;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Slf4j
@Component
@Configuration
public class ZzhlSmsSender implements ISmsSender {

    @Value("${channel.sms.zzhl.sendUrl:none}")
    private String sendUrl;
    @Value("${channel.sms.zzhl.account_id:none}")
    private String accountId;
    @Value("${channel.sms.zzhl.password:none}")
    private String pw;


    @Override
    public String getId() {
        return "zzhl";
    }

    @Override
    public ResultEntity sendMsg(String code, String phone, String content) {
        ResultEntity resultEntity = new ResultEntity();
        try {
            content = URLEncoder.encode(content, StandardCharsets.UTF_8.name());
            String result = httpGetSend(
                    sendUrl + StrConstant.C_DOUBT + "UserName=" + accountId + "&UserPass=" + pw + "&Content=" + content + "&Mobile=" + phone
                            + "&Subid=" + "", StandardCharsets.UTF_8.name());
            log.info("zzhl发送短信返回结果{}", LogUtil.cleanupParameter(result));
            if (StringUtils.isBlank(result)) {
                resultEntity.setCode(IBaseExceptionCode.SYSTEM_ERROR);
                resultEntity.setMsg("系统错误，可能是缺少配置");
                return resultEntity;
            }
            if (result.startsWith("03")) {
                resultEntity.setCode(IBaseExceptionCode.SUCCESS);
            } else {
                resultEntity.setCode(IBaseExceptionCode.SYSTEM_ERROR);
                resultEntity.setMsg(ZzhlErrorCodeAndMsg.getMsgByCode(result));
            }
            return resultEntity;
        } catch (Exception e) {
            log.error("至臻互联短信通道发送短信失败:", e);
            resultEntity.setCode(IBaseExceptionCode.SYSTEM_ERROR);
        }
        return resultEntity;
    }

    @Override
    public String getTemplateCode(Map<String, Object> map) {
        return null;
    }
    
    public String httpGetSend(String sendUrl, String encoded) {
        StringBuilder sbf = new StringBuilder();
        BufferedReader reader = null;
        HttpURLConnection uc = null;

        try {
            URL url = new URL(sendUrl);
            uc = (HttpURLConnection) url.openConnection();
            uc.setConnectTimeout(30000);
            uc.setReadTimeout(30000);
            uc.setRequestMethod("GET");
            uc.setDoOutput(true);
            uc.setDoInput(true);

            uc.connect();
            reader = new BufferedReader(new InputStreamReader(uc.getInputStream())); // 读取服务器响应信息
            String line;
            while ((line = reader.readLine()) != null) {
                sbf.append(line);
            }
            reader.close();
            uc.disconnect();
            return sbf.toString();
        } catch (Exception e) {
            log.error("zzhl-send-msg-failed:", e);
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (Exception e) {
                log.error("reader-close-failed:", e);
            }
        }
        return null;
    }
}
