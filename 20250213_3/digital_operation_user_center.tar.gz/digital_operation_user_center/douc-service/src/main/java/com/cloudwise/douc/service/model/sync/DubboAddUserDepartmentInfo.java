package com.cloudwise.douc.service.model.sync;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Dubbo新增用户实体-部门信息实体
 *
 * @author maker.wang
 * @date 2021-11-08 17:30
 **/
@Data
@ApiModel("Dubbo新增用户实体-部门信息实体")
public class DubboAddUserDepartmentInfo implements Serializable {
    private static final long serialVersionUID = 4448495301398450803L;

    @ApiModelProperty(value = "部门编码", required = true)
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_DEPARTMENT_INFO_NOT_BLANK)
    private String departmentCode;

    @ApiModelProperty(value = "部门名称")
    private String departmentName;

    @ApiModelProperty(value = "部门职位编码")
    private String departmentPosition;

    @ApiModelProperty(value = "是否是主部门:true是主部门 false是次部门 必传", required = true)
    @NotNull(message = IBaseExceptionCode.RPC_DATA_IS_MAIN_DEPARTMENT_NOT_NULL)
    private Boolean isMainDepartment;

}
