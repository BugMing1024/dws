package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;


/**
 * 企业微信配置
 *
 * @author maker.wang
 * @date 2022-05-23 11:57
 **/

@Component
@RefreshScope
@ConfigurationProperties(prefix = "sso.server.wechat")
@Data
public class ChannelWeComConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    @ApiModelProperty(value = "企业微信api地址")
    public String address;

    @ApiModelProperty(value = "企业微信企业id")
    private String corpid;

    @ApiModelProperty(value = "企业微信应用id")
    private String agentId;

    @ApiModelProperty(value = "企业微信应用秘钥")
    private String corpsecret;

    @ApiModelProperty(value = "企业微信获取code地址")
    private String proxyWxGetCodeUrl;

}