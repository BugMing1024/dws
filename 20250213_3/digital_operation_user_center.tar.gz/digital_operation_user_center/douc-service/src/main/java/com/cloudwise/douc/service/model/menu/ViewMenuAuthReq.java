package com.cloudwise.douc.service.model.menu;

import com.cloudwise.douc.commons.model.BaseEntity;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ViewMenuAuthReq extends BaseEntity {

    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;

    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    private Long userId;

    private String language;

    private String appCode;

    private Integer authType;

    @NotNull(message = IBaseExceptionCode.API_ROLE_ID_NULL)
    private Long roleId;

    private List<ViewMenuVo> viewMenuVoList;

}
