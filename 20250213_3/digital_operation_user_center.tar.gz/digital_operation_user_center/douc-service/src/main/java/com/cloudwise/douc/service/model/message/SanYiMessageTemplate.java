package com.cloudwise.douc.service.model.message;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author leakey.li
 * @description:
 * @date Created in 3:15 下午 2022/2/21.
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SanYiMessageTemplate extends AbstractMessageTemplate {

    public SanYiMessageTemplate(String code, String content, String mobile, String typeCode) {
        this.code = code;
        this.mobile = mobile;
        this.content = content;
        this.typeCode = typeCode;
    }

}