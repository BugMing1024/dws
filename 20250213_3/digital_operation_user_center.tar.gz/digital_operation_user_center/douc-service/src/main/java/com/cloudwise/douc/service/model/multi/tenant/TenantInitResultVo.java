package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.department.Department;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 租户初始化结果
 *
 * @author maker.wang
 * @date 2021-06-30 14:12
 **/
@Data
@ApiModel
public class TenantInitResultVo implements Serializable {
    private static final long serialVersionUID = 1993829431453449760L;

    /**
     * 租户信息
     **/
    @ApiModelProperty(value = "租户信息")
    private TenantInitInfoVo tenantInfo;

    /**
     * 顶级部门信息
     **/
    @ApiModelProperty(value = "顶级部门信息")
    private Department department;

    /**
     * 初始化用户信息
     **/
    @ApiModelProperty(value = "初始化用户信息")
    private TenantDefaultUserInfoVo defaultUserInfo;

    /**
     * 初始化角色信息
     **/
    @ApiModelProperty(value = "初始化角色信息")
    private TenantDefaultRoleInfoVo defaultRoleInfo;


}
