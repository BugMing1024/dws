package com.cloudwise.douc.service.model.dataauthorization;

import com.cloudwise.douc.metadata.model.dataauthorization.DataAndGroupRelationPo;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author liweizhi
 * @date 2020/4/9 10:42
 */
@Data
public class DataAuthUpdateParamFromSearchList implements Serializable {

    /**
     * 租户id
     */
    private long accountId;
    /**
     * 当前用户id
     */
    private long currentUserId;
    /**
     * 组id
     */
    private long groupId;
    private List<DataNode> list;

    @Data
    public static class DataNode {
        /**
         * 模块编码
         */
        private String moduleCode;
        /**
         * 数据类型code
         */
        private String dataTypeCode;
        /**
         * 数据分组code
         */
        private String dataGroupCode;
        /**
         * 数据code
         */
        private String code;
        /**
         * 是否被选
         */
        private boolean selected;

        public DataAndGroupRelationPo newDataAndGroupRelationPo(long accountId, long currentUserId, long groupId) {
            DataAndGroupRelationPo ret = new DataAndGroupRelationPo();

            ret.setModuleCode(this.moduleCode);
            ret.setDataTypeCode(this.dataTypeCode);
            ret.setDataGroupCode(this.dataGroupCode);
            ret.setDataCode(this.code);

            ret.setAccountId(accountId);
            ret.setGroupId(groupId);

            Date now = new Date();
            ret.setCreateUserId(currentUserId);
            ret.setCreateTime(now);
            ret.setModifyUserId(currentUserId);
            ret.setModifTime(now);
            return ret;
        }
    }
}
