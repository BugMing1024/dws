package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;


/**
 * 企业微信配置
 *
 * @author maker.wang
 * @date 2022-05-23 11:57
 **/

@Component
@RefreshScope
@ConfigurationProperties(prefix = "sso.server.dingding")
@Data
public class ChannelDingDingConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    @ApiModelProperty(value = "钉钉api地址")
    public String address;

    @ApiModelProperty(value = "钉钉应用key")
    private String appkey;

    @ApiModelProperty(value = "钉钉秘钥")
    private String appsecret;

    @ApiModelProperty(value = "应用id")
    private String proxyDdCorpId;


}
