package com.cloudwise.douc.service.model.channel;

import lombok.Data;

/**
 * @author zafir.zhong
 * @description 删除渠道配置的对象
 * @date Created in 14:20 2022/5/6.
 */
@Data
public class DeleteChannelConfigFront {

    private Long id;
}
