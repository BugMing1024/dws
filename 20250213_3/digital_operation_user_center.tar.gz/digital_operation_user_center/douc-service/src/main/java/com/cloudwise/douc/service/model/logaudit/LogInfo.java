package com.cloudwise.douc.service.model.logaudit;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @description: 接受到的日志信息
 * @author: jasonlee
 * @date: 2020-06-12 00:42
 **/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LogInfo {
    private Long timeMillis;
    private String message;
    private String thread;
    private String level;
    private String loggerName;
    private String endOfBatch;
    private String loggerFqcn;
    private Object instant;
    private Object contextMap;
    private Object threadId;
    private Object threadPriority;
}
