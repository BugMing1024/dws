package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * Role 返回类
 */
@Data
@ApiModel
public class RoleResp implements Serializable {
    @ApiModelProperty(value = "id")
    private Long id;
    @ApiModelProperty(value = "名称")
    @NotBlank(message = IBaseExceptionCode.API_ROLE_NAME_NOT_BLANK)
    private String name;
    @ApiModelProperty(value = "类型")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer type;
    @ApiModelProperty(value = "角色组id")
    @NotBlank(message = IBaseExceptionCode.API_ROLE_GROUP_ID_NOT_BLANK)
    private String roleGroupId;
    @ApiModelProperty(value = "租户id")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long accountId;
    @ApiModelProperty(value = "当前角色下人数")
    @JsonInclude
    private Integer perNum;
    @ApiModelProperty(value = "当前角色下启用人数")
    @JsonInclude
    private Integer perNumInUse;
    @ApiModelProperty(value = "是否被选中")
    @JsonInclude
    private boolean selected;

    public RoleResp() {
        if (this.getPerNum() == null) {
            this.setPerNum(0);
        }
        if (this.getPerNumInUse() == null) {
            this.setPerNumInUse(0);
        }
    }

    public RoleResp(Long id, Long accountId) {
        this.id = id;
        this.accountId = accountId;
        if (this.getPerNum() == null) {
            this.setPerNum(0);
        }
        if (this.getPerNumInUse() == null) {
            this.setPerNumInUse(0);
        }
    }
}
