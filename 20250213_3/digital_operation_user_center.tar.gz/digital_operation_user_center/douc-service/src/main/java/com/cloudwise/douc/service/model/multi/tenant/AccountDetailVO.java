package com.cloudwise.douc.service.model.multi.tenant;

import lombok.Data;

import java.io.Serializable;

/**
 * 租户初始化信息
 *
 * @author maker.wang
 * @date 2021-06-30 11:46
 **/
@Data
public class AccountDetailVO implements Serializable {

    private static final long serialVersionUID = -3261950429002331859L;

    /**
     * 租户id
     **/
    private Long accountId;

    /**
     * 租户名称
     **/
    private String accountName;

    /**
     * 上级租户id
     **/
    private Long parentAccountId;

    /**
     * 子租户管理员用户id
     **/
    private Long innerAdminUserId;

    /**
     * 子租户管理员用户姓名
     **/
    private String innerAdminUserName;

    /**
     * 子租户管理员用户别名
     **/
    private String innerAdminUserAlias;

    /**
     * 用于租户关联其他信息如部门的编码
     */
    private String code;
}
