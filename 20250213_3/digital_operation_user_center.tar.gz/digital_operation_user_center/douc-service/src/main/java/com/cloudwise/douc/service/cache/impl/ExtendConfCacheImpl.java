package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.model.extend.ExtendConfEntity;
import com.cloudwise.douc.service.cache.IExtendConfCache;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:59 PM 2021/4/7.
 */
@Component
@Slf4j
public class ExtendConfCacheImpl implements IExtendConfCache {
    @Override
    public ArrayList<ExtendConfEntity> getExtendConfByType(Long accountId, Integer type) {
        return RedisTools.getByte(this.getExtendConfKey(accountId, type), ArrayList.class);
    }

    @Override
    public void setExtendConfByType(Long accountId, Integer type, ArrayList<ExtendConfEntity> extendConfByTypeList) {
        String extendConfKey = this.getExtendConfKey(accountId, type);
        //判断属否处于清除缓存阶段
        String lock = RedisTools.getByte(extendConfKey + ":LOCK", String.class);
        if (StringUtils.isEmpty(lock)) {
            log.info("add extendConf cache success: accountId:{},type:{}", accountId, type);
            RedisTools.setByteWithTime(this.getExtendConfKey(accountId, type), extendConfByTypeList, 60 * 10);
        } else {
            log.info("add extendConf cache error: accountId:{},type:{}", accountId, type);
        }
    }

    @Override
    public void deleteExtendConfCacheByType(Long accountId, Integer type) {
        String extendConfKey = getExtendConfKey(accountId, type);
        if (RedisTools.isKeyExist(extendConfKey)) {
            //添加删除缓存锁
            RedisTools.setNXEX(extendConfKey + ":LOCK", "LOCK", 5L, TimeUnit.MINUTES);
            boolean hmset = RedisTools.deleteValueByKey(getExtendConfKey(accountId, type));
            if (!hmset) {
                log.info("delete extendConf Cache error: accountId:{},type:{}", accountId, type);
                throw new BaseException(IBaseExceptionCode.API_EXTEND_CACHE_ERROR);
            } else {
                log.info("delete extendConf cache success: accountId:{},type:{}", accountId, type);
                //删除成功清理缓存锁
                RedisTools.deleteValueByKey(extendConfKey + ":LOCK");
            }
        }
    }

    private String getExtendConfKey(Long accountId, Integer type) {
        return CacheConstant.REDIS_CACHE_KEY_EXTEND_CONF_KEY + accountId + StrPool.C_COLON + type;
    }

}
