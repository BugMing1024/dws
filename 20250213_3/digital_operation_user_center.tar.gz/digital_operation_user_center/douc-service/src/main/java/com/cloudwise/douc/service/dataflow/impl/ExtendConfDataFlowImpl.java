package com.cloudwise.douc.service.dataflow.impl;

import com.cloudwise.douc.metadata.mapper.IExtendDao;
import com.cloudwise.douc.metadata.model.extend.ExtendConfEntity;
import com.cloudwise.douc.service.cache.IExtendConfCache;
import com.cloudwise.douc.service.dataflow.IExtendConfDataFlow;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:54 PM 2021/4/7.
 */
@Component
@Slf4j
public class ExtendConfDataFlowImpl implements IExtendConfDataFlow {

    @Autowired
    private IExtendDao extendDao;
    @Autowired
    private IExtendConfCache extendConfCache;

    @Override
    public List<ExtendConfEntity> getExtendConfByType(Long accountId, Integer type) {
        List<ExtendConfEntity> extendConfByTypeList = extendConfCache.getExtendConfByType(accountId, type);
        if (CollectionUtils.isEmpty(extendConfByTypeList)) {
            extendConfByTypeList = extendDao.getExtendConfByType(accountId, String.valueOf(type));
            extendConfCache.setExtendConfByType(accountId, type, (ArrayList<ExtendConfEntity>) extendConfByTypeList);
        }
        return extendConfByTypeList;
    }

    @Override
    public void deleteExtendConfByType(Long accountId, Integer type) {
        extendConfCache.deleteExtendConfCacheByType(accountId, type);
    }
}
