package com.cloudwise.douc.service.model.app;

import com.cloudwise.douc.metadata.model.apimanage.DegradeRuleEntity;
import com.cloudwise.douc.metadata.model.apimanage.FlowRuleEntity;
import lombok.Data;

/**
 * 流控实体类
 **/
@Data
public class ApiRuleVo {

    private String apiId;

    private FlowRuleEntity flowRule;

    private DegradeRuleEntity degradeRule;
    /**
     * 是否开启流控信息
     */
    private Integer hasFlowRule;
    /**
     * 是否开启熔断信息
     */
    private Integer hasDegradeRule;

    private String code;

    private String moduleCode;

}
