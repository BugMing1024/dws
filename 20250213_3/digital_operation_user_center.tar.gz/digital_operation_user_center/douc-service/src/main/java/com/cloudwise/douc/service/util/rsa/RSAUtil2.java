package com.cloudwise.douc.service.util.rsa;


import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

@Slf4j
public class RSAUtil2 {

    public static final String ECB_PKCS1_PADDING = "RSA/ECB/PKCS1Padding"; //加密填充方式
    public static final String RSA = "RSA"; // 非对称加密密钥算法
    public static final String DEFAULT_PRIVATE_KEY_STRING = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDPWuHTJT1kVQ0W11gFuvJqIaVOGe1w+w54hmE/J/jH4p9O85K47cqXyl16xSjhdB+LXD/DrCI/9snbMoCUv76tLfSIVnijt9kL8Rgd1U+glPalZrCsR7pAfIQvVvvFiudab/4fmTM3I37cnCeexfTU0TB0sC+PhGfZlkocyyVcuw02SFYQMpUy7ohECbmNgIfi/ZHbfhPtXV8Vxo6NSVcoCj5v7go6AjpfD1Dtb/wNF9dYhhbNhW4BN0PW6aneU8pqUmA6DQ3x2BH8RzRyZlV0Goq6OsPwl9ru12y6+uaRmUxQpL0BkdGEIiIsrLDvZR6FPbrCqvHxt9ZXoxSh2i0ZAgMBAAECggEBAI6e7xbA1YIuMcuVIJkIZfZz3/RhRvzf4asqmrbK8oXhrTursy55eFCBQ1zPQXgY3B2JvN4EhqZCQ8L98IzfefI52qjv+Rh6utJI6RKUBqnn6+IGSNymlUgHnQ/Gn3PXP5vnzf3D7QMu6fIpgeLmO6kpnU+VY5EuPBPgGGfHnpIxZSdmMb+WK6b5mhWTXbiNQySrbHI9Y5PAN1nW/mWGAGrqKY7hdre9eKxjiER+GGbX90CrD8GziLo0Fcc54Nyt/VoKig6seWjhUEnId1PwuyE83JyehermirsYxrNprthTQnwVJvx60ohASxQCiv7ATPulF/Okrw0Ri6dbDMIj38UCgYEA7UNfql6THQJYwhegVai1vquFMRmoq2p4nSCXUOOymW33e/cF+iAVEswXyaQFY45lMclWb+8dNT8/jeRyXW8e47Mv1cUVDaa4TXa3SRo4n1ULHSYpbXmbJ5USyoesSGgvgLtRHGANpplxMW0xdVkm3Y5N6x0nzDRJzEyn3UJf2G8CgYEA37re2b3m2YHaQNNWRb5Tw3+GOpKEBWXJ/EbfLLCuCwg+aDaFxSQHT3z0CahevPj6y1s1ZZC5y33upZnIMqdKD8gCI/9t+tKIvZHjK258ayxpe8d96i7tW4kim6VE01GaqmRs5j4b8YRXlpESxpavObCcdFxsZf1ligGswgXuRvcCgYBkp69/HI42wVccSF+p11/7GtLviJ4o0ouGxVvMYjzToHZcrehoO5IVHmZ9EcuDd9Zwb6Tu6bcvbrysmpz2DH1DRjJl8y1CVFdd7Z5GMgyRc8e6PwVWPz/WZATLzREGysRUTaNUcV95LSF7QYK48PBvD774nq7Sj+A6/s48LLtymwKBgBP9vqv2LAqDb90bBTp2J0Xwvy28qc9RqRrBum9j2iliMzFcrddPwNd5ctTqFo0MMly5aawJopBsUEa71wevqw598LMGv+0Jou5Net8GoFdzQHmu+bFTQCJNvqnpupynTgqrro9kPVr3WFw72lGkZUPiZBiBqa3zVn9eZvFvVjtBAoGAQy+ggtTQjT64xQcb13zodJZyj251LDDRg/jsi4iw2KhkSnUxvMSOsKjNJDrro74rrSxfboKnb8BlhJO1+KiKh9lmDJ5p4og9KSGynyU5H6vOTRo/Db7qB6KADwcBZfIjKqoQ6PdPv8mN7jkr6uMSdNhZsotnzdE1jdxu+hZcXS8=";
    public static final String DEFAULT_PUBLIC_KEY_STRING = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz1rh0yU9ZFUNFtdYBbryaiGlThntcPsOeIZhPyf4x+KfTvOSuO3Kl8pdesUo4XQfi1w/w6wiP/bJ2zKAlL++rS30iFZ4o7fZC/EYHdVPoJT2pWawrEe6QHyEL1b7xYrnWm/+H5kzNyN+3JwnnsX01NEwdLAvj4Rn2ZZKHMslXLsNNkhWEDKVMu6IRAm5jYCH4v2R234T7V1fFcaOjUlXKAo+b+4KOgI6Xw9Q7W/8DRfXWIYWzYVuATdD1ump3lPKalJgOg0N8dgR/Ec0cmZVdBqKujrD8Jfa7tdsuvrmkZlMUKS9AZHRhCIiLKyw72UehT26wqrx8bfWV6MUodotGQIDAQAB";

    /**
     * 用公钥加密 <br>
     * 每次加密的字节数，不能超过密钥的长度值减去11
     *
     * @param data 需加密数据的byte数据
     *             公钥
     * @return 加密后的byte型数据
     */
    public static byte[] encryptData(byte[] data, PublicKey publicKey) {
        try {
            Cipher cipher = Cipher.getInstance(ECB_PKCS1_PADDING);
            // 编码前设定编码方式及密钥
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            // 传入编码数据并返回编码结果
            return cipher.doFinal(data);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * 公钥加密
     *
     * @param plaintext
     * @param publicKeyString
     * @return
     * @throws Exception
     * @throws NoSuchPaddingException
     */
    public static String encrypt(String plaintext, String publicKeyString) {
        try {
            PublicKey publicKey = loadPublicKey(publicKeyString);
            byte[] bytes = encryptData(plaintext.getBytes(StandardCharsets.UTF_8), publicKey);
            return Base64Utils.encode(bytes);
        } catch (Exception e) {
            log.error("==encrypt rsa error===Exception ", e);
            throw new BaseException(IBaseExceptionCode.SYSTEM_ERROR, e);
        }
    }


    /**
     * 私钥解密
     *
     * @param ciphertext
     * @param key
     * @return
     * @throws Exception
     */
    public static String decrypt(String ciphertext, String key) {
        try {
            return privateDecrypt(ciphertext, key);
        } catch (Exception e) {
            log.error("==decrypt rsa error===Exception ", e);
            throw new BaseException(IBaseExceptionCode.SYSTEM_ERROR, e);
        }
    }

    public static String privateDecrypt(String ciphertext, String privateKeyString) throws Exception {
        PrivateKey privateKey = loadPrivateKey(privateKeyString);
        byte[] bytes = decryptData(Base64Utils.decode(ciphertext), privateKey);
        return new String(bytes, StandardCharsets.UTF_8);
    }


    /**
     * 用私钥解密
     *
     * @param encryptedData   经过encryptedData()加密返回的byte数据
     * @param privateKeyPkcs8 privateKey    私钥
     * @return
     */
    public static byte[] decryptData(byte[] encryptedData, PrivateKey privateKeyPkcs8) {
        try {
            Cipher cipher = Cipher.getInstance(ECB_PKCS1_PADDING);
            cipher.init(Cipher.DECRYPT_MODE, privateKeyPkcs8);
            return cipher.doFinal(encryptedData);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 从字符串中加载公钥
     *
     * @param publicKeyStr 公钥数据字符串
     * @throws Exception 加载公钥时产生的异常
     */
    public static PublicKey loadPublicKey(String publicKeyStr) throws Exception {
        try {
            byte[] buffer = Base64Utils.decode(publicKeyStr);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
            return keyFactory.generatePublic(keySpec);
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此算法", e);
        } catch (InvalidKeySpecException e) {
            throw new Exception("公钥非法", e);
        } catch (NullPointerException e) {
            throw new Exception("公钥数据为空", e);
        }
    }

    /**
     * 从字符串中加载私钥<br>
     * 加载时使用的是PKCS8EncodedKeySpec（PKCS#8编码的Key指令）。
     *
     * @param privateKeyStr
     * @return
     * @throws Exception
     */
    public static PrivateKey loadPrivateKey(String privateKeyStr) throws Exception {
        try {
            byte[] buffer = Base64Utils.decode(privateKeyStr);
            // X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(buffer);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            return keyFactory.generatePrivate(keySpec);
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此算法", e);
        } catch (InvalidKeySpecException e) {
            throw new Exception("私钥非法", e);
        } catch (NullPointerException e) {
            throw new Exception("私钥数据为空", e);
        }
    }

}