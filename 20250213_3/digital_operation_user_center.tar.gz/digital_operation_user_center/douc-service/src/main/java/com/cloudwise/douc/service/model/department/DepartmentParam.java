package com.cloudwise.douc.service.model.department;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author leakey.li
 * @description:
 * @date Created in 12:00 下午 2022/5/9.
 */
@Data
public class DepartmentParam implements Serializable {
    private static final long serialVersionUID = 8586726058499572574L;
    /**
     * 租户id
     */
    @ApiModelProperty(value = "租户id")
    private Long accountId;
    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id")
    private Long userId;

    /**
     * 部门名称
     */
    @ApiModelProperty(value = "部门名称")
    private String departmentName;
    /**
     * 部门机构类型
     */
    @ApiModelProperty(value = "部门机构类型")
    private String orgType;

    @ApiModelProperty(value = "上级id")
    private Long parentId;
    /**
     * 是否查所有
     */
    private Boolean allDepartment = Boolean.FALSE;

    /**
     * 页码
     */
    @ApiModelProperty(value = "页码")

    private Integer current;

    /**
     * 每页条数
     */
    @ApiModelProperty(value = "每页条数")
    private Integer size;

    private List<String> authDepartment;
    private List<Long> currentDepartments;
    /**
     * 顶级租户id
     */
    @ApiModelProperty(value = "顶级租户id")
    private Long topAccountId;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
