package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.constant.StrConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.metadata.model.quota.AccountQuotaInfo;
import com.cloudwise.douc.service.cache.AccountDataCache;
import com.cloudwise.douc.service.service.IAccountService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author bradyliu
 * @description:
 * @date Created in 15:00 2021/7/7.
 */
@Slf4j
@Component
public class AccountDataCacheImpl implements AccountDataCache {
    @Autowired
    private IAccountDao accountDao;
    @Autowired
    private IAccountService accountService;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Override
    public void loadAllUserCountCache() {
        // 查询库中所有顶级租户id
        List<Long> topAccountIdList = this.accountService.getAllTopAccountIdList();
        if (CollectionUtils.isNotEmpty(topAccountIdList)) {
            for (Long accountId : topAccountIdList) {
                // 先删除缓存，在重新加载,删除放在设置的前一步
                //RedisTools.deleteValueByKey(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId);
                this.setUserCountCache(accountId);
            }
        }
    }

    @Override
    public Map<String, Set<String>> getUserCountCache(Long accountId) {
        Map<String, List<String>> countMap = RedisTools.getByte(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId, Map.class);
        Map<String, Set<String>> resultMap = Collections.emptyMap();
        if (Objects.nonNull(countMap)) {
            resultMap = Maps.newHashMapWithExpectedSize(countMap.size());
            for (Map.Entry<String, List<String>> entry : countMap.entrySet()) {
                resultMap.put(entry.getKey(), new TreeSet<>(entry.getValue()));
            }
        }
        return resultMap;
    }

    @Override
    public void setUserCountCacheIncrease(Long accountId, Map<String, Set<String>> countMap) {

        Map<String, Set<String>> userCountMap = this.getUserCountCache(accountId);

        for (Map.Entry<String, Set<String>> entry : countMap.entrySet()) {
            Set<String> cacheCountSet = userCountMap.getOrDefault(entry.getKey(), new TreeSet<>());
            cacheCountSet.addAll(entry.getValue());
            userCountMap.put(entry.getKey(), cacheCountSet);
        }

        RedisTools.setJson(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId, userCountMap);

    }


    @Override
    public void setUserCountCacheDecrease(Long accountId, Map<String, Set<String>> countMap) {
        Map<String, Set<String>> userCountMap = this.getUserCountCache(accountId);

        for (Map.Entry<String, Set<String>> entry : countMap.entrySet()) {
            Set<String> cacheCountSet = userCountMap.getOrDefault(entry.getKey(), new TreeSet<>());
            cacheCountSet.removeAll(entry.getValue());
            userCountMap.put(entry.getKey(), cacheCountSet);
        }
        RedisTools.setJson(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId, userCountMap);
    }

    /**
     * @param accountId 顶级租户id
     * @return
     * @description 初始化更新租户用户量到缓存中
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:13
     */
    private void setUserCountCache(Long accountId) {
        // 获取到所有userId 和 user关联租户level
        List<UserCountDO> userIdAndUserLevelList = this.accountDao.getUserIdAndUserLevelList(accountId);
        Map<String, Set<String>> countMap = Maps.newHashMapWithExpectedSize(userIdAndUserLevelList.size());
        for (UserCountDO userCountDO : userIdAndUserLevelList) {
            String level = userCountDO.getLevel();
            Long userId = userCountDO.getUserId();
            String accountId1 = userCountDO.getAccountId().toString();
            String[] levelSplit = level.split("\\.");
            // 保存当前级用户
            Set<String> levelSetId = countMap.getOrDefault(accountId1, new TreeSet<String>());
            levelSetId.add(accountId1 + StrConstant.C_EQ + userId);
            countMap.put(accountId1, levelSetId);
            for (String s : levelSplit) {
                // 查询map集合中是否有该节点
                Set<String> levelSet = countMap.getOrDefault(s, new TreeSet<String>());
                levelSet.add(s + StrConstant.C_EQ + userId);
                countMap.put(s, levelSet);
            }
        }
        RedisTools.deleteValueByKey(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId);
        RedisTools.setJson(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId, countMap);
    }

    /**
     * @param accountId 顶级租户id
     * @return
     * @description 重新更新顶级租户下用户量缓存
     * @author brady.liu
     * @date 2021/7/14
     * @time 14:42
     */
    @Override
    public void setUserCountCacheByTopAccountId(Long accountId) {
        // 删除内容
        RedisTools.deleteValueByKey(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId);
        // 更新顶级租户下id
        this.setUserCountCache(accountId);
    }

    @Override
    public void setAccountDetailByAccountId(Long accountId, AccountDetail accountDetail) {
        boolean setSuccess = RedisTools.setByteWithTime(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_DETAIL_KEY + accountId,
                accountDetail, CacheConstant.REDIS_CACHE_KEY_ACCOUNT_DETAIL_TTL);
        if (!setSuccess) {
            log.warn("Failed to cache account detail :{}", accountDetail);
        }
    }

    @Override
    public AccountDetail getAccountDetailByAccountId(Long accountId) {
        return RedisTools.getByte(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_DETAIL_KEY + accountId, AccountDetail.class);
    }

    @Override
    public void deleteAccountDetailByAccountId(List<Long> accountIds) {
        List<String> accountIdCacheKeyList = Lists.newArrayList();
        accountIds.forEach(accountId -> {
            accountIdCacheKeyList.add(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_DETAIL_KEY + accountId);
        });
        boolean deleteSuccess = RedisTools.deleteValueByKeys(accountIdCacheKeyList);
        if (!deleteSuccess) {
            log.error("Failed to delete cache account detail :{}", accountIds);
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }

    @Override
    public void setAccountQuotaInfo(Long accountId, AccountQuotaInfo aqi) {
        RedisTools.setByte(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_QUOTA_KEY + accountId, aqi);
    }

    @Override
    public AccountQuotaInfo getAccountQuotaInfo(Long accountId) {
        AccountQuotaInfo aqi = RedisTools.getByte(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_QUOTA_KEY + accountId, AccountQuotaInfo.class);
        return aqi;
    }

    @Override
    public void loadAllAccountQuotaCache() {
        // 查询库中所有顶级租户id
        List<AccountQuotaInfo> aqis = this.accountDao.getAllAccountQuotaInfo();
        if (aqis != null && aqis.size() > 0) {
            for (AccountQuotaInfo aqi : aqis) {
                RedisTools.setByte(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_QUOTA_KEY + aqi.getAccountId(), aqi);
            }
        }
    }


    @Override
    public void setAccountQuotaMenuInfo(Long accountId, Map<String, List<String>> map) {
        RedisTools.setJson(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_QUOTA_MENU_KEY + accountId, map);
    }

    @Override
    public Map<String, List<String>> getAccountQuotaMenuInfo(Long accountId) {
        Map<String, List<String>> map = RedisTools.getByte(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_QUOTA_MENU_KEY + accountId, Map.class);
        if (MapUtils.isEmpty(map)) {
            try {
                List<Long> accountIdList = Collections.singletonList(accountId);
                List<AccountQuotaInfo> quotaModuleList = accountDao.getQuotaModule(accountIdList);
                HashMap<String, List<String>> moduleCodeAndMenuCodeList = new HashMap<>();
                for (AccountQuotaInfo accountQuotaInfo : quotaModuleList) {
                    Map<String, Object> quotaInfoJson = accountQuotaInfo.getQuotaInfoJson();
                    for (Map.Entry<String, Object> entry : quotaInfoJson.entrySet()) {
                        Map<String, Object> quotaInfoByKey = (Map<String, Object>) entry.getValue();
                        Object baseInfoValue = quotaInfoByKey.get("baseInfo");
                        if (MapUtils.isNotEmpty(quotaInfoByKey) && Objects.nonNull(baseInfoValue)) {
                            Map<String, Object> baseInfoByKey = (Map<String, Object>) baseInfoValue;
                            Object hiddenModelMenusValue = baseInfoByKey.get("hiddenModelMenus");
                            if (MapUtils.isNotEmpty(baseInfoByKey) && Objects.nonNull(hiddenModelMenusValue)) {
                                List<Map<String, Object>> hiddenMenuMap = (List<Map<String, Object>>) hiddenModelMenusValue;
                                for (Map<String, Object> moduleCodeAndMenuCodeMap : hiddenMenuMap) {
                                    String module = (String) moduleCodeAndMenuCodeMap.get("module");
                                    List<String> menuCodes = OBJECT_MAPPER.convertValue(moduleCodeAndMenuCodeMap.get("menuCodes"), new TypeReference<List<String>>() {
                                    });
                                    moduleCodeAndMenuCodeList.put(module, menuCodes);
                                }
                            }
                        }
                    }
                }
                RedisTools.setJson(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_QUOTA_MENU_KEY + accountId, moduleCodeAndMenuCodeList);
                return moduleCodeAndMenuCodeList;
            } catch (Exception e) {
                log.error("存储租户配额缓存失败：", e);
            }
        }
        return map;
    }

}
