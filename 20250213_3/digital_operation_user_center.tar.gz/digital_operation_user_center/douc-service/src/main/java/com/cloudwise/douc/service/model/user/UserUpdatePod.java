package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 修改用户密码
 */
@Data
public class UserUpdatePod implements Serializable {
    private String oldPassword2;
    private String oldPassword3;
    private String newPassword2;
    private String newPassword3;
    private String newPassword;


    /**
     * 1 SM2 加密
     * 2 AES 加密
     * 3 SM3 SM2组合加密不可逆
     */
    private String type;
    /**
     * 加密类型 1 sm2 2 AES 3 sm3sm2 加密后不可逆
     */
    private String encrypt;
    private String username;
    private String language;
}
