package com.cloudwise.douc.service.model.menu;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UpGradeCustomProductRoleInfo {

    @ApiModelProperty(value = "历史自定义应用的id（portal）douc中是code")
    private String code;

    @ApiModelProperty(value = "历史自定义应用升级后的appCode")
    private String appCode;

    @ApiModelProperty(value = "历史自定义应用升级后的viewCode")
    private String viewCode;
}
