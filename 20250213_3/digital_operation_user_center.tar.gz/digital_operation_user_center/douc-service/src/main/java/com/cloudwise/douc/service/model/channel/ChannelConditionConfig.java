package com.cloudwise.douc.service.model.channel;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 渠道条件配置
 *
 * @author maker.wang
 * @date 2023-05-16 18:06
 **/
@Data
@ApiModel("渠道条件配置")
public class ChannelConditionConfig implements Serializable {
    private static final long serialVersionUID = -2583730175816575977L;

    @ApiModelProperty("条件表达式唯一标识")
    private String key;

    @ApiModelProperty("条件表达式")
    private String expression;

    @ApiModelProperty("条件表达式匹配值")
    private String expressionValue;

    @ApiModelProperty("关联符号")
    private String associationSymbol;

    @ApiModelProperty("子条件表达式")
    private List<ChannelConditionConfig> condition;
}
