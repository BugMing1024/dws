package com.cloudwise.douc.service.model.app;

import lombok.Builder;
import lombok.Setter;

import java.io.Serializable;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/17/2:18 下午
 * @Description:
 */
@Builder
@Setter
public class AppApiEntity implements Serializable {
    private String apiName;
    private long id;
}
