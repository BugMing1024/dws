package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.extend.ExtendConfEntity;

import java.util.ArrayList;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:59 PM 2021/4/7.
 */
public interface IExtendConfCache {

    ArrayList<ExtendConfEntity> getExtendConfByType(Long accountId, Integer type);

    void setExtendConfByType(Long accountId, Integer type, ArrayList<ExtendConfEntity> extendConfByTypeList);

    /**
     * 删除拓展字段缓存
     *
     * @param accountId
     * @param type
     */
    void deleteExtendConfCacheByType(Long accountId, Integer type);
}
