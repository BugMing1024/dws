package com.cloudwise.douc.service.model.role;

import lombok.Data;

import java.io.Serializable;

/**
 * @author barney.song Description: No Description
 */
@Data
public class RoleListRequestObject implements Serializable {
    
    /**
     * 角色id
     */
    private String roleId;
    
    /**
     * 部门id
     */
    private Long departmentId;
    
    /**
     * 组id
     */
    private Long groupId;
    
    /**
     * 角色关联用户关系类型 1：用户、2：组织机构、3：用户组（UserRoleRelationType）
     */
    private Integer userRoleRelationType;
    
    /**
     * 用于拼音搜索
     */
    private String keyword;
    
    /**
     * 用户名或姓名或邮箱
     */
    private String aliasOrNameOrEmail;

    /**
     * 别名或姓名
     */
    private String aliasOrName;

    /**
     * 页码
     */
    private Integer current;

    /**
     * 每页条数
     */
    private Integer size;

    /**
     * 租户id
     */
    private Long accountId;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
