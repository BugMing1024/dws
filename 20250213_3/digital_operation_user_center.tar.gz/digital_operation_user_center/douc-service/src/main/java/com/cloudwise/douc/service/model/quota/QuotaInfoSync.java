package com.cloudwise.douc.service.model.quota;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * 配额数据同步
 *
 * @author maker.wang
 * @date 2023-06-07 14:01
 **/
@Data
@ApiModel("配额数据同步实体类")
public class QuotaInfoSync implements Serializable {
    private static final long serialVersionUID = 4496385249925795299L;

    @ApiModelProperty("租户名称")
    private String accountName;

    @ApiModelProperty("租户id")
    private Long accountId;

    @ApiModelProperty("配额信息")
    private Map<String, Object> quotaInfo;

}
