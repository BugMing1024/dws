package com.cloudwise.douc.service.model.auth;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:27 AM 2020/4/12.
 */
@Data
public class DataAuthRequestObject implements Serializable {
    private Long accountId;
    private Long userId;
    private String moduleCode;
    private List<String> dataTypeCodes;

}
