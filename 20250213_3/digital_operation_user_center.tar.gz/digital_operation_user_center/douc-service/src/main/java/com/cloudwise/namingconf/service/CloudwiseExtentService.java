package com.cloudwise.namingconf.service;

import com.alibaba.nacos.api.config.listener.Listener;
import com.alibaba.nacos.api.exception.NacosException;
import com.alibaba.nacos.api.naming.listener.EventListener;
import com.alibaba.nacos.api.naming.pojo.Instance;

import java.util.List;

/**
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @date created at 2024-11-01 14:54; update at 2024-11-01 14:54
 */
public interface CloudwiseExtentService {
    
    String getConfig(String dataId, String group) throws NacosException;
    
    String getConfigAndSignListener(String dataId, String group, Listener listener) throws NacosException;
    
    void addListener(String dataId, String group, Listener listener) throws NacosException;
    
    boolean publishConfig(String dataId, String group, String content);
    
    void registerInstance(String serviceName, Instance instance);
    
    void deregisterInstance(String serviceName, String ip, int port);
    
    void batchRegisterInstance(String serviceName, String groupName, List<Instance> instances);
    
    void batchDeregisterInstance(String serviceName, String groupName, List<Instance> instances) throws NacosException;
    
    List<Instance> getAllInstances(String serviceName);
    
    List<Instance> selectInstances(String serviceName, boolean healthy);
    
    void unsubscribe(String serviceName, EventListener listener);
    
    void subscribe(String serviceName, EventListener listener);
}

