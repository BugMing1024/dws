package com.cloudwise.douc.service.model.multi.tenant;

import lombok.Data;

import java.io.Serializable;

/**
 * 新建企业-初始化其顶级租户
 *
 * @author maker.wang
 * @date 2021-07-28 18:44
 **/
@Data
public class EnterpriseInfoBO implements Serializable {
    private static final long serialVersionUID = 3820281432242538236L;

    /**
     * 企业名称/顶级租户名称
     **/
    private String enterpriseName;

    /**
     * 企业id
     **/
    private String enterpriseId;

    /**
     * 企业内置管理员名称
     **/
    private String innerName;

    /**
     * 企业内置管理员别名
     **/
    private String innerUserAlias;

    /**
     * 企业内置内置管理员邮箱
     **/
    private String innerEmail;

    /**
     * 企业内置内置管理员邮箱
     **/
    private String innerMobile;

    /**
     * 企业内置内置管理员手机号区号
     */
    private String innerMobileAreaCode;

    /**
     * 企业内置管理员密码
     **/
    private String innerPassword;

    /**
     * 内置数据国际化 内置数据国际化 中文：zh_CN 英文:en_US
     **/
    private String innerLanguage;
}
