package com.cloudwise.douc.service.model.department;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author bradyliu
 * @description: 用于返回树形列表
 * @date Created in 14:48 2021/7/1.
 */
@Data
public class AccountNode implements Serializable {
    private static final long serialVersionUID = 4656961941095423877L;
    /**
     * 租户id
     **/
    private Long id;

    /**
     * 租户名称
     **/
    private String name;

    /**
     * 上级租户id
     **/
    private Long parentId;

    /**
     * 顶级租户id
     **/
    private Long topId;

    /**
     * 顶级租户为0
     **/
    private String level;

    /**
     * 1只能看自己，2可看所有租户，3可看指定租户（顶级租户为2）
     **/
    private Integer visibleScope;

    /**
     * 1顶级租户，2非顶级租户 默认2
     **/
    private Integer isTop;

    /**
     * 1正常、2暂停（租户下用户无法登录,可删除）、3已删除(定时清除改租户相关的数据)
     **/
    private Integer status;

    /**
     * 创建人id
     **/
    private Long createUserId;
    /**
     * 租户人数,默认为零值
     */
    private Integer userCount = 0;

    /**
     * 子租户
     */
    private List<AccountNode> childAccontNode;

    private String remark;
}
