package com.cloudwise.douc.service.model.watermark;

import com.cloudwise.douc.metadata.activerecord.WatermarkEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 实际配置
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/11/9 17:27; update at 2023/11/9 17:27
 */
@Data
public class WatermarkSettingSimple extends WatermarkEntity {
    
    private String typeface;
    
    @ApiModelProperty(value = "水印的高度")
    private int height;
    @ApiModelProperty(value = "水印的宽度")
    private int width;
    private String value;
    private List<WatermarkField> params;
    
}
