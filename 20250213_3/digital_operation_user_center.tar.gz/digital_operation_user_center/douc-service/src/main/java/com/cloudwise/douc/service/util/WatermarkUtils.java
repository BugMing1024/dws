package com.cloudwise.douc.service.util;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.service.model.watermark.WatermarkSettingSimple;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ooxml.POIXMLDocumentPart;
import org.apache.poi.openxml4j.opc.PackagePartName;
import org.apache.poi.openxml4j.opc.PackageRelationship;
import org.apache.poi.openxml4j.opc.TargetMode;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRelation;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 水印图片获取
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/11/12 12:11; update at 2023/11/12 12:11
 */
@Slf4j
public class WatermarkUtils {
    
    private void addWatermarkExcel(String in, String out, String img) {
        try (FileOutputStream fileOutputStream = new FileOutputStream(new File(out));
                InputStream image = new FileInputStream(img);
                XSSFWorkbook workbook = new XSSFWorkbook(in);) {
            int pictureIdx = workbook.addPicture(image, Workbook.PICTURE_TYPE_PNG);
            POIXMLDocumentPart poixmlDocumentPart = workbook.getAllPictures().get(pictureIdx);
            //获取每个Sheet表
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                XSSFSheet sheet = workbook.getSheetAt(i);
                PackagePartName ppn = poixmlDocumentPart.getPackagePart().getPartName();
                String relType = XSSFRelation.IMAGES.getRelation();
                //add relation from sheet to the picture data
                PackageRelationship pr = sheet.getPackagePart()
                        .addRelationship(ppn, TargetMode.INTERNAL, relType, null);
                //set background picture to sheet
                sheet.getCTWorksheet().addNewPicture().setId(pr.getId());
            }
            workbook.write(fileOutputStream);
            
        } catch (Exception e) {
            log.error("addWatermarkExcel error ", e);
        }
        
    }
    
    
    public void addWatermark(String tarImgPath, String waterMarkContent, String fileExt) {
        //1.创建白色背景板空白图片
        int blankWidth = 1000;
        int blankHeight = 600;
        
        // 设置背景宽高.
        BufferedImage bufImg = new BufferedImage(blankWidth, blankHeight, BufferedImage.TYPE_INT_RGB);
        java.awt.Graphics graphics = bufImg.getGraphics();
        // 获取图形上下文对象
        
        graphics.fillRect(0, 0, blankWidth, blankHeight);
        // 填充
        graphics.fillRect(0, 0, blankWidth, blankHeight);
        // 填充
        graphics.dispose(); // 释放资源
        //2.设置水印基本信息
        //水印字体，大小
        java.awt.Font font = new java.awt.Font("#404040", java.awt.Font.BOLD, 34);
        //水印颜色
        java.awt.Color markContentColor = java.awt.Color.GRAY;
        //设置水印文字的旋转角度
        int degree = -45;
        //设置水印透明度 默认为1.0  值越小颜色越浅
        float alpha = 0.6f;
        
        try (OutputStream outImgStream = new FileOutputStream(tarImgPath);) {
            // 加水印
            // 得到画笔
            java.awt.Graphics2D g = bufImg.createGraphics();
            //设置水印颜色
            g.setColor(markContentColor);
            //设置字体
            g.setFont(font);
            //设置水印文字透明度
            g.setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_ATOP, alpha));
            //设置水印旋转
            g.rotate(Math.toRadians(degree), bufImg.getWidth(), bufImg.getHeight());
            JLabel label = new JLabel(waterMarkContent);
            FontMetrics metrics = label.getFontMetrics(font);
            //文字水印的宽
            int width = metrics.stringWidth(label.getText());
            g.drawString(waterMarkContent, 510, -100);
            g.dispose();
            // 输出图片
            ImageIO.write(bufImg, fileExt, outImgStream);
        } catch (Exception e) {
            log.error("addWatermark error:", e);
        }
    }
    
    
    /**
     * <p>Title: 生成水印图片信息 </p>
     * <p>Description: 生成水印图片信息 </p>
     */
    public static BufferedImage createWatermarkImage(WatermarkSettingSimple watermark) {
        Font font = new Font(watermark.getTypeface(), Font.BOLD, watermark.getSize());
        int width = watermark.getWidth();
        int height = watermark.getHeight()
                + watermark.getSize() * watermark.getValue().length() * Math.abs(watermark.getRotation()) / 125
                + watermark.getSize() * 3;
        
        Rectangle2D r = font.getStringBounds(watermark.getValue(),
                new FontRenderContext(AffineTransform.getScaleInstance(1d, 1d), false, false));
        width = width + (int) Math.floor(r.getWidth()) + 20;
        // height = (int) Math.floor(r.getHeight()) + 20;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        // 背景透明 开始
        java.awt.Graphics2D g = image.createGraphics();
        image = g.getDeviceConfiguration().createCompatibleImage(width, height, java.awt.Transparency.TRANSLUCENT);
        g.dispose();
        // 背景透明 结束
        g = image.createGraphics();
        // 设定画笔颜色
        g.setColor(new Color(Color.BLACK.getRed(), Color.BLACK.getGreen(), Color.BLACK.getBlue(),
                new Float(255 * watermark.getTransparency()).intValue()));
        // 设置画笔字体
        g.setFont(font);
        // 设定倾斜度
        g.shear(0.0, watermark.getRotation() / 90d);
        // 消除文字锯齿
        g.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING,
                java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        //设置字体平滑
        g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        
        int y = (height / 2) + font.getSize() * 2 + -watermark.getRotation() * 7;
        y = Math.max(Math.min(y, height) - 2 * watermark.getSize(), 0) + watermark.getSize();
        int x = 0;
        g.drawString(watermark.getValue(), x, y);
        // 释放画笔
        g.dispose();
        return image;
    }
    
    
    /**
     * <p>Title: 添加水印 </p>
     * <p>Description: 添加水印信息 </p>
     *
     * @param wb        工作薄
     * @param sheet     工作表
     * @param watermark 水印信息
     */
    public static void addWaterMark(XSSFWorkbook wb, XSSFSheet sheet, WatermarkSettingSimple watermark) {
        //是否添加水印
        if (StrUtil.isNotBlank(watermark.getValue())) {
            BufferedImage image = createWatermarkImage(watermark);
            // 导出到字节流B
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            try {
                ImageIO.write(image, "png", os);
            } catch (IOException e) {
                log.error("add watermark error: {}", e.getMessage());
            }
            
            int pictureIdx = wb.addPicture(os.toByteArray(), Workbook.PICTURE_TYPE_PNG);
            POIXMLDocumentPart poixmlDocumentPart = wb.getAllPictures().get(pictureIdx);
            
            PackagePartName ppn = poixmlDocumentPart.getPackagePart().getPartName();
            String relType = XSSFRelation.IMAGES.getRelation();
            //add relation from sheet to the picture data
            PackageRelationship pr = sheet.getPackagePart().addRelationship(ppn, TargetMode.INTERNAL, relType, null);
            //set background picture to sheet
            sheet.getCTWorksheet().addNewPicture().setId(pr.getId());
        }
    }
    
}
