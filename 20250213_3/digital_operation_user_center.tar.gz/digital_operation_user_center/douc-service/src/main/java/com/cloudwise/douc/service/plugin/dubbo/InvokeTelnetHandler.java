package com.cloudwise.douc.service.plugin.dubbo;

import cn.hutool.core.text.StrPool;
import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.commons.constant.StrConstant;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.common.utils.CollectionUtils;
import org.apache.dubbo.common.utils.PojoUtils;
import org.apache.dubbo.common.utils.ReflectUtils;
import org.apache.dubbo.common.utils.StringUtils;
import org.apache.dubbo.remoting.Channel;
import org.apache.dubbo.remoting.telnet.TelnetHandler;
import org.apache.dubbo.remoting.telnet.support.Help;
import org.apache.dubbo.rpc.AppResponse;
import org.apache.dubbo.rpc.model.ApplicationModel;
import org.apache.dubbo.rpc.model.MethodDescriptor;
import org.apache.dubbo.rpc.model.ProviderModel;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author bernie.wang
 * @description: 因dubbo 3.x中不再适配invoke命令，为便于历史兼容添加此调用插件
 * @date Created in 10:52 2023/5/15.
 */
@Activate
@Help(parameter = "[service.]method(args) ", summary = "Invoke the service method.", detail = "Invoke the service method.")
public class InvokeTelnetHandler implements TelnetHandler {

    public static final String INVOKE_MESSAGE_KEY = "telnet.invoke.method.message";
    public static final String INVOKE_METHOD_LIST_KEY = "telnet.invoke.method.list";
    public static final String INVOKE_METHOD_PROVIDER_KEY = "telnet.invoke.method.provider";

    public InvokeTelnetHandler() {
    }

    @Override
    public String telnet(Channel channel, String message) {
        if (StringUtils.isEmpty(message)) {
            return "Please input method name, eg: \r\ninvoke xxxMethod(1234, \"abcd\", {\"prop\" : \"value\"})\r\ninvoke XxxService.xxxMethod(1234, \"abcd\", {\"prop\" : \"value\"})\r\ninvoke com.xxx.XxxService.xxxMethod(1234, \"abcd\", {\"prop\" : \"value\"})";
        } else {
            String service = (String) channel.getAttribute("telnet.service");
            int i = message.indexOf(StrConstant.C_BRACKET_START);
            if (i >= 0 && message.endsWith(StrConstant.BRACKET_END)) {
                String method = message.substring(0, i).trim();
                String args = message.substring(i + 1, message.length() - 1).trim();
                i = method.lastIndexOf(StrPool.C_DOT);
                if (i >= 0) {
                    service = method.substring(0, i).trim();
                    method = method.substring(i + 1).trim();
                }

                List list;
                try {
                    list = JSONUtil.toList("[" + args + "]", Object.class);
                } catch (Throwable ex) {
                    return "Invalid json argument, cause: " + ex.getMessage();
                }

                StringBuilder buf = new StringBuilder();
                Method invokeMethod = null;
                ProviderModel selectedProvider = null;
                if (this.isInvokedSelectCommand(channel)) {
                    selectedProvider = (ProviderModel) channel.getAttribute("telnet.invoke.method.provider");
                    invokeMethod = (Method) channel.getAttribute("telnet.select.method");
                } else {
                    Iterator var11 = ApplicationModel.allProviderModels().iterator();

                    while (var11.hasNext()) {
                        ProviderModel provider = (ProviderModel) var11.next();
                        if (this.isServiceMatch(service, provider)) {
                            selectedProvider = provider;
                            List<Method> methodList = this
                                    .findSameSignatureMethod(provider.getAllMethods(), method, list);
                            if (CollectionUtils.isNotEmpty(methodList)) {
                                if (methodList.size() == 1) {
                                    invokeMethod = methodList.get(0);
                                } else {
                                    List<Method> matchMethods = this.findMatchMethods(methodList, list);
                                    if (CollectionUtils.isNotEmpty(matchMethods)) {
                                        if (matchMethods.size() != 1) {
                                            channel.setAttribute("telnet.invoke.method.provider", provider);
                                            channel.setAttribute("telnet.invoke.method.list", matchMethods);
                                            channel.setAttribute("telnet.invoke.method.message", message);
                                            this.printSelectMessage(buf, matchMethods);
                                            return buf.toString();
                                        }

                                        invokeMethod = matchMethods.get(0);
                                    }
                                }
                            }
                            break;
                        }
                    }
                }

                if (!StringUtils.isEmpty(service)) {
                    buf.append("Use default service ").append(service).append(StrPool.C_DOT);
                }

                if (selectedProvider != null) {
                    if (invokeMethod != null) {
                        try {
                            Object[] array = PojoUtils
                                    .realize(list.toArray(), invokeMethod.getParameterTypes(),
                                            invokeMethod.getGenericParameterTypes());
                            long start = System.currentTimeMillis();
                            AppResponse result = new AppResponse();

                            try {
                                Object o = invokeMethod.invoke(selectedProvider.getServiceInstance(), array);
                                result.setValue(o);
                            } catch (Throwable ex) {
                                result.setException(ex);
                            }

                            long end = System.currentTimeMillis();
                            buf.append("\r\nresult: ");
                            buf.append(JSONUtil.toJsonStr(result.recreate()));
                            buf.append("\r\nelapsed: ");
                            buf.append(end - start);
                            buf.append(" ms.");
                        } catch (Throwable ex) {
                            return "Failed to invoke method " + invokeMethod.getName() + ", cause: " + StringUtils
                                    .toString(ex);
                        }
                    } else {
                        buf.append("\r\nNo such method ").append(method).append(" in service ").append(service);
                    }
                } else {
                    buf.append("\r\nNo such service ").append(service);
                }

                return buf.toString();
            } else {
                return "Invalid parameters, format: service.method(args)";
            }
        }
    }

    private boolean isServiceMatch(String service, ProviderModel provider) {
        return provider.getServiceKey().equalsIgnoreCase(service) || provider.getServiceInterfaceClass().getSimpleName()
                .equalsIgnoreCase(service) || provider.getServiceInterfaceClass().getName().equalsIgnoreCase(service)
                || StringUtils.isEmpty(service);
    }

    private List<Method> findSameSignatureMethod(Set<MethodDescriptor> methods, String lookupMethodName,
                                                 List<Object> args) {
        List<Method> sameSignatureMethods = new ArrayList<>();
        Iterator<MethodDescriptor> var5 = methods.iterator();

        while (var5.hasNext()) {
            MethodDescriptor model = var5.next();
            Method method = model.getMethod();
            if (method.getName().equals(lookupMethodName) && method.getParameterTypes().length == args.size()) {
                sameSignatureMethods.add(method);
            }
        }

        return sameSignatureMethods;
    }

    private List<Method> findMatchMethods(List<Method> methods, List<Object> args) {
        List<Method> matchMethod = new ArrayList<>();
        Iterator<Method> var4 = methods.iterator();

        while (var4.hasNext()) {
            Method method = var4.next();
            if (isMatch(method, args)) {
                matchMethod.add(method);
            }
        }

        return matchMethod;
    }

    private static boolean isMatch(Method method, List<Object> args) {
        Class<?>[] types = method.getParameterTypes();
        if (types.length != args.size()) {
            return false;
        } else {
            for (int i = 0; i < types.length; ++i) {
                Class<?> type = types[i];
                Object arg = args.get(i);
                if (arg == null) {
                    if (type.isPrimitive()) {
                        return false;
                    }
                } else if (ReflectUtils.isPrimitive(arg.getClass())) {
                    if (!(arg instanceof String) || !type.isEnum()) {
                        if (!ReflectUtils.isPrimitive(type)) {
                            return false;
                        }

                        if (!ReflectUtils.isCompatible(type, arg)) {
                            return false;
                        }
                    }
                } else if (arg instanceof Map) {
                    String name = (String) ((Map) arg).get("class");
                    if (!StringUtils.isNotEmpty(name)) {
                        return true;
                    }

                    Class<?> cls = ReflectUtils.forName(name);
                    if (!type.isAssignableFrom(cls)) {
                        return false;
                    }
                } else if (arg instanceof Collection) {
                    if (!type.isArray() && !type.isAssignableFrom(arg.getClass())) {
                        return false;
                    }
                } else if (!type.isAssignableFrom(arg.getClass())) {
                    return false;
                }
            }

            return true;
        }
    }

    private void printSelectMessage(StringBuilder buf, List<Method> methods) {
        buf.append("Methods:\r\n");

        for (int i = 0; i < methods.size(); ++i) {
            Method method = methods.get(i);
            buf.append(i + 1).append(". ").append(method.getName()).append(StrConstant.C_BRACKET_START);
            Class<?>[] parameterTypes = method.getParameterTypes();

            for (int n = 0; n < parameterTypes.length; ++n) {
                buf.append(parameterTypes[n].getSimpleName());
                if (n != parameterTypes.length - 1) {
                    buf.append(StrPool.C_COMMA);
                }
            }

            buf.append(")\r\n");
        }

        buf.append("Please use the select command to select the method you want to invoke. eg: select 1");
    }

    private boolean isInvokedSelectCommand(Channel channel) {
        if (channel.hasAttribute("telnet.select")) {
            channel.removeAttribute("telnet.select");
            return true;
        } else {
            return false;
        }
    }
}
