package com.cloudwise.douc.service.dataflow.impl;

import com.cloudwise.douc.service.cache.IAuthCache;
import com.cloudwise.douc.service.cache.IRoleGroupCache;
import com.cloudwise.douc.service.dataflow.IAuthDataFlow;
import com.cloudwise.douc.service.dataflow.IRoleGroupDataFlow;
import com.cloudwise.douc.service.model.role.RoleGroupResp;
import com.cloudwise.douc.service.service.IRoleService;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Bernie
 * @date 2021-02-01 10:33
 */
@Component
@Slf4j
public class RoleGroupDataFlowImpl implements IRoleGroupDataFlow {

    @Autowired
    private IRoleService iRoleService;
    @Autowired
    private IRoleGroupCache roleGroupCache;
    @Autowired
    private IAuthCache authCache;
    @Autowired
    private IAuthDataFlow authDataFlow;

    @Override
    public List<RoleGroupResp> getAllRoleInfosByDataFlow(long accountId) {
        return roleGroupCache.getAllRoleGroupDirect(accountId);
    }

    @Override
    public void setAllRoleInfosByDataFlow(List<RoleGroupResp> roleGroupResps, long accountId) {
        roleGroupCache.setAllRoleGroupDirect(roleGroupResps, accountId);
    }

    @Override
    public void deleteAllRoleInfosByDataFlow(long accountId) {
        roleGroupCache.deleteAllRoleGroupDirect(accountId);
    }


    @Override
    public void deleteAllV2RoleGroupFromCacheByAccountId(Long accountId) {
        roleGroupCache.deleteAllV2RoleGroupFromCacheByAccountId(accountId);
    }

    @Override
    public void deleteAllMenuAndDataAuthCacheByRoleIds(Long accountId, List<Long> roleIds) {

        authDataFlow.deleteDataAuthedByRoleIds(accountId, Lists.newArrayList(Constant.DATAAUTH_DATATYPE_CMDB_BIZ), roleIds);
        authDataFlow.deleteDataAuthedByRoleIds(accountId, Lists.newArrayList(Constant.DATAAUTH_DATATYPE_CMDB_MODEL), roleIds);

        List<String> roleModuleCodes = iRoleService.getRoleModuleCodesByRoleId(accountId, roleIds.get(0));
        authCache.deleteMenuAuthedByRoleIds(accountId, roleModuleCodes, roleIds);
    }
}
