package com.cloudwise.douc.service.model.wecom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 企业微信响应对象
 *
 * @author maker.wang
 * @date 2022-01-08 11:19
 **/
@Data
@ApiModel("企业微信响应对象")
public class WeComSuiteAccessTokenDTO implements Serializable {
    private static final long serialVersionUID = 8461602132166396879L;

    @ApiModelProperty("出错返回码，为0表示成功，非0表示调用失败")
    private int errcode;

    @ApiModelProperty("返回码提示语")
    private String errmsg;

    // CHECKSTYLE:OFF
    @ApiModelProperty("代开发应用模板access_token")
    private String suite_access_token;

    @ApiModelProperty("有效期（秒）")
    private Integer expires_in;
    // CHECKSTYLE:ON

    public boolean checkRequestResult() {
        return 0 == this.errcode;
    }
}
