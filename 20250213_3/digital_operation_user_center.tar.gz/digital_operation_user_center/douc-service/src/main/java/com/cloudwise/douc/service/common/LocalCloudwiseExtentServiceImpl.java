package com.cloudwise.douc.service.common;

import cn.hutool.core.io.FileUtil;
import com.alibaba.nacos.api.config.listener.Listener;
import com.alibaba.nacos.api.exception.NacosException;
import com.alibaba.nacos.api.naming.listener.EventListener;
import com.alibaba.nacos.api.naming.pojo.Instance;
import com.cloudwise.namingconf.service.CloudwiseExtentService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;

/**
 * 覆盖nacos工具类，变成本地工具类
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-10-08 16:50; update at 2024-10-08 16:50
 */
@Primary
@Component
public class LocalCloudwiseExtentServiceImpl implements CloudwiseExtentService {
    
    @Value("${local.config.path:/data/app/doucApi/conf/local/}")
    private String path;
    
    @Override
    public String getConfig(String dataId, String group) throws NacosException {
        return FileUtil.readString(path + dataId, Charset.defaultCharset());
    }
    
    @Override
    public String getConfigAndSignListener(String dataId, String group, Listener listener) throws NacosException {
        return FileUtil.readString(path + dataId, Charset.defaultCharset());
    }
    
    @Override
    public void addListener(String dataId, String group, Listener listener) throws NacosException {
    
    }
    
    @Override
    public boolean publishConfig(String dataId, String group, String content) {
        return false;
    }
    
    @Override
    public void registerInstance(String serviceName, Instance instance) {
    
    }
    
    @Override
    public void deregisterInstance(String serviceName, String ip, int port) {
    
    }
    
    @Override
    public void batchRegisterInstance(String serviceName, String groupName, List<Instance> instances) {
    
    }
    
    @Override
    public void batchDeregisterInstance(String serviceName, String groupName, List<Instance> instances) throws NacosException {
    
    }
    
    @Override
    public List<Instance> getAllInstances(String serviceName) {
        return Collections.emptyList();
    }
    
    @Override
    public List<Instance> selectInstances(String serviceName, boolean healthy) {
        return Collections.emptyList();
    }
    
    @Override
    public void unsubscribe(String serviceName, EventListener listener) {
    
    }
    
    @Override
    public void subscribe(String serviceName, EventListener listener) {
    
    }
}
