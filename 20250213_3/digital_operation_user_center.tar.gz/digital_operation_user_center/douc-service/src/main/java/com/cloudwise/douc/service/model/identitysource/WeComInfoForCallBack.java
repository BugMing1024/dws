package com.cloudwise.douc.service.model.identitysource;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComInfoForCallBack implements Serializable {

    @JsonProperty("Id")
    private Long id;

    @JsonProperty("ToUserName")
    private String toUserName;

    @JsonProperty("FromUserName")
    private String fromUserName;

    @JsonProperty("CreateTime")
    private Long createTime;

    @JsonProperty("MsgType")
    private String msgType;

    @JsonProperty("UserID")
    private String userID;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Mobile")
    private String mobile;

    @JsonProperty("Gender")
    private Integer gender;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("ChangeType")
    private String changeType;

    @JsonProperty("event")
    private String event;

    @JsonProperty("ExtAttr")
    private List<com.cloudwise.douc.service.model.identitysource.WeComItem> extAttr;

    @JsonProperty("Position")
    private String position;

    @JsonProperty("Department")
    private String departmentId;

    @JsonProperty("Status")
    private Integer status;

    @JsonProperty("IsLeader")
    private Integer isLeader;

    @JsonProperty("Telephone")
    private String telephone;

    @JsonProperty("Alias")
    private String alias;

    @JsonProperty("IsLeaderInDept")
    private String isLeaderInDept;

    @JsonProperty("Address")
    private String address;

    @JsonProperty("MainDepartment")
    private Integer mainDepartment;

    @JsonProperty("BizMail")
    private String bizMail;

    @JsonProperty("ParentId")
    private Long parentId;

    @JsonProperty("Order")
    private Long order;

    @JsonProperty("DirectLeader")
    private String directLeader;
}
