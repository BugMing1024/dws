package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 顶级租户初始化信息
 *
 * @author maker.wang
 * @date 2021-06-30 11:46
 **/
@Data
public class TopTenantInitInfoBo implements Serializable {

    private static final long serialVersionUID = 4270910278666964736L;

    /**
     * 租户名称
     **/
    @NotBlank(message = IBaseExceptionCode.API_ACCOUNT_NAME_NOT_BLANK)
    private String name;

    /**
     * 顶级租户id，非自增 由系统生成
     *
     * @author maker.wang
     * @date 2021-07-30 15:15
     **/
    private Long topAccountId;

    /**
     * 企业id 8位数字
     *
     * @author maker.wang
     * @date 2021-07-30 15:15
     **/
    private Long enterpriseId;

    /**
     * 内置数据国际化 内置数据国际化 中文：zh_CN 英文:en_US
     **/
    private String innerLanguage;
}
