package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;
import com.cloudwise.douc.service.cache.IUserCache;
import com.cloudwise.douc.service.model.dingding.DingdingTokenResp;
import com.cloudwise.douc.service.util.Constant;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 用户相关缓存
 *
 * @description: ${description}
 * @author: ken
 * @date: 2021-01-26 19:43
 **/
@Slf4j
@Component
public class UserCacheImpl implements IUserCache {

    @Resource
    private ObjectMapper objectMapper;

    private static CloseableHttpClient createSSLClientDefault() {

        SSLContext sslContext;
        try {
            sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
                //信任所有
                @Override
                public boolean isTrusted(X509Certificate[] xcs, String string) {
                    return true;
                }
            }).build();

            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext);

            return HttpClients.custom().setSSLSocketFactory(sslsf).build();
        } catch (KeyStoreException ex) {
            log.error("", ex);
        } catch (NoSuchAlgorithmException ex) {
            log.error("", ex);
        } catch (KeyManagementException ex) {
            log.error("", ex);
        }

        return HttpClients.createDefault();
    }

    public String getAccountUserInfoByIdCacheKey(Long accountId) {
        return CacheConstant.REDIS_CACHE_KEY_USERINFOBYIDS_HASH_KEY + accountId;
    }

    public String getAccountUserInfoByUserAliasCacheKey(Long accountId) {
        return CacheConstant.REDIS_CACHE_KEY_USERINFOBYUSERALIAS_HASH_KEY + accountId;
    }

    public String getGatewayUserSessionCacheKey(Long userId) {
        return CacheConstant.REDIS_CACHE_KEY_GATEWAY_USER_SESSION + userId;
    }

    @Override
    public List<UserBaseInfoCacheDTO> getMultiUserFromCacheByIds(Long accountId, List<Long> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            return null;
        }
        List<String> userIdsStr = Lists.newArrayList();

        userIds.forEach((userId) -> {
            if (userId != null) {
                userIdsStr.add(String.valueOf(userId));
            }
        });
        Map<String, UserBaseInfoCacheDTO> userBaseInfoCacheDTOMap = RedisTools.hmget(this.getAccountUserInfoByIdCacheKey(accountId), UserBaseInfoCacheDTO.class, userIdsStr);
        return userBaseInfoCacheDTOMap != null ? Lists.newArrayList(userBaseInfoCacheDTOMap.values()) : null;
    }

    @Override
    public List<UserBaseInfoCacheDTO> getMultiUserFromCacheByUserAliass(Long accountId, List<String> userAlias) {
        Map<String, UserBaseInfoCacheDTO> userBaseInfoCacheDTOMap = RedisTools.hmget(this.getAccountUserInfoByUserAliasCacheKey(accountId), UserBaseInfoCacheDTO.class, userAlias);
        return userBaseInfoCacheDTOMap != null ? Lists.newArrayList(userBaseInfoCacheDTOMap.values()) : null;
    }

    @Override
    public void addOrUpdateSingleUserBasedToCache(UserBaseInfoCacheDTO userBaseInfoCacheDTO) {
        this.addOrUpdateUsersBasedToCache(Lists.newArrayList(userBaseInfoCacheDTO));
    }

    @Override
    public void addOrUpdateUsersBasedToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList) {
        this.addOrUpdateUserToCache(userBaseInfoCacheDTOList);
    }

    @Override
    public void addOrUpdateSingleOnlyUserStatusBasedToCache(Boolean isStart, UserBaseInfoCacheDTO userBaseInfoCacheDTO) {
        this.addOrUpdateOnlyUsersStatusBasedToCache(isStart ? Lists.newArrayList(userBaseInfoCacheDTO) : null, !isStart ? Lists.newArrayList(userBaseInfoCacheDTO) : null);
    }

    @Override
    public void addOrUpdateOnlyUsersStatusBasedToCache(List<UserBaseInfoCacheDTO> startUserBaseInfoCacheDTOList, List<UserBaseInfoCacheDTO> stopUserBaseInfoCacheDTOList) {
        this.updateUserStatusToCache(Boolean.TRUE, startUserBaseInfoCacheDTOList);
        this.updateUserStatusToCache(Boolean.FALSE, stopUserBaseInfoCacheDTOList);
    }

    @Override
    public void deleteUsersBasedFromCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList) {
        Map<Long, List<String>> accountUserIdMap = Maps.newHashMap();
        Map<Long, List<String>> accountUserAliasMap = Maps.newHashMap();
        userBaseInfoCacheDTOList.forEach(userBaseInfoCacheDTO -> {
            List<String> userIdList = accountUserIdMap.computeIfAbsent(userBaseInfoCacheDTO.getAccountId(), key -> Lists.newArrayList());
            List<String> userAliasList = accountUserAliasMap.computeIfAbsent(userBaseInfoCacheDTO.getAccountId(), key -> Lists.newArrayList());
            userIdList.add(String.valueOf(userBaseInfoCacheDTO.getId()));
            userAliasList.add(userBaseInfoCacheDTO.getUserAlias());
        });
        accountUserIdMap.forEach((accountId, userIdList) -> {
            boolean hdelIdsResult = RedisTools.hdel(this.getAccountUserInfoByIdCacheKey(accountId), userIdList);
            if (!hdelIdsResult) {
                log.error("Failed to delete userid cache:{}", userIdList);
                throw new BaseException(IBaseExceptionCode.API_USER_CACHE_ERROR);
            }
            log.debug("Success to delete userid cache,size：{}", userIdList.size());
        });
        accountUserAliasMap.forEach((accountId, userAliasList) -> {
            boolean hdelAliasResult = RedisTools.hdel(this.getAccountUserInfoByUserAliasCacheKey(accountId), userAliasList);
            if (!hdelAliasResult) {
                log.error("Failed to delete user alias cache:{}", userAliasList);
                throw new BaseException(IBaseExceptionCode.API_USER_CACHE_ERROR);
            }
            log.debug("Success to delete user alias cache ,size：{}", userAliasList.size());
        });

    }

    @Override
    public String getUsersCountByAccountIdAndStatus(Long accountId, Integer status) {
        String statusStr = "";
        if (status == null) {
            statusStr = "all";
        } else {
            statusStr = status + "";
        }
        List<String> statusList = Lists.newArrayList(statusStr);
        Map<String, String> usersCountMap = RedisTools.hmget(this.getUserCountKeyByAccountIdAndStatus(accountId, null), String.class, statusList);
        return usersCountMap.get(statusStr);
    }

    @Override
    public void setUsersCountByAccountId(Long accountId, Map<String, String> userCountMap) {
        boolean flag = RedisTools.hmset(getUserCountKeyByAccountIdAndStatus(accountId, null), userCountMap);
    }

    @Override
    public void deleteUsersCountByAccountId(Long accountId) {
        String key = getUserCountKeyByAccountIdAndStatus(accountId, null);
        if (RedisTools.isKeyExist(key)) {
            boolean hmset = RedisTools.deleteValueByKey(key);
            if (!hmset) {
                log.error("Failed to delete user count :{}", key);
                throw new BaseException(IBaseExceptionCode.API_USER_CACHE_ERROR);
            }
        }
    }

    @Override
    public Map<Long, Integer> getRoleIdTypeMapByUserIdAndAccountId(Long accountId, Long userId) {
        return RedisTools.getByte(this.getUserRoleIdsByAccountIdAndUserIdCacheKey(accountId, userId), Map.class);
    }

    @Override
    public void setRoleIdTypeMapByUserIdAndAccountId(Long accountId, Long userId, Map<Long, Integer> roleIdTypeMap) {
        HashMap<Long, Integer> roleIdTypeHashMap = Maps.newHashMap(roleIdTypeMap);
        RedisTools.setByteWithTime(this.getUserRoleIdsByAccountIdAndUserIdCacheKey(accountId, userId), roleIdTypeHashMap,
                this.getUserRoleIdsByAccountIdAndUserIdCacheTTL());
    }

    @Override
    public void deleteRoleIdTypeMapByUserIdAndAccountId(Long accountId, List<Long> userIdList) {

        List<String> userIdStrList = userIdList.stream().map(userId ->
                this.getUserRoleIdsByAccountIdAndUserIdCacheKey(accountId, userId)
        ).collect(Collectors.toList());
        boolean result = RedisTools.deleteValueByKeys(userIdStrList);
        if (!result) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }

    }

    @Override
    public void clearMultiUserFromCacheByUserAliasCache(Long accountId) {
        RedisTools.deleteValueByKey(this.getAccountUserInfoByUserAliasCacheKey(accountId));
    }

    @Override
    public void clearMultiUserFromCacheByIdsCache(Long accountId) {
        RedisTools.deleteValueByKey(this.getAccountUserInfoByIdCacheKey(accountId));
    }

    @Override
    public Map<Long, String> getUserSessionByUserIds(List<Long> userIds) {
        List<String> cacheKeyList = Lists.newArrayList();
        userIds.forEach(userId -> {
            cacheKeyList.add(this.getGatewayUserSessionCacheKey(userId));
        });
        Map<String, String> userSessionCacheMap = RedisTools.mgetNotPre(cacheKeyList, String.class);
        Map<Long, String> userSessionByUserIdMap = Maps.newHashMap();

        userIds.forEach(userId -> {
            userSessionByUserIdMap.put(userId, userSessionCacheMap.get(this.getGatewayUserSessionCacheKey(userId)));
        });
        return userSessionByUserIdMap;
    }

    //更新用户状态缓存
    private void updateUserStatusToCache(Boolean isStart, List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList) {
        if (userBaseInfoCacheDTOList != null) {
            Map<Long, Map<String, UserBaseInfoCacheDTO>> accountUserIdMap = Maps.newHashMap();
            Map<Long, Map<String, UserBaseInfoCacheDTO>> accountUserAliasMap = Maps.newHashMap();
            this.formatUserByAccountId(userBaseInfoCacheDTOList, accountUserIdMap, accountUserAliasMap);
            List<UserBaseInfoCacheDTO> userBaseInfoCacheDTONew = Lists.newArrayList();
            accountUserIdMap.forEach((accountId, userIdMap) -> {
                Map<String, UserBaseInfoCacheDTO> userIdCacheMap = RedisTools.hmget(this.getAccountUserInfoByIdCacheKey(accountId), UserBaseInfoCacheDTO.class, Lists.newArrayList(userIdMap.keySet()));
                if (userIdCacheMap != null) {
                    for (UserBaseInfoCacheDTO value : userIdCacheMap.values()) {
                        if (value != null) {
                            userBaseInfoCacheDTONew.add(value);
                        }
                    }
                }
            });
            userBaseInfoCacheDTONew.forEach(userBaseInfoCacheDTO -> {
                if (isStart) {
                    userBaseInfoCacheDTO.setStatus(Constant.STATUS_UP);
                } else {
                    userBaseInfoCacheDTO.setStatus(Constant.STATUS_DOWN);
                }
            });
            this.addOrUpdateUsersBasedToCache(userBaseInfoCacheDTONew);
        }
    }

    private void addOrUpdateUserToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList) {
        Map<Long, Map<String, UserBaseInfoCacheDTO>> accountUserIdMap = Maps.newHashMap();
        Map<Long, Map<String, UserBaseInfoCacheDTO>> accountUserAliasMap = Maps.newHashMap();
        this.formatUserByAccountId(userBaseInfoCacheDTOList, accountUserIdMap, accountUserAliasMap);
        accountUserIdMap.forEach((accountId, userIdMap) -> {
            boolean hmsetIdsResult = RedisTools.hmset(this.getAccountUserInfoByIdCacheKey(accountId), userIdMap);
            if (!hmsetIdsResult) {
                log.error("Failed to caching userInfo:{}", userIdMap);
                throw new BaseException(IBaseExceptionCode.API_USER_CACHE_ERROR);
            }
            log.debug("Success to caching userInfo,size：{}", userIdMap.size());
        });
        accountUserAliasMap.forEach((accountId, userAliasDepartmentNodeMap) -> {
            boolean hmsetAliasResult = RedisTools.hmset(this.getAccountUserInfoByUserAliasCacheKey(accountId), userAliasDepartmentNodeMap);
            if (!hmsetAliasResult) {
                log.error("Failed to caching userAlias");
                throw new BaseException(IBaseExceptionCode.API_USER_CACHE_ERROR);
            }
            log.debug("Success to caching userAlias,size：{}", userAliasDepartmentNodeMap.size());
        });
    }

    //根据accountId格式化数据
    private void formatUserByAccountId(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList, Map<Long, Map<String, UserBaseInfoCacheDTO>> accountUserIdMap, Map<Long, Map<String, UserBaseInfoCacheDTO>> accountUserAliasMap) {
        for (UserBaseInfoCacheDTO userBaseInfoCacheDTO : userBaseInfoCacheDTOList) {
            if (userBaseInfoCacheDTO == null) {
                continue;
            }
            Map<String, UserBaseInfoCacheDTO> userIdMap = accountUserIdMap
                    .computeIfAbsent(userBaseInfoCacheDTO.getAccountId(), key -> Maps.newHashMap());
            Map<String, UserBaseInfoCacheDTO> userAliasMap = accountUserAliasMap
                    .computeIfAbsent(userBaseInfoCacheDTO.getAccountId(), key -> Maps.newHashMap());
            userIdMap.put(String.valueOf(userBaseInfoCacheDTO.getId()), userBaseInfoCacheDTO);
            //多租户userAlias可能为空
            if (StringUtils.isNotBlank(userBaseInfoCacheDTO.getUserAlias())) {
                userAliasMap.put(userBaseInfoCacheDTO.getUserAlias(), userBaseInfoCacheDTO);
            }
        }
    }

    /**
     * 获取用户数量
     *
     * @param accountId
     * @param status
     * @return
     */
    private String getUserCountKeyByAccountIdAndStatus(Long accountId, Integer status) {
        if (status != null) {
            return CacheConstant.REDIS_CACHE_KEY_USERCOUNT_KEY + accountId + status;
        } else {
            return CacheConstant.REDIS_CACHE_KEY_USERCOUNT_KEY + accountId;
        }
    }

    /**
     * @param accountId
     * @param userId
     * @return java.lang.String
     * @description 获取用户拥有角色缓存key
     * @author ken.liang
     * @date 2021/6/22
     * @time 4:45 PM
     */
    private String getUserRoleIdsByAccountIdAndUserIdCacheKey(Long accountId, Long userId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_USER_ROLEIDS_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(userId);
        return stringBuilder.toString();
    }

    /**
     * @return java.lang.String
     * @description 获取用户拥有角色缓存ttl
     * @author ken.liang
     * @date 2021/6/22
     * @time 4:45 PM
     */
    private long getUserRoleIdsByAccountIdAndUserIdCacheTTL() {
        return ConfigUtils.getLong("auth.cache.user-roles.ttl", CacheConstant.REDIS_CACHE_KEY_USER_ROLEIDS_TTL);
    }

    public String getDingDingTokenByAppKey(String dingDingAppKey, String appSecret, String address) {
        try {
            String token = (String) RedisTools.getRedisUtils().get(dingDingAppKey);
            if (null != token && StringUtils.isNotBlank(token)) {
                return token;
            }
            String tokenUrl = address + "/gettoken?appkey=" + dingDingAppKey + "&appsecret=" + appSecret;
            HttpHost proxy = getHttpHost();
            log.info("获取tokenurl：{}", tokenUrl);
            String resp = getResult(tokenUrl, proxy);
            log.info("token resp:{}", resp);
            DingdingTokenResp tokenResp = objectMapper.readValue(resp, DingdingTokenResp.class);
            if (tokenResp != null && tokenResp.getErrcode() == 0) {
                String accessToken = tokenResp.getAccess_token();
                boolean result = RedisTools.setJsonIfAbsentWithTime(dingDingAppKey, accessToken, 7000L);
                log.info("钉钉设置缓存结果：{}", result);
                return accessToken;
            }
        } catch (Exception e) {
            log.error("获取钉钉token失败：", e);
        }
        return null;
    }

    private String getResult(String url, HttpHost proxy) {
        CloseableHttpClient httpClient = createSSLClientDefault();
        HttpGet httpGet = new HttpGet(url);
        // 响应模型
        CloseableHttpResponse response = null;
        String resp = "";
        try {
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(5000)
                    .setConnectionRequestTimeout(5000)
                    .setSocketTimeout(5000)
                    .setRedirectsEnabled(true).build();
            if (proxy != null) {
                //设置代理
                requestConfig = RequestConfig.custom()
                        .setConnectTimeout(5000)
                        .setConnectionRequestTimeout(5000)
                        .setSocketTimeout(5000)
                        .setRedirectsEnabled(true).setProxy(proxy).build();
            }
            httpGet.setConfig(requestConfig);
            response = httpClient.execute(httpGet);
            HttpEntity responseEntity = response.getEntity();
            resp = EntityUtils.toString(responseEntity);
        } catch (Exception e) {
            log.error("Failed to get userinfo ，request url:{}, exception:{}", url, e);
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }

        return resp;
    }

    private HttpHost getHttpHost() {
        HttpHost proxy = null;
        boolean isProxy = ConfigUtils.getBoolean("http.proxy");
        if (isProxy) {
            String proxyHost = ConfigUtils.getString("http.proxyHost", "");
            int proxyPort = ConfigUtils.getInt("http.proxyPort", 0);
            proxy = getRequestConfig(isProxy, proxyHost, proxyPort);
        }
        return proxy;
    }

    private HttpHost getRequestConfig(boolean isProxy, String proxyHost, int proxyPort) {
        log.debug("isProxy -result--{}", isProxy);
        if (!isProxy) {
            return null;
        }
        return new HttpHost(proxyHost, proxyPort);
    }
}

