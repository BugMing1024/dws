package com.cloudwise.douc.service.model.simulation;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 查看当前用户是否有管理员角色
 *
 * @author maker.wang
 * @date 2022-08-09 15:53
 **/
@Data
@ApiModel("查看当前用户是否有管理员角色出参")
public class CheckSimulateStatusVO implements Serializable {
    private static final long serialVersionUID = 4160210417341006110L;

    @ApiModelProperty("true: 是试用用户状态  false：不是")
    private Boolean isSimulateStatus;

    @ApiModelProperty("true:真实用户是顶级租户管理员 false:不是")
    private Boolean realUserIsTopAccountAdmin;

}
