package com.cloudwise.douc.service.dataflow;

public interface IDepartmentDataFlow {
    /**
     * 通过accountId和departmentId获取用户所在部门
     *
     * @param accountId
     * @param departmentId
     * @return
     */
    String getDepartmentDataByDepartmentId(Long accountId, Long departmentId, String departmentLevel);

}
