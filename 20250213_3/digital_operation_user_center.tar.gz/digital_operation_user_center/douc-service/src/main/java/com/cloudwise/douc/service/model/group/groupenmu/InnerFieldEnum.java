package com.cloudwise.douc.service.model.group.groupenmu;

public enum InnerFieldEnum {
    
    INNER_FIELE_NAME("name", "姓名", "String", 1, "id"),
    INNER_FIELE_ALIAS("user_alias", "用户名", "String", 1, "id"),
    INNER_FIELE_EMAIL("email", "邮箱", "String", 0, null),
    INNER_FIELE_MOBILE("mobile", "手机号", "String", 0, null),
    INNER_FIELE_FEISHU("feishu_account", "飞书账号", "String", 0, null),
    INNER_FIELE_DINGTALK("dingtalk_account", "钉钉账号", "String", 0, null),
    INNER_FIELE_QYWX("weixinwork_account", "企业微信账号", "String", 0, null),
    INNER_FIELE_WXPUSH("wxpush_account", "微信公众号", "String", 0, null),
    INNER_FIELE_DEPARTMENT("department_id", "部门", "DepartmentUserString", 1, null),
    INNER_FIELE_POSITION("position", "职务", "DepartmentUserPositionString", 1, null),
    INNER_FIELE_TYPE("origin", "类型", "UserOriginString", 1, null),
    INNER_FIELE_USERLEADERID("user_leader_id", "汇报对象", "UserLeaderString", 1, null);
    
    
    private String alias;
    
    private String name;
    
    private String type;
    
    private Integer isSearch;
    
    private String saveField;
    
    InnerFieldEnum(String alias, String name, String type, Integer isSearch, String saveField) {
        this.alias = alias;
        this.name = name;
        this.type = type;
        this.isSearch = isSearch;
        this.saveField = saveField;
    }
    
    public static final String FIELD = "Field_";
    
    public String getAlias() {
        return alias;
    }
    
    public String getName() {
        return name;
    }
    
    public String getType() {
        return type;
    }
    
    public Integer getIsSearch() {
        return isSearch;
    }
    
    public String getSaveField() {
        return saveField;
    }
}
