package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 角色配置用户组 用户分页入参
 *
 * @author maker.wang
 * @date 2022-03-10 09:40
 **/
@Data
@ApiModel("角色配置用户组 用户分页入参")
public class RoleSetGroupUserPageBO implements Serializable {
    private static final long serialVersionUID = 6767104631329661892L;

    public RoleSetGroupUserPageBO() {
        this.size = 10;
        this.current = 1;
        this.groupId = 0L;
    }

    @ApiModelProperty("用户组Id")
    @NotNull(message = IBaseExceptionCode.API_ROLE_ID_NULL)
    private Long groupId;

    @ApiModelProperty("名称/用户别名/邮箱")
    private String nameOrUserAliasOrEmail;

    @ApiModelProperty("每页条数 默认10")
    private Integer size;

    @ApiModelProperty("当前页 默认1")
    private Integer current;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }

}
