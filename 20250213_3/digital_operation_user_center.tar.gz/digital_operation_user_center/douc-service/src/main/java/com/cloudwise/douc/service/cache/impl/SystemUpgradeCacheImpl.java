package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.service.cache.ISystemUpgradeCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author leakey.li
 * @description:
 * @date Created in 2:34 下午 2021/9/6.
 */
@Component
@Slf4j
public class SystemUpgradeCacheImpl implements ISystemUpgradeCache {
    @Override
    public void setSystemUpgradeCache(Long accountId, Integer openSystemUpgrade) {
        String systemUpgradeCacheKey = getAccountSystemUpgradeCacheKey(accountId);
        if (openSystemUpgrade == null) {
            openSystemUpgrade = 0;
        }
        boolean b = RedisTools.setByte(systemUpgradeCacheKey, String.valueOf(openSystemUpgrade));
        if (!b) {
            throw new BaseException(IBaseExceptionCode.API_OPEN_SYSTEM_UPGRADE_CHECK_FAILED);
        }
    }

    public String getAccountSystemUpgradeCacheKey(Long accountId) {
        return CacheConstant.DOUC_SYSTEM_UPGRADE_CACHE_PRE + accountId;
    }
}
