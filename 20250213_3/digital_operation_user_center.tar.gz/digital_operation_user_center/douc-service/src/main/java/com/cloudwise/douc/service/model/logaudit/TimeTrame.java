package com.cloudwise.douc.service.model.logaudit;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author elsa.yang
 * @date 2020/6/10 2:49 下午
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimeTrame {
    /**
     * 查询开始时间
     */
    private long startTime;

    /**
     * 查询结束时间
     */
    private long endTime;
}
