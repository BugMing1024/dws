package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;


/**
 * Curl配置
 *
 * @author maker.wang
 * @date 2022-08-24 13:53
 **/
@Component
@RefreshScope
@ConfigurationProperties(prefix = "curl")
@Data
public class CurlConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    public CurlConfig() {
        this.syncUserInfoToSaaSLoginNum = 1000;
    }

    @ApiModelProperty(value = "和登录有关的数据都同步到后台 默认1000条")
    public Integer syncUserInfoToSaaSLoginNum;


}
