package com.cloudwise.douc.service.model.multi.tenant;

import lombok.Data;

import java.io.Serializable;

/**
 * 顶级部门信息
 *
 * @author maker.wang
 * @date 2021-06-30 14:16
 **/
@Data
public class TopDepartmentInfoVo implements Serializable {
    private static final long serialVersionUID = -1280469041992605415L;

    /**
     * 部门id
     **/
    private Long id;


}
