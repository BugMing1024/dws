package com.cloudwise.douc.service.model.group;

import lombok.Data;

/**
 * @author Bernie
 * @date 2021-04-29 21:38
 */
@Data
public class GroupPositionReq {
    private Long groupId;
    private String name;
    private Long userId;
    private Integer size;
    private Integer current;

    /**
     * 冗余参数,网下级传递
     *
     * @author maker.wang
     * @date 2021-09-09 21:40
     **/
    private transient Long accountId;
    private transient Long topAccountId;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
