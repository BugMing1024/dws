package com.cloudwise.douc.service.util;

import com.cloudwise.douc.commons.config.ConfigUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * @author bernie.wang
 * @description:
 * @date Created in 10:29 上午 2022/8/12.
 */
public class RouteUtils {

    /**
     * 为重定向url添加路由前缀
     *
     * @param url
     * @return java.lang.String
     * @description
     * @author bernie.wang
     * @date 2022/8/12
     * @time 10:30 上午
     */
    public static String addPrefixRedirectUrl(String url) {
        return ConfigUtils.getString("sso.server.default.prefix", StringUtils.EMPTY) + url;
    }
}
