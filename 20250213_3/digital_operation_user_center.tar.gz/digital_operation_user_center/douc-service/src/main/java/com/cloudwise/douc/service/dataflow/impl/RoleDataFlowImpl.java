package com.cloudwise.douc.service.dataflow.impl;

import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.model.role.RoleInfo;
import com.cloudwise.douc.service.cache.IRoleCache;
import com.cloudwise.douc.service.dataflow.IRoleDataFlow;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author Bernie
 * @date 2021-02-01 09:49
 */
@Component
@Slf4j
public class RoleDataFlowImpl implements IRoleDataFlow {

    @Autowired
    private IRoleDao roleDao;

    @Autowired
    private IRoleCache roleCache;

    @Override
    public List<RoleInfo> getRoleInfosByRoleIds(Long accountId, List<Long> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            return new ArrayList<>();
        }
        List<RoleInfo> roleInfos = roleCache.getRoleInfosByRoleIds(accountId, roleIds);
        //缓存key 不存在的情况
        if (roleInfos == null) {
            //从数据库里面拿数据，设置缓存中
            List<RoleInfo> allRoles = roleDao.getRoleListByAccountId(accountId);
            roleCache.setRoleInfos(accountId, allRoles);
            roleInfos = getRoleListByRoleIds(allRoles, roleIds);
        }
        if (CollectionUtils.isNotEmpty(roleInfos)) {
            //过滤null
            return roleInfos.stream().filter(Objects::nonNull).collect(Collectors.toList());
        }
        return roleInfos;
    }

    /**
     * 获取角色集合通过roleIds过滤从全量角色中
     *
     * @param allRoles
     * @param roleIds
     * @return
     */
    private List<RoleInfo> getRoleListByRoleIds(List<RoleInfo> allRoles, List<Long> roleIds) {
        List<RoleInfo> roleInfos = new ArrayList<>(roleIds.size());
        allRoles.forEach(roleInfo -> {
            if (roleIds.contains(roleInfo.getRoleId())) {
                roleInfos.add(roleInfo);
            }
        });
        return roleInfos;
    }


}
