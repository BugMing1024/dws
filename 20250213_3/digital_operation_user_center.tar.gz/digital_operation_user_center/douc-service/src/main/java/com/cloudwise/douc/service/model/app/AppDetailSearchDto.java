package com.cloudwise.douc.service.model.app;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/27/12:01 下午
 * @Description:
 */
@Data
public class AppDetailSearchDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private String appName;
    private String appId;
}
