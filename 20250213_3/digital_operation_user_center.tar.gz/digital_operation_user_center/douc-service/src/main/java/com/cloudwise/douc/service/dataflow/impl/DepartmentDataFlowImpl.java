package com.cloudwise.douc.service.dataflow.impl;

import com.cloudwise.douc.service.cache.IDepartmentDataCache;
import com.cloudwise.douc.service.dataflow.IDepartmentDataFlow;
import com.cloudwise.douc.service.service.IDepartmentV2Service;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DepartmentDataFlowImpl implements IDepartmentDataFlow {
    @Autowired
    private IDepartmentV2Service departmentV2Service;
    @Autowired
    private IDepartmentDataCache departmentDataCache;

    @Override
    public String getDepartmentDataByDepartmentId(Long accountId, Long departmentId, String departmentLevel) {
        String departmentData = departmentDataCache.getDepartmentDataByDepartmentId(accountId, departmentId);
        log.debug("getDepartmentDataByUserId-accountId:{},departmentId:{},redis value:{}", accountId, departmentId, departmentData);
        if (StringUtils.isNotEmpty(departmentData)) {
            return departmentData;
        }

        String departmentNameDetail = departmentV2Service.getDepartmentNameDetailByDepartmentLevel(accountId, departmentLevel);
        log.debug("getDepartmentDataByUserId-accountId:{},departmentId:{},departmentNameDetail value:{}", accountId, departmentId, departmentNameDetail);

        if (StringUtils.isNotEmpty(departmentNameDetail)) {
            departmentDataCache.setDepartmentDataByDepartmentId(accountId, departmentId, departmentNameDetail);
        }
        return departmentNameDetail;
    }

}
