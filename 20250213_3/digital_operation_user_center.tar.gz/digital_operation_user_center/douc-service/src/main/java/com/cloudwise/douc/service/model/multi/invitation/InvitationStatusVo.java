package com.cloudwise.douc.service.model.multi.invitation;

import lombok.Data;

import java.io.Serializable;

/**
 * 邀请状态查询实体
 *
 * @author maker.wang
 * @date 2021-07-15 09:43
 **/
@Data
public class InvitationStatusVo implements Serializable {
    private static final long serialVersionUID = 5654826042989505272L;

    /**
     * 邀请状态 1待回复 2已通过 3已拒绝 4 已撤销 5 发送失败 6 已过期
     **/
    private Integer invitationStatus;

    /**
     * 邀请详情
     **/
    private InvitationInfoVo invitationInfo;


}
