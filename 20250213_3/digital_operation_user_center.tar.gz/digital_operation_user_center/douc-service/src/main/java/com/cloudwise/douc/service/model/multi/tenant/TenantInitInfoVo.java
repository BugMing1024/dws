package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 租户初始化信息
 *
 * @author maker.wang
 * @date 2021-06-30 11:46
 **/
@Data
public class TenantInitInfoVo implements Serializable {
    private static final long serialVersionUID = -7544147896557158890L;

    /**
     * 租户id
     **/
    @ApiModelProperty(value = "租户id")
    private Long id;

    /**
     * 租户名称
     **/
    @ApiModelProperty(value = "租户名称")
    private String name;

    /**
     * 上级租户id
     **/
    @ApiModelProperty(value = "上级租户id")
    private Long parentId;

    /**
     * 顶级租户id
     **/
    @ApiModelProperty(value = "顶级租户id")
    private Long topId;

    /**
     * 顶级租户为0
     **/
    @ApiModelProperty(value = "顶级租户为0")
    private String level;

    /**
     * 1只能看自己，2可看所有租户，3可看指定租户（顶级租户为2）
     **/
    @ApiModelProperty(value = "1只能看自己，2可看所有租户，3可看指定租户（顶级租户为2）")
    private Integer visibleScope;

    /**
     * 1顶级租户，2非顶级租户 默认2
     **/
    @ApiModelProperty(value = "1顶级租户，2非顶级租户 默认2")
    private Integer isTop;

    /**
     * 1正常、2暂停（租户下用户无法登录,可删除）、3已删除(定时清除改租户相关的数据)
     **/
    @ApiModelProperty(value = "1正常、2暂停（租户下用户无法登录,可删除）、3已删除(定时清除改租户相关的数据)")
    private Integer status;

    /**
     * 当前租户可以看见的租户id列表
     **/
    @ApiModelProperty(value = "当前租户可以看见的租户id列表")
    private List<Long> visibleAccountIdList;

    @ApiModelProperty(value = "")
    private transient AccountDetail accountDetail;
}
