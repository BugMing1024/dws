package com.cloudwise.douc.service.model.feishu;

import com.lark.oapi.service.contact.v3.model.User;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author zhangmengyang
 */
@Data
@Builder
public class FeishuUser {

    private User user;

    @ApiModelProperty(value = "同步类型：1 新增，2 编辑")
    private Integer syncDataType;

    private String oldDepartmentCode;

}
