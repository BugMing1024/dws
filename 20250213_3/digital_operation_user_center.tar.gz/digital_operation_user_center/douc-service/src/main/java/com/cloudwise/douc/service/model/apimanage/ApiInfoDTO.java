package com.cloudwise.douc.service.model.apimanage;

import lombok.Data;

/**
 * Description: API信息实体类
 *
 * @author damon
 */
@Data
public class ApiInfoDTO {
    /**
     * API自定义id
     */
    private String code;
    /**
     * 模块编码
     */
    private String moduleCode;
    /**
     * API名称
     */
    private String name;
    /**
     * 资源路径
     */
    private String uri;
    /**
     * 组id
     */
    private String groupId;
    /**
     * 是否开启流控信息
     */
    private Integer hasFlowRule;
    /**
     * 是否开启熔断信息
     */
    private Integer hasDegradeRule;
    /**
     * 规则
     */
    private String rule;
    /**
     * 描述
     */
    private String description;
    /**
     * 发布状态
     */
    private Integer status;
    /**
     * api类型
     */
    private Integer apiType;
    /**
     * api请求信息
     */
    private String requestInfo;
}
