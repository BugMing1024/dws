package com.cloudwise.douc.service.model.channel;

import lombok.Data;

import java.util.Map;

/**
 * @author zafir.zhong
 * @description 与前端角度的渠道设置字段
 * @date Created in 14:04 2022/5/16.
 */
@Data
public class ChannelSettingFieldFront {
    private Long id;
    private String title;
    private String channelCode;
    private String channelConfigKey;
    private String subTypeCode;
    private Map<String, String> fields;
}
