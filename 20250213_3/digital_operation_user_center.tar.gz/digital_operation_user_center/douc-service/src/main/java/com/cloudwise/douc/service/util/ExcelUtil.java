package com.cloudwise.douc.service.util;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.text.StrPool;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import com.cloudwise.douc.metadata.model.extend.ExtendConfEntity;
import com.cloudwise.douc.service.model.ExcelEntity;
import com.cloudwise.douc.service.model.ExcelEntitySaaS;
import com.cloudwise.douc.service.model.department.DepartmentExcelEntity;
import com.cloudwise.douc.service.model.user.ExcelDepartmentEntity;
import com.cloudwise.douc.service.model.watermark.WatermarkSettingSimple;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataValidationConstraint;
import org.apache.poi.xssf.usermodel.XSSFDataValidationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author barney.song Description: No Description
 */
@Slf4j
public class ExcelUtil {

    /**
     * Description:  excel默认第三行默认为非重复属性名(中文字符串)，数据从第一列开始，
     *
     * @param sheetNum sheet数（从0开始）
     * @param file     文件
     * @return list
     */
    public static Map<String, Object> getUserExcelData(File file, int sheetNum, Boolean isSaaS,
                                                       List<ExtendConfEntity> userExtendField) throws BaseException {
        String language = ThreadLocalUtil.getLanguage();
        Map<String, Object> results = ExcelUtil.generatorExcelUserMap();
        InputStream fi = null;
        try {
            fi = Files.newInputStream(file.toPath());
            //根据文件名称获取Workbook对象
            Workbook wb = ExcelUtil.getWorkbookByFileNameAndFileInputStream(file.getName(), fi);
            //根据页签获取sheet
            Sheet sheet = wb.getSheetAt(sheetNum);
            //获取Excel数据行数
            int rowNum = sheet.getLastRowNum() + 1;
            //获取excel标头行
            Row titleRow = sheet.getRow(1);
            //获取Excel标准字段的下标索引
            Map<Integer, String> basicKeyIndex = ExcelUtil.generatorExcelKeyMap(titleRow, isSaaS);
            //获取Excel拓展字段下标索引
            Map<Integer, String> extendKeyIndex = ExcelUtil.generatorExcelExtendIndex(titleRow, userExtendField);
            //标准字段数量判定
            if (basicKeyIndex.size() < 11) {
                throw new BaseException(IBaseExceptionCode.API_USER_EXCEL_HAVE_WRONG_COLUMN);
            }
            for (int i = 2; i < rowNum; i++) {
                ExcelUtil.parseUserExcelData(sheet, i, results, basicKeyIndex, extendKeyIndex, language);
            }
        } catch (IOException e) {
            log.error("Error reading user information from Excel:", e);
            throw new BaseException(IBaseExceptionCode.EXCEL_HANDLE_WRONG, e);
        } finally {
            if (fi != null) {
                try {
                    fi.close();
                } catch (IOException e) {
                    fi = null;
                    log.error(e.getMessage(), e);
                }
            }
        }
        return results;
    }

    private static Workbook getWorkbookByFileNameAndFileInputStream(String fileName, InputStream fileInputStream)
            throws IOException {
        Workbook workbook = null;
        //选择解析方式
        if (fileName.endsWith(".xls")) {
            workbook = new HSSFWorkbook(fileInputStream);

        } else {
            workbook = new XSSFWorkbook(fileInputStream);
        }
        return workbook;
    }

    private static void parseUserExcelData(Sheet sheet, int rowNum, Map<String, Object> dataMap,
                                           Map<Integer, String> basicKeyIndex, Map<Integer, String> extendKeyIndex, String language) {
        //获取当前的数据行
        Row row = sheet.getRow(rowNum);
        //跳过空行
        if (null == row) {
            log.info("Excel null row:{}", rowNum);
            return;
        }
        //获取每行的最后一个单元格位置
        int cellNum = row.getLastCellNum();
        //表格列数不应超过标准字段加拓展字段数量的和
        if (cellNum > ExcelEntity.getMaxIndexValue() + 1 + extendKeyIndex.size()) {
            Map<Integer, List<String>> errorInfos = (Map<Integer, List<String>>) dataMap.get("errorInfos");
            errorInfos.put(rowNum + 1, Collections.singletonList(
                    Constant.DOUC_LANGUGE_TYPE_EN_US.equals(language) ? "The imported user file has out-of-region text"
                            : "导入用户文件存在区域外文字"));
        } else {
            Map<String, Object> rowMap = Maps.newHashMap();
            for (int currentKeyIndex = 0; currentKeyIndex < cellNum; currentKeyIndex++) {
                //获取当前单元格数据
                Cell cell = row.getCell(Short.parseShort(currentKeyIndex + ""));
                String cellValue = null;
                if (null != cell) {
                    //判断excel单元格内容的格式，并对其进行转换，以便插入数据库
                    cellValue = ExcelUtil.convertCellType(cell);
                    //用户标准字段数据
                    ExcelUtil.addExcelUserBasicData(dataMap, cellValue, currentKeyIndex);
                    //标准字段填入用户数据填入
                    if (StringUtils.isNotEmpty(basicKeyIndex.get(currentKeyIndex)) && StringUtils.isNotEmpty(
                            cellValue)) {
                        rowMap.put(basicKeyIndex.get(currentKeyIndex), cellValue);
                    }
                    //拓展字段用户数据填入
                    if (StringUtils.isNotEmpty(extendKeyIndex.get(currentKeyIndex)) && StringUtils.isNotEmpty(
                            cellValue)) {
                        //拓展字段数据
                        ExcelUtil.addExcelExtendData(dataMap, extendKeyIndex, currentKeyIndex, cellValue);
                        rowMap.put(extendKeyIndex.get(currentKeyIndex), cellValue);
                    }
                }
            }
            //添加用户对象
            if (rowMap.size() > 0) {
                List<Map<String, Object>> userList = (List<Map<String, Object>>) dataMap.get("userList");
                userList.add(rowMap);
            }
        }
    }

    private static void addExcelExtendData(Map<String, Object> dataMap, Map<Integer, String> extendKeyIndex,
                                           int currentKeyIndex, String cellValue) {
        String extendKey = extendKeyIndex.get(currentKeyIndex);
        List<String> dataList = (List<String>) dataMap.get(extendKey);
        if (dataList == null) {
            List<String> resultData = Lists.newArrayList();
            resultData.add(cellValue);
            dataMap.put(extendKey, resultData);
        } else {
            dataList.add(cellValue);
        }
    }
    
    public static Map<Integer, List<String>> getErrorGroupData(File file, int sheetNum, Set<String> existGroup, Set<String> tooLongGroup,
            Set<String> notParent, Set<String> notUser) throws BaseException {
        // 第一项是全路径，第二项是用户（list）
        Map<Integer, List<String>> results = new HashMap<>();
        try (FileInputStream fi = new FileInputStream(file)) {
            Workbook wb = null;
            //选择解析方式
            if (file.getName().endsWith(".xls")) {
                wb = new HSSFWorkbook(fi);
            } else {
                wb = new XSSFWorkbook(fi);
            }
            Sheet sheet = wb.getSheetAt(sheetNum);
            int rowNum = sheet.getLastRowNum() + 1;
            for (int i = 2; i < rowNum; i++) {
                //每行的最后一个单元格位置
                Row row = sheet.getRow(i);
                //空row 跳过
                if (null == row) {
                    continue;
                }
                List<String> tempErrorData = org.apache.commons.compress.utils.Lists.newArrayList();
                Cell cell = row.getCell(0, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (cell == null) {
                    tempErrorData.add("用户组名称为空");
                } else {
                    String name = cell.getStringCellValue();
                    if (notParent.contains(name)) {
                        tempErrorData.add("父用户组不存在");
                    }
                    if (existGroup.contains(name)) {
                        tempErrorData.add("用户组已存在");
                    }
                    if (tooLongGroup.contains(name)) {
                        tempErrorData.add("用户组名称过长");
                    }
                }

                Cell userCell = row.getCell(1, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (userCell != null) {
                    String user = userCell.getStringCellValue();
                    if (user != null) {
                        List<String> users = Collections.emptyList();
                        if (StrUtil.isNotBlank(user)) {
                            users = Arrays.asList(user.split(","));
                        }
                        StringBuilder userAlias = new StringBuilder();
                        users.forEach(u -> {
                            if (notUser.contains(u)) {
                                if (userAlias.length() > 0) {
                                    userAlias.append(",");
                                }
                                userAlias.append(u);
                            }
                        });
                        if (userAlias.length() > 0) {
                            tempErrorData.add("用户不存在:" + userAlias);
                        }
                    }
                }
                if (tempErrorData.size() > 0) {
                    results.put(i + 1, tempErrorData);
                }
            }
        } catch (IOException e) {
            log.error("Error reading user information from Excel:{}", e.getStackTrace());
            throw new BaseException(IBaseExceptionCode.EXCEL_HANDLE_WRONG);
        }
        return results;
    }

    private static void addExcelUserBasicData(Map<String, Object> dataMap, String cellValue, int keyIndex) {
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.USER_ALIAS.getIndex()) {
            List<String> userAlias = (List<String>) dataMap.get("userAlias");
            userAlias.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.EMAIL.getIndex()) {
            List<String> emails = (List<String>) dataMap.get("emails");
            emails.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.MOBILE.getIndex()) {
            List<String> mobiles = (List<String>) dataMap.get("mobiles");
            mobiles.add(cellValue);
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.WECHAT.getIndex()) {
            List<String> wechats = (List<String>) dataMap.get("wechats");
            wechats.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.DINGTALK.getIndex()) {
            List<String> dingtalks = (List<String>) dataMap.get("dingtalks");
            dingtalks.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.CODE.getIndex()) {
            List<String> codes = (List<String>) dataMap.get("codes");
            codes.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.FEISHU.getIndex()) {
            List<String> feishus = (List<String>) dataMap.get("feishus");
            feishus.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.WXPUSH.getIndex()) {
            List<String> wxpushs = (List<String>) dataMap.get("wxpushs");
            wxpushs.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.DEPARTMENT.getIndex()) {
            List<String> departments = (List<String>) dataMap.get("departments");
            Set<String> departmentsSet = (Set<String>) dataMap.get("departmentsSet");
            departmentsSet.addAll(Arrays.asList(cellValue.split(StrPool.SLASH)));
            departments.add(cellValue);
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.POSITION.getIndex()) {
            List<String> positions = (List<String>) dataMap.get("positions");
            positions.add(cellValue);
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == ExcelEntity.USERLEADER.getIndex()) {
            List<String> userleaders = (List<String>) dataMap.get("userleaders");
            userleaders.add(cellValue);
        }
    }

    private static String convertCellType(Cell cell) {
        String cellValue = "";
        switch (cell.getCellType()) {
            case NUMERIC:
                cellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
                break;
            case STRING:
                cellValue = cell.getStringCellValue();
                break;
            case FORMULA:
                cellValue = cell.getNumericCellValue() + "";
                break;
            case BLANK:
                cellValue = "";
                break;
            case BOOLEAN:
                cellValue = String.valueOf(cell.getBooleanCellValue());
                break;
            case ERROR:
                cellValue = String.valueOf(cell.getErrorCellValue());
                break;
            default:
                cellValue = "";
        }
        return cellValue;
    }

    private static Map<Integer, String> generatorExcelKeyMap(Row row, boolean isSaaS) {
        Map<Integer, String> resuleMap = Maps.newHashMap();
        for (int currentCellNum = 0; currentCellNum < row.getLastCellNum(); currentCellNum++) {
            Cell cell = row.getCell(Short.parseShort(currentCellNum + ""));
            //获取列值
            String cellValue = cell.getStringCellValue();
            //根据下标获取列名
            String excelName = ExcelEntity.getExcelRowNameByIndex(currentCellNum);
            if (isSaaS) {
                excelName = ExcelEntitySaaS.getExcelRowNameByIndex(currentCellNum);
            }
            if (StringUtils.isNotEmpty(cellValue) && cellValue.equals(excelName)) {
                resuleMap.put(currentCellNum, currentCellNum + "");
            }
        }
        return resuleMap;
    }

    private static Map<Integer, String> generatorExcelExtendIndex(Row row, List<ExtendConfEntity> userExtendField) {
        //获取标准字段的最大下标用于过滤掉标准字段数据
        int maxIndexValue = ExcelEntity.getMaxIndexValue();
        //回参容器
        Map<Integer, String> resuleMap = Maps.newHashMap();
        //从标准字段最大下标开始遍历
        for (int currentCellNum = maxIndexValue + 1; currentCellNum < row.getLastCellNum(); currentCellNum++) {
            Cell cell = row.getCell(Short.parseShort(currentCellNum + ""));
            //获取列值
            String cellValue = cell.getStringCellValue();
            //拓展字段名列表
            List<String> dataList = userExtendField.stream().map(ExtendConfEntity::getAlias)
                    .collect(Collectors.toList());
            //拓展字段
            if (StringUtils.isNotEmpty(cellValue)) {
                //根据换行符拆分获取拓展字段名
                String[] split = cellValue.split("\\n");
                //别名删除可能存在的必填标识
                String extendKey = split[1].replace("（required）", "");
                //生成excel拓展字段的下标索引，key为excel中的下标，value是拓展字段别名
                if (dataList.contains(extendKey)) {
                    resuleMap.put(currentCellNum, extendKey + Constant.EXCEL_EXTEND_FIELD_PREFIX);
                } else {
                    throw new BaseException(IBaseExceptionCode.API_EXCEL_TEMPLATE_ERROR);
                }
            }
        }
        return resuleMap;
    }


    private static Map<String, Object> generatorExcelUserMap() {
        Map<String, Object> results = new HashMap<>();
        List<String> userAlias = new ArrayList<>();
        List<String> emails = new ArrayList<>();
        List<String> mobiles = new ArrayList<>();
        List<String> wechats = new ArrayList<>();
        List<String> dingtalks = new ArrayList<>();
        List<String> codes = new ArrayList<>();
        List<String> feishus = new ArrayList<>();
        List<String> wxpushs = new ArrayList<>();
        List<String> departments = new ArrayList<>();
        Set<String> departmentsSet = new HashSet<>();
        Map<Integer, List<String>> errorInfos = new HashMap<>();
        List<Map<String, Object>> userList = new ArrayList<>();
        //职位
        List<String> positions = new ArrayList<>();
        //汇报人
        List<String> userleaders = new ArrayList<>();
        results.put("userAlias", userAlias);
        results.put("emails", emails);
        results.put("mobiles", mobiles);
        results.put("wechats", wechats);
        results.put("dingtalks", dingtalks);
        results.put("feishus", feishus);
        results.put("wxpushs", wxpushs);
        results.put("codes", codes);
        results.put("departmentsSet", departmentsSet);
        results.put("departments", departments);
        results.put("positions", positions);
        results.put("userleaders", userleaders);
        results.put("errorInfos", errorInfos);
        results.put("userList", userList);
        return results;
    }

    public static void setExcelBasicData(XSSFRow dataRow, CellStyle dataCellStyle, List<Map<Integer, Object>> mapList,
                                         int dataRowNum, int basicDataNum) {
        for (int j = 0; j < basicDataNum; j++) {
            XSSFCell cell = dataRow.createCell(j);
            Object valueObject = mapList.get(dataRowNum).get(j);
            String value;
            if (valueObject == null) {
                valueObject = "";
            }
            if (valueObject instanceof String) {
                value = (String) valueObject;
            } else if (valueObject instanceof Integer) {
                value = String.valueOf(((Integer) (valueObject)).floatValue());
            } else if (valueObject instanceof BigDecimal) {
                value = String.valueOf(((BigDecimal) (valueObject)).floatValue());
            } else {
                value = valueObject.toString();
            }
            cell.setCellValue(value);
            cell.setCellStyle(dataCellStyle);
        }
    }

    public static void updateExcelTitls(XSSFSheet wbSheet, XSSFCellStyle titleStyle, List<String> basicTitle) {
        XSSFRow row = wbSheet.createRow(1);
        //标准字段title
        for (int i = 0; i < basicTitle.size(); i++) {
            XSSFCell cellHead = row.createCell(i);
            cellHead.setCellValue(basicTitle.get(i));
            cellHead.setCellStyle(titleStyle);
        }
    }

    public static int addTitleCell(Row row, String cnStr, String enStr, CellStyle cellStyle, boolean isRequire) {
        int cellsNumber = row.getPhysicalNumberOfCells();
        Cell cell = row.createCell(cellsNumber);
        if (isRequire) {
            cell.setCellValue(cnStr + "（必填）" + StrPool.LF + enStr + "（required）");
        } else {
            cell.setCellValue(cnStr + StrPool.LF + enStr);
        }
        cell.setCellStyle(cellStyle);
        return cellsNumber;
    }

    public static void setExcelChiefMsg(XSSFSheet wbSheet, XSSFCellStyle contentStyle) {
        String inHeadContext = "" + "1.支持Excel 2007及以上版本文件；1.Support Excel 2007 and above；\n"
                + "2.文件格式见示例批量导入模板文件<1>；2.See sample file for file format<1>；\n"
                + "3 不能在本excel表中对表字段进行增加、删除、修改；3.Cannot add, delete, or modify table fields in this excel sheet；\n"
                + "4 员工登录名：员工在企业的唯一标识，该字段可初始设定或自动生成，且不可修改； 4.Employee login name: the unique identification of the employee in the enterprises, the field can be initially set or automatically generated and can not be modified";

        //融合单元格
        CellRangeAddress region = new CellRangeAddress(0, 0, 0, 3);
        wbSheet.addMergedRegion(region);
        //创建提示信息行数据
        XSSFRow row = wbSheet.createRow(0);
        row.setHeight((short) (20 * 120));
        XSSFCell headContext = row.createCell(0);
        headContext.setCellStyle(contentStyle);
        headContext.setCellValue(inHeadContext + "");
    }


    public static Map<String, List<String>> getGroupExcelData(File file, int sheetNum) throws BaseException {
        // 第一项是全路径，第二项是用户（list）
        Map<String, List<String>> results = new HashMap<>();
        try (FileInputStream fi = new FileInputStream(file)) {
            Workbook wb = null;
            //选择解析方式
            if (file.getName().endsWith(".xls")) {
                wb = new HSSFWorkbook(fi);
            } else {
                wb = new XSSFWorkbook(fi);
            }
            Sheet sheet = wb.getSheetAt(sheetNum);
            int rowNum = sheet.getLastRowNum() + 1;
            for (int i = 2; i < rowNum; i++) {
                //每行的最后一个单元格位置
                Row row = sheet.getRow(i);
                //空row 跳过
                if (null == row) {
                    log.info("Excel null row:{}", i);
                    continue;
                }

                Cell cell = row.getCell(0, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (cell == null) {
                    log.info("Excel null row:{}", i);
                    continue;
                }
                String name = cell.getStringCellValue();
                Cell userCell = row.getCell(1, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (userCell == null) {
                    results.put(name, Collections.emptyList());
                    continue;
                }
                String user = userCell.getStringCellValue();
                if (user == null) {
                    results.put(name, Collections.emptyList());
                    continue;
                }
                List<String> users = Collections.emptyList();
                if (StrUtil.isNotBlank(user)) {
                    users = Arrays.asList(user.split(","));
                }
                results.put(name, users);
            }
        } catch (IOException e) {
            log.error("Error reading user information from Excel:{}", e.getStackTrace());
            throw new BaseException(IBaseExceptionCode.EXCEL_HANDLE_WRONG);
        }
        return results;
    }

    /**
     * Description:  excel默认第一行默认为非重复属性名(中文字符串)，数据从第一列开始，导出默认表Sheet1
     *
     * @param mapList 导出数据
     */
    public static XSSFWorkbook setExcelData(List<Map<Integer, Object>> mapList) {
        String inHeadContext = ""
                + "1.支持Excel 2007及以上版本文件；1.Support Excel 2007 and above；\n"
                + "2.文件格式见示例批量导入模板文件<1>；2.See sample file for file format<1>；\n"
                + "3 不能在本excel表中对表字段进行增加、删除、修改；Cannot add, delete, or modify table fields in this excel sheet；\n"
                + "4 红色字段为必填字段，黑色字段为选填字段。4 The fields in red are required and the fields in black are optional. \n"
                + "5 员工登录名：员工在企业的唯一标识，该字段可初始设定或自动生成，且不可修改；5 Employee login name: the unique identification of the employee in the enterprises, the field can be initially set or automatically generated and can not be modified";

        List headList = ExcelEntity.toExcelRowName();
        List headExplanationList = ExcelEntity.toExcelHeadName();

        XSSFWorkbook wb = new XSSFWorkbook();

        XSSFSheet wbSheet = wb.createSheet("Sheet1");
        //第一行：11号、黑色
        CellRangeAddress region = new CellRangeAddress(0, 0, 0, 3);
        wbSheet.addMergedRegion(region);
        XSSFCellStyle contentStyle = wb.createCellStyle();
        XSSFFont contentFont = wb.createFont();
        contentFont.setFontName("宋体");
        contentFont.setFontHeightInPoints((short) 11);
        contentFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        contentStyle.setFont(contentFont);
        contentStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        XSSFRow row = wbSheet.createRow(0);
        row.setHeight((short) (20 * 120));
        XSSFCell headContext = row.createCell(0);
        contentStyle.setWrapText(true);
        headContext.setCellStyle(contentStyle);
        headContext.setCellValue(inHeadContext + "");
        //第二行：加粗、14号、深灰色
        //第三行：11号、黑色、加粗、灰色背景
        XSSFCellStyle contentStyle3 = wb.createCellStyle();
        XSSFFont contentFont3 = wb.createFont();
        contentFont3.setFontName("宋体");
        contentFont3.setBold(true);
        contentFont3.setFontHeightInPoints((short) 11);
        contentStyle3.setFont(contentFont3);
        contentStyle3.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());
        contentStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        contentStyle3.setAlignment(HorizontalAlignment.CENTER);
        XSSFRow row3 = wbSheet.createRow(1);
        XSSFCell cellHead3;
        for (int i = 0; i < headList.size(); i++) {
            cellHead3 = row3.createCell(i);
            cellHead3.setCellValue(headList.get(i).toString());
            cellHead3.setCellStyle(contentStyle3);
        }
        //数据行：11号、黑色、边框
        XSSFCellStyle contentStyle4 = wb.createCellStyle();
        contentStyle4.cloneStyleFrom(contentStyle);
        contentStyle4.setAlignment(HorizontalAlignment.CENTER);
        contentStyle4.setBorderBottom(BorderStyle.THIN);
        contentStyle4.setBorderTop(BorderStyle.THIN);
        contentStyle4.setBorderRight(BorderStyle.THIN);
        contentStyle4.setBorderLeft(BorderStyle.THIN);
        for (int i = 0; i < mapList.size(); i++) {
            XSSFRow roww = wbSheet.createRow(i + 2);
            XSSFCell cell;
            for (int j = 0; j < headList.size(); j++) {
                cell = roww.createCell(j);
                Object valueObject = mapList.get(i).get(j);
                String value;
                if (valueObject == null) {
                    valueObject = "";
                }
                if (valueObject instanceof String) {
                    value = (String) valueObject;
                } else if (valueObject instanceof Integer) {
                    value = String.valueOf(((Integer) (valueObject)).floatValue());
                } else if (valueObject instanceof BigDecimal) {
                    value = String.valueOf(((BigDecimal) (valueObject)).floatValue());
                } else {
                    value = valueObject.toString();
                }
                cell.setCellValue(value);
                cell.setCellStyle(contentStyle4);
            }
        }
        for (int i = 0; i < headList.size(); i++) {
            // 调整每一列宽度
            wbSheet.autoSizeColumn((short) i);
            // 解决自动设置列宽中文失效的问题
            int colWidth = wbSheet.getColumnWidth(i) * 17 / 10;
            if (colWidth < 255 * 256) {
                wbSheet.setColumnWidth(i, colWidth < 3000 ? 3000 : colWidth);
            } else {
                wbSheet.setColumnWidth(i, 6000);
            }
        }
        return wb;
    }


    public static XSSFCellStyle getContentStyle(XSSFWorkbook wb) {
        XSSFCellStyle contentStyle = wb.createCellStyle();
        XSSFFont contentFont = wb.createFont();
        contentFont.setFontName("宋体");
        contentFont.setFontHeightInPoints((short) 11);
        contentFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        contentStyle.setFont(contentFont);
        contentStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        contentStyle.setWrapText(true);
        return contentStyle;
    }


    public static XSSFCellStyle getTitleStyle(XSSFWorkbook wb) {
        XSSFCellStyle contentStyle3 = wb.createCellStyle();
        XSSFFont contentFont3 = wb.createFont();
        contentFont3.setFontName("宋体");
        contentFont3.setBold(true);
        contentFont3.setFontHeightInPoints((short) 11);
        contentStyle3.setFont(contentFont3);
        contentStyle3.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());
        contentStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        contentStyle3.setAlignment(HorizontalAlignment.CENTER);
        contentStyle3.setWrapText(true);
        return contentStyle3;
    }

    public static CellStyle getDataCellStyle(XSSFWorkbook wb) {
        XSSFCellStyle contentStyle = wb.createCellStyle();
        XSSFFont contentFont = wb.createFont();
        contentFont.setFontName("宋体");
        contentFont.setFontHeightInPoints((short) 11);
        contentFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        contentStyle.setFont(contentFont);
        contentStyle.setWrapText(true);
        contentStyle.setAlignment(HorizontalAlignment.CENTER);
        return contentStyle;
    }


    /**
     * Description:  excel默认第一行默认为非重复属性名(中文字符串)，数据从第一列开始，导出默认表Sheet1
     *
     * @param mapList 导出数据
     */
    public static XSSFWorkbook setDepartmentExcelData(List<Map<Integer, Object>> mapList, WatermarkSettingSimple settingSimple) {
        String inHeadContext = "" + "1.支持Excel 2007及以上版本文件；1.Support Excel 2007 and above；";

        List headList = ExcelDepartmentEntity.toExcelRowName();
        List headExplanationList = DepartmentExcelEntity.toExcelHeadName();

        XSSFWorkbook wb = new XSSFWorkbook();

        XSSFSheet wbSheet = wb.createSheet("Sheet1");
        //第一行：11号、黑色
        CellRangeAddress region = new CellRangeAddress(0, 0, 0, 3);
        wbSheet.addMergedRegion(region);
        XSSFCellStyle contentStyle = wb.createCellStyle();
        XSSFFont contentFont = wb.createFont();
        contentFont.setFontName("宋体");
        contentFont.setFontHeightInPoints((short) 11);
        contentFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        contentStyle.setFont(contentFont);
        contentStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        XSSFRow row = wbSheet.createRow(0);
        row.setHeight((short) (20 * 120));
        XSSFCell headContext = row.createCell(0);
        contentStyle.setWrapText(true);
        headContext.setCellStyle(contentStyle);
        headContext.setCellValue(inHeadContext + "");
        //第二行：加粗、14号、深灰色
        //第三行：11号、黑色、加粗、灰色背景
        XSSFCellStyle contentStyle3 = wb.createCellStyle();
        XSSFFont contentFont3 = wb.createFont();
        contentFont3.setFontName("宋体");
        contentFont3.setBold(true);
        contentFont3.setFontHeightInPoints((short) 11);
        contentStyle3.setFont(contentFont3);
        contentStyle3.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());
        contentStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        contentStyle3.setAlignment(HorizontalAlignment.CENTER);
        XSSFRow row3 = wbSheet.createRow(1);
        XSSFCell cellHead3;
        for (int i = 0; i < headList.size(); i++) {
            cellHead3 = row3.createCell(i);
            cellHead3.setCellValue(headList.get(i).toString());
            cellHead3.setCellStyle(contentStyle3);
        }
        //数据行：11号、黑色、边框
        XSSFCellStyle contentStyle4 = wb.createCellStyle();
        contentStyle4.cloneStyleFrom(contentStyle);
        contentStyle4.setAlignment(HorizontalAlignment.CENTER);
        contentStyle4.setBorderBottom(BorderStyle.THIN);
        contentStyle4.setBorderTop(BorderStyle.THIN);
        contentStyle4.setBorderRight(BorderStyle.THIN);
        contentStyle4.setBorderLeft(BorderStyle.THIN);
        for (int i = 0; i < mapList.size(); i++) {
            XSSFRow roww = wbSheet.createRow(i + 2);
            XSSFCell cell;
            for (int j = 0; j < headList.size(); j++) {
                cell = roww.createCell(j);
                Object valueObject = mapList.get(i).get(j);
                String value;
                if (valueObject == null) {
                    valueObject = "";
                }
                if (valueObject instanceof String) {
                    value = (String) valueObject;
                } else if (valueObject instanceof Integer) {
                    value = String.valueOf(((Integer) (valueObject)).floatValue());
                } else if (valueObject instanceof BigDecimal) {
                    value = String.valueOf(((BigDecimal) (valueObject)).floatValue());
                } else {
                    value = valueObject.toString();
                }
                cell.setCellValue(value);
                cell.setCellStyle(contentStyle4);
            }
        }
        mapList = null;
        for (int i = 0; i < headList.size(); i++) {
            // 调整每一列宽度
            wbSheet.autoSizeColumn((short) i);
            // 解决自动设置列宽中文失效的问题
            int colWidth = wbSheet.getColumnWidth(i) * 17 / 10;
            if (colWidth < 255 * 256) {
                wbSheet.setColumnWidth(i, colWidth < 3000 ? 3000 : colWidth);
            } else {
                wbSheet.setColumnWidth(i, 6000);
            }
        }
        if (settingSimple != null) {
            WatermarkUtils.addWaterMark(wb, wbSheet, settingSimple);
        }
        return wb;
    }

    public static XSSFWorkbook setGroupExcelData(List<Map<Integer, Object>> mapList) {
        String inHeadContext = ""
                + "1.支持Excel 2007及以上版本文件；1.Support Excel 2007 and above；\n"
                + "2.文件格式见示例批量导入模板文件<1>；2.See sample file for file format<1>；\n"
                + "3 不能在本excel表中对表字段进行增加、删除、修改；Cannot add, delete, or modify table fields in this excel sheet；\n";
        XSSFWorkbook wb = new XSSFWorkbook();

        XSSFSheet wbSheet = wb.createSheet("Sheet1");
        //第一行：11号、黑色
        CellRangeAddress region = new CellRangeAddress(0, 0, 0, 3);
        wbSheet.addMergedRegion(region);
        XSSFCellStyle contentStyle = wb.createCellStyle();
        XSSFFont contentFont = wb.createFont();
        contentFont.setFontName("宋体");
        contentFont.setFontHeightInPoints((short) 11);
        contentFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        contentStyle.setFont(contentFont);
        contentStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        XSSFRow row = wbSheet.createRow(0);
        row.setHeight((short) (20 * 120));
        XSSFCell headContext = row.createCell(0);
        contentStyle.setWrapText(true);
        headContext.setCellStyle(contentStyle);
        headContext.setCellValue(inHeadContext + "");
        //第二行：加粗、14号、深灰色
        //第三行：11号、黑色、加粗、灰色背景
        XSSFCellStyle contentStyle3 = wb.createCellStyle();
        XSSFFont contentFont3 = wb.createFont();
        contentFont3.setFontName("宋体");
        contentFont3.setBold(true);
        contentFont3.setFontHeightInPoints((short) 11);
        contentStyle3.setFont(contentFont3);
        contentStyle3.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());
        contentStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        contentStyle3.setAlignment(HorizontalAlignment.CENTER);
        XSSFRow row3 = wbSheet.createRow(1);
        XSSFCell cellHead3;
        cellHead3 = row3.createCell(0);
        cellHead3.setCellValue("用户组名称");
        cellHead3.setCellStyle(contentStyle3);
        cellHead3 = row3.createCell(1);
        cellHead3.setCellValue("用户组全路径");
        cellHead3.setCellStyle(contentStyle3);
        //数据行：11号、黑色、边框
        XSSFCellStyle contentStyle4 = wb.createCellStyle();
        contentStyle4.cloneStyleFrom(contentStyle);
        contentStyle4.setAlignment(HorizontalAlignment.CENTER);
        contentStyle4.setBorderBottom(BorderStyle.THIN);
        contentStyle4.setBorderTop(BorderStyle.THIN);
        contentStyle4.setBorderRight(BorderStyle.THIN);
        contentStyle4.setBorderLeft(BorderStyle.THIN);
        for (int i = 0; i < mapList.size(); i++) {
            XSSFRow roww = wbSheet.createRow(i + 2);
            XSSFCell cell;
            for (int j = 0; j < 2; j++) {
                cell = roww.createCell(j);
                Object valueObject = mapList.get(i).get(j);
                String value;
                if (valueObject == null) {
                    valueObject = "";
                }
                if (valueObject instanceof String) {
                    value = (String) valueObject;
                } else if (valueObject instanceof Integer) {
                    value = String.valueOf(((Integer) (valueObject)).floatValue());
                } else if (valueObject instanceof BigDecimal) {
                    value = String.valueOf(((BigDecimal) (valueObject)).floatValue());
                } else {
                    value = valueObject.toString();
                }
                cell.setCellValue(value);
                cell.setCellStyle(contentStyle4);
            }
        }
        for (int i = 0; i < 2; i++) {
            // 调整每一列宽度
            wbSheet.autoSizeColumn((short) i);
            // 解决自动设置列宽中文失效的问题
            int colWidth = wbSheet.getColumnWidth(i) * 17 / 10;
            if (colWidth < 255 * 256) {
                wbSheet.setColumnWidth(i, colWidth < 3000 ? 3000 : colWidth);
            } else {
                wbSheet.setColumnWidth(i, 6000);
            }
        }
        return wb;
    }

    /**
     * Description:  excel默认第三行默认为非重复属性名(中文字符串)，数据从第一列开始， 校验excel是否格式正确
     *
     * @param sheetNum sheet数（从0开始）
     * @param file     文件
     * @return list
     */
    public static Map<String, Object> getExcelDataForDepartment(File file, int sheetNum,
                                                                List<ExtendConfEntity> departmentExtendField) throws BaseException {
        Map<String, Object> results = ExcelUtil.generatorExcelDepartmentMap();
        try (InputStream fi = Files.newInputStream(file.toPath()); Workbook wb = WorkbookFactory.create(fi)) {
            Sheet sheet = wb.getSheetAt(sheetNum);
            int rowNum = sheet.getLastRowNum() + 1;
            //获取excel标头行
            Row titleRow = sheet.getRow(1);
            //获取Excel标准字段的下标索引
            Map<Integer, String> basicKeyIndex = ExcelUtil.generatorDepartmentExcelKeyMap(titleRow);
            //获取Excel拓展字段下标索引
            Map<Integer, String> extendKeyIndex = ExcelUtil.generatorDepartmentExcelExtendIndex(titleRow,
                    departmentExtendField);
            //标准字段数量判定
            if (basicKeyIndex.size() < 7) {
                throw new BaseException(IBaseExceptionCode.API_USER_EXCEL_HAVE_WRONG_COLUMN);
            }
            //解析部门数据
            for (int i = 2; i < rowNum; i++) {
                ExcelUtil.parseDepartmentExcelData(sheet, i, results, basicKeyIndex, extendKeyIndex);
            }
        } catch (IOException e) {
            log.error("Error reading department information from Excel :", e);
            throw new BaseException(IBaseExceptionCode.EXCEL_HANDLE_WRONG, e);
        }
        return results;
    }

    private static void addExcelDepartmentBasicData(Map<String, Object> dataMap, String cellValue, int keyIndex) {
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.NAME.getIndex()) {
            List<String> departmentNameList = (List<String>) dataMap.get("departmentNameList");
            departmentNameList.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.CODE.getIndex()) {
            List<String> departmentCodeList = (List<String>) dataMap.get("departmentCodeList");
            departmentCodeList.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.PARENTCODE.getIndex()) {
            List<String> parentDepartmentCodeList = (List<String>) dataMap.get("parentDepartmentCodeList");
            parentDepartmentCodeList.add(cellValue);
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.TYPE.getIndex()) {
            List<String> departmentTypeList = (List<String>) dataMap.get("departmentTypeList");
            departmentTypeList.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.STATUS.getIndex()) {
            List<String> deparmentStatusList = (List<String>) dataMap.get("deparmentStatusList");
            deparmentStatusList.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.ADDRESS.getIndex()) {
            List<String> departmentAddressList = (List<String>) dataMap.get("departmentAddressList");
            departmentAddressList.add(cellValue.toLowerCase());
        }
        if (StringUtils.isNotEmpty(cellValue) && keyIndex == DepartmentExcelEntity.PHONE.getIndex()) {
            List<String> departmentPhoneList = (List<String>) dataMap.get("departmentPhoneList");
            departmentPhoneList.add(cellValue);
        }
    }


    private static Map<String, Object> generatorExcelDepartmentMap() {
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> departmentList = new ArrayList<>();
        Map<Integer, List<String>> errorInfos = new HashMap<>();
        List<String> departmentNameList = new ArrayList<>();
        List<String> departmentCodeList = new ArrayList<>();
        List<String> parentDepartmentCodeList = new ArrayList<>();
        List<String> departmentTypeList = new ArrayList<>();
        List<String> deparmentStatusList = new ArrayList<>();
        List<String> departmentAddressList = new ArrayList<>();
        List<String> departmentPhoneList = new ArrayList<>();
        results.put("departmentNameList", departmentNameList);
        results.put("departmentCodeList", departmentCodeList);
        results.put("parentDepartmentCodeList", parentDepartmentCodeList);
        results.put("departmentTypeList", departmentTypeList);
        results.put("deparmentStatusList", deparmentStatusList);
        results.put("departmentAddressList", departmentAddressList);
        results.put("departmentPhoneList", departmentPhoneList);
        results.put("errorInfos", errorInfos);
        results.put("departmentList", departmentList);
        return results;
    }


    private static void parseDepartmentExcelData(Sheet sheet, int rowNum, Map<String, Object> dataMap,
                                                 Map<Integer, String> basicKeyIndex, Map<Integer, String> extendKeyIndex) {
        //获取当前的数据行
        Row row = sheet.getRow(rowNum);
        //跳过空行
        if (null == row) {
            log.info("Excel null row:{}", rowNum);
            return;
        }
        //获取每行的最后一个单元格位置
        int cellNum = row.getLastCellNum();
        //表格列数不应超过标准字段加拓展字段数量的和
        if (cellNum > DepartmentExcelEntity.getMaxIndexValue() + 1 + extendKeyIndex.size()) {
            Map<Integer, List<String>> errorInfos = (Map<Integer, List<String>>) dataMap.get("errorInfos");
            errorInfos.put(rowNum + 1, Collections.singletonList(Constant.DOUC_LANGUGE_TYPE_EN_US.equals(ThreadLocalUtil.getLanguage())
                    ? "The imported department file has out-of-region text" : "导入组织机构文件存在区域外文字"));
        } else {
            Map<String, Object> rowMap = Maps.newHashMap();
            for (int currentKeyIndex = 0; currentKeyIndex < cellNum; currentKeyIndex++) {
                //获取当前单元格数据
                Cell cell = row.getCell(Short.parseShort(currentKeyIndex + ""));
                String cellValue = null;
                if (null != cell) {
                    //判断excel单元格内容的格式，并对其进行转换，以便插入数据库
                    cellValue = ExcelUtil.convertCellType(cell);
                    //部门标准字段数据
                    ExcelUtil.addExcelDepartmentBasicData(dataMap, cellValue, currentKeyIndex);
                    //标准字段填入部门数据填入
                    if (StringUtils.isNotEmpty(basicKeyIndex.get(currentKeyIndex)) && StringUtils.isNotEmpty(
                            cellValue)) {
                        rowMap.put(basicKeyIndex.get(currentKeyIndex), cellValue);
                    }
                    //拓展字段部门数据填入
                    if (StringUtils.isNotEmpty(extendKeyIndex.get(currentKeyIndex)) && StringUtils.isNotEmpty(
                            cellValue)) {
                        //拓展字段数据
                        ExcelUtil.addExcelExtendData(dataMap, extendKeyIndex, currentKeyIndex, cellValue);
                        //拓展字段用户数据
                        rowMap.put(extendKeyIndex.get(currentKeyIndex), cellValue);
                    }
                }
            }
            //添加部门对象
            if (rowMap.size() > 0) {
                List<Map<String, Object>> departmentList = (List<Map<String, Object>>) dataMap.get("departmentList");
                departmentList.add(rowMap);
            }
        }
    }

    private static Map<Integer, String> generatorDepartmentExcelKeyMap(Row row) {
        Map<Integer, String> resuleMap = Maps.newHashMap();
        for (int currentCellNum = 0; currentCellNum < row.getLastCellNum(); currentCellNum++) {
            Cell cell = row.getCell(Short.parseShort(currentCellNum + ""));
            //获取列值
            String cellValue = cell.getStringCellValue();
            //根据下标获取列名
            String excelName = DepartmentExcelEntity.getExcelRowNameByIndex(currentCellNum);
            if (StringUtils.isNotEmpty(cellValue) && cellValue.equals(excelName)) {
                resuleMap.put(currentCellNum, currentCellNum + "");
            }
        }
        return resuleMap;
    }

    private static Map<Integer, String> generatorDepartmentExcelExtendIndex(Row row,
                                                                            List<ExtendConfEntity> depertmentExtendField) {
        //获取标准字段的最大下标用于过滤掉标准字段数据
        int maxIndexValue = DepartmentExcelEntity.getMaxIndexValue();
        //回参容器
        Map<Integer, String> resuleMap = Maps.newHashMap();
        //从标准字段最大下标开始遍历
        for (int currentCellNum = maxIndexValue + 1; currentCellNum < row.getLastCellNum(); currentCellNum++) {
            Cell cell = row.getCell(Short.parseShort(currentCellNum + ""));
            //获取列值
            String cellValue = cell.getStringCellValue();
            //拓展字段名列表
            List<String> dataList = depertmentExtendField.stream().map(ExtendConfEntity::getAlias)
                    .collect(Collectors.toList());
            //拓展字段
            if (StringUtils.isNotEmpty(cellValue)) {
                //根据换行符拆分获取拓展字段名
                String[] split = cellValue.split("\\n");
                //别名删除可能存在的必填标识
                String extendKey = split[1].replace("（required）", "");
                //生成excel拓展字段的下标索引，key为excel中的下标，value是拓展字段别名
                if (dataList.contains(extendKey)) {
                    resuleMap.put(currentCellNum, extendKey + Constant.EXCEL_EXTEND_FIELD_PREFIX);
                } else {
                    throw new BaseException(IBaseExceptionCode.API_EXCEL_TEMPLATE_ERROR);
                }
            }
        }
        return resuleMap;
    }

    public static Workbook getExcelWorkbookToFile(String filePath) {
        try (InputStream inputStream = Files.newInputStream(Paths.get(filePath))) {
            return ExcelUtil.getWorkbookByFileNameAndFileInputStream(new File(filePath).getName(), inputStream);
        } catch (Exception e) {
            log.error("Excel解析失败: ", e);
            throw new BaseException(IBaseExceptionCode.API_USER_BATCH_DOWNLOAD, e);
        }
    }

    public static CellStyle getOrdinaryCellStyle(Workbook workbook) {
        //创建列样式
        CellStyle cellStyle = workbook.createCellStyle();
        //设置边框
        ExcelUtil.setBorder(cellStyle);
        //设置自动换行
        cellStyle.setWrapText(true);
        //设置字体
        Font font = workbook.createFont();
        font.setFontName("宋体");
        font.setFontHeightInPoints((short) 11);
        font.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        //设置单元格字体
        cellStyle.setFont(font);
        //设置单元格背景颜色
        cellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.WHITE.getIndex());
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        //设置单元格水平居中
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        //设置单元格垂直居中
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        return cellStyle;
    }

    /**
     * 设置单元格边框
     *
     * @param cellStyle
     * @return void
     * @description
     * @author bernie.wang
     * @date 2022/10/30
     * @time 3:54 上午
     */
    private static void setBorder(CellStyle cellStyle) {
        cellStyle.setBorderBottom(BorderStyle.THIN); //下边框
        cellStyle.setBorderLeft(BorderStyle.THIN); //左边框
        cellStyle.setBorderTop(BorderStyle.THIN); //上边框
        cellStyle.setBorderRight(BorderStyle.THIN); //右边框
    }

    /**
     * 添加Excel下拉项
     *
     * @param sheet       sheet页
     * @param optionsList 下拉选项列表
     * @param colNum      添加的列号
     * @return void
     * @description
     * @author bernie.wang
     * @date 2022/11/1
     * @time 11:54 上午
     */
    public static void addSelectedList(Sheet sheet, List<String> optionsList, Integer colNum) {
        if (CollectionUtil.isEmpty(optionsList)) {
            return;
        }
        String[] optionArray = optionsList.toArray(new String[optionsList.size()]);
        //设置行列范围(资源类型)
        CellRangeAddressList addressList = new CellRangeAddressList(2, 15, colNum, colNum);
        //数据校验实体
        DataValidation validation = null;
        //按数据量选择约束数据添加方式
        if (optionArray.length > 15) {
            validation = ExcelUtil.getExcelComplexDataValidation(sheet, addressList, optionArray);
        } else {
            validation = ExcelUtil.getExcelSimpleDataValidation(sheet, addressList, optionArray);
        }
        //添加下拉约束
        sheet.addValidationData(validation);
    }

    public static DataValidation getExcelSimpleDataValidation(Sheet sheet, CellRangeAddressList addressList,
                                                              String[] optionArray) {
        //获取Excel数据校验helper类
        DataValidationHelper helper = sheet.getDataValidationHelper();
        //数据有效性
        DataValidationConstraint constraint = helper.createExplicitListConstraint(optionArray);
        //绑定下拉框数据
        return helper.createValidation(constraint, addressList);
    }

    public static DataValidation getExcelComplexDataValidation(Sheet sheet, CellRangeAddressList addressList,
                                                               String[] optionArray) {
        Workbook wb = sheet.getWorkbook();
        //获取所有sheet页个数
        int sheetTotal = wb.getNumberOfSheets();
        String hiddenSheetName = "hiddenSheet" + sheetTotal;
        XSSFSheet hiddenSheet = (XSSFSheet) wb.createSheet(hiddenSheetName);
        Row row;
        //写入下拉数据到新的sheet页中
        for (int i = 0; i < optionArray.length; i++) {
            row = hiddenSheet.createRow(i);
            Cell cell = row.createCell(0);
            cell.setCellValue(optionArray[i]);
        }
        //获取新sheet页内容
        String strFormula = hiddenSheetName + "!$A$1:$A$" + optionArray.length;
        XSSFDataValidationConstraint constraint = new XSSFDataValidationConstraint(
                DataValidationConstraint.ValidationType.LIST, strFormula);
        // 数据有效性对象
        DataValidationHelper help = new XSSFDataValidationHelper((XSSFSheet) sheet);
        DataValidation validation = help.createValidation(constraint, addressList);
        //将新建的sheet页隐藏掉
        wb.setSheetHidden(sheetTotal, true);
        return validation;
    }

    public static void setAutoColumnWidth(Sheet sheet, int columnNum) {
        for (int i = 0; i < columnNum; i++) {
            // 调整每一列宽度
            sheet.autoSizeColumn((short) i);
            // 解决自动设置列宽中文失效的问题
            int colWidth = sheet.getColumnWidth(i) * 17 / 10;
            if (colWidth < 255 * 256) {
                sheet.setColumnWidth(i, colWidth < 3000 ? 3000 : colWidth);
            } else {
                sheet.setColumnWidth(i, 6000);
            }
        }
    }

    /**
     * 从模版中获取必填单元格样式
     *
     * @return org.apache.poi.ss.usermodel.CellStyle
     * @description
     * @author bernie.wang
     * @date 2022/11/1
     * @time 11:55 上午
     */
    public static CellStyle getExcelTemplateCellStrlyToRequire(Row row, int cellNum) {
        return row.getCell(cellNum).getCellStyle();
    }

    /**
     * 从模版中获取非必填单元格样式
     *
     * @return org.apache.poi.ss.usermodel.CellStyle
     * @description
     * @author bernie.wang
     * @date 2022/11/1
     * @time 11:55 上午
     */
    public static CellStyle getExcelTemplateCellStrlyToNotRequire(Row row, int cellNum) {
        return row.getCell(cellNum).getCellStyle();
    }

    public static void paddingDataCellStyle(Sheet sheet, Integer colNum, CellStyle cellStyle) {
        //补充数据单元格样式
        for (int i = 2; i < sheet.getPhysicalNumberOfRows(); i++) {
            sheet.getRow(i).createCell(colNum).setCellStyle(cellStyle);
        }
    }

    public static void setCellDefaultData(Sheet sheet, Integer colNum, String data) {
        //补充数据单元格默认值
        sheet.getRow(2).getCell(colNum).setCellValue(data);
    }

    public static String getMultiSelectSeparator() {
        return StrPool.COMMA;
    }

    public static final Pattern INT_PATTERN = Pattern.compile("[0-9]*");

    public static void isInteger(String str) {
        Matcher isNum = INT_PATTERN.matcher(str);
        if (!isNum.matches()) {
            throw new BaseException(IBaseExceptionCode.API_USER_EXTEND_DATA_TYPE_EXCEPTION);
        }
    }

    public static void isDouble(String str) {
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException numberFormatException) {
            throw new BaseException(IBaseExceptionCode.API_USER_EXTEND_DATA_TYPE_EXCEPTION, numberFormatException);
        }
    }

    public static void updateExcelNoteRegion(Sheet sheet) {
        short lastCellNum = sheet.getRow(1).getLastCellNum();
        CellRangeAddress mergedRegion = sheet.getMergedRegion(0);
        mergedRegion.setLastColumn(lastCellNum - 1);
        sheet.removeMergedRegion(0);
        sheet.addMergedRegion(mergedRegion);
    }
}
