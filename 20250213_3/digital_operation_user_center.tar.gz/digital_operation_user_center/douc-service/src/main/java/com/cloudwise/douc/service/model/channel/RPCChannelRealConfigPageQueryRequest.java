package com.cloudwise.douc.service.model.channel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author zafir.zhong
 * @description 渠道实际配置条件查询
 * @date Created in 14:59 2022/5/17.
 */
@Data
public class RPCChannelRealConfigPageQueryRequest {
    @ApiModelProperty(value = "当前页数")
    private Integer current = 1;
    @ApiModelProperty(value = "每页大小")
    private Integer size = 10;
    @ApiModelProperty(value = "租户id")
    private Long accountId;

    @ApiModelProperty(value = "模块选项")
    private String moduleChoice;
    @ApiModelProperty(value = "渠道编码")
    private String channelCode;
    @ApiModelProperty(value = "渠道名称模糊查询")
    private String name;

    @ApiModelProperty(value = "国际化中英文转化")
    private String language;

    @ApiModelProperty(value = "查询的id范围")
    private List<Long> ids;
    @ApiModelProperty(value = "按照字段内容查询")
    private Map<String, String> fieldQuery;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
