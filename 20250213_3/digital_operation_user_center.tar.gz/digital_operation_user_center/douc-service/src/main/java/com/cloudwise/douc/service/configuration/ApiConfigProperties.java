package com.cloudwise.douc.service.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 21:32 2020/11/28.
 */
@Component
@ConfigurationProperties(prefix = "api.server")
@Data
public class ApiConfigProperties {
    private List<String> cors;
}
