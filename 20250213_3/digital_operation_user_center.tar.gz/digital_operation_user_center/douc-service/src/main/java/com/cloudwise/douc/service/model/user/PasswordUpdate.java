package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;

/**
 * @author barney.song
 * Description: No Description
 */

@Data
public class PasswordUpdate implements Serializable {
    private Long id;
    private String oldPassword;
    private String newPassword;
}
