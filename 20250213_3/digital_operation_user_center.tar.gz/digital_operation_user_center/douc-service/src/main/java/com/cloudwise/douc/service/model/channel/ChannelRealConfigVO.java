package com.cloudwise.douc.service.model.channel;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


/**
 * 渠道实际配置表
 *
 * @author maker.wang
 * @date 2022-08-19 14:03
 **/
@Data
@ApiModel(value = "渠道实际配置表")

public class ChannelRealConfigVO implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "渠道唯一key")
    private String channelConfigKey;

    @ApiModelProperty(value = "进行配置的租户id，所有的渠道配置是租户完全隔离的")
    private Long accountId;

    @ApiModelProperty(value = "配置的名称，用户填写的配置名称，为用户新增的信息，所以可以收到填写正文或英文，不在此处独立字段互")
    private String name;

    @ApiModelProperty(value = "配置的产品模块")
    private String moduleCode;

    @ApiModelProperty(value = "渠道的编码，对应渠道表中的编码")
    private String channelCode;


    @ApiModelProperty(value = "企业ID")
    private String enterpriseId;

    @ApiModelProperty(value = "应用ID")
    private String agentId;

    @ApiModelProperty(value = "获取codeURL")
    private String proxyFeishuGetCodeUrl;


}
