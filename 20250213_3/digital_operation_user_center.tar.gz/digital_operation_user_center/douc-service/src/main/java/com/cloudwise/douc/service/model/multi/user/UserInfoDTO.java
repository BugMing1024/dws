package com.cloudwise.douc.service.model.multi.user;

import com.cloudwise.douc.metadata.model.department.DepartmentUserRelation;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author bradyliu
 * @description:
 * @date Created in 14:52 2021/7/30.
 */
@Data
public class UserInfoDTO implements Serializable {
    private static final long serialVersionUID = -1;
    /**
     * 用户ID
     */
    private Long id;
    /**
     * 用户名
     */
    private String name;
    /**
     * 手机号 必填，可用于登录和短信验证码
     */
    private String mobile;
    /**
     * 联系方式，固话或手机号码，预留字段
     */
    private String phone;
    /**
     * 联系邮箱
     */
    private String email;
    /**
     * 用户密码
     */
    private String password;
    /**
     * 用户导入来源 1 douc 2dosm
     */
    private Integer origin;
    /**
     * 用户别名
     */
    private String userAlias;
    /**
     * 用户类型  1个人用户 2企业用户（冗余）
     */
    private Object type;
    /**
     * 国家
     */
    private String state;
    /**
     * 地区
     */
    private String region;
    /**
     * 城市
     */
    private String city;
    /**
     * 属性字段2
     */
    private String attribute2;
    /**
     * 属性字段1
     */
    private String attribute1;
    /**
     * 最后登录IP
     */
    private String lastIp;
    /**
     * 最后登录时间
     */
    private String lastTime;
    /**
     * 1 初始化系统管理员 2普通用户
     */
    private Integer adminType;
    /**
     * 钉钉账号
     */
    private String dingtalkAccount;
    /**
     * 企业微信账号
     */
    private String weixinworkAccount;
    /**
     * 企业微信账号
     */
    private String feishuAccount;
    /**
     * 微信公众号账号
     */
    private String wxpushAccount;
    /**
     * 编码
     */
    private String code;
    /**
     * 冗余字段
     */
    private String extra;
    /**
     * 员工号
     */
    private String workNum;

    private String ldapDn;

    private String ldapUserId;
    /**
     * 国际化语言类型 en 英文，zh中文
     */
    private String userLanguage;
    /**
     * sm3（密码的SM3摘要值）
     */
    private String smPasswordCpd;
    /**
     * sm2（sm3（密码的SM3摘要值））
     */
    private String smPasswordBpd;
    /**
     * 顶级租户id
     */
    private Long topAccountId;
    /**
     * 默认租户id
     */
    private Long defaultAccountId;

    private Long createUserId;

    private Date createTime;

    private Long modifyUserId;

    private Date modifyTime;
    /**
     * 拓展字段返回
     */
    private List<Map<String, Object>> extend;
    /**
     * 备注
     */
    private String remark;

    private List<DepartmentUserRelation> departmentUserRelations;
    /**
     * 用于前端是否可更改内容邮箱方面的内容,TRUE 没有值可更改，FALSE为不可更改
     */
    private Boolean emailChangeFlag;
}
