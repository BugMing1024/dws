package com.cloudwise.douc.service.model.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


/**
 * 平台免密登录用户信息：SaaS和私有部署共用
 *
 * @author maker.wang
 * @date 2022-08-22 17:07
 **/
@Data
@ApiModel("平台免密登录用户信息：SaaS和私有部署共用")
public class UserForPlatformLogin implements Serializable {
    private static final long serialVersionUID = -565177074406915020L;

    @ApiModelProperty(value = "LoginUserId/UserId")
    private Long id;

    @ApiModelProperty(value = "userId")
    private Long userId;

    @ApiModelProperty("用户姓名")
    private String name;

    @ApiModelProperty("手机号")
    private String mobile;

    @ApiModelProperty("邮箱")
    private String email;

    @ApiModelProperty("用户别名")
    private String userAlias;

    private Long accountId;
    private String accountName;
    private Integer accountStatus;
    private Long topAccountId;
    private String topAccountName;

    @ApiModelProperty(value = "默认顶级租户id")
    private Long defaultTopAccountId;

}
