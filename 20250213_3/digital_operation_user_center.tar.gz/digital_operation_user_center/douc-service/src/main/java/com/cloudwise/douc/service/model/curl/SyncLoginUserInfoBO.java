package com.cloudwise.douc.service.model.curl;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 同步和登录有关用户数据入参
 *
 * @author maker.wang
 * @date 2022-08-24 13:49
 **/
@Data
@ApiModel("同步和登录有关用户数据入参")
public class SyncLoginUserInfoBO implements Serializable {
    private static final long serialVersionUID = -3224774111777377930L;

    @ApiModelProperty("用户ID集合")
    private List<Long> userIdList;

    @ApiModelProperty("租户ID")
    private Long accountId;

}
