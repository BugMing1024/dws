package com.cloudwise.douc.service.model.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 用户返回数据类
 */
@Data
@ApiModel
public class UserInfoDto implements Serializable {
    @ApiModelProperty(value = "用户id")
    private Long userId;
    @ApiModelProperty(value = "租户id")
    private Long accountId;
    @ApiModelProperty(value = "名称")
    private String name;
    @ApiModelProperty(value = "手机")
    private String mobile;
    @ApiModelProperty(value = "邮箱")
    private String email;
    @ApiModelProperty(value = "状态")
    private Integer status;
    @ApiModelProperty(value = "用户别名")
    private String userAlias;
    @ApiModelProperty(value = "部门id")
    private Long departmentId;
    @ApiModelProperty(value = "部门")
    private String department;
    @ApiModelProperty(value = "部门层级")
    private String departmentLevel;
    @ApiModelProperty(value = "用户来源")
    private String userOrigin;
    @ApiModelProperty(value = "拓展字段")
    private String attribute;
    @ApiModelProperty(value = "钉钉账号")
    private String dingtalkAccount;
    @ApiModelProperty(value = "微信账号")
    private String weixinworkAccount;
    @ApiModelProperty(value = "飞书账号")
    private String feishuAccount;
    @ApiModelProperty(value = "微信公众号账号")
    private String wxpushAccount;
    @ApiModelProperty(value = "职务")
    private String position;
    @ApiModelProperty(value = "电话")
    private String phone;
    /**
     * 拓展字段返回
     */
    @ApiModelProperty(value = "拓展字段返回")
    private List<Map<String, Object>> extend;

    @ApiModelProperty(value = "用户id")
    private Long id;


    @ApiModelProperty(value = "区号")
    private String areaCode;

}
