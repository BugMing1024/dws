package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.metadata.model.user.UserInfoPO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 用户详情结果类
 */
@Data
@ApiModel
public class UserDetailInfoPO extends UserInfoPO implements Serializable {

    @ApiModelProperty(value = "城市")
    private String city;
    @ApiModelProperty(value = "编码")
    private String code;
    @ApiModelProperty(value = "地区")
    private String region;
    @ApiModelProperty(value = "手机号")
    private String phone;
    @ApiModelProperty(value = "部门详情")
    private String departmentDetail;
    @ApiModelProperty(value = "部门Code")
    private String departmentCode;
    @ApiModelProperty(value = "角色id集合")
    private List<Long> roleIds;
    @ApiModelProperty(value = "组id集合")
    private List<Long> groupIds;

}
