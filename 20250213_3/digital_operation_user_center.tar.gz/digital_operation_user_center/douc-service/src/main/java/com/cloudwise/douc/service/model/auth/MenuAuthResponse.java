package com.cloudwise.douc.service.model.auth;

import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

/**
 * @author barney.song
 * Description: No Description
 */
@Data
@ApiModel
public class MenuAuthResponse implements Serializable {
    private static final long serialVersionUID = -6742176385133429860L;
    @ApiModelProperty(value = "模块编码")
    private String moduleCode;
    @ApiModelProperty(value = "模块名称")
    private String moduleName;
    @ApiModelProperty(value = "英文模块名称")
    private String moduleEnName;
    private List<MenuResponse> menus;
    @ApiModelProperty(value = "接口权限id Set集合")
    private Set<String> interfaceAuthIds;

    public MenuAuthResponse(String moduleCode, String moduleName, List<MenuResponse> menus, Set<String> interfaceAuthIds) {
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.menus = menus;
        this.interfaceAuthIds = interfaceAuthIds;
    }

    public MenuAuthResponse() {
    }
}
