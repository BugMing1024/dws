package com.cloudwise.douc.service.model.multi.tenant;

import lombok.Data;

import java.io.Serializable;

/**
 * 系统配置表(SysSystemSetting)实体类
 *
 * @author makejava
 * @since 2021-07-02 14:11:55
 */
@Data
public class MultiAccountSystemSetting implements Serializable {
    private static final long serialVersionUID = -35981659416547582L;
    /**
     * 自增主键
     */
    private Long id;
    /**
     * 租户id
     */
    private Long accountId;
    /**
     * 配置名称
     */
    private String configurationName;
    /**
     * 配置内容
     */
    private String configurationValue;
    /**
     * 配置描述
     */
    private String description;
    /**
     * 修改人
     */
    private Long updateUserId;
    /**
     * 修改时间
     */
    private String updateTime;

}
