package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.validation.validator.Mobile;
import com.cloudwise.douc.commons.validation.validator.Password;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 三一手机号注册用户VO
 */
@Data
public class UserRegisterVO implements Serializable {
    private String name;
    /**
     * 公众号code
     */
    private String code;
    @Mobile
    private String mobile;
    //@NotBlank(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_NOT_BLANK)
    private String email;
    /**
     * 加密类型 1 sm2 2 AES 3 sm2sm3 加密后不可逆
     */
    private String encrypt;
    @Password
    private String password;
    //邀请码
    @NotNull(message = "invitationCode not blank")
    private String invitationCode;
    private String password2;
    private String password3;
    private Integer status;
    @NotBlank(message = IBaseExceptionCode.API_USER_MODEL_USERALIAS_NOT_BLANK)
    private String userAlias;
    private Long accountId;
    //部门
    private String company;
    //手机号前缀
    private String prefix;
    //地址
    private String address;
    //拓展
    private List<Map<String, Object>> extend;
    //验证码
    private String verificationCode;

    /**
     * 多租户 部门id
     **/
    private Long departmentId;

}
