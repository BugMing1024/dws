package com.cloudwise.douc.service.dataflow.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.constant.StrConstant;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.metadata.model.quota.AccountQuotaInfo;
import com.cloudwise.douc.service.cache.AccountDataCache;
import com.cloudwise.douc.service.constants.data.AccountConstants;
import com.cloudwise.douc.service.dataflow.IAccountDataFlow;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.util.AccountUserOperatEnum;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author bradyliu
 * @description:
 * @date Created in 15:30 2021/7/5.
 */
@Component
@Slf4j
public class AccountDataFlowImpl implements IAccountDataFlow {

    @Autowired
    private IAccountService accountService;
    @Autowired
    private AccountDataCache accountDataCache;

    @Override
    public void loadAllUserCountCache() {
        accountDataCache.loadAllUserCountCache();
    }


    @Override
    public Map<String, Set<String>> getUserCountCache(Long accountId) {
        return accountDataCache.getUserCountCache(accountId);
    }

    @Override
    public void setUserCountCacheIncrease(Long accountId, Map<String, Set<String>> countMap) {
        accountDataCache.setUserCountCacheIncrease(accountId, countMap);
    }

    @Override
    public void setUserCountCacheDecrease(Long accountId, Map<String, Set<String>> countMap) {
        accountDataCache.setUserCountCacheDecrease(accountId, countMap);
    }

    @Override
    public void setUserCountCacheByTopAccountId(Long accountId) {
        accountDataCache.setUserCountCacheByTopAccountId(accountId);
    }

    @Override
    public AccountDetail getAccountDetailByAccountId(Long accountId) {
        AccountDetail accountDetailByAccountId = accountDataCache.getAccountDetailByAccountId(accountId);
        if (accountDetailByAccountId == null || AccountConstants.Status.ENABLED != accountDetailByAccountId.getStatus()) {
            accountDetailByAccountId = accountService.getAccountDetailById(accountId);
            accountDataCache.setAccountDetailByAccountId(accountId, accountDetailByAccountId);
        }
        return accountDetailByAccountId;
    }

    @Override
    public void deleteAccountDetailCacheByAccountId(List<Long> accountIds) {
        accountDataCache.deleteAccountDetailByAccountId(accountIds);
    }

    @Override
    public List<Long> getParentId(String level) {
        String[] split = level.split(Constant.LEVEL_SPLIT_REGEX);
        List<Long> parentIds = new ArrayList<Long>(split.length);

        for (String id : split) {
            // 去除无效id
            if (!"0".equals(id)) {
                parentIds.add(Long.valueOf(id));
            }

        }
        return parentIds;
    }


    @Override
    public List<Long> getIds(String level, Long id) {
        List<Long> ids = getParentId(level);
        ids.add(id);
        return ids;
    }


    @Override
    public Map<String, Set<String>> montageAccountUserMap(List<Long> accountIds, List<Long> userIds) {
        // 拼接租户用户id
        Map<String, Set<String>> countMap = Maps.newHashMapWithExpectedSize(accountIds.size());

        for (Long accountId : accountIds) {
            Set<String> idSet = countMap.getOrDefault(accountId.toString(), new TreeSet<>());
            for (Long userId : userIds) {
                idSet.add(accountId + StrConstant.EQ + userId);
            }
            countMap.put(accountId.toString(), idSet);
        }
        return countMap;
    }

    @Override
    public void accountPersonNumberCacheAddMethod(String level, Long accountId, Long topAccountId, List<Long> userIds, List<UserCountDO> moveForwardUserAccountRelation) {
        this.accountPersonNumberCache(null, level, accountId, topAccountId, userIds, moveForwardUserAccountRelation, null, AccountUserOperatEnum.ADD.getOpera());
    }

    @Override
    public void accountPersonNumberCacheDeleteMethod(String level, Long accountId, Long topAccountId, List<Long> userIds, List<UserCountDO> moveAfterUserAccountRelation) {
        this.accountPersonNumberCache(null, level, accountId, topAccountId, userIds, null, moveAfterUserAccountRelation, AccountUserOperatEnum.DELETE.getOpera());
    }

    @Override
    public void accountPersonNumberCacheUpateMethod(String oldLevel, String level, Long accountId, Long topAccountId, List<Long> userIds, List<UserCountDO> moveForwardUserAccountRelation, List<UserCountDO> moveAfterUserAccountRelation) {
        this.accountPersonNumberCache(oldLevel, level, accountId, topAccountId, userIds, moveForwardUserAccountRelation, moveAfterUserAccountRelation, AccountUserOperatEnum.UPDATE.getOpera());
    }

    /**
     * @param oldLevel                       旧的租户等级
     * @param level                          最终的租户等级
     * @param accountId                      租户id
     * @param topAccountId                   顶级租户id
     * @param userIds                        用户ids
     * @param moveForwardUserAccountRelation 移动前租户用户关系
     * @param moveAfterUserAccountRelation   移动后租户用户关系
     * @param flag                           新增、删除、移动标记
     * @return
     * @description 通过租户id和用户id更新人数（本方法只针对非顶级租户）
     * @author brady.liu
     * @date 2021/9/24
     * @time 14:33
     */
    private void accountPersonNumberCache(String oldLevel, String level, @NotNull Long accountId, @NotNull Long topAccountId, @NotNull List<Long> userIds,
                                          List<UserCountDO> moveForwardUserAccountRelation, List<UserCountDO> moveAfterUserAccountRelation, @NotNull String flag) {
        // 人数集合，以下集合结构都为 accountId_userId 格式
        // 计算公式
        // 需减少人数为： moveForwardSet - moveAfterAllSet  ① - ④
        // 需增加人数为： moveAfterSet - moveForwardAllSet  ② - ③


        // 移动前需操作租户和被操作用户关系 ①
        //Set<String> moveForwardSet = new TreeSet();
        Map<String, Set<String>> moveForwardMap = new HashMap<>();
        // 移动后需操作租户和被操作用户关系 ②
        //Set<String> moveAfterSet = new TreeSet();
        Map<String, Set<String>> moveAfterMap = new HashMap<>();
        // 移动前和被操作用户有关系的租户   ③
        //Set<String> moveForwardAllSet = new TreeSet();
        Map<String, Set<String>> moveForwardAllMap = new HashMap<>();
        // 移动后和被操作用户有关系的租户   ④
        //Set<String> moveAfterAllSet = new TreeSet();
        Map<String, Set<String>> moveAfterAllMap = new HashMap<>();


        // 如果是新增，只需要计算 ②和③的值
        if (flag.equals(AccountUserOperatEnum.ADD.getOpera())) {
            // 得到level
            List<Long> ids = this.getIds(level, accountId);
            // 当前租户和用户管理
            for (Long userId : userIds) {
                for (Long id : ids) {
                    Set<String> idSet = moveAfterMap.getOrDefault(id.toString(), new TreeSet<String>());
                    idSet.add(id + StrConstant.EQ + userId);
                    moveAfterMap.put(id.toString(), idSet);
                }
            }
            // 更新前查询租户和用户的关系
            if (moveForwardUserAccountRelation != null) {
                for (UserCountDO userCountDO : moveForwardUserAccountRelation) {
                    List<Long> aIds = this.getIds(userCountDO.getLevel(), userCountDO.getAccountId());
                    Long uId = userCountDO.getUserId();
                    for (Long aId : aIds) {
                        Set<String> idSet = moveForwardAllMap.getOrDefault(aId.toString(), new TreeSet<String>());
                        idSet.add(aId + StrConstant.EQ + uId);
                        moveForwardAllMap.put(aId.toString(), idSet);
                    }
                }
            }

            Map<String, Set<String>> increaseMap = new HashMap<>(moveAfterMap);
            // 得到需要accountId
            Set<Map.Entry<String, Set<String>>> entries = moveAfterMap.entrySet();
            for (Map.Entry<String, Set<String>> entry : entries) {
                increaseMap.get(entry.getKey()).removeAll(moveForwardAllMap.getOrDefault(entry.getKey(), new TreeSet<>()));
            }
            // 更新缓存人数
            accountDataCache.setUserCountCacheIncrease(topAccountId, increaseMap);
        }


        // 如果是删除，只需要计算 ①和④的值
        if (flag.equals(AccountUserOperatEnum.DELETE.getOpera())) {
            // 得到level
            List<Long> ids = this.getIds(level, accountId);
            // 当前租户和用户管理
            for (Long userId : userIds) {
                for (Long id : ids) {
                    Set<String> idSet = moveForwardMap.getOrDefault(id.toString(), new TreeSet<>());
                    idSet.add(id + StrConstant.EQ + userId);
                    moveForwardMap.put(id.toString(), idSet);
                }
            }

            // 更新后查询租户和用户的关系
            if (moveAfterUserAccountRelation != null) {
                for (UserCountDO userCountDO : moveAfterUserAccountRelation) {
                    List<Long> aIds = this.getIds(userCountDO.getLevel(), userCountDO.getAccountId());
                    Long uId = userCountDO.getUserId();
                    for (Long aId : aIds) {
                        Set<String> idSet = moveAfterAllMap.getOrDefault(aId.toString(), new TreeSet<>());
                        idSet.add(aId + StrConstant.EQ + uId);
                        moveAfterAllMap.put(aId.toString(), idSet);
                    }
                }
            }

            Map<String, Set<String>> decreaseMap = new HashMap<>(moveForwardMap);
            // 得到需要accountId
            Set<Map.Entry<String, Set<String>>> entries = moveForwardMap.entrySet();
            for (Map.Entry<String, Set<String>> entry : entries) {
                decreaseMap.get(entry.getKey()).removeAll(moveAfterAllMap.getOrDefault(entry.getKey(), new TreeSet<>()));
            }
            // 更新缓存
            accountDataCache.setUserCountCacheDecrease(topAccountId, decreaseMap);

        }

        // 如果是移动，①②③④都需要计算
        if (flag.equals(AccountUserOperatEnum.UPDATE.getOpera())) {
            // 得到level
            List<Long> ids = this.getIds(level, accountId);
            // 当前租户和用户管理
            for (Long userId : userIds) {
                for (Long id : ids) {
                    Set<String> idSet = moveAfterMap.getOrDefault(id.toString(), new TreeSet<>());
                    idSet.add(id + StrConstant.EQ + userId);
                    moveAfterMap.put(id.toString(), idSet);
                }
            }
            // 需要查询操作数据库前租户和用户关系
            if (moveForwardUserAccountRelation != null) {
                for (UserCountDO userCountDO : moveForwardUserAccountRelation) {
                    List<Long> aIds = this.getIds(userCountDO.getLevel(), userCountDO.getAccountId());
                    Long uId = userCountDO.getUserId();
                    for (Long aId : aIds) {
                        Set<String> idSet = moveForwardAllMap.getOrDefault(aId.toString(), new TreeSet<>());
                        idSet.add(aId + StrConstant.EQ + uId);
                        moveForwardAllMap.put(aId.toString(), idSet);
                    }
                }
            }
            Map<String, Set<String>> increaseMap = new HashMap<>(moveAfterMap);
            // 得到需要accountId
            Set<Map.Entry<String, Set<String>>> increaseEntries = moveAfterMap.entrySet();
            for (Map.Entry<String, Set<String>> entry : increaseEntries) {
                increaseMap.get(entry.getKey()).removeAll(moveForwardAllMap.getOrDefault(entry.getKey(), new TreeSet<>()));
            }

            // 得到level
            List<Long> oldIds = this.getIds(oldLevel, accountId);
            // 当前租户和用户管理
            for (Long userId : userIds) {
                for (Long id : oldIds) {
                    Set<String> idSet = moveForwardMap.getOrDefault(id.toString(), new TreeSet<>());
                    idSet.add(id + StrConstant.EQ + userId);
                    moveForwardMap.put(id.toString(), idSet);
                }
            }
            // 需要查询操作数据库后，租户和用户的关系
            if (moveAfterUserAccountRelation != null) {
                for (UserCountDO userCountDO : moveAfterUserAccountRelation) {
                    List<Long> aIds = this.getIds(userCountDO.getLevel(), userCountDO.getAccountId());
                    Long uId = userCountDO.getUserId();
                    for (Long aId : aIds) {
                        Set<String> idSet = moveAfterAllMap.getOrDefault(aId.toString(), new TreeSet<>());
                        idSet.add(aId + StrConstant.EQ + uId);
                        moveAfterAllMap.put(aId.toString(), idSet);
                    }
                }
            }
            Map<String, Set<String>> decreaseMap = new HashMap<>(moveForwardMap);
            // 得到需要accountId
            Set<Map.Entry<String, Set<String>>> decreaseEntries = moveForwardMap.entrySet();
            for (Map.Entry<String, Set<String>> entry : decreaseEntries) {
                decreaseMap.get(entry.getKey()).removeAll(moveAfterAllMap.getOrDefault(entry.getKey(), new TreeSet<>()));
            }
            // 更新新增的缓存
            accountDataCache.setUserCountCacheIncrease(topAccountId, increaseMap);
            // 更新减少的缓存
            accountDataCache.setUserCountCacheDecrease(topAccountId, decreaseMap);
        }
    }

    @Override
    public void setAccountQuotaInfo(Long accountId, AccountQuotaInfo aqi) {
        accountDataCache.setAccountQuotaInfo(accountId, aqi);
    }

    @Override
    public AccountQuotaInfo getAccountQuotaInfo(Long accountId) {
        return accountDataCache.getAccountQuotaInfo(accountId);
    }

    @Override
    public void loadAllAccountQuotaCache() {
        accountDataCache.loadAllAccountQuotaCache();
    }


    @Override
    public void batchDecreaseAccountPersonNumCache(Map<String, List<UserCountDO>> userAccounInfo, @NotNull Long accountId) {
        //查询用户数量缓存
        Map<String, Set<String>> userCountMap = this.getUserCountCache(accountId);

        Set<String> userMapKeys = userAccounInfo.keySet();
        userMapKeys.forEach(userKsye -> {

            Map<String, Set<String>> moveForwardMap = new HashMap<>();
            Map<String, Set<String>> moveAfterAllMap = new HashMap<>();

            //解析用户相关信息
            String[] keyArray = userKsye.split(StrPool.UNDERLINE);
            List<Long> userIds = Collections.singletonList(Long.valueOf(keyArray[0]));
            String level = keyArray[1];
            List<UserCountDO> moveAfterUserAccountRelation = userAccounInfo.get(userKsye);

            // 得到level
            List<Long> ids = this.getIds(level, accountId);
            // 当前租户和用户管理
            for (Long userId : userIds) {
                for (Long id : ids) {
                    Set<String> idSet = moveForwardMap.getOrDefault(id.toString(), new TreeSet<>());
                    idSet.add(id + StrConstant.EQ + userId);
                    moveForwardMap.put(id.toString(), idSet);
                }
            }

            // 更新后查询租户和用户的关系
            if (moveAfterUserAccountRelation != null) {
                for (UserCountDO userCountDO : moveAfterUserAccountRelation) {
                    List<Long> aIds = this.getIds(userCountDO.getLevel(), userCountDO.getAccountId());
                    Long uId = userCountDO.getUserId();
                    for (Long aId : aIds) {
                        Set<String> idSet = moveAfterAllMap.getOrDefault(aId.toString(), new TreeSet<String>());
                        idSet.add(aId + StrConstant.EQ + uId);
                        moveAfterAllMap.put(aId.toString(), idSet);
                    }
                }
            }

            Map<String, Set<String>> decreaseMap = new HashMap<>(moveForwardMap);
            // 得到需要accountId
            Set<Map.Entry<String, Set<String>>> entries = moveForwardMap.entrySet();
            for (Map.Entry<String, Set<String>> entry : entries) {
                decreaseMap.get(entry.getKey()).removeAll(moveAfterAllMap.getOrDefault(entry.getKey(), new TreeSet<>()));
            }

            for (Map.Entry<String, Set<String>> entry : decreaseMap.entrySet()) {
                Set<String> cacheCountSet = userCountMap.getOrDefault(entry.getKey(), new TreeSet<>());
                cacheCountSet.removeAll(entry.getValue());
                userCountMap.put(entry.getKey(), cacheCountSet);
            }
        });

        //更新新的用户数量缓存
        RedisTools.setJson(CacheConstant.REDIS_CACHE_KEY_ACCOUNT_TYPE_KEY + accountId, userCountMap);
    }


    @Override
    public void setAccountQuotaMenuInfo(Long accountId, Map<String, List<String>> map) {
        accountDataCache.setAccountQuotaMenuInfo(accountId, map);
    }

    @Override
    public Map<String, List<String>> getAccountQuotaMenuInfo(Long accountId) {
        return accountDataCache.getAccountQuotaMenuInfo(accountId);
    }

}
