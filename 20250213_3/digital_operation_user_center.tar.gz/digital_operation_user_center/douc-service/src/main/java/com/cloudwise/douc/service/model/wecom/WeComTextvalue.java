package com.cloudwise.douc.service.model.wecom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties
public class WeComTextvalue {

    private String value;
}
