package com.cloudwise.douc.service.constants.data;

public class MessageConstants {

    public static class DefaultMessageCode {
        public static final String MODULECODE = "100";
        public static final String LEVEL = "URGENT";
        public static final String CONTENTTYPE = "RICH_TEXT";
        public static final String TYPE = "SYSTEM";
        public static final String TITLE = "密码到期提醒";
        public static final String UPDATESECRETURI = "/doucWeb/index.html#/douc/setting/passwordSetting";
        public static final String VERSION = "2";
        public static final String SECRET_TITLE_PRE = "notice.message.password.title.";
    }

}
