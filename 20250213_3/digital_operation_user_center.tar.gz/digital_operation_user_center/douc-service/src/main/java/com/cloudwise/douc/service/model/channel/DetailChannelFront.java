package com.cloudwise.douc.service.model.channel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author zafir.zhong
 * @description 一个很详细的渠道配置
 * @date Created in 14:34 2022/5/5.
 */
@Data
public class DetailChannelFront {

    /**
     * 主键标识，此字段会用于页面中的查询、删除
     */
    @ApiModelProperty(value = "主键标识，此字段会用于页面中的查询、删除")
    private Long id;
    /**
     * 进行配置的租户id，所有的渠道配置是租户完全隔离的
     */
    @ApiModelProperty(value = "进行配置的租户id，所有的渠道配置是租户完全隔离的")
    private Long accountId;
    /**
     * 配置的名称，用户填写的配置名称，为用户新增的信息，所以可以收到填写正文或英文，不在此处独立字段互
     */
    @ApiModelProperty(value = "配置的名称，用户填写的配置名称，为用户新增的信息，所以可以收到填写正文或英文，不在此处独立字段互")
    private String name;
    /**
     * 渠道的编码，对应渠道表中的编码
     */
    @ApiModelProperty(value = "渠道的编码，对应渠道表中的编码")
    private String channelCode;

    /**
     * 渠道配置的唯一标识
     */
    @ApiModelProperty(value = "渠道配置的唯一标识")
    private String channelConfigKey;
    /**
     * key-value形式的内容，每个配置项中的key字段的对应内容，每个配置项中的value的对应内容
     */
    @ApiModelProperty(value = "key-value形式的内容，每个配置项中的key字段的对应内容，每个配置项中的value的对应内容")
    private List<ChannelStepConfig> config;
    @ApiModelProperty(value = "子类型的编码")
    private String subTypeCode;

}
