package com.cloudwise.douc.service.model.license;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

/**
 * @author elsa.yang
 * @date 2020/9/9 10:35 上午
 */
@Data
@ToString
@NoArgsConstructor
@Slf4j
public class BasicModule {
    //可用配额数
    private Long used;
    //剩余配额书
    private Long rest;
    //到期时间
    private Date endingTime;
}
