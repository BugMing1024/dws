package com.cloudwise.douc.service.util.httpclient;

import cn.hutool.core.map.MapUtil;
import cn.hutool.core.net.url.UrlBuilder;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.Method;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.constant.StrConstant;
import com.cloudwise.douc.commons.utils.JsonUtils;
import com.cloudwise.douc.commons.utils.XssCleanRuleUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLContext;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RefreshScope
@Slf4j
public class HttpClientHelper {

    public static final String STATUS_CODE = "statusCode";
    public static final String SUCCESS_STATUS_CODE = "200";
    public static final String RESPONSE_DATA = "responseData";
    private static final String CONTENT_TYPE_TEXT_JSON = "text/json";
    private static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";

    @Value("${sso.server.login.request.ssl.valid:false}")
    private Boolean sslValid;

    @Autowired
    private CloseableHttpClient httpClient;

    @Autowired
    private RequestConfig requestConfig;

    public Map<String, String> get(String url, HashMap<String, Object> paramMap, HashMap<String, Object> header) {
        if ("".equals(url)) {
            return Maps.newHashMap();
        }
        if (Objects.equals(ConfigUtils.getString("http.mode", "normal"), "hutool")) {
            Map<String, String> map = Maps.newHashMap();
            try {
                UrlBuilder urlBuilder = UrlBuilder.of(url);
                if (MapUtil.isNotEmpty(paramMap)) {
                    paramMap.forEach((k, v) -> {
                        urlBuilder.addQuery(k, v);
                    });
                }
                HttpRequest httpRequest = HttpRequest.get(urlBuilder.toString());
                if (MapUtil.isNotEmpty(header)) {
                    header.forEach((k, v) -> {
                        httpRequest.header(k, v.toString());
                    });
                }
                log.info("request:{}", httpRequest);
                HttpResponse execute = httpRequest.execute();
                String body = execute.body();
                log.info("resp status:{} body:{}", execute.getStatus(), body);
                // 获取响应状态
                int statusCode = execute.getStatus();
                map.put(HttpClientHelper.STATUS_CODE, String.valueOf(statusCode));
                map.put(HttpClientHelper.RESPONSE_DATA, body);
            } catch (Exception exception) {
                log.error("error send request", exception);
            }
            return map;
        }
        // 创建一个request对象
        HttpGet httpGet = new HttpGet(url);
        CloseableHttpResponse response = null;
        try {
            // 配置连接参数
            //获取代理
            // HttpHost proxy = getHttpHost();
            // if(proxy !=null){
            //     //设置代理
            //     requestConfig = RequestConfig.custom()
            //             .setConnectTimeout(5000)
            //             .setConnectionRequestTimeout(5000)
            //             .setSocketTimeout(5000)
            //             .setRedirectsEnabled(true).setProxy(proxy).build();
            // }
            httpGet.setConfig(requestConfig);
            // 设置参数
            if (paramMap != null && paramMap.size() > 0) {
                List<NameValuePair> params = Lists.newArrayListWithExpectedSize(paramMap.size());
                for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                    params.add(new BasicNameValuePair(entry.getKey(), URLEncoder.encode(String.valueOf(entry.getValue()), StandardCharsets.UTF_8.name())));
                }
                String strParams = EntityUtils.toString(new UrlEncodedFormEntity(params));
                // 防止多参数时，分隔符","被转义
                String realParams = URLDecoder.decode(strParams, StandardCharsets.UTF_8.name());
                URI old = httpGet.getURI();
                String oldScheme = old.getScheme() == null ? "" : old.getScheme();
                String oldUrl = old.getSchemeSpecificPart();
                URI uri;
                if (oldUrl.indexOf(StrConstant.C_DOUBT) > 0) {
                    uri = new URI(oldScheme + ':' + oldUrl + StrConstant.C_AND + realParams);
                } else {
                    uri = new URI(oldScheme + ':' + oldUrl + StrConstant.C_DOUBT + realParams);
                }
                httpGet.setURI(uri);
                //String urlStr = httpGet.getURI().toString();
                //httpGet.setURI(new URI(urlStr.indexOf(StrConstant.C_DOUBT) > 0 ? urlStr + StrConstant.C_AND + realParams : urlStr + StrConstant.C_DOUBT + realParams));
            }
            // 设置头
            if (header != null && header.size() > 0) {
                for (Map.Entry<String, Object> entry : header.entrySet()) {
                    httpGet.addHeader(XssCleanRuleUtils.xssClean(entry.getKey()), XssCleanRuleUtils.xssClean(entry.getValue().toString()));
                }
            }
            // 执行request请求
            response = httpClient.execute(httpGet);
            return parseResponse(response);

        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            httpGet.abort();
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error(ExceptionUtils.getStackTrace(e));
            }
        }
        return Maps.newHashMap();
    }

    public HttpHost getHttpHost() {
        HttpHost proxy = null;
        boolean isProxy = ConfigUtils.getBoolean("http.proxy");
        if (isProxy) {
            String proxyHost = ConfigUtils.getString("http.proxyHost", "");
            int proxyPort = ConfigUtils.getInt("http.proxyPort", 0);
            proxy = getRequestConfig(isProxy, proxyHost, proxyPort);
        }
        return proxy;
    }

    private HttpHost getRequestConfig(boolean isProxy, String proxyHost, int proxyPort) {
        log.debug("isProxy -result--  {}", isProxy);
        if (!isProxy) {
            return null;
        }
        return new HttpHost(proxyHost, proxyPort);
    }

    public Map<String, String> post(String url, HashMap<String, Object> paramMap, HashMap<String, Object> header) {
        if ("".equals(url)) {
            return Maps.newHashMap();
        }
        if (Objects.equals(ConfigUtils.getString("http.mode", "normal"), "hutool")) {
            Map<String, String> map = Maps.newHashMap();
            try {
                UrlBuilder urlBuilder = UrlBuilder.of(url);
                HttpRequest httpRequest = HttpRequest.post(urlBuilder.toString());
                if (MapUtil.isNotEmpty(paramMap)) {
                    httpRequest.form(paramMap);
                }
                if (MapUtil.isNotEmpty(header)) {
                    header.forEach((k, v) -> {
                        httpRequest.header(k, v.toString());
                    });
                }
                log.info("request:{}", httpRequest);
                HttpResponse execute = httpRequest.execute();
                String body = execute.body();
                log.info("resp status:{} body:{}", execute.getStatus(), body);
                // 获取响应状态
                int statusCode = execute.getStatus();
                map.put(HttpClientHelper.STATUS_CODE, String.valueOf(statusCode));
                map.put(HttpClientHelper.RESPONSE_DATA, body);
            } catch (Exception exception) {
                log.error("error send request", exception);
            }
            return map;
        }
        // 创建一个request对象
        HttpPost httpPost = new HttpPost(url);
        CloseableHttpResponse response = null;
        try {
            // 配置连接参数
            httpPost.setConfig(requestConfig);
            // 设置参数
            if (paramMap != null && paramMap.size() > 0) {
                List<NameValuePair> params = Lists.newArrayListWithExpectedSize(paramMap.size());
                for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                    params.add(new BasicNameValuePair(entry.getKey(), String.valueOf(entry.getValue())));
                }
                HttpEntity entity = new UrlEncodedFormEntity(params);
                httpPost.setEntity(entity);
            }
            // 设置头
            if (header != null && header.size() > 0) {
                for (Map.Entry<String, Object> entry : header.entrySet()) {
                    httpPost.addHeader(entry.getKey(), String.valueOf(entry.getValue()));
                }
            }
            // 执行request请求
            response = httpClient.execute(httpPost);
            return parseResponse(response);
        } catch (Exception e) {
            log.error("http get error:,url:{},paramMap:{}, header:{},exception:{}", url, paramMap, header, e);
            httpPost.abort();
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error(ExceptionUtils.getStackTrace(e));
            }
        }
        return Maps.newHashMap();
    }

    /**
     * 解析 response数据
     *
     * @param response
     * @return
     * @description
     * @author tangjingjing
     * @date 2018年10月12日
     */
    private Map<String, String> parseResponse(CloseableHttpResponse response) {
        String result = "";
        // 获取响应体
        HttpEntity httpEntity = null;
        InputStream inputStream = null;
        Map<String, String> map = Maps.newHashMap();
        try {
            // 获取响应状态
            int statusCode = response.getStatusLine().getStatusCode();
            map.put(HttpClientHelper.STATUS_CODE, String.valueOf(statusCode));
            // 获取响应体
            httpEntity = response.getEntity();
            if (httpEntity != null) {
                inputStream = httpEntity.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                reader.close();
                result = sb.toString();
                map.put(HttpClientHelper.RESPONSE_DATA, result);
            }

        } catch (Exception e) {
            log.error("HttpClientHelper parseResponse error:", e);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
            // 如果httpEntity没有被完全消耗，那么连接无法安全重复使用，将被关闭并丢弃
            try {
                EntityUtils.consume(httpEntity);
            } catch (IOException e) {
                log.error(ExceptionUtils.getStackTrace(e));
            }
        }

        return map;
    }

    private String reponseHandle(CloseableHttpResponse response) {
        String result = "";
        // 获取响应体
        HttpEntity httpEntity = null;
        try {
            // 获取响应状态
            int statusCode = response.getStatusLine().getStatusCode();
            // 没有正常响应
            if (statusCode < HttpStatus.SC_OK || statusCode >= HttpStatus.SC_MULTIPLE_CHOICES) {
                throw new RuntimeException("statusCode : " + statusCode);
            }
            // 获取响应体
            httpEntity = response.getEntity();
            if (httpEntity != null) {
                result = EntityUtils.toString(httpEntity);
            }

        } catch (Exception e) {
            log.error("HttpClientHelper reponseHandle error :", e);
        } finally {
            // 如果httpEntity没有被完全消耗，那么连接无法安全重复使用，将被关闭并丢弃
            try {
                EntityUtils.consume(httpEntity);
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
        return result;
    }


    public Map<String, String> postJson(String url, HashMap<String, Object> paramMap, HashMap<String, Object> header) {
        if (Objects.equals(ConfigUtils.getString("http.mode", "normal"), "hutool")) {
            Map<String, String> map = Maps.newHashMap();
            try {
                UrlBuilder urlBuilder = UrlBuilder.of(url);
                HttpRequest httpRequest = HttpRequest.post(urlBuilder.toString());
                if (MapUtil.isNotEmpty(paramMap)) {
                    httpRequest.body(JsonUtils.encode(paramMap));
                }
                if (MapUtil.isNotEmpty(header)) {
                    header.forEach((k, v) -> {
                        httpRequest.header(k, v.toString());
                    });
                }
                log.info("request:{}", httpRequest);
                HttpResponse execute = httpRequest.execute();
                String body = execute.body();
                log.info("resp status:{} body:{}", execute.getStatus(), body);
                // 获取响应状态
                int statusCode = execute.getStatus();
                map.put(HttpClientHelper.STATUS_CODE, String.valueOf(statusCode));
                map.put(HttpClientHelper.RESPONSE_DATA, body);
            } catch (Exception exception) {
                log.error("error send request", exception);
            }
            return map;
        }
        HttpPost httpPost = new HttpPost(url);


        ObjectMapper mapper = new ObjectMapper();
        httpPost.setConfig(requestConfig);
        String parameter = null;
        try {
            parameter = mapper.writeValueAsString(paramMap);
        } catch (JsonProcessingException e) {
            log.error("http post error.", e);
        }
        StringEntity se = null;
        log.info("-----------请求体 parameter{}", parameter);
        se = new StringEntity(parameter, StandardCharsets.UTF_8);
        se.setContentType(CONTENT_TYPE_TEXT_JSON);
        httpPost.setEntity(se);

        if (header != null && header.size() > 0) {
            for (Map.Entry<String, Object> entry : header.entrySet()) {
                httpPost.addHeader(XssCleanRuleUtils.xssClean(entry.getKey()), XssCleanRuleUtils.xssClean(entry.getValue().toString()));
            }
        }
        httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");

        CloseableHttpResponse response = null;
        Map<String, String> result = null;
        try {
            response = httpClient.execute(httpPost);
            return parseResponse(response);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    public Map<String, String> doPostJson(String url, String json) {
        String resultString = "";
        CloseableHttpResponse response = null;
        Map<String, String> result = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            httpPost.setHeader("HTTP Method", "POST");
            httpPost.setHeader("Connection", "Keep-Alive");
            httpPost.setHeader("Content-Type", "application/json;charset=utf-8");

            StringEntity entity = new StringEntity(json);

            entity.setContentType("application/json;charset=utf-8");
            httpPost.setEntity(entity);

            // 执行http请求
            response = httpClient.execute(httpPost);
            result = parseResponse(response);
        } catch (Exception e) {
            log.error("http post error.", e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("http client close error.", e);
            }
        }

        return result;
    }

    public Map<String, String> execute(String url, String method, String contentType, Map<String, String> paramMap, Map<String, String> header) {
        
        if (Objects.equals(ConfigUtils.getString("http.mode", "normal"), "hutool")) {
            Map<String, String> map = Maps.newHashMap();
            
            try {
                UrlBuilder urlBuilder = UrlBuilder.of(url);
                HttpRequest httpRequest = new HttpRequest(urlBuilder);
                switch (contentType) {
                    case "json": {
                        httpRequest.header("Content-Type", "application/json;charset=UTF-8");
                        if (MapUtil.isNotEmpty(paramMap)) {
                            httpRequest.body(JsonUtils.encode(paramMap));
                        }
                        break;
                    }
                    case "x-www-form-urlencoded": {
                        httpRequest.header("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                        if (MapUtil.isNotEmpty(paramMap)) {
                            Map<String, Object> temp = new HashMap<>(paramMap.size());
                            temp.putAll(paramMap);
                            httpRequest.form(temp);
                        }
                        break;
                    }
                    case "query": {
                        if (MapUtils.isNotEmpty(paramMap)) {
                            paramMap.forEach((k, v) -> {
                                urlBuilder.addQuery(k, v);
                            });
                        }
                        httpRequest = new HttpRequest(urlBuilder);
                        break;
                    }
                    default: {
                        httpRequest.header("Content-Type", contentType);
                        if (MapUtil.isNotEmpty(paramMap)) {
                            httpRequest.body(JsonUtils.encode(paramMap));
                        }
                    }
                }
                switch (method.toUpperCase()) {
                    case "GET":
                        httpRequest.method(Method.GET);
                        break;
                    case "POST":
                        httpRequest.method(Method.POST);
                        break;
                    case "PATCH":
                        httpRequest.method(Method.PATCH);
                        break;
                    case "PUT":
                        httpRequest.method(Method.PUT);
                        break;
                    case "DELETE":
                        httpRequest.method(Method.DELETE);
                        break;
                    case "HEAD":
                        httpRequest.method(Method.HEAD);
                        break;
                    case "TRACE":
                        httpRequest.method(Method.TRACE);
                        break;
                    case "CONNECT":
                        httpRequest.method(Method.CONNECT);
                        break;
                    default:
                        httpRequest.method(Method.OPTIONS);
                        break;
                }
                if (MapUtil.isNotEmpty(header)) {
                    for (Map.Entry<String, String> stringStringEntry : header.entrySet()) {
                        String k = stringStringEntry.getKey();
                        String v = stringStringEntry.getValue();
                        httpRequest.header(k, v);
                    }
                }
                log.info("request:{}", httpRequest);
                HttpResponse execute = httpRequest.execute();
                String body = execute.body();
                log.info("resp status:{} body:{}", execute.getStatus(), body);
                // 获取响应状态
                int statusCode = execute.getStatus();
                map.put(HttpClientHelper.STATUS_CODE, String.valueOf(statusCode));
                map.put(HttpClientHelper.RESPONSE_DATA, body);
            } catch (Exception exception) {
                log.error("error send request", exception);
            }
            return map;
        }
        RequestBuilder builder = RequestBuilder.create(method)
                .setUri(url)
                .setCharset(StandardCharsets.UTF_8);

        if (header != null && header.size() > 0) {
            for (Map.Entry<String, String> entry : header.entrySet()) {
                builder.addHeader(entry.getKey(), entry.getValue());
            }
        }
        switch (contentType) {
            case "json": {
                builder.setHeader("Content-Type", "application/json;charset=UTF-8");
                builder.setEntity(new StringEntity(JsonUtils.encode(paramMap), StandardCharsets.UTF_8));
                break;
            }
            case "x-www-form-urlencoded": {
                builder.setHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                List<NameValuePair> params = Lists.newArrayListWithExpectedSize(paramMap.size());
                for (Map.Entry<String, String> entry : paramMap.entrySet()) {
                    params.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                }
                builder.setEntity(new UrlEncodedFormEntity(params, StandardCharsets.UTF_8));
                break;
            }
            case "query": {
                if (MapUtils.isNotEmpty(paramMap)) {
                    String join = Joiner.on(StrConstant.C_AND).withKeyValueSeparator(StrConstant.C_EQ).join(paramMap);
                    builder.setUri(url + StrConstant.C_DOUBT + join);
                }
                break;
            }
            default: {
                builder.setHeader("Content-Type", contentType);
                if (MapUtils.isNotEmpty(paramMap)) {
                    builder.setEntity(new StringEntity(JsonUtils.encode(paramMap), StandardCharsets.UTF_8));
                }

            }
        }

        HttpUriRequest request = builder.build();
        CloseableHttpResponse response = null;
        try {
            CloseableHttpClient closeableHttpClient = sslValid ? httpClient : createSSLClientDefault();
            response = closeableHttpClient.execute(request);
            return parseResponse(response);
        } catch (IOException e) {
            log.error("url : {} , msg:{}", url, e.getMessage());
            request.abort();
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error(ExceptionUtils.getStackTrace(e));
            }
        }
        return Maps.newHashMap();
    }

    public String getResult(String url, HttpHost proxy) {
        CloseableHttpClient httpClient = createSSLClientDefault();
        HttpGet httpGet = new HttpGet(url);
        // 响应模型
        CloseableHttpResponse response = null;
        String resp = "";
        try {
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(5000)
                    .setConnectionRequestTimeout(5000)
                    .setSocketTimeout(5000)
                    .setRedirectsEnabled(true).build();
            if (proxy != null) {
                //设置代理
                requestConfig = RequestConfig.custom()
                        .setConnectTimeout(5000)
                        .setConnectionRequestTimeout(5000)
                        .setSocketTimeout(5000)
                        .setRedirectsEnabled(true).setProxy(proxy).build();
            }
            httpGet.setConfig(requestConfig);
            response = httpClient.execute(httpGet);
            HttpEntity responseEntity = response.getEntity();
            resp = EntityUtils.toString(responseEntity);
        } catch (Exception e) {
            log.error("Failed to get userinfo ，request url:{}, exception:{}", url, e);
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }

        return resp;
    }

    private static CloseableHttpClient createSSLClientDefault() {

        SSLContext sslContext;
        try {
            sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
                //信任所有
                @Override
                public boolean isTrusted(X509Certificate[] xcs, String string) {
                    return true;
                }
            }).build();

            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext);

            return HttpClients.custom().setSSLSocketFactory(sslsf).build();
        } catch (KeyStoreException ex) {
            log.error("", ex);
        } catch (NoSuchAlgorithmException ex) {
            log.error("", ex);
        } catch (KeyManagementException ex) {
            log.error("", ex);
        }

        return HttpClients.createDefault();
    }

    private CloseableHttpClient buildSelfSignatureSSLHttpClient() {
        try {
            SSLConnectionSocketFactory scsf = new SSLConnectionSocketFactory(SSLContexts.custom().loadTrustMaterial(null, new TrustSelfSignedStrategy()).build(), NoopHostnameVerifier.INSTANCE);
            return HttpClients.custom().setSSLSocketFactory(scsf).build();
        } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
            log.error(e.getMessage(), e);
        }
        return HttpClients.createDefault();
    }

}