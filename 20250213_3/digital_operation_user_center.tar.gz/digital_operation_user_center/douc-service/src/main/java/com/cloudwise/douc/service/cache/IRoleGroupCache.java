package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.service.model.role.RoleGroupResp;

import java.util.List;

/**
 * @author Bernie
 * @date 2021-01-30 16:21
 */
public interface IRoleGroupCache {

    /**
     * @Param
     * @Return
     * @Auth bernie
     * @Date 4:22 PM 2021/1/30
     */
    void updateAllRoleGroupByIdToCache();

    /**
     * description: 删除角色组信息缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void deleteRoleGroupsFromCache(Long accountId, List<Long> roleGroupIds);

    List<RoleGroupResp> getAllRoleGroupDirect(Long accountId);

    void setAllRoleGroupDirect(List<RoleGroupResp> roleGroupResps, long accountId);

    void deleteAllRoleGroupDirect(long accountId);

    /**
     * 删除角色组缓存
     */
    void deleteAllV2RoleGroupFromCacheByAccountId(Long accountId);
}
