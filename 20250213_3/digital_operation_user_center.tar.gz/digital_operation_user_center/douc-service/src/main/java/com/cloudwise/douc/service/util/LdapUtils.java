package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.metadata.model.ldap.LdapEntity;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sun.jndi.ldap.LdapName;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Bernie
 * @date 2020-07-29 14:17
 */
@Slf4j
@Component
public class LdapUtils {
    
    @Value("${ldap.provider.url.key:java.naming.provider.url}")
    private void initUrlKey(String s) {
        urlKey = s;
    }
    
    private static String urlKey;

    /**
     * @Param LdapEntity ldapEntity
     * @Return
     * @Auth bernie
     * @Date 2:19 PM 2020/7/29
     */
    public static LdapContext ldapLogin(LdapEntity ldapEntity) {

        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(urlKey, ldapEntity.getLdapUrl() + StrPool.C_COLON + ldapEntity.getPort());
        //适配ad域 san登陆方式
        if (ldapEntity.getType().equalsIgnoreCase(Constant.LDAP_PRODUVCT_TYPE_AD) && ldapEntity.getLoginType()
                .equals(Constant.LDAP_TYPE_FALSE)) {
            env.put(Context.SECURITY_PRINCIPAL, ldapEntity.getDomain() + "\\" + ldapEntity.getUsername());
        } else {
            env.put(Context.SECURITY_PRINCIPAL, ldapEntity.getUsername());
        }

        env.put(Context.SECURITY_CREDENTIALS, ldapEntity.getPassword());

        //ad下guid需要解析
        if (ldapEntity.getType().equals(Constant.LDAP_PRODUVCT_TYPE_AD)) {
            env.put("java.naming.ldap.attributes.binary", "objectGUID");
        }

        LdapContext ctx = null;
        Control[] connCtls = null;

        if (ldapEntity.getIsSsl().equals(Constant.LDAP_TYPE_TRUE)) {
            env.put(Context.REFERRAL, "ignore");
            env.put(Context.SECURITY_PROTOCOL, "ssl");
            env.put("java.naming.ldap.factory.socket", LdapsNoVerifySSLSocketFactory.class.getName());
        } else {
            env.put("com.sun.jndi.ldap.connect.timeout", "5000");
        }

        try {
            ctx = new InitialLdapContext(env, connCtls);
            log.info("============== ldap author success ===============");

            //设置查询分页
            ctx.setRequestControls(
                    new Control[] {new PagedResultsControl(Constant.LDAP_QUERY_PAGE_SIZE, Control.CRITICAL)});

            return ctx;
        } catch (javax.naming.AuthenticationException e) {
            log.error("ldap authentication failed: ", e);
            throw new BaseException(IBaseExceptionCode.LDAP_CREDENTIALS_ERROR, e);
        } catch (Exception e) {
            log.error("ldap authentication error : ", e);
            throw new BaseException(IBaseExceptionCode.LDAP_AUTH_ERROR, e);
        }
    }

    //ldap拉取数据
    public static List<Map<String, Object>> getDataByConf(LdapContext ctx, LdapEntity ldapEntity, String flage) {
        //获取查询的属性列表
        List<String> ldapQueryAttrList = getLdapQueryAttrList(ldapEntity, flage);
        if (ConfigUtils.getBoolean("ldap.sync.manger.enabled", false)) {
            ldapQueryAttrList.add(ConfigUtils.getString("ldap.sync.manger.field"));
        }
        String[] attrList = ldapQueryAttrList.stream().distinct().collect(Collectors.toList())
                .toArray(new String[ldapQueryAttrList.size()]);

        List<Map<String, Object>> resultMap = null;
        if (flage.equals(Constant.LDAP_MAPPING_TYPE_USER)) {
            log.info("========= start pull ldap user data ===============");
            try {
                String uniqueId =
                        StringUtils.isNotEmpty(ldapEntity.getReplaceUniqueId()) ? ldapEntity.getReplaceUniqueId()
                                : ldapEntity.getUniqueId();
                String userFilter = generateUserFilteringCriteria(ldapEntity.getUserFilterConditions(), uniqueId);
                resultMap = queryByConditions(ctx, ldapEntity.getUserRootPath(), userFilter, attrList,
                        SearchControls.SUBTREE_SCOPE);
            } catch (Exception e) {
                log.error("query <" + ldapEntity.getUserRootPath() + ">user error: ", e);
                throw new BaseException(IBaseExceptionCode.LDAP_QUERY_USER_ERROR, new String[] {ldapEntity.getUserRootPath()}, e);
            }
        } else if (flage.equals(Constant.LDAP_MAPPING_TYPE_GROUP)) {
            log.info("========= start pull ldap group data ===============");
            List<Map<String, Object>> intervalData = Lists.newArrayList();
            //拉取部门数据
            List<String> groupRootPath = ldapEntity.getGroupRootPath();

            //拉取配置的部门信息
            for (String dn : groupRootPath) {
                try {
                    intervalData.addAll(queryByConditions(ctx, dn, ldapEntity.getGroupFilterConditions(), attrList,
                            SearchControls.SUBTREE_SCOPE));
                } catch (Exception e) {
                    log.error("query <" + dn + "> department user error: ", e);
                    throw new BaseException(IBaseExceptionCode.LDAP_QUERY_DEPARTMENT_USER_ERROR, new String[] {dn}, e);
                }
            }
            resultMap = intervalData.stream().distinct().collect(Collectors.toList());
        } else {
            log.info("========= start pull super ldap group data ===============");
            List<Map<String, Object>> intervalData = Lists.newArrayList();
            //获得补全的上级部门信息
            List<String> otherGroupRootPathByDn = getSuperiorGroupRootPathByDn(ldapEntity);
            if (otherGroupRootPathByDn.size() > 0) {
                for (String dn : otherGroupRootPathByDn) {
                    try {
                        intervalData.addAll(queryByConditions(ctx, dn, ldapEntity.getGroupFilterConditions(), attrList,
                                SearchControls.OBJECT_SCOPE));
                    } catch (Exception e) {
                        log.error("query <" + dn + "> department user error: ", e);
                        throw new BaseException(IBaseExceptionCode.LDAP_QUERY_DEPARTMENT_USER_ERROR, new String[] {dn}, e);
                    }
                }
            }
            resultMap = intervalData.stream().distinct().collect(Collectors.toList());
        }
        log.info("ldap pull data success : data size == {}", resultMap.size());
        return resultMap;
    }

    //根据部门拉取用户数据
    public static List<Map<String, Object>> getUserDataByDepertment(LdapContext ctx, LdapEntity ldapEntity,
            List<Map<String, Object>> depetmentData) {
        log.info("========= start pull user data ===============");
        //获取查询的属性列表
        List<String> ldapQueryAttrList = getLdapQueryAttrList(ldapEntity, Constant.LDAP_MAPPING_TYPE_USER);
        if (ConfigUtils.getBoolean("ldap.sync.manger.enabled", false)) {
            ldapQueryAttrList.add(ConfigUtils.getString("ldap.sync.manger.field"));
        }
        String[] attrList = ldapQueryAttrList.stream().distinct().collect(Collectors.toList())
                .toArray(new String[ldapQueryAttrList.size()]);

        List<Map<String, Object>> resultList = Lists.newArrayList();
        depetmentData.forEach(department -> {
            String dn = "";
            if (ldapEntity.getType().equals(Constant.LDAP_PRODUVCT_TYPE_OPENLDAP)) {
                dn = String.valueOf(department.get(Constant.LDAP_OPENLDAP_DN_FIELD));
            } else if (ldapEntity.getType().equals(Constant.LDAP_PRODUVCT_TYPE_AD)) {
                dn = String.valueOf(department.get(Constant.LDAP_AD_DN_FIELD));
            }

            if (StringUtils.isNotEmpty(dn) && !"null".equalsIgnoreCase(dn)) {
                List<Map<String, Object>> maps = null;
                try {
                    String uniqueId =
                            StringUtils.isNotEmpty(ldapEntity.getReplaceUniqueId()) ? ldapEntity.getReplaceUniqueId()
                                    : ldapEntity.getUniqueId();
                    String userFilter = generateUserFilteringCriteria(ldapEntity.getUserFilterConditions(), uniqueId);
                    maps = queryByConditions(ctx, dn, userFilter, attrList, SearchControls.ONELEVEL_SCOPE);
                } catch (Exception e) {
                    log.error("query <" + dn + "> department user error: ", e);
                    throw new BaseException(IBaseExceptionCode.LDAP_QUERY_DEPARTMENT_USER_ERROR, new String[] {dn}, e);
                }
                resultList.addAll(maps);
            }
        });
        log.debug("============== ldap pull data success : data:{}", resultList);
        log.info("============== ldap pull data success : data size:{} == ", resultList.size());
        return resultList;
    }

    /**
     * 根据需求查询ldap
     *
     * @Param
     * @Return
     * @Auth bernie
     * @Date 10:21 PM 2020/7/30
     */
    public static List<Map<String, Object>> queryByConditions(LdapContext ctx, String basePath, String filter,
            String[] attribute, Integer searchScope) throws Exception {

        byte[] cookie = null;
        List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();

        do {
            //搜索控件
            SearchControls searchControls = new SearchControls();
            //搜索范围
            searchControls.setSearchScope(searchScope);
            searchControls.setReturningAttributes(attribute);

            try {
                NamingEnumeration<SearchResult> answer = ctx.search(new LdapName(basePath), filter, searchControls);
                while (answer.hasMoreElements()) {
                    SearchResult result = answer.next();
                    NamingEnumeration<? extends Attribute> attrs = result.getAttributes().getAll();
                    Map<String, Object> map = Maps.newHashMapWithExpectedSize(16);

                    while (attrs.hasMoreElements()) {
                        Attribute attr = attrs.next();
                        if ("userPassword".equals(attr.getID())) {
                            Object value = attr.get();
                            map.put(attr.getID(), new String((byte[]) value, StandardCharsets.UTF_8));
                        } else if ("objectGUID".equals(attr.getID())) {
                            byte[] guid = (byte[]) attr.get();
                            map.put(attr.getID(), getGUID(guid));
                        } else {
                            map.put(attr.getID(), attr.get());
                        }
                    }

                    if (map != null) {
                        if (map.containsKey(Constant.LDAP_OPENLDAP_DN_FIELD) || map.containsKey(
                                Constant.LDAP_AD_DN_FIELD)) {
                            resultList.add(map);
                        } else {
                            throw new Exception("无法获取dn信息");
                        }
                    }
                }

                Control[] controls = ctx.getResponseControls();
                if (controls != null) {
                    for (int i = 0; i < controls.length; i++) {
                        if (controls[i] instanceof PagedResultsResponseControl) {
                            PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
                            cookie = prrc.getCookie();
                        }
                    }
                }

                // 将cookie资讯提供给InitialLdapContext，让它在接下来的查询中进行换页
                ctx.setRequestControls(new Control[] {
                        new PagedResultsControl(Constant.LDAP_QUERY_PAGE_SIZE, cookie, Control.CRITICAL)});

            } catch (Exception e) {
                log.error("ldap query error", e);
                throw new Exception(e);
            }

        } while (cookie != null);

        return resultList;
    }

    /**
     * 获取需要查询的LDAP属性列表
     *
     * @param ldapEntity ldap配置实体
     * @param flag       用户或组织机构
     * @return java.util.List<java.lang.String>
     * @author bernie.wang
     * @date 2022/1/10
     * @time 2:33 下午
     */
    public static List<String> getLdapQueryAttrList(LdapEntity ldapEntity, String flag) {
        List<String> attrList = Lists.newArrayList();
        //根据不同的LDAP类型添加专属字段
        switch (ldapEntity.getType()) {
            case Constant.LDAP_PRODUVCT_TYPE_OPENLDAP:
                setOpneLdapAttributeList(attrList, ldapEntity);
                break;
            case Constant.LDAP_PRODUVCT_TYPE_AD:
                setAdAttributeList(attrList, ldapEntity);
                break;
            default:
                setAdAttributeList(attrList, ldapEntity);
                break;
        }
        //根据flag添加映射属性
        if (flag.equals(Constant.LDAP_MAPPING_TYPE_USER)) {
            //获取配置的用户标准映射属性
            ldapEntity.getUserAttributeMapping().forEach(x -> attrList.add(x.get("ldapAttr")));
            //获取配置的用户拓展映射属性
            ldapEntity.getUserExtendAttributeMapping().forEach(x -> attrList.add(x.get("ldapAttr")));
        } else {
            //获取配置的组织机构标准字段
            ldapEntity.getGroupAttributeMapping().forEach(x -> attrList.add(x.get("ldapAttr")));
            //获取配置的组织机构拓展字段
            ldapEntity.getGroupExtendAttributeMapping().forEach(x -> attrList.add(x.get("ldapAttr")));
        }
        return attrList;
    }

    private static void setAdAttributeList(List<String> attrList, LdapEntity ldapEntity) {
        //添加DN字段
        attrList.add(Constant.LDAP_AD_DN_FIELD);
        //添加唯一ID
        if (StringUtils.isEmpty(ldapEntity.getUniqueId())) {
            //AD域默认唯一ID
            attrList.add(Constant.LDAP_AD_DEFAULT_UNIQUE_ID);
        } else {
            //自定义唯一ID
            attrList.add(ldapEntity.getUniqueId());
        }
        //根据loginType添加对应的登陆名字段
        if (ldapEntity.getLoginType().equals(Constant.LDAP_TYPE_FALSE)) {
            //san登陆名
            attrList.add(Constant.LDAP_AD_DEFAULT_SAN_USER_ALIAS);
        } else {
            //upn登陆名
            attrList.add(Constant.LDAP_AD_DEFAULT_UPN_USER_ALIAS);
        }
        if (StringUtils.isNotEmpty(ldapEntity.getReplaceUniqueId())) {
            //要替换的唯一ID
            attrList.add(ldapEntity.getReplaceUniqueId());
        }
    }

    private static void setOpneLdapAttributeList(List<String> attrList, LdapEntity ldapEntity) {
        //添加DN字段
        attrList.add(Constant.LDAP_OPENLDAP_DN_FIELD);
        //添加唯一ID
        if (StringUtils.isEmpty(ldapEntity.getUniqueId())) {
            //OpneLdap默认唯一ID
            attrList.add(Constant.LDAP_OPENLDAP_DEFAULT_UNIQUE_ID);
        } else {
            //自定义唯一ID
            attrList.add(ldapEntity.getUniqueId());
        }
        if (StringUtils.isNotEmpty(ldapEntity.getReplaceUniqueId())) {
            //要替换的唯一ID
            attrList.add(ldapEntity.getReplaceUniqueId());
        }
    }

    private static String generateUserFilteringCriteria(String filterStr, String uniqueId) {
        if (StringUtils.isNotEmpty(uniqueId)) {
            return "(&(" + filterStr + ")(" + uniqueId + "=*))";
        }
        return filterStr;
    }

    public static String getGUID(byte[] guid) {

        String strGUID = "";
        /*StringBuilder byteGUID = new StringBuilder();

        for (byte b : guid) {
            byteGUID.append('\\').append(addLeadingZero((int) b & 0xFF));
        }*/

        strGUID = strGUID + addLeadingZero((int) guid[3] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[2] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[1] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[0] & 0xFF);
        strGUID = strGUID + StrPool.DASHED;
        strGUID = strGUID + addLeadingZero((int) guid[5] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[4] & 0xFF);
        strGUID = strGUID + StrPool.DASHED;
        strGUID = strGUID + addLeadingZero((int) guid[7] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[6] & 0xFF);
        strGUID = strGUID + StrPool.DASHED;
        strGUID = strGUID + addLeadingZero((int) guid[8] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[9] & 0xFF);
        strGUID = strGUID + StrPool.DASHED;
        strGUID = strGUID + addLeadingZero((int) guid[10] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[11] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[12] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[13] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[14] & 0xFF);
        strGUID = strGUID + addLeadingZero((int) guid[15] & 0xFF);

        return strGUID;
    }

    public static String addLeadingZero(int k) {
        return (k <= 0xF) ? "0" + Integer.toHexString(k) : Integer.toHexString(k);
    }

    private static List<String> getSuperiorGroupRootPathByDn(LdapEntity ldapEntity) {
        List<String> groupRootPathLists = ldapEntity.getGroupRootPath();
        List<String> rootGroups = Lists.newArrayList();
        String localRoot = "";
        int localRootIndex = 0;
        for (String str : groupRootPathLists) {
            if (ldapEntity.getType().equals(Constant.LDAP_PRODUVCT_TYPE_AD)) {
                //ad域使用占位符替换逗号
                str = str.replace("\\,", Constant.LDAP_TEMPORARY_PLACEHOLDER_COMMA);
            }
            List<String> basicGroup = Arrays.stream(str.split(StrPool.COMMA))
                    .filter(x -> !x.contains("dc=") && !x.contains("DC=")).map(x ->
                            x.replace("dc=", "").replace("DC=", "")
                    ).collect(Collectors.toList());

            if (basicGroup.size() > 1) {
                //移除最大部门
                basicGroup.remove(basicGroup.size() - 1);
                for (int i = 0; i < basicGroup.size(); i++) {
                    //str = str.replace(basicGroup.get(i) + ",", "");
                    //解决上级部门中和本次同步有重名同步失败问题
                    localRoot = basicGroup.get(i);
                    localRootIndex = str.indexOf(localRoot);
                    str = str.substring(localRootIndex + localRoot.length() + 1);
                    //占位符还原
                    if (ldapEntity.getType().equals(Constant.LDAP_PRODUVCT_TYPE_AD)) {
                        str = str.replace(Constant.LDAP_TEMPORARY_PLACEHOLDER_COMMA, "\\,");
                    }
                    rootGroups.add(str);
                }
            }
        }
        return rootGroups;
    }
}
