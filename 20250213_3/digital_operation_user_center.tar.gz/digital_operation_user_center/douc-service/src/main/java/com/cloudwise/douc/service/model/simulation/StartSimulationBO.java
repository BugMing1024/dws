package com.cloudwise.douc.service.model.simulation;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 开始模拟
 *
 * @author maker.wang
 * @date 2022-08-09 15:53
 **/
@Data
@ApiModel("开始模拟入参")
public class StartSimulationBO implements Serializable {
    private static final long serialVersionUID = -6105506944969230430L;

    @ApiModelProperty(value = "模拟对象用户ID")
    private Long userId;

}
