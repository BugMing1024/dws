package com.cloudwise.douc.service.model.mq;

import lombok.Data;

import java.io.Serializable;

/**
 * 统计堆积的mq的总数
 *
 * @author maker.wang
 * @date 2021-08-17 16:44
 **/
@Data
public class AccountMqHistory implements Serializable {
    private static final long serialVersionUID = 4190027317082570896L;


    private Integer rocketMqNum;

    private Integer kafkaNum;


}
