package com.cloudwise.douc.service.model.license;

import lombok.Data;

import java.io.Serializable;

/**
 * @author elsa.yang
 * @date 2020/9/9 10:30 上午
 */
@Data
public class LicenseCheckInfo implements Serializable {
    private String message;

    private String code;
    /**
     * 标志位，license是否可用。
     */
    private boolean enable;
}

