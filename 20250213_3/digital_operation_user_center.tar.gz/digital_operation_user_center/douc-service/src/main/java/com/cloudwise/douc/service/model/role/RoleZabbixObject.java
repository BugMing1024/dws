package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.metadata.model.role.Role;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * @author leakey
 */
@Data
@ApiModel
public class RoleZabbixObject {
    private Role role;
    private List<RoleResourceMultiTypeZabbixRelation> hosts;
}
