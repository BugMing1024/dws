package com.cloudwise.douc.service.plugin.lucene.redir.util;

import com.cloudwise.douc.commons.constant.CacheConstant;
import lombok.extern.log4j.Log4j2;

/**
 * @author dwq
 */
@Log4j2
public class FileBlocksUtils {
    public static byte[] getBlockName(String fileName, int i) {
        return String.format("@%s:%s", fileName, i).getBytes();
    }

    public static Long getBlockSize(long length) {
        return getBlockSize(length, CacheConstant.REDIS_CACHE_BUFFER_SIZE);
    }

    private static Long getBlockSize(long length, long bufferSize) {
        if (bufferSize == 0) {
            log.error("Default buffer size is zero!");
            return 0L;
        }
        return length % bufferSize == 0 ? length / bufferSize : length / bufferSize + 1;
    }
}
