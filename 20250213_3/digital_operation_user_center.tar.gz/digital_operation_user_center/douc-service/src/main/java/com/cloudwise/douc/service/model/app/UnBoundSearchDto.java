package com.cloudwise.douc.service.model.app;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/30/3:29 下午
 * @Description:
 */
@Data
public class UnBoundSearchDto implements Serializable {

    @NotNull(message = IBaseExceptionCode.APP_API_CODE_NOT_NULL)
    private String apiCode;
    @NotNull(message = IBaseExceptionCode.APP_API_MODULE_CODE_NOT_NULL)
    private String apiModuleCode;

    private String appName;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
