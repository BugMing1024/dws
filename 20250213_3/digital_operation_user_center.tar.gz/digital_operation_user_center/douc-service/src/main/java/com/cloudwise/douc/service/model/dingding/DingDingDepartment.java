package com.cloudwise.douc.service.model.dingding;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class DingDingDepartment {

    @ApiModelProperty(value = "部门id")
    @JsonProperty(value = "dept_id")
    private String departmentId;

    @ApiModelProperty(value = "部门名称")
    @JsonProperty(value = "name")
    private String name;

    @ApiModelProperty(value = "上级部门id")
    @JsonProperty(value = "parent_id")
    private String parentId;

    @ApiModelProperty(value = "部门的主管userd列表")
    @JsonProperty(value = "dept_manager_userid_list")
    private List<String> deptManagerUseridList;

    @ApiModelProperty(value = "部门电话")
    @JsonProperty(value = "telephone")
    private String telephone;

    @ApiModelProperty(value = "简介")
    @JsonProperty(value = "brief")
    private String brief;

    @ApiModelProperty(value = "直属子部门id")
    @JsonProperty(value = "dept_id_list")
    private List<Long> childDeparmentIdList;

}
