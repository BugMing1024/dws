package com.cloudwise.douc.service.model.token;

import lombok.Data;

import java.io.Serializable;

/**
 * @author maker.wang
 * @description: token信息
 * @date Created in 2:50 下午 2021/6/2.
 */
@Data
public class TokenInfo implements Serializable {

    private static final long serialVersionUID = 1997042293967954099L;

    /**
     * 签发的token
     */
    private String token;

    /**
     * 有效时长(单位分钟)
     */
    private Integer expire;

    /**
     * 签发时间(秒级)
     */
    private String issueTimestamp;

    /**
     * 加密算法 默认sm2
     */
    private String encrypt;
}
