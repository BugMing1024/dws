package com.cloudwise.douc.service.model.ldap;

import lombok.Data;

import java.io.Serializable;

/**
 * @author bernie.wang
 * @description:
 * @date Created in 9:50 上午 2022/4/24.
 */
@Data
public class LdapQueryParams implements Serializable {
    private String filterName;
    private String startTime;
    private String endTime;
    private int current;
    private int size;
}
