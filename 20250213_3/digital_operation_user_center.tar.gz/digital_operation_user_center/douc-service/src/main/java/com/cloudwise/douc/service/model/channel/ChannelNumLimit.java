package com.cloudwise.douc.service.model.channel;

import lombok.Data;

/**
 * @author zafir.zhong
 * @description
 * @date Created in 11:14 2022/11/2.
 */
@Data
public class ChannelNumLimit {
    private Integer min;
    private Integer max;
}
