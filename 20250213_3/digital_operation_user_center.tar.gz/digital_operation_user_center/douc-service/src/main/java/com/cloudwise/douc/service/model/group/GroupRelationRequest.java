package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.metadata.model.department.DepartmentPO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author Bernie
 * @date 2021-04-27 18:21
 */
@Data
@ApiModel
public class GroupRelationRequest {
    @ApiModelProperty(value = "新关联的组织id集合")
    private List<Long> addList;
    @ApiModelProperty(value = "移除的组织id集合")
    private List<Long> removeList;
    @ApiModelProperty(value = "用户组id")
    private Long groupId;
    @ApiModelProperty(value = "用户id")
    private Long userId;

    /**
     * 冗余-为了往下传参 顶级租户id
     **/
    private Long topAccountId;
    @ApiModelProperty(value = "新增或删除的部门集合")
    private List<DepartmentPO> addUpdateList;
}
