package com.cloudwise.douc.service.model.wecom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComInfo implements Serializable {

    private String errcode;

    private String errmsg;

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("department")
    private List<WeComDepartment> weComDepartmentList;

    @JsonProperty("userlist")
    private List<WeComUser> weComUserList;

}
