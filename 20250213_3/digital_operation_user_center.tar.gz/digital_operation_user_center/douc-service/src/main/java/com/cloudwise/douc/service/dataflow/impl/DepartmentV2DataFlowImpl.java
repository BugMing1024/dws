package com.cloudwise.douc.service.dataflow.impl;

import com.cloudwise.douc.service.cache.IDepartmentV2Cache;
import com.cloudwise.douc.service.dataflow.IDepartmentV2DataFlow;
import com.cloudwise.douc.service.model.department.DepartmentNodeCacheDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @ProjectName: digital_operation_user_center
 * @Package: com.cloudwise.douc.service.dataflow.impl
 * @ClassName: DepartmentV2DataFlow
 * @Author: bradyliu
 * @Description: 部门缓存V2版本
 * @Date: 2021/5/17 4:50 下午
 * @Version: 1.0
 */
@Component
public class DepartmentV2DataFlowImpl implements IDepartmentV2DataFlow {

    @Autowired
    private IDepartmentV2Cache departmentV2Cache;

    @Override
    public Map<Long, DepartmentNodeCacheDTO> getDepartmentMap(Long accountId, List<Long> ids) {
        return departmentV2Cache.getDepartmentMap(accountId, ids);
    }

    @Override
    public Boolean setDepartmentMap(Long accountId, Map<Long, DepartmentNodeCacheDTO> departmentMap) {
        return departmentV2Cache.setDepartmentMap(accountId, departmentMap);
    }

    @Override
    public Boolean deleteDepartment(Long accountId, List<Long> ids) {
        return departmentV2Cache.deleteDepartment(accountId, ids);
    }

    @Override
    public void loadAllDepartmentToCache() {
        departmentV2Cache.loadAllDepartmentToCache();
    }
}
