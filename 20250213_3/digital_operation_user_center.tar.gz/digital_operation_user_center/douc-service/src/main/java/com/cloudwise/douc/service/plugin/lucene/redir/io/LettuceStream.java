package com.cloudwise.douc.service.plugin.lucene.redir.io;

import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.service.plugin.lucene.redir.Operations;
import com.cloudwise.douc.service.plugin.lucene.redir.util.CompressUtils;
import com.cloudwise.douc.service.plugin.lucene.redir.util.FileBlocksUtils;
import com.google.common.primitives.Longs;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author dwq
 */
@Log4j2
public class LettuceStream implements InputOutputStream {


    private LettuceConnectionFactory factory;

    private RedisConnection getConnect() {
        return factory.getConnection();
    }

    public LettuceStream(LettuceConnectionFactory factory) {
        this.factory = factory;
    }

    @Override
    public Boolean hexists(byte[] key, byte[] field) {
        RedisConnection connect = getConnect();
        Boolean hexists = connect.hExists(key, field);
        connect.close();
        return hexists;
    }

    @Override
    public byte[] hget(byte[] key, byte[] field, Operations operations) {
        RedisConnection connect = getConnect();
        byte[] hget = connect.hGet(key, field);
        connect.close();
        if (operations == Operations.FILE_DATA) {
            return CompressUtils.uncompressFilter(hget);
        }
        return hget;
    }

    @Override
    public void close() throws IOException {
    }

    @Override
    public Set<byte[]> hkeys(byte[] key) {
        RedisConnection connect = getConnect();
        Set<byte[]> hkeys = connect.hKeys(key);
        connect.close();
        return hkeys;
    }

    /**
     * Use transactions to delete index file
     *
     * @param fileLengthKey the key using for hash file length
     * @param fileDataKey   the key using for hash file data
     * @param field         the hash field
     * @param blockSize     the index file data block size
     */
    @Override
    public void deleteFile(String fileLengthKey, String fileDataKey, String field, long blockSize) {
        RedisConnection connect = getConnect();
        connect.openPipeline();
        //delete file length
        connect.hDel(fileLengthKey.getBytes(), field.getBytes());
        //delete file content
        for (int i = 0; i < blockSize; i++) {
            byte[] blockName = FileBlocksUtils.getBlockName(field, i);
            connect.hDel(fileDataKey.getBytes(), blockName);
        }
        connect.closePipeline();
        connect.close();
    }

    /**
     * Use transactions to add index file and then delete the old one
     *
     * @param fileLengthKey the key using for hash file length
     * @param fileDataKey   the key using for hash file data
     * @param oldField      the old hash field
     * @param newField      the new hash field
     * @param values        the data values of the old hash field
     * @param fileLength    the data length of the old hash field
     */
    @Override
    public void rename(String fileLengthKey, String fileDataKey, String oldField, String newField, List<byte[]> values, long
            fileLength) {
        RedisConnection connect = getConnect();
        connect.openPipeline();
        //add new file length
        connect.hSet(fileLengthKey.getBytes(), newField.getBytes(), Longs.toByteArray(fileLength));
        //add new file content
        Long blockSize = FileBlocksUtils.getBlockSize(fileLength);
        for (int i = 0; i < blockSize; i++) {
            connect.hSet(fileDataKey.getBytes(), FileBlocksUtils.getBlockName(newField, i), CompressUtils.compressFilter(values.get(i)));
        }
        connect.closePipeline();
        connect.close();
        values.clear();
        deleteFile(fileLengthKey, fileDataKey, oldField, blockSize);
    }

    @Override
    public void saveFile(String fileLengthKey, String fileDataKey, String fileName, List<byte[]> values, long fileLength) {
        RedisConnection connect = getConnect();
        connect.openPipeline();
        connect.hSet(fileLengthKey.getBytes(), fileName.getBytes(), Longs.toByteArray(fileLength));
        Long blockSize = FileBlocksUtils.getBlockSize(fileLength);
        for (int i = 0; i < blockSize; i++) {
            connect.hSet(fileDataKey.getBytes(), FileBlocksUtils.getBlockName(fileName, i), CompressUtils.compressFilter(values.get(i)));
        }
        connect.closePipeline();
        connect.close();
        values.clear();
    }

    @Override
    public List<byte[]> loadFileOnce(String fileDataKey, String fileName, long blockSize) {
        RedisConnection connect = getConnect();
        connect.openPipeline();
        List<byte[]> res = new ArrayList<>();
        int temp = 0;
        //如果不分批次sync容易read time out和Java heap space
        while (temp < blockSize) {
            if (temp % CacheConstant.LUCENE_SYNC_COUNT == 0) {
                List<Object> tempS = connect.closePipeline();
                tempS.forEach(e -> {
                    if (e != null) {
                        res.add((byte[]) e);
                    }
                });
                connect.openPipeline();
            }
            temp++;
        }
        try {
            List<Object> tempS = connect.closePipeline();
            tempS.forEach(e -> {
                if (e != null) {
                    res.add((byte[]) e);
                }
            });
        } catch (Exception e) {
            log.error("connect = {}, blockSize = {}!", connect.toString(), blockSize);
            log.error("", e);
        } finally {
            connect.close();
        }
        return res;
    }
}