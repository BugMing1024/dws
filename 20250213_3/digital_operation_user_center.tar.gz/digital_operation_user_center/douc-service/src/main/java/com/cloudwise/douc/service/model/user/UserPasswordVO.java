package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.commons.validation.validator.Mobile;
import com.cloudwise.douc.commons.validation.validator.Password;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户密码vo
 */
@Data
public class UserPasswordVO implements Serializable {

    @Mobile
    private String mobile;
    private String prefix;
    private Long accountId;
    @Password
    private String newPassword;
    /**
     * 加密类型 1 sm2 2 AES 3 sm2sm3 加密后不可逆
     */
    private String encrypt;
    private String newPassword2;
    private String newPassword3;
    //验证码
    private String verificationCode;
    //区分验证码发送的供应商提供
    private String code;
    private String language;
    private String userIp;

}
