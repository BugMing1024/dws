package com.cloudwise.douc.service.plugin.lucene.redir.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.BooleanUtils;
import org.xerial.snappy.Snappy;

import java.io.IOException;

/**
 * @author dwq
 */
@Log4j2
public class CompressUtils {
    public static byte[] compressFilter(byte[] datas) {
        if (BooleanUtils.toBoolean(ConfigUtils.getValue("COMPRESS_FILE"))) {
            try {
                datas = Snappy.compress(datas);
            } catch (IOException e) {
                log.error("Compress error!", e);
            }
        }
        return datas;
    }

    public static byte[] uncompressFilter(byte[] datas) {
        if (BooleanUtils.toBoolean(ConfigUtils.getValue("COMPRESS_FILE"))) {
            try {
                datas = Snappy.uncompress(datas);
            } catch (IOException e) {
                log.error("Uncompress error!", e);
            }
        }
        return datas;
    }
}
