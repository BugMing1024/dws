package com.cloudwise.douc.service.configuration;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsPasswordService;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

/**
 * @author bernie.wang
 * @description:
 * @date Created in 10:42 AM 2021/10/14.
 */
@EnableWebSecurity
@Configuration
@Slf4j
public class ActuatorWebSecurityConfigurationAdapter extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable().authorizeRequests()
                .antMatchers(StrPool.SLASH).authenticated()
                .antMatchers("/autoconfig/**").authenticated()
                .antMatchers("/beans/**").authenticated()
                .antMatchers("/env/**").authenticated()
                .antMatchers("/configprops/**").authenticated()
                .antMatchers("/dump/**").authenticated()
                .antMatchers("/health/**").authenticated()
                .antMatchers("/info/**").authenticated()
                .antMatchers("/mappings/**").authenticated()
                .antMatchers("/metrics/**").authenticated()
                .antMatchers("/shutdown/**").authenticated()
                .antMatchers("/trace/**").authenticated()
                .antMatchers("/v2/api-docs").authenticated()
                .antMatchers("/auditevents/**").authenticated()
                .antMatchers("/flyway/**").authenticated()
                .antMatchers("/heapdump/**").authenticated()
                .antMatchers("/httptrace/**").authenticated()
                .antMatchers("/jolokia/**").authenticated()
                .antMatchers("/logfile/**").authenticated()
                .antMatchers("/loggers/**").authenticated()
                .antMatchers("/liquibase/**").authenticated()
                .antMatchers("/prometheus/**").authenticated()
                .antMatchers("/sessions/**").authenticated()
                .antMatchers("/threaddump/**").authenticated()
                .antMatchers("/swagger-resources/**").authenticated()
                .antMatchers("/scheduledtasks/**").authenticated()
                .antMatchers("/service-registry/**").authenticated()
                .antMatchers("/**").permitAll()
                .and()
                .httpBasic();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        String userName = ConfigUtils.getString("spring.security.user.name");
        String passCode = "{noop}" + ConfigUtils.getString("spring.security.user.password");
        User user = new User(userName, passCode, true, true, true, true, Lists.newArrayList());
        UserDetailsService userDetailsService = new InMemoryUserDetailsManager(user);
        UserDetailsPasswordService userDetailsPasswordService = new InMemoryUserDetailsManager(user);
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setUserDetailsPasswordService(userDetailsPasswordService);
        provider.afterPropertiesSet();
        auth.authenticationProvider(provider);
    }
}
