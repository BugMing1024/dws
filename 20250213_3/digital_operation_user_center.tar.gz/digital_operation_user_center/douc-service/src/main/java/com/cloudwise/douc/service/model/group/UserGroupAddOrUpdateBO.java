package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * 添加或修改用户组
 *
 * @author maker.wang
 * @date 2022-08-11 09:41
 **/
@Data
@ApiModel("添加或修改用户组")
public class UserGroupAddOrUpdateBO implements Serializable {
    private static final long serialVersionUID = 220388424810113991L;

    @ApiModelProperty("租户ID")
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    @Range(min = 110, max = 999999999, message = IBaseExceptionCode.MULTI_ACCOUNT_TOP_ID_ILLEGAL)
    private Long accountId;

    @ApiModelProperty("用户ID")
    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    @Range(min = 1, max = Long.MAX_VALUE, message = "userId必须是正整数")
    private Long userId;

    @ApiModelProperty("用户组名称")
    @NotBlank(message = IBaseExceptionCode.API_GROUP_NAME_NOT_BLANK)
    @Length(max = 40, message = IBaseExceptionCode.RPC_USER_GROUP_NAME_LENGTH_ERROR)
    private String groupName;

    @ApiModelProperty("用户组编码")
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_DATAITEMCODE_NOT_BLANK)
    @Length(max = 64, message = IBaseExceptionCode.RPC_USER_GROUP_CODE_LENGTH_ERROR)
    private String groupCode;

    @ApiModelProperty("上级用户组编码")
    private String parentGroupCode;

    @ApiModelProperty("用户组组长编码")
    @Length(max = 64, message = IBaseExceptionCode.RPC_USER_CODE_LENGTH_ERROR)
    private String groupUserLeaderCode;

    @ApiModelProperty("用户组组长ID")
    private transient Long groupUserLeaderId;

    @ApiModelProperty("用户组描述")
    @Length(max = 100, message = IBaseExceptionCode.RPC_USER_GROUP_DESCRIPTION_LENGTH_ERROR)
    private String groupDescription;

    @ApiModelProperty("用户组下新增人员编码集合")
    private List<String> addUserList;

    @ApiModelProperty("用户组下认出人员编码集合")
    private List<String> removeUserList;

}
