package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;


/**
 * 企业微信配置
 *
 * @author maker.wang
 * @date 2022-05-23 11:57
 **/

@Component
@RefreshScope
@ConfigurationProperties(prefix = "sso.server.feishu")
@Data
public class ChannelFeiShuConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    @ApiModelProperty(value = "飞书api地址")
    public String address;

    @ApiModelProperty(value = "飞书网页id")
    private String appid;

    @ApiModelProperty(value = "飞书网页秘钥")
    private String appsecret;

    @ApiModelProperty(value = "企业微信获取copde地址")
    private String proxyFeishuGetCodeUrl;

    @ApiModelProperty(value = "checkField")
    private String checkField;


}
