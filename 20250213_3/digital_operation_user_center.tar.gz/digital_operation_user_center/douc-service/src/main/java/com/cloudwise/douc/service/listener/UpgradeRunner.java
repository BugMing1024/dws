package com.cloudwise.douc.service.listener;

import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.service.service.ICurlService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author zafir.zhong
 * @description 渠道升级的, 也可以直接拓展simpleUpgrade用于其他的情况，强制要求幂等
 * @date Created in 18:34 2023/4/11.
 */
@ConditionalOnProperty(name = "upgrade.auto", havingValue = "true", matchIfMissing = true)
@Component
@Slf4j
public class UpgradeRunner implements ApplicationRunner {

    @Resource
    private ICurlService curlService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        log.info("UpgradeRunner start");
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            try {
                log.info("UpgradeRunner start");
                curlService.simpleUpgrade();
                log.info("UpgradeRunner end");
            } catch (Exception exception) {
                log.error("UpgradeRunner", exception);
            }
        });


    }
}
