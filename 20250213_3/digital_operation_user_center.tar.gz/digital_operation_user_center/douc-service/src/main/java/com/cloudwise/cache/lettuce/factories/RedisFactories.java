//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.cloudwise.cache.lettuce.factories;

import com.cloudwise.cache.components.BeanHelper;
import com.cloudwise.cache.conditions.RedisCondtion;
import com.cloudwise.cache.config.Cluster;
import com.cloudwise.cache.config.RedisConfigs;
import com.cloudwise.cache.config.Sentinel;
import com.cloudwise.cache.enums.AllocationModeArgs;
import com.cloudwise.cache.enums.RedisMode;
import com.cloudwise.cache.lettuce.annotations.RedisConditionalOnProperty;
import com.cloudwise.cache.utils.CommonUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;

import java.util.HashSet;
// CHECKSTYLE:OFF
@Conditional({RedisCondtion.class})
public class RedisFactories {

    private static final Logger log = LoggerFactory.getLogger(RedisFactories.class);
    @Autowired
    RedisConfigs redisConfigs;
    @Autowired
    LettucePoolingClientConfiguration lettucePoolingClientConfiguration;
    @Autowired
    BeanHelper getBeanHelper;

    public RedisFactories() {
    }

    @Bean
    @RedisConditionalOnProperty(
            name = {AllocationModeArgs.REDISCLUSTERTYPE, AllocationModeArgs.TOOLSALLOCATIONMODE},
            type = AllocationModeArgs.LETTUCE
    )
    public RedisConnectionFactory redisConnectionFactory() {

        log.info("init redis data server:{} username:{} password:{}", redisConfigs.getRedisSingleServers(), redisConfigs.getUsername(), redisConfigs.getPassword());

        if (this.redisConfigs.getAllocationMode().equalsIgnoreCase(RedisMode.MASTERSLAVE.getMode())) {
            String master = CommonUtils.getMaster(this.redisConfigs.getRedisSingleServers().split(",")[0], this.redisConfigs.getPassword());
            this.redisConfigs.setRedisSingleServers(master);
        }

        RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration();
        configuration.setHostName(this.redisConfigs.getRedisSingleServers().split(":")[0]);
        configuration.setPort(Integer.valueOf(this.redisConfigs.getRedisSingleServers().split(":")[1]));
        configuration.setDatabase(this.redisConfigs.getDatabase());
        if (StringUtils.isNoneBlank(new CharSequence[]{this.redisConfigs.getPassword()})) {
            configuration.setPassword(this.redisConfigs.getPassword());
        }
        if (StringUtils.isNoneBlank(new CharSequence[]{this.redisConfigs.getUsername()})) {
            configuration.setUsername(this.redisConfigs.getUsername());
        }
        LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(configuration, this.lettucePoolingClientConfiguration);
        lettuceConnectionFactory.afterPropertiesSet();
        return lettuceConnectionFactory;
    }

    @Bean
    @RedisConditionalOnProperty(
            name = {AllocationModeArgs.REDISCLUSTERTYPE, AllocationModeArgs.TOOLSALLOCATIONMODE},
            type = AllocationModeArgs.LETTUCE,
            havingValue = RedisMode.SENTINEL
    )
    public RedisConnectionFactory redisSentinelConnectionFactory() {
        Sentinel sentinel = (Sentinel)this.getBeanHelper.getBean(Sentinel.class);
        RedisSentinelConfiguration redisSentinelConfiguration = new RedisSentinelConfiguration(this.redisConfigs.getSentinel().getMaster() == null ? sentinel.getMaster() : this.redisConfigs.getSentinel().getMaster(), new HashSet(this.redisConfigs.getSentinel().getNodes() == null ? sentinel.getNodes() : this.redisConfigs.getSentinel().getNodes()));
        if (StringUtils.isNoneBlank(new CharSequence[]{this.redisConfigs.getSentinel().getPassword() == null ? sentinel.getPassword() : this.redisConfigs.getSentinel().getPassword()})) {
            redisSentinelConfiguration.setSentinelPassword(this.redisConfigs.getSentinel().getPassword() == null ? sentinel.getPassword() : this.redisConfigs.getSentinel().getPassword());
        }

        if (StringUtils.isNoneBlank(new CharSequence[]{this.redisConfigs.getPassword()})) {
            redisSentinelConfiguration.setPassword(this.redisConfigs.getPassword());
        }
        if (StringUtils.isNoneBlank(new CharSequence[] {this.redisConfigs.getUsername()})) {
            redisSentinelConfiguration.setUsername(this.redisConfigs.getUsername());
        }
        redisSentinelConfiguration.setDatabase(this.redisConfigs.getDatabase());
        LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisSentinelConfiguration, this.lettucePoolingClientConfiguration);
        lettuceConnectionFactory.afterPropertiesSet();
        return lettuceConnectionFactory;
    }

    @Bean
    @RedisConditionalOnProperty(
            name = {AllocationModeArgs.REDISCLUSTERTYPE, AllocationModeArgs.TOOLSALLOCATIONMODE},
            type = AllocationModeArgs.LETTUCE,
            havingValue = RedisMode.CLUSTER
    )
    public RedisConnectionFactory redisClusterConnectionFactory() {
        Cluster cluster = (Cluster)this.getBeanHelper.getBean(Cluster.class);
        RedisClusterConfiguration redisClusterConfig = new RedisClusterConfiguration(this.redisConfigs.getCluster().getNodes() == null ? cluster.getNodes() : this.redisConfigs.getCluster().getNodes());
        redisClusterConfig.setMaxRedirects(this.redisConfigs.getCluster().getMaxRedirects());
        if (StringUtils.isNoneBlank(new CharSequence[]{this.redisConfigs.getPassword()})) {
            redisClusterConfig.setPassword(this.redisConfigs.getPassword());
        }
        if (StringUtils.isNoneBlank(new CharSequence[] {this.redisConfigs.getUsername()})) {
            redisClusterConfig.setUsername(this.redisConfigs.getUsername());
        }
        LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisClusterConfig, this.lettucePoolingClientConfiguration);
        lettuceConnectionFactory.afterPropertiesSet();
        return lettuceConnectionFactory;
    }
}
// CHECKSTYLE:ON
