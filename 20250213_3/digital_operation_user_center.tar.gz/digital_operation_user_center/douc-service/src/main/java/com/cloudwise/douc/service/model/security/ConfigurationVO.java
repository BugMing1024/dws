package com.cloudwise.douc.service.model.security;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 安全策略管理-请求实体
 *
 * @Author maker.wang
 * @Date 2021-05-24 10:56
 **/
@Data
public class ConfigurationVO implements Serializable {

    private static final long serialVersionUID = 813294839869241252L;
    /**
     * 是否开启多点登录 0关 1开
     **/
    private String multiPointLogin;

    /**
     * 密码有效时间 天
     **/
    private String secretEffectiveTime;

    /**
     * 密码连续错误次数
     **/
    private String secretErrorTime;

    /**
     * 账号锁定时间 小时
     **/
    private String accountLockTime;

    /**
     * 禁止使用最近密码次数
     **/
    private String disableLatestSecretTime;

    /**
     * 密码最大长度
     **/
    private String secretMaxLength;

    /**
     * 密码最小长度
     **/
    private String secretMinLength;

    /**
     * 回话超时时间 分钟
     **/
    private String sessionTimeOut;

    /**
     * 日志保留时间 天
     **/
    private String logSaveTime;

    /**
     * 开启告警消息推送 0关 1开
     **/
    private String warnMessagePush;

    /**
     * 报警推送地址URL
     **/
    private String warnPushUrl;

    /**
     * appKey
     **/
    private String warnAppKey;

    /**
     * 非法IP登录提醒 0关 1开
     **/
    private String warnIllegalIp;

    /**
     * 密码连续错误提醒 0关 1开
     **/
    private String warnPasswordContinuousError;

    /**
     * 第一次登录或者重置密码修改密码 开关   0关 1开
     */
    private String updatePasswordOpen;

    /**
     * 二次认证配置是否开启  0关 1开,默认关闭
     */
    private String openSecondaryAuthentication;

    /**
     * 通知管理员
     */
    private String administratorName;

    /**
     * 二次认证模板
     */
    private String secondaryAuthenticationTemplate;

    /**
     * 二次认证英文模板
     */
    private String enSecondaryAuthenticationTemplate;

    private String secondaryAuthenticationCode;
    private String secondaryAuthenticationHistoryTemplate;
    private String secondaryAuthenticationHistoryCode;

    /**
     * 系统时区code
     */
    private String systemTimeZoneCityCode;

    @ApiModelProperty(value = "定期改密，1：开启，2：关闭")
    private String timingUpdatePasswordOpen;

    @ApiModelProperty(value = "密码到期提醒，1：开启，2：关闭")
    private String passwordExpireRemindOpen;

    @ApiModelProperty(value = "提醒频率 天")
    private String passwordExpireRemindDays;

    @ApiModelProperty(value = "提醒方式 1系统消息，2短信，3邮箱。多个逗号分隔")
    private String passwordExpireRemindWays;

    @ApiModelProperty(value = "密码过期提醒短信模板")
    private String passwordExpireSmsTemplate;

    @ApiModelProperty(value = "密码过期提醒邮箱模板")
    private String passwordExpireEmailTemplate;

    @ApiModelProperty(value = "密码过期提醒系统模板")
    private String passwordExpireSysMessageTemplate;

    @ApiModelProperty(value = "找回密码模板")
    private String retrievePasswordSmsTemplate;

    @ApiModelProperty(value = "找回密码英文模板")
    private String enRetrievePasswordSmsTemplate;

    @ApiModelProperty(value = "手机验证码登录模板")
    private String loginSmsTemplate;

    @ApiModelProperty(value = "手机验证码英文登录模板")
    private String enLoginSmsTemplate;

    @ApiModelProperty(value = "是否开启手机验证码登录，1开启")
    private String openMobileVerificationCodeLogin;

    @ApiModelProperty(value = "1：开启，2：关闭")
    private String licenseExpireRemindOpen;

    @ApiModelProperty(value = "'提醒方式 1系统消息，2短信，3邮箱")
    private String licenseExpireRemindWays;

    @ApiModelProperty(value = "短信模板")
    private String licenseExpireSmsTemplate;

    @ApiModelProperty(value = "邮件模板")
    private String licenseExpireEmailTemplate;

    @ApiModelProperty(value = "密码至少包含 1大写字母 2小写字母 3数字 4特殊符号")
    private String passwordContains;
    
    @ApiModelProperty(value = "true表示启动子租户功能，false代表关闭子租户功能。子租户功能：显示用户邀请，显示子租户管理")
    private String childAccountEnable;
}
