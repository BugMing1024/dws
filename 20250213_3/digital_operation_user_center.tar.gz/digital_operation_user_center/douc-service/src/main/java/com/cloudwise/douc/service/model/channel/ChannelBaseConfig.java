package com.cloudwise.douc.service.model.channel;

import com.cloudwise.douc.metadata.model.channel.ChannelSubType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author zafir.zhong
 * @description 渠道基本的配置
 * @date Created in 16:08 2022/4/15.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelBaseConfig {

    /**
     * 渠道的唯一标识
     */
    private String code;
    @ApiModelProperty(value = "图标地址")
    private String icon;
    private String iconUnChoose;
    /**
     * 顺序
     */
    @ApiModelProperty(value = "顺序")
    private Integer sequence;

    /**
     * 字段的显示名称 中文
     */
    private String name;
    /**
     * 字段的显示名称 英文
     */
    private String enName;

    private ChannelSubType subType;

    @ApiModelProperty(value = "发送的实现类")
    private String senderClazz;
    @ApiModelProperty(value = "检查的实现类")
    private String checkerClazz;

    /**
     * 单次发送的上限
     */
    private Map<String, Integer> senderPartNum = new HashMap<>();

    /**
     * 页面相关的配置
     */
    private List<ChannelStepConfig> config;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ChannelBaseConfig that = (ChannelBaseConfig) o;
        return Objects.equals(code, that.code) && Objects.equals(this.getSubTypeCode(), that.getSubTypeCode());
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, getSubTypeCode());
    }

    private String getSubTypeCode() {
        if (subType == null) {
            return null;
        }
        return subType.getCode();
    }
}
