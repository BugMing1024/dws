package com.cloudwise.douc.service.cache;

/**
 * @author leakey.li
 * @description:
 * @date Created in 2:32 下午 2021/9/3.
 */
public interface ISystemUpgradeCache {
    /**
     * @param accountId         租户id
     * @param openSystemUpgrade 系统设置开关
     * @return
     * @description 设置 系统设置开关缓存
     * @author leakey.li
     * @date 2021/9/6
     * @time 2:33 下午
     */
    void setSystemUpgradeCache(Long accountId, Integer openSystemUpgrade);

}
