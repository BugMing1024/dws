package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;

import java.util.List;
import java.util.Map;

/**
 * @author KenLiang
 * @description: 用户信息数据流类，从redis或者数据库获取用户信息
 * @date Created in 7:15 PM 2021/1/29.
 */
public interface IUserDataFlow {
    /**
     * description:全量更新基于用户id的用户信息至缓存
     *
     * @date create by ken at 2021/1/26 7:46 PM
     */
    void updateAllUserBasedByIdToCache();

    /**
     * description:通过用户id集合批量获取缓存中的用户信息，没获取到从数据库查
     *
     * @param userIds 用户id集合
     * @return 用户信息集合
     * @date create by ken at 2021/1/26 7:47 PM
     */
    List<UserBaseInfoCacheDTO> getMultiUserByIds(Long accountId, List<Long> userIds);


    /**
     * description:通过用户名集合批量获取缓存中的用户信息，没获取到从数据库查
     *
     * @param userAlias 用户名集合
     * @return 用户信息集合
     * @date create by ken at 2021/1/26 7:47 PM
     */
    List<UserBaseInfoCacheDTO> getMultiUserFromCacheByUserAliass(Long accountId, List<String> userAlias);

    /**
     * description: 增加/更新基于用户单一用户信息至缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateSingleUserBasedToCache(UserBaseInfoCacheDTO userBaseInfoCacheDTO);


    /**
     * description: 增加/更新基于用户用户信息至缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateUsersBasedToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList);

    /**
     * description: 增加/更新基于用户单一用户状态至缓存
     *
     * @param userBaseInfoCacheDTO 需要用户id,和accountid
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateSingleUserStatusBasedToCache(Boolean isStart, UserBaseInfoCacheDTO userBaseInfoCacheDTO);


    /**
     * description: 增加/更新基于用户用户状态至缓存
     *
     * @param userBaseInfoCacheDTO 需要用户id,和accountid
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateUsersStatusBasedToCache(List<UserBaseInfoCacheDTO> startUserBaseInfoCacheDTOList, List<UserBaseInfoCacheDTO> stopUserBaseInfoCacheDTOList);

    /**
     * description: 删除基于用户用户信息至缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void deleteUsersBasedToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList);

    /**
     * 查询用户的数量
     *
     * @param accountId
     * @param status
     * @return
     */
    int getUsersCountByAccountIdAndStatus(Long accountId, Integer status);


    /**
     * 删除用户数量缓存
     *
     * @param accountId
     */
    void deleteUsersCountByAccountId(Long accountId);

    /**
     * @param accountId 租户id
     * @param userId    用户id
     * @return 用户拥有的角色id+type
     * @description 获取用户拥有的角色id
     * @autor ken.liang
     * @date 2021/6/22
     * @time 3:00 PM
     */
    Map<Long, Integer> getRoleIdTypeMapByUserIdAndAccountId(Long accountId, Long userId);

    /**
     * @param accountId
     * @param userIdList
     * @return void
     * @description 删除用户与角色关系缓存
     * @author ken.liang
     * @date 2021/6/28
     * @time 7:41 PM
     */
    void deleteRoleIdTypeMapByUserIdAndAccountId(Long accountId, List<Long> userIdList);

    void clearMultiUserFromCacheByUserAliasCache(Long accountId);

    void clearMultiUserFromCacheByIdsCache(Long accountId);

}
