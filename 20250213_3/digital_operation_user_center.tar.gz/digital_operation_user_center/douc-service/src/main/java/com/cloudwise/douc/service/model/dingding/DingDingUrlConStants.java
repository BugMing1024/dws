package com.cloudwise.douc.service.model.dingding;


public class DingDingUrlConStants {

    //获取accessToken
    public static final String DINGDING_ACCESS_TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/accessToken";

    //获取子部门ID列表
    public static final String DINGDING_DEPARTMENT_CHILDDEPARTMENTID_URL = "https://oapi.dingtalk.com/topapi/v2/department/listsubid?access_token=";

    //获取部门详情
    public static final String DINGDING_DEPARTMENT_INFO_URL = "https://oapi.dingtalk.com/topapi/v2/department/get?access_token=";

    //获取部门用户UserID列表
    public static final String DINGDING_DEPARTMENT_USERID_LIST_URL = "https://oapi.dingtalk.com/topapi/user/listid?access_token=";

    //查询用户详情
    public static final String DINGDING_USER_INFO_URL = "https://oapi.dingtalk.com/topapi/v2/user/get?access_token=";

}
