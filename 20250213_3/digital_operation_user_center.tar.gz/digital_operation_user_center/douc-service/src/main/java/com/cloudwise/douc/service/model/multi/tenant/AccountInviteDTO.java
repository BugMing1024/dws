package com.cloudwise.douc.service.model.multi.tenant;

import cn.hutool.core.date.DatePattern;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author bradyliu
 * @description: 当前作为邀请表数据响应传输对象
 * @date Created in 14:23 2021/7/13.
 */
@Data
public class AccountInviteDTO {
    // id
    private Long id;
    // 被邀请人姓名
    @NotBlank(message = IBaseExceptionCode.MULTI_ACCOUNT_SYSTEM_NAME_NOT_BLANK)
    private String name;
    // 被邀请人邮箱
    @Email(message = IBaseExceptionCode.API_MODEL_EMAIL)
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_NOT_BLANK)
    @Length(max = 64, message = IBaseExceptionCode.API_ACCOUNT_EMAIL_OVER_SIZE)
    private String inviteeEmail;
    // 目标部门id
    @NotNull
    private Long targetDepartmentId;
    private String targetDepartment;
    // 邮寄、邀请同意状态
    private Integer status;
    // 被邀请类型，1 内部 2 外部
    @NotNull
    private Integer origin;
    // 有效起始日期
    @NotNull
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    private Date startTime;
    // 有效终止日期
    @NotNull
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    private Date endTime;
    // 工作职务
    private String position;
    // 外部连接相关UUID，邀请连接必带信息
    @NotBlank
    private String externalLinkUUID;
    // 顶级租户id
    @NotNull
    private Long topAccountId;
    // 创建该邀请项的租户id
    @NotNull
    private Long accountId;
    @NotNull
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    private Date createTime;
    // 回复时间
    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    private Date replyTime;
}