package com.cloudwise.douc.service.model.logo;

import lombok.Data;

import java.util.Map;

/**
 * @author Bernie
 * @date 2020-12-11 13:46
 */
@Data
public class LogoResultEntity {
    private String logoData;
    private Long version;
    private String name;
    private String cnName;
    private String enName;
    private Integer type;
    private Map<String, Map> multiLanguage;
}
