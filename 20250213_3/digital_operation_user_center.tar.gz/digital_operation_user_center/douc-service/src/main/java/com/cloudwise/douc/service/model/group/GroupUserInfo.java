package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.metadata.model.user.UserGroupBaseInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class GroupUserInfo implements Serializable {
    private List<UserGroupBaseInfo> list;

    private List<GroupInfo> nextGroups;
}