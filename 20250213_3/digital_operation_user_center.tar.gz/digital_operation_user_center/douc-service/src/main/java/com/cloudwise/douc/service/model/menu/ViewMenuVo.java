package com.cloudwise.douc.service.model.menu;

import com.cloudwise.douc.commons.model.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ViewMenuVo extends BaseEntity {

    private String code;

    @ApiModelProperty(value = "1菜单 4按钮")
    private Integer resourceType;

    @ApiModelProperty(value = "是否选中")
    private Boolean selected;

    private String moduleCode;
}
