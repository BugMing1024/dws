package com.cloudwise.douc.service.model.sync;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * Dubbo删除部门实体
 *
 * @author maker.wang
 * @date 2021-11-08 17:30
 **/
@Data
@ApiModel("Dubbo删除部门实体")
public class DubboDeleteDepartment implements Serializable {

    private static final long serialVersionUID = 5504334306968638060L;
    @ApiModelProperty(value = "部门编码集合", required = true)
    @NotEmpty(message = IBaseExceptionCode.RPC_DATA_DEPARTMENT_INFO_NOT_BLANK)
    private List<String> departmentCodes;

    @ApiModelProperty(value = "顶级租户id", required = true)
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_TOP_ID_NULL)
    private Long accountId;

}
