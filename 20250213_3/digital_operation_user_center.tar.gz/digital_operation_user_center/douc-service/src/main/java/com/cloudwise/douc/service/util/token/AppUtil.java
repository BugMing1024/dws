package com.cloudwise.douc.service.util.token;

import cn.hutool.core.util.IdUtil;
import com.cloudwise.douc.commons.utils.sm2.Sm2Utils;
import com.cloudwise.douc.commons.utils.sm2.SmsecurityService;
import com.cloudwise.douc.service.util.rsa.RSAUtil2;
import com.cloudwise.douc.service.util.wecom.SHA1;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


/**
 * @author maker.wang
 * @description: 随机产生唯一的app_key和app_secret
 * @date Created in 10:40 上午 2021/6/2.
 */
@Slf4j
public class AppUtil {

    /**
     * 生成 app_secret 密钥
     *
     * @author maker.wang
     * @date 2021-06-02
     * @time 10:45
     */
    private static final String[] CHARS = new String[]{
            "a", "b", "c", "d", "e", "f",
            "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
            "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I",
            "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
            "W", "X", "Y", "Z"};

    /**
     * @Description: <p>
     * 短8位UUID思想其实借鉴微博短域名的生成方式，但是其重复概率过高，而且每次生成4个，需要随即选取一个。
     * 本算法利用62个可打印字符，通过随机生成32位UUID，由于UUID都为十六进制，
     * 所以将UUID分成8组，每4个为一组，然后通过模62操作，结果作为索引取出字符，
     * 这样重复率大大降低。
     * 经测试，在生成一千万个数据也没有出现重复，完全满足大部分需求。
     * </p>
     */
    public static String getAppId() {
        StringBuilder shortBuffer = new StringBuilder();
        String uuid = IdUtil.fastSimpleUUID();
        for (int i = 0; i < 8; i++) {
            String str = uuid.substring(i * 4, i * 4 + 4);
            int x = Integer.parseInt(str, 16);
            shortBuffer.append(CHARS[x % 0x3E]);
        }
        return shortBuffer.toString();

    }

    /**
     * 算法： sha1(appId+uuid) 生成AppSecret
     *
     * @param appId
     * @return java.lang.String
     * @author maker.wang
     * @date 2021-06-02
     * @time 10:47
     */
    public static String getAppSecret(String appId) {
        try {
            String str = appId + IdUtil.fastUUID();
            
            return SHA1.getSHA1(str);
        } catch (Exception e) {
            log.error("generte appSecret error,exception:", e);
        }
        return appId;
    }

    /**
     * sm2加密生成带时间戳的appSecret :appSecret---时间戳
     *
     * @param
     * @return String:格式  appSecret---时间戳
     * @author maker.wang
     * @date 2021-06-02
     * @time 18:55
     */
    public static String sm2GenerateAppSecretWithTimeStamp(String appSecret) {
        if (StringUtils.isBlank(appSecret)) {
            throw new NullPointerException("appSecret不能空");
        }
        appSecret += "---";
        appSecret += System.currentTimeMillis();
        String appSecretSm2 = Sm2Utils.SMBEncryption(appSecret, SmsecurityService.pubkey);
        return appSecretSm2;
    }

    /**
     * sm2加密生成带时间戳的appSecret :appSecret---时间戳
     *
     * @param
     * @return String:格式  appSecret---时间戳
     * @author maker.wang
     * @date 2021-06-02
     * @time 18:55
     */
    public static String rsaGenerateAppSecretWithTimeStamp(String appSecret) {
        if (StringUtils.isBlank(appSecret)) {
            throw new NullPointerException("appSecret不能空");
        }
        appSecret += "---";
        appSecret += System.currentTimeMillis();
        String appSecretSm2 = RSAUtil2.encrypt(appSecret, RSAUtil2.DEFAULT_PUBLIC_KEY_STRING);
        return appSecretSm2;
    }

}
