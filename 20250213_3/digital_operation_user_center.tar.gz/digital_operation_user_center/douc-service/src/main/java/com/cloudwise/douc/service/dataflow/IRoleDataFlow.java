package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.role.RoleInfo;

import java.util.List;

/**
 * 查询角色相关信息，屏蔽底层查询，数据可能来自DB或redis
 *
 * @author Bernie
 * @date 2021-02-01 09:41
 */
public interface IRoleDataFlow {

    /**
     * 通过roleIds获取角色从缓存中
     *
     * @param accountId
     * @param roleIds
     * @return
     */
    List<RoleInfo> getRoleInfosByRoleIds(Long accountId, List<Long> roleIds);


}
