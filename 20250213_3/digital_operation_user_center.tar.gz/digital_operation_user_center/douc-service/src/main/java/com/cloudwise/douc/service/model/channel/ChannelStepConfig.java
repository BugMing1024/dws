package com.cloudwise.douc.service.model.channel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

/**
 * @author zafir.zhong
 * @description 渠道分步的对象
 * @date Created in 16:05 2022/4/15.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelStepConfig {
    /**
     * 本步的标题
     */
    private String title;
    /**
     * 副标题
     */
    private String subtitle;
    /**
     * 页面上的提示
     */
    private String tips;
    /**
     * 本步的标题
     */
    private String enTitle;
    /**
     * 副标题
     */
    private String enSubtitle;
    /**
     * 页面上的提示
     */
    private String enTips;
    /**
     * 排序
     */
    private int sequence;
    
    private String multiLanguage;

    /**
     * 本步骤中所有的字段
     */
    private List<ChannelFieldConfig> fields;

}
