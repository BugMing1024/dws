package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 添加或修改角色组
 *
 * @author maker.wang
 * @date 2022-08-11 09:41
 **/
@Data
@ApiModel("添加或修改角色组")
public class RoleGroupAddOrUpdateBO implements Serializable {
    private static final long serialVersionUID = 4785433476513809860L;

    @ApiModelProperty("租户ID")
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;

    @ApiModelProperty("用户ID")
    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    @Range(min = 1, max = Long.MAX_VALUE, message = "userId必须是正整数")
    private Long userId;

    @ApiModelProperty("角色组名称")
    @NotBlank(message = IBaseExceptionCode.API_ROLEGROUP_NAME_NOT_BLANK)
    @Length(max = 60, message = IBaseExceptionCode.RPC_ROLE_GROUP_NAME_LENGTH_ERROR)
    private String roleGroupName;

    @ApiModelProperty("角色组编码")
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_DATAITEMCODE_NOT_BLANK)
    @Length(max = 64, message = IBaseExceptionCode.RPC_ROLE_GROUP_CODE_LENGTH_ERROR)
    private String roleGroupCode;

    @ApiModelProperty("角色组描述")
    @Length(max = 100, message = IBaseExceptionCode.RPC_USER_GROUP_DESCRIPTION_LENGTH_ERROR)
    private String roleGroupDescription;


}
