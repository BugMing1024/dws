package com.cloudwise.douc.service.model.group;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class GroupUserRequestObject implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;
    private Long roleId;
    private String aliasOrNameOrEmail;
    private Integer current;
    private Integer size;
    private Long accountId;
    private Long topAccountId;
    private List<String> userIds;
    private String language;

    private boolean orderByLinked;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
