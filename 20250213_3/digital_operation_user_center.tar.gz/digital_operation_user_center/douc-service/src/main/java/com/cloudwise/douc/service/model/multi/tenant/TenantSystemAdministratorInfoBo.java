package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.validation.validator.StringValidator;
import com.cloudwise.douc.service.util.Constant;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 租户初始化自定义系统管理员信息
 *
 * @author maker.wang
 * @date 2021-06-30 14:28
 **/
@Data
public class TenantSystemAdministratorInfoBo implements Serializable {
    private static final long serialVersionUID = 3807502700605158285L;

    public TenantSystemAdministratorInfoBo() {
        this.adminType = Constant.USER_ORDINARY_TYPE;
    }

    /**
     * 系统管理员名称
     **/
    @NotBlank(message = IBaseExceptionCode.MULTI_ACCOUNT_SYSTEM_NAME_NOT_BLANK)
    @Length(max = 60, message = IBaseExceptionCode.MULTI_ACCOUNT_SYSTEM_NAME_OUT_OF_LENGTH)
    @StringValidator(regexp = "^[^\\s]{0,}$", message = IBaseExceptionCode.API_ACCOUNT_CANNOT_CONTAIN_SPACES)
    private String userName;

    /**
     * 系统管理员邮箱
     **/
    @Email(message = IBaseExceptionCode.API_MODEL_EMAIL)
    @Length(max = 64, message = IBaseExceptionCode.API_ACCOUNT_EMAIL_OVER_SIZE)
    private String email;
    /**
     * 系统管理员手机号
     **/
    @Email(message = IBaseExceptionCode.API_MODEL_MOBILE)
    private String mobile;

    /**
     * 系统管理员手机号区号
     **/
    private String areaCode;

    /**
     * 系统管理员别名
     **/
    private String userAlias;

    /**
     * 系统管理员密---码, sm2(明文密码—sm3(明文密码))
     **/
    private String userSecret;

    /**
     * sm3(sm3(明文密码))
     **/
    private transient String smPasswordCpd;

    /**
     * sm2(sm3(sm3(明文密码)))
     **/
    private transient String smPasswordBpd;

    /**
     * 1.系统管理员 2普通 3 内置
     **/
    private Integer adminType;

    /**
     * MD5加密后的密码（同步到后台）
     */
    private String encryptPassword;
}
