package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 用户组部门请求Vo
 */
@Data
@ApiModel
public class GroupDepartmentReq {
    /**
     * groupId ：用户组id
     */
    @NotNull(message = IBaseExceptionCode.API_GROUP_ID_NOT_BLANK)
    @ApiModelProperty(value = "用户组id")
    private Long groupId;
    @ApiModelProperty(value = "用户组id集合")
    private List<Long> groupIds;
    /**
     * parentId：上级部门id (传空为查询顶级部门)
     */
    @ApiModelProperty(value = "parentId：上级部门id (传空为查询顶级部门)")
    private Long parentId;
    /**
     * 部门名称 模糊查询 ，name不为空那么模糊查，与parentId无关
     */
    @ApiModelProperty(value = "部门名称 模糊查询 ，name不为空那么模糊查，与parentId无关")
    private String name;

    @ApiModelProperty(value = "用户id")
    private Long userId;

    /**
     * 本租户id
     **/
    @ApiModelProperty(value = "本租户id")
    private Long accountId;

    /**
     * 顶级租户id
     **/
    @ApiModelProperty(value = "顶级租户id")
    private Long topAccountId;

    private Integer size;
    private Integer current;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
