package com.cloudwise.douc.service.plugin.lucene;

import com.cloudwise.douc.commons.config.ConfigUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.core.LowerCaseFilter;


public class LcPinyinAnalyzerExt extends Analyzer {

    public LcPinyinAnalyzerExt() {
    }

    @Override
    protected TokenStreamComponents createComponents(String name) {
        Tokenizer tokenizer = new LcPinyinTokenizer();
        return new TokenStreamComponents(tokenizer, new LowerCaseFilter(new PinYinNGramTokenFilter(tokenizer, 1,
                ConfigUtils.getInt("lucene.sync.maxGram", 30))));
    }
}
