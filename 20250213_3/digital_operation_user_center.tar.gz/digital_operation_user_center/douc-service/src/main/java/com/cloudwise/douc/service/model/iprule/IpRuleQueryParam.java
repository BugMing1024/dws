package com.cloudwise.douc.service.model.iprule;

import lombok.Data;

/**
 * @author elsa.yang
 * @date 2020/10/13 11:34 上午
 */
@Data
public class IpRuleQueryParam {
    /**
     * 掩码或开始ip
     */
    private String ipOrNetwork;
    /**
     * 是否可用
     */
    private String type;
    private Integer size;
    private Integer current;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
