package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author leakey.li
 * @description:
 * @date Created in 3:18 下午 2021/7/3.
 */
@Data
public class UserNamePageParam implements Serializable {
    private static final long serialVersionUID = 8045984285249154860L;
    private Long accountId;
    private List<Long> groupIds;
    private String nameOrAlias;
    private Integer current;
    private Integer size;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
