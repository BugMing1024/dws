package com.cloudwise.douc.service.configuration;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author myron
 * @ClassName : RemoteAddrFilter
 * @Description :
 * @Version 1.0
 */
@Slf4j
@Component
public class ProtocolDomainFilter extends OncePerRequestFilter {
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        //校验请求request Header中是否有对应值
        try {
            String schema = request.getHeader(ConfigUtils.getString("server.protocol.header"));
            if (StrUtil.isNotBlank(schema)) {
                ThreadLocalUtil.set("protocol", schema);
            } else {
                schema = ConfigUtils.getString("server.protocol.default", "");
                if (StrUtil.isNotBlank(schema)) {
                    ThreadLocalUtil.set("protocol", schema);
                }
            }
            String domain = request.getHeader(ConfigUtils.getString("server.domain.header"));
            if (StrUtil.isNotBlank(domain)) {
                ThreadLocalUtil.set("domain", domain);
            }
            // Goes to default servlet.
            filterChain.doFilter(request, response);
        } finally {
            // 清空线程变量
            ThreadLocalUtil.remove();
        }
    }
    
}
