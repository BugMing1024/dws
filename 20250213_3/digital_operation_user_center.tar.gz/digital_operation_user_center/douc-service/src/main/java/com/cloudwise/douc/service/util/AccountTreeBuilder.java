package com.cloudwise.douc.service.util;

import com.cloudwise.douc.service.model.department.AccountNode;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * @author bradyliu
 * @description: 构造租户树
 * @date Created in 18:11 2021/7/1.
 */
public class AccountTreeBuilder {
    
    private List<AccountNode> nodes;

    public static List<AccountNode> buildTree(List<AccountNode> nodes) {

        AccountTreeBuilder treeBuilder = new AccountTreeBuilder(nodes);

        return treeBuilder.buildJSONTree();
    }

    private AccountTreeBuilder(List<AccountNode> nodes) {
        this.nodes = nodes;
    }

    // 构建JSON树形结构
    private List<AccountNode> buildJSONTree() {
        List<AccountNode> nodeTree = buildTree1();
        return nodeTree;
    }

    // 构建树形结构
    private List<AccountNode> buildTree1() {
        List<AccountNode> rootNodes = getRootAccountNode();
        List<AccountNode> treeNodes = Lists.newArrayListWithExpectedSize(rootNodes.size());
        for (AccountNode rootNode : rootNodes) {
            buildChildNodes(rootNode);
            treeNodes.add(rootNode);
        }
        return treeNodes;
    }

    // 获取到树根节点
    List<AccountNode> getRootAccountNode() {
        List<AccountNode> accountNodeResult = Lists.newArrayListWithExpectedSize(nodes.size());
        for (AccountNode accountNode : nodes) {
            Integer isTop = accountNode.getIsTop();
            boolean isTopBoolean = Constant.MULTI_ACCOUNT_IS_TOP.equals(isTop);
            if (isTopBoolean) {
                accountNodeResult.add(accountNode);
                break;
            }
        }
        return accountNodeResult;
    }

    // 根据根节点，递归查询子租户
    // 递归查询子租户信息
    private void buildChildNodes(AccountNode node) {
        List<AccountNode> childrenAccontNode = getChildAccontNode(node);
        if (!childrenAccontNode.isEmpty()) {
            for (AccountNode child : childrenAccontNode) {
                buildChildNodes(child);
            }
            node.setChildAccontNode(childrenAccontNode);
        }
    }

    // 获取父节点下所有的子节点
    private List<AccountNode> getChildAccontNode(AccountNode pnode) {
        List<AccountNode> childNodes = Lists.newArrayListWithExpectedSize(nodes.size());
        Long a = pnode.getId();
        for (AccountNode n : nodes) {
            Long b = n.getParentId();
            if (a.equals(b)) {
                childNodes.add(n);
            }
        }
        return childNodes;
    }

}
