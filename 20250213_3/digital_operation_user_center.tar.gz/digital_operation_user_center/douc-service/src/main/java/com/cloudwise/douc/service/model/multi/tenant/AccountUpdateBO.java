package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 修改子租户入参
 *
 * @author maker.wang
 * @date 2021-09-05 10:13
 **/
@Data
public class AccountUpdateBO implements Serializable {
    private static final long serialVersionUID = 2421981910805213550L;

    /**
     * 子租户id
     **/
    private Long accountId;

    /**
     * 租户名称
     **/
    @NotBlank(message = IBaseExceptionCode.API_ACCOUNT_NAME_NOT_BLANK)
    private String accountName;

    /**
     * 上级租户id
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_PARENT_ID_NOT_BLANK)
    private Long parentAccountId;

    /**
     * 子租户管理员id
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_ADMIN_USER_ID_NULL)
    private Long innerAdminUserId;
    
    /**
     * 租户可见范围 1只能看自己，2可看所有租户，3可看指定租户（顶级租户为2）
     */
    private Integer visibleScope;

    private Long createUserId;

    /**
     * 用于租户关联其他信息如部门的编码
     */
    private String code;
    
    /**
     * 企业id
     */
    private Long enterpriseId;
    
    private String innerLanguage;

}
