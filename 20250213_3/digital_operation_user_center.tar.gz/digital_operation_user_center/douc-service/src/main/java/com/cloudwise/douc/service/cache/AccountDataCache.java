package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.quota.AccountQuotaInfo;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author brady.liu
 * @description 租户缓存处理
 * @date 2021/7/7
 * @time 14:59
 */
public interface AccountDataCache {
    /**
     * @param
     * @return
     * @description 初始化租户用户量至缓存中
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:11
     */
    void loadAllUserCountCache();

    /**
     * @param accountId 顶级租户id
     * @return Map<String, Set < String>> 用户数据缓存，key:租户id，value：去重过后的accountId=userId，样式的数据
     * @description 获取缓存中租户用户量
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:11
     */
    Map<String, Set<String>> getUserCountCache(Long accountId);

    /**
     * @param accountId
     * @return
     * @description 更新租户人数应该增加缓存内容
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:06
     */
    void setUserCountCacheIncrease(Long accountId, Map<String, Set<String>> countMap);

    /**
     * @param accountId
     * @return
     * @description 更新租户人数应该减少缓存内容
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:06
     */
    void setUserCountCacheDecrease(Long accountId, Map<String, Set<String>> countMap);

    /**
     * @param accountId 顶级租户id
     * @return
     * @description 重新加载顶级租户下用户量
     * @author brady.liu
     * @date 2021/7/14
     * @time 14:40
     */
    void setUserCountCacheByTopAccountId(Long accountId);

    /**
     * @param accountDetail 租户信息
     * @return
     * @description 缓存租户信息
     * @author ken.liang
     * @date 2021/9/8
     * @time 14:40
     */
    void setAccountDetailByAccountId(Long accountId, AccountDetail accountDetail);

    /**
     * @param accountId 租户id
     * @return
     * @description 获取租户信息
     * @author ken.liang
     * @date 2021/9/8
     * @time 14:40
     */
    AccountDetail getAccountDetailByAccountId(Long accountId);


    /**
     * @param accountIds 租户id
     * @return
     * @description 删除租户信息
     * @author ken.liang
     * @date 2021/9/8
     * @time 14:40
     */
    void deleteAccountDetailByAccountId(List<Long> accountIds);

    /**
     * @param accountId 租户id
     * @return
     * @description 缓存配额信息
     * @author brady.liu
     * @date 2021/10/11
     * @time 16:09
     */
    void setAccountQuotaInfo(Long accountId, AccountQuotaInfo aqi);

    /**
     * @param accountId 租户id
     * @return
     * @description 查询配额信息
     * @author brady.liu
     * @date 2021/10/11
     * @time 16:10
     */
    AccountQuotaInfo getAccountQuotaInfo(Long accountId);

    /**
     * @description 初始加载配额缓存
     * @author brady.liu
     * @date 2021/10/12
     * @time 16:23
     */
    void loadAllAccountQuotaCache();


    void setAccountQuotaMenuInfo(Long accountId, Map<String, List<String>> map);

    Map<String, List<String>> getAccountQuotaMenuInfo(Long accountId);

}
