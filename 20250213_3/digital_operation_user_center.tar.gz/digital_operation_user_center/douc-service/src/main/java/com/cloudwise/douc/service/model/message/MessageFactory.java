package com.cloudwise.douc.service.model.message;

/**
 * @author leakey.li
 * @description: 创建短信模板类工厂
 * @date Created in 3:29 下午 2022/2/21.
 */
public class MessageFactory {
    /**
     * 三一短信通道
     */
    public static final String SAN_YI_TYPE_CODE = "SAN_YI";
    /**
     * 兴业银行短信通道
     */
    public static final String YING_YE_TYPE_CODE = "XING_YE";

    public static AbstractMessageTemplate getMessageTemplate(String code, String mobile, String content, String ip, String typeCode) {

        AbstractMessageTemplate template = null;

        switch (typeCode) {
            case SAN_YI_TYPE_CODE:
                template = new SanYiMessageTemplate(code, content, mobile, typeCode);
                break;
            case YING_YE_TYPE_CODE:
                template = new YingYeMessageTemplate(mobile, content, ip, typeCode, "北分网管系统");
                break;
            default:
        }

        return template;
    }

}