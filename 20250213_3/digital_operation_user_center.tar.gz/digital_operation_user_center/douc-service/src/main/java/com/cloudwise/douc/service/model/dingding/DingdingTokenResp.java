package com.cloudwise.douc.service.model.dingding;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @description: ${description}
 * @author: jasonlee
 * @date: 2020-10-02 15:29
 **/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DingdingTokenResp {
    private int errcode;
    private String errmsg;
    // CHECKSTYLE:OFF
    private String access_token;
    // CHECKSTYLE:ON
}
