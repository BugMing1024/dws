package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserGroupBaseInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 下级用户组 和当前用户组的用户信息
 */
@Data
@ApiModel
public class GroupUserInfoResp implements Serializable {
    /**
     * 当前用户组的用户信息
     */
    @ApiModelProperty(value = "当前用户组的用户信息")
    private List<UserGroupBaseInfo> userInfoList;
    /**
     * 下级用户组
     */
    @ApiModelProperty(value = "下级用户组")
    private List<GroupBaseInfo> groupInfoList;

}
