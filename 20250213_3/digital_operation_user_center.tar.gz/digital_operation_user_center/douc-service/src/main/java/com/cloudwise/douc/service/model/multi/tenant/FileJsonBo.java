package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountDepartmentResource;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountDicData;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountDicType;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 本地配置文件 json格式
 *
 * @author maker.wang
 * @date 2021-07-02 11:23
 **/
@Data
public class FileJsonBo implements Serializable {
    private static final long serialVersionUID = -8231664474522566748L;

    /**
     * sys_department_resource 数据
     **/
    private List<MultiAccountDepartmentResource> sysDepartmentResource;

    /**
     * sys_dic_type 数据
     **/
    private List<MultiAccountDicType> sysDicType;

    /**
     * sys_dic_data 数据
     **/
    private List<MultiAccountDicData> sysDicData;

    /**
     * sys_system_setting
     **/
    private List<MultiAccountSystemSetting> sysSystemSetting;

}
