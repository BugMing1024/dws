package com.cloudwise.douc.service.cache;


/**
 * @author zafir.zhong
 * @description 系统设置缓存的操作类
 * @date Created in 6:06 下午 2022/3/18.
 */
public interface ISystemSettingDataCache {


    /**
     * @return java.lang.Boolean
     * @description 查询缓存中的是否子租户配置
     * - 无参数
     * @author zafir.zhong
     * @date 2022/3/18
     * @time 6:06 下午
     */
    Boolean getChildAccountEnable();


    /**
     * @param enabled 是否开启子租户
     * @return boolean
     * @description 往缓存中保存子租户配置
     * @author zafir.zhong
     * @date 2022/3/18
     * @time 6:07 下午
     */
    boolean saveChildAccountEnable(boolean enabled);
}
