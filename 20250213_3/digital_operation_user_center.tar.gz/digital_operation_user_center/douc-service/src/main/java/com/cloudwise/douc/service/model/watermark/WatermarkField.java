package com.cloudwise.douc.service.model.watermark;

import lombok.Data;

/**
 * 水印的字段信息
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/11/9 16:52; update at 2023/11/9 16:52
 */
@Data
public class WatermarkField {
    
    private int type;
    private String key;
    private String value;

}
