package com.cloudwise.douc.service.model.multi.tenant;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 多租户-部门详情
 *
 * @author maker.wang
 * @date 2021-07-01 16:39
 **/
@Data
public class MultiAccountDepartmentDetail implements Serializable {
    private static final long serialVersionUID = 268500766286086124L;
    /**
     * 部门ID
     */
    private Long id;
    /**
     * 部门名称
     */
    private String name;
    /**
     * 部门编码
     */
    private String code;
    /**
     * 部门描述
     */
    private String description;
    /**
     * 上级部门ID
     */
    private Long parentId;
    /**
     * 层级
     */
    private String level;
    /**
     * 顺序
     */
    private Integer sequence;
    /**
     * 状态 1启用，2停用
     */
    private Integer status;
    /**
     * 租户ID
     */
    private Long accountId;

    private Long createUserId;

    private Date createTime;

    private Long modifyUserId;

    private Date modifyTime;

    private Object importType;

    private String ldapOu;
    /**
     * 机构电话
     */
    private String departmentTel;
    /**
     * 机构地址
     */
    private String address;
    /**
     * 负责人
     */
    private String personCharges;
    /**
     * 机构类型
     */
    private String orgType;
    /**
     * 机构城市
     */
    private String proCities;

    private String attribute;

}
