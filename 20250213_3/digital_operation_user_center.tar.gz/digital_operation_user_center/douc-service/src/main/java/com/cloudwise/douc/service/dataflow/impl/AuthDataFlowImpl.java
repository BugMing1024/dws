package com.cloudwise.douc.service.dataflow.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.StrPool;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cloudwise.douc.commons.config.DomainConfig;
import com.cloudwise.douc.commons.config.I18nMessages;
import com.cloudwise.douc.commons.constant.Constants;
import com.cloudwise.douc.commons.constant.DbConstant;
import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.commons.utils.BeanDeepCopyUtil;
import com.cloudwise.douc.metadata.activerecord.domain.SysDomain;
import com.cloudwise.douc.metadata.mapper.IDataResourceDao;
import com.cloudwise.douc.metadata.mapper.ILogDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IMenuDao;
import com.cloudwise.douc.metadata.mapper.IModelDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IMultiTypeDataResourceDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import com.cloudwise.douc.metadata.model.data.DataAuthentication;
import com.cloudwise.douc.metadata.model.menu.Menu;
import com.cloudwise.douc.metadata.model.menu.ViewMenuDto;
import com.cloudwise.douc.service.cache.IAuthCache;
import com.cloudwise.douc.service.cache.IMenuResourceCache;
import com.cloudwise.douc.service.dataflow.IAuthDataFlow;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.service.IDomainService;
import com.cloudwise.douc.service.service.IMenuService;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * @author ken.liang
 * @description:
 * @date Created in 11:12 AM 2021/6/24.
 */
@Component
@Slf4j
public class AuthDataFlowImpl implements IAuthDataFlow {
    
    @Autowired
    private IAuthCache authCache;
    
    @Autowired
    private IMenuDao menuDao;
    
    @Autowired
    private IRoleDao roleDao;
    
    @Autowired
    private IDataResourceDao dataResourceDao;
    
    @Autowired
    private IModelDataResourceDao modelDataResourceDao;
    
    @Autowired
    private ILogDataResourceDao logDataResourceDao;
    
    @Autowired
    private IMenuService menuService;
    
    @Autowired
    private IAccountService accountService;
    
    @Autowired
    private IMultiTypeDataResourceDao multiTypeDataResourceDao;
    
    @Autowired
    private IMenuResourceCache menuResourceCache;
    
    @Resource
    private IDomainService domainService;
    
    @Override
    public List<MenuResponse> getMenuAuthedByModuleCodeAndRoleIds(Long accountId, String moduleCode, Map<Long, Integer> roleIdTypeMap,
            String language) {
        if (DomainConfig.isOpenDomain()) {
            accountId = domainService.getGlobalDomainId();
        }
        Long finalAccountId = accountId;
        Set<MenuResponse> distinctMenuAuthedResponse = Sets.newTreeSet(Comparator.comparing(MenuResponse::getCode));
        Map<Long, List<MenuResponse>> menuAuthedByRoleIds = authCache.getMenuAuthedByRoleIds(accountId, moduleCode,
                Lists.newArrayList(roleIdTypeMap.keySet()));
        List<Long> noCacheRoleIds = Lists.newArrayList();
        menuAuthedByRoleIds.forEach((roleId, menuAuthedResponseList) -> {
            if (CollUtil.isEmpty(menuAuthedResponseList)) {
                noCacheRoleIds.add(roleId);
            } else {
                distinctMenuAuthedResponse.addAll(menuAuthedResponseList);
            }
        });
        log.debug("noCacheRoleIds：{}", noCacheRoleIds);
        //存在未缓存的角色菜单权限
        if (noCacheRoleIds.size() > 0) {
            Map<Long, List<MenuResponse>> noCacheMenuAuthedByModuleCodeAndRoleIdsMap = Maps.newHashMap();
            List<Long> noCacheAdminRoleIds = Lists.newArrayList();
            List<Long> noCacheCommonRoleIds = Lists.newArrayList();
            noCacheRoleIds.forEach(noCacheRoleId -> {
                if (Constant.SYSTEM_ROLE_TYPE.equals(roleIdTypeMap.get(noCacheRoleId))) {
                    noCacheAdminRoleIds.add(noCacheRoleId);
                } else {
                    noCacheCommonRoleIds.add(noCacheRoleId);
                }
            });
            //如果是系统管理员,查询所有菜单
            if (CollectionUtils.isNotEmpty(noCacheAdminRoleIds)) {
                Menu menu = new Menu();
                menu.setModuleCode(moduleCode);
                menu.setAccountId(accountId);
                menu.setLanguage(language);
                menu.setDefaultLanguage(I18nMessages.defaultLanguage().equals(language));
                List<Menu> menusByModuleCodeAndAccountId = menuDao.getMenusByModuleCodeAndAccountId(menu);
                List<MenuResponse> menuResponses = BeanDeepCopyUtil.copyObjects(menusByModuleCodeAndAccountId, MenuResponse.class);
                log.debug("noCacheAdminRoleIds:{},menuResponses:{}", noCacheAdminRoleIds, menuResponses);
                noCacheAdminRoleIds.forEach(roleId -> noCacheMenuAuthedByModuleCodeAndRoleIdsMap.put(roleId, menuResponses));
            }
            //普通角色查询菜单权限
            Map<Long, List<MenuResponse>> menuAuthedByModuleCodeAndRoleIdsMap = Maps.newHashMap();
            noCacheCommonRoleIds.forEach(roleId -> menuAuthedByModuleCodeAndRoleIdsMap.put(roleId, Lists.newArrayList()));
            if (CollectionUtils.isNotEmpty(noCacheCommonRoleIds)) {
                List<MenuResponse> menuAuthResponseList = roleDao.getMenuAuthedByModuleCodeAndRoleIds(accountId, moduleCode, noCacheCommonRoleIds);
                List<MenuResponse> menuTopAuthResponse = roleDao.getTopMenuAuthed(accountId, moduleCode, noCacheCommonRoleIds);
                Set<String> menuCodeSet = Sets.newHashSet();
                menuAuthResponseList.forEach(menuResponse -> {
                    menuCodeSet.add(menuResponse.getCode());
                    menuAuthedByModuleCodeAndRoleIdsMap.get(menuResponse.getRoleId()).add(menuResponse);
                });
                menuTopAuthResponse.forEach(menuResponse -> {
                    if (!menuCodeSet.contains(menuResponse.getCode())) {
                        menuAuthedByModuleCodeAndRoleIdsMap.get(menuResponse.getRoleId()).add(menuResponse);
                    }
                });
                boolean isProfessional = menuResourceCache.isProfessionalCache();
                noCacheMenuAuthedByModuleCodeAndRoleIdsMap.putAll(menuAuthedByModuleCodeAndRoleIdsMap);
                if (isProfessional) {
                    noCacheMenuAuthedByModuleCodeAndRoleIdsMap.entrySet().forEach(entry -> {
                        boolean isSubscribeRole = menuService.isSubscribeRole(finalAccountId, entry.getKey());
                        if (!isSubscribeRole) {
                            List<MenuResponse> filterMenuResponses = entry.getValue().stream()
                                    .filter(menuResponse -> !(StrUtil.isNotBlank(menuResponse.getTag()) && !JSONUtil.parseArray(menuResponse.getTag())
                                            .isEmpty() && JSONUtil.parseArray(menuResponse.getTag())
                                            .contains(Constants.Lic.PROFESSION_USER_FEATURE_CODE))).collect(Collectors.toList());
                            entry.setValue(filterMenuResponses);
                        }
                    });
                }
            }
            //缓存未缓存的角色菜单权限
            authCache.setMenuAuthedByRoleIds(accountId, moduleCode, noCacheMenuAuthedByModuleCodeAndRoleIdsMap);
            noCacheMenuAuthedByModuleCodeAndRoleIdsMap.values().forEach(distinctMenuAuthedResponse::addAll);
        }
        distinctMenuAuthedResponse.forEach(
                res -> I18nMessages.putMultiLanguageForce(res, Collections.singletonList("name"), language, res.getMultiLanguage()));
        return new ArrayList<>(distinctMenuAuthedResponse);
    }
    
    @Override
    public List<MenuResponse> getViewMenuAuthedByAppCodeAndRoleIds(Long accountId, String appCode, Map<Long, Integer> roleIdTypeMap) {
        List<MenuResponse> distinctMenuResponseList = new ArrayList<>();
        Map<Long, List<MenuResponse>> viewMenuAuthedByRoleIds = authCache.getViewMenuAuthedByRoleIds(accountId, appCode,
                Lists.newArrayList(roleIdTypeMap.keySet()));
        List<Long> noCacheRoleIds = Lists.newArrayList();
        for (Map.Entry<Long, List<MenuResponse>> entry : viewMenuAuthedByRoleIds.entrySet()) {
            List<MenuResponse> menuResponseList = entry.getValue();
            if (CollectionUtils.isEmpty(menuResponseList)) {
                noCacheRoleIds.add(entry.getKey());
            } else {
                distinctMenuResponseList.addAll(menuResponseList);
            }
        }
        log.debug("noCacheRoleIds:{}", noCacheRoleIds);
        //存在未缓存的角色菜单权限
        if (noCacheRoleIds.size() > 0) {
            Map<Long, List<MenuResponse>> noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap = Maps.newHashMap();
            List<Long> noCacheAdminRoleIds = Lists.newArrayList();
            List<Long> noCacheCommonRoleIds = Lists.newArrayList();
            noCacheRoleIds.forEach(noCacheRoleId -> {
                if (Constant.SYSTEM_ROLE_TYPE.equals(roleIdTypeMap.get(noCacheRoleId))) {
                    noCacheAdminRoleIds.add(noCacheRoleId);
                } else {
                    noCacheCommonRoleIds.add(noCacheRoleId);
                }
            });
            Long topAccountId = accountService.getTopAccountIdByAccountId(accountId);
            //如果是系统管理员,查询所有菜单
            if (CollectionUtils.isNotEmpty(noCacheAdminRoleIds)) {
                noCacheAdminRoleIds.forEach(roleId -> {
                    List<MenuResponse> menuList = new ArrayList<>();
                    List<ViewMenuDto> allViewMenu = menuService.getAllViewMenu(topAccountId, appCode, null, null, accountId);
                    log.debug("noCacheAdminRoleIds:{},roleId:{},allViewMenu:{}", noCacheAdminRoleIds, roleId, allViewMenu);
                    if (CollectionUtils.isNotEmpty(allViewMenu)) {
                        for (ViewMenuDto viewMenu : allViewMenu) {
                            MenuResponse menuResponse = BeanDeepCopyUtil.copyProperties(viewMenu, MenuResponse.class);
                            if (StringUtils.isNotBlank(viewMenu.getResourceCode())) {
                                Menu menu = new Menu();
                                menu.setCode(viewMenu.getResourceCode());
                                menu.setModuleCode(viewMenu.getModuleCode());
                                Menu menuByCode = menuDao.getMenuByCode(menu);
                                if (menuByCode != null) {
                                    menuResponse.setDisplayCondition(menuByCode.getDisplayCondition());
                                }
                            }
                            menuList.add(menuResponse);
                        }
                    }
                    List<MenuResponse> distinctMenuResponses = menuList.stream().distinct().collect(Collectors.toList());
                    noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap.put(roleId, distinctMenuResponses);
                });
            }
            //普通角色查询菜单权限
            if (CollectionUtils.isNotEmpty(noCacheCommonRoleIds)) {
                noCacheCommonRoleIds.forEach(roleId -> {
                    List<Long> roleIdList = new ArrayList<>();
                    roleIdList.add(roleId);
                    List<ViewMenuDto> allViewMenu = new ArrayList<>();
                    List<MenuResponse> menuList = new ArrayList<>();
                    allViewMenu = menuService.getAllViewMenu(topAccountId, appCode, roleIdList, null, accountId);
                    log.debug("noCacheCommonRoleIds:{},roleId:{},allViewMenu:{}", noCacheCommonRoleIds, roleId, allViewMenu);
                    if (CollectionUtils.isNotEmpty(allViewMenu)) {
                        for (ViewMenuDto viewMenu : allViewMenu) {
                            MenuResponse menuResponse = BeanDeepCopyUtil.copyProperties(viewMenu, MenuResponse.class);
                            if (StringUtils.isNotBlank(viewMenu.getResourceCode())) {
                                Menu menu = new Menu();
                                menu.setCode(viewMenu.getResourceCode());
                                menu.setModuleCode(viewMenu.getModuleCode());
                                Menu menuByCode = menuDao.getMenuByCode(menu);
                                if (menuByCode != null) {
                                    menuResponse.setDisplayCondition(menuByCode.getDisplayCondition());
                                    menuResponse.setTag(menuByCode.getTag());
                                }
                            }
                            boolean isProfessional = menuResourceCache.isProfessionalCache();
                            if (isProfessional) {
                                boolean isSubscribeRole = menuService.isSubscribeRole(accountId, roleId);
                                if (!isSubscribeRole) {
                                    boolean isViewSubscribe =
                                            viewMenu.getType() == 4 && StrUtil.isNotBlank(viewMenu.getTag()) && JSONUtil.parseArray(viewMenu.getTag())
                                                    .contains(Constants.Lic.PROFESSION_USER_FEATURE_CODE);
                                    
                                    if (!StrUtil.isNotBlank(menuResponse.getTag()) && !JSONUtil.parseArray(menuResponse.getTag()).isEmpty()
                                            && JSONUtil.parseArray(menuResponse.getTag()).contains(Constants.Lic.PROFESSION_USER_FEATURE_CODE)
                                            && isViewSubscribe) {
                                        continue;
                                    }
                                }
                            }
                            menuList.add(menuResponse);
                        }
                        List<MenuResponse> distinctMenuResponses = menuList.stream().distinct().collect(Collectors.toList());
                        noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap.put(roleId, distinctMenuResponses);
                    }
                });
            }
            log.debug("noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap:{}", noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap);
            //缓存未缓存的角色菜单权限
            authCache.setViewMenuAuthedByRoleIds(accountId, appCode, noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap);
            List<MenuResponse> allMenuResponseList = new ArrayList<>();
            for (List<MenuResponse> menuResponseList : noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap.values()) {
                allMenuResponseList.addAll(menuResponseList);
            }
            if (CollectionUtils.isNotEmpty(distinctMenuResponseList)) {
                distinctMenuResponseList.addAll(
                        allMenuResponseList.stream().distinct().sorted(Comparator.comparing(MenuResponse::getSequence)).collect(Collectors.toList()));
            } else {
                distinctMenuResponseList = allMenuResponseList.stream().distinct().sorted(Comparator.comparing(MenuResponse::getSequence))
                        .collect(Collectors.toList());
            }
        }
        return new ArrayList<>(distinctMenuResponseList);
    }
    
    @Override
    public void deleteMenuAuthedByRoleIds(Long accountId, List<String> moduleCodeList, List<Long> roleIds) {
        authCache.deleteMenuAuthedByRoleIds(accountId, moduleCodeList, roleIds);
    }
    
    @Override
    public void deleteViewMenuAuthedByRoleIds(Long accountId, List<String> appCodeList, List<Long> roleIds) {
        authCache.deleteViewMenuAuthedByRoleIds(accountId, appCodeList, roleIds);
    }
    
    @Override
    public void setMenuAuthedByRoleIdsDirty(Long accountId, List<String> moduleCodeList) {
        moduleCodeList.forEach(moduleCode -> authCache.setMenuAuthedByRoleIdsDirty(accountId, moduleCode));
    }
    
    @Override
    public void setViewMenuAuthedByRoleIdsDirty(Long accountId, List<String> appCodeList) {
        appCodeList.forEach(appCode -> authCache.setViewMenuAuthedByRoleIdsDirty(accountId, appCode));
    }
    
    @Override
    public List<DataAuthentication> getBizDataAuthedByRoleIds(Long accountId, Map<Long, Integer> roleIdTypeMap) {
        
        List<DataAuthentication> allDataAuthenticationList = Lists.newArrayList();
        //查询角色数据权限缓存
        Map<Long, List<DataAuthentication>> dataAuthedByRoleIds = authCache.getDataAuthedByRoleIds(accountId, Constant.DATAAUTH_DATATYPE_CMDB_BIZ,
                Lists.newArrayList(roleIdTypeMap.keySet()));
        List<Long> noCacheRoleIds = Lists.newArrayList();
        dataAuthedByRoleIds.forEach((roleId, dataAuthenticationList) -> {
            if (dataAuthenticationList == null) {
                noCacheRoleIds.add(roleId);
            } else {
                allDataAuthenticationList.addAll(dataAuthenticationList);
            }
        });
        //存在未缓存的角色数据权限
        if (noCacheRoleIds.size() > 0) {
            Map<Long, List<DataAuthentication>> noCacheDataAuthedByDataTypeAndRoleIdsMap = Maps.newHashMap();
            List<Long> noCacheAdminRoleIds = Lists.newArrayList();
            List<Long> noCacheCommonRoleIds = Lists.newArrayList();
            noCacheRoleIds.forEach(noCacheRoleId -> {
                if (Constant.SYSTEM_ROLE_TYPE.equals(roleIdTypeMap.get(noCacheRoleId))) {
                    noCacheAdminRoleIds.add(noCacheRoleId);
                } else {
                    noCacheCommonRoleIds.add(noCacheRoleId);
                }
            });
            if (CollectionUtils.isNotEmpty(noCacheAdminRoleIds)) {
                //系统管理员，查询所有数据资源
                List<DataAuthentication> dataAuthenticationList = dataResourceDao.listDataAuthentication(
                        DomainConfig.isOpenDomain() ? null : Lists.newArrayList(StrUtil.toString(accountId)));
                setAllAuth(dataAuthenticationList, 1, null);
                noCacheAdminRoleIds.forEach(roleId -> noCacheDataAuthedByDataTypeAndRoleIdsMap.put(roleId, dataAuthenticationList));
            }
            if (CollectionUtils.isNotEmpty(noCacheCommonRoleIds)) {
                Map<Long, List<DataAuthentication>> dataAuthedByModuleCodeAndRoleIdsMap = Maps.newHashMap();
                noCacheCommonRoleIds.forEach(roleId -> {
                    dataAuthedByModuleCodeAndRoleIdsMap.put(roleId, Lists.newArrayList());
                });
                List<DataAuthentication> dataAuthedByRoleIds1 = dataResourceDao.getDataAuthedByRoleIds(
                        DomainConfig.isOpenDomain() ? null : Lists.newArrayList(StrUtil.toString(accountId)),
                        noCacheCommonRoleIds.stream().map(String::valueOf).collect(Collectors.toList()));
                dataAuthedByRoleIds1.forEach((dataAuthentication) -> {
                    dataAuthedByModuleCodeAndRoleIdsMap.get(dataAuthentication.getRoleId()).add(dataAuthentication);
                });
                //普通角色，查询角色拥有数据权限
                noCacheDataAuthedByDataTypeAndRoleIdsMap.putAll(dataAuthedByModuleCodeAndRoleIdsMap);
            }
            //缓存未缓存的角色数据权限
            authCache.setDataAuthedByRoleIds(accountId, Constant.DATAAUTH_DATATYPE_CMDB_BIZ, noCacheDataAuthedByDataTypeAndRoleIdsMap);
            noCacheDataAuthedByDataTypeAndRoleIdsMap.values().forEach(allDataAuthenticationList::addAll);
        }
        //合并所有角色数据权限
        this.distinctAndSetAuthDataAuthentications(allDataAuthenticationList, 1);
        //去除空权限
        this.removeEmptyAuth(allDataAuthenticationList);
        return allDataAuthenticationList;
    }
    
    @Override
    public List<DataAuthentication> getModelDataAuthedByRoleIds(Long accountId, Map<Long, Integer> roleIdTypeMap) {
        List<DataAuthentication> allDataAuthenticationList = Lists.newArrayList();
        //查询角色数据权限缓存
        Map<Long, List<DataAuthentication>> dataAuthedByRoleIds = authCache.getDataAuthedByRoleIds(accountId, Constant.DATAAUTH_DATATYPE_CMDB_MODEL,
                Lists.newArrayList(roleIdTypeMap.keySet()));
        List<Long> noCacheRoleIds = Lists.newArrayList();
        dataAuthedByRoleIds.forEach((roleId, dataAuthenticationList) -> {
            if (dataAuthenticationList == null) {
                noCacheRoleIds.add(roleId);
            } else {
                allDataAuthenticationList.addAll(dataAuthenticationList);
            }
        });
        //存在未缓存的角色数据权限
        if (noCacheRoleIds.size() > 0) {
            Map<Long, List<DataAuthentication>> noCacheDataAuthedByDataTypeAndRoleIdsMap = Maps.newHashMap();
            List<Long> noCacheAdminRoleIds = Lists.newArrayList();
            List<Long> noCacheCommonRoleIds = Lists.newArrayList();
            noCacheRoleIds.forEach(noCacheRoleId -> {
                if (Constant.SYSTEM_ROLE_TYPE.equals(roleIdTypeMap.get(noCacheRoleId))) {
                    noCacheAdminRoleIds.add(noCacheRoleId);
                } else {
                    noCacheCommonRoleIds.add(noCacheRoleId);
                }
            });
            if (CollectionUtils.isNotEmpty(noCacheAdminRoleIds)) {
                //系统管理员，查询所有数据资源
                List<DataAuthentication> dataAuthenticationList = modelDataResourceDao.listDataAuthentication(String.valueOf(accountId));
                setAllAuth(dataAuthenticationList, 2, null);
                noCacheAdminRoleIds.forEach(roleId -> noCacheDataAuthedByDataTypeAndRoleIdsMap.put(roleId, dataAuthenticationList));
            }
            if (CollectionUtils.isNotEmpty(noCacheCommonRoleIds)) {
                //普通角色，查询角色拥有数据权限
                Map<Long, List<DataAuthentication>> dataAuthedByModuleCodeAndRoleIdsMap = Maps.newHashMap();
                noCacheCommonRoleIds.forEach(roleId -> {
                    dataAuthedByModuleCodeAndRoleIdsMap.put(roleId, Lists.newArrayList());
                });
                List<DataAuthentication> dataAuthenticationList = modelDataResourceDao.getDataAuthedByRoleIds(String.valueOf(accountId),
                        noCacheCommonRoleIds.stream().map(String::valueOf).collect(Collectors.toList()));
                dataAuthenticationList.forEach((dataAuthentication) -> {
                    dataAuthedByModuleCodeAndRoleIdsMap.get(dataAuthentication.getRoleId()).add(dataAuthentication);
                });
                noCacheDataAuthedByDataTypeAndRoleIdsMap.putAll(dataAuthedByModuleCodeAndRoleIdsMap);
            }
            //缓存未缓存的角色数据权限
            authCache.setDataAuthedByRoleIds(accountId, Constant.DATAAUTH_DATATYPE_CMDB_MODEL, noCacheDataAuthedByDataTypeAndRoleIdsMap);
            noCacheDataAuthedByDataTypeAndRoleIdsMap.values().forEach(allDataAuthenticationList::addAll);
        }
        //合并所有角色数据权限
        this.distinctAndSetAuthDataAuthentications(allDataAuthenticationList, 2);
        //去除空权限
        this.removeEmptyAuth(allDataAuthenticationList);
        return allDataAuthenticationList;
    }
    
    @Override
    public List<DataAuthentication> getOtherDataAuthedByRoleIds(Long accountId, String dataType, Map<Long, Integer> roleIdTypeMap) {
        
        List<DataAuthentication> allDataAuthenticationList = Lists.newArrayList();
        //查询角色数据权限缓存
        Map<Long, List<DataAuthentication>> dataAuthedByRoleIds = authCache.getDataAuthedByRoleIds(accountId, dataType,
                Lists.newArrayList(roleIdTypeMap.keySet()));
        List<Long> noCacheRoleIds = Lists.newArrayList();
        dataAuthedByRoleIds.forEach((roleId, dataAuthenticationList) -> {
            if (dataAuthenticationList == null) {
                noCacheRoleIds.add(roleId);
            } else {
                allDataAuthenticationList.addAll(dataAuthenticationList);
            }
        });
        //存在未缓存的角色数据权限
        if (noCacheRoleIds.size() > 0) {
            Map<Long, List<DataAuthentication>> noCacheDataAuthedByDataTypeAndRoleIdsMap = Maps.newHashMap();
            List<Long> noCacheAdminRoleIds = Lists.newArrayList();
            List<Long> noCacheCommonRoleIds = Lists.newArrayList();
            noCacheRoleIds.forEach(noCacheRoleId -> {
                if (Constant.SYSTEM_ROLE_TYPE.equals(roleIdTypeMap.get(noCacheRoleId))) {
                    noCacheAdminRoleIds.add(noCacheRoleId);
                } else {
                    noCacheCommonRoleIds.add(noCacheRoleId);
                }
            });
            if (CollectionUtils.isNotEmpty(noCacheAdminRoleIds)) {
                //系统管理员，查询所有数据资源
                List<DataAuthentication> dataAuthenticationList = logDataResourceDao.listDataAuthentication(
                        DomainConfig.isOpenDomain() ? null : Lists.newArrayList(accountId), dataType);
                setAllAuth(dataAuthenticationList, 2, dataType);
                //将系统管理员的数据资源添加到 noCacheDataAuthedByDataTypeAndRoleIdsMap
                noCacheAdminRoleIds.forEach(roleId -> noCacheDataAuthedByDataTypeAndRoleIdsMap.put(roleId, dataAuthenticationList));
            }
            if (CollectionUtils.isNotEmpty(noCacheCommonRoleIds)) {
                //非系统管理员，查询所有数据资源
                Map<Long, List<DataAuthentication>> commonDataAuthedByRoleIds = Maps.newHashMap();
                noCacheCommonRoleIds.forEach(roleId -> {
                    commonDataAuthedByRoleIds.put(roleId, Lists.newArrayList());
                });
                List<DataAuthentication> dataAuthenticationList1 = logDataResourceDao.getDataAuthedByRoleIds(accountId, noCacheCommonRoleIds,
                        dataType);
                dataAuthenticationList1.forEach((dataAuthentication) -> {
                    commonDataAuthedByRoleIds.get(dataAuthentication.getRoleId()).add(dataAuthentication);
                });
                Integer authType = multiTypeDataResourceDao.getAuthTypeByDataType(dataType);
                //给非系统管理员赋予authType
                commonDataAuthedByRoleIds.forEach((roleId, dataAuthenticationList) -> {
                    for (DataAuthentication dataAuthentication : dataAuthenticationList) {
                        dataAuthentication.setAuthType(authType);
                    }
                });
                //普通角色，查询角色拥有数据权限，并将其添加到 noCacheDataAuthedByDataTypeAndRoleIdsMap
                noCacheDataAuthedByDataTypeAndRoleIdsMap.putAll(commonDataAuthedByRoleIds);
            }
            //缓存未缓存的角色数据权限
            authCache.setDataAuthedByRoleIds(accountId, dataType, noCacheDataAuthedByDataTypeAndRoleIdsMap);
            noCacheDataAuthedByDataTypeAndRoleIdsMap.values().forEach(allDataAuthenticationList::addAll);
        }
        //合并所有角色数据权限
        this.distinctAndSetAuthDataAuthentications(allDataAuthenticationList, 2);
        //去除空权限
        this.removeEmptyAuth(allDataAuthenticationList);
        return allDataAuthenticationList;
    }
    
    @Override
    public void deleteDataAuthedByRoleIds(Long accountId, List<String> dataTypeList, List<Long> roleIds) {
        authCache.deleteDataAuthedByRoleIds(accountId, dataTypeList, roleIds);
    }
    
    @Override
    public void setDataAuthedByRoleIdsDirty(Long accountId, List<String> dataTypeList) {
        if (DomainConfig.isOpenDomain()) {
            CompletableFuture.runAsync(() -> {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    dataTypeList.forEach(dataType -> authCache.setDataAuthedByRoleIdsDirty(domain.getId(), dataType));
                });
            }, AsyncTaskPool.getTaskExecutor());
        } else {
            dataTypeList.forEach(dataType -> authCache.setDataAuthedByRoleIdsDirty(accountId, dataType));
        }
    }
    
    @Override
    public List<DataAuthentication> getCreatorOtherDataAuthed(Long accountId, Long userId, String dataType) {
        //查询创建者数据权限缓存
        List<DataAuthentication> creatorDataAuthed = authCache.getCreatorDataAuthed(accountId, dataType, userId);
        if (creatorDataAuthed == null) {
            creatorDataAuthed = logDataResourceDao.getCreatorDataAuthed(accountId, userId, dataType);
            for (DataAuthentication dataAuthentication : creatorDataAuthed) {
                dataAuthentication.setMaintenance(Boolean.TRUE);
                dataAuthentication.setRead(Boolean.TRUE);
                dataAuthentication.setAdd(Boolean.TRUE);
                dataAuthentication.setUpdate(Boolean.TRUE);
                dataAuthentication.setDelete(Boolean.TRUE);
            }
            Integer authType = multiTypeDataResourceDao.getAuthTypeByDataType(dataType);
            creatorDataAuthed.forEach(creatorDataAuth -> creatorDataAuth.setAuthType(authType));
            //缓存创建者数据权限
            authCache.setCreatorDataAuthed(accountId, dataType, creatorDataAuthed, userId);
        }
        return creatorDataAuthed;
    }
    
    @Override
    public void deleteCreatorDataAuthed(Long accountId, String dataType, List<Long> userIdList) {
        if (DomainConfig.isOpenDomain()) {
            CompletableFuture.runAsync(() -> {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    authCache.deleteCreatorDataAuthed(domain.getId(), dataType, userIdList);
                });
            }, AsyncTaskPool.getTaskExecutor());
        } else {
            authCache.deleteCreatorDataAuthed(accountId, dataType, userIdList);
        }
        
    }
    
    private void setAllAuth(List<DataAuthentication> dataAuthentications, int type, String dataType) {
        //数据资源权限拓展
        if (StringUtils.isNotEmpty(dataType)) {
            Integer authType = multiTypeDataResourceDao.getAuthTypeByDataType(dataType);
            if (authType != null) {
                for (DataAuthentication dataAuthentication : dataAuthentications) {
                    if (DbConstant.AUTH_TYPE_TWO.equals(authType)) {
                        dataAuthentication.setRead(Boolean.TRUE);
                        dataAuthentication.setAdd(Boolean.TRUE);
                        dataAuthentication.setUpdate(Boolean.TRUE);
                        dataAuthentication.setDelete(Boolean.TRUE);
                    }
                    dataAuthentication.setAuthType(authType);
                }
            }
        }
        if (type == 1) {
            for (DataAuthentication dataAuthentication : dataAuthentications) {
                dataAuthentication.setCurrentMaintenance(Boolean.TRUE);
                dataAuthentication.setCurrentRead(Boolean.TRUE);
                dataAuthentication.setRead(Boolean.TRUE);
                dataAuthentication.setMaintenance(Boolean.TRUE);
            }
        } else {
            for (DataAuthentication dataAuthentication : dataAuthentications) {
                dataAuthentication.setRead(Boolean.TRUE);
                dataAuthentication.setMaintenance(Boolean.TRUE);
            }
        }
    }
    
    private void removeEmptyAuth(List<DataAuthentication> dataAuthentications) {
        Iterator<DataAuthentication> iterator = dataAuthentications.iterator();
        while (iterator.hasNext()) {
            DataAuthentication next = iterator.next();
            if ("0000".equals(next.getAuth())) {
                iterator.remove();
            } else if ("00".equals(next.getAuth())) {
                iterator.remove();
            }
        }
    }
    
    /**
     * @param data
     * @param type 1表示有维护、查看、本层维护、本层查看,2表示只有维护、查看
     * @return
     */
    private void distinctAndSetAuthDataAuthentications(List<DataAuthentication> data, int type) {
        HashMap<String, DataAuthentication> map = Maps.newHashMapWithExpectedSize(data.size());
        Iterator<DataAuthentication> iterator = data.iterator();
        while (iterator.hasNext()) {
            DataAuthentication next = iterator.next();
            String uniqueCode = (StringUtils.isEmpty(next.getParentCode()) ? "" : next.getParentCode()) + StrPool.C_UNDERLINE + next.getCode();
            DataAuthentication last = map.get(uniqueCode);
            if (last == null) {
                map.put(uniqueCode, next);
            } else {
                last.doCombineAuth(next);
                iterator.remove();
            }
        }
        
        for (DataAuthentication dataAuthentication : data) {
            Integer authType = dataAuthentication.getAuthType();
            dataAuthentication.doSetAuth(type, authType);
        }
    }
    
    
}
