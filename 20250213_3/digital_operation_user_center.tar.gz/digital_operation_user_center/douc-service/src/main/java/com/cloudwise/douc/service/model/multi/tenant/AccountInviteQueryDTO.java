package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import java.io.Serializable;

/**
 * @author bradyliu
 * @description: 列表加载、检索、排序请求传输类
 * @date Created in 10:54 2021/7/15.
 */
@Data
public class AccountInviteQueryDTO implements Serializable {
    /**
     * 邮寄状态 只能为 1 待回复 2 已通过 3 拒绝 4 已撤销 5 发送失败 6 已过期
     */
    private Integer status;
    /**
     * 被邀请人邮箱
     */
    @Email(message = IBaseExceptionCode.API_MODEL_EMAIL)
    @Length(max = 64, message = IBaseExceptionCode.API_ACCOUNT_EMAIL_OVER_SIZE)
    private String inviteeEmail;
    /**
     * 时间排序条件 asc/desc
     */
    private String dateSort;
    /**
     * 当前页码
     */
    private Integer current;
    /**
     * 每页条数
     */
    private Integer size;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
