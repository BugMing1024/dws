package com.cloudwise.douc.service.model.watermark;

import com.cloudwise.douc.metadata.activerecord.WatermarkEntity;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 水印的设置
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/11/9 16:51; update at 2023/11/9 16:51
 */
@Data
public class WatermarkSetting extends WatermarkEntity {

    private List<WatermarkField> fields = new ArrayList<>();
}
