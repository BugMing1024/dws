package com.cloudwise.douc.service.dataflow;


/**
 * @author zafir.zhong
 * @description 系统一些配置的获取和保存
 * @date Created in 6:04 下午 2022/3/18.
 */
public interface ISystemSettingDataFlow {

    /**
     * @return boolean true为开启，false为关闭
     * @description 是否开启子租户，会先读取redis，没有再查询数据库
     * - 无参数
     * @author zafir.zhong
     * @date 2022/3/18
     * @time 6:05 下午
     */
    boolean isChildAccountEnable();

    /**
     * @description 把子租户功能打开，会先写数据库再修改redis
     * - 无参数
     * - 无返回
     * @author zafir.zhong
     * @date 2022/3/18
     * @time 6:05 下午
     */
    void enableChildAccount();
}
