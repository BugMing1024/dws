package com.cloudwise.douc.service.util;

import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.metadata.model.user.UserListResponseObject;
import org.apache.commons.lang3.StringUtils;

/**
 * @author ethan.du
 * @version v1.0
 * @date 2024/4/22 17:35
 */

public class UserUtil {
    
    public static void getResult(UserListResponseObject userListResponseObject, String name, int begin, int end) {
        if (ConfigUtils.getBoolean("mobile.desensitization.enabled", true)) {
            String frontName = name.substring(0, begin) + "****" + name.substring(end, name.length());
            userListResponseObject.setMobile(frontName);
        }
    }
    
    public static String getDesensitizationMobile(String mobile) {
        if (ConfigUtils.getBoolean("mobile.desensitization.enabled", true) && StringUtils.isNotEmpty(mobile)) {
            if (mobile.length() >= 11) {
                return mobile.substring(0, 3) + "****" + mobile.substring(7, mobile.length());
            } else if (mobile.length() == 8) {
                return mobile.substring(0, 4) + "****" + mobile.substring(8, mobile.length());
            } else if (mobile.length() >= 4) {
                return mobile.substring(0, mobile.length() - 4) + "****";
            } else {
                return "****";
            }
        } else {
            return mobile;
        }
    }
}
