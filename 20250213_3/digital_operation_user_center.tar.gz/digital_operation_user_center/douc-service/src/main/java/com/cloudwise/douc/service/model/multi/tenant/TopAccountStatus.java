package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.multi.tenant.AccountModuleStatusWithName;
import lombok.Data;

import java.util.List;

/**
 * @author zafir.zhong
 * @description
 * @date Created in 11:02 2022/6/8.
 */
@Data
public class TopAccountStatus {

    private Integer status;
    private List<AccountModuleStatusWithName> module;
}
