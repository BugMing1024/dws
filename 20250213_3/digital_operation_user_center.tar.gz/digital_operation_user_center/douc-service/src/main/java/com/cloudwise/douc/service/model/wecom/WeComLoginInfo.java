package com.cloudwise.douc.service.model.wecom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 企业微信登录信息
 *
 * @author maker.wang
 * @date 2022-05-24 11:15
 **/
@Data
@ApiModel("企业微信登录信息")
public class WeComLoginInfo implements Serializable {
    private static final long serialVersionUID = 2869786562183032724L;

    @ApiModelProperty("租户id")
    private Long accountId;

    @ApiModelProperty("企业微信code")
    private String code;

    @ApiModelProperty("企业微信应用id")
    private String appId;

    @ApiModelProperty("TGT")
    private String tgtStr;

    @ApiModelProperty("首页")
    private String service;

    private String restapi;

    private String userIp;
    private String refer;
    private String userAgent;

}
