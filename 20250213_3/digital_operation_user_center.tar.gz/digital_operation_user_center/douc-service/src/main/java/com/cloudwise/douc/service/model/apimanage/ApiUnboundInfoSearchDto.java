package com.cloudwise.douc.service.model.apimanage;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @Author: damon.fu
 * @Date: 2021/08/30 15:41
 * @Description:
 */
@Data
public class ApiUnboundInfoSearchDto implements Serializable {
    private static final long serialVersionUID = 1L;
    @NotNull(message = IBaseExceptionCode.APP_ID_IS_NOT_NULL)
    private String appId;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;

    private String name;

    private List<String> apiCodes;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
