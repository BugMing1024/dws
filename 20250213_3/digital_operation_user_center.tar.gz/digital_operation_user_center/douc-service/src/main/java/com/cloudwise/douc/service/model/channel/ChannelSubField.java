package com.cloudwise.douc.service.model.channel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

/**
 * @author zafir.zhong
 * @description
 * @date Created in 11:13 2022/11/2.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelSubField {

    private Integer type;
    private ChannelNumLimit limitLength;
    private List<ChannelFieldConfig> fields;

}
