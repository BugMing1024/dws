package com.cloudwise.douc.service.model.wecom;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComExternalAttr implements Serializable {


    private String name;

    @JsonProperty(value = "text")
    private WeComTextvalue weComTextvalue;

    @JsonProperty(value = "type")
    private Integer type;

}
