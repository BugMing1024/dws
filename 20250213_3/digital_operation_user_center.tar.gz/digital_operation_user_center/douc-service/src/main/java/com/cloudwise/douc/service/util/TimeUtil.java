package com.cloudwise.douc.service.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/*
 *时间工具类
 *@return:
 *@author: bernie
 *@date: 2020/3/17 上午10:49
 */
@Slf4j
public class TimeUtil {

    /**
     * 为开始时间加上目标时间
     *
     * @param startTime  起始时间
     * @param targetTime 需要加上的目标时间，写发示例 1h (1小时) 1m (1分钟)
     * @return: java.util.Date
     * @author: bernie
     * @date: 2020/3/17 上午11:08
     */
    public static Date addTime(Date startTime, String targetTime) {

        //解析增加时间单位
        int unit;
        String lockTimeUnit = targetTime.substring(targetTime.length() - 1);
        switch (lockTimeUnit.toLowerCase()) {
            case "m":
                unit = Calendar.MINUTE;
                break;
            case "h":
                unit = Calendar.HOUR;
                break;
            case "d":
                unit = Calendar.DATE;
                break;
            case "y":
                unit = Calendar.YEAR;
                break;
            default:
                unit = Calendar.HOUR;
                break;
        }

        //解析增加时长
        int addTime = 1;
        try {
            addTime = Integer.parseInt(targetTime.substring(0, targetTime.length() - 1));
        } catch (NumberFormatException ex) {
            log.info("Parseing Date Exception : time format error{}", ex.getMessage(), ex);
        }

        //获得锁定时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startTime);
        calendar.add(unit, addTime);

        return calendar.getTime();
    }

    /**
     * 时间间隔解析为中文
     */
    public static String timeUnitParse(String targetTime) {

        //解析增加时间单位
        String unit;
        String lockTimeUnit = targetTime.substring(targetTime.length() - 1);
        switch (lockTimeUnit.toLowerCase()) {
            case "m":
                unit = "min";
                break;
            case "h":
                unit = "hour";
                break;
            case "d":
                unit = "day";
                break;
            case "y":
                unit = "year";
                break;
            default:
                unit = "hour";
                break;
        }

        return targetTime.substring(0, targetTime.length() - 1) + unit;
    }

    /**
     * 为开始时间减去目标时间
     *
     * @param startTime, targetTime
     * @return: java.util.Date
     * @author: bernie
     * @date: 2020/3/22 上午3:28
     */
    public static Date subTime(Date startTime, String targetTime) {

        //解析增加时间单位
        int unit;
        String lockTimeUnit = targetTime.substring(targetTime.length() - 1);
        switch (lockTimeUnit.toLowerCase()) {
            case "m":
                unit = Calendar.MINUTE;
                break;
            case "h":
                unit = Calendar.HOUR;
                break;
            case "d":
                unit = Calendar.DATE;
                break;
            case "y":
                unit = Calendar.YEAR;
                break;
            default:
                unit = Calendar.HOUR;
                break;
        }

        //解析增加时长
        int addTime = 1;
        try {
            addTime = Integer.parseInt(targetTime.substring(0, targetTime.length() - 1));
        } catch (NumberFormatException ex) {
            log.info("Parse Date Exception : time format error", ex);
        }

        //获得锁定时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startTime);
        calendar.add(unit, -addTime);

        return calendar.getTime();
    }

    //根据传递的建议时间单位字符返回对应的文字
    public static String getTimeUnitToCN(String dateUnitStr) {
        String unit = "";
        switch (dateUnitStr.toLowerCase()) {
            case "m":
                unit = "min";
                break;
            case "h":
                unit = "hour";
                break;
            case "d":
                unit = "day";
                break;
            case "y":
                unit = "year";
                break;
            default:
                unit = "hour";
                break;
        }
        return unit;
    }

    public static TimeUnit getTimeUnit(String dateUnitStr) {
        TimeUnit unit;
        switch (dateUnitStr.toLowerCase()) {
            case "m":
                unit = TimeUnit.MINUTES;
                break;
            case "h":
                unit = TimeUnit.HOURS;
                break;
            case "d":
                unit = TimeUnit.DAYS;
                break;
            default:
                unit = TimeUnit.MINUTES;
                break;
        }
        return unit;
    }

    public static Date utcToLocal(String utcTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date utcDate = new Date();
        try {
            utcDate = sdf.parse(utcTime);
        } catch (ParseException e) {
            log.error(e.getMessage());
        }
        sdf.setTimeZone(TimeZone.getDefault());
        Date locatlDate = null;
        String localTime = sdf.format(utcDate.getTime());
        try {
            locatlDate = sdf.parse(localTime);
        } catch (ParseException e) {
            log.error(e.getMessage());
        }
        return locatlDate;
    }


    public static String localToUtc(String localTime) {
        String utcTime = "";
        if (StringUtils.isNotEmpty(localTime)) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            sdf.setTimeZone(TimeZone.getDefault());
            Date localDate = new Date();
            try {
                localDate = sdf.parse(localTime);
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            utcTime = sdf.format(localDate.getTime());
        }
        return utcTime;
    }

}