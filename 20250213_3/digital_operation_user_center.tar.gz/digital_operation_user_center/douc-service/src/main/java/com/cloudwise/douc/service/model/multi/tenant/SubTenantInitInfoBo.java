package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.commons.enums.MultiAccountStatusEnum;
import com.cloudwise.douc.commons.enums.MultiAccountTypeEnum;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 后台传过来的租户信息
 *
 * @author maker.wang
 * @date 2021-06-30 11:46
 **/
@Data
public class SubTenantInitInfoBo implements Serializable {

    private static final long serialVersionUID = 4270910278666964736L;

    /**
     * 初始化默认值
     *
     * @author maker.wang
     * @date 2021-06-30 14:03
     **/
    public SubTenantInitInfoBo() {
        this.isTop = MultiAccountTypeEnum.SUB_ACCOUNT.getCode();
        this.status = MultiAccountStatusEnum.NORMAL.getCode();
        this.parentId = 0L;
        this.createUserId = 0L;
    }

    /**
     * 租户名称
     **/
    @NotBlank(message = IBaseExceptionCode.API_ACCOUNT_NAME_NOT_BLANK)
    private String name;

    /**
     * 上级租户id
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_PARENT_ID_NOT_BLANK)
    private Long parentId;

    /**
     * 上级租户level
     **/
    private String parentLevel;

    /**
     * 顶级租户id
     **/
    private Long topId;

    /**
     * 1顶级租户，2非顶级租户 默认2
     **/
    private Integer isTop;

    /**
     * 1正常、2暂停（租户下用户无法登录,可删除）、3已删除(定时清除改租户相关的数据)
     **/
    private Integer status;

    /**
     * 创建人
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_CREATE_USER_NOT_BLANK)
    private Long createUserId;

    /**
     * 子租户管理员id
     **/
    private Long innerAdminUserId;

    /**
     * 子租户管理员姓名
     **/
    private String innerAdminUserName;

    /**
     * 子租户管理员别名
     **/
    private String innerAdminUserAlias;

    /**
     * 用于租户关联其他信息如部门的编码
     */
    private String code;
    
    /**
     * 租户可见范围 1只能看自己，2可看所有租户，3可看指定租户（顶级租户为2）
     */
    private Integer visibleScope;
    
    /**
     * 企业id
     */
    private Long enterpriseId;
    
    private String innerLanguage;

}
