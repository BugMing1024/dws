package com.cloudwise.douc.service.model.simulation;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 试用用户列表
 *
 * @author maker.wang
 * @date 2022-08-09 15:53
 **/
@Data
@ApiModel("试用用户列表入参")
public class TrialUserPageBO implements Serializable {
    private static final long serialVersionUID = -6105506944969230430L;

    /**
     * 默认分页大小、当前页
     **/
    private static final Integer DEFAULT_PAGE_SIZE = 30;
    private static final Integer DEFAULT_CURRENT_PAGE_NO = 1;

    public TrialUserPageBO() {
        this.current = DEFAULT_PAGE_SIZE;
        this.size = DEFAULT_PAGE_SIZE;
    }

    @ApiModelProperty(value = "页码")
    private Integer current;

    @ApiModelProperty(value = "每页条数")
    private Integer size;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
