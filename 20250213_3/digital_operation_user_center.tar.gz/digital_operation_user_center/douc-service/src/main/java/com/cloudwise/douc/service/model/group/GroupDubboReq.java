package com.cloudwise.douc.service.model.group;


import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author bernie.wang
 * @description:
 * @date Created in 12:15 AM 2021/7/3.
 */
@Data
public class GroupDubboReq {
    @NotNull(message = IBaseExceptionCode.API_GROUP_ID_NOT_BLANK)
    private Long groupId;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    private Long userId;
    @NotNull(message = IBaseExceptionCode.API_GROUP_NAME_NOT_BLANK)
    private String groupName;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;
    @ApiModelProperty(value = "选填    all全部用户组  internal 或null 或“” 内部用户组 ")
    private String groupScope;
    @ApiModelProperty(value = "非必填   传的话查当前groupID或者是level中包含groupID的用户组")
    private Long searchGroupId;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
