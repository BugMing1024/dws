package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.metadata.model.user.User;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @author zhangmengyang
 */
@Builder
@Data
public class IdentityUserResp {

    private List<User> userList;

    private IdentityUserUpdateField identityUserUpdateField;
}
