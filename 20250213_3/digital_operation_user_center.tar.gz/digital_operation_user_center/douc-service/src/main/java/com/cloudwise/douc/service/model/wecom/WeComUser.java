package com.cloudwise.douc.service.model.wecom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties
public class WeComUser implements Serializable {

    @JsonProperty(value = "userid")
    private String userid;
    @JsonProperty(value = "name")
    private String name;
    @JsonProperty(value = "department")
    private List<Long> department;
    @JsonProperty(value = "position")
    private String position;
    @JsonProperty(value = "mobile")
    private String mobile;
    @JsonProperty(value = "gender")
    private Integer gender;
    @JsonProperty(value = "email")
    private String email;
    @JsonProperty(value = "avatar")
    private String avatar;
    @JsonProperty(value = "status")
    private Integer status;
    @JsonProperty(value = "enable")
    private Integer enable;
    @JsonProperty(value = "isleader")
    private Integer isleader;
    @JsonProperty(value = "extattr")
    private WeComExtattr extattr;
    @JsonProperty(value = "hide_mobile")
    // CHECKSTYLE:OFF
    private Integer hide_mobile;
    // CHECKSTYLE:ON
    @JsonProperty(value = "telephone")
    private String telephone;
    @JsonProperty(value = "order")
    private List<Long> order;
    @JsonProperty(value = "external_profile")
    private WeComExternalProfile weComExternalProfile;
    @JsonProperty(value = "main_department")
    private Long mainDepartment;
    @JsonProperty(value = "qr_code")
    // CHECKSTYLE:OFF
    private String qr_code;
    // CHECKSTYLE:ON
    @JsonProperty(value = "alias")
    private String alias;
    @JsonProperty(value = "is_leader_in_dept")
    private List<Long> isLeaderInDept;
    @JsonProperty(value = "address")
    private String address;
    @JsonProperty(value = "thumb_avatar")
    private String thumbAvater;
    @JsonProperty(value = "direct_leader")
    private List<String> directLeader;
    // CHECKSTYLE:OFF
    @JsonProperty(value = "biz_mail")
    private String biz_mail;
    @JsonProperty(value = "ChangeType")
    private String ChangeType;
    // CHECKSTYLE:ON
}
