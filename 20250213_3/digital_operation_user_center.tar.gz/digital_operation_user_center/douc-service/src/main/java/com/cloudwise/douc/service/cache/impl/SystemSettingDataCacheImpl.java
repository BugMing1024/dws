package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.service.cache.ISystemSettingDataCache;
import com.cloudwise.douc.service.constants.data.AccountConstants;
import org.springframework.stereotype.Component;

/**
 * 系统设置缓存的操作类
 *
 * @author ：zafir zhong
 * @version : 1.0.0
 * @date ：Created in 2022/3/17 3:30 下午
 * @modified By：
 */
@Component
public class SystemSettingDataCacheImpl implements ISystemSettingDataCache {


    @Override
    public Boolean getChildAccountEnable() {
        return RedisTools.getByte(AccountConstants.Key.ACCOUNT_PRE + AccountConstants.Key.CHILD_ACCOUNT_ENABLE_SETTING, Boolean.class);
    }

    @Override
    public boolean saveChildAccountEnable(boolean enabled) {
        return RedisTools.setByteWithTime(AccountConstants.Key.ACCOUNT_PRE + AccountConstants.Key.CHILD_ACCOUNT_ENABLE_SETTING, enabled, AccountConstants.Key.CACHE_SETTING_TIMEOUT);
    }
}
