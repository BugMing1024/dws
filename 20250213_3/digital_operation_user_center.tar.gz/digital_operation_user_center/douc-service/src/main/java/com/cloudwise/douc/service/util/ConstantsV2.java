package com.cloudwise.douc.service.util;

/**
 * @author KenLiang
 * @description:
 * @date Created in 3:33 PM 2021/5/20.
 */
public class ConstantsV2 {


    //部门常量-----start

    public static final String DEPARTMENT_FIRST_LEVEL = "0";

    public static final String TOP_DEPARTMENT_ID = "0";
    // 用于ExtendConfEntity扩展类dataType比较  selected 表示 拓展项是字典
    public static final String SELECTED = "selected";

    public static final String DEPARTMENT_INTEGER_STR = "integer";
    public static final String DEPARTMENT_NUMBER_STR = "number";

    // 用于String.valueOf之后是否为null
    public static final String DEPARTMENT_NULL_STR = "null";
    /**
     * 字典code
     */
    public static final String DIC_CODE_COLUMN = "code";


    //部门常量-----end


    //扩展字段常量----start

    public static final String EXTEND_VALUE_KEY = "value";
    public static final String EXTEND_ALIAS_KEY = "alias";

    public static final String EXTEND_SELECTEDNAME_KEY = "selectedName";
    //扩展字段常量----end
    //时区字典code
    public static final String TIME_ZONE_CODE = "TIME_ZONE_CODE";
    //国家字典code
    public static final String COUNTY_CODE = "COUNTY_CODE";

}
