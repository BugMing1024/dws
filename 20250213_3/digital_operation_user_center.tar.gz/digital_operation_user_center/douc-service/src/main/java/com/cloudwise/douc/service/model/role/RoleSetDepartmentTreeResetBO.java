package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.metadata.model.department.DepartmentPO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 角色配置组织机构 重新配置组织机构入参
 *
 * @author maker.wang
 * @date 2022-03-10 09:40
 **/
@Data
@ApiModel("角色配置组织机构 重新配置组织机构入参")
public class RoleSetDepartmentTreeResetBO implements Serializable {
    private static final long serialVersionUID = 5843058342985432909L;

    @ApiModelProperty("角色id")
    private Long roleId;

    @ApiModelProperty("选中部门列表")
    private List<DepartmentPO> addUpdateList;

    @ApiModelProperty("反选部门列表")
    private List<Long> removeList;


}
