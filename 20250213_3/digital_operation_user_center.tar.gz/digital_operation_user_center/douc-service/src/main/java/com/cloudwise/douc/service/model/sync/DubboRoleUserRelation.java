package com.cloudwise.douc.service.model.sync;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2022-7-14.
 *
 * @author skiya
 */
@Data
public class DubboRoleUserRelation implements Serializable {

    private static final long serialVersionUID = 4111868967890641767L;

    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_TOP_ID_NULL)
    private Long accountId;

    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    private Long userId;

    private List<String> userCodes = new ArrayList<>();

    @NotBlank(message = IBaseExceptionCode.API_ROLE_ID_NULL)
    private String roleCode;
}
