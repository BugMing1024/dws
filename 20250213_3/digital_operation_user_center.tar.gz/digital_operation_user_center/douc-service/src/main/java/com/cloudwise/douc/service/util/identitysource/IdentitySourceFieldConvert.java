package com.cloudwise.douc.service.util.identitysource;

import cn.hutool.core.text.StrPool;
import com.alibaba.nacos.common.utils.CollectionUtils;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IIdentitySourceDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.model.department.DepartMentInfo;
import com.cloudwise.douc.metadata.model.department.Department;
import com.cloudwise.douc.metadata.model.department.DepartmentUserRelation;
import com.cloudwise.douc.metadata.model.identitysource.IdentityFiledMapping;
import com.cloudwise.douc.metadata.model.user.User;
import com.cloudwise.douc.service.model.dingding.DingDingDepartment;
import com.cloudwise.douc.service.model.dingding.DingDingUser;
import com.cloudwise.douc.service.model.feishu.FeishuUser;
import com.cloudwise.douc.service.model.identitysource.IdentityTypeEnum;
import com.cloudwise.douc.service.model.identitysource.IdentityUserUpdateField;
import com.cloudwise.douc.service.service.IIdentitySourceExternalService;
import com.cloudwise.douc.service.service.impl.FeishuExternalServiceImpl;
import com.cloudwise.douc.service.util.Constant;
import com.cloudwise.douc.service.util.ObjectToMapUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lark.oapi.service.contact.v3.model.CustomAttr;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class IdentitySourceFieldConvert {
    
    private static final String DOUC_BASE_FILED_STRING = "name,user_alias,mobile,phone,email,department_user,user_leader_id,dingtalk_account,feishu_account,weixinwork_account,position";
    
    private static final String NAME = "name";
    
    private static final String USER_ALIAS = "user_alias";
    
    private static final String MOBILE = "mobile";
    
    private static final String EMAIL = "email";
    
    private static final String PHONE = "phone";
    
    private static final String DINGTALK_ACCOUNT = "dingtalk_account";
    
    private static final String WEIXINWORK_ACCOUNT = "weixinwork_account";
    
    private static final String FEISHU_ACCOUNT = "feishu_account";
    
    private static final String WXPUSH_ACCOUNT = "wxpush_account";
    
    private static final String POSITION = "position";
    
    private List<String> doucBaseFiledForUpdateList = Arrays.asList("departmentUserRelations", "status");
    
    /**
     * douc中所有的基础字段
     */
    private Set<String> doucBaseFiledList = new HashSet<>(Arrays.asList(DOUC_BASE_FILED_STRING.split(StrPool.COMMA)));
    
    @Autowired
    private IIdentitySourceDao iIdentitySourceDao;
    
    @Autowired
    private IDepartmentDao departmentDao;
    
    @Autowired
    private IUserDao userDao;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Resource(name = "feishuExternalService")
    private IIdentitySourceExternalService feishuExternalService;
    
    //组织数据转换
    public void dingDingDepartmentConvert(List<DingDingDepartment> dingDingDepartmentList,
            List<Department> departmentList, Long identitySourceId, Integer status,
            Boolean isSyncDepartmentManagement) {
        for (DingDingDepartment dingDingDepartment : dingDingDepartmentList) {
            if (dingDingDepartment == null) {
                log.error("get null dingDingDepartment, list size {}", dingDingDepartmentList.size());
                continue;
            }
            Department department = new Department();
            department.setCode(this.getDoucCodeByDingDing(dingDingDepartment.getDepartmentId(), identitySourceId));
            department.setName(dingDingDepartment.getName());
            department.setParentCode(this.getDoucCodeByDingDing(dingDingDepartment.getParentId(), identitySourceId));
            department.setStatus(status);
            List<String> managementUserCodeList = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(dingDingDepartment.getDeptManagerUseridList())
                    && isSyncDepartmentManagement) {
                for (String managementUserId : dingDingDepartment.getDeptManagerUseridList()) {
                    managementUserCodeList.add(this.getDoucCodeByDingDing(managementUserId, identitySourceId));
                }
                department.setPersonChargeUserCodeList(managementUserCodeList);
            }
            departmentList.add(department);
        }
    }
    
    /**
     * 转换前预处理 对于历史同步过的用户 校验用户主部门 主部门存在设置同步类型为新增
     *
     * @param dingDingUserList         钉钉获取的所有用户列表
     * @param accountId                租户id
     * @param identitySourceId         身份源id
     * @param dingDingDepartmentIdList 钉钉部门列表
     */
    public void prepareDingDingUserConvert(List<DingDingUser> dingDingUserList, Long accountId, Long identitySourceId,
            List<String> dingDingDepartmentIdList) {
        List<String> dingdingAllDepartmentCodeList = dingDingDepartmentIdList.stream()
                .map(m -> this.getDoucCodeByDingDing(m, identitySourceId)).collect(Collectors.toList());
        List<String> dingDingUserCodeList = dingDingUserList.stream()
                .map(m -> this.getDoucCodeByDingDing(m.getUserid(), identitySourceId)).collect(Collectors.toList());
        List<User> userInfoByUserCodeList = userDao.getUserInfoByUserCodeList(accountId, dingDingUserCodeList);
        if (CollectionUtils.isNotEmpty(userInfoByUserCodeList)) {
            List<String> alreadyUserCodeList = userInfoByUserCodeList.stream().map(User::getCode)
                    .collect(Collectors.toList());
            dingDingUserList.stream().filter(f -> {
                return alreadyUserCodeList.contains(this.getDoucCodeByDingDing(f.getUserid(), identitySourceId));
            }).forEach(f -> {
                String oldDepartmentCode = userDao.getMainDepartmentCodeByUserCode(
                        this.getDoucCodeByDingDing(f.getUserid(), identitySourceId), accountId);
                f.setOldDepartmentCode(oldDepartmentCode);
                List<String> userDepartmentCodeList = f.getDeptIdList().stream()
                        .map(m -> this.getDoucCodeByDingDing(m, identitySourceId)).collect(Collectors.toList());
                if (dingdingAllDepartmentCodeList.contains(oldDepartmentCode) && userDepartmentCodeList.contains(
                        oldDepartmentCode)) {
                    f.setSyncDataType(1);
                }
            });
        }
        
    }
    
    
    /**
     * 用户数据转换
     *
     * @param dingDingUserList         钉钉用户列表
     * @param userList                 该身份源douc已经同步的用户列表
     * @param identitySourceId         身份源id
     * @param accountId                租户id
     * @param isSyncDepartment         是否同步部门
     * @param departmentParentId       同步到douc选择的部门
     * @param dingDingDepartmentIdList 钉钉部门id列表
     * @param status                   用户状态
     * @param feishuDepartmentCodeList 钉钉部门code列表
     * @return 转换结果
     */
    public IdentityUserUpdateField dingDingUserConvert(List<DingDingUser> dingDingUserList, List<User> userList,
            Long identitySourceId, Long accountId, Boolean isSyncDepartment, Long departmentParentId,
            List<String> dingDingDepartmentIdList, Integer status, List<String> feishuDepartmentCodeList) {
        IdentityUserUpdateField identityUserUpdateField = new IdentityUserUpdateField();
        List<IdentityFiledMapping> identityFiledMappingList = iIdentitySourceDao.getOpenFiledMappingByIdentitySourceId(
                identitySourceId, accountId, 2);
        Map<String, String> localAndExternalFiledMap;
        try {
            localAndExternalFiledMap = identityFiledMappingList.stream().collect(
                    Collectors.toMap(IdentityFiledMapping::getLocalAttr, IdentityFiledMapping::getExternalAttr));
        } catch (Exception e) {
            log.error("获取配置的字段异常：", e);
            return identityUserUpdateField;
        }
        List<String> identitySourceBaseFields = identityFiledMappingList.stream()
                .map(IdentityFiledMapping::getLocalAttr).collect(Collectors.toList());
        List<String> realUpdateBaseFieldList = new ArrayList<>(doucBaseFiledForUpdateList);
        for (String baseField : identitySourceBaseFields) {
            if ("name".equals(baseField)) {
                realUpdateBaseFieldList.add("name");
            }
            if ("mobile".equals(baseField)) {
                realUpdateBaseFieldList.add("mobile");
            }
            if ("phone".equals(baseField)) {
                realUpdateBaseFieldList.add("phone");
            }
            if ("user_alias".equals(baseField)) {
                realUpdateBaseFieldList.add("userAlias");
            }
            if ("dingtalk_account".equals(baseField)) {
                realUpdateBaseFieldList.add("dingtalkAccount");
            }
            if ("weixinwork_account".equals(baseField)) {
                realUpdateBaseFieldList.add("weixinworkAccount");
            }
            if ("email".equals(baseField)) {
                realUpdateBaseFieldList.add("email");
            }
            if ("position".equals(baseField)) {
                realUpdateBaseFieldList.add("position");
            }
        }
        List<String> extendFieldList = new ArrayList<>();
        for (IdentityFiledMapping identityFiledMapping : identityFiledMappingList) {
            if (!doucBaseFiledList.contains(identityFiledMapping.getLocalAttr())) {
                if (!realUpdateBaseFieldList.contains("extend")) {
                    realUpdateBaseFieldList.add("extend");
                }
                if (!extendFieldList.contains(identityFiledMapping.getLocalAttr())) {
                    extendFieldList.add(identityFiledMapping.getLocalAttr());
                }
            }
        }

        Set<String> extarnameList = new HashSet<>();
        for (DingDingUser dingDingUser : dingDingUserList) {
            extarnameList.clear();
            User user = new User();
            //内置的匹配字段-不能动的字段
            user.setUserLeaderCodes(Collections.singletonList(
                    this.getDoucCodeByDingDing(dingDingUser.getManagerUserId(), identitySourceId)));
            List<DepartmentUserRelation> departmentUserRelationList = new ArrayList<>();
            if (!isSyncDepartment) {
                List<Long> departmentIdList = new ArrayList<>();
                departmentIdList.add(departmentParentId);
                List<DepartMentInfo> departmentInfoByIds = departmentDao.getDepartmentInfoByIds(accountId,
                        departmentIdList);
                if (CollectionUtils.isNotEmpty(departmentInfoByIds)) {
                    DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                    departmentUserRelation.setDepartmentCode(departmentInfoByIds.get(0).getCode());
                    departmentUserRelation.setDepartmentId(departmentInfoByIds.get(0).getId());
                    departmentUserRelation.setIsMain(1);
                    if (MapUtils.isNotEmpty(localAndExternalFiledMap) && localAndExternalFiledMap.containsKey(
                            POSITION)) {
                        departmentUserRelation.setPosition(dingDingUser.getTitle());
                    }
                    departmentUserRelationList.add(departmentUserRelation);
                }
            } else {
                List<String> dingdingAllDepartmentCodeList = feishuDepartmentCodeList;
                if (CollectionUtils.isEmpty(feishuDepartmentCodeList)) {
                    dingdingAllDepartmentCodeList = dingDingDepartmentIdList.stream()
                            .map(m -> this.getDoucCodeByDingDing(m, identitySourceId)).collect(Collectors.toList());
                }
                List<String> userDepartmentCodeList = dingDingUser.getDeptIdList().stream()
                        .map(f -> this.getDoucCodeByDingDing(f, identitySourceId)).collect(Collectors.toList());
                List<String> endDepartmentCodeList = new ArrayList<>();
                for (String userDepartmentCode : userDepartmentCodeList) {
                    if (dingdingAllDepartmentCodeList.contains(userDepartmentCode)) {
                        endDepartmentCodeList.add(userDepartmentCode);
                    }
                }
                if (null == dingDingUser.getSyncDataType()) {
                    if (CollectionUtils.isNotEmpty(endDepartmentCodeList)) {
                        for (int i = 0; i < endDepartmentCodeList.size(); i++) {
                            DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                            departmentUserRelation.setDepartmentCode(endDepartmentCodeList.get(i));
                            departmentUserRelation.setAccountId(accountId);
                            if (i == 0) {
                                if (MapUtils.isNotEmpty(localAndExternalFiledMap)
                                        && localAndExternalFiledMap.containsKey(POSITION)) {
                                    departmentUserRelation.setPosition(dingDingUser.getTitle());
                                }
                                departmentUserRelation.setIsMain(1);
                            }
                            departmentUserRelationList.add(departmentUserRelation);
                        }
                    }
                } else {
                    endDepartmentCodeList.remove(dingDingUser.getOldDepartmentCode());
                    DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                    departmentUserRelation.setDepartmentCode(dingDingUser.getOldDepartmentCode());
                    departmentUserRelation.setAccountId(accountId);
                    if (MapUtils.isNotEmpty(localAndExternalFiledMap) && localAndExternalFiledMap.containsKey(
                            POSITION)) {
                        departmentUserRelation.setPosition(dingDingUser.getTitle());
                    }
                    departmentUserRelationList.add(departmentUserRelation);
                    departmentUserRelation.setIsMain(1);
                    for (String departmentCode : endDepartmentCodeList) {
                        DepartmentUserRelation departmentUserRelation1 = new DepartmentUserRelation();
                        departmentUserRelation1.setDepartmentCode(departmentCode);
                        departmentUserRelation1.setAccountId(accountId);
                        departmentUserRelationList.add(departmentUserRelation1);
                    }
                }
            }
            user.setDepartmentUserRelations(departmentUserRelationList);
            //内置的匹配字段-可以修改的字段 可能配置钉钉中的所有字段（钉钉自带字段，拓展字段）
            //钉钉中内部拓展字段的名称-值 的map
            Map<String, String> dingDingUserMap = new HashMap<>();
            Map<String, String> dingdingExtenNameAndValueMap = new HashMap<>();
            try {
                //钉钉中所有拓展字段名称
                if (StringUtils.isNotBlank(dingDingUser.getExtension())) {
                    dingdingExtenNameAndValueMap = objectMapper.readValue(dingDingUser.getExtension(), Map.class);
                    extarnameList = dingdingExtenNameAndValueMap.keySet();
                }
                //钉钉中所有自带字段-值 map
                dingDingUserMap = ObjectToMapUtil.convert(dingDingUser);
            } catch (Exception e) {
                log.error("java实体转map异常:", e);
            }
            
            //姓名匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(NAME))) {
                user.setName(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(NAME)));
            } else {
                user.setName(dingDingUserMap.get(localAndExternalFiledMap.get(NAME)));
            }
            //用户名匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(USER_ALIAS))) {
                user.setUserAlias(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            } else {
                user.setUserAlias(dingDingUserMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            }
            //手机号匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(MOBILE))) {
                user.setMobile(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(MOBILE)));
            } else {
                user.setMobile(dingDingUserMap.get(localAndExternalFiledMap.get(MOBILE)));
            }
            //邮箱匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(EMAIL))) {
                user.setEmail(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(EMAIL)));
            } else {
                user.setEmail(dingDingUserMap.get(localAndExternalFiledMap.get(EMAIL)));
            }
            //座机匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(PHONE))) {
                user.setPhone(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(PHONE)));
            } else {
                user.setPhone(dingDingUserMap.get(localAndExternalFiledMap.get(PHONE)));
            }
            //钉钉账号匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(DINGTALK_ACCOUNT))) {
                user.setDingtalkAccount(
                        dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(DINGTALK_ACCOUNT)));
            } else {
                user.setDingtalkAccount(dingDingUserMap.get(localAndExternalFiledMap.get(DINGTALK_ACCOUNT)));
            }
            //企业微信账号匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT))) {
                user.setWeixinworkAccount(
                        dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT)));
            } else {
                user.setWeixinworkAccount(dingDingUserMap.get(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT)));
            }
            //企业飞书账号匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(FEISHU_ACCOUNT))) {
                user.setFeishuAccount(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            } else {
                user.setFeishuAccount(dingDingUserMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            }
            //微信服务号账号匹配
            if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(WXPUSH_ACCOUNT))) {
                user.setWxpushAccount(dingdingExtenNameAndValueMap.get(localAndExternalFiledMap.get(WXPUSH_ACCOUNT)));
            } else {
                user.setWxpushAccount(dingDingUserMap.get(localAndExternalFiledMap.get(WXPUSH_ACCOUNT)));
            }
            List<Map<String, Object>> extendFields = new ArrayList<>();
            for (IdentityFiledMapping identityFiledMapping : identityFiledMappingList) {
                // 用户自定义的匹配字段-douc的拓展字段
                if (!doucBaseFiledList.contains(identityFiledMapping.getLocalAttr())) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("alias", identityFiledMapping.getLocalAttr());
                    if (MapUtils.isNotEmpty(dingdingExtenNameAndValueMap) && extarnameList.contains(
                            identityFiledMapping.getExternalAttr())) {
                        map.put("value", dingdingExtenNameAndValueMap.get(identityFiledMapping.getExternalAttr()));
                    } else {
                        map.put("value", dingDingUserMap.get(identityFiledMapping.getExternalAttr()));
                    }
                    extendFields.add(map);
                }
            }
            user.setExtend(extendFields);
            user.setTopAccountId(accountId);
            user.setIdentitySourceId(identitySourceId);
            user.setCode(getDoucCodeByDingDing(dingDingUser.getUserid(), identitySourceId));
            user.setImportType(5);
            user.setStatus(status);
            userList.add(user);
        }
        identityUserUpdateField.setBaseFieldList(realUpdateBaseFieldList);
        identityUserUpdateField.setExtendFieldList(extendFieldList);
        return identityUserUpdateField;
    }
    
    public String getDoucCodeByDingDing(String code, Long identitySourceId) {
        return IdentityTypeEnum.dingding.name() + StrPool.UNDERLINE + identitySourceId + StrPool.UNDERLINE + code;
    }
    
    /**
     * 转换前预处理 对于历史同步过的用户 校验用户主部门 主部门存在设置同步类型为新增
     *
     * @param users                  钉钉获取的所有用户列表
     * @param accountId              租户id
     * @param identitySourceId       身份源id
     * @param feishuDepartmentIdList 钉钉部门列表
     */
    public List<FeishuUser> prepareFeishuUserConvert(List<com.lark.oapi.service.contact.v3.model.User> users,
            Long accountId, Long identitySourceId, List<String> feishuDepartmentIdList) {
        List<FeishuUser> feishuUsers = new ArrayList<>(users.size());
        users.forEach(user -> {
            FeishuUser feishuUser = FeishuUser.builder().user(user).build();
            feishuUsers.add(feishuUser);
        });
        List<String> feishuAllDepartmentCodeList = feishuDepartmentIdList.stream()
                .map(m -> this.getDoucCodeByFeishu(m, identitySourceId)).collect(Collectors.toList());
        List<String> feishuUserCodeList = feishuUsers.stream()
                .map(m -> this.getDoucCodeByFeishu(m.getUser().getUserId(), identitySourceId))
                .collect(Collectors.toList());
        List<com.cloudwise.douc.metadata.model.user.User> userInfoByUserCodeList = userDao.getUserInfoByUserCodeList(
                accountId, feishuUserCodeList);
        // CHECKSTYLE:OFF
        if (CollectionUtils.isNotEmpty(userInfoByUserCodeList)) {
            List<String> alreadyUserCodeList = userInfoByUserCodeList.stream()
                    .map(com.cloudwise.douc.metadata.model.user.User::getCode).collect(Collectors.toList());
            feishuUsers.stream().filter(f -> {
                return alreadyUserCodeList.contains(
                        this.getDoucCodeByFeishu(f.getUser().getUserId(), identitySourceId));
            }).forEach(f -> {
                String oldDepartmentCode = userDao.getMainDepartmentCodeByUserCode(
                        this.getDoucCodeByFeishu(f.getUser().getUserId(), identitySourceId), accountId);
                f.setOldDepartmentCode(oldDepartmentCode);
                List<String> userDepartmentCodeList = Arrays.stream(f.getUser().getDepartmentIds())
                        .map(m -> this.getDoucCodeByFeishu(m, identitySourceId)).collect(Collectors.toList());
                if (feishuAllDepartmentCodeList.contains(oldDepartmentCode) && userDepartmentCodeList.contains(
                        oldDepartmentCode)) {
                    f.setSyncDataType(1);
                }
            });
            // CHECKSTYLE:ON
        }
        return feishuUsers;
    }
    
    /**
     * 用户数据转换
     *
     * @param feishuUsers              飞书用户列表
     * @param userList                 该身份源douc已经同步的用户列表
     * @param identitySourceId         身份源id
     * @param accountId                租户id
     * @param isSyncDepartment         是否同步部门
     * @param departmentParentId       同步到douc选择的部门
     * @param feishuDepartmentIdList   飞书部门id列表
     * @param status                   用户状态
     * @param feishuDepartmentCodeList 飞书部门code列表
     * @return 转换结果
     */
    public IdentityUserUpdateField feishuUserConvert(List<FeishuUser> feishuUsers, List<User> userList,
            Long identitySourceId, Long accountId, Boolean isSyncDepartment, Long departmentParentId,
            List<String> feishuDepartmentIdList, Integer status, List<String> feishuDepartmentCodeList) {
        IdentityUserUpdateField identityUserUpdateField = new IdentityUserUpdateField();
        List<IdentityFiledMapping> identityFiledMappingList = iIdentitySourceDao.getOpenFiledMappingByIdentitySourceId(
                identitySourceId, accountId, 2);
        Map<String, String> localAndExternalFiledMap;
        try {
            // key-localField  value-externalField
            localAndExternalFiledMap = identityFiledMappingList.stream().collect(
                    Collectors.toMap(IdentityFiledMapping::getLocalAttr, IdentityFiledMapping::getExternalAttr));
        } catch (Exception e) {
            log.error("获取配置的字段异常：", e);
            return identityUserUpdateField;
        }
        //获取飞书自定义字段id name
        List<CustomAttr> customAttrs = ((FeishuExternalServiceImpl) feishuExternalService).getCustomAttr();
        Map<String, String> feishuExternalFiledIdNameMap = customAttrs.stream()
                .collect(Collectors.toMap(CustomAttr::getId, c -> c.getI18nName()[0].getValue()));
        //本地Fields localField集合
        List<String> identitySourceBaseFields = identityFiledMappingList.stream()
                .map(IdentityFiledMapping::getLocalAttr).collect(Collectors.toList());
        //"departmentUserRelations", "status"
        List<String> realUpdateBaseFieldList = new ArrayList<>(doucBaseFiledForUpdateList);
        for (String baseField : identitySourceBaseFields) {
            if ("name".equals(baseField)) {
                realUpdateBaseFieldList.add("name");
            }
            if ("mobile".equals(baseField)) {
                realUpdateBaseFieldList.add("mobile");
            }
            if ("user_alias".equals(baseField)) {
                realUpdateBaseFieldList.add("userAlias");
            }
            if ("feishu_account".equals(baseField)) {
                realUpdateBaseFieldList.add("feishuAccount");
            }
            if ("email".equals(baseField)) {
                realUpdateBaseFieldList.add("email");
            }
            if ("position".equals(baseField)) {
                realUpdateBaseFieldList.add("position");
            }
        }
        //存放 扩展字段
        List<String> extendFieldList = new ArrayList<>();
        for (IdentityFiledMapping identityFiledMapping : identityFiledMappingList) {
            if (!doucBaseFiledList.contains(identityFiledMapping.getLocalAttr())) {
                if (!realUpdateBaseFieldList.contains("extend")) {
                    realUpdateBaseFieldList.add("extend");
                }
                if (!extendFieldList.contains(identityFiledMapping.getLocalAttr())) {
                    extendFieldList.add(identityFiledMapping.getLocalAttr());
                }
            }
        }
        Set<String> extarnameList = new HashSet<>();
        for (FeishuUser feishuUser : feishuUsers) {
            extarnameList.clear();
            User user = new User();
            //飞书中内部拓展字段的名称-值 的map
            final Map<String, String> feishuUserMap = new HashMap<>();
            //飞书所有自带字段-值 map
            try {
                feishuUserMap.putAll(ObjectToMapUtil.convert(feishuUser.getUser()));
            } catch (Exception e) {
                log.error("java实体转map异常:", e);
            }

            final Map<String, String> feishuExtenNameAndValueMap = new HashMap<>();
            //飞书中所有拓展字段名称
            if (Objects.nonNull(feishuUser.getUser().getCustomAttrs())
                    && feishuUser.getUser().getCustomAttrs().length > 0) {
                Arrays.stream(feishuUser.getUser().getCustomAttrs()).forEach(userCustomAttr -> {
                    if (Objects.nonNull(feishuExternalFiledIdNameMap.get(userCustomAttr.getId()))) {
                        // 自定义字段类型】- `TEXT`：文本;- `HREF`：网页;- `ENUMERATION`：枚举;- `PICTURE_ENUM`：图片;- `GENERIC_USER`：用户
                        String type = userCustomAttr.getType();
                        String value;
                        switch (type) {
                            case "ENUMERATION":
                                value = userCustomAttr.getValue().getOptionValue();
                                break;
                            case "PICTURE_ENUM":
                                value = userCustomAttr.getValue().getPictureUrl();
                                break;
                            case "GENERIC_USER":
                                value = userCustomAttr.getValue().getGenericUser().getId();
                                break;
                            default:
                                value = userCustomAttr.getValue().getText();
                                break;
                        }
                        feishuExtenNameAndValueMap.put(feishuExternalFiledIdNameMap.get(userCustomAttr.getId()), value);
                        feishuUserMap.putIfAbsent(feishuExternalFiledIdNameMap.get(userCustomAttr.getId()), value);
                    }
                });
                extarnameList = feishuExtenNameAndValueMap.keySet();
            }
            
            //内置的匹配字段-不能动的字段
            user.setUserLeaderCodes(Collections.singletonList(
                    this.getDoucCodeByFeishu(feishuUser.getUser().getLeaderUserId(), identitySourceId)));
            List<DepartmentUserRelation> departmentUserRelationList = new ArrayList<>();
            if (!isSyncDepartment) {
                //不同步部门
                List<DepartMentInfo> departmentInfoByIds = departmentDao.getDepartmentInfoByIds(accountId,
                        Collections.singletonList(departmentParentId));
                if (CollectionUtils.isNotEmpty(departmentInfoByIds)) {
                    DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                    departmentUserRelation.setDepartmentCode(departmentInfoByIds.get(0).getCode());
                    departmentUserRelation.setDepartmentId(departmentInfoByIds.get(0).getId());
                    departmentUserRelation.setIsMain(1);
                    String positionValue = feishuUserMap.get(localAndExternalFiledMap.get(POSITION));
                    if (Objects.nonNull(positionValue)) {
                        departmentUserRelation.setPosition(positionValue);
                    }
                    departmentUserRelationList.add(departmentUserRelation);
                }
            } else {
                //同步部门
                List<String> feishuAllDepartmentCodeList = feishuDepartmentCodeList;
                if (CollectionUtils.isEmpty(feishuDepartmentCodeList)) {
                    feishuAllDepartmentCodeList = feishuDepartmentIdList.stream()
                            .map(m -> this.getDoucCodeByFeishu(m, identitySourceId)).collect(Collectors.toList());
                }
                List<String> userDepartmentCodeList = Arrays.stream(feishuUser.getUser().getDepartmentIds())
                        .map(f -> this.getDoucCodeByFeishu(f, identitySourceId)).collect(Collectors.toList());
                List<String> endDepartmentCodeList = new ArrayList<>();
                for (String userDepartmentCode : userDepartmentCodeList) {
                    if (feishuAllDepartmentCodeList.contains(userDepartmentCode)) {
                        endDepartmentCodeList.add(userDepartmentCode);
                    }
                }
                if (null == feishuUser.getSyncDataType()) {
                    for (int i = 0; i < endDepartmentCodeList.size(); i++) {
                        DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                        departmentUserRelation.setDepartmentCode(endDepartmentCodeList.get(i));
                        departmentUserRelation.setAccountId(accountId);
                        if (i == 0) {
                            String positionValue = feishuUserMap.get(localAndExternalFiledMap.get(POSITION));
                            if (Objects.nonNull(positionValue)) {
                                departmentUserRelation.setPosition(positionValue);
                            }
                            departmentUserRelation.setIsMain(1);
                        }
                        departmentUserRelationList.add(departmentUserRelation);
                    }
                } else {
                    endDepartmentCodeList.remove(feishuUser.getOldDepartmentCode());
                    DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                    departmentUserRelation.setDepartmentCode(feishuUser.getOldDepartmentCode());
                    departmentUserRelation.setAccountId(accountId);
                    String positionValue = feishuUserMap.get(localAndExternalFiledMap.get(POSITION));
                    if (Objects.nonNull(positionValue)) {
                        departmentUserRelation.setPosition(positionValue);
                    }
                    departmentUserRelationList.add(departmentUserRelation);
                    departmentUserRelation.setIsMain(1);
                    for (String departmentCode : endDepartmentCodeList) {
                        DepartmentUserRelation departmentUserRelation1 = new DepartmentUserRelation();
                        departmentUserRelation1.setDepartmentCode(departmentCode);
                        departmentUserRelation1.setAccountId(accountId);
                        departmentUserRelationList.add(departmentUserRelation1);
                    }
                }
            }
            user.setDepartmentUserRelations(departmentUserRelationList);
            //内置的匹配字段-可以修改的字段 可能配置钉钉中的所有字段（钉钉自带字段，拓展字段）
            
            //姓名匹配
            if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(NAME))) {
                user.setName(feishuExtenNameAndValueMap.get(localAndExternalFiledMap.get(NAME)));
            } else {
                user.setName(feishuUserMap.get(localAndExternalFiledMap.get(NAME)));
            }
            //用户名匹配
            if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(USER_ALIAS))) {
                user.setUserAlias(feishuExtenNameAndValueMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            } else {
                user.setUserAlias(feishuUserMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            }
            //职位匹配
            if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(POSITION))) {
                user.setPosition(feishuExtenNameAndValueMap.get(localAndExternalFiledMap.get(POSITION)));
            } else {
                user.setPosition(feishuUserMap.get(localAndExternalFiledMap.get(POSITION)));
            }
            //手机号匹配
            if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(MOBILE))) {
                user.setMobile(mobileSplit(feishuExtenNameAndValueMap.get(localAndExternalFiledMap.get(MOBILE))));
            } else {
                user.setMobile(mobileSplit(feishuUserMap.get(localAndExternalFiledMap.get(MOBILE))));
            }
            //邮箱匹配
            if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(EMAIL))) {
                user.setEmail(feishuExtenNameAndValueMap.get(localAndExternalFiledMap.get(EMAIL)));
            } else {
                user.setEmail(feishuUserMap.get(localAndExternalFiledMap.get(EMAIL)));
            }
            //飞书账号匹配
            if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                    localAndExternalFiledMap.get(FEISHU_ACCOUNT))) {
                user.setFeishuAccount(feishuExtenNameAndValueMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            } else {
                user.setFeishuAccount(feishuUserMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            }
            List<Map<String, Object>> extendFields = new ArrayList<>();
            for (IdentityFiledMapping identityFiledMapping : identityFiledMappingList) {
                // 用户自定义的匹配字段-douc的拓展字段
                if (!doucBaseFiledList.contains(identityFiledMapping.getLocalAttr())) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("alias", identityFiledMapping.getLocalAttr());
                    if (MapUtils.isNotEmpty(feishuExtenNameAndValueMap) && extarnameList.contains(
                            identityFiledMapping.getExternalAttr())) {
                        map.put("value", feishuExtenNameAndValueMap.get(identityFiledMapping.getExternalAttr()));
                    } else {
                        map.put("value", feishuUserMap.get(identityFiledMapping.getExternalAttr()));
                    }
                    extendFields.add(map);
                }
            }
            user.setExtend(extendFields);
            user.setTopAccountId(accountId);
            user.setIdentitySourceId(identitySourceId);
            user.setCode(getDoucCodeByFeishu(feishuUser.getUser().getUserId(), identitySourceId));
            user.setImportType(Constant.USER_IMPORT_TYPE_IDENTITY);
            if (feishuUser.getUser().getStatus().getIsFrozen()) {
                user.setStatus(Constant.STATUS_DOWN);
            } else {
                user.setStatus(status);
            }
            userList.add(user);
        }
        identityUserUpdateField.setBaseFieldList(realUpdateBaseFieldList);
        identityUserUpdateField.setExtendFieldList(extendFieldList);
        return identityUserUpdateField;
    }
    
    public static String mobileSplit(String mobile) {
        if (StringUtils.isNotEmpty(mobile)) {
            return mobile.replace(Constant.DEFAULT_AREA_CODE, "");
        }
        return StringUtils.EMPTY;
    }

    public String getDoucCodeByFeishu(String code, Long identitySourceId) {
        return IdentityTypeEnum.feishu.name() + StrPool.UNDERLINE + identitySourceId + StrPool.UNDERLINE + code;
    }
}
