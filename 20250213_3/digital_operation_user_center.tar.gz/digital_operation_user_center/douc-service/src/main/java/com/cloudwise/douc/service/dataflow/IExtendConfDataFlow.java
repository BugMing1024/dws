package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.extend.ExtendConfEntity;

import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:53 PM 2021/4/7.
 */
public interface IExtendConfDataFlow {
    /**
     * 根据配置类型获取拓展字段配置
     *
     * @Param accountId 租户id
     * @Param type 配置类型 1 用户 , 2 组织机构
     * @Return
     * @author ken
     * @Date 3:14 PM 2020/11/24
     */
    List<ExtendConfEntity> getExtendConfByType(Long accountId, Integer type);

    /**
     * 删除缓存
     *
     * @param accountId
     * @param type
     */
    void deleteExtendConfByType(Long accountId, Integer type);
}
