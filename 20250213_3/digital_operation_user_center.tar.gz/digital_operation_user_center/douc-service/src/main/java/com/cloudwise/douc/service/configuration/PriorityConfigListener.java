package com.cloudwise.douc.service.configuration;

import cn.hutool.core.text.StrPool;
import com.cloudwise.cwop.security.RSAUtils;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;

import java.util.Arrays;
import java.util.Collection;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author KenLiang
 * @description: 优先级比较高的密码解密，主要为nacos 密码
 * @date Created in 11:32 AM 2020/12/4.
 */
@Slf4j
public class PriorityConfigListener implements ApplicationListener<ApplicationEnvironmentPreparedEvent> {
    private static final String DECRYPT_PROP = "props.decrypt.props";
    private static final String DECRYPT_NOPROP = "props.decrypt.noprops";
    
    private static final String DECRYPT_NAME = "props.decrypt.key";
    private static final String DECRYPT_PROPERTY_SOURCE = "cloudwise-priority-common-decrypt";

    @Override
    public void onApplicationEvent(ApplicationEnvironmentPreparedEvent applicationEnvironmentPreparedEvent) {

        ConfigurableEnvironment environment = applicationEnvironmentPreparedEvent.getEnvironment();
        MutablePropertySources propertySources = environment.getPropertySources();
        //nacos账号密码解密
        Collection<String> processDecryptKeyList = Arrays.asList(environment.getProperty(DECRYPT_PROP, "").split(
                StrPool.COMMA));
        Collection<String> noProcessDecryptKeyList = Arrays.asList(environment.getProperty(DECRYPT_NOPROP, "").split(StrPool.COMMA));
        log.info("preparedDecryptKeyList : {}", processDecryptKeyList);
        log.info("noprocessDecryptKeyList : {}", noProcessDecryptKeyList);
        propertySources.remove(DECRYPT_PROPERTY_SOURCE);
        processDecryptProperties(propertySources, environment, processDecryptKeyList, noProcessDecryptKeyList);

    }

    private void processDecryptProperties(MutablePropertySources propertySources,
                                          ConfigurableEnvironment environment,
                                          @NonNull Collection<String> keys, Collection<String> noprocessDecryptKeyList) {
        final Set<String> collect = keys.stream().filter(StringUtils::isNoneBlank).map(String::trim)
                .collect(Collectors.toSet());
        Properties properties = new Properties();
        collect.forEach(key -> {
            String value = environment.getProperty(key, "");
            if (StringUtils.isNoneBlank(value) && !noprocessDecryptKeyList.contains(key)) {
                String decrypt = decrypt(value, environment.getProperty(DECRYPT_NAME));
                properties.setProperty(key, decrypt);

            }
        });
        PropertiesPropertySource propertiesPropertySource = new PropertiesPropertySource(DECRYPT_PROPERTY_SOURCE, properties);
        propertySources.addFirst(propertiesPropertySource);
    }
    
    private String decrypt(String source, String key) {
        if (StringUtils.isBlank(key)) {
            log.error("DecryptKey cannot be null or empty.");
        }
        String result = null;
        try {
            result = RSAUtils.decrypt(key, source);
            log.info(">>>processDecryptProperties--success>>>-【{}】-【{}】", key, source);
        } catch (Exception e) {
            log.warn("Decryption failed:{}", e.getMessage(), e);
            log.warn("Decryption failed,key:{}", key);
            result = source;
        }
        return result;
    }
}