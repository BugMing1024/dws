package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Bernie
 * @date 2020-11-20 11:11
 */
@Data
public class UserEntity implements Serializable {
    private Long id;
    private String name;
    private String mobile;
    private String phone;
    private String email;
    private String password;
    private Integer status;
    private Integer importType;
    private String userAlias;
    private Integer type;
    private String state;
    private String region;
    private String city;
    private Integer origin;
    private String lastIp;
    private String lastTime;
    private Long accountId;
    private Integer adminType;
    private String dingtalkAccount;
    private String weixinworkAccount;
    private String feishuAccount;
    private String wxpushAccount;
    private String code;
    private String extra;
    private String workNum;
    private String remark;
    private long createUserId;
    private Date createTime;
    private long modifyUserId;
    private Date modifyTime;
    private String ldapDn;
    private String ldapUserId;
}
