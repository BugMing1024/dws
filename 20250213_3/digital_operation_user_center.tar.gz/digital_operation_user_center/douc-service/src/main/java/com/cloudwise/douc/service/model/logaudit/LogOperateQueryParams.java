package com.cloudwise.douc.service.model.logaudit;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * @author elsa.yang
 * @date 2020/6/10 2:32 下午
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogOperateQueryParams {

    /**
     * 日志类型
     */
    private String logType;

    /**
     * 操作时间
     */
    private TimeTrame operationTime;

    /**
     * 时间范围
     */
    private String timeRanges;

    /**
     * 操作人员
     */
    private List<String> operationUser;

    /**
     * 模块
     */
    private List<String> module;

    /**
     * 操作
     */
    private List<String> operateType;

    /**
     * 结果
     */
    private String result;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序方式
     */
    private String sortMode;

    /**
     * 排序字段
     */
    private String dbSortField;

    /**
     * 排序方式
     */
    private String dbSortMode;
    
    /**
     * 内容
     */
    private String content;

    /**
     * 页码
     */
    private Integer current;

    /**
     * 每页条数
     */
    private Integer size;


    public String getSortField() {
        return StringUtils.isNotBlank(this.sortField) ? this.sortField : "timestamp";
    }

    public String getSortMode() {
        return StringUtils.isNotBlank(this.sortMode) ? this.sortMode : "desc";
    }

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
