package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.activerecord.domain.SysDomain;

/**
 * 域相关缓存
 * @author zhangmengyang
 */
public interface IDomainCache {
    
    /**
     * 存储域信息
     * @param topAccountId 顶级租户ID
     * @param sysDomain 域信息
     */
    void setSysDomain(Long topAccountId, SysDomain sysDomain);
    
    /**
     * 获取域信息
     * @param topAccountId 顶级租户ID
     * @param domainId 域id
     * @return 域信息
     */
    SysDomain getSysDomain(Long topAccountId, Long domainId);
    
    /**
     * 删除域信息
     * @param topAccountId 顶级租户ID
     * @param domainId 域id
     */
    void deleteSysDomain(Long topAccountId, Long domainId);
    
    /**
     * 同步所有域信息
     */
    void syncSysDomain();
}
