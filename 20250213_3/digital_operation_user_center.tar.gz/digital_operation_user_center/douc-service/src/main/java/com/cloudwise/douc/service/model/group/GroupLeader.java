package com.cloudwise.douc.service.model.group;

import lombok.Data;

import java.io.Serializable;

/**
 * @author leakey.li
 * @description:
 * @date Created in 3:56 下午 2021/8/8.
 */
@Data
public class GroupLeader implements Serializable {
    private Long groupId;
    private String leader;
}
