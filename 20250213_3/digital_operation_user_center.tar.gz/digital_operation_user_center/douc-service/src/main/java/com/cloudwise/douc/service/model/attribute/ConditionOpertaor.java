package com.cloudwise.douc.service.model.attribute;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class ConditionOpertaor {

    private String name;

    private String code;

    private static Map<String, String> typeAndConditionOperatorMap = new HashMap<>();

    private static Map<String, String> fieldAndConditionOperatorMap = new HashMap<>();

    static {
        initTypeAndConditionOperatorMap();
        initFieldAndConditionOperatorMap();
    }
    
    private static void initFieldAndConditionOperatorMap() {
        fieldAndConditionOperatorMap.put("name", "Eq,NotEq");
        fieldAndConditionOperatorMap.put("user_alias", "Eq,NotEq");
        fieldAndConditionOperatorMap.put("department_id", "Eq,NotEq,Contain,NotContain");
        fieldAndConditionOperatorMap.put("position", "Eq,NotEq,Contain,NotContain");
        fieldAndConditionOperatorMap.put("origin", "Eq,NotEq");
        fieldAndConditionOperatorMap.put("user_leader_id", "Eq,NotEq,Contain,NotContain");
    }

    private static void initTypeAndConditionOperatorMap() {
        typeAndConditionOperatorMap.put("JsonCheckboxOne", "Eq,NotEq,IsNull,IsNotNull");
        typeAndConditionOperatorMap.put("JsonCheckboxMore", "Eq,NotEq,IsNull,IsNotNull,Contain,NotContain");
        typeAndConditionOperatorMap.put("JsonString", "Eq,NotEq,IsNull,IsNotNull,Contain,NotContain,StartWith,EndWith");
        typeAndConditionOperatorMap.put("JsonInteger", "Eq,NotEq,IsNull,IsNotNull,Ge,Gt,Le,Lt");
        typeAndConditionOperatorMap.put("JsonFloat", "Eq,NotEq,IsNull,IsNotNull,Ge,Gt,Le,Lt");
        typeAndConditionOperatorMap.put("String", "Eq,NotEq,IsNull,IsNotNull,StartWith,EndWith");
    }

    public static Map<String, String> getFieldAndConditionOperatorMap() {
        return fieldAndConditionOperatorMap;
    }
    
    public static final String CONDITION = "Condition_";

    public static Map<String, String> getTypeAndConditionOperatorMap() {
        return typeAndConditionOperatorMap;
    }
}
