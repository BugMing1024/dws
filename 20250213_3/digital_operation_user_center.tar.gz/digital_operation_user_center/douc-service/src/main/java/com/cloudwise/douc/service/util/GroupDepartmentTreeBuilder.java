package com.cloudwise.douc.service.util;


import com.cloudwise.douc.metadata.model.group.GroupDepartmentResp;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * @author barney.song
 * Description: 构造目录用户组部门关联树
 */
@Slf4j
public class GroupDepartmentTreeBuilder {
    private List<GroupDepartmentResp> nodes = new ArrayList<>();
    private List<Long> departmentIds = new ArrayList<>();

    public static List<GroupDepartmentResp> buildTree(List<GroupDepartmentResp> nodes, List<Long> departmentIds) {

        GroupDepartmentTreeBuilder treeBuilder = new GroupDepartmentTreeBuilder(nodes, departmentIds);

        return treeBuilder.buildJSONTree();
    }

    private GroupDepartmentTreeBuilder(List<GroupDepartmentResp> nodes, List<Long> departmentIds) {
        super();
        this.departmentIds = departmentIds;
        this.nodes = nodes;
    }

    // 构建JSON树形结构
    private List<GroupDepartmentResp> buildJSONTree() {
        List<GroupDepartmentResp> nodeTree = buildTree1();
        return nodeTree;
    }

    // 构建树形结构
    private List<GroupDepartmentResp> buildTree1() {
        List<GroupDepartmentResp> treeNodes = Lists.newArrayListWithExpectedSize(nodes.size());
        List<GroupDepartmentResp> rootNodes = getRootNodes();
        for (GroupDepartmentResp rootNode : rootNodes) {
            buildChildNodes(rootNode);
            treeNodes.add(rootNode);
        }
        return treeNodes;
    }

    // 递归子节点
    private void buildChildNodes(GroupDepartmentResp node) {
        List<GroupDepartmentResp> children = getChildNodes(node);
        if (!children.isEmpty()) {
            for (GroupDepartmentResp child : children) {
                buildChildNodes(child);
            }
            node.setIfChildren(false);
            node.setChildrenList(children);
        } else {
            node.setIfChildren(true);
        }
        node.setSelected(setDepartmentIsSelected(node.getLevel(), node.getId(), departmentIds));
    }

    /**
     * 通过部门id 部门level 和已关联的部门ids 判断是否被选中
     *
     * @param level
     * @param id
     * @param departmentIds
     * @return
     */
    private boolean setDepartmentIsSelected(String level, Long id, List<Long> departmentIds) {
        if (departmentIds.contains(id)) {
            return true;
        }
        return false;
    }

    // 获取父节点下所有的子节点
    private List<GroupDepartmentResp> getChildNodes(GroupDepartmentResp pnode) {
        List<GroupDepartmentResp> childNodes = new ArrayList<>();
        Long a = pnode.getId();
        for (GroupDepartmentResp n : nodes) {
            Long b = n.getParentId();
            if (a.equals(b)) {
                childNodes.add(n);
            }
        }
        return childNodes;
    }

    // 判断是否为根节点
    private boolean rootNode(GroupDepartmentResp node) {
        boolean isRootNode = true;
        Long a = node.getParentId();
        for (GroupDepartmentResp n : nodes) {
            Long b = n.getId();
            if (a.equals(b)) {
                isRootNode = false;
                break;
            }
        }
        return isRootNode;
    }

    // 获取集合中所有的根节点
    private List<GroupDepartmentResp> getRootNodes() {
        List<GroupDepartmentResp> rootNodes = new ArrayList<>();
        for (GroupDepartmentResp n : nodes) {

            if (rootNode(n)) {
                rootNodes.add(n);
            }
        }
        return rootNodes;
    }

}