package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户分页参数类
 */
@Data
public class UserPageParam implements Serializable {
    private static final long serialVersionUID = 2973538425638426095L;
    private Long accountId;
    private Integer status;
    private Long roleId;
    private Integer current;
    private Integer size;
    private String aliasOrName;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
