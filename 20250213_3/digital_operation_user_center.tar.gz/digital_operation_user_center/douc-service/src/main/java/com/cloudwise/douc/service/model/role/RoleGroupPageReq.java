package com.cloudwise.douc.service.model.role;

import lombok.Data;

/**
 * 角色groupPage参数类
 */
@Data
public class RoleGroupPageReq {
    private Long roleGroupId;
    private Long accountId;
    private String language;
    private Integer current;
    private Integer size;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
