package com.cloudwise.douc.service.model.auth;

import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ken.liang
 * @description:
 * @date Created in 12:06 PM 2021/6/23.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuAuthedCacheDTO implements Serializable {
    private static final long serialVersionUID = 6770221874196641132L;
    private long createTime;
    private List<MenuResponse> menuResponseList;
}
