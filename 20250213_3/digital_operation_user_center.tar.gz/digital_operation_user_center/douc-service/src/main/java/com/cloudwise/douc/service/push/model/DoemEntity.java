package com.cloudwise.douc.service.push.model;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.HashMap;

/**
 * @author Zack.Gao
 */
@Data
public class DoemEntity {

    private String url;

    private HashMap<String, Object> header;

    private HashMap<String, Object> body;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
