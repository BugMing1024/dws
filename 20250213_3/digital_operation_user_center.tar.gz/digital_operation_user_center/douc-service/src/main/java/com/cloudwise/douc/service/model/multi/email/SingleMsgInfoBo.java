package com.cloudwise.douc.service.model.multi.email;

import lombok.Data;

import java.io.Serializable;

/**
 * 邮件信息
 *
 * @author maker.wang
 * @date 2021-07-15 10:28
 **/
@Data
public class SingleMsgInfoBo implements Serializable {
    private static final long serialVersionUID = 322362101929331878L;

    /**
     * 消息主题
     **/
    private String msgTitle;

    /**
     * 消息内容
     **/
    private String msgContent;

    /**
     * 接收人邮箱
     **/
    private String receiveEmail;

    /**
     * 发送人用户id
     **/
    private Long sendUserId;

    /**
     * 发送人租户id
     **/
    private Long sendAccountId;

}
