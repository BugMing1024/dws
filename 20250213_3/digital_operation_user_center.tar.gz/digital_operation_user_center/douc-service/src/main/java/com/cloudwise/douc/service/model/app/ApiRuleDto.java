package com.cloudwise.douc.service.model.app;

import com.cloudwise.douc.metadata.model.apimanage.DegradeRuleEntity;
import com.cloudwise.douc.metadata.model.apimanage.FlowRuleEntity;
import lombok.Data;

/**
 * 流控实体类
 **/
@Data
public class ApiRuleDto {

    private FlowRuleEntity flowRule;

    private DegradeRuleEntity degradeRule;

    private String code;

    private Integer hasFlowRule;

    private Boolean flow;

    private Integer hasDegradeRule;

    private Boolean degrade;

}
