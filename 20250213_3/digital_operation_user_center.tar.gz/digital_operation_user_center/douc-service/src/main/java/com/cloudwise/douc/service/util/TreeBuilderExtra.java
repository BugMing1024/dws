package com.cloudwise.douc.service.util;


import com.cloudwise.douc.dto.v3.common.TreeNode;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author barney.song Description: 构造目录JSON树
 */
@Slf4j
public class TreeBuilderExtra<T extends TreeNode> {
    
    private List<T> nodes = new ArrayList<>();
    
    private TreeBuilderExtra() {
    }
    
    public TreeBuilderExtra(List<T> nodes) {
        super();
        this.nodes = nodes;
    }
    
    public static <T extends TreeNode> List<T> buildTree(List<T> nodes) {
        
        TreeBuilderExtra treeBuilder = new TreeBuilderExtra(nodes);
        
        return treeBuilder.buildJSONTree();
    }
    
    public static <T extends TreeNode> void sortNodes(List<T> nodes) {
        if (CollectionUtils.isNotEmpty(nodes)) {
            sortBySequence(nodes);
            for (T node : nodes) {
                if (CollectionUtils.isNotEmpty(node.getChildren())) {
                    List<T> children = (List<T>) node.getChildren();
                    sortBySequence(children);
                    sortNodes(children);
                }
            }
        }
    }
    
    public static <T extends TreeNode> void sortBySequence(List<T> nodes) {
        if (CollectionUtils.isNotEmpty(nodes)) {
            nodes.sort((o1, o2) -> {
                if (o1.getSequence() == null && o2.getSequence() == null) {
                    return 0;
                } else if (o1.getSequence() == null) {
                    return 1;
                } else if (o2.getSequence() == null) {
                    return -1;
                } else {
                    return o1.getSequence() - o2.getSequence();
                }
            });
        }
    }
    
    private List<T> buildJSONTree() {
        List<T> nodeTree = buildTree1();
        return nodeTree;
    }
    
    private List<T> buildTree1() {
        List<T> treeNodes = Lists.newArrayListWithExpectedSize(nodes.size());
        List<T> rootNodes = getRootNodes();
        for (T rootNode : rootNodes) {
            buildChildNodes(rootNode);
            treeNodes.add(rootNode);
        }
        return treeNodes;
    }
    
    private void buildChildNodes(T node) {
        List<T> children = getChildNodes(node);
        if (!children.isEmpty()) {
            for (T child : children) {
                buildChildNodes(child);
            }
            node.setChildren(children);
        }
    }
    
    private List<T> getChildNodes(T pnode) {
        List<T> childNodes = new ArrayList<>();
        Long a = pnode.getId();
        for (T n : nodes) {
            Long b = n.getParentId();
            if (a.equals(b)) {
                childNodes.add(n);
            }
        }
        return childNodes;
    }
    
    private boolean rootNode(T node) {
        boolean isRootNode = true;
        Long a = node.getParentId();
        for (T n : nodes) {
            Long b = n.getId();
            if (a.equals(b)) {
                isRootNode = false;
                break;
            }
        }
        return isRootNode;
    }
    
    private List<T> getRootNodes() {
        List<T> rootNodes = new ArrayList<>();
        for (T n : nodes) {
            
            if (rootNode(n)) {
                rootNodes.add(n);
            }
        }
        return rootNodes;
    }
}

