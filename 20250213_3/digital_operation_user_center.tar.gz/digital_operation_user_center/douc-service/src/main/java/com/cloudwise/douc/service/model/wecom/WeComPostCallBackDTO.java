package com.cloudwise.douc.service.model.wecom;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 企业微信代开发-get请求参数
 *
 * @author maker.wang
 * @date 2022-10-31 10:38
 **/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel("企业微信代开发-get请求参数")
public class WeComPostCallBackDTO implements Serializable {
    private static final long serialVersionUID = -4471194567823459854L;

    @ApiModelProperty("代开发应用模板id")
    @JsonProperty(value = "SuiteId")
    private String suiteId;

    @ApiModelProperty("临时授权码,最长为512字节。用于获取企业永久授权码。10分钟内有效")
    @JsonProperty(value = "AuthCode")
    private String authCode;

    @ApiModelProperty("类型：suite_ticket ,create_auth")
    @JsonProperty(value = "InfoType")
    private String infoType;

    @ApiModelProperty("时间戳")
    @JsonProperty(value = "TimeStamp")
    private String timeStamp;

    @ApiModelProperty("构造授权链接指定的state参数")
    @JsonProperty(value = "State")
    private String state;

    @ApiModelProperty("Ticket内容，最长为512字节")
    @JsonProperty(value = "SuiteTicket")
    private String suiteTicket;

    /**
     * 未知,暂记录
     **/
    @ApiModelProperty("ToUserName")
    @JsonProperty(value = "ToUserName")
    private String toUserName;

    @ApiModelProperty("AgentID")
    @JsonProperty(value = "AgentID")
    private String agentID;

    @ApiModelProperty("Encrypt")
    @JsonProperty(value = "Encrypt")
    private String encrypt;


}
