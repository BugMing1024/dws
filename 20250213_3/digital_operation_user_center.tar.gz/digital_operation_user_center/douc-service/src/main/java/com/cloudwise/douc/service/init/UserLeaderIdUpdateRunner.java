package com.cloudwise.douc.service.init;

import com.cloudwise.douc.metadata.mapper.IQuestRecordDao;
import com.cloudwise.douc.metadata.model.questrecord.QuestRecordEntity;
import com.cloudwise.douc.service.service.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ConditionalOnProperty(name = "sso.server.mode.isSaasLoginApi", havingValue = "false")
public class UserLeaderIdUpdateRunner implements ApplicationRunner {
    
    @Autowired
    private IUserService userService;
    
    @Autowired
    private IQuestRecordDao questRecordDao;
    
    @Override
    public void run(ApplicationArguments args) throws Exception {
        String questCode = "UserLeaderIdSortedQuest";
        int count = questRecordDao.getQuestRecordByCode(questCode);
        if (count > 0) {
            log.info("UserLeaderIdSortedQuest任务已执行过");
            return;
        }
        userService.changeUserLeaderIdSorted();
        QuestRecordEntity questRecordEntity = new QuestRecordEntity();
        questRecordEntity.setCreateTime(System.currentTimeMillis());
        questRecordEntity.setQuestCode(questCode);
        questRecordEntity.setDescription("user表中userLeaderId历史数据重排序");
        questRecordDao.addQuestRecord(questRecordEntity);
    }
}
