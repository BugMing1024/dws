package com.cloudwise.douc.service.model.identitysource;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class IdentitySourceCallBackInfo {

    @ApiModelProperty(value = "回调uri")
    private String callBackUrl;
    @ApiModelProperty(value = "回调token")
    private String callBackToken;
    @ApiModelProperty(value = "回调EncodingAESKey")
    private String callBackKey;
}
