package com.cloudwise.douc.service.model.quota;

import lombok.Data;

import java.io.Serializable;
import java.sql.Date;

/**
 * @author bradyliu
 * @description:
 * @date Created in 10:48 2021/10/11.
 */
@Data
public class AccountQuotaInfoDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    /* '租户id，非空' */
    private Long enterpriseId;
    /* '租户名称，非空'*/
    private String enterpriseName;
    /* '签发日期，非空' */
    private Date issued;
    /* '配额信息，RSA加密，非空' */
    private String quotaInfo;
}
