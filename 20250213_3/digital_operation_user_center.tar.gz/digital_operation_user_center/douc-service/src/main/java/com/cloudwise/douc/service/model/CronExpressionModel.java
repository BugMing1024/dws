package com.cloudwise.douc.service.model;

import lombok.Data;

/**
 * @author Bernie
 * @date 2021-01-06 10:58
 */
@Data
public class CronExpressionModel {
    private Integer jobType;
    private Integer day;
    private Integer second;
    private Integer minute;
    private Integer hour;
    private Integer[] dayOfWeeks;
    private Integer[] dayOfMonths;
}
