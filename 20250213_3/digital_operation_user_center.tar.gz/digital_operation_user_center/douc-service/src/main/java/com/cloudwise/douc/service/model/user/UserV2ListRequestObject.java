package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.dto.v3.common.PageReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ethan.du
 * @version v2.0
 * @date 2024/4/22 15:58
 */

@Data
public class UserV2ListRequestObject extends PageReq implements Serializable {

    private static final long serialVersionUID = -4104989938789421871L;

    @ApiModelProperty("拼音搜索")
    private String keyword;

    @ApiModelProperty("关键字，用于邮箱模糊搜索")
    private String emailKeyword;

    @ApiModelProperty("关键字，用于手机模糊搜索")
    private String mobileKeyword;

    @ApiModelProperty("组织机构")
    private Long departmentId;

    @ApiModelProperty("用户组")
    private Long groupId;

    @ApiModelProperty("角色")
    private Long roleId;

    @ApiModelProperty("职务")
    private Long positionId;

    @ApiModelProperty("角色关联类型 参考：SysUserRoleRelation.UserRoleRelationType")
    private Integer userRoleRelationType;

    @ApiModelProperty("用户组关联类型 参考：SysUserRoleRelation.UserGroupRelationType")
    private Integer userGroupRelationType;

    @ApiModelProperty("仅查询主部门用户(查询指定部门时有效)")
    private Boolean onlyDisplayMainDepartment;

    @ApiModelProperty("邮箱")
    private String email;

    @ApiModelProperty("手机号")
    private String mobile;

    @ApiModelProperty("用户状态")
    private Integer status;

    @ApiModelProperty("可见范围")
    private String accountScope;

    public UserV2ListRequestObject() {
        this.onlyDisplayMainDepartment = Boolean.TRUE;
    }
}
