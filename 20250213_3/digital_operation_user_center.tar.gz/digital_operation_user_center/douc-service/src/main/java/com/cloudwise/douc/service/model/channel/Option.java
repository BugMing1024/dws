package com.cloudwise.douc.service.model.channel;

import lombok.Data;

import java.util.Map;

/**
 * @author zafir.zhong
 * @description 选项的设置
 * @date Created in 15:53 2022/4/15.
 */
@Data
public class Option {

    private String name;
    private String enName;
    private String value;
    private String multiLanguage;
    
    private Map<String, String> extendFields;

}
