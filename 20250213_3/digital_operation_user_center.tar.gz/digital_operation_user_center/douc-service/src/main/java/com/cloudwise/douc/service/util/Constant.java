package com.cloudwise.douc.service.util;

import com.cloudwise.douc.commons.constant.DbConstant;
import com.cloudwise.douc.commons.constant.LanguageConstants;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author barney.song Description: No Description
 */
public class Constant {
    
    //系统默认租户id
    public static final Long DEFAULT_ACCOUNTID = 110L;
    
    public static final long DEFAULT_MAX_ACCOUNTID = 99999999;
    
    public static final long AGENCY_ID = 1111;
    
    public static final long CREATE_USER_ID = DbConstant.CREATE_USER_ID;
    
    public static final long MODIFY_USER_ID = DbConstant.MODIFY_USER_ID;
    
    public static final long DELETE_USER_ID = DbConstant.DELETE_USER_ID;
    
    public static final Integer ZERO = 0;
    
    public static final Integer ONE = 1;
    
    public static final Integer MAX_PAGE_SIZE = 100;
    
    public static final Integer COMMA_TRUE = 1;
    
    public static final Integer COMMA_FALSE = 0;
    
    public static final String LOGO_TYPE1_NAME = "{\"zh_CN\":{\"name\":\"智能业务运维平台\"},\"en_US\":{\"name\":\"Digital Operation Central Platform\"},\"zh_TW\":{\"name\":\"智能業務運維平台\"}}";
    public static final String LOGO_TYPE3_NAME = "{\"zh_CN\":{\"name\":\"云智慧\"},\"en_US\":{\"name\":\"cloudwise\"},\"zh_TW\":{\"name\":\"雲智慧\"}}";
    public static final String LOGO_TYPE4_NAME = "{\"zh_CN\":{\"name\":\"智能业务运维\"},\"en_US\":{\"name\":\"Digital Operation Central Platform\"},\"zh_TW\":{\"name\":\"智能業務運維\"}}\n";
    
    
    /**
     * 子租户最小id，4位数字
     *
     * @author maker.wang
     * @date 2021-07-30 10:28
     **/
    public static final Long ACCOUNT_MIN_ID = 1000L;
    
    public static final String FIRST_LEVEL = "0";
    
    public static final Long FIRST_LEVEL_LONG = 0L;
    
    public static final String LEVEL_SPLIT_REGEX = "\\.";
    
    public static final String LEVEL_SPLIT = ".";
    
    public static final String COMMA = ",";
    
    public static final String COLON = ":";
    
    public static final String SEMICOLON = ";";
    
    public static final char C_SEMICOLON = ';';
    
    public static final Integer FIRST_SEQUENCE = 0;
    
    //是否设置默认租户
    public static final Long SELECT = 1L;
    
    //是否第一次登录标识
    public static final Long FISRT_LOGIN = 1L;
    
    public static final Long NO_FISRT_LOGIN = 2L;
    
    
    //启用
    public static final Integer STATUS_UP = 1;
    
    //停用
    public static final Integer STATUS_DOWN = 2;
    
    //选中 1
    public static final Integer SELECTED_STATUS = DbConstant.SELECTED_STATUS;
    
    //不选 0
    public static final Integer NO_SELECTED_STATUS = DbConstant.NO_SELECTED_STATUS;
    
    //ip规则相关
    public static final String WRITE_LIST = "write_list";
    
    public static final String BLACK_LIST = "black_list";
    
    //用户第一次登录和重置密码之后修改密码
    public static final String DIS_UPDATE_SECRET = "0";
    
    public static final String UPDATE_SECRET = "1";
    
    //用户锁定
    public static final Integer USER_LOCKED = 1;
    
    //用户未锁定
    public static final Integer USER_UNLOCKED = 2;
    
    //批量锁定用户数量
    public static final int BATCH_LOCK_USER_SIZE = 1000;
    
    //用户锁定次数vertxmap存储名称
    public static final String USER_LOCK_TIME_VETTXMAP_NAME = "errLogins";
    
    //用户机构层级
    public static final String DEPART_FIRST_LEVEL = "1";
    
    public static final String DEPART_SECOND_LEVEL = "2";
    
    public static final String DEPART_THIRD_LEVEL = "3";
    
    public static final String DEPART_FOURTH_LEVEL = "4";
    
    public static final String DEPART_FIFTH_LEVEL = "5";
    
    //用户导入type
    public static final Integer USER_IMPORT_TYPE_DOUC = 1;
    
    public static final Integer USER_IMPORT_TYPE_DOSM = 2;
    
    //身份源导入type
    public static final Integer USER_IMPORT_TYPE_IDENTITY = 5;
    
    //身份源手动同步类型
    public static final Integer DATA_SYNC_TYPE_HAND = 1;
    
    public static final Integer DATA_SYNC_TYPE_JOB_TIME = 2;
    
    public static final Integer DATA_SYNC_TYPE_REAL_TIME = 3;
    
    //用户来源
    public static final Integer USER_ORIGIN_INNER = 1;
    
    public static final Integer USER_ORIGIN_OUTER = 2;
    
    public static final Integer USER_ORIGIN_TRIAL = 3;
    
    //excel 导入数量限制
    public static final Integer EXCEL_IMPORT_USER_MAX_SIZE = 2000;
    
    public static final Integer EXCEL_IMPORT_DEPARTMENT_MAX_SIZE = 1000;
    
    //Excel拓展字段后缀
    public static final String EXCEL_EXTEND_FIELD_PREFIX = "_EXTENDPREFIX";
    
    //管理员类型
    public static final Integer USER_ADMIN_TYPE = 1;
    
    public static final Integer USER_ORDINARY_TYPE = 2;
    
    public static final Integer USER_INNER_TYPE = 3;
    
    //session name
    public static final String SESSION_NAME = "douc_session_id";
    
    
    //数据资源  ---是否包含新增数据
    public static final Integer INCLUDE_FUTURE_TRUE = 1;
    
    public static final Integer INCLUDE_FUTURE_FALSE = 2;
    
    //角色相关
    public static final Long BASIC_ROLE_ID = 2L;
    
    public static final Integer SYSTEM_ROLE_TYPE = 1;
    
    public static final Integer COMMON_ROLE_TYPE = 2;
    
    public static final Integer SYSTEM_VISITOR_TYPE = 3;
    
    public static final Integer ZABBIX_ROLE_TYPE = 4;

    public static final String BASE_ROLE_CODE_PREFIX = "baseRole";
    public static final String SYSTEM_ROLE_GROUP_CODE_PREFIX = "systemRoleGroup";


    //角色组type  1系统角色组 2自定义角色组
    public static final Integer SYSTEM_ROLE_GROUP_TYPE = 1;
    
    public static final Integer COMMON_ROLE_GROUP_TYPE = 2;
    
    //功能资源相关
    public static final Integer TYPE_MENU = 1;
    
    public static final Integer TYPE_DATA_TYPE = 2;
    
    public static final Integer TYPE_DATA_FUNCTION = 3;
    
    public static final Integer TYPE_MENU_FUNCTION = 4;
    
    public static final Integer TYPE_VIEW_MENU_FUNCTION = 5;
    
    //用户组、角色配置
    public static final Integer ROLE_DISTRIBUTE_TYPE = 1;

    public static final Integer RROUP_DISTRIBUTE_TYPE = 2;

    //用户组类型 1 是普通用户组
    public static final Integer GROUP_TYPE_NORMAL = 1;

    //用户组类型 2 是属性用户组
    public static final Integer GROUP_TYPE_ATTRIBUTE = 2;

    //用户组类型3 是外部用户组
    public static final Integer GROUP_TYPE_EXTERNAL = 3;

    //用户组类型4 是圈子用户组
    public static final Integer GROUP_TYPE_CYCLE = 4;
    /**
     * 企业微信账号类型
     */
    public static final Long THIRD_NUMBER_WECOM_TYPE = 1L;

    /**
     * 钉钉账号类型
     */
    public static final Long THIRD_NUMBER_DINGDING_TYPE = 2L;

    /**
     * 钉钉账号类型
     */
    public static final Long THIRD_NUMBER_FEISHU_TYPE = 3L;
    
    /**
     * 微信公众号账号类型
     */
    public static final Long THIRD_NUMBER_WXPUSH_TYPE = 4L;
    
    
    /**
     * 圈子用户组下，搜索部门下用户 1，还是用户组下的用户2 类型
     */
    public static final Integer GROUP_SELECT_DEPARTMENT_USER_TYPE = 1;
    
    public static final Integer GROUP_SELECT_GROUP_USER_TYPE = 2;
    
    public static final Integer GROUP_SELECT_GROUP_ALL_TYPE = 3;
    
    //ldap
    public static final Integer LDAP_TYPE_TRUE = DbConstant.LDAP_TYPE_TRUE;

    public static final Integer LDAP_TYPE_FALSE = DbConstant.LDAP_TYPE_FALSE;

    public static final String LDAP_TYPE_TRUE_STRING = DbConstant.LDAP_TYPE_TRUE_STRING;

    public static final String LDAP_TYPE_FALSE_STRING = DbConstant.LDAP_TYPE_FALSE_STRING;
    
    public static final Integer LDAP_OPENLDAP_IMPORT_TYPE = 3;
    
    public static final Integer LDAP_AD_IMPORT_TYPE = 4;
    
    public static final String LDAP_MAPPING_TYPE = "mappingType";
    
    public static final String LDAP_MAPPING_TYPE_USER = "user";
    
    public static final String LDAP_MAPPING_TYPE_GROUP = "group";
    
    public static final String LDAP_MAPPING_TYPE_SUPER_GROUP = "superGroup";
    
    public static final String LDAP_USE_CONFIG_BACK = "back";
    
    public static final String LDAP_USE_CONFIG_FRONT = "front";
    
    public static final String LDAP_PRODUVCT_TYPE_OPENLDAP = "OpenLdap";
    
    public static final String LDAP_PRODUVCT_TYPE_AD = "Microsoft Active Directory";
    
    public static final Integer LDAP_QUERY_PAGE_SIZE = 1000;
    
    public static final String LDAP_MAPPING_USER_FIELD = "userField";
    
    public static final String LDAP_MAPPING_USER_EXTEND_FIELD = "userExtendField";
    
    public static final String LDAP_MAPPING_GROUP_FIELD = "groupField";
    
    public static final String LDAP_MAPPING_GROUP_EXTEND_FIELD = "groupExtendField";
    
    public static final String LDAP_MAPPING_LOCAL_ATTRIBUTE = "localAttr";
    
    public static final String LDAP_MAPPING_LDAP_ATTRIBUTE = "ldapAttr";
    
    public static final String LDAP_MAPPING_FIELD_CONFIG = "ldap.config.field.mapping";
    
    public static final String LDAP_AD_DN_FIELD = "distinguishedName";
    
    public static final String LDAP_AD_DEFAULT_UNIQUE_ID = "uSNCreated";
    
    public static final String LDAP_AD_DEFAULT_UPN_USER_ALIAS = "userPrincipalName";
    
    public static final String LDAP_AD_DEFAULT_SAN_USER_ALIAS = "sAMAccountName";
    
    public static final String LDAP_OPENLDAP_DN_FIELD = "entryDN";
    
    public static final String LDAP_OPENLDAP_DEFAULT_UNIQUE_ID = "entryUUID";
    
    public static final String LDAP_OPENLDAP_DEFAULT_USER_ALIAS = "cn";
    
    public static final String LDAP_DEFAULT_GROUP_NAME = "ou";
    
    public static final String LDAP_TEMPORARY_PLACEHOLDER_COMMA = "&XX---XX&";
    
    public static final String LDAP_TEMPORARY_PLACEHOLDER_OU = "&XX--OU--XX&";
    
    public static final String LDAP_TEMPORARY_PLACEHOLDER_DC = "&XX--DC--XX&";
    
    
    //sys_group_data_group type
    public static final Integer GROUP_DATA_GROUP_TYPE_MODULE = 1;
    
    public static final Integer GROUP_DATA_GROUP_TYPE_DATATYPE = 2;
    
    public static final Integer GROUP_DATA_GROUP_TYPE_DATAGROUP = 3;
    
    public static final Integer GROUP_DATA_GROUP_TYPE_DATA = 4;
    
    
    public static final String REQUEST_BASE_HEADER_USERID_NAME = "userId";
    
    public static final String REQUEST_BASE_HEADER_USER_NAME = "userName";
    
    public static final String REQUEST_BASE_HEADER_ACCOUNTID_NAME = "accountId";
    
    public static final String REQUEST_BASE_HEADER_TOP_ACCOUNT_ID_NAME = "topAccountId";
    
    public static final String REQUEST_BASE_HEADER_LANGUAGE_NAME = "language";
    
    public static final String REQUEST_BASE_HEADER_FORWARDED_USERIP = "X-Forwarded-For";
    
    public static final String REQUEST_BASE_HEADER_CURRENT_USERIP = "userIP";
    
    public static final String REQUEST_BASE_HEADER_CURRENT_USER_AGENT = "user-agent";
    
    
    //menu moduleCode
    public static final String DOUC_MODULE_CODE = "100";
    
    public static final String DOUC_MODULE_NAME = "DOUC";
    
    //加密 方式
    
    /**
     * sm2加密
     */
    public static final String ENCRYPTION_SM2_TYPE = "1";
    
    /**
     * AES
     */
    public static final String ENCRYPTION_AES_TYPE = "2";
    
    /**
     * sm2加密 sm3加密
     */
    public static final String ENCRYPTION_SM2SM3_TYPE = "3";
    
    // 租户相关
    public static final Integer MULTI_ACCOUNT_IS_TOP = 1;
    
    public static final Integer MULTI_ACCOUNT_IS_NOT_TOP = 2;
    
    // 租户，可见范围
    public static final Integer MULTI_ACCOUNT_VISIBLE_SCOPE_ONE = 1;
    
    public static final Integer MULTI_ACCOUNT_VISIBLE_SCOPE_TWO = 2;
    
    public static final Integer MULTI_ACCOUNT_VISIBLE_SCOPE_TREE = 3;
    
    // 部门是否是主次部门
    
    public static final Integer DOUC_DEPARTMENT_IS_MAIN = DbConstant.DOUC_DEPARTMENT_IS_MAIN;
    
    public static final Integer DOUC_DEPARTMENT_IS_NOT_MAIN = DbConstant.DOUC_DEPARTMENT_IS_NOT_MAIN;
    
    //部门最大负责人数量
    public static final Integer DOUC_DEPARTMENT_MAX_PERSON_NUM = 20;
    
    /**
     * 角色组数据管理
     */
    public static final String DOUC_DATATYPE_ROLE_GROUP_MANAGE_DATA_CODE = "1032101201";
    
    /**
     * 查看
     */
    public static final String DOUC_DATATYPE_ROLE_GROUP_DETAIL_CODE = "1033201301";
    
    /**
     * 编辑
     */
    public static final String DOUC_DATATYPE_ROLE_GROUP_UPDATE_CODE = "1033201302";
    
    /**
     * 删除
     */
    public static final String DOUC_DATATYPE_ROLE_GROUP_DELETE_CODE = "1033201303";
    
    /**
     * 角色数据管理
     */
    public static final String DOUC_DATATYPE_ROLE_MANAGE_DATA_CODE = "1032101202";
    
    /**
     * 查看
     */
    public static final String DOUC_DATATYPE_ROLE_DETAIL_CODE = "1032202301";
    
    /**
     * 编辑
     */
    public static final String DOUC_DATATYPE_ROLE_UPDATE_CODE = "1032202302";
    
    /**
     * 删除
     */
    public static final String DOUC_DATATYPE_ROLE_DELETE_CODE = "1032202303";
    
    /**
     * 功能权限
     */
    public static final String DOUC_DATATYPE_ROLE_MODULE_MENU_CODE = "1032202304";
    
    /**
     * 配置成员
     */
    public static final String DOUC_DATATYPE_ROLE_DISTRIBUTE_USER_CODE = "1032202305";
    
    /**
     * 批量移除
     */
    public static final String DOUC_DATATYPE_ROLE_DELETE_USERS_CODE = "1032202306";
    
    //douc dataCode
    
    /**
     * 机构&用户数据管理 的dataTypeCode
     */
    public static final String DOUC_DATATYPECODE_DEPARTMENT = "1002101202";
    
    public static final String DOUC_DATACODE_DEPARTMENT_COMPANY = "401-all";
    
    public static final String DOUC_DATACODE_DEPARTMENT_CURRENT_LOWER_LEVEL = "402-current";
    
    /**
     * 特定部门 的dataGroupCode
     */
    public static final String DOUC_DATACODE_DEPARTMENT_SPECIAL = "301";
    
    //部门查看
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_CHECK = "1003102301";
    
    //部门编辑
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_EDIT = "1003202302";
    
    //部门删除
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_DELETE = "1003202303";
    
    //部门起停
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_STATUS_UPDATE = "1003202304";
    
    //用户查看
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_USER_CHECK = "1003202305";
    
    //用户新增
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_ADD_USER = "1003202306";
    
    //用户编辑
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_EDIT_USER = "1003202307";
    
    //用户删除
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_DELETE_USER = "1003202308";
    
    //重置密码
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_RESET_SECRET_USER = "1003202309";
    
    //用户起停
    public static final String DOUC_FUNCTIONCODE_DEPARTMENT_STATUS_UPDATE_USER = "1003001310";
    
    /**
     * 用户组数据管理 的dataTypeCode
     */
    public static final String DOUC_DATATYPECODE_GROUP = "1042101201";
    
    public static final String DOUC_DATACODE_GROUP_COMPANY = "401-all";
    
    public static final String DOUC_DATACODE_GROUP_CURRENT_LOWER_LEVEL = "402-current";
    
    /**
     * 特定用户组 的dataGroupCode
     */
    public static final String DOUC_DATACODE_GROUP_SPECIAL = "301";
    
    //用户组查看
    public static final String DOUC_FUNCTIONCODE_GROUP_CHECK = "1043201301";
    
    //用户组编辑
    public static final String DOUC_FUNCTIONCODE_GROUP_EDIT = "1043201302";
    
    //用户组删除
    public static final String DOUC_FUNCTIONCODE_GROUP_DELETE = "1043201303";
    
    //用户组数据授权
    public static final String DOUC_FUNCTIONCODE_GROUP_DATA_AUTH = "1043201304";
    
    //用户组配置成员
    public static final String DOUC_FUNCTIONCODE_GROUP_DISTRIBUTE_USER = "1043201305";
    
    //用户组批量移除
    public static final String DOUC_FUNCTIONCODE_GROUP_REMOVE_USER = "1043201306";
    
    /**
     * 功能权限第二版 start
     */
    //角色配置用户
    public static final String DOUC_MENU_ROLE_DISTRIBUTE_USER_CODE = "1034101409";
    
    //用户组配置成员
    public static final String DOUC_MENU_GROUP_DISTRIBUTE_USER_CODE = "1044101404";
    
    /**
     * 数据权限第二版 start
     */
    //按业务tag
    public static final String BIZ_RESOURCE_DATA_TAG_MODEL = "2";
    
    public static final String BIZ_RESOURCE_DATA_TAG_MODELPARENT = "modelParent";
    
    //按模型tag
    public static final String BIZ_RESOURCE_DATA_TAG_GROUP = "1";
    
    //其他数据类型 dataType
    public static final String MULTITYPE_RESOURCE_DATA_DATATYPE_LOGGROUP = "logGroup";
    
    public static final String DEPARTMENT_RESOURCE_DATA_ALL_DEPARTMENT = "all";
    
    public static final String DEPARTMENT_RESOURCE_DATA_CURRENT_DEPARTMENT = "current";
    
    public static final String DEPARTMENT_RESOURCE_DATA_SPECIAL_DEPARTMENT = "special";
    
    //dataAuth dataType
    public static final String DATAAUTH_DATATYPE_CMDB_ALL = "0";
    
    public static final String DATAAUTH_DATATYPE_CMDB_BIZ = "1";
    
    public static final String DATAAUTH_DATATYPE_CMDB_MODEL = "2";
    
    /**
     * 数据权限第二版 end
     */
    //logo类型
    public static final Integer LOGO_LOGIN_PAGE = 1;
    
    public static final Integer LOGO_BACK_GROUND = 2;
    
    public static final Integer LOGO_BROWER_PAGE = 3;
    
    public static final Integer LOGO_PRODUCT_PAGE = 4;
    
    public static final Integer LOGO_IMAGE_SIZE_THREE_MB = 3 * 1024 * 1024;
    
    public static final Integer LOGO_IMAGE_SIZE_TWO_HUNDERED_KB = 200 * 1024;
    
    public static final Integer LOGO_IMAGE_SIZE_THIRTY_KB = 30 * 1024;
    
    public static final String LOGO_REGION_EN_GB = "en-gb";
    
    public static final String LOGO_REGION_ZH_CN = "zh-cn";
    
    public static final Integer LOGO_ENNAME_MAX_SIZE = 200;
    
    public static final Integer LOGO_CNNAME_MAX_SIZE = 12;
    
    /**
     * zabbix 用户组读写权限 3
     */
    public static final String DOUC_MENU_ROLE_ZABBIX_WRITE_READ_CODE = "3";
    
    /**
     * zabbix 用户组读权限 2
     */
    public static final String DOUC_MENU_ROLE_ZABBIX_READ_CODE = "2";
    
    /**
     * 短信提交方code 1 平台
     */
    public static final String DOUC_PHONE_MESSAGE_SYS_CODE = "1";
    
    /**
     * 短信提交方code 2 三一
     */
    public static final String DOUC_PHONE_MESSAGE_TF_CODE = "2";
    
    /**
     * 拓展属性-用户类型 1
     */
    public static final Integer DOUC_EXTEND_TYPE_USER_CODE = 1;
    
    /**
     * 拓展属性-用户类型 2
     */
    public static final Integer DOUC_EXTEND_TYPE_DEPARTMENT_CODE = 2;
    /**
     * 拓展属性-用户组类型 3
     */
    public static final Integer DOUC_EXTEND_TYPE_GROUP_CODE = 3;
    
    /**
     * 拓展属性-默认PAGESIZE
     */
    public static final Integer EXTEND_QUERY_MAX_PAGE_SIZE = 100;
    
    /**
     * 语言切换类型 中文
     */
    public static final String DOUC_LANGUGE_TYPE_ZH_CN = LanguageConstants.CHINESE_ZH_CN;
    
    /**
     * 语言切换类型 英文
     */
    public static final String DOUC_LANGUGE_TYPE_EN_US = LanguageConstants.ENGLISH_EN_US;
    
    /**
     * 语言切换类型 中文
     */
    public static final String DOUC_LANGUGE_TYPE_ZH_TW = LanguageConstants.CHINESE_ZH_TW;
    
    /**
     * 语言切换类型 英文
     */
    public static final String DOUC_ROLE_GROUP_SYSTEM_TYPE_ENGLISH = "System roles";
    
    public static final String DOUC_ROLE_ADMIN_ROLE = "系统管理员";
    
    public static final String DOUC_ROLE_BASE_ROLE = "基础角色";
    
    public static final String DOUC_ROLE_ADMIN_ROLE_ENGLISH = "Admin";
    
    public static final String DOUC_ROLE_BASE_ROLE_ENGLISH = "Basic roles";
    
    public static final String DOUC_ROLE_GROUP_SYSTEM_CODE = "system_role";
    
    public static final String DOUC_ROLE_ADMIN_ROLE_CODE = "admin";
    
    public static final String DOUC_ROLE_BASE_ROLE_CODE = "basic_role";
    
    /**
     * ldap-姓名-DB
     */
    public static final String DOUC_DIC_LDAP_NAME_CN = "name";
    
    /**
     * ldap-姓名-英文
     */
    public static final String DOUC_DIC_LDAP_NAME_EN = "name";
    
    /**
     * ldap-手机-DB
     */
    public static final String DOUC_DIC_LDAP_PHONE_CN = "mobile";
    
    /**
     * ldap-手机英文
     */
    public static final String DOUC_DIC_LDAP_PHONE_EN = "mobile";
    
    /**
     * ldap-邮箱-DB
     */
    public static final String DOUC_DIC_LDAP_EMAIL_CN = "email";
    
    /**
     * ldap-邮箱-英文
     */
    public static final String DOUC_DIC_LDAP_EMAIL_EN = "email";
    
    /**
     * ldap-座机-DB
     */
    public static final String DOUC_DIC_LDAP_TEL_CN = "phone";
    
    /**
     * ldap-座机-英文
     */
    public static final String DOUC_DIC_LDAP_TEL_EN = "phone";
    
    /**
     * ldap-钉钉账号-DB
     */
    public static final String DOUC_DIC_LDAP_DINGTALK_CN = "dingtalk_account";
    
    /**
     * ldap-钉钉账号-英文
     */
    public static final String DOUC_DIC_LDAP_DINGTALK_EN = "Dingtalk";
    
    /**
     * ldap-企业微信账号-DB
     */
    public static final String DOUC_DIC_LDAP_WECHAT_CN = "weixinwork_account";
    
    /**
     * ldap-企业微信账号-英文
     */
    public static final String DOUC_DIC_LDAP_WECHAT_EN = "Wecom";
    
    public static final String DOUC_DIC_LDAP_FEISHU_EN = "Feishu";
    
    /**
     * ldap-微信公众号账号-英文
     */
    public static final String DOUC_DIC_LDAP_WXPUSH_EN = "WxPush";
    
    /**
     * ldap-部门编码-DB
     */
    public static final String DOUC_DIC_LDAP_DEPARTMENT_CODE_CN = "code";
    
    /**
     * ldap-部门编码-英文
     */
    public static final String DOUC_DIC_LDAP_DEPARTMENT_CODE_EN = "code";
    
    /**
     * ldap-部门描述-DB
     */
    public static final String DOUC_DIC_LDAP_DESCRIPTION_CN = "description";
    
    /**
     * ldap-部门描述-英文
     */
    public static final String DOUC_DIC_LDAP_DESCRIPTION_EN = "description";
    
    /**
     * 邮寄待回复 acount invite status
     */
    public static final Integer DOUC_ACCOUNT_INVITE_STATUS_ANSWERING = 1;
    
    /**
     * 邮寄已通过
     */
    public static final Integer DOUC_ACCOUNT_INVITE_STATUS_PROCESSED = 2;
    
    /**
     * 邮寄已拒绝
     */
    public static final Integer DOUC_ACCOUNT_INVITE_STATUS_REJECTED = 3;
    
    /**
     * 邮寄已撤销
     */
    public static final Integer DOUC_ACCOUNT_INVITE_STATUS_CANCELLED = 4;
    
    /**
     * 邮寄发送失败
     */
    public static final Integer DOUC_ACCOUNT_INVITE_STATUS_SEND_FAILURE = 5;
    
    /**
     * 邮寄已过期
     */
    public static final Integer DOUC_ACCOUNT_INVITE_STATUS_EXPIRED = 6;
    
    //系统设置多点登陆
    public static final String SYSTEM_SETTINT_MULTI_POINT_LOGIN = "multiPointLogin";
    
    public static final String SYSTEM_SETTINT_SECONDAR_AUTH = "openSecondaryAuthentication";
    
    public static final String SYSTEM_SETTINT_ADMINISTRATOR_NAME = "administratorName";
    
    public static final String SYSTEM_SETTINT_MESSAGE_TEMPLATE = "secondaryAuthenticationTemplate";
    
    public static final String SYSTEM_OPEN_SECOND_ARYAUTHENTICATION = "openSecondaryAuthentication";
    
    //操作字典值
    public static final String DIC_TYPE_CODE = "operate";
    
    //职位字典值
    public static final String DIC_POSITION_CODE = "position";
    
    public static final String GATEWAY_MODULE_CODE = "116";
    
    public static final String GATEWAY_MODULE_NAME = "gateway";
    
    //字段管理类型
    public static final Integer USER_TYPE = 1;
    
    public static final Integer ORG_TYPE = 2;
    
    //日志结果
    public static final String LOG_SUCCESS = "1";
    
    public static final String LOG_FAIL = "2";
    
    //身份源同步常量--start
    //身份源数据同步记录数据类型
    //部门
    public static final int IDENTITY_DATA_SYNC_DATA_TYPE_DEPARTMENT = 1;
    
    //用户
    public static final int IDENTITY_DATA_SYNC_DATA_TYPE_USER = 2;
    
    //身份源数据同步记录操作类型
    //新增
    public static final int IDENTITY_DATA_SYNC_OPERATE_TYPE_ADD = 1;
    
    //修改
    public static final int IDENTITY_DATA_SYNC_OPERATE_TYPE_UPDATE = 2;
    
    //删除
    public static final int IDENTITY_DATA_SYNC_OPERATE_TYPE_DELETE = 3;
    
    //身份源数据同步记录状态
    //初始化
    public static final int IDENTITY_DATA_SYNC_STATUS_INIT = 0;
    
    //成功
    public static final int IDENTITY_DATA_SYNC_STATUS_SUCCEED = 1;
    
    //失败
    public static final int IDENTITY_DATA_SYNC_STATUS_FAILED = 2;
    
    //身份源数据同步记录同步类型
    //手动
    public static final int IDENTITY_DATA_SYNC_STATUS_MANUAL = 1;
    
    //定时
    public static final int IDENTITY_DATA_SYNC_STATUS_TIMING = 2;
    
    //实时
    public static final int IDENTITY_DATA_SYNC_STATUS_REALTIME = 3;
    
    //身份源钉钉accessToken缓存key
    public static final Object IDENTITY_DINGDING_ACCESSTOKEN_APPKEY = "IDENTITY_DINGDING_ACCESSTOKEN_APPKEY";
    
    //身份源钉钉accessToken缓存时间
    public static final long IDENTITY_DINGDING_ACCESSTOKEN_EXPIRE_TIME = 5400L;
    
    //身份源飞书accessToken缓存key
    public static final Object IDENTITY_FEISHU_ACCESSTOKEN_APPKEY = "IDENTITY_FEISHU_ACCESSTOKEN_APPKEY";
    
    //身份源飞书accessToken缓存时间
    public static final long IDENTITY_FEISHU_ACCESSTOKEN_EXPIRE_TIME = 5400L;
    
    //身份源删除策略
    //禁用
    public static final int IDENTITY_DATA_SYNC_DELETE_STRATEGY_DISABLE = 2;
    
    //删除
    public static final int IDENTITY_DATA_SYNC_DELETE_STRATEGY_DELETE = 1;
    
    //双因子认证
    // 手机验证码发送锁定key
    public static final Object REDIS_CACHE_KEY_DOUC_MOBILE_VERIFYCODE_LOCKET_KEY = "DOUBLE_FACTOR_CERTIFICATION:DOUC_MOBILE_VERIFY_CODE_LOCK:";
    
    //手机验证码一天内最多发送次数
    public static final Integer MOBILE_VERIFY_DEFAULT_SEND_LIMIT = 200;
    
    //手机验证码发送锁定key
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_VERIFY_CODE_MAX_SEND_LIMIT_KEY = "DOUBLE_FACTOR_CERTIFICATION:DOUC_MOBILE_VERIFY_CODE:SEND_LIMIT:";
    
    //手机验证码缓存key
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_VERIFY_CODE_KEY = "DOUBLE_FACTOR_CERTIFICATION:DOUC_MOBILE_VERIFY_CODE:";
    
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_VERIFY_CODE_SSO_KEY = "MOBILE_LOGIN_CACHE:DOUC_MOBILE_VERIFY_CODE:";
    
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_LOGIN_VERIFY_CODE_MAX_SEND_FLAG_KEY = "MOBILE_LOGIN_CACHE:DOUC_MOBILE_VERIFY_CODE:SEND_FLAG:";
    
    //手机验证码有效期
    public static final long MOBILE_VERIFY_CODE_EXPIRE_TIME = 2 * 60L;
    
    //短信模板
    //public static final String MOBILE_VERIFY_DEFAULT_TEMPLATE = "【云智慧】验证码：${code}， 2分钟内有效。尊敬的用户，您正在通过手机号进行二次认证，为了自己的账号安全，请不要告诉他人哦，如非本人，请忽略。";
    //手机验证嘛发送时间间隔
    public static final Long MOBILE_VERIFY_CODE_SEND_LOCK_TIME = 60L;
    
    //用户手机号发送错误次数太多
    public static final String USER_ERROR_MESSAGE_TIME_NAME = "DOUBLE_FACTOR_CERTIFICATION:DOUC_MOBILE_ERROR_MESSAGE:";
    
    // 手机验证码发送锁定key
    public static final Object REDIS_CACHE_KEY_DOUC_MOBILE_SECURITY_KEY = "DOUBLE_FACTOR_CERTIFICATION:DOUC_MOBILE_SECURITY:";
    
    /**
     * 渠道配置
     **/
    public static final String CHANNEL_WECOM = "WECOM";
    
    public static final String CHANNEL_FEISHU = "FEISHU";
    
    public static final String CHANNEL_DINGTALK = "DINGTALK";
    
    public static final String CHANNEL_OFFICIAL_ACCOUNT = "WXPUSH";
    
    public static final String CHANNEL_CONFIG_KEY = "channelConfigKey";
    
    //身份源同步常量--end
    
    public static final String CHANNEL_WECOM_CODE = "channelCode";
    
    public static final String CHANNEL_WECOM_INTEGRATED_TYPE = "IntegratedType";
    
    public static final String CHANNEL_WECOM_PRODUCT_MODULE = "ProductModule";
    
    public static final String CHANNEL_WECOM_CHANNEL_WECOM_NAME = "ChannelName";
    
    public static final String CHANNEL_WECOM_ASSOCIATE_SOURCE = "AssociateSourceAttribute";
    
    public static final String CHANNEL_WECOM_ASSOCIATE_USER = "AssociateUserAttribute";
    
    public static final String CHANNEL_WECOM_HOMEPAGE_ADDRESS = "HomepageAddress";
    
    public static final String CHANNEL_WECOM_DOMAIN_NAME = "AuthorizedTrustedDomainName";
    
    public static final String CHANNEL_WXPUSH_AGENT_ID = "AppID";
    
    public static final String CHANNEL_WXPUSH_SECRET = "AppSecret";
    
    public static final String CHANNEL_WXPUSH_OPEN_ID_FIELD = "OpenIdField";
    
    public static final String CHANNEL_WXPUSH_DEFAULT_MODULE = "1";
    
    public static final String CHANNEL_WXPUSH_DEFAULT_CHANNEL_NAME = "微信服务号免密登录";
    
    public static final String CHANNEL_WXPUSH_OPNE_ID = "openId";
    
    public static final String CHANNEL_WXPUSH_WXPUSH_ACCOUNT = "wxpushAccount";
    
    public static final String CHANNEL_WXPUSH_EXTEND_OPEN_ID = "extend.wx_open_id";
    
    public static final String CHANNEL_WXPUSH_MODULE_OTHERS_URL = "channel.wxpush.desktop.module.999";
    
    public static final String CHANNEL_WECOM_APP_ID = "appId";
    
    public static final String CHANNEL_WECOM_ENTERPRISE_ID = "EnterpriseId";
    
    public static final String CHANNEL_WECOM_AGENT_ID = "AgentId";
    
    public static final String CHANNEL_WECOM_SECRET = "Secret";
    
    public static final String CHANNEL_WECOM_DEFAULT_CREATE_TIME = "2019-01-01 00:00:00.0";
    
    public static final String CHANNEL_WECOM_DEFAULT_CHANNEL_NAME = "自建应用免密登录";
    
    public static final String CHANNEL_WECOM_WEXIN_USER_ID = "userid";
    
    public static final String CHANNEL_WECOM_MODULE_OTHERS_URL = "channel.wecom.module.999";
    
    public static final String CHANNEL_WECOM_MODULE_OTHERS = "Others";
    
    public static final String CHANNEL_FEISHU_CODE = "channelCode";
    
    public static final String CHANNEL_FEISHU_INTEGRATED_TYPE = "IntegratedType";
    
    public static final String CHANNEL_FEISHU_PRODUCT_MODULE = "ProductModule";
    
    public static final String CHANNEL_FEISHU_CHANNEL_WECOM_NAME = "ChannelName";
    
    public static final String CHANNEL_FEISHU_ASSOCIATE_SOURCE = "AssociateSourceAttribute";
    
    public static final String CHANNEL_FEISHU_ASSOCIATE_USER = "AssociateUserAttribute";
    
    public static final String CHANNEL_FEISHU_DESKTOP_HOMEPAGE_ADDRESS = "DesktopHomepageAddress";
    
    public static final String CHANNEL_FEISHU_MOBILE_HOMEPAGE_ADDRESS = "MobileHomepageAddress";
    
    public static final String CHANNEL_FEISHU_APP_ID = "AppID";
    
    public static final String CHANNEL_FEISHU_SECRET = "Secret";
    
    public static final String CHANNEL_FEISHU_DEFAULT_CREATE_TIME = "2019-01-01 00:00:00.0";
    
    public static final String CHANNEL_FEISHU_MODULE_OTHERS_DESKTOP_URL = "channel.feishu.module.Others.desktop";
    
    public static final String CHANNEL_FEISHU_MODULE_OTHERS_MOBILE_URL = "channel.feishu.module.Others.mobile";
    
    public static final String CHANNEL_FEISHU_REDIRECT_URL = "RedirectURLs";
    
    public static final String CHANNEL_FEISHU_EXTEND_TYPE = "TEXT";
    
    public static final String CHANNEL_DINGDING_CODE = "channelCode";
    
    public static final String CHANNEL_DINGDING_INTEGRATED_TYPE = "IntegratedType";
    
    public static final String CHANNEL_DINGDING_PRODUCT_MODULE = "ProductModule";
    
    public static final String CHANNEL_DINGDING_CHANNEL_NAME = "ChannelName";
    
    public static final String CHANNEL_DINGDING_AGENTID = "AgentId";
    
    public static final String CHANNEL_DINGDING_PROXYCORPID = "CorpId";
    
    public static final String CHANNEL_DINGDING_APP_KEY = "AppKey";
    
    public static final String CHANNEL_DINGDING_SECRET = "AppSecret";
    
    public static final String CHANNEL_DINGDING_ASSOCIATE_SOURCE = "AssociateSourceAttribute";
    
    public static final String CHANNEL_DINGDING_ASSOCIATE_USER = "AssociateUserAttribute";
    
    public static final String CHANNEL_DINGDING_MOBILE_HOMEPAGE_ADDRESS = "AppHomeAddress";
    
    public static final String CHANNEL_DINGDING_DESKTOP_HOMEPAGE_ADDRESS = "PCHomeAddress";
    
    public static final String CHANNEL_DINGDING_DEFAULT_CREATE_TIME = "2019-01-01 00:00:00.0";
    
    public static final String CHANNEL_SMS_DEFAULT_CHANNEL_NAME = "内置短信";
    
    public static final String CHANNEL_AZURE_METADATA_URL = "元数据url";
    
    public static final String CHANNEL_AZURE_LOGIN_URL = "登录url";
    
    //手机号登录类型
    public static final String MOBIE_LOGIN_TYPE = "2";
    
    public static final String SECONDARY_AUTHENTICATION_TYPE = "1";
    
    /**
     * email相关常量 start
     */
    public static final String EMAIL_SUBJECT_EN_US = "Email verification code";
    
    public static final String EMAIL_TEMPLATE_RESET_PW_EN_US = "<head>\n" + "  <base target=\"_blank\" />\n"
            + "  <style type=\"text/css\">::-webkit-scrollbar{ display: none; }</style>\n"
            + "  <style id=\"cloudAttachStyle\" type=\"text/css\">#divNeteaseBigAttach, #divNeteaseBigAttach_bak{display:none;}</style>\n"
            + "  <style id=\"blockquoteStyle\" type=\"text/css\">blockquote{display:none;}</style>\n"
            + "  <style type=\"text/css\">\n"
            + "      body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}\n"
            + "      td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}\n"
            + "      pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;width:95%}\n"
            + "      th,td{font-family:arial,verdana,sans-serif;line-height:1.666}\n" + "      img{ border:0}\n"
            + "      header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}\n"
            + "      blockquote{margin-right:0px}\n" + "  </style>\n" + "</head>\n"
            + "<body tabindex=\"0\" role=\"listitem\">\n"
            + "<table width=\"700\" border=\"0\" align=\"center\" cellspacing=\"0\" style=\"width:700px;\">\n"
            + "  <tbody>\n" + "  <tr>\n" + "      <td>\n"
            + "          <div style=\"width:700px;margin:0 auto;margin-bottom:30px;\">\n"
            + "              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"700\" height=\"39\" style=\"font:12px Tahoma, Arial, 宋体;\">\n"
            + "                  <tbody><tr><td width=\"210\"></td></tr></tbody>\n" + "              </table>\n"
            + "          </div>\n" + "          <div style=\"width:680px;padding:0 10px;margin:0 auto;\">\n"
            + "              <div style=\"line-height:1.5;font-size:14px;margin-bottom:25px;color:#4d4d4d;\">\n"
            + "                  <strong style=\"display:block;\">Dear user:<span style=\"color:#f60;font-size: 16px;\"></span></strong>\n"
            + "                  <strong style=\"display:block;margin-bottom:50px;\">\n"
            + "                      You are resetting password.Enter <span style=\"font-size: 24px\">{VerifyCode}</span>，in the input box to complete the operation.\n"
            + "                  </strong>\n" + "              </div>\n"
            + "              <div style=\"margin-bottom:30px;\">\n"
            + "                  <small style=\"display:block;margin-bottom:20px;font-size:12px;\">\n"
            + "                      <p style=\"color:#747474;\">\n"
            + "                          Note: If it is operated by yourself, log in in time and change your password to ensure account security. \n"
            + "                          <br>（The staff will not ask you for this verification code, The staff will not ask you for this verification code, please do not disclose it.)\n"
            + "                      </p>\n" + "                  </small>\n" + "              </div>\n"
            + "          </div>\n" + "          <div style=\"width:700px;margin:0 auto;\">\n"
            + "              <div style=\"padding:10px 10px 0;color:#747474;margin-bottom:20px;line-height:1.3em;font-size:12px;\">\n"
            + "                  <p>This is a system email, please do not reply<br>\n"
            + "                      Please keep your email address to avoid the account being stolen by others\n"
            + "                  </p>\n" + "              </div>\n" + "          </div>\n" + "      </td>\n"
            + "  </tr>\n" + "  </tbody>\n" + "</table>\n" + "</body>";
    
    public static final String EMAIL_TEMPLATE_RESET_PW_ZH_CN = "<head>\n" + "  <base target=\"_blank\" />\n"
            + "  <style type=\"text/css\">::-webkit-scrollbar{ display: none; }</style>\n"
            + "  <style id=\"cloudAttachStyle\" type=\"text/css\">#divNeteaseBigAttach, #divNeteaseBigAttach_bak{display:none;}</style>\n"
            + "  <style id=\"blockquoteStyle\" type=\"text/css\">blockquote{display:none;}</style>\n"
            + "  <style type=\"text/css\">\n"
            + "      body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}\n"
            + "      td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}\n"
            + "      pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;width:95%}\n"
            + "      th,td{font-family:arial,verdana,sans-serif;line-height:1.666}\n" + "      img{ border:0}\n"
            + "      header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}\n"
            + "      blockquote{margin-right:0px}\n" + "  </style>\n" + "</head>\n"
            + "<body tabindex=\"0\" role=\"listitem\">\n"
            + "<table width=\"700\" border=\"0\" align=\"center\" cellspacing=\"0\" style=\"width:700px;\">\n"
            + "  <tbody>\n" + "  <tr>\n" + "      <td>\n"
            + "          <div style=\"width:700px;margin:0 auto;margin-bottom:30px;\">\n"
            + "              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"700\" height=\"39\" style=\"font:12px Tahoma, Arial, 宋体;\">\n"
            + "                  <tbody><tr><td width=\"210\"></td></tr></tbody>\n" + "              </table>\n"
            + "          </div>\n" + "          <div style=\"width:680px;padding:0 10px;margin:0 auto;\">\n"
            + "              <div style=\"line-height:1.5;font-size:14px;margin-bottom:25px;color:#4d4d4d;\">\n"
            + "                  <strong style=\"display:block;\">尊敬的用户：<span style=\"color:#f60;font-size: 16px;\"></span>您好！</strong>\n"
            + "                  <strong style=\"display:block;margin-bottom:50px;\">\n"
            + "                      您正在进行重置密码操作，请在验证码输入框中输入：<span style=\"font-size: 24px\">{VerifyCode}</span>，以完成操作。\n"
            + "                  </strong>\n" + "              </div>\n"
            + "              <div style=\"margin-bottom:30px;\">\n"
            + "                  <small style=\"display:block;margin-bottom:20px;font-size:12px;\">\n"
            + "                      <p style=\"color:#747474;\">\n"
            + "                          注意：如非本人操作，请及时登录并修改密码以保证帐户安全\n"
            + "                          <br>（工作人员不会向你索取此验证码，请勿泄漏！)\n"
            + "                      </p>\n" + "                  </small>\n" + "              </div>\n"
            + "          </div>\n" + "          <div style=\"width:700px;margin:0 auto;\">\n"
            + "              <div style=\"padding:10px 10px 0;color:#747474;margin-bottom:20px;line-height:1.3em;font-size:12px;\">\n"
            + "                  <p>此为系统邮件，请勿回复<br>\n" + "                      请保管好您的邮箱，避免账号被他人盗用\n"
            + "                  </p>\n" + "              </div>\n" + "          </div>\n" + "      </td>\n"
            + "  </tr>\n" + "  </tbody>\n" + "</table>\n" + "</body>";
    
    public static final String EMAIL_TEMPLATE_RETRIEVE_PW_ZH_CN = "<head>\n" + "  <base target=\"_blank\" />\n"
            + "  <style type=\"text/css\">::-webkit-scrollbar{ display: none; }</style>\n"
            + "  <style id=\"cloudAttachStyle\" type=\"text/css\">#divNeteaseBigAttach, #divNeteaseBigAttach_bak{display:none;}</style>\n"
            + "  <style id=\"blockquoteStyle\" type=\"text/css\">blockquote{display:none;}</style>\n"
            + "  <style type=\"text/css\">\n"
            + "      body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}\n"
            + "      td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}\n"
            + "      pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;width:95%}\n"
            + "      th,td{font-family:arial,verdana,sans-serif;line-height:1.666}\n" + "      img{ border:0}\n"
            + "      header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}\n"
            + "      blockquote{margin-right:0px}\n" + "  </style>\n" + "</head>\n"
            + "<body tabindex=\"0\" role=\"listitem\">\n"
            + "<table width=\"700\" border=\"0\" align=\"center\" cellspacing=\"0\" style=\"width:700px;\">\n"
            + "  <tbody>\n" + "  <tr>\n" + "      <td>\n"
            + "          <div style=\"width:700px;margin:0 auto;margin-bottom:30px;\">\n"
            + "              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"700\" height=\"39\" style=\"font:12px Tahoma, Arial, 宋体;\">\n"
            + "                  <tbody><tr><td width=\"210\"></td></tr></tbody>\n" + "              </table>\n"
            + "          </div>\n" + "          <div style=\"width:680px;padding:0 10px;margin:0 auto;\">\n"
            + "              <div style=\"line-height:1.5;font-size:14px;margin-bottom:25px;color:#4d4d4d;\">\n"
            + "                  <strong style=\"display:block;\">尊敬的用户：<span style=\"color:#f60;font-size: 16px;\"></span>您好！</strong>\n"
            + "                  <strong style=\"display:block;margin-bottom:50px;\">\n"
            + "                      您正在进行重置密码操作，请在验证码输入框中输入：<span style=\"font-size: 24px\">{VerifyCode}</span>，以完成操作。\n"
            + "                  </strong>\n" + "              </div>\n"
            + "              <div style=\"margin-bottom:30px;\">\n"
            + "                  <small style=\"display:block;margin-bottom:20px;font-size:12px;\">\n"
            + "                      <p style=\"color:#747474;\">\n"
            + "                          注意：如非本人操作，请及时登录并修改密码以保证帐户安全\n"
            + "                          <br>（工作人员不会向你索取此验证码，请勿泄漏！)\n"
            + "                      </p>\n" + "                  </small>\n" + "              </div>\n"
            + "          </div>\n" + "          <div style=\"width:700px;margin:0 auto;\">\n"
            + "              <div style=\"padding:10px 10px 0;color:#747474;margin-bottom:20px;line-height:1.3em;font-size:12px;\">\n"
            + "                  <p>此为系统邮件，请勿回复<br>\n" + "                      请保管好您的邮箱，避免账号被他人盗用\n"
            + "                  </p>\n" + "              </div>\n" + "          </div>\n" + "      </td>\n"
            + "  </tr>\n" + "  </tbody>\n" + "</table>\n" + "</body>";
    
    public static final String EMAIL_TEMPLATE_RETRIEVE_PW_EN_US = "<head>\n" + "  <base target=\"_blank\" />\n"
            + "  <style type=\"text/css\">::-webkit-scrollbar{ display: none; }</style>\n"
            + "  <style id=\"cloudAttachStyle\" type=\"text/css\">#divNeteaseBigAttach, #divNeteaseBigAttach_bak{display:none;}</style>\n"
            + "  <style id=\"blockquoteStyle\" type=\"text/css\">blockquote{display:none;}</style>\n"
            + "  <style type=\"text/css\">\n"
            + "      body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}\n"
            + "      td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}\n"
            + "      pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;width:95%}\n"
            + "      th,td{font-family:arial,verdana,sans-serif;line-height:1.666}\n" + "      img{ border:0}\n"
            + "      header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}\n"
            + "      blockquote{margin-right:0px}\n" + "  </style>\n" + "</head>\n"
            + "<body tabindex=\"0\" role=\"listitem\">\n"
            + "<table width=\"700\" border=\"0\" align=\"center\" cellspacing=\"0\" style=\"width:700px;\">\n"
            + "  <tbody>\n" + "  <tr>\n" + "      <td>\n"
            + "          <div style=\"width:700px;margin:0 auto;margin-bottom:30px;\">\n"
            + "              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"700\" height=\"39\" style=\"font:12px Tahoma, Arial, 宋体;\">\n"
            + "                  <tbody><tr><td width=\"210\"></td></tr></tbody>\n" + "              </table>\n"
            + "          </div>\n" + "          <div style=\"width:680px;padding:0 10px;margin:0 auto;\">\n"
            + "              <div style=\"line-height:1.5;font-size:14px;margin-bottom:25px;color:#4d4d4d;\">\n"
            + "                  <strong style=\"display:block;\">Dear user:<span style=\"color:#f60;font-size: 16px;\"></span></strong>\n"
            + "                  <strong style=\"display:block;margin-bottom:50px;\">\n"
            + "                      You are recovering password.Enter <span style=\"font-size: 24px\">{VerifyCode}</span>，in the input box to complete the operation.\n"
            + "                  </strong>\n" + "              </div>\n"
            + "              <div style=\"margin-bottom:30px;\">\n"
            + "                  <small style=\"display:block;margin-bottom:20px;font-size:12px;\">\n"
            + "                      <p style=\"color:#747474;\">\n"
            + "                          Note: If it is operated by yourself, log in in time and change your password to ensure account security. \n"
            + "                          <br>（The staff will not ask you for this verification code, The staff will not ask you for this verification code, please do not disclose it.)\n"
            + "                      </p>\n" + "                  </small>\n" + "              </div>\n"
            + "          </div>\n" + "          <div style=\"width:700px;margin:0 auto;\">\n"
            + "              <div style=\"padding:10px 10px 0;color:#747474;margin-bottom:20px;line-height:1.3em;font-size:12px;\">\n"
            + "                  <p>This is a system email, please do not reply<br>\n"
            + "                      Please keep your email address to avoid the account being stolen by others\n"
            + "                  </p>\n" + "              </div>\n" + "          </div>\n" + "      </td>\n"
            + "  </tr>\n" + "  </tbody>\n" + "</table>\n" + "</body>";
    
    public static final String EMAIL_TEMPLATE_UPDATE_LOGIN_EMAIL_EN_US = "<head>\n" + "  <base target=\"_blank\" />\n"
            + "  <style type=\"text/css\">::-webkit-scrollbar{ display: none; }</style>\n"
            + "  <style id=\"cloudAttachStyle\" type=\"text/css\">#divNeteaseBigAttach, #divNeteaseBigAttach_bak{display:none;}</style>\n"
            + "  <style id=\"blockquoteStyle\" type=\"text/css\">blockquote{display:none;}</style>\n"
            + "  <style type=\"text/css\">\n"
            + "      body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}\n"
            + "      td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}\n"
            + "      pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;width:95%}\n"
            + "      th,td{font-family:arial,verdana,sans-serif;line-height:1.666}\n" + "      img{ border:0}\n"
            + "      header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}\n"
            + "      blockquote{margin-right:0px}\n" + "  </style>\n" + "</head>\n"
            + "<body tabindex=\"0\" role=\"listitem\">\n"
            + "<table width=\"700\" border=\"0\" align=\"center\" cellspacing=\"0\" style=\"width:700px;\">\n"
            + "  <tbody>\n" + "  <tr>\n" + "      <td>\n"
            + "          <div style=\"width:700px;margin:0 auto;margin-bottom:30px;\">\n"
            + "              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"700\" height=\"39\" style=\"font:12px Tahoma, Arial, 宋体;\">\n"
            + "                  <tbody><tr><td width=\"210\"></td></tr></tbody>\n" + "              </table>\n"
            + "          </div>\n" + "          <div style=\"width:680px;padding:0 10px;margin:0 auto;\">\n"
            + "              <div style=\"line-height:1.5;font-size:14px;margin-bottom:25px;color:#4d4d4d;\">\n"
            + "                  <strong style=\"display:block;\">Dear user:<span style=\"color:#f60;font-size: 16px;\"></span></strong>\n"
            + "                  <strong style=\"display:block;margin-bottom:50px;\">\n"
            + "                      You are  modifying login email.Enter <span style=\"font-size: 24px\">{VerifyCode}</span>，in the input box to complete the operation.\n"
            + "                  </strong>\n" + "              </div>\n"
            + "              <div style=\"margin-bottom:30px;\">\n"
            + "                  <small style=\"display:block;margin-bottom:20px;font-size:12px;\">\n"
            + "                      <p style=\"color:#747474;\">\n"
            + "                          Note: If it is operated by yourself, log in in time and change your password to ensure account security. \n"
            + "                          <br>（The staff will not ask you for this verification code, The staff will not ask you for this verification code, please do not disclose it.)\n"
            + "                      </p>\n" + "                  </small>\n" + "              </div>\n"
            + "          </div>\n" + "          <div style=\"width:700px;margin:0 auto;\">\n"
            + "              <div style=\"padding:10px 10px 0;color:#747474;margin-bottom:20px;line-height:1.3em;font-size:12px;\">\n"
            + "                  <p>This is a system email, please do not reply<br>\n"
            + "                      Please keep your email address to avoid the account being stolen by others\n"
            + "                  </p>\n" + "              </div>\n" + "          </div>\n" + "      </td>\n"
            + "  </tr>\n" + "  </tbody>\n" + "</table>\n" + "</body>";
    
    public static final String EMAIL_TEMPLATE_UPDATE_LOGIN_EMAIL_ZH_CN = "<head>\n" + "  <base target=\"_blank\" />\n"
            + "  <style type=\"text/css\">::-webkit-scrollbar{ display: none; }</style>\n"
            + "  <style id=\"cloudAttachStyle\" type=\"text/css\">#divNeteaseBigAttach, #divNeteaseBigAttach_bak{display:none;}</style>\n"
            + "  <style id=\"blockquoteStyle\" type=\"text/css\">blockquote{display:none;}</style>\n"
            + "  <style type=\"text/css\">\n"
            + "      body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}\n"
            + "      td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}\n"
            + "      pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;width:95%}\n"
            + "      th,td{font-family:arial,verdana,sans-serif;line-height:1.666}\n" + "      img{ border:0}\n"
            + "      header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}\n"
            + "      blockquote{margin-right:0px}\n" + "  </style>\n" + "</head>\n"
            + "<body tabindex=\"0\" role=\"listitem\">\n"
            + "<table width=\"700\" border=\"0\" align=\"center\" cellspacing=\"0\" style=\"width:700px;\">\n"
            + "  <tbody>\n" + "  <tr>\n" + "      <td>\n"
            + "          <div style=\"width:700px;margin:0 auto;margin-bottom:30px;\">\n"
            + "              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"700\" height=\"39\" style=\"font:12px Tahoma, Arial, 宋体;\">\n"
            + "                  <tbody><tr><td width=\"210\"></td></tr></tbody>\n" + "              </table>\n"
            + "          </div>\n" + "          <div style=\"width:680px;padding:0 10px;margin:0 auto;\">\n"
            + "              <div style=\"line-height:1.5;font-size:14px;margin-bottom:25px;color:#4d4d4d;\">\n"
            + "                  <strong style=\"display:block;\">尊敬的用户：<span style=\"color:#f60;font-size: 16px;\"></span>您好！</strong>\n"
            + "                  <strong style=\"display:block;margin-bottom:50px;\">\n"
            + "                      您正在进行修改登录邮箱操作，请在验证码输入框中输入：<span style=\"font-size: 24px\">{VerifyCode}</span>，以完成操作。\n"
            + "                  </strong>\n" + "              </div>\n"
            + "              <div style=\"margin-bottom:30px;\">\n"
            + "                  <small style=\"display:block;margin-bottom:20px;font-size:12px;\">\n"
            + "                      <p style=\"color:#747474;\">\n"
            + "                          注意：如非本人操作，请及时登录并修改密码以保证帐户安全\n"
            + "                          <br>（工作人员不会向你索取此验证码，请勿泄漏！)\n"
            + "                      </p>\n" + "                  </small>\n" + "              </div>\n"
            + "          </div>\n" + "          <div style=\"width:700px;margin:0 auto;\">\n"
            + "              <div style=\"padding:10px 10px 0;color:#747474;margin-bottom:20px;line-height:1.3em;font-size:12px;\">\n"
            + "                  <p>此为系统邮件，请勿回复<br>\n" + "                      请保管好您的邮箱，避免账号被他人盗用\n"
            + "                  </p>\n" + "              </div>\n" + "          </div>\n" + "      </td>\n"
            + "  </tr>\n" + "  </tbody>\n" + "</table>\n" + "</body>";
    
    /**
     * 缓存常量 start
     */
    //手机验证码并发锁
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_GLOBAL_SYNC_LOCK_KEY = "SAAS_LOGIN_CACHE:DOUC_MOBILE_GLOBAL_SYNC_LOCK:";
    
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_VERIFY_CODE_SSO_LOCKET_KEY = "MOBILE_LOGIN_CACHE:DOUC_MOBILE_VERIFY_CODE_LOCK:";
    
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_VERIFY_CODE_SSO_MAX_SEND_LIMIT_KEY = "MOBILE_LOGIN_CACHE:DOUC_MOBILE_VERIFY_CODE:SEND_LIMIT:";
    
    public static final String MOBIE_LOGIN_CACHE_DOUC_MOBILE_VERIFY_CODE_ERROR_MESSAGE_KEY = "MOBILE_LOGIN_CACHE:DOUC_MOBILE_VERIFY_CODE_ERROR_MESSAGE:";
    
    //手机已发送key
    public static final String REDIS_CACHE_KEY_DOUC_MOBILE_VERIFY_CODE_MAX_SEND_FLAG_KEY = "MOBILE_CACHE:DOUC_MOBILE_VERIFY_CODE:SEND_FLAG:";
    
    /**
     * 登录方式
     */
    
    public static final String DEFAULT_AREA_CODE = "+86";
    
    public static final String REDIS_DOMAIN_CACHE_KEY = "DOUC:DOMAIN:";
    
    /**
     * 自定义上下文
     */
    public static final String CUSTOM_THREAD_LOCAL_KEY_OF_PROFESSION_USER = "professionUserInfo";
    
    /**
     * 特定的数据类型set,目前包含: 用户组数据管理,机构&用户数据管理
     */
    protected static final Set<String> DOUC_SPECIFIC_DATATYPE_CODE_SET = Sets.newHashSet(DOUC_DATATYPECODE_GROUP,
            DOUC_DATATYPECODE_DEPARTMENT);
    
    /**
     * 特定的数据分组set,目前包含: 特定部门,特定用户组
     */
    protected static final Set<String> DOUC_SPECIFIC_DATAGROUP_CODE_SET = Sets.newHashSet(
            DOUC_DATACODE_DEPARTMENT_SPECIAL, DOUC_DATACODE_GROUP_SPECIAL);
    
    /**
     * IDAP 中英文hashmap映射
     */
    private static final Map<String, String> IDAP_ITEMS = new HashMap<>();
    
    static {
        IDAP_ITEMS.put(DOUC_DIC_LDAP_NAME_EN, DOUC_DIC_LDAP_NAME_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_PHONE_EN, DOUC_DIC_LDAP_PHONE_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_EMAIL_EN, DOUC_DIC_LDAP_EMAIL_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_TEL_EN, DOUC_DIC_LDAP_TEL_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_DINGTALK_EN, DOUC_DIC_LDAP_DINGTALK_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_WECHAT_EN, DOUC_DIC_LDAP_WECHAT_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_DEPARTMENT_CODE_EN, DOUC_DIC_LDAP_DEPARTMENT_CODE_CN);
        IDAP_ITEMS.put(DOUC_DIC_LDAP_DESCRIPTION_EN, DOUC_DIC_LDAP_DESCRIPTION_CN);
    }
    
    public static Map<String, String> getIdapItems() {
        return IDAP_ITEMS;
    }
    
    public static final String CUSTOMISE_GROUP_CHECK_TIME_KEY = "DOUC:CUSTOMGROUP:UPDATETIME";
    
    /**
     * 将一批数据分割成多个 放入list
     */
    public static <T> List<List<T>> getBatch(List<T> list, Integer batchSize) {
        batchSize = Math.min(batchSize, 30000);
        if (list.size() < batchSize) {
            return Collections.singletonList(list);
        }
        List<List<T>> batch = Lists.newArrayListWithExpectedSize(list.size() / batchSize);
        Integer finalBatchSize = batchSize;
        Map<Integer, List<T>> groupedMap = list.stream().collect(Collectors.groupingBy(element -> list.indexOf(element) / finalBatchSize));
        batch.addAll(groupedMap.values());
        return batch;
    }
    
}
