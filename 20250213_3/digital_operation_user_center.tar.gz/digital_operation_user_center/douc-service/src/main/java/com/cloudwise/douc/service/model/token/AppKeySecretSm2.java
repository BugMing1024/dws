package com.cloudwise.douc.service.model.token;

import lombok.Data;

import java.io.Serializable;

/**
 * @author maker.wang
 * @description: 配置文件中的实体信息
 * @date Created in 2:50 下午 2021/6/2.
 */
@Data
public class AppKeySecretSm2 implements Serializable {

    private static final long serialVersionUID = 1813659502628622699L;
    /**
     * 应用
     */
    private String appKey;

    /**
     * 应用密钥
     */
    private String appSecret;

    /**
     * 用户别名
     */
    private String appName;

    /**
     * sm2加密后的appSecret:appSecret+"---"+timestamp传输 sm2加密
     */
    private String appSecretWithSm2;
    private String appSecretWithRsa;
}
