package com.cloudwise.douc.service.model.mq;

import lombok.Data;

import java.io.Serializable;

/**
 * 前台、后台数据同步mq消息体
 *
 * @author maker.wang
 * @date 2021-09-22 16:26
 **/
@Data
public class EnterpriseInfo implements Serializable {
    private static final long serialVersionUID = -6058105572214069401L;

    /**
     * 企业名称/顶级租户名称
     **/
    private String enterpriseName;

    /**
     * 企业id
     **/
    private String enterpriseId;

    /**
     * 企业内置管理员名称
     **/
    private String innerName;

    /**
     * 企业内置管理员别名
     **/
    private String innerUserAlias;

    /**
     * 企业内置内置管理员邮箱
     **/
    private String innerEmail;

    /**
     * 企业内置内置管理员手机号
     **/
    private String innerMobile;


    /**
     * 企业内置内置管理员手机号区号
     */
    private String innerMobileAreaCode;

    /**
     * 企业内置管理员密码
     **/
    private String innerPassword;

    /**
     * 内置数据国际化 内置数据国际化 中文：zh_CN 英文:en_US
     **/
    private String innerLanguage;

}
