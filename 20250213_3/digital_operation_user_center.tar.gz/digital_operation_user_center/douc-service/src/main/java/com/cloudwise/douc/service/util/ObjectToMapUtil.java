package com.cloudwise.douc.service.util;

import com.google.common.collect.Maps;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.Map;

public class ObjectToMapUtil {

    public static Map<String, String> convert(Object object) throws Exception {
        Class<?> clazz = object.getClass();
        Field[] declaredFields = clazz.getDeclaredFields();
        Map<String, String> map = Maps.newHashMapWithExpectedSize(declaredFields.length);
        for (Field field : declaredFields) {
            ReflectionUtils.makeAccessible(field);
            String value = field.get(object) != null ? field.get(object).toString() : "";
            map.put(field.getName(), value);
        }
        return map;
    }

}