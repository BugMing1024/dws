package com.cloudwise.douc.service.model.mq;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author zafir.zhong
 * @description 建单的渠道修改通知
 * @date Created in 13:45 2022/5/17.
 */
@Data
@NoArgsConstructor
public class AccountDeleteModifyNotice implements Serializable {
    private static final long serialVersionUID = 411438760363821486L;

    private String type;
    private long sendTime = System.currentTimeMillis();
    private AccountDeleteEntity accountDeleteEntity;


    public static class ModifyType {
        public static final String ADD = "ADD";
        public static final String DELETE = "DELETE";
        public static final String UPDATE = "UPDATE";
    }

}
