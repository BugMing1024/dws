package com.cloudwise.douc.service.util.file;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.text.StrPool;
import cn.hutool.core.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Set;

@Slf4j
public class FileUtils {


    private static final String FILE_NAME_INVALID = "[\\s\\\\/:\\*\\?\\\"<>\\|]";

    private FileUtils() {
        throw new IllegalStateException("FileUtils class");
    }

    public static String replaceInvalid(String fileName) {
        return replaceInvalid(fileName, StrPool.DASHED);
    }

    public static String replaceInvalid(String fileName, String r) {
        if (StringUtils.isBlank(r)) {
            r = StrPool.DASHED;
        }
        return StringUtils.isBlank(fileName) ? r : fileName.replaceAll(FILE_NAME_INVALID, r).trim();
    }

    /**
     * 文件探针 当父目录不存在时，创建目录！
     *
     * @param dirFile
     */
    public static final void fileProber(File dirFile) {
        int index = dirFile.getName().indexOf(StrPool.C_DOT);

        if (index == -1) {
            dirFile.mkdirs();
        } else {
            dirFile.getParentFile().mkdirs();
        }
    }

    /**
     * 获取文件扩展名
     *
     * @param fileName
     * @return
     */
    public static final String getFileExt(String fileName) {
        int len = fileName.lastIndexOf(StrPool.C_DOT);
        return len == -1 ? null : fileName.substring(len);
    }

    /**
     * 获取文件扩展名
     *
     * @param file
     * @return
     */
    public static final String getFileExt(File file) {
        return getFileExt(file.getName());
    }

    /**
     * 获取文件名，不包含扩展名
     *
     * @param fileName
     * @return
     */
    public static final String getFileName(String fileName) {
        int len = fileName.lastIndexOf(StrPool.C_DOT);
        return len == -1 ? fileName : fileName.substring(0, len);
    }

    public static final void deleteFileByThread(String filePath, long sleepTime) {
        deleteFileByThread(new File(filePath), sleepTime);
    }

    public static final void deleteFileByThread(File file, long sleep) {
        new Thread(() -> {
            try {
                Thread.sleep(sleep * 1000);
                deleteFile(file);
            } catch (Exception e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    public static final boolean deleteFile(String filePath) {
        return deleteFile(new File(filePath));
    }

    public static final boolean deleteFile(File file) {
        if (file == null || !file.exists()) {
            return true;
        }

        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                deleteFile(f);
            }
        }
        return file.delete();
    }

    public static final boolean deleteEmptyDir(File file) {
        if (file.isDirectory()) {
            String[] files = file.list();
            if (files == null || files.length == 0) {
                boolean delete = file.delete();
                if (!delete) {
                    log.error("delete file fail");
                }
                deleteEmptyDir(file.getParentFile());
                return true;
            }
        }
        if (file.isFile()) {
            boolean delete = file.delete();
            if (!delete) {
                log.error("delete file fail");
            }
            deleteEmptyDir(file.getParentFile());
            return true;
        }
        return false;
    }

    /**
     * 文件类型和文件大小校验
     *
     * @param file 上传的附件
     */
    public static boolean checkRealFileType(MultipartFile file) {
        boolean realFlag = true;
        String fileType;
        // 文件类型判断 - 校验文件后缀
        String fileName = file.getOriginalFilename();
        if (StringUtils.isBlank(fileName)) {
            realFlag = false;
        }
        String suffix = fileName.substring(fileName.lastIndexOf(StrPool.C_DOT) + 1);
        // 文件类型判断 - 校验文件头内容
        try (InputStream inputStream = file.getInputStream()) {
            // 获取到上传文件的文件头信息
            String fileHeader = FileUtils.getFileHeader(inputStream);
            if (StringUtils.isBlank(fileHeader)) {
                log.error("Failed to get file header content.");
                realFlag = false;
            }
            // 根据上传文件的后缀获取法定的文件头
            String validHeader = getHeaderByFileType(suffix);
            // 类型不匹配
            if (StrUtil.isNotBlank(validHeader) && fileHeader != null && !fileHeader.toUpperCase().startsWith(validHeader)) {
                realFlag = false;
            }
        } catch (IOException e) {
            log.error("Get file input stream failed.", e);
        }
        return realFlag;
    }

    /**
     * 文件类型校验
     *
     * @param fileType    待校验的类型
     * @param allowedType 允许上传的文件类型
     * @return true - 满足，false - 不满足
     */
    private static boolean fileTypeAllowed(String fileType, Set<String> allowedType) {
        if (StringUtils.isBlank(fileType) || CollectionUtil.isEmpty(allowedType)) {
            return false;
        }
        return allowedType.contains(fileType);
    }

    /**
     * 据文件的头信息获取文件类型
     *
     * @param fileHeader 文件头信息
     * @return 文件类型
     */
    public static String getFileType(String fileHeader) {
        if (fileHeader == null || fileHeader.length() == 0) {
            return null;
        }
        fileHeader = fileHeader.toUpperCase();
        FileTypeEnum[] fileTypes = FileTypeEnum.values();
        for (FileTypeEnum type : fileTypes) {
            boolean b = fileHeader.startsWith(type.getHeadCode());
            if (b) {
                return type.getSuffixName();
            }
        }
        return null;
    }

    public static String getHeaderByFileType(String fileType) {
        if (StrUtil.isBlank(fileType)) {
            return StrUtil.EMPTY;
        }
        fileType = fileType.toUpperCase();
        FileTypeEnum[] fileTypes = FileTypeEnum.values();
        String fileHeader = StrUtil.EMPTY;
        for (FileTypeEnum type : fileTypes) {
            if (type.getSuffixName().equalsIgnoreCase(fileType)) {
                fileHeader = type.getHeadCode();
                break;
            }
        }
        return fileHeader;
    }

    /**
     * 文件头字节数组转为十六进制编码
     *
     * @param content 文件头字节数据
     * @return 十六进制编码
     */
    private static String bytesToHexString(byte[] content) {
        StringBuilder builder = new StringBuilder();
        if (content == null || content.length <= 0) {
            return null;
        }
        String temp;
        for (byte b : content) {
            temp = Integer.toHexString(b & 0xFF).toUpperCase();
            if (temp.length() < 2) {
                builder.append(0);
            }
            builder.append(temp);
        }
        return builder.toString();
    }

    /**
     * 获取文件的文件头信息
     *
     * @param inputStream 输入流
     * @return 文件头信息
     * @throws IOException 异常
     */
    public static String getFileHeader(InputStream inputStream) throws IOException {
        byte[] content = new byte[28];
        inputStream.read(content, 0, content.length);
        return bytesToHexString(content);
    }

    /**
     * base64转化成 inputStream
     *
     * @param base64
     * @return
     */
    public static InputStream base64ToInputStream(String base64) {
        //获取到前缀的定位
        int index = base64.indexOf("base64,") + 7;
        base64 = base64.substring(index);
        ByteArrayInputStream stream = null;
        try {
            byte[] bytes = Base64.getDecoder().decode(base64);
            stream = new ByteArrayInputStream(bytes);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return stream;
    }


}
