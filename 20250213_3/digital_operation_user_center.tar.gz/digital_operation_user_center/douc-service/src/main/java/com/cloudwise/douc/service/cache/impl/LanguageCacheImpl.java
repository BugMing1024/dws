package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.service.cache.ILanguageCache;
import org.springframework.stereotype.Component;

@Component
public class LanguageCacheImpl implements ILanguageCache {

    @Override
    public String getLanguageCacheByUserId(Long accountId, Long userId) {
        return RedisTools.getByte(CacheConstant.REDIS_CACHE_KEY_DOUC_LANGUAGE_KEY + accountId + userId, String.class);
    }

    @Override
    public void setLanguageToCacheWithUserId(String language, Long accountId, Long userId) {
        //设置过期时间为15分
        RedisTools.setByteWithTime(CacheConstant.REDIS_CACHE_KEY_DOUC_LANGUAGE_KEY + accountId + userId, language, 3 * CacheConstant.FIVE_MINITE_DDL);
    }
}
