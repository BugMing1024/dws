package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import com.cloudwise.douc.metadata.model.data.DataAuthentication;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author ken.liang
 * @description:鉴权缓存接口
 * @date Created in 11:20 AM 2021/6/24.
 */
public interface IAuthCache {
    /**
     * @param accountId
     * @param roleIds
     * @param moduleCode 模块code
     * @return 角色id为key, 菜单权限为value
     * @description 根据模块code, 角色id获取菜单权限
     * @author ken.liang
     * @date 2021/6/23
     * @time 10:34 AM
     */
    Map<Long, List<MenuResponse>> getMenuAuthedByRoleIds(Long accountId, String moduleCode, List<Long> roleIds);

    /**
     * @param accountId
     * @param moduleCode
     * @param menuAuthedByRoleIdsMap
     * @return void
     * @description 缓存具体模块，角色拥有的菜单权限
     * @author ken.liang
     * @date 2021/6/23
     * @time 3:33 PM
     */
    void setMenuAuthedByRoleIds(Long accountId, String moduleCode, Map<Long, List<MenuResponse>> menuAuthedByRoleIdsMap);

    /**
     * @param accountId
     * @param moduleCode
     * @param roleIds
     * @return void
     * @description 删除角色菜单缓存
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:35 PM
     */
    void deleteMenuAuthedByRoleIds(Long accountId, List<String> moduleCodeList, List<Long> roleIds);


    /**
     * @param accountId
     * @param appCode
     * @param roleIds
     * @description 删除角色菜单缓存
     */
    void deleteViewMenuAuthedByRoleIds(Long accountId, List<String> appCodeList, List<Long> roleIds);

    /**
     * @param accountId
     * @param moduleCode
     * @return void
     * @description 缓存角色菜单缓存失效标记
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:35 PM
     */
    void setMenuAuthedByRoleIdsDirty(Long accountId, String moduleCode);

    /**
     * @param accountId
     * @param moduleCode
     * @return void
     * @description 缓存角色菜单视图缓存失效标记
     */
    void setViewMenuAuthedByRoleIdsDirty(Long accountId, String appCode);


    /**
     * @param accountId
     * @param dataType
     * @param roleIds
     * @return java.util.Map<java.lang.Long, java.util.List < com.cloudwise.douc.service.model.data.DataAuthentication>>
     * @description 根据数据类型，角色id获取数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 6:08 PM
     */
    Map<Long, List<DataAuthentication>> getDataAuthedByRoleIds(Long accountId, String dataType, List<Long> roleIds);

    /**
     * @param accountId
     * @param dataType
     * @param dataAuthedByRoleIdsMap
     * @return void
     * @description 缓存具体数据类型，角色拥有的数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 6:09 PM
     */
    void setDataAuthedByRoleIds(Long accountId, String dataType, Map<Long, List<DataAuthentication>> dataAuthedByRoleIdsMap);

    /**
     * @param accountId
     * @param dataTypeList
     * @param roleIds
     * @return void
     * @description 删除角色数据缓存
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:35 PM
     */
    void deleteDataAuthedByRoleIds(Long accountId, List<String> dataTypeList, List<Long> roleIds);


    /**
     * @param accountId
     * @param dataType
     * @return void
     * @description 缓存角色数据缓存失效标记
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:35 PM
     */
    void setDataAuthedByRoleIdsDirty(Long accountId, String dataType);

    /**
     * @param accountId
     * @param dataType
     * @param userId
     * @return java.util.List<com.cloudwise.douc.service.model.data.DataAuthentication>
     * @description 获取创建者拥有的其他数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 6:10 PM
     */
    List<DataAuthentication> getCreatorDataAuthed(Long accountId, String dataType, Long userId);

    /**
     * @param accountId
     * @param dataType
     * @param dataAuthenticationList
     * @param userId
     * @return void
     * @description 缓存创建者拥有的其他数据权限
     * @author ken.liang
     * @date 2021/6/24
     * @time 6:10 PM
     */
    void setCreatorDataAuthed(Long accountId, String dataType, List<DataAuthentication> dataAuthenticationList, Long userId);

    /**
     * @param accountId
     * @param dataType
     * @param userIdList
     * @return void
     * @description 删除创建者数据缓存
     * @author ken.liang
     * @date 2021/6/24
     * @time 7:35 PM
     */
    void deleteCreatorDataAuthed(Long accountId, String dataType, List<Long> userIdList);

    Map<Long, List<MenuResponse>> getViewMenuAuthedByRoleIds(Long accountId, String appCode, ArrayList<Long> roleIds);

    void setViewMenuAuthedByRoleIds(Long accountId, String appCode, Map<Long, List<MenuResponse>> noCacheViewMenuAuthedByModuleCodeAndRoleIdsMap);

}
