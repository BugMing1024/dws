package com.cloudwise.douc.service.model.auth;

import lombok.Data;

import java.io.Serializable;

/**
 * @author KenLiang
 * @description:
 * @date Created in 12:43 PM 2020/4/12.
 */
@Data
public class DataAuthGroupDataGroupRelation implements Serializable {
    private String functionCode;
    private String dataDataTypeCode;
    private String dataGroupLevel;
    private String dataGroupCode;
    private Integer groupDataGroupType;

}
