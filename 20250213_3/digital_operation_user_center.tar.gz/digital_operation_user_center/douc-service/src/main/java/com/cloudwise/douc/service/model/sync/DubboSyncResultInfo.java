package com.cloudwise.douc.service.model.sync;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Dubbo v2 部分失败响应实体
 *
 * @author maker.wang
 * @date 2021-11-08 17:30
 **/
@Data
@ApiModel("Dubbo v2 部分失败响应实体")
public class DubboSyncResultInfo implements Serializable {

    private static final long serialVersionUID = 5223399272426640283L;

    @ApiModelProperty(value = "(用户/部门)唯一编码")
    private List<String> dataCodes;
    @ApiModelProperty(value = "(用户/部门)id")
    private List<Long> dataIds;

    @ApiModelProperty(value = "失败错误码")
    private String failCode;

    @ApiModelProperty(value = "失败错误描述")
    private String failMsg;

}
