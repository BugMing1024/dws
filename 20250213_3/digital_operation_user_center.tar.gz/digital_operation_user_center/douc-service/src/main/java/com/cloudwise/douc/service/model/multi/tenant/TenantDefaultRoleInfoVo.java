package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.role.Role;
import com.cloudwise.douc.metadata.model.role.RoleGroup;
import lombok.Data;

import java.io.Serializable;

/**
 * 租户初始化角色信息
 *
 * @author maker.wang
 * @date 2021-06-30 14:18
 **/
@Data
public class TenantDefaultRoleInfoVo implements Serializable {
    private static final long serialVersionUID = -743425275105214295L;

    /**
     * 角色组
     **/
    private RoleGroup roleGroup;

    /**
     * 系统管理员角色
     **/
    private Role sysRole;

    /**
     * 普通角色
     **/
    private Role visitorRole;
}
