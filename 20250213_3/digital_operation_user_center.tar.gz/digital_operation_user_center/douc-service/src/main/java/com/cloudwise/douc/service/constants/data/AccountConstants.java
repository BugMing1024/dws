package com.cloudwise.douc.service.constants.data;

/**
 * 租户相关的关键字
 *
 * @author zafir zhong
 * @version 1.0.0
 * @date created at 2022/3/2 2:16 下午 ; update at
 */
public class AccountConstants {

    public static class Key {
        /**
         * 缓存前缀
         */
        public static final String ACCOUNT_PRE = "DOUC:MULTI_ACCOUNT:";
        /**
         * 拼接和拆分的标准记录
         */
        public static final String SPLIT = "_";
        /**
         * 保存缓存的后缀
         */
        public static final String RESULT_SUFFIX = "result";
        /**
         * 并发限制的后缀
         */
        public static final String CONCURRENT_LIMIT = "current";
        /**
         * 结果缓存时间和超时时间的多少倍
         */
        public static final long TIMEOUT_FOR_RESULT = 60;
        /**
         * 缺省的并发限制时间
         */
        public static final int DEFAULT_TIMEOUT = 60;
        /**
         * 通知其他产品的主题
         */
        public static final String TOPIC = "DOUC_ALL_ACCOUNT_SYNC";
        /**
         * 通知其他产品的配额主题
         */
        public static final String QUOTA = "DOUC_QUOTA_SYNC";
        /**
         *
         */
        public static final String TOP_LEVEL_TOPIC = "DOUC_ALL_ACCOUNT_TOP_LEVEL_SYNC";
        /**
         * 给网关传输信息的标记前缀
         */
        public static final String GATEWAY_PAUSE_ACCOUNT_KEY_PRE = "PAUSE_ACCOUNT_ID:";

        /**
         * 给网关消息的超时时间
         */
        public static final long GATEWAY_DEFAULT_TIMEOUT = 7L * 24 * 60 * 60;

        /**
         * 缓存里面设置的有效期
         */
        public static final long CACHE_SETTING_TIMEOUT = 30L * 24 * 60 * 60;

        /**
         * 给后台发结果的主题
         */
        public static final String BACK_MQ_TOPIC = "DOUC_ACCOUNT_REASON_BY_FRONT";

        /**
         * 缓存里面是否是否开启子租户的设置
         */
        public static final String CHILD_ACCOUNT_ENABLE_SETTING = "CHILD_ACCOUNT_ENABLE_SETTING";

        /**
         * 数据库里面对应的key
         */
        public static final String CHILD_ACCOUNT_ENABLE_DB_KEY = "childAccountEnable";

    }

    /**
     * 上报的结果枚举
     */
    public static class Result {
        public static final String SUCCESS = "SUCCESS";
        public static final String FAILED = "FAILED";
        public static final String STARTING = "STARTING";
    }

    /**
     * 操作的动作枚举
     */
    public static class Type {
        public static final String ADD = "ADD";
        public static final String PAUSE = "PAUSE";
        public static final String DELETE = "DELETE";
    }

    /**
     * 1
     * 正常（启用）
     * 2
     * 暂停（停用）
     * 3
     * 已删除（删除成功）
     * 4
     * 初始化中
     * 5
     * 初始化失败
     * 6
     * 停用中
     * 7
     * 停用失败
     * 8
     * 删除中
     * 9
     * 删除失败
     **/
    public static class Status {
        public static final int ENABLED = 1;
        public static final int PAUSE = 2;
        public static final int DELETED = 3;
        public static final int INITIALIZING = 4;
        public static final int INIT_FAIL = 5;
        public static final int PAUSING = 6;
        public static final int PAUSE_FAIL = 7;
        public static final int DELETING = 8;
        public static final int DELETE_FAIL = 9;
    }

    /**
     * 失败原因的各种注释
     */
    public static class Remark {
        public static final String INTI_FAIL = "新增产品初始化失败：%s，请联系项目支持人员";
        public static final String INIT_FAIL_EN = "New product initialization failed: %s, please contact project support staff";
        public static final String FAIL_MODULE_CODE = "失败产品模块：%s，请联系项目支持人员";
        public static final String FAIL_MODULE_CODE_EN = "Failed product module: %s, please contact project support staff";

        public static final String TOP_ACCOUNT_FAIL = "失败租户：%s <br/>失败产品模块：%s；<br/>";
        public static final String TOP_ACCOUNT_FAIL_END = "请联系项目支持人员";
        public static final String TOP_ACCOUNT_FAIL_EN = "Failed tenant: %s <br/> Failed product module: %s;<br/>";
        public static final String TOP_ACCOUNT_FAIL_END_EN = "Please contact project support staff";
    }

    /**
     * 修改状态动作的枚举
     */
    public static class ChangeAction {
        public static final String DISABLE = "disable";
        public static final String ENABLE = "enable";
    }
}
