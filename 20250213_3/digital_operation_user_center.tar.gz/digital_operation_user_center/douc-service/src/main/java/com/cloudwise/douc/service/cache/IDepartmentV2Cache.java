package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.service.model.department.DepartmentNodeCacheDTO;

import java.util.List;
import java.util.Map;

public interface IDepartmentV2Cache {

    /**
     * @param accountId
     * @param ids
     * @return Map<Long, DepartmentNode>
     * @Description 从缓存中获取Depantment集合
     */
    Map<Long, DepartmentNodeCacheDTO> getDepartmentMap(Long accountId, List<Long> ids);

    /**
     * @param accountId
     * @param departmentMap
     * @return Boolean
     * @Description 添加Depantment到缓存中
     */
    Boolean setDepartmentMap(Long accountId, Map<Long, DepartmentNodeCacheDTO> departmentMap);

    /**
     * @param accountId
     * @param ids
     * @return Boolean
     * @Description 删除缓存中Depantment
     */
    Boolean deleteDepartment(Long accountId, List<Long> ids);

    /**
     * @Description 加载所有Department到缓存中
     */
    void loadAllDepartmentToCache();

    /**
     * @Description 加载所有Department到缓存中
     */
    void loadSingleDepartmentToCache(Long accountId);


}
