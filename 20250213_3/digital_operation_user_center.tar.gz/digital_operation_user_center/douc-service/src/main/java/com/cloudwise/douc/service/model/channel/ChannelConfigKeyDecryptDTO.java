package com.cloudwise.douc.service.model.channel;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 解析渠道唯一key
 *
 * @author maker.wang
 * @date 2022-08-19 14:32
 **/
@Data
@ApiModel(value = "解析渠道唯一key")
public class ChannelConfigKeyDecryptDTO implements Serializable {
    private static final long serialVersionUID = -5835026978139078408L;

    @ApiModelProperty(value = "渠道唯一key")
    private String channelConfigKey;

    @ApiModelProperty(value = "租户ID")
    private Long accountId;

}
