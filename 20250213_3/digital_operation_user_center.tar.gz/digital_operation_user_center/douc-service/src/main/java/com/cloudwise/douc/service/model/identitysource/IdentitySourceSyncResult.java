package com.cloudwise.douc.service.model.identitysource;

import lombok.Data;

import java.io.Serializable;

/**
 * @author ken.liang
 * @description:身份源数据同步结果实体类
 * @date Created in 5:18 下午 2022/4/18.
 */
@Data
public class IdentitySourceSyncResult implements Serializable {
    private static final long serialVersionUID = -9002570502532327015L;
    private int addedDepartmentSucceedCount = 0;
    private int addedDepartmentFailedCount = 0;
    private int updatedDepartmentSucceedCount = 0;
    private int updatedDepartmentFailedCount = 0;
    private int deletedDepartmentSucceedCount = 0;
    private int deletedDepartmentFailedCount = 0;
    private int addedUserSucceedCount = 0;
    private int addedUserFailedCount = 0;
    private int updatedUserSucceedCount = 0;
    private int updatedUserFailedCount = 0;
    private int deletedUserSucceedCount = 0;
    private int deletedUserFailedCount = 0;

    public int getAllCount() {
        return addedDepartmentSucceedCount + addedDepartmentFailedCount + updatedDepartmentSucceedCount + updatedDepartmentFailedCount + deletedDepartmentSucceedCount + deletedDepartmentFailedCount
                + addedUserSucceedCount + addedUserFailedCount + updatedUserSucceedCount + updatedUserFailedCount + deletedUserSucceedCount + deletedUserFailedCount;
    }

    public int getAllUserCount() {
        return addedUserSucceedCount + updatedUserSucceedCount + deletedUserSucceedCount
                + addedUserFailedCount + updatedUserFailedCount + deletedUserFailedCount;
    }

    public int getAllDepartmentCount() {
        return addedDepartmentSucceedCount + updatedDepartmentSucceedCount + deletedDepartmentSucceedCount
                + addedDepartmentFailedCount + updatedDepartmentFailedCount + deletedDepartmentFailedCount;
    }

    public int getAllSucceedCount() {
        return addedDepartmentSucceedCount + updatedDepartmentSucceedCount + deletedDepartmentSucceedCount
                + addedUserSucceedCount + updatedUserSucceedCount + deletedUserSucceedCount;
    }


    public int getAllFailedCount() {
        return addedDepartmentFailedCount + updatedDepartmentFailedCount + deletedDepartmentFailedCount
                + addedUserFailedCount + updatedUserFailedCount + deletedUserFailedCount;
    }

    public int getSucceedDepartmentCount() {
        return addedDepartmentSucceedCount + updatedDepartmentSucceedCount + deletedDepartmentSucceedCount;
    }

    public int getSucceedUserCount() {
        return addedUserSucceedCount + updatedUserSucceedCount + deletedUserSucceedCount;
    }

    public int getFailedDepartmentCount() {
        return addedDepartmentFailedCount + updatedDepartmentFailedCount + deletedDepartmentFailedCount;
    }

    public int getFailedUserCount() {
        return addedUserFailedCount + updatedUserFailedCount + deletedUserFailedCount;
    }
}
