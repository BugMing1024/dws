package com.cloudwise.douc.service.model.user;

import lombok.Data;

/**
 * @author elsa.yang
 * @date 2020/8/14 11:00 上午
 */
@Data
public class UserCount {

    private int userCount;


    private Long accountId;
}
