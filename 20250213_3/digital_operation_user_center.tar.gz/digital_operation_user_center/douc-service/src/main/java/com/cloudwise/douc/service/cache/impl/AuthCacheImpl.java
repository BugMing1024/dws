package com.cloudwise.douc.service.cache.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.config.DomainConfig;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.metadata.activerecord.domain.SysDomain;
import com.cloudwise.douc.metadata.model.auth.MenuResponse;
import com.cloudwise.douc.metadata.model.data.DataAuthentication;
import com.cloudwise.douc.service.cache.IAuthCache;
import com.cloudwise.douc.service.model.auth.DataAuthCacheDTO;
import com.cloudwise.douc.service.model.auth.MenuAuthedCacheDTO;
import com.cloudwise.douc.service.service.IDomainService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * @author ken.liang
 * @description:鉴权缓存类
 * @date Created in 11:20 AM 2021/6/24.
 */
@Component
@Slf4j
public class AuthCacheImpl implements IAuthCache {
    
    private final double dirtyTTLRatio = 1.1;
    
    @Autowired
    private IDomainService domainService;
    
    @Override
    public Map<Long, List<MenuResponse>> getMenuAuthedByRoleIds(Long accountId, String moduleCode, List<Long> roleIds) {
        //查询角色菜单权限缓存失效标记
        String menuAuthedByRoleIdsDirtyKey = this.getMenuAuthedByRoleIdDirtyCacheKey(accountId, moduleCode);
        Long menuAuthByRoleIdsDirtyTime = RedisTools.getByte(menuAuthedByRoleIdsDirtyKey, Long.class);
        log.debug("menuAuthByRoleIdsDirtyTime:{}", menuAuthByRoleIdsDirtyTime);
        //最终已缓存角色菜单权限
        Map<Long, List<MenuResponse>> menuAuthedByRoleIdMap = Maps.newHashMap();
        //角色菜单权限缓存和角色id对应关系
        Map<String, Long> roleIdKeyMap = Maps.newHashMap();
        //角色菜单权限缓存key list
        List<String> menuAuthedByRoleIdsKeyList = roleIds.stream().map(roleId -> {
            String menuAuthedByRoleIdsKey = this.getMenuAuthedByRoleIdCacheKey(accountId, moduleCode, roleId);
            roleIdKeyMap.put(menuAuthedByRoleIdsKey, roleId);
            return menuAuthedByRoleIdsKey;
        }).collect(Collectors.toList());
        //查询角色菜单权限缓存
        Map<String, MenuAuthedCacheDTO> menuAuthedByRoleIdKeyMap = RedisTools.mget(menuAuthedByRoleIdsKeyList, MenuAuthedCacheDTO.class);
        log.debug("menuAuthedByRoleIdKeyMap:{}", menuAuthedByRoleIdKeyMap);
        menuAuthedByRoleIdKeyMap.forEach((roleIdKey, menuAuthedCache) -> {
            //验证缓存是否失效，失效缓存置空
            if (menuAuthByRoleIdsDirtyTime != null && menuAuthedCache != null && menuAuthByRoleIdsDirtyTime > menuAuthedCache.getCreateTime()) {
                menuAuthedByRoleIdMap.put(roleIdKeyMap.get(roleIdKey), null);
            } else {
                menuAuthedByRoleIdMap.put(roleIdKeyMap.get(roleIdKey), menuAuthedCache != null ? menuAuthedCache.getMenuResponseList() : null);
            }
        });
        return menuAuthedByRoleIdMap;
    }
    
    @Override
    public Map<Long, List<MenuResponse>> getViewMenuAuthedByRoleIds(Long accountId, String appCode, ArrayList<Long> roleIds) {
        log.debug("查询角色对应缓存方法开始accountId:{},appCode:{},roleIds:{}", accountId, appCode, roleIds);
        //查询角色菜单权限缓存失效标记
        String viewMenuAuthedByRoleIdsDirtyKey = this.getViewMenuAuthedByRoleIdDirtyCacheKey(accountId, appCode);
        Long viewMenuAuthByRoleIdsDirtyTime = RedisTools.getByte(viewMenuAuthedByRoleIdsDirtyKey, Long.class);
        log.debug("viewMenuAuthByRoleIdsDirtyTime:{}", viewMenuAuthByRoleIdsDirtyTime);
        //最终已缓存角色菜单权限
        Map<Long, List<MenuResponse>> viewMenuAuthedByRoleIdMap = Maps.newHashMap();
        //角色菜单权限缓存和角色id对应关系
        Map<String, Long> roleIdKeyMap = Maps.newHashMap();
        //角色菜单权限缓存key list
        List<String> menuAuthedByRoleIdsKeyList = roleIds.stream().map(roleId -> {
            String menuAuthedByRoleIdsKey = this.getViewMenuAuthedByRoleIdCacheKey(accountId, appCode, roleId);
            roleIdKeyMap.put(menuAuthedByRoleIdsKey, roleId);
            return menuAuthedByRoleIdsKey;
        }).collect(Collectors.toList());
        log.debug("menuAuthedByRoleIdsKeyList:{}", menuAuthedByRoleIdsKeyList);
        //查询角色菜单权限缓存
        Map<String, MenuAuthedCacheDTO> menuAuthedByRoleIdKeyMap = RedisTools.mget(menuAuthedByRoleIdsKeyList, MenuAuthedCacheDTO.class);
        log.debug("menuAuthedByRoleIdKeyMap:{}", menuAuthedByRoleIdKeyMap);
        menuAuthedByRoleIdKeyMap.forEach((roleIdKey, menuAuthedCache) -> {
            //验证缓存是否失效，失效缓存置空
            if (viewMenuAuthByRoleIdsDirtyTime != null && menuAuthedCache != null
                    && viewMenuAuthByRoleIdsDirtyTime > menuAuthedCache.getCreateTime()) {
                log.debug("dirty缓存生效-roleIdKey:{},menuAuthedCache:{},viewMenuAuthByRoleIdsDirtyTime:{}", roleIdKey, menuAuthedCache,
                        viewMenuAuthByRoleIdsDirtyTime);
                viewMenuAuthedByRoleIdMap.put(roleIdKeyMap.get(roleIdKey), null);
            } else {
                viewMenuAuthedByRoleIdMap.put(roleIdKeyMap.get(roleIdKey),
                        menuAuthedCache != null && CollectionUtils.isNotEmpty(menuAuthedCache.getMenuResponseList())
                                ? menuAuthedCache.getMenuResponseList() : null);
            }
        });
        return viewMenuAuthedByRoleIdMap;
    }
    
    @Override
    public void setMenuAuthedByRoleIds(Long accountId, String moduleCode, Map<Long, List<MenuResponse>> menuAuthedByRoleIdsMap) {
        menuAuthedByRoleIdsMap.forEach((roleId, menuResponseList) -> {
            MenuAuthedCacheDTO menuAuthedCache = new MenuAuthedCacheDTO(System.currentTimeMillis(), menuResponseList);
            RedisTools.setByteWithTime(this.getMenuAuthedByRoleIdCacheKey(accountId, moduleCode, roleId), menuAuthedCache,
                    this.getMenuAuthedByRoleIdCacheTTL());
        });
    }
    
    @Override
    public void setViewMenuAuthedByRoleIds(Long accountId, String appCode, Map<Long, List<MenuResponse>> viewMenuAuthedByRoleIdsMap) {
        viewMenuAuthedByRoleIdsMap.forEach((roleId, viewMenuResponseList) -> {
            MenuAuthedCacheDTO viewMenuAuthedCache = new MenuAuthedCacheDTO(System.currentTimeMillis(), viewMenuResponseList);
            RedisTools.setByteWithTime(this.getViewMenuAuthedByRoleIdCacheKey(accountId, appCode, roleId), viewMenuAuthedCache,
                    this.getViewMenuAuthedByRoleIdCacheTTL());
        });
    }
    
    @Override
    public void deleteMenuAuthedByRoleIds(Long accountId, List<String> moduleCodeList, List<Long> roleIds) {
        //角色菜单权限缓存key list
        List<String> menuAuthedByRoleIdsKeyList = Lists.newArrayList();
        roleIds.forEach(roleId -> moduleCodeList.forEach(moduleCode -> {
            if (DomainConfig.isOpenDomain()) {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    menuAuthedByRoleIdsKeyList.add(this.getMenuAuthedByRoleIdCacheKey(domain.getId(), moduleCode, roleId));
                });
            } else {
                menuAuthedByRoleIdsKeyList.add(this.getMenuAuthedByRoleIdCacheKey(accountId, moduleCode, roleId));
            }
        }));
        boolean result = RedisTools.deleteValueByKeys(menuAuthedByRoleIdsKeyList);
        if (!result) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }
    
    @Override
    public void deleteViewMenuAuthedByRoleIds(Long accountId, List<String> appCodeList, List<Long> roleIds) {
        //角色菜单权限缓存key list
        List<String> viewMenuAuthedByRoleIdsKeyList = Lists.newArrayList();
        roleIds.forEach(roleId -> appCodeList.forEach(
                appCode -> viewMenuAuthedByRoleIdsKeyList.add(this.getViewMenuAuthedByRoleIdCacheKey(accountId, appCode, roleId))));
        log.debug("删除菜单视图缓存key:{}", viewMenuAuthedByRoleIdsKeyList);
        boolean result = RedisTools.deleteValueByKeys(viewMenuAuthedByRoleIdsKeyList);
        if (!result) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }
    
    @Override
    public void setMenuAuthedByRoleIdsDirty(Long accountId, String moduleCode) {
        boolean result = RedisTools.setByteWithTime(this.getMenuAuthedByRoleIdDirtyCacheKey(accountId, moduleCode), System.currentTimeMillis(),
                this.getMenuAuthedByRoleIdDirtyCacheTTL());
        if (!result) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }
    
    @Override
    public void setViewMenuAuthedByRoleIdsDirty(Long accountId, String appCode) {
        log.debug("失效菜单视图缓存开始：accountId:{},appCode:{}", accountId, appCode);
        boolean result = RedisTools.setByteWithTime(this.getViewMenuAuthedByRoleIdDirtyCacheKey(accountId, appCode), System.currentTimeMillis(),
                this.getViewMenuAuthedByRoleIdDirtyCacheTTL());
        log.debug("失效菜单视图缓存结束，result:{}", result);
        if (!result) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }
    
    @Override
    public Map<Long, List<DataAuthentication>> getDataAuthedByRoleIds(Long accountId, String dataType, List<Long> roleIds) {
        //查询角色数据权限缓存失效标记
        String dataAuthedByRoleIdsDirtyKey = this.getDataAuthedByRoleIdDirtyCacheKey(accountId, dataType);
        Long dataAuthByRoleIdsDirtyTime = RedisTools.getByte(dataAuthedByRoleIdsDirtyKey, Long.class);
        //最终已缓存角色数据权限
        Map<Long, List<DataAuthentication>> dataAuthedByRoleIdMap = Maps.newHashMap();
        //角色数据权限缓存和角色id对应关系
        Map<String, Long> roleIdKeyMap = Maps.newHashMap();
        //角色数据权限缓存key list
        List<String> dataAuthedByRoleIdsKeyList = roleIds.stream().map(roleId -> {
            String dataAuthedByRoleIdsKey = this.getDataAuthedByRoleIdCacheKey(accountId, dataType, roleId);
            roleIdKeyMap.put(dataAuthedByRoleIdsKey, roleId);
            return dataAuthedByRoleIdsKey;
        }).collect(Collectors.toList());
        //查询角色数据权限缓存
        Map<String, DataAuthCacheDTO> dataAuthedByRoleIdKeyMap = RedisTools.mget(dataAuthedByRoleIdsKeyList, DataAuthCacheDTO.class);
        dataAuthedByRoleIdKeyMap.forEach((roleIdKey, dataAuthCacheDTO) -> {
            //验证缓存是否失效，失效缓存置空
            if (dataAuthByRoleIdsDirtyTime != null && dataAuthCacheDTO != null && dataAuthByRoleIdsDirtyTime > dataAuthCacheDTO.getCreateTime()) {
                dataAuthedByRoleIdMap.put(roleIdKeyMap.get(roleIdKey), null);
            } else {
                dataAuthedByRoleIdMap.put(roleIdKeyMap.get(roleIdKey),
                        dataAuthCacheDTO != null ? dataAuthCacheDTO.getDataAuthenticationList() : null);
            }
        });
        return dataAuthedByRoleIdMap;
    }
    
    @Override
    public void setDataAuthedByRoleIds(Long accountId, String dataType, Map<Long, List<DataAuthentication>> dataAuthedByRoleIdsMap) {
        
        dataAuthedByRoleIdsMap.forEach((roleId, dataAuthenticationList) -> {
            DataAuthCacheDTO dataAuthCacheDTO = new DataAuthCacheDTO(System.currentTimeMillis(), dataAuthenticationList);
            RedisTools.setByteWithTime(this.getDataAuthedByRoleIdCacheKey(accountId, dataType, roleId), dataAuthCacheDTO,
                    this.getDataAuthedByRoleIdCacheTTL());
        });
    }
    
    @Override
    public void deleteDataAuthedByRoleIds(Long accountId, List<String> dataTypeList, List<Long> roleIds) {
        //角色数据权限缓存key list
        List<String> dataAuthedByRoleIdsKeyList = Lists.newArrayList();
        roleIds.forEach(roleId -> dataTypeList.forEach(dataType -> {
            if (DomainConfig.isOpenDomain()) {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    dataAuthedByRoleIdsKeyList.add(this.getDataAuthedByRoleIdCacheKey(domain.getId(), dataType, roleId));
                });
            } else {
                dataAuthedByRoleIdsKeyList.add(this.getDataAuthedByRoleIdCacheKey(accountId, dataType, roleId));
            }
        }));
        boolean result = RedisTools.deleteValueByKeys(dataAuthedByRoleIdsKeyList);
        if (!result) {
            throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
        }
    }
    
    @Override
    public void setDataAuthedByRoleIdsDirty(Long accountId, String dataType) {
        if (DomainConfig.isOpenDomain()) {
            CompletableFuture.runAsync(() -> {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    boolean result = RedisTools.setByteWithTime(this.getDataAuthedByRoleIdDirtyCacheKey(domain.getId(), dataType),
                            System.currentTimeMillis(), this.getDataAuthedByRoleIdDirtyCacheTTL());
                    if (!result) {
                        throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
                    }
                });
            }, AsyncTaskPool.getTaskExecutor());
        } else {
            boolean result = RedisTools.setByteWithTime(this.getDataAuthedByRoleIdDirtyCacheKey(accountId, dataType), System.currentTimeMillis(),
                    this.getDataAuthedByRoleIdDirtyCacheTTL());
            if (!result) {
                throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
            }
        }
        
    }
    
    @Override
    public List<DataAuthentication> getCreatorDataAuthed(Long accountId, String dataType, Long userId) {
        //查询创建者数据权限缓存
        return RedisTools.getByte(this.getCreatorDataAuthedCacheKey(accountId, dataType, userId), List.class);
    }
    
    @Override
    public void setCreatorDataAuthed(Long accountId, String dataType, List<DataAuthentication> dataAuthenticationList, Long userId) {
        RedisTools.setByteWithTime(this.getCreatorDataAuthedCacheKey(accountId, dataType, userId), Lists.newArrayList(dataAuthenticationList),
                this.getCreatorDataAuthedCacheTTL());
    }
    
    @Override
    public void deleteCreatorDataAuthed(Long accountId, String dataType, List<Long> userIdList) {
        if (DomainConfig.isOpenDomain()) {
            CompletableFuture.runAsync(() -> {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    //创建者数据权限缓存key list
                    List<String> creatorDataAuthedCacheKeyList = userIdList.stream()
                            .map(userId -> this.getCreatorDataAuthedCacheKey(domain.getId(), dataType, userId)).collect(Collectors.toList());
                    boolean result = RedisTools.deleteValueByKeys(creatorDataAuthedCacheKeyList);
                    if (!result) {
                        throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
                    }
                });
            }, AsyncTaskPool.getTaskExecutor());
        } else {
            //创建者数据权限缓存key list
            List<String> creatorDataAuthedCacheKeyList = userIdList.stream()
                    .map(userId -> this.getCreatorDataAuthedCacheKey(accountId, dataType, userId)).collect(Collectors.toList());
            boolean result = RedisTools.deleteValueByKeys(creatorDataAuthedCacheKeyList);
            if (!result) {
                throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
            }
        }
    }
    
    
    private String getMenuAuthedByRoleIdDirtyCacheKey(Long accountId, String moduleCode) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_ROLE_MENU_AUTHED_DIRTY_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(moduleCode);
        return stringBuilder.toString();
    }
    
    private String getViewMenuAuthedByRoleIdDirtyCacheKey(Long accountId, String appCode) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_ROLE_VIEW_MENU_AUTHED_DIRTY_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(appCode);
        return stringBuilder.toString();
    }
    
    private String getMenuAuthedByRoleIdCacheKey(Long accountId, String moduleCode, Long roleId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_ROLE_MENU_AUTHED_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(roleId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(moduleCode);
        return stringBuilder.toString();
    }
    
    private String getViewMenuAuthedByRoleIdCacheKey(Long accountId, String appCode, Long roleId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_ROLE_VIEW_MENU_AUTHED_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(roleId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(appCode);
        return stringBuilder.toString();
    }
    
    private String getDataAuthedByRoleIdDirtyCacheKey(Long accountId, String dataType) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_ROLE_DATA_AUTHED_DIRTY_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(dataType);
        return stringBuilder.toString();
    }
    
    private String getDataAuthedByRoleIdCacheKey(Long accountId, String dataType, Long roleId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_ROLE_DATA_AUTHED_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(roleId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(dataType);
        return stringBuilder.toString();
    }
    
    private String getCreatorDataAuthedCacheKey(Long accountId, String dataType, Long userId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CacheConstant.REDIS_CACHE_KEY_CREATOR_DATA_AUTHED_KEY);
        stringBuilder.append(accountId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(userId);
        stringBuilder.append(CacheConstant.C_REDIS_KEY_SEPARATOR);
        stringBuilder.append(dataType);
        return stringBuilder.toString();
    }
    
    
    private long getMenuAuthedByRoleIdCacheTTL() {
        return ConfigUtils.getLong("auth.cache.menu-role.ttl", CacheConstant.REDIS_CACHE_KEY_ROLE_MENU_AUTHED_TTL);
    }
    
    private long getViewMenuAuthedByRoleIdCacheTTL() {
        return ConfigUtils.getLong("auth.cache.view-menu-role.ttl", CacheConstant.REDIS_CACHE_KEY_ROLE_VIEW_MENU_AUTHED_TTL);
    }
    
    private long getDataAuthedByRoleIdCacheTTL() {
        return ConfigUtils.getLong("auth.cache.data-role.ttl", CacheConstant.REDIS_CACHE_KEY_ROLE_DATA_AUTHED_TTL);
    }
    
    private long getCreatorDataAuthedCacheTTL() {
        return ConfigUtils.getLong("auth.cache.data-role.ttl", CacheConstant.REDIS_CACHE_KEY_ROLE_DATA_AUTHED_TTL);
    }
    
    private long getMenuAuthedByRoleIdDirtyCacheTTL() {
        return (long) (Math.ceil(this.getMenuAuthedByRoleIdCacheTTL() * dirtyTTLRatio));
    }
    
    private long getViewMenuAuthedByRoleIdDirtyCacheTTL() {
        return (long) (Math.ceil(this.getViewMenuAuthedByRoleIdCacheTTL() * dirtyTTLRatio));
    }
    
    private long getDataAuthedByRoleIdDirtyCacheTTL() {
        return (long) (Math.ceil(this.getDataAuthedByRoleIdCacheTTL() * dirtyTTLRatio));
    }
    
    
}
