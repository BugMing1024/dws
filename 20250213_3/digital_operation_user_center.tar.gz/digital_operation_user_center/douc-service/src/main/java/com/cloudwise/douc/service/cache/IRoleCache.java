package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.role.RoleInfo;

import java.util.List;

/**
 * @author Bernie
 * @date 2021-01-28 15:06
 */
public interface IRoleCache {
    /**
     * 全量角色信息缓存
     *
     * @Param
     * @Return
     * @Auth bernie
     * @Date 3:09 PM 2021/1/28
     */
    void updateAllRoleInfoByIdToCache();

    /**
     * description: 删除角色信息缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void deleteRolesFromCache(Long accountId, List<Long> roleIds);

    /**
     * 设置全量角色缓存
     *
     * @param accountId
     * @param roleInfos
     */
    void setRoleInfos(Long accountId, List<RoleInfo> roleInfos);

    /**
     * 删除role缓存
     *
     * @param accountId
     */
    void deleteAllV2RolesFromCache(Long accountId);

    /**
     * 通过角色ids从缓存中获取角色
     *
     * @param accountId
     * @return
     */
    List<RoleInfo> getRoleInfosByRoleIds(Long accountId, List<Long> roleIds);
}
