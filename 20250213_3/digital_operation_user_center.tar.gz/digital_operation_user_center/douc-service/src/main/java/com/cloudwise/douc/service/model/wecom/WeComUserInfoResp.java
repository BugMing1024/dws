package com.cloudwise.douc.service.model.wecom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 企业微信响应对象
 *
 * @author maker.wang
 * @date 2022-01-08 11:19
 **/
@Data
@ApiModel("企业微信响应对象")
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComUserInfoResp implements Serializable {
    private static final long serialVersionUID = -5754284255843545539L;

    @ApiModelProperty("出错返回码，为0表示成功，非0表示调用失败")
    private int errcode;

    @ApiModelProperty("返回码提示语")
    private String errmsg;

    @ApiModelProperty("成员userID")
    private String userid;

    @ApiModelProperty("成员名称")
    private String name;

    @ApiModelProperty("手机号码")
    private String mobile;

    @ApiModelProperty("邮箱")
    private String email;

    @ApiModelProperty("激活状态: 1=已激活，2=已禁用，4=未激活，5=退出企业。")
    private Integer status;

    @ApiModelProperty("性别。0表示未定义，1表示男性，2表示女性")
    private String gender;


    @ApiModelProperty("成员所属部门id列表，仅返回该应用有查看权限的部门id")
    private List<Long> department;

    // CHECKSTYLE:OFF
    @ApiModelProperty("表示在所在的部门内是否为部门负责人")
    private List<Long> is_leader_in_dept;

    @ApiModelProperty("直属上级UserID，最多有五个直属上级")
    private List<String> direct_leader;
    // CHECKSTYLE:ON

    @ApiModelProperty("部门内的排序值，默认为0")
    private List<Long> order;

    @ApiModelProperty("职务信息")
    private String position;


    @ApiModelProperty("头像url")
    private String avatar;

    // CHECKSTYLE:OFF
    @ApiModelProperty("头像缩略图url")
    private String thumb_avatar;
    // CHECKSTYLE:ON

    @ApiModelProperty("座机")
    private String telephone;

    @ApiModelProperty("别名")
    private String alias;

    @ApiModelProperty("扩展属性")
    private Map<String, Object> extattr;

    // CHECKSTYLE:OFF
    @ApiModelProperty("员工个人二维码")
    private String qr_code;

    @ApiModelProperty("成员对外属性")
    private Map<String, Object> external_profile;
    // CHECKSTYLE:ON

    @ApiModelProperty("地址")
    private String address;

    // CHECKSTYLE:OFF
    @ApiModelProperty("全局唯一")
    private String open_userid;

    @ApiModelProperty("主部门，仅当应用对主部门有查看权限时返回")
    private String main_department;
    // CHECKSTYLE:ON

    public boolean checkRequestResult() {
        return 0 == this.errcode;
    }
}
