package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserGroupBaseInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 用户组信息加用户组下用户信息列表
 */
@Data
public class GroupUserResp extends GroupBaseInfo implements Serializable {

    private List<UserGroupBaseInfo> userInfoList;
}
