package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.mapper.IModuleAccountDao;
import com.cloudwise.douc.metadata.mapper.IRoleGroupDao;
import com.cloudwise.douc.metadata.model.role.RoleGroup;
import com.cloudwise.douc.service.cache.IRoleGroupCache;
import com.cloudwise.douc.service.model.role.RoleGroupResp;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Bernie
 * @date 2021-01-30 16:24
 */
@Component
@Slf4j
public class RoleGroupCacheImpl implements IRoleGroupCache {

    private static final int BATCH_SIZE = 10000;

    @Autowired
    private IRoleGroupDao roleGroupDao;

    @Autowired
    private IModuleAccountDao moduleAccountDao;

    @Autowired
    private ObjectMapper objectMapper;


    @Override
    public void updateAllRoleGroupByIdToCache() {
        //获取所有的租户id
        List<Long> accountIds = moduleAccountDao.listAllAccountId();
        //根据id查询并缓存角色信息
        accountIds.forEach(accountId -> {
            //初始查询角色id
            long lastMaxId = 0L;
            //角色容器
            List<RoleGroup> roleList = Lists.newArrayList();
            while (true) {
                //循环批量查询角色信息
                List<RoleGroup> lastRoleList = roleGroupDao.getRoleGroupByLastMaxIddAndBatchSize(lastMaxId, BATCH_SIZE, accountId);
                roleList.addAll(lastRoleList);
                //当查询的角色数量小于单批次数量
                if (lastRoleList.size() < BATCH_SIZE) {
                    if (lastRoleList.size() != 0) {
                        log.debug("query role group startId:{},endId:{}", lastMaxId, lastRoleList.get(lastRoleList.size() - 1).getId());
                        break;
                    }
                    break;
                } else {
                    log.debug("query role group startId:{},endId:{}", lastMaxId, lastRoleList.get(lastRoleList.size() - 1).getId());
                    //以查询的最大id作为下次查询的起始id
                    lastMaxId = Long.parseLong(lastRoleList.get(lastRoleList.size() - 1).getId());
                }
            }
            //把roleList处理成map
            Map<String, RoleGroup> roleMap = Maps.newHashMap();
            roleList.forEach(role -> roleMap.put(String.valueOf(role.getId()), role));

            //删除历史缓存数据
            RedisTools.deleteValueByKey(CacheConstant.ROLE_GROUP_CACHE_PRE + accountId);
            //角色map存入redis
            boolean hmset = RedisTools.hmset(CacheConstant.ROLE_GROUP_CACHE_PRE + accountId, roleMap);
            if (!hmset) {
                log.error("Failed to get roleGroup from cache");
                throw new BaseException(IBaseExceptionCode.API_ROLEGROUP_CACHE_ERROR);
            }
        });
    }

    @Override
    public void deleteRoleGroupsFromCache(Long accountId, List<Long> roleGroupIds) {
        List<String> collect = roleGroupIds.stream().map(String::valueOf).collect(Collectors.toList());
        boolean hmset = RedisTools.hdel(CacheConstant.ROLE_GROUP_CACHE_PRE + accountId, collect);
        if (!hmset) {
            log.error("Failed to delete role group cache:{}", roleGroupIds);
            throw new BaseException(IBaseExceptionCode.API_ROLEGROUP_CACHE_ERROR);
        }
    }

    @Override
    public List<RoleGroupResp> getAllRoleGroupDirect(Long accountId) {
        String result = RedisTools.getByteWithGzip(CacheConstant.ROLE_GROUP_CACHE_DIRECT_PRE + accountId, String.class);
        CollectionType listType = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, RoleGroupResp.class);
        List<RoleGroupResp> roleGroupRespList = null;
        if (StrUtil.isBlank(result)) {
            return null;
        } else {
            try {
                roleGroupRespList = objectMapper.readValue(result, listType);
            } catch (Exception e) {
                log.error("Failed to get all role group cache:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR, e);
            }
        }
        return roleGroupRespList;
    }

    @Override
    public void setAllRoleGroupDirect(List<RoleGroupResp> roleGroupResps, long accountId) {
        try {
            String roleGroupRespStr = objectMapper.writeValueAsString(roleGroupResps);
            boolean del = RedisTools.setByteWithGzip(CacheConstant.ROLE_GROUP_CACHE_DIRECT_PRE + accountId, roleGroupRespStr, CacheConstant.ROLE_GROUP_CACHE_DIRECT_TTL);
            if (!del) {
                log.error("Failed to caching all role group:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR);
            }
        } catch (JsonProcessingException e) {
            log.error("Failed to caching all role group:{}", accountId);
            throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR, e);
        }
    }

    @Override
    public void deleteAllRoleGroupDirect(long accountId) {
        String key = CacheConstant.ROLE_GROUP_CACHE_DIRECT_PRE + accountId;
        if (RedisTools.isKeyExist(key)) {
            boolean deleteValueByKey = RedisTools.deleteValueByKey(key);
            if (!deleteValueByKey) {
                log.error("Failed to delete all role group cache:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR);
            }
        }
    }

    @Override
    public void deleteAllV2RoleGroupFromCacheByAccountId(Long accountId) {
        String key = getRoleGroupCachelKey(accountId);
        if (RedisTools.isKeyExist(key)) {
            boolean hmset = RedisTools.deleteValueByKey(key);
            if (!hmset) {
                log.error("Failed to delete all role group cache:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR);
            }
        }
    }

    /**
     * 获取 V2角色组key
     *
     * @param accountId
     * @return
     */
    private String getRoleGroupCachelKey(Long accountId) {
        return CacheConstant.ROLE_V2_GROUP_CACHE_PRE + accountId;
    }
}
