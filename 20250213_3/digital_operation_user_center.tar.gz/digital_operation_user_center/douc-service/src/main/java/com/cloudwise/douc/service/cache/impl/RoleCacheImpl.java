package com.cloudwise.douc.service.cache.impl;

import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.mapper.IModuleAccountDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.model.role.Role;
import com.cloudwise.douc.metadata.model.role.RoleInfo;
import com.cloudwise.douc.service.cache.IRoleCache;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Bernie
 * @date 2021-01-28 15:28
 */
@Component
@Slf4j
public class RoleCacheImpl implements IRoleCache {

    private static final int BATCH_SIZE = 10000;

    @Autowired
    private IRoleDao roleDao;

    @Autowired
    private IModuleAccountDao moduleAccountDao;


    @Override
    public void updateAllRoleInfoByIdToCache() {
        //获取所有的租户id
        List<Long> accountIds = moduleAccountDao.listAllAccountId();
        //根据id查询并缓存角色信息
        accountIds.forEach(accountId -> {
            //初始查询角色id
            long lastMaxId = 0L;
            //角色容器
            List<Role> roleList = Lists.newArrayList();
            while (true) {
                //循环批量查询角色信息
                List<Role> lastRoleList = roleDao.getRoleByLastMaxIddAndBatchSize(lastMaxId, BATCH_SIZE, accountId);
                roleList.addAll(lastRoleList);
                //当查询的角色数量小于单批次数量
                if (lastRoleList.size() < BATCH_SIZE) {
                    if (lastRoleList.size() != 0) {
                        log.debug("query role startId:{},endId:{}", lastMaxId, lastRoleList.get(lastRoleList.size() - 1).getId());
                        break;
                    }
                    break;
                } else {
                    log.debug("query role startId:{},endId:{}", lastMaxId, lastRoleList.get(lastRoleList.size() - 1).getId());
                    //以查询的最大id作为下次查询的起始id
                    lastMaxId = lastRoleList.get(lastRoleList.size() - 1).getId();
                }
            }
            //把roleList处理成map
            Map<String, Role> roleMap = Maps.newHashMap();
            roleList.forEach(role -> roleMap.put(String.valueOf(role.getId()), role));

            //删除历史缓存数据
            RedisTools.deleteValueByKey(CacheConstant.ROLE_CACHE_PRE + accountId);
            //角色map存入redis
            RedisTools.hmset(CacheConstant.ROLE_CACHE_PRE + accountId, roleMap);
        });
    }

    @Override
    public void deleteRolesFromCache(Long accountId, List<Long> roleIds) {
        List<String> collect = roleIds.stream().map(String::valueOf).collect(Collectors.toList());
        boolean hmset = RedisTools.hdel(CacheConstant.ROLE_CACHE_PRE + accountId, collect);
        if (!hmset) {
            log.error("Failed to delete role cache  roleIds:{}", roleIds);
            throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR);
        }
    }

    @Override
    public void setRoleInfos(Long accountId, List<RoleInfo> roleInfos) {
        //把roleList处理成map
        Map<String, RoleInfo> roleMap = Maps.newHashMap();
        roleInfos.forEach(role -> roleMap.put(String.valueOf(role.getRoleId()), role));
        //删除历史缓存数据
        deleteAllV2RolesFromCache(accountId);
        //角色map存入redis
        RedisTools.hmset(getRoleV2CacheKey(accountId), roleMap, CacheConstant.ROLE_GROUP_CACHE_DIRECT_TTL, TimeUnit.MINUTES);
    }

    /**
     * role缓存
     *
     * @param accountId
     * @return
     */
    private String getRoleV2CacheKey(Long accountId) {
        return CacheConstant.ROLE_V2_CACHE_PRE + accountId;
    }

    @Override
    public void deleteAllV2RolesFromCache(Long accountId) {
        String key = getRoleV2CacheKey(accountId);
        if (RedisTools.isKeyExist(key)) {
            boolean hmset = RedisTools.deleteValueByKey(key);
            if (!hmset) {
                log.error("Failed to delete role cache accountId:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR);
            }
        }
    }

    @Override
    public List<RoleInfo> getRoleInfosByRoleIds(Long accountId, List<Long> roleIds) {
        if (!RedisTools.isKeyExist(getRoleV2CacheKey(accountId))) {
            return null;
        }
        //id处理成string
        List<String> collect = roleIds.stream().map(String::valueOf).collect(Collectors.toList());
        Map<String, RoleInfo> roleInfoMap = RedisTools.hmget(getRoleV2CacheKey(accountId), RoleInfo.class, collect);
        return roleInfoMap != null ? Lists.newArrayList(roleInfoMap.values()) : null;
    }

}