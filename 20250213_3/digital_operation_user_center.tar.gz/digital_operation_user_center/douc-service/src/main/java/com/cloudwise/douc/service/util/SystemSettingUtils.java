package com.cloudwise.douc.service.util;

import com.cloudwise.douc.service.model.security.ConfigurationVO;
import com.cloudwise.douc.service.service.ISystemSettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 系统设置的协助类
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-08-07 15:11; update at 2024-08-07 15:11
 */
@Component
public class SystemSettingUtils {
    
    private static ISystemSettingService iSystemSettingService;
    
    private static Map<Long, ConfigurationVO> systemSettingMap = new HashMap<>();
    
    public static ConfigurationVO getSystemSetting(Long id) {
        if (systemSettingMap.containsKey(id)) {
            return systemSettingMap.get(id);
        }
        ConfigurationVO configurationVO = iSystemSettingService.getSystemSetting(id.toString());
        systemSettingMap.put(id, configurationVO);
        return configurationVO;
    }
    
    public static ConfigurationVO setSystemSetting(Long id, ConfigurationVO configurationVO) {
        systemSettingMap.put(id, configurationVO);
        return configurationVO;
    }
    
    @Autowired
    public void setISystemSettingService(ISystemSettingService iSystemSettingService) {
        SystemSettingUtils.iSystemSettingService = iSystemSettingService;
    }
    
}
