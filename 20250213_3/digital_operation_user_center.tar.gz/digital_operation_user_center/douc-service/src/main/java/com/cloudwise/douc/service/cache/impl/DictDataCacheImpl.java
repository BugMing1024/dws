package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.model.dicdata.DicDataInfo;
import com.cloudwise.douc.metadata.model.dicdata.DicTypePo;
import com.cloudwise.douc.service.cache.IDictDataCache;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:59 PM 2021/4/7.
 */
@Component
public class DictDataCacheImpl implements IDictDataCache {
    @Override
    public List<DicDataInfo> getDictDataByTypeId(Long accountId, Long typeId) {
        return RedisTools.getByte(this.getDictDataTypeKey(accountId, typeId), List.class);
    }

    @Override
    public void setDictDataByTypeId(Long accountId, Long typeId, ArrayList<DicDataInfo> dicDataInfos) {
        RedisTools.setByteWithTime(this.getDictDataTypeKey(accountId, typeId), dicDataInfos, 60 * 10);
    }

    @Override
    public void deleteDictDataByTypeId(Long accountId, Long typeId) {
        RedisTools.deleteValueByKey(this.getDictDataTypeKey(accountId, typeId));
    }

    private String getDictDataTypeKey(Long accountId, Long typeId) {
        return CacheConstant.REDIS_CACHE_KEY_DICT_DATA_KEY + accountId + StrPool.C_COLON + typeId;
    }

    @Override
    public DicTypePo getDicTypeById(Long accountId, Long typeId) {
        return RedisTools.getByte(this.getDictTypeKey(accountId, typeId), DicTypePo.class);
    }

    @Override
    public void setDicTypeByTypeId(Long accountId, Long typeId, DicTypePo dicType) {
        RedisTools.setByteWithTime(this.getDictTypeKey(accountId, typeId), dicType, 60 * 10);
    }

    @Override
    public void deleteDicTypeByTypeId(Long accountId, Long typeId) {
        RedisTools.deleteValueByKey(this.getDictTypeKey(accountId, typeId));
    }

    private String getDictTypeKey(Long accountId, Long typeId) {
        return CacheConstant.REDIS_CACHE_KEY_DICT_TYPE_KEY + accountId + StrPool.C_COLON + typeId;
    }
}
