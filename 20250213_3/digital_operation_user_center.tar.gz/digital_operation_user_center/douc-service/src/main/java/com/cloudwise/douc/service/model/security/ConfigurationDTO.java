package com.cloudwise.douc.service.model.security;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author maker.wang
 * @description: 安全策略管理dto
 * @date Created in 5:08 下午 2021/5/24.
 */
@Data
public class ConfigurationDTO implements Serializable {
    private static final long serialVersionUID = 5672320952845664424L;

    /**
     * 是否开启多点登录 0关 1开
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Range(min = 0, max = 1, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_BOOLEAN)
    private String multiPointLogin;

    /**
     * 密码有效时间 天
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 0, max = 9999, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String secretEffectiveTime;

    /**
     * 密码连续错误次数
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 1, max = 10, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String secretErrorTime;

    /**
     * 账号锁定时间 小时
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 1, max = 99999, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String accountLockTime;

    /**
     * 禁止使用最近密码次数
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 0, max = 5, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String disableLatestSecretTime;

    /**
     * 密码最大长度
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 8, max = 20, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String secretMaxLength;

    /**
     * 密码最小长度
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 8, max = 20, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String secretMinLength;

    /**
     * 回话超时时间 分钟
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 0, max = 9999, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String sessionTimeOut;

    /**
     * 日志保留时间 天
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Digits(integer = 64, fraction = 0, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    @Range(min = 1, max = 180, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_DIGIT)
    private String logSaveTime;

    /**
     * 开启告警消息推送 0关 1开
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Range(min = 0, max = 1, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_BOOLEAN)
    private String warnMessagePush;

    /**
     * 报警推送地址URL
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Length(max = 255, message = IBaseExceptionCode.SYSTEM_SETTING_URL_LENGTH_LIMIT)
    private String warnPushUrl;

    /**
     * appKey
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Length(max = 255, message = IBaseExceptionCode.SYSTEM_SETTING_URL_LENGTH_LIMIT)
    private String warnAppKey;

    /**
     * 非法IP登录提醒 0关 1开
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Range(min = 0, max = 1, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_BOOLEAN)
    private String warnIllegalIp;

    /**
     * 密码连续错误提醒 0关 1开
     **/
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Range(min = 0, max = 1, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_BOOLEAN)
    private String warnPasswordContinuousError;

    /**
     * 第一次登录或者重置密码修改密码 开关   0关 1开
     */
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Range(min = 0, max = 1, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_BOOLEAN)
    private String updatePasswordOpen;

    /**
     * 二次认证配置是否开启  0关 1开,默认关闭
     */
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    @Range(min = 0, max = 1, message = IBaseExceptionCode.SYSTEM_SETTING_PARAMS_NOT_BOOLEAN)
    private String openSecondaryAuthentication;

    /**
     * 通知管理员
     */
    private String administratorName;

    /**
     * 二次认证模板
     */
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_VALUE_NULL)
    private String secondaryAuthenticationTemplate;

    /**
     * 二次认证英文模板
     */
    private String enSecondaryAuthenticationTemplate;

    private String secondaryAuthenticationCode;
    private String secondaryAuthenticationHistoryTemplate;
    private String secondaryAuthenticationHistoryCode;
    /**
     * 系统时区code
     */
    private String systemTimeZoneCityCode;

    @ApiModelProperty(value = "定期改密，1：开启，2：关闭")
    private String timingUpdatePasswordOpen;

    @ApiModelProperty(value = "密码到期提醒，1：开启，2：关闭")
    private String passwordExpireRemindOpen;

    @ApiModelProperty(value = "提醒频率 天")
    private String passwordExpireRemindDays;

    @ApiModelProperty(value = "提醒方式 1系统消息，2短信，3邮箱。多个逗号分隔")
    private String passwordExpireRemindWays;

    @ApiModelProperty(value = "密码过期提醒短信模板")
    private String passwordExpireSmsTemplate;

    @ApiModelProperty(value = "密码过期提醒邮箱模板")
    private String passwordExpireEmailTemplate;

    @ApiModelProperty(value = "密码过期提醒邮箱模板")
    private String passwordExpireSysMessageTemplate;

    @ApiModelProperty(value = "找回密码模板")
    private String retrievePasswordSmsTemplate;

    @ApiModelProperty(value = "找回密码英文模板")
    private String enRetrievePasswordSmsTemplate;

    @ApiModelProperty(value = "找回密码后的登录模板")
    private String loginSmsTemplate;

    @ApiModelProperty(value = "找回密码后的英文登录模板")
    private String enLoginSmsTemplate;

    @ApiModelProperty(value = "是否开启手机验证码登录，1开启")
    private String openMobileVerificationCodeLogin;

    @ApiModelProperty(value = "1：开启，2：关闭")
    private String licenseExpireRemindOpen;

    @ApiModelProperty(value = "'提醒方式 1系统消息，2短信，3邮箱")
    private String licenseExpireRemindWays;

    @ApiModelProperty(value = "短信模板")
    private String licenseExpireSmsTemplate;

    @ApiModelProperty(value = "邮件模板")
    private String licenseExpireEmailTemplate;

    @ApiModelProperty(value = "密码至少包含 1大写字母 2小写字母 3数字 4特殊符号")
    private String passwordContains;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
