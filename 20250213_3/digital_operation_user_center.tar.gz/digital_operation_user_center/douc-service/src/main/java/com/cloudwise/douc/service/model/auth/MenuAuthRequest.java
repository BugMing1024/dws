package com.cloudwise.douc.service.model.auth;

import com.cloudwise.douc.commons.model.BaseEntity;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * @author barney.song
 * Description: No Description
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MenuAuthRequest extends BaseEntity {
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    private Long userId;

    private String moduleCode;

    private String appCode;
    
    private String language = "zh_CN";
}
