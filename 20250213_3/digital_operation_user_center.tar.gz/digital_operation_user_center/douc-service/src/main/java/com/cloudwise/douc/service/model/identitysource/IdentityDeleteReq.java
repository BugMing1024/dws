package com.cloudwise.douc.service.model.identitysource;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class IdentityDeleteReq {

    @ApiModelProperty(value = "身份源id")
    private Long identitySourceId;

    @ApiModelProperty(value = "用户名")
    private String userName;

    @ApiModelProperty(value = "密码")
    private String password2;

    @ApiModelProperty(value = "密码")
    private String password3;

    private Long accountId;

    private Long userId;

}
