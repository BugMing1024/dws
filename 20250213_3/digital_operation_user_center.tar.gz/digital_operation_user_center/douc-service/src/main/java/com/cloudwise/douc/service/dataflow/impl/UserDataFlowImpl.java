package com.cloudwise.douc.service.dataflow.impl;

import cn.hutool.core.map.MapUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.config.DomainConfig;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import com.cloudwise.douc.metadata.activerecord.domain.SysDomain;
import com.cloudwise.douc.metadata.handler.ResultModelHandler;
import com.cloudwise.douc.metadata.mapper.IModuleAccountDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.model.department.DepartMentInfo;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;
import com.cloudwise.douc.service.cache.IUserCache;
import com.cloudwise.douc.service.dataflow.IUserDataFlow;
import com.cloudwise.douc.service.service.IDepartmentService;
import com.cloudwise.douc.service.service.IDomainService;
import com.cloudwise.douc.service.service.impl.UserServiceImpl;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * @author KenLiang
 * @description:用户信息获取数据流类
 * @date Created in 7:16 PM 2021/1/29.
 */
@Component
@Slf4j
public class UserDataFlowImpl implements IUserDataFlow {
    
    private static final String ALL_USER_COUNT_KEY = "all";
    
    @Autowired
    private IUserDao userDao;
    
    @Autowired
    private IRoleDao roleDao;
    
    @Autowired
    private IModuleAccountDao moduleAccountDao;
    
    @Autowired
    private IUserCache userCache;
    
    @Autowired
    private IDepartmentService departmentService;
    
    @Autowired
    private IDomainService domainService;
    
    public String getAccountUserInfoByIdCacheKey(Long accountId) {
        return CacheConstant.REDIS_CACHE_KEY_USERINFOBYIDS_HASH_KEY + accountId;
    }
    
    public String getAccountUserInfoByUserAliasCacheKey(Long accountId) {
        return CacheConstant.REDIS_CACHE_KEY_USERINFOBYUSERALIAS_HASH_KEY + accountId;
    }
    
    @Override
    public void updateAllUserBasedByIdToCache() {
        int batchSize = ConfigUtils.getInt("cache.init.size", 1000);
        List<Long> accountIds = moduleAccountDao.listAllAccountId();
        if (CollectionUtils.isNotEmpty(accountIds)) {
            RedisTools.deleteValueByKeys(accountIds.stream().map(this::getAccountUserInfoByIdCacheKey).collect(Collectors.toList()));
            RedisTools.deleteValueByKeys(accountIds.stream().map(this::getAccountUserInfoByUserAliasCacheKey).collect(Collectors.toList()));
        }
        for (long lastMaxId = 0L; ; ) {
            Long nextLastMaxId = Long.MAX_VALUE;
            List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList = userDao.listUserByBatch(lastMaxId, batchSize);
            if (userBaseInfoCacheDTOList.size() < batchSize) {
                if (userBaseInfoCacheDTOList.size() != 0) {
                    nextLastMaxId = userBaseInfoCacheDTOList.get(userBaseInfoCacheDTOList.size() - 1).getId();
                    log.info("query user cache startId:{},endId:{}", lastMaxId, nextLastMaxId);
                    userCache.addOrUpdateUsersBasedToCache(userBaseInfoCacheDTOList);
                    log.info("success to caching user,size：{},startId:{},endId:{}", userBaseInfoCacheDTOList.size(), lastMaxId, nextLastMaxId);
                    break;
                }
                break;
            } else {
                nextLastMaxId = userBaseInfoCacheDTOList.get(userBaseInfoCacheDTOList.size() - 1).getId();
                log.info("query user cache startId:{},endId:{}", lastMaxId, nextLastMaxId);
                userCache.addOrUpdateUsersBasedToCache(userBaseInfoCacheDTOList);
                log.info("success to caching user,size：{},startId:{},endId:{}", userBaseInfoCacheDTOList.size(), lastMaxId, nextLastMaxId);
            }
            lastMaxId = nextLastMaxId;
        }
    }
    
    @Override
    public List<UserBaseInfoCacheDTO> getMultiUserByIds(Long accountId, List<Long> userIds) {
        if (DomainConfig.isOpenDomain()) {
            accountId = ThreadLocalUtil.getTopAccountId();
        }
        List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList = userCache.getMultiUserFromCacheByIds(accountId, userIds);
        if (CollectionUtils.isNotEmpty(userBaseInfoCacheDTOList)) {
            userBaseInfoCacheDTOList.removeIf(Objects::isNull);
            List<Long> noCacheUserIds = Lists.newArrayList(userIds);
            // zafir：是否应该使用下面的来优化性能呢
            Set<Long> collect = userBaseInfoCacheDTOList.stream().map(UserBaseInfoCacheDTO::getId).collect(Collectors.toSet());
            noCacheUserIds.removeIf(collect::contains);
            if (CollectionUtils.isNotEmpty(noCacheUserIds)) {
                userBaseInfoCacheDTOList.addAll(userDao.listUserByIds(accountId, noCacheUserIds));
            }
        } else {
            if (userBaseInfoCacheDTOList == null) {
                userBaseInfoCacheDTOList = new ArrayList<>(userIds.size());
            }
            userBaseInfoCacheDTOList.addAll(userDao.listUserByIds(accountId, userIds));
        }
        return getUserBaseInfoCacheDTOListAndSetDepartMentInfo(accountId, userBaseInfoCacheDTOList);
    }
    
    @Override
    public List<UserBaseInfoCacheDTO> getMultiUserFromCacheByUserAliass(Long accountId, List<String> userAlias) {
        if (DomainConfig.isOpenDomain()) {
            accountId = ThreadLocalUtil.getTopAccountId();
        }
        List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList = userCache.getMultiUserFromCacheByUserAliass(accountId, userAlias);
        if (CollectionUtils.isNotEmpty(userBaseInfoCacheDTOList)) {
            userBaseInfoCacheDTOList.removeIf(Objects::isNull);
            List<String> noCacheUserAlias = Lists.newArrayList(userAlias);
            List<UserBaseInfoCacheDTO> finalUserBaseInfoCacheDTOList = userBaseInfoCacheDTOList;
            noCacheUserAlias.removeIf(userAlia -> finalUserBaseInfoCacheDTOList.stream()
                    .anyMatch(userBaseInfoCacheDTO -> userAlia.equals(userBaseInfoCacheDTO.getUserAlias())));
            if (CollectionUtils.isNotEmpty(noCacheUserAlias)) {
                userBaseInfoCacheDTOList.addAll(userDao.listUserByUserAliass(accountId, noCacheUserAlias));
            }
        } else {
            userBaseInfoCacheDTOList = Lists.newArrayList();
            userBaseInfoCacheDTOList.addAll(userDao.listUserByUserAliass(accountId, userAlias));
        }
        
        return getUserBaseInfoCacheDTOListAndSetDepartMentInfo(accountId, userBaseInfoCacheDTOList);
    }
    
    @Override
    public void addOrUpdateSingleUserBasedToCache(UserBaseInfoCacheDTO userBaseInfoCacheDTO) {
        userCache.addOrUpdateSingleUserBasedToCache(userBaseInfoCacheDTO);
    }
    
    @Override
    public void addOrUpdateUsersBasedToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList) {
        userCache.addOrUpdateUsersBasedToCache(userBaseInfoCacheDTOList);
    }
    
    @Override
    public void addOrUpdateSingleUserStatusBasedToCache(Boolean isStart, UserBaseInfoCacheDTO userBaseInfoCacheDTO) {
        userCache.addOrUpdateSingleOnlyUserStatusBasedToCache(isStart, userBaseInfoCacheDTO);
    }
    
    @Override
    public void addOrUpdateUsersStatusBasedToCache(List<UserBaseInfoCacheDTO> startUserBaseInfoCacheDTOList,
            List<UserBaseInfoCacheDTO> stopUserBaseInfoCacheDTOList) {
        userCache.addOrUpdateOnlyUsersStatusBasedToCache(startUserBaseInfoCacheDTOList, stopUserBaseInfoCacheDTOList);
    }
    
    @Override
    public void deleteUsersBasedToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList) {
        userCache.deleteUsersBasedFromCache(userBaseInfoCacheDTOList);
    }
    
    @Override
    public int getUsersCountByAccountIdAndStatus(Long accountId, Integer status) {
        
        String userCount = userCache.getUsersCountByAccountIdAndStatus(accountId, status);
        if (StringUtils.isEmpty(userCount)) {
            Map<String, String> userCountMap = getUserCountMap(accountId, status);
            //设置缓存
            userCache.setUsersCountByAccountId(accountId, userCountMap);
            userCount = getUserCount(status, userCountMap);
        }
        return Integer.parseInt(userCount);
    }
    
    /**
     * @param resultUserBaseInfoCacheDTOList 缓存map中的用户
     * @return List<UserBaseInfoCacheDTO>
     * @description 设置部门的
     * @author leakey.li
     * @date 2021/6/15
     * @time 5:20 下午
     */
    private List<UserBaseInfoCacheDTO> getUserBaseInfoCacheDTOListAndSetDepartMentInfo(Long accountId,
            List<UserBaseInfoCacheDTO> resultUserBaseInfoCacheDTOList) {
        if (CollectionUtils.isEmpty(resultUserBaseInfoCacheDTOList)) {
            return new ArrayList<>();
        }
        if (CollectionUtils.isNotEmpty(resultUserBaseInfoCacheDTOList)) {
            List<Long> departmentIds = Lists.newArrayList();
            Map<Long, List<UserBaseInfoCacheDTO>> userBaseInfoCacheDTOByDepartmentIdMap = Maps.newHashMap();
            resultUserBaseInfoCacheDTOList.forEach(userCache -> {
                if (userCache != null) {
                    departmentIds.add(userCache.getDepartmentId());
                    List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOS = userBaseInfoCacheDTOByDepartmentIdMap.computeIfAbsent(
                            userCache.getDepartmentId(), departmentId -> Lists.newArrayList());
                    userBaseInfoCacheDTOS.add(userCache);
                }
            });
            if (CollectionUtils.isNotEmpty(departmentIds)) {
                List<DepartMentInfo> departments = departmentService.getDepartMentsByIds(accountId, departmentIds);
                if (CollectionUtils.isNotEmpty(departments)) {
                    departments.forEach(departmentInfo -> {
                        List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOS = userBaseInfoCacheDTOByDepartmentIdMap.getOrDefault(departmentInfo.getId(),
                                Lists.newArrayList());
                        userBaseInfoCacheDTOS.forEach(userBaseInfoCacheDTO -> {
                            userBaseInfoCacheDTO.setDepartment(departmentInfo.getName());
                            userBaseInfoCacheDTO.setDepartmentLevel(departmentInfo.getLevel());
                        });
                    });
                    
                }
            }
        }
        return resultUserBaseInfoCacheDTOList;
    }
    
    /**
     * 获取人数
     *
     * @param status
     * @param userCountMap
     * @return
     */
    private String getUserCount(Integer status, Map<String, String> userCountMap) {
        String userCount;
        String key = status + "";
        if (status == null) {
            key = ALL_USER_COUNT_KEY;
        }
        userCount = userCountMap.get(key);
        return userCount;
    }
    
    /**
     * 获取人数map
     *
     * @param accountId
     * @param status
     * @return
     */
    private Map<String, String> getUserCountMap(Long accountId, Integer status) {
        Map<String, String> userCountMap = new HashMap<>(3);
        if (status == null) {
            //全量
            long downUserCount = userDao.getUserCountByAccountIdAndStatus(accountId, Constant.STATUS_DOWN);
            long upUserCount = userDao.getUserCountByAccountIdAndStatus(accountId, Constant.STATUS_UP);
            String allString = (downUserCount + upUserCount) + "";
            String upUserCountString = upUserCount + "";
            String downUserCountString = downUserCount + "";
            userCountMap.put(ALL_USER_COUNT_KEY, allString);
            userCountMap.put(Constant.STATUS_UP + "", upUserCountString);
            userCountMap.put(Constant.STATUS_DOWN + "", downUserCountString);
        } else {
            //状态缓存
            long userCountStatus = userDao.getUserCountByAccountIdAndStatus(accountId, status);
            userCountMap.put(status + "", userCountStatus + "");
        }
        return userCountMap;
    }
    
    
    @Override
    public void deleteUsersCountByAccountId(Long accountId) {
        userCache.deleteUsersCountByAccountId(accountId);
    }
    
    @Override
    public Map<Long, Integer> getRoleIdTypeMapByUserIdAndAccountId(Long accountId, Long userId) {
        Map<Long, Integer> roleIdTypeMapByUserIdAndAccountId = userCache.getRoleIdTypeMapByUserIdAndAccountId(accountId, userId);
        if (MapUtil.isEmpty(roleIdTypeMapByUserIdAndAccountId)) {
            HashMap<Long, Integer> resultHashMap = Maps.newHashMap();
            roleDao.getRoleIdTypeMapByUserId(DomainConfig.getDefaultOrNullSingle(accountId), userId, resultContext -> {
                ResultModelHandler resultObject = resultContext.getResultObject();
                resultHashMap.put(resultObject.getId(), resultObject.getType());
            });
            roleIdTypeMapByUserIdAndAccountId = resultHashMap;
            userCache.setRoleIdTypeMapByUserIdAndAccountId(accountId, userId, roleIdTypeMapByUserIdAndAccountId);
        }
        return roleIdTypeMapByUserIdAndAccountId;
    }
    
    
    @Override
    public void deleteRoleIdTypeMapByUserIdAndAccountId(Long accountId, List<Long> userIdList) {
        if (DomainConfig.isOpenDomain()) {
            CompletableFuture.runAsync(() -> {
                domainService.list(new LambdaQueryWrapper<>(SysDomain.class).eq(SysDomain::getIsDeleted, 0)).forEach(domain -> {
                    userCache.deleteRoleIdTypeMapByUserIdAndAccountId(domain.getId(), userIdList);
                });
            }, AsyncTaskPool.getTaskExecutor());
        } else {
            userCache.deleteRoleIdTypeMapByUserIdAndAccountId(accountId, userIdList);
        }
        UserServiceImpl.ADMIN_CACHE.clear();
    }
    
    @Override
    public void clearMultiUserFromCacheByUserAliasCache(Long accountId) {
        userCache.clearMultiUserFromCacheByUserAliasCache(accountId);
    }
    
    @Override
    public void clearMultiUserFromCacheByIdsCache(Long accountId) {
        userCache.clearMultiUserFromCacheByIdsCache(accountId);
    }
    
}