package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.service.model.auth.MenuAuthRequest;
import com.cloudwise.douc.service.model.auth.MenuAuthResponse;

/**
 * @description: 功能资源缓存
 * @author: jasonlee
 * @date: 2021-01-29 19:29
 **/
public interface IMenuResourceCache {
    /**
     * description:向缓存中添加某租户下某用户在某产品中的功能权限
     *
     * @param menuAuthRequest  功能权限查询信息
     * @param menuAuthResponse MenuAuthResponse 功能权限
     * @date create by jasonlee at 2021/1/29 7:34 PM
     */
    void setMenuBasedAccountIdUserIdModuleCodeToCache(MenuAuthRequest menuAuthRequest, MenuAuthResponse menuAuthResponse);

    /**
     * description: 从缓存中获取某租户下某用户在某产品中的功能权限
     *
     * @param menuAuthRequest 功能权限查询信息
     * @return MenuAuthResponse 功能权限结果
     * @date create by jasonlee at 2021/1/29 7:34 PM
     */
    MenuAuthResponse getMenuAuthFromCache(MenuAuthRequest menuAuthRequest);

    boolean isProfessionalCache();

    void clearProfessionalCache();
}
