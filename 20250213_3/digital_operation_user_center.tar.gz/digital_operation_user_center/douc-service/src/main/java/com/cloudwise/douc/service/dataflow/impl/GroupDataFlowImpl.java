package com.cloudwise.douc.service.dataflow.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.config.DomainConfig;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.metadata.handler.ResultModelHandler;
import com.cloudwise.douc.metadata.mapper.IGroupDao;
import com.cloudwise.douc.metadata.mapper.IModuleAccountDao;
import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;
import com.cloudwise.douc.service.cache.IGroupCache;
import com.cloudwise.douc.service.dataflow.IGroupDataFlow;
import com.cloudwise.douc.service.dataflow.IUserDataFlow;
import com.cloudwise.douc.service.service.impl.GroupServiceImpl;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class GroupDataFlowImpl implements IGroupDataFlow {
    @Autowired
    private IGroupDao groupDao;
    @Autowired
    private IGroupCache groupCache;
    @Autowired
    private IModuleAccountDao moduleAccountDao;
    @Autowired
    private IUserDataFlow userDataFlow;

    @Override
    public List<GroupBaseInfo> getAllGroupByAccountId(Long accountId) {
        List<GroupBaseInfo> allGroup = groupCache.getAllGroupByAccountId(accountId);
        if (CollectionUtils.isEmpty(allGroup) || DomainConfig.isOpenDomain()) {
            List<GroupBaseInfo> groupList = groupDao.getUserGroupListByAccountId(accountId);
            this.setGroupUserCount(groupList, accountId, null);
            //设置缓存
            groupCache.setAllGroupByAccountId(accountId, groupList);
            return groupList;
        }
        return allGroup;
    }

    @Override
    public List<GroupBaseInfo> getGroupListByAccountIdAndGroupdIds(Long accountId, List<Long> groupIds) {
        if (CollectionUtils.isEmpty(groupIds)) {
            return new ArrayList<>();
        }
        List<GroupBaseInfo> allGroupByAccountId = this.getAllGroupByAccountId(accountId);
        return this.getResultGroupListByGroupIds(allGroupByAccountId, groupIds);
    }

    @Override
    public List<GroupBaseInfo> getFirstLevelGroupListByAccountId(Long accountId) {
        //从全量缓存中哪，如果缓存不存在那么先加载缓存
        List<GroupBaseInfo> allGroup = getAllGroupByAccountId(accountId);
        if (CollectionUtils.isNotEmpty(allGroup)) {
            return makeFirstLevelGroupList(allGroup);
        } else {
            //走数据库
            List<GroupBaseInfo> firstLevelGroupList = groupDao.getFirstLevelGroupList(accountId);
            this.setGroupUserCount(firstLevelGroupList, accountId, firstLevelGroupList.stream().map(GroupBaseInfo::getGroupId).collect(Collectors.toList()));
            return firstLevelGroupList;
        }
    }

    @Override
    public List<GroupBaseInfo> getNextLevelGroupListByGroupId(Long accountId, Long groupId) {
        if (groupId == null) {
            return new ArrayList<>();
        }
        //从全量缓存中哪，如果缓存不存在那么先加载缓存
        List<GroupBaseInfo> allGroup = getAllGroupByAccountId(accountId);
        if (CollectionUtils.isNotEmpty(allGroup)) {
            return makeNextLevelGroupList(allGroup, groupId);
        } else {
            //走数据库
            return groupDao.getNextLevelGroupListByGroupId(accountId, groupId);
        }
    }

    @Override
    public List<Long> getUserIdsByGroupId(Long accountId, Long groupId) {
        List<Long> userIdList = groupCache.getUserIdListFromCacheByGroupId(groupId, String.valueOf(accountId));
        if (CollectionUtils.isEmpty(userIdList)) {
            userIdList = groupDao.getUserIdsByGroupId(accountId, groupId);
            groupCache.setGroupUserBasedByGroupIdToCache(String.valueOf(groupId), String.valueOf(accountId), Lists.newArrayList(userIdList));
        }
        return userIdList;
    }

    @Override
    public List<UserBaseInfoCacheDTO> getGroupHasUserListFromCacheByUserIdsAndUserStatus(List<Long> userIds, String accountId) {
        List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList = groupCache.getGroupHasUserListFromCacheByUserIdsAndUserStatus(userIds, accountId);

        return userBaseInfoCacheDTOList;
    }

    @Override
    public Map<String, ArrayList<String>> getGroupLeaderFromCacheByAccountIdAndGroup(Long accountId, List<GroupBaseInfo> groups) {
        Map<String, ArrayList<String>> groupLeaderCache = groupCache.getGroupLeaderCache(accountId);
        if (groupLeaderCache == null) {
            groupLeaderCache = setGroupLeaderCache(accountId, groups);
        }
        return groupLeaderCache;
    }

    @Override
    public void setGroupLeaderFromCacheByAccountId() {
        //获取所有的租户id
        List<Long> accountIds = moduleAccountDao.listAllAccountId();
        //设置用户组组长的领导缓存
        accountIds.forEach(accountId -> {
            List<GroupBaseInfo> allGroup = getAllGroupByAccountId(accountId);
            setGroupLeaderCache(accountId, allGroup);
        });
    }

    @Override
    public List<GroupBaseInfo> getCircleGroup(Long accountId) {
        List<GroupBaseInfo> allGroups = this.getAllGroupByAccountId(accountId);
        return allGroups.stream().filter(groupInfo ->
                GroupServiceImpl.GROUP_SCOPE_CIRCLE_TYPE.equals(groupInfo.getType())).collect(Collectors.toList());
    }

    @Override
    public void deleteGroupUserBasedByGroupIdsToCache(Long accountId, List<Long> groupIds) {
        if (CollectionUtils.isNotEmpty(groupIds)) {
            Set<String> groupUserKeys = new HashSet<>();
            groupIds.forEach(groupId -> {
                groupUserKeys.add(getGroupUserRedisKey(accountId, groupId));
            });
            groupCache.deleteGroupUserBasedByGroupIdsKeysToCache(Lists.newArrayList(groupUserKeys));
        }
    }

    private HashMap<String, ArrayList<String>> setGroupLeaderCache(Long accountId, List<GroupBaseInfo> allGroup) {
        HashMap<String, ArrayList<String>> groupLeaderMap = new HashMap<>();
        allGroup.forEach(group -> {
            ArrayList<String> resultGroupLeader = new ArrayList<>();
            //查组长的上级，最多10级
            if (StringUtils.isNotBlank(group.getLeader())) {
                getGroupLeader(Lists.newArrayList(group.getLeader()), accountId, 1, resultGroupLeader);
                groupLeaderMap.put(String.valueOf(group.getGroupId()), resultGroupLeader);
            }
        });
        //设置缓存
        long time = ConfigUtils.getLong("group.leaderCacheTime", CacheConstant.ONE_MINITE_DDL * 60L);
        if (time < 60L) {
            time = CacheConstant.ONE_MINITE_DDL * 10L;
        }
        log.debug("---------groupLeaderMap------size-----{}", groupLeaderMap.size());
        groupCache.setGroupLeaderCache(accountId, groupLeaderMap, time);
        return groupLeaderMap;
    }

    private int getGroupLeader(List<String> groupLeaders, Long accountId, int n, List<String> resultGroupLeader) {

        List<String> allUserIdList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(groupLeaders)) {
            Set<Long> idsList = new HashSet<>();
            groupLeaders.forEach(leader -> {
        
                List<Long> ids = Arrays.stream(leader.split(StrPool.COMMA)).map(s -> Long.valueOf(s.trim())).distinct().collect(Collectors.toList());
                idsList.addAll(ids);
            });

            List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOS = userDataFlow.getMultiUserByIds(accountId, Lists.newArrayList(idsList));
            List<UserBaseInfoCacheDTO> listWithoutNulls = userBaseInfoCacheDTOS.parallelStream()
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            for (UserBaseInfoCacheDTO userBaseInfoCacheDTO : listWithoutNulls) {
                String userLeaderId = userBaseInfoCacheDTO.getUserLeaderId();
                if (StringUtils.isNotEmpty(userLeaderId)) {
                    allUserIdList.add(userLeaderId);
                }
            }
        }
        resultGroupLeader.addAll(allUserIdList);
        if (n <= 10 && CollectionUtils.isNotEmpty(allUserIdList)) {
            return getGroupLeader(allUserIdList, accountId, n + 1, resultGroupLeader);
        }
        return 0;
    }

    /**
     * 从总的用户组里面过滤出下级用户组list
     *
     * @param allGroup
     * @param groupId
     * @return
     */
    private List<GroupBaseInfo> makeNextLevelGroupList(List<GroupBaseInfo> allGroup, Long groupId) {
        List<GroupBaseInfo> nextLvevelGroupList = new LinkedList<>();
        allGroup.forEach(groupBaseInfo -> {
            //groupId == parentId 那么为下级用户组
            if (groupBaseInfo != null && groupId.equals(groupBaseInfo.getParentId())) {
                nextLvevelGroupList.add(groupBaseInfo);
            }
        });
        return nextLvevelGroupList;
    }

    /**
     * 拼装顶级用户组
     *
     * @param allGroup
     * @return
     */
    private List<GroupBaseInfo> makeFirstLevelGroupList(List<GroupBaseInfo> allGroup) {
        List<GroupBaseInfo> firstLvevelGroupList = new LinkedList<>();
        allGroup.forEach(groupBaseInfo -> {
            if (groupBaseInfo != null && groupBaseInfo.getParentId() == null) {
                firstLvevelGroupList.add(groupBaseInfo);
            }
        });
        return firstLvevelGroupList;
    }

    /**
     * 通过groupIds获取groupList
     *
     * @param groupAllList
     * @param groupIds
     */
    @Override
    public List<GroupBaseInfo> getResultGroupListByGroupIds(List<GroupBaseInfo> groupAllList, List<Long> groupIds) {
        List<GroupBaseInfo> groupList = new ArrayList<>(groupIds.size());
    
        groupAllList.forEach(group -> {
            Long groupId = group.getGroupId();
            if (groupIds.contains(groupId)) {
                groupList.add(group);
            }
        });
        return groupList;
    }

    /**
     * 获取用户组下用户key
     *
     * @param accountId
     * @param groupId
     * @return
     */
    private String getGroupUserRedisKey(Long accountId, Long groupId) {
        return CacheConstant.DOUC_GROUP_USER_CACHE_PRE + accountId + StrPool.C_COLON + groupId;
    }

    //设置用户组人数
    private void setGroupUserCount(List<GroupBaseInfo> groupBaseInfos, Long accountId, List<Long> groupIds) {
        Map<Long, Integer> userCountByGroupIdsAndAccountId = Maps.newHashMap();
        groupDao.getUserCountByGroupIdsAndAccountId(accountId, groupIds, new ResultHandler<ResultModelHandler>() {
            @Override
            public void handleResult(ResultContext<? extends ResultModelHandler> resultContext) {
                ResultModelHandler resultObject = resultContext.getResultObject();
                userCountByGroupIdsAndAccountId.put(resultObject.getGroupId(), resultObject.getUserCount());
            }
        });

        groupBaseInfos.forEach(groupBaseInfo -> groupBaseInfo.setUserCount(userCountByGroupIdsAndAccountId.getOrDefault(groupBaseInfo.getGroupId(), 0)));
    }
}
