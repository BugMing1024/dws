package com.cloudwise.douc.service.model.logaudit;

/**
 * @author elsa.yang
 * @date 2020/6/11 3:10 下午
 */
public enum LogTypeMenu {

    /**
     * 操作日志
     */
    OPERATELOG(1, "operateLog"),
    /**
     * 系统日志
     */
    SYSTEMLOG(2, "systemLog"),
    /**
     * 登陆日志
     */
    LOGINLOG(3, "loginLog"),


    /***
     * 语言设置
     */
    LANGUAGE(4, "language"),

    /**
     * 行业设置
     */
    BUSINESS(5, "business");

    private final Integer typeId;
    private final String logType;

    LogTypeMenu(Integer typeId, String logType) {
        this.typeId = typeId;
        this.logType = logType;
    }

    public static Integer getTypeId(String logType) {
        for (LogTypeMenu log : LogTypeMenu.values()) {
            if (logType.equals(log.logType)) {
                return log.typeId;
            }
        }
        return null;
    }


    public static String getType(Integer typeId) {
        for (LogTypeMenu log : LogTypeMenu.values()) {
            if (typeId.equals(log.typeId)) {
                return log.logType;
            }
        }
        return null;
    }

}
