package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class UserAndGroupAndRoleDto {

    private Map<Long, String> userIdAndGroupDepartmentRoleMap;

    private Map<Long, String> userIdAndGroupDepartmentGroupMap;

    private List<String> distinctGroupList;

    private List<String> distinctRoleList;

}
