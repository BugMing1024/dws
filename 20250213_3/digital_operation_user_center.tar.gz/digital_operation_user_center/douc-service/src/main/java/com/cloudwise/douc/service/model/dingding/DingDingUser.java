package com.cloudwise.douc.service.model.dingding;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties
public class DingDingUser implements Serializable {

    @JsonProperty(value = "userid")
    private String userid;
    @JsonProperty(value = "unionid")
    private String unionid;
    @JsonProperty(value = "name")
    private String name;
    @JsonProperty(value = "manager_userid")
    private String managerUserId;
    @JsonProperty(value = "mobile")
    private String mobile;
    @JsonProperty(value = "email")
    private String email;
    @JsonProperty(value = "telephone")
    private String telephone;
    @JsonProperty(value = "job_number")
    private String jobNumber;
    @JsonProperty(value = "title")
    private String title;
    @JsonProperty(value = "work_place")
    private String workPlace;
    @JsonProperty(value = "remark")
    private String remark;
    @JsonProperty(value = "org_email")
    private String orgEmail;
    @JsonProperty(value = "dept_id_list")
    private List<String> deptIdList;
    @JsonProperty(value = "extension")
    private String extension;
    @JsonProperty(value = "hired_date")
    private Long hiredDate;
    @JsonProperty(value = "active")
    private Boolean active;
    @JsonProperty(value = "real_authed")
    private Boolean realAuthed;
    @JsonProperty(value = "userid_list")
    private List<String> useridList;

    @ApiModelProperty(value = "同步类型：1 新增，2 编辑")
    private Integer syncDataType;

    private String oldDepartmentCode;


}
