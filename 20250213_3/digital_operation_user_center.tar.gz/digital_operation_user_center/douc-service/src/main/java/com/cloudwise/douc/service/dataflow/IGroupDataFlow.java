package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 用户组数据流接口
 */
public interface IGroupDataFlow {

    /**
     * 获取所有的用户组信息
     *
     * @param accountId
     * @return
     */
    List<GroupBaseInfo> getAllGroupByAccountId(Long accountId);

    /**
     * 获取用户组信息 通过groupIds
     *
     * @param accountId
     * @param groupIds
     * @return
     */
    List<GroupBaseInfo> getGroupListByAccountIdAndGroupdIds(Long accountId, List<Long> groupIds);

    /**
     * 获取顶级的用户组信息
     */
    List<GroupBaseInfo> getFirstLevelGroupListByAccountId(Long accountId);

    /**
     * 获取下级用户组信息通过groupID
     *
     * @param accountId
     * @param groupId
     * @return
     */
    List<GroupBaseInfo> getNextLevelGroupListByGroupId(Long accountId, Long groupId);


    /**
     * @param accountId
     * @param groupId
     * @return java.util.List<java.lang.Long>
     * @description 获取用户组下用户id
     * @author ken.liang
     * @date 2021/6/29
     * @time 10:49 AM
     */
    List<Long> getUserIdsByGroupId(Long accountId, Long groupId);

    /**
     * description:通过用户id集合批量获取缓存中的用户信息
     *
     * @return 用户集合
     */
    List<UserBaseInfoCacheDTO> getGroupHasUserListFromCacheByUserIdsAndUserStatus(List<Long> userIds, String accountId);


    /**
     * 用户组组长领导
     */
    Map<String, ArrayList<String>> getGroupLeaderFromCacheByAccountIdAndGroup(Long accountId, List<GroupBaseInfo> groups);

    /**
     * 设置用户组组长领导缓存 ，全量缓存按照租户id
     */
    void setGroupLeaderFromCacheByAccountId();

    List<GroupBaseInfo> getResultGroupListByGroupIds(List<GroupBaseInfo> groupAllList, List<Long> groupIds);

    /**
     * @param accountId
     * @return
     * @description 查询圈子用户组
     * @author leakey.li
     * @date 2021/11/15
     * @time 6:26 下午
     */
    List<GroupBaseInfo> getCircleGroup(Long accountId);

    /**
     * 批量删除用户组与用户缓存
     *
     * @param accountId
     * @param groupIds
     */
    void deleteGroupUserBasedByGroupIdsToCache(Long accountId, List<Long> groupIds);


}
