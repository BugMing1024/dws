package com.cloudwise.douc.service.model.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户的登录账号信息
 *
 * @author maker.wang
 * @date 2022-05-07 10:16
 **/
@Data
@ApiModel("用户的登录账号信息")
public class LoginAccountInfoVO implements Serializable {
    private static final long serialVersionUID = 8502845847420057940L;

    @ApiModelProperty("登录手机号")
    private String loginMobile;

    @ApiModelProperty("登录邮箱")
    private String loginEmail;

}
