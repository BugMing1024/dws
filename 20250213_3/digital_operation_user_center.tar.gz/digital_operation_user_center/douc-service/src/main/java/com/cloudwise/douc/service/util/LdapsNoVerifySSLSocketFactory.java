package com.cloudwise.douc.service.util;

import cn.hutool.core.net.DefaultTrustManager;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;


/**
 * @author Bernie
 * @date 2020-08-11 00:27
 */
public class LdapsNoVerifySSLSocketFactory extends SSLSocketFactory {


    static {
        Security.setProperty("ssl.SocketFactory.provider",
                LdapsNoVerifySSLSocketFactory.class.getName());
    }

    private final SSLContext sslContext;

    private final SSLSocketFactory socketFactory;

    public LdapsNoVerifySSLSocketFactory() throws NoSuchAlgorithmException, KeyManagementException {
        DefaultTrustManager defaultTrustManager = new DefaultTrustManager();
        sslContext = SSLContext.getInstance("TLSv1.2");
        sslContext.init(null, new TrustManager[]{defaultTrustManager}, new SecureRandom());
        socketFactory = sslContext.getSocketFactory();
        SSLContext.setDefault(sslContext);
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return socketFactory.getDefaultCipherSuites();
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return socketFactory.getSupportedCipherSuites();
    }

    @Override
    public Socket createSocket(Socket s, String host, int port, boolean autoClose)
            throws IOException {
        return socketFactory.createSocket(s, host, port, autoClose);
    }

    @Override
    public Socket createSocket(String host, int port) throws IOException {
        SSLSocketFactory socketFactory = sslContext.getSocketFactory();
        return this.socketFactory.createSocket(host, port);
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost, int localPort)
            throws IOException {
        return socketFactory.createSocket(host, port, localHost, localPort);
    }

    @Override
    public Socket createSocket(InetAddress host, int port) throws IOException {
        return socketFactory.createSocket(host, port);
    }

    @Override
    public Socket createSocket(InetAddress address, int port, InetAddress localAddress,
                               int localPort) throws IOException {
        return socketFactory.createSocket(address, port, localAddress, localPort);
    }
}
