package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author leakey.li
 * @description:
 * @date Created in 3:15 下午 2021/10/18.
 */
@Slf4j
public class TimeZoneUtil {

    /**
     * 格林尼标准时区
     */
    public static final String GMT_CODE = "GMT";
    /**
     * 北京时间
     */
    public static final String CN_CODE = "Asia/Shanghai";

    /**
     * 获取城市所在时区
     *
     * @param targetId 目标时区id 比如：America/New_York
     * @return string 时区 比如：+08:00
     */
    public static String getTimeZone(String targetId) {
        //校验入参是否合法
        if (null == targetId || "".equals(targetId)) {
            return null;
        }

        try {
            TimeZone timeZone = TimeZone.getTimeZone(targetId);
            SimpleDateFormat outputFormat = new SimpleDateFormat("Z");
            outputFormat.setTimeZone(timeZone);
            Date date = new Date(System.currentTimeMillis());

            //加上冒号显示，把+0800转成+08:00
            StringBuilder stringBuilder = new StringBuilder("GMT");
            stringBuilder.append(outputFormat.format(date));
            return stringBuilder.insert(6, StrPool.C_COLON).toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * @param sourceZoneId 源时区Id 比如：America/New_York
     * @param targetZoneId 目标时区Id 比如：GMT
     * @param sourceDate   源日期
     * @return 转后日期
     * @description 将日期通过时区ID转换为目标时区Id对应的日期
     * @author leakey.li
     * @date 2021/10/27
     * @time 10:42 上午
     */
    public static Date convertTargetTimeZoneDate(String sourceZoneId, String targetZoneId, Date sourceDate) {
        if (sourceDate == null) {
            return null;
        }
        ZoneId sourceZone;
        if (sourceZoneId == null) {
            sourceZone = ZoneId.systemDefault();
        } else {
            sourceZone = ZoneId.of(sourceZoneId);
        }
        ZoneId targetZone;
        if (targetZoneId == null) {
            targetZone = ZoneId.systemDefault();
        } else {
            targetZone = ZoneId.of(targetZoneId);
        }
        ZonedDateTime sourceZonedDateTime = ZonedDateTime.ofInstant(sourceDate.toInstant(), sourceZone);
        ZonedDateTime targetZonedDateTime = sourceZonedDateTime.withZoneSameInstant(targetZone);
        //处理重叠问题
        long hours = Duration.between(targetZonedDateTime.withEarlierOffsetAtOverlap(),
                targetZonedDateTime.withLaterOffsetAtOverlap()).toHours();
        targetZonedDateTime = targetZonedDateTime.plusHours(hours);

        return Date.from(targetZonedDateTime.toLocalDateTime().atZone(sourceZone).toInstant());
    }

}
