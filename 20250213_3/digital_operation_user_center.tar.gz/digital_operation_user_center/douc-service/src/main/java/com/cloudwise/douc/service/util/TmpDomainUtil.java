package com.cloudwise.douc.service.util;

import com.cloudwise.douc.service.service.IDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author zafir.zhong
 * @description 临时的域使用协助
 * @date Created in 00:44 2023/10/4.
 */
@Component
public class TmpDomainUtil {

    private static IDomainService domainService;

    @Autowired
    public void setDomainService(IDomainService domainService) {
        TmpDomainUtil.domainService = domainService;
    }

    /**
     * accountId转换。
     * 由于打开了域之后所有的accountId会变成domainId
     * 所以当出现混乱的时候可以进行转换
     * 转换方式如下：
     *  accountId = TmpDomainUtil.translateDomainToAccount(accountId);
     * @param domainId
     * @return
     */
    public static Long translateDomainToAccount(Long domainId) {
        return domainService.translateDomainToAccount(domainId);
    }
}
