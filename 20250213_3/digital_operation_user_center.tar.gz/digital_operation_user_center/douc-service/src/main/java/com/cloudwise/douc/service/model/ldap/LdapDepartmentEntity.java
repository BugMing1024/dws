package com.cloudwise.douc.service.model.ldap;

import lombok.Data;

import java.util.Map;

/**
 * @author Bernie
 * @date 2020-07-31 16:51
 */
@Data
public class LdapDepartmentEntity {
    private Long id;
    private Integer level;
    private String name;
    private Long parentId;
    private String ou;
    private Map<String, Object> baseMappingAttr;
    private Map<String, Object> extendMappingAttr;
}
