package com.cloudwise.douc.service.model.mq;

import lombok.Data;

import java.io.Serializable;

/**
 * 前台、后台数据同步mq消息体
 *
 * @author maker.wang
 * @date 2021-09-22 16:26
 **/
@Data
public class EnterpriseStatus implements Serializable {
    private static final long serialVersionUID = -1664625306048476449L;

    /**
     * 企业名称/顶级租户名称
     **/
    private Long accountId;

    /**
     * 企业启停状态 1启用，2停用
     **/
    private Integer status;

}
