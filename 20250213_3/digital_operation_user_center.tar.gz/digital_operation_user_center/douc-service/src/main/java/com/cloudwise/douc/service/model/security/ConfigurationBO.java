package com.cloudwise.douc.service.model.security;

import com.cloudwise.douc.commons.model.BaseEntity;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 安全策略管理-响应实体
 *
 * @Author maker.wang
 * @Date 2021-05-24 10:56
 **/
@Getter
@Setter
public class ConfigurationBO extends BaseEntity {

    private static final long serialVersionUID = 6577522579781337170L;
    /**
     * 租户id
     */
    @NotBlank(message = IBaseExceptionCode.SYSTEM_SETTING_ACCOUNT_ID_NOT_NULL)
    private String accountId;
    /**
     * 用户id
     */
    @NotNull(message = IBaseExceptionCode.SYSTEM_SETTING_UPDATE_USER_ID_NOT_NULL)
    private Long userId;

    private ConfigurationDTO configuration;
}
