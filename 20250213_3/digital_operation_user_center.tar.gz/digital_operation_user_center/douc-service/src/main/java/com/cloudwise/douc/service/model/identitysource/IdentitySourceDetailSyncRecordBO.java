package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 获取详细同步记录入参实体
 *
 * @author maker.wang
 * @date 2022-04-18 14:11
 **/
@Data
@ApiModel("获取详细同步记录入参实体")
public class IdentitySourceDetailSyncRecordBO implements Serializable {
    private static final long serialVersionUID = -6170277498665238310L;

    public IdentitySourceDetailSyncRecordBO() {
        this.current = 1;
        this.size = 30;
        this.dataSyncType = 1;
    }

    @ApiModelProperty(value = "sys_identity_source_sync_data_hand_record 主键自增id 或null")
    private Long id;

    @ApiModelProperty("数据同步类型 1:手动执行 2 定时同步 ")
    @NotNull(message = IBaseExceptionCode.IDENTITY_SOURCE_SYNC_TYPE_NULL)
    @Range(min = 1, max = 3, message = "数据同步类型 1:手动执行 2 定时同步 3: 回调事件/实时同步")
    private Integer dataSyncType;

    @ApiModelProperty(value = "对象类型 1:组织,2:用户 sys_identity_source_sync_data_record.data_type")
    private Integer dataType;

    @ApiModelProperty(value = "对象名称 sys_identity_source_sync_data_record.data_name")
    private String dataName;

    @ApiModelProperty(value = "操作类型1:新增,2:修改,3:删除 sys_identity_source_sync_data_record.operate_type")
    private Integer operateType;

    @ApiModelProperty(value = "0:初始化状态,1:成功,2:失败 sys_identity_source_sync_data_record.status")
    private Integer status;

    @ApiModelProperty(value = "查询开始时间 毫秒")
    private Long startTime;

    @ApiModelProperty(value = "查询结束时间 毫毛")
    private Long endTime;

    @ApiModelProperty(value = "当前页 默认1", required = true)
    private Integer current;

    @ApiModelProperty(value = "每页条数 默认30条")
    private Integer size;

    @ApiModelProperty(value = "身份源id")
    private Integer identitySourceId;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
