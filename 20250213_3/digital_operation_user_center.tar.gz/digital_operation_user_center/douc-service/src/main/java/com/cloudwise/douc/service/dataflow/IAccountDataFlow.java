package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserCountDO;
import com.cloudwise.douc.metadata.model.quota.AccountQuotaInfo;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author brady.liu
 * @description 有关子租户处理
 * @date 2021/7/5
 * @time 15:29
 */
public interface IAccountDataFlow {

    /**
     * @param
     * @return
     * @description 初始化租户用户量至缓存中
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:11
     */
    void loadAllUserCountCache();

    /**
     * @param accountId 顶级租户id
     * @return Map<String, Set < String>> 用户数据缓存，key:租户id，value：去重过后的accountId=userId，样式的数据
     * @description 获取缓存中租户用户量
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:11
     */
    Map<String, Set<String>> getUserCountCache(Long accountId);

    /**
     * @param accountId
     * @return
     * @description 更新租户人数应该增加的缓存内容
     * @author brady.liu
     * @date 2021/7/5
     * @time 16:06
     */
    void setUserCountCacheIncrease(Long accountId, Map<String, Set<String>> countMap);

    /**
     * @param accountId 顶级租户id
     * @param countMap  更新租户缓存数据
     * @return
     * @description 更新租户人应该减少的缓存内容
     * @author brady.liu
     * @date 2021/7/14
     * @time 11:21
     */
    void setUserCountCacheDecrease(Long accountId, Map<String, Set<String>> countMap);

    /**
     * @param accountId 顶级租户id
     * @return
     * @description 重新加载顶级租户下用户量
     * @author brady.liu
     * @date 2021/7/14
     * @time 14:40
     */
    void setUserCountCacheByTopAccountId(Long accountId);


    /**
     * @param accountId 租户id
     * @return
     * @description 查询租户信息
     * @author ken.liang
     * @date 2021/9/8
     * @time 14:40
     */
    AccountDetail getAccountDetailByAccountId(Long accountId);


    /**
     * @param accountIds 租户id
     * @return
     * @description 删除租户信息缓存
     * @author ken.liang
     * @date 2021/9/8
     * @time 14:40
     */
    void deleteAccountDetailCacheByAccountId(List<Long> accountIds);

    /**
     * @param level level
     * @return List<Long> 父租户id集合
     * @description 通过level得到上级的id，屏蔽无效level 0
     * @author brady.liu
     * @date 2021/9/9
     * @time 11:48
     */
    List<Long> getParentId(String level);

    /**
     * @param level level
     * @param id    当前id
     * @return
     * @description 得到包含当前以及父级的id
     * @author brady.liu
     * @date 2021/9/9
     * @time 14:07
     */
    List<Long> getIds(String level, Long id);

    /**
     * @param accountIds 租户ids
     * @param userIds    用户ids
     * @return Map<String, Set < String>>  key：accountId value： 租户id=用户id，拼接内容
     * @description 拼接租户用户id
     * @author brady.liu
     * @date 2021/9/9
     * @time 14:20
     */
    Map<String, Set<String>> montageAccountUserMap(List<Long> accountIds, List<Long> userIds);

    /**
     * @param level                          最终的租户等级
     * @param accountId                      租户id
     * @param topAccountId                   顶级租户id
     * @param userIds                        用户ids
     * @param moveForwardUserAccountRelation 移动前租户用户关系
     * @return
     * @description 通过租户id和用户id更新人数（本方法只针对非顶级租户）
     * @author brady.liu
     * @date 2021/9/24
     * @time 14:33
     */
    void accountPersonNumberCacheAddMethod(String level, Long accountId, Long topAccountId, List<Long> userIds, List<UserCountDO> moveForwardUserAccountRelation);

    /**
     * @param level                        最终的租户等级
     * @param accountId                    租户id
     * @param topAccountId                 顶级租户id
     * @param userIds                      用户ids
     * @param moveAfterUserAccountRelation 移动后租户用户关系
     * @return
     * @description 通过租户id和用户id更新人数（本方法只针对非顶级租户）
     * @author brady.liu
     * @date 2021/9/24
     * @time 14:33
     */
    void accountPersonNumberCacheDeleteMethod(String level, Long accountId, Long topAccountId, List<Long> userIds, List<UserCountDO> moveAfterUserAccountRelation);

    /**
     * @param oldLevel                       旧的租户等级
     * @param level                          最终的租户等级
     * @param accountId                      租户id
     * @param topAccountId                   顶级租户id
     * @param userIds                        用户ids
     * @param moveForwardUserAccountRelation 移动前租户用户关系
     * @param moveAfterUserAccountRelation   移动后租户用户关系
     * @return
     * @description 通过租户id和用户id更新人数（本方法只针对非顶级租户）
     * @author brady.liu
     * @date 2021/9/24
     * @time 14:33
     */
    void accountPersonNumberCacheUpateMethod(String oldLevel, String level, Long accountId, Long topAccountId, List<Long> userIds,
                                             List<UserCountDO> moveForwardUserAccountRelation, List<UserCountDO> moveAfterUserAccountRelation);


    /**
     * @param accountId 租户id
     * @return
     * @description 缓存配额信息
     * @author brady.liu
     * @date 2021/10/11
     * @time 16:09
     */
    void setAccountQuotaInfo(Long accountId, AccountQuotaInfo aqi);

    /**
     * @param accountId 租户id
     * @return
     * @description 查询配额信息
     * @author brady.liu
     * @date 2021/10/11
     * @time 16:10
     */
    AccountQuotaInfo getAccountQuotaInfo(Long accountId);

    /**
     * @description 初始加载配额缓存
     * @author brady.liu
     * @date 2021/10/12
     * @time 16:23
     */
    void loadAllAccountQuotaCache();

    /**
     * 批量减少用户缓存数据
     *
     * @param userAccounInfo
     * @param accountId
     */
    void batchDecreaseAccountPersonNumCache(Map<String, List<UserCountDO>> userAccounInfo, Long accountId);


    void setAccountQuotaMenuInfo(Long accountId, Map<String, List<String>> map);

    Map<String, List<String>> getAccountQuotaMenuInfo(Long accountId);

}
