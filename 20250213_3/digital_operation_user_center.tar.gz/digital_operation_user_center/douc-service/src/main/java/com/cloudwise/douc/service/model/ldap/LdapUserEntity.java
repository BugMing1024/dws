package com.cloudwise.douc.service.model.ldap;

import lombok.Data;

import java.util.Map;

/**
 * @author Bernie
 * @date 2020-08-01 15:40
 */
@Data
public class LdapUserEntity {
    private Long id;
    private Long groupId;
    private String ldapUserId;
    private String repliaceLdapUserId;
    private String dn;
    private String userName;
    private String ldapLoginName;
    private String groupName;
    private Map<String, Object> baseMappingAttr;
    private Map<String, Object> extendMappingAttr;
}
