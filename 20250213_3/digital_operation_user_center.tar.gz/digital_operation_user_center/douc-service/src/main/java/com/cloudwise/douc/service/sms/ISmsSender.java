package com.cloudwise.douc.service.sms;

import com.cloudwise.douc.commons.model.ResultEntity;

import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2021/8/6
 */
public interface ISmsSender {


    String getId();

    /**
     * 发送短信至手机
     *
     * @param code
     * @param phone
     * @param content
     * @return
     */
    ResultEntity sendMsg(String code, String phone, String content);

    String getTemplateCode(Map<String, Object> map);
}
