package com.cloudwise.douc.service.model.role;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class RoleResourceMultiTypeZabbixRelation {
    /**
     * 权限
     */
    @ApiModelProperty(value = "权限")
    private String authority;
    /**
     * 主机组IDz
     */
    @ApiModelProperty(value = "主机组IDz")
    private String id;
    /**
     * 主机名称
     */
    @ApiModelProperty(value = "主机名称")
    private String name;
}
