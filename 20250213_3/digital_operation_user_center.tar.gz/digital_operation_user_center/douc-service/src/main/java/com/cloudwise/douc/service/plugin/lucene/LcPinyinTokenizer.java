package com.cloudwise.douc.service.plugin.lucene;

import com.cloudwise.douc.commons.config.ConfigUtils;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Set;

public class LcPinyinTokenizer extends Tokenizer {
    
    private final CharTermAttribute termAtt = this.addAttribute(CharTermAttribute.class);
    
    private final OffsetAttribute offsetAtt = this.addAttribute(OffsetAttribute.class);
    
    private final PositionIncrementAttribute posIncrAtt = this.addAttribute(PositionIncrementAttribute.class);
    
    private String[] pinyin;
    
    private int i;
    
    private int length;
    
    private String getNext() throws IOException {
        if (pinyin == null) {
            try (BufferedReader reader = new BufferedReader(input)) {
                String chines = reader.readLine();
                if (chines == null) {
                    return null;
                }
                length = chines.length();
                Set<String> strings = Pinyin4jUtils.pinyinTerm(chines.toUpperCase(),
                        ConfigUtils.getInt("lucene.sync.mode", 2), ConfigUtils.getInt("lucene.sync.max", 10000));
                pinyin = strings.toArray(new String[] {});
            }
        }
        if (i < pinyin.length) {
            return pinyin[i++];
        }
        return null;
    }
    
    @Override
    public boolean incrementToken() throws IOException {
        clearAttributes();
        
        String s = getNext();
        if (s == null) {
            return false;
        }
        //设置词元文本
        termAtt.append(s);
        //设置词元长度
        termAtt.setLength(s.length());
        //设置词元位移
        offsetAtt.setOffset(0, length);
        //词元增量
        posIncrAtt.setPositionIncrement(1);
        return true;
        
    }
    
    
    @Override
    public void reset() throws IOException {
        super.reset();
        length = 0;
        i = 0;
        pinyin = null;
    }
    
    @Override
    public void end() throws IOException {
        super.end();
    }
    
}
