package com.cloudwise.douc.service.model.identitysource;

import lombok.Data;

import java.util.List;

@Data
public class IdentityUserUpdateField {

    private List<String> baseFieldList;

    private List<String> extendFieldList;

}
