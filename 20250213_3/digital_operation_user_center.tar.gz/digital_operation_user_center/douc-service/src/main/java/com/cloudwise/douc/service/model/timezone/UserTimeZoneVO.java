package com.cloudwise.douc.service.model.timezone;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户时区
 *
 * @author leakey.li
 * @description:
 * @date Created in 5:49 下午 2021/10/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel
public class UserTimeZoneVO implements Serializable {
    /**
     * 时区
     */
    @ApiModelProperty(value = "时区")
    private String timeZone;
    /**
     * 国家对应code
     */
    @ApiModelProperty(value = "国家对应code")
    private String countryCityCode;
    /**
     * 国家城市
     */
    @ApiModelProperty(value = "国家城市")
    private String countryCity;
    /**
     * 系统时区
     */
    @ApiModelProperty(value = "系统时区")
    private String systemTimeZone;
    /**
     * 系统时区 back
     */
    @ApiModelProperty(value = "系统时区 back")
    @JsonIgnore
    private String systemTimeZoneBack;
    /**
     * 系统时区Code
     */
    @ApiModelProperty(value = "系统时区Code")
    private String systemTimeZoneCode;
    /**
     * 是否是系统时区 true：是 ，false：否
     */
    @ApiModelProperty(value = "是否是系统时区 true：是 ，false：否")
    private Boolean isSystemTimeZone;

}
