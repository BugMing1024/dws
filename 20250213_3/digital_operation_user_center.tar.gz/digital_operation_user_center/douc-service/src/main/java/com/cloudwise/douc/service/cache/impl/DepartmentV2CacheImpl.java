package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IModuleAccountDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.model.department.DepartmentNode;
import com.cloudwise.douc.metadata.model.user.UserDepartmentDO;
import com.cloudwise.douc.service.cache.IDepartmentV2Cache;
import com.cloudwise.douc.service.model.department.DepartmentNodeCacheDTO;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * @ProjectName: digital_operation_user_center
 * @Package: com.cloudwise.douc.service.cache.impl
 * @ClassName: DepartmentV2CacheImpl
 * @Author: bradyliu
 * @Description: 部门缓存V2版本
 * @Date: 2021/5/17 5:07 下午
 * @Version: 1.0
 */
@Component
@Slf4j
public class DepartmentV2CacheImpl implements IDepartmentV2Cache {

    @Autowired
    private IDepartmentDao departmentDao;
    @Autowired
    private IModuleAccountDao moduleAccountDao;
    @Autowired
    private IAccountService accountService;
    @Autowired
    private IUserDao userDao;

    @Override
    public Map<Long, DepartmentNodeCacheDTO> getDepartmentMap(Long accountId, List<Long> ids) {

        if (ids.isEmpty()) {
            return new HashMap();
        }

        Map<String, DepartmentNodeCacheDTO> departmentStrs = RedisTools.hmget(
                getAccountDepartmentCacheKey(accountId),
                DepartmentNodeCacheDTO.class,
                ids.stream().map(id -> id + "").collect(Collectors.toList()));

        if (Objects.isNull(departmentStrs) || departmentStrs.isEmpty()) {
            return null;
        }
        // 输出内容
        Map<Long, DepartmentNodeCacheDTO> departmentLongs = Maps.newHashMapWithExpectedSize(departmentStrs.size());
        Set<Map.Entry<String, DepartmentNodeCacheDTO>> entries = departmentStrs.entrySet();
        for (Map.Entry<String, DepartmentNodeCacheDTO> entry : entries) {
            departmentLongs.put(Long.valueOf(entry.getKey()), entry.getValue());
        }

        return departmentLongs;
    }

    @Override
    public Boolean setDepartmentMap(Long accountId, Map<Long, DepartmentNodeCacheDTO> departmentMap) {
        // 输出内容
        Map<String, DepartmentNodeCacheDTO> departmentStrs = Maps.newHashMapWithExpectedSize(departmentMap.size());
        Set<Map.Entry<Long, DepartmentNodeCacheDTO>> entries = departmentMap.entrySet();
        for (Map.Entry<Long, DepartmentNodeCacheDTO> entry : entries) {
            departmentStrs.put(String.valueOf(entry.getKey().longValue()), entry.getValue());
        }

        return RedisTools.hmset(
                getAccountDepartmentCacheKey(accountId),
                departmentStrs);
    }

    @Override
    public Boolean deleteDepartment(Long accountId, List<Long> ids) {
        return RedisTools.hdel(
                getAccountDepartmentCacheKey(accountId),
                ids.stream().map(String::valueOf).collect(Collectors.toList()));
    }

    @Override
    public void loadAllDepartmentToCache() {
        
        // 循环查询所有部门数据
        List<DepartmentNodeCacheDTO> departments = this.getAllDepartments();
        // 删除所有部门缓存
        this.deleteAllDepartmentCache();
        if (Objects.nonNull(departments) && !departments.isEmpty()) {
            // 缓存数据
            this.cacheDepartment(departments);
        }
    }

    @Override
    public void loadSingleDepartmentToCache(Long accountId) {
        //删除缓存
        List<Long> accountIds = new ArrayList<>();
        accountIds.add(accountId);
        if (CollectionUtils.isNotEmpty(accountIds)) {
            RedisTools.deleteValueByKeys(
                    accountIds.stream()
                            .map(e -> getAccountDepartmentCacheKey(e))
                            .collect(Collectors.toList())
            );
        }
        List<DepartmentNodeCacheDTO> departments = this.getSingleDepartments(accountId);
        if (Objects.isNull(departments) || departments.isEmpty()) {
            throw new BaseException(IBaseExceptionCode.API_DEPARMENT_ID_NOT_EXIST);
        }
        // 缓存数据
        this.cacheDepartment(departments);
    }

    /**
     * 缓存数据
     *
     * @param departments
     */
    private void cacheDepartment(List<DepartmentNodeCacheDTO> departments) {

        Map<Long, Map<String, DepartmentNodeCacheDTO>> accountCacheDepartmentNodeMap = Maps.newHashMap();
        for (DepartmentNodeCacheDTO departmentNode : departments) {
            Map<String, DepartmentNodeCacheDTO> cacheDepartmentNodeMap =
                    accountCacheDepartmentNodeMap.computeIfAbsent(departmentNode.getAccountId(), k -> Maps.newHashMap());
            cacheDepartmentNodeMap.put(String.valueOf(departmentNode.getId().longValue()), departmentNode);
        }
        // 循环更新缓存
        accountCacheDepartmentNodeMap.forEach((accountId, cacheDepartmentNodeMap) -> {
            boolean hmsetResult = RedisTools.hmset(getAccountDepartmentCacheKey(accountId), cacheDepartmentNodeMap);
            if (!hmsetResult) {
                log.error("department cache initialization failed");
                throw new BaseException(IBaseExceptionCode.CACHE_ERROR);
            } else {
                log.info("department cache,size：{}", cacheDepartmentNodeMap.size());
            }

        });

    }

    /**
     * 删除缓存
     */
    private void deleteAllDepartmentCache() {
        List<Long> accountIds = moduleAccountDao.listAllAccountId();
        if (CollectionUtils.isNotEmpty(accountIds)) {
            RedisTools.deleteValueByKeys(
                    accountIds.stream()
                            .map(accountId -> getAccountDepartmentCacheKey(accountId))
                            .collect(Collectors.toList())
            );
        }
    }

    /**
     * 获取所有部门信息
     *
     * @return List<DepartmentNode> departments
     */
    private List<DepartmentNodeCacheDTO> getAllDepartments() {
    
        List<DepartmentNodeCacheDTO> departmentNodeCacheDTOS = Lists.newArrayListWithExpectedSize(32);
        // 先查询租户信息

        List<Long> allAccountId = this.accountService.getAllAccountId();
        // 部门list，从map中取值
        // 循环用户和level拼接，放入到 Map<Long,Set<departmentId_userId>> \
        Map<Long, Set<String>> userDepartmentMap = new HashMap<>();
        Map<Long, Set<String>> userDepartmentUseMap = new HashMap<>();
        for (Long accountId : allAccountId) {
            userDepartmentMap.clear();
            userDepartmentUseMap.clear();
            // sql中加上租户内容

            // 查询部门
            // 是否需要放入到文件开始
            final int batchSize = 10000;
            List<DepartmentNode> finaleDepartmentNodeList = Lists.newArrayList();
            // 循环查询
            long lastMaxId = 0L;
            while (true) {
                List<DepartmentNode> departmentNodeList = departmentDao.getDepartmentByPatch(lastMaxId, batchSize, accountId);
                finaleDepartmentNodeList.addAll(departmentNodeList);
                if (departmentNodeList.size() < batchSize) {
                    if (departmentNodeList.size() != 0) {
                        log.info("department inquiry startId:{},endId:{}", lastMaxId, departmentNodeList.get(departmentNodeList.size() - 1).getId());
                        break;
                    }
                    break;
                } else {
                    log.info("department inquiry startId:{},endId:{}", lastMaxId, departmentNodeList.get(departmentNodeList.size() - 1).getId());
                    lastMaxId = departmentNodeList.get(departmentNodeList.size() - 1).getId();
                }
            }


            // 查询部门下所有用户
            // 仅仅处理用户人数
            // 查询用户关系，拼接用户和部门level，用户状态，是否是启停，通过accountid进行关联

            final int userBatchSize = 10000;
            List<UserDepartmentDO> finaleUserDepartmentDOList = Lists.newArrayList();
            // 循环查询
            long departmentUserLastMaxId = 0L;
            while (true) {
                List<UserDepartmentDO> userDepartmentDOList = userDao.getUserByPatch(departmentUserLastMaxId, userBatchSize, accountId);
                finaleUserDepartmentDOList.addAll(userDepartmentDOList);
                if (userDepartmentDOList.size() < batchSize) {
                    if (userDepartmentDOList.size() != 0) {
                        log.info("departmentUser inquiry startId:{},endId:{}", departmentUserLastMaxId, userDepartmentDOList.get(userDepartmentDOList.size() - 1).getId());
                        break;
                    }
                    break;
                } else {
                    log.info("departmentUser inquiry startId:{},endId:{}", departmentUserLastMaxId, userDepartmentDOList.get(userDepartmentDOList.size() - 1).getId());
                    departmentUserLastMaxId = userDepartmentDOList.get(userDepartmentDOList.size() - 1).getId();
                }
            }
            
            // su.user_id,'_',sd.`level`,'.',sd.id  用户id_level.departmentId
            if (finaleUserDepartmentDOList.size() > 0) {
                for (UserDepartmentDO userDepartmentDO : finaleUserDepartmentDOList) {
                    String[] split = StringUtils.split(userDepartmentDO.getUserIdLevel(), "\\_");
                    if (split != null) {
                        String userId = split[0];
                        if (split[1] != null) {
                            String[] split1 = StringUtils.split(split[1], Constant.LEVEL_SPLIT_REGEX);
                            if (split1 != null) {
                                for (String s : split1) {
                                    if (!Constant.FIRST_LEVEL.equals(s)) {
                                        Set<String> userDepartmentSet = userDepartmentMap.getOrDefault(Long.valueOf(s), new TreeSet<String>());
                                        userDepartmentSet.add(s + StrPool.UNDERLINE + userId);
                                        userDepartmentMap.put(Long.valueOf(s), userDepartmentSet);
                                        if (Constant.STATUS_UP.equals(userDepartmentDO.getStatus())) {
                                            Set<String> userDepartmentUseSet = userDepartmentUseMap.getOrDefault(Long.valueOf(s), new TreeSet<String>());
                                            userDepartmentUseSet.add(s + StrPool.UNDERLINE + userId);
                                            userDepartmentUseMap.put(Long.valueOf(s), userDepartmentUseSet);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // 存入到缓存中
            if (finaleDepartmentNodeList.size() > 0) {
                for (DepartmentNode departmentNode : finaleDepartmentNodeList) {
                    Set<String> perNum = userDepartmentMap.get(departmentNode.getId());
                    Set<String> perNumUse = userDepartmentUseMap.get(departmentNode.getId());
                    departmentNode.setPerNum(perNum != null ? perNum.size() : 0);
                    departmentNode.setPerNumInUse(perNumUse != null ? perNumUse.size() : 0);
                }
            }
            for (DepartmentNode departmentNode : finaleDepartmentNodeList) {
                DepartmentNodeCacheDTO departmentNodeCacheDTO = new DepartmentNodeCacheDTO();
                BeanUtils.copyProperties(departmentNode, departmentNodeCacheDTO);
                departmentNodeCacheDTOS.add(departmentNodeCacheDTO);
            }

        }
        return departmentNodeCacheDTOS;
    }

    /**
     * 通过accountId和常量获取到缓存的部门key
     *
     * @param accountId
     * @return
     */
    private static String getAccountDepartmentCacheKey(Long accountId) {
        return CacheConstant.REDIS_CACHE_KEY_DEPARTMENTNODE_HASH_KEY + accountId;
    }

    /**
     * 获取单个部门信息
     *
     * @return List<DepartmentNode> departments
     */
    private List<DepartmentNodeCacheDTO> getSingleDepartments(Long accountId) {
        // 先查询租户信息

        // sql中加上租户内容

        // 查询部门
        // 是否需要放入到文件开始
        final int batchSize = 10000;
        List<DepartmentNode> finaleDepartmentNodeList = Lists.newArrayList();
        // 循环查询
        long lastMaxId = 0L;
        while (true) {
            List<DepartmentNode> departmentNodeList = departmentDao.getDepartmentByPatch(lastMaxId, batchSize, accountId);
            finaleDepartmentNodeList.addAll(departmentNodeList);
            if (departmentNodeList.size() < batchSize) {
                if (departmentNodeList.size() != 0) {
                    log.info("department inquiry startId:{},endId:{}", lastMaxId, departmentNodeList.get(departmentNodeList.size() - 1).getId());
                    break;
                }
                break;
            } else {
                log.info("department inquiry startId:{},endId:{}", lastMaxId, departmentNodeList.get(departmentNodeList.size() - 1).getId());
                lastMaxId = departmentNodeList.get(departmentNodeList.size() - 1).getId();
            }
        }


        // 查询部门下所有用户
        // 仅仅处理用户人数
        // 查询用户关系，拼接用户和部门level，用户状态，是否是启停，通过accountid进行关联

        final int userBatchSize = 10000;
        List<UserDepartmentDO> finaleUserDepartmentDOList = Lists.newArrayList();
        // 循环查询
        long userLastMaxId = 0L;
        while (true) {
            List<UserDepartmentDO> userDepartmentDOList = userDao.getUserByPatch(userLastMaxId, userBatchSize, accountId);
            finaleUserDepartmentDOList.addAll(userDepartmentDOList);
            if (userDepartmentDOList.size() < batchSize) {
                if (userDepartmentDOList.size() != 0) {
                    log.info("department inquiry startId:{},endId:{}", userLastMaxId, userDepartmentDOList.get(userDepartmentDOList.size() - 1).getId());
                    break;
                }
                break;
            } else {
                log.info("department inquiry startId:{},endId:{}", userLastMaxId, userDepartmentDOList.get(userDepartmentDOList.size() - 1).getId());
                userLastMaxId = userDepartmentDOList.get(userDepartmentDOList.size() - 1).getId();
            }
        }
        // 部门list，从map中取值
        // 循环用户和level拼接，放入到 Map<Long,Set<departmentId_userId>> \
        Map<Long, Set<String>> userDepartmentMap = new HashMap();
        Map<Long, Set<String>> userDepartmentUseMap = new HashMap();
        // su.user_id,'_',sd.`level`,'.',sd.id  用户id_level.departmentId
        if (finaleUserDepartmentDOList != null && finaleUserDepartmentDOList.size() > 0) {
            for (UserDepartmentDO userDepartmentDO : finaleUserDepartmentDOList) {
                String[] split = StringUtils.split(userDepartmentDO.getUserIdLevel(), "\\_");
                if (split != null) {
                    String userId = split[0];
                    if (split[1] != null) {
                        String[] split1 = StringUtils.split(split[1], Constant.LEVEL_SPLIT_REGEX);
                        if (split1 != null) {
                            for (String s : split1) {
                                if (!Constant.FIRST_LEVEL.equals(s)) {
                                    Set<String> userDepartmentSet = userDepartmentMap.getOrDefault(Long.valueOf(s), new TreeSet<String>());
                                    userDepartmentSet.add(s + StrPool.UNDERLINE + userId);
                                    userDepartmentMap.put(Long.valueOf(s), userDepartmentSet);
                                    if (Constant.STATUS_UP.equals(userDepartmentDO.getStatus())) {
                                        Set<String> userDepartmentUseSet = userDepartmentUseMap.getOrDefault(Long.valueOf(s), new TreeSet<String>());
                                        userDepartmentUseSet.add(s + StrPool.UNDERLINE + userId);
                                        userDepartmentUseMap.put(Long.valueOf(s), userDepartmentUseSet);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // 存入到缓存中
        if (finaleDepartmentNodeList != null && finaleDepartmentNodeList.size() > 0) {
            for (DepartmentNode departmentNode : finaleDepartmentNodeList) {
                Set<String> perNum = userDepartmentMap.get(departmentNode.getId());
                Set<String> perNumUse = userDepartmentUseMap.get(departmentNode.getId());
                departmentNode.setPerNum(perNum != null ? perNum.size() : 0);
                departmentNode.setPerNumInUse(perNumUse != null ? perNumUse.size() : 0);
            }
        }
        
        List<DepartmentNodeCacheDTO> departmentNodeCacheDTOS = Lists.newArrayListWithExpectedSize(finaleDepartmentNodeList.size());
        for (DepartmentNode departmentNode : finaleDepartmentNodeList) {
            DepartmentNodeCacheDTO departmentNodeCacheDTO = new DepartmentNodeCacheDTO();
            BeanUtils.copyProperties(departmentNode, departmentNodeCacheDTO);
            departmentNodeCacheDTOS.add(departmentNodeCacheDTO);
        }

        return departmentNodeCacheDTOS;
    }


}
