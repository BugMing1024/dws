package com.cloudwise.douc.service.model.token;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author maker.wang
 * @description: token生成所需的参数
 * @date Created in 2:58 下午 2021/6/2.
 */
@Data
public class TokenGenerateParams implements Serializable {

    private static final long serialVersionUID = -1572946139893712375L;

    /**
     * 应用
     */
    @NotBlank(message = IBaseExceptionCode.API_HTTP_TOKEN_GENERATE_LACK_PARAM)
    private String appKey;

    /**
     * 应用密钥 需加密，appSecret+"---"+timestamp传输 sm2加密,  服务端验证timestamp必须是当前时间的前三分钟内，即3分钟有效
     */
    @NotBlank(message = IBaseExceptionCode.API_HTTP_TOKEN_GENERATE_LACK_PARAM)
    private String appSecret;

    /**
     * 用户别名
     */
    @NotBlank(message = IBaseExceptionCode.API_HTTP_TOKEN_GENERATE_LACK_PARAM)
    private String userAlias;

    /**
     * 加密算法 默认sm2
     */
    private String encrypt;

    /**
     * 租户id
     */
    private Long accountId;
}
