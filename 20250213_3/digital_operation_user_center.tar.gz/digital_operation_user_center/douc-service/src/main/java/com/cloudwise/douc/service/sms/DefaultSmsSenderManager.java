package com.cloudwise.douc.service.sms;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2021/8/6
 */
@Component
public class DefaultSmsSenderManager implements ISmsSenderManager, BeanPostProcessor {


    private Map<String, ISmsSender> smsSenderMap = new ConcurrentHashMap<>();

    @Override
    public ISmsSender getSmsSender(String id) {
        return smsSenderMap.get(id);
    }

    @Override
    public void register(ISmsSender smsSender) {
        synchronized (ISmsSender.class) {
            smsSenderMap.put(smsSender.getId(), smsSender);
        }
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof ISmsSender) {
            register((ISmsSender) bean);
        }
        return bean;
    }
}
