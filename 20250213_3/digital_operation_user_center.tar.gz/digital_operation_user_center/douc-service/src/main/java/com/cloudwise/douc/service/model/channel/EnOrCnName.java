package com.cloudwise.douc.service.model.channel;

import lombok.Data;

/**
 * @author zafir.zhong
 * @description 中英文名
 * @date Created in 21:35 2022/5/19.
 */
@Data
public class EnOrCnName {

    private String en;

    private String cn;
}
