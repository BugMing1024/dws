package com.cloudwise.douc.service.util.token.sm.cert;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

public class FileSNAllocator implements CertSNAllocator {
    private static final String SN_FILENAME = "sn.dat";
    private static String snFilePath;

    static {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        snFilePath = Objects.requireNonNull(loader.getResource(SN_FILENAME)).getPath();
    }

    @Override
    public synchronized BigInteger nextSerialNumber() throws Exception {
        BigInteger sn = readSN();
        writeSN(sn.add(BigInteger.ONE));
        return sn;
    }

    private BigInteger readSN() throws IOException {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(snFilePath, "r");
            byte[] data = new byte[(int) raf.length()];
            raf.read(data);
            String snStr = new String(data, StandardCharsets.UTF_8);
            return new BigInteger(snStr);
        } finally {
            if (raf != null) {
                raf.close();
            }
        }
    }

    private void writeSN(BigInteger sn) throws IOException {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(snFilePath, "rw");
            raf.writeBytes(sn.toString(10));
        } finally {
            if (raf != null) {
                raf.close();
            }
        }
    }
}
