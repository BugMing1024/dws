package com.cloudwise.douc.service.model.app;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/17/11:37 上午
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppApiPermissonVo {

    private static final long serialVersionUID = 1L;

    private String id;
    private String limitInfo;
    private String accountId;

    private String expireTime;
    /**
     * 0-永久，1-短期
     **/
    private Integer bindType;
    /**
     * 状态[0:停用，1:启用]
     **/
    private Integer status;
}
