package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.service.cache.IDepartmentDataCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class DepartmentDataCacheImpl implements IDepartmentDataCache {
    @Override
    public String getDepartmentDataByDepartmentId(Long accountId, Long departmentId) {
        return RedisTools.getByte(this.getDepartmentDataTypeKey(accountId, departmentId), String.class);
    }

    @Override
    public void setDepartmentDataByDepartmentId(Long accountId, Long departmentId, String departmentInfo) {
        RedisTools.setByteWithTime(this.getDepartmentDataTypeKey(accountId, departmentId), departmentInfo, 60 * 10);
    }

    private String getDepartmentDataTypeKey(Long accountId, Long userId) {
        return CacheConstant.REDIS_CACHE_KEY_USERDEPARTMENT_DATA_KEY + accountId + StrPool.C_COLON + userId;
    }
}
