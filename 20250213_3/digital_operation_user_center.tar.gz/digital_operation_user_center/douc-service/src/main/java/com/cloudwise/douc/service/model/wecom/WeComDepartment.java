package com.cloudwise.douc.service.model.wecom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComDepartment implements Serializable {

    @JsonProperty(value = "id")
    private String id;

    @JsonProperty(value = "name")
    private String name;

    @JsonProperty(value = "parentid")
    private String parentId;

    @JsonProperty(value = "order")
    private long order;

    @JsonProperty(value = "department_leader")
    private List<String> departmentLeaderList;

}
