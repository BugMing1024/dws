package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.utils.XssCleanRuleUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * RequestUtil
 *
 * @author liam
 * @date 2020/09/22
 */
public class RequestUtil {

    private static final String UNKNOWN = "unknown";

    private static final String LOCAL_IP4 = "127.0.0.1";
    private static final String LOCAL_IP6 = "0:0:0:0:0:0:0:1";

    public static String getRealIP(HttpServletRequest request) {
        String ip = null;

        //X-Forwarded-For：Squid 服务代理
        String ipAddresses = request.getHeader("X-Forwarded-For");
        ipAddresses = XssCleanRuleUtils.xssClean(ipAddresses);
        if (ipAddresses == null || ipAddresses.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddresses)) {
            //Proxy-Client-IP：apache 服务代理
            ipAddresses = XssCleanRuleUtils.xssClean(request.getHeader("Proxy-Client-IP"));
        }

        if (ipAddresses == null || ipAddresses.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddresses)) {
            //WL-Proxy-Client-IP：weblogic 服务代理
            ipAddresses = XssCleanRuleUtils.xssClean(request.getHeader("WL-Proxy-Client-IP"));
        }

        if (ipAddresses == null || ipAddresses.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddresses)) {
            //HTTP_CLIENT_IP：有些代理服务器
            ipAddresses = XssCleanRuleUtils.xssClean(request.getHeader("HTTP_CLIENT_IP"));
        }

        if (ipAddresses == null || ipAddresses.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddresses)) {
            //X-Real-IP：nginx服务代理
            ipAddresses = XssCleanRuleUtils.xssClean(request.getHeader("X-Real-IP"));
        }

        //有些网络通过多层代理，那么获取到的ip就会有多个，一般都是通过逗号（,）分割开来，并且第一个ip为客户端的真实IP
        if (ipAddresses != null && ipAddresses.length() != 0) {
            ip = ipAddresses.split(StrPool.COMMA)[0];
        }

        //还是不能获取到，最后再通过request.getRemoteAddr();获取
        if (ip == null || ip.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddresses)) {
            ip = XssCleanRuleUtils.xssClean(request.getRemoteAddr());
        }

        if (LOCAL_IP6.equals(ip)) {
            return LOCAL_IP4;
        }

        return ip;
    }
}
