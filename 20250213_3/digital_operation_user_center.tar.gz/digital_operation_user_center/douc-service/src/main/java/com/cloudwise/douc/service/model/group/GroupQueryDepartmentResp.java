package com.cloudwise.douc.service.model.group;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户组关联部门返回PO类
 *
 * @author maker.wang
 * @date 2022-03-04 11:22
 **/
@Data
@ApiModel("用户组关联部门返回PO类")
public class GroupQueryDepartmentResp implements Serializable {
    private static final long serialVersionUID = -6292594307598915475L;

    @ApiModelProperty("部门id")
    private Long id;

    @ApiModelProperty("部门名称")
    private String name;

    @ApiModelProperty("部门全路径 示例: a/b/c")
    private String departmentDetail;

}
