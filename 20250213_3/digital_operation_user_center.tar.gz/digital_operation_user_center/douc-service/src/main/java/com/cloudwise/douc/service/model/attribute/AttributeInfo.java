package com.cloudwise.douc.service.model.attribute;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AttributeInfo {

    private Long id;

    @ApiModelProperty(value = "变量名称")
    private String alias;

    @ApiModelProperty(value = "显示名称")
    private String name;

    @ApiModelProperty(value = "条件类型 JsonCheckboxOne,JsonCheckboxMore,JsonString,JsonInteger,JsonFloat")
    private String type;

    @ApiModelProperty(value = "类型id")
    private Long selectedId;

    @ApiModelProperty(value = "是否是拓展字段 1是 0否")
    private Integer isExtend;
    
    @ApiModelProperty(value = "是否模糊查询 1是 0否")
    private Integer isSearch;
    
    @ApiModelProperty(value = "字段保存时存的值")
    private String saveField;


}
