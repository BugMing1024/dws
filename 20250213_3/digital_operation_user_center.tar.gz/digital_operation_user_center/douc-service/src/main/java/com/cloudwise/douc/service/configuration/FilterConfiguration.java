package com.cloudwise.douc.service.configuration;

import com.cloudwise.douc.facadev3.DomainFacade;
import com.cloudwise.douc.filter.HttpDomainFilter;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

/**
 * @author jiayongming filter管理
 */
@Configuration
@Data
public class FilterConfiguration {

    @Resource
    private RemoteAddrFilter remoteAddrFilter;
    
    @Resource
    private ProtocolDomainFilter protocolDomainFilter;
    
    @Autowired(required = false)
    private DomainFacade domainFacade;

    @Value("${openDomain:false}")
    private boolean openDomain;

    @Bean
    public FilterRegistrationBean<HttpDomainFilter> httpDomainFilterRegister() {
        FilterRegistrationBean<HttpDomainFilter> registration = new FilterRegistrationBean<>();
        HttpDomainFilter httpDomainFilter = new HttpDomainFilter(domainFacade, openDomain);
        //注入过滤器
        registration.setFilter(httpDomainFilter);
        //拦截规则
        registration.addUrlPatterns("/*");
        //过滤器名称
        registration.setName("httpDomainFilter");
        //过滤器顺序
        registration.setOrder(FilterRegistrationBean.LOWEST_PRECEDENCE);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<RemoteAddrFilter> remoteAddrFilterRegister() {
        FilterRegistrationBean<RemoteAddrFilter> registration = new FilterRegistrationBean<>();
        //注入过滤器
        registration.setFilter(remoteAddrFilter);
        //拦截规则
        registration.addUrlPatterns("/*");
        //过滤器名称
        registration.setName("remoteAddrFilter");
        //过滤器顺序
        registration.setOrder(FilterRegistrationBean.LOWEST_PRECEDENCE);
        return registration;
    }
    
    @Bean
    public FilterRegistrationBean<ProtocolDomainFilter> protocolDomainFilterRegister() {
        FilterRegistrationBean<ProtocolDomainFilter> registration = new FilterRegistrationBean<>();
        //注入过滤器
        registration.setFilter(protocolDomainFilter);
        //拦截规则
        registration.addUrlPatterns("/*");
        //过滤器名称
        registration.setName("protocolDomainFilter");
        //过滤器顺序
        registration.setOrder(FilterRegistrationBean.HIGHEST_PRECEDENCE);
        return registration;
    }
    
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper;
    }

}