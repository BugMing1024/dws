package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserInfoDO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author bradyliu
 * @description:
 * @date Created in 19:10 2021/7/1.
 */
@Data
public class AccountDTO implements Serializable {
    private AccountDetail accountDetail;
    private UserInfoDO userInfoDO;
    private List<Long> visibleAccountId;
    private String encrypt;
}
