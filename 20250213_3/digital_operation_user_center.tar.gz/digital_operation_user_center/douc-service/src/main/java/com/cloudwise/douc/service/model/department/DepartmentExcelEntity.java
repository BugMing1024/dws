package com.cloudwise.douc.service.model.department;

import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author bruce.liu Description: No Description
 */
public enum DepartmentExcelEntity {
    /**
     * 机构名称（必填）
     */
    NAME(0, "name", "机构名称（必填）Department name (required)", "机构名称"),
    /**
     * 机构编码（必填）
     */
    CODE(1, "code", "机构编码（必填）Department code (required)", "机构编码"),
    /**
     * 上级机构（必填）
     */
    PARENTCODE(2, "code", "上级机构编码（必填）Parent department code (required)", "上级机构"),
    /**
     * 机构类型
     */
    TYPE(3, "type", "机构类型\n" + "Type", "机构类型"),
    /**
     * 机构状态
     */
    STATUS(4, "status", "机构状态\n" + "Organization status", "机构状态"),
    /**
     * 机构地址
     */
    ADDRESS(5, "address", "机构地址\n" + "Organization address", "机构地址"),
    /**
     * 机构电话
     */
    PHONE(6, "department_tel", "机构电话\n" + "Organization phone", "机构电话");
    
    private int index;
    
    private String fieldName;
    
    private String excelRowName;
    
    private String excelHeadName;
    
    DepartmentExcelEntity(int index, String fieldName, String excelRowName, String excelHeadName) {
        this.index = index;
        this.fieldName = fieldName;
        this.excelRowName = excelRowName;
        this.excelHeadName = excelHeadName;
    }
    
    public static String getExcelRowNameByIndex(int index) {
        for (DepartmentExcelEntity excelEntity : DepartmentExcelEntity.values()) {
            if (index == excelEntity.index) {
                return excelEntity.excelRowName;
            }
        }
        return null;
    }
    
    public static List toExcelHeadName() {
        List list = Lists.newArrayListWithExpectedSize(DepartmentExcelEntity.values().length);
        for (DepartmentExcelEntity excelEntity : DepartmentExcelEntity.values()) {
            list.add(excelEntity.getExcelHeadName());
        }
        return list;
    }
    
    public static List toExcelRowName() {
        List list = Lists.newArrayListWithExpectedSize(DepartmentExcelEntity.values().length);
        for (DepartmentExcelEntity excelEntity : DepartmentExcelEntity.values()) {
            list.add(excelEntity.getExcelRowName());
        }
        return list;
    }
    
    public static int getMaxIndexValue() {
        List<Integer> indexCollect = Arrays.asList(DepartmentExcelEntity.values()).stream().map(excel -> excel.getIndex()).sorted()
                .collect(Collectors.toList());
        return indexCollect.get(indexCollect.size() - 1);
    }
    
    public int getIndex() {
        return index;
    }
    
    public String getFieldName() {
        return fieldName;
    }
    
    public String getExcelRowName() {
        return excelRowName;
    }
    
    public String getExcelHeadName() {
        return excelHeadName;
    }
}
