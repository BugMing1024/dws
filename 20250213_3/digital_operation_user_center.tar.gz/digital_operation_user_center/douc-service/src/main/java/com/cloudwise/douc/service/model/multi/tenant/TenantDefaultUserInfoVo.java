package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.MultiAccountUserInfoDetail;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 租户初始化用户信息
 *
 * @author maker.wang
 * @date 2021-06-30 14:18
 **/
@Data
public class TenantDefaultUserInfoVo implements Serializable {
    private static final long serialVersionUID = 2616222383023164967L;


    /**
     * 用户id
     **/
    @ApiModelProperty(value = "用户id")
    private Long id;

    /**
     * 用户基础信息
     **/
    @ApiModelProperty(value = "用户基础信息")
    private MultiAccountUserInfoDetail userInfoDetail;

    /**
     * 用户
     **/
    @ApiModelProperty(value = "用户")
    private MultiAccountUserDetail userDetail;

}
