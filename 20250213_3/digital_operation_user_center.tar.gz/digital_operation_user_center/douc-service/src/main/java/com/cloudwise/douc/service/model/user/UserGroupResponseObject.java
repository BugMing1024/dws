package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;

/**
 * @author KenLiang
 * @description:
 * @date Created in 8:36 PM 2020/2/17.
 */
@Data
public class UserGroupResponseObject implements Serializable {
    
    private String code;
    private String name;
    
}
