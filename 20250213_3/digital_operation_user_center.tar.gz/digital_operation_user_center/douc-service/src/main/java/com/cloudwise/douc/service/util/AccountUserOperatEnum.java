package com.cloudwise.douc.service.util;

/**
 * @author brady.liu
 * @description 用于租户操作用户方式
 * @return
 * @date 2021/9/24
 * @time 15:40
 */
public enum AccountUserOperatEnum {
    UPDATE("UPDATE"), ADD("ADD"), DELETE("DELETE");
    private final String opera;

    AccountUserOperatEnum(String opera) {
        this.opera = opera;
    }

    public String getOpera() {
        return opera;
    }

}
