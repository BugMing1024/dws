package com.cloudwise.douc.service.model.channel;

import lombok.Data;

/**
 * @author zafir.zhong
 * @description
 * @date Created in 15:37 2022/5/17.
 */
@Data
public class ChannelSettingStatusModifyRequest {

    private Long id;
    private Integer status;

    private Long accountId;

    private Long userId;

    public ChannelSettingStatusModifyRequest fillAccountAndUser(Long accountId, Long userId) {
        this.accountId = accountId;
        this.userId = userId;
        return this;
    }
}
