package com.cloudwise.douc.service.model.group;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel
public class GroupNode {
    @ApiModelProperty(value = "id")
    private Long id;
    @ApiModelProperty(value = "名称")
    private String name;
    @ApiModelProperty(value = "序号")
    private Integer sequence;

    /**
     * 1角色(普通)；2属性(配置了属性)3外部(开启跨租户)
     **/
    @ApiModelProperty(value = "1角色(普通)；2属性(配置了属性)3外部(开启跨租户)")
    private Integer type;
    @ApiModelProperty(value = "属性标识")
    private String label;
    @ApiModelProperty(value = "描述")
    private String description;
    @ApiModelProperty(value = "用户数")
    private Integer resourceCount;
    @JsonInclude
    @ApiModelProperty(value = "字段已废弃")
    private Boolean deleteAllowed = Boolean.FALSE;
    @JsonInclude
    @ApiModelProperty(value = "字段已废弃")
    private Boolean updateAllowed = Boolean.FALSE;
    @JsonInclude
    @ApiModelProperty(value = "字段已废弃")
    private Boolean distributeUser = Boolean.FALSE;
    @JsonInclude
    @ApiModelProperty(value = "字段已废弃")
    private Boolean removeUser = Boolean.FALSE;
    @JsonInclude
    @ApiModelProperty(value = "字段已废弃")
    private Boolean addDataAuth = Boolean.FALSE;
    @ApiModelProperty(value = "子节点")
    private List<GroupNode> children;

    /**
     * 是否是顶级用户组标识 true:顶级用户组 false:子用户组
     **/
    @ApiModelProperty(value = "是否是顶级用户组标识 true:顶级用户组 false:子用户组")
    private Boolean groupIsTop = Boolean.FALSE;

    public void addChildren(GroupNode node) {
        if (children == null) {
            children = Lists.newArrayList();
        }
        children.add(node);
    }

    public GroupNode(Integer resourceCount) {
        this.resourceCount = resourceCount;
    }

    public GroupNode() {
    }
}
