package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


/**
 * 企业微信配置
 *
 * @author maker.wang
 * @date 2022-05-23 11:57
 **/

@Component
@RefreshScope
@ConfigurationProperties(prefix = "channel.wecom.module")
@Data
public class ChannelWeComModuleConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    @ApiModelProperty(value = "企业微信产品模块默认登录首页")
    public List<Map<String, String>> moduleUrlMap;

}
