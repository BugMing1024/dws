package com.cloudwise.douc.service.model.mq;

import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import lombok.Data;

import java.io.Serializable;

/**
 * @author maker.wang
 * @description:
 * @date Created in 12:46 下午 2021/8/17.
 */
@Data
public class AccountMqMessage implements Serializable {
    private static final long serialVersionUID = 1325458217132199400L;

    public AccountMqMessage() {
        this.sendTime = System.currentTimeMillis();
    }

    /**
     * 类型: ADD新增 DELETE删除
     **/
    private String type;

    /**
     * 发送时间戳
     **/
    private Long sendTime;
    /**
     * 租户详情
     **/
    private AccountDetail accountDetail;
}
