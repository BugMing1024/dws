package com.cloudwise.douc.service.model.feishu;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeiShuAppTokenResp {

    private int code;

    private String msg;
    // CHECKSTYLE:OFF
    private String app_access_token;
    // CHECKSTYLE:ON
}