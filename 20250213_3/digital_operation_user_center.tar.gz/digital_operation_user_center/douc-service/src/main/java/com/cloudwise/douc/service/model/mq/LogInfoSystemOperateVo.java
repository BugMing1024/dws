package com.cloudwise.douc.service.model.mq;

import com.cloudwise.cwop.log.enums.LogTypeEnum;
import com.cloudwise.cwop.log.enums.OperateEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 系统操作日志
 *
 * @author maker.wang
 * @date 2022-04-27 15:12
 **/
@Data
@ApiModel("系统操作日志")
public class LogInfoSystemOperateVo implements Serializable {
    private static final long serialVersionUID = 5209365419444788461L;

    public LogInfoSystemOperateVo() {
        this.timestamp = System.currentTimeMillis();
        this.logType = LogTypeEnum.SYSTEMLOG.getType();
    }

    @ApiModelProperty(value = "租户id")
    private Long accountId;

    @ApiModelProperty(value = "前台用户表id")
    private Long userId;

    @ApiModelProperty(value = "用户名")
    private String userName;

    @ApiModelProperty(value = "登录者ip")
    private String userIp;

    @ApiModelProperty(value = "模块")
    private String module;

    @ApiModelProperty(value = "日志类型")
    private OperateEnum operate;

    @ApiModelProperty(value = "日志内容")
    private String content;

    @ApiModelProperty(value = "英文日志内容")
    private String enContent;

    @ApiModelProperty(value = "请求地址")
    private String url;

    @ApiModelProperty(value = "操作结果")
    private Boolean result;

    @ApiModelProperty(value = "异常详情")
    private String exception;

    @ApiModelProperty(value = "参数")
    private Object parameters;

    @ApiModelProperty(value = "登录时间")
    private Long timestamp;

    @ApiModelProperty(value = "日志类型")
    private Integer logType;

    @ApiModelProperty(value = "二级域名")
    private String secondLevelDomain;

}
