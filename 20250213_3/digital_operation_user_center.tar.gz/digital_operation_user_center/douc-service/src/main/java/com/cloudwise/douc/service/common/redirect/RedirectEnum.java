package com.cloudwise.douc.service.common.redirect;

/**
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @date created at 2024/2/6 0:47; update at 2024/2/6 0:47
 */
public enum RedirectEnum {
    /**
     *
     */
    TO_ERROR(),
    /**
     *
     */
    TO_URL();
}
