package com.cloudwise.douc.service.model.role;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 角色配置用户组 重新配置用户组入参
 *
 * @author maker.wang
 * @date 2022-03-10 09:40
 **/
@Data
@ApiModel("角色配置用户组 重新配置用户组入参")
public class RoleSetGroupDTO implements Serializable {
    private static final long serialVersionUID = 5843058342985432909L;

    @ApiModelProperty("用户组id")
    private Long id;

    @ApiModelProperty("上级用户组id")
    private Long parentId;

    @ApiModelProperty("是否包含所有下级用户组")
    private Boolean isSelectChild;

    @ApiModelProperty("用户组层级")
    private String level;

}
