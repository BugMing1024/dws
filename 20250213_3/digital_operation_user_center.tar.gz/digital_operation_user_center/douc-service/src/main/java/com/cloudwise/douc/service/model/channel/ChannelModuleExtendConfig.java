package com.cloudwise.douc.service.model.channel;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 渠道产品模块拓展配置
 *
 * @author maker.wang
 * @date 2022-06-01 10:45
 **/
@Data
@ApiModel("渠道产品模块拓展配置")
public class ChannelModuleExtendConfig implements Serializable {
    private static final long serialVersionUID = 5390632381168523170L;

    @ApiModelProperty("企业微信首页")
    private String weComHomePage;

    @ApiModelProperty("钉钉首页")
    private String dingDingHomePage;

    @ApiModelProperty("钉钉PC首页")
    private String dingDingPcHomePage;

    @ApiModelProperty("飞书PC首页")
    private String feiShuDesktopHomePage;

    @ApiModelProperty("飞书移动首页")
    private String feiShuMobileHomePage;

}
