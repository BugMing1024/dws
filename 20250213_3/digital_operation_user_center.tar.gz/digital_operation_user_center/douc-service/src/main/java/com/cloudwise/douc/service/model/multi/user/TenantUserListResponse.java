package com.cloudwise.douc.service.model.multi.user;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author KenLiang
 * @description:
 * @date Created in 8:36 PM 2020/2/17.
 */
@Data
public class TenantUserListResponse implements Serializable {
    private Long id;
    private String userAlias;
    private String name;
    private Integer origin;
    private String department;
    private String email;
    private String mobile;
    private String dingtalkAccount;
    private String weixinworkAccount;
    private String feishuAccount;
    private String wxpushAccount;
    private Long departmentId;
    private String groupRole;
    private String projects;
    private Integer status;
    private Integer adminType;
    private String roles;
    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN, timezone = "GMT+8")
    private Date modifyTime;
    private Integer importType = 1;
    private String position;
    private String attribute;
    private List<Map<String, Object>> extend;
    /**
     * 主次部门标记
     */
    private Integer isMain;

}
