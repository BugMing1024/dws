package com.cloudwise.douc.service.model.statistics;

import com.cloudwise.douc.metadata.model.statistics.StatisticsResultPO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author leakey.li
 * @description:
 * @date Created in 11:21 上午 2022/10/10.
 */
@Data
public class StatisticsResult implements Serializable {
    @ApiModelProperty(value = "统计List")
    private List<StatisticsResultPO> statisticsResult;
    @ApiModelProperty(value = "在职总人数")
    private Integer totalOnDutyCount;
    @ApiModelProperty(value = "总人数")
    private Integer totalCount;
}
