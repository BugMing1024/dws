package com.cloudwise.douc.service.model.message;

import lombok.Data;

import java.util.Date;

@Data
public class MtNewMessage {
    private String smsId;
    private String phoneNumber;
    private String content;
    private Date scheduleTime;
    // CHECKSTYLE:OFF
    private String Wappushurl;
    // CHECKSTYLE:ON
}
