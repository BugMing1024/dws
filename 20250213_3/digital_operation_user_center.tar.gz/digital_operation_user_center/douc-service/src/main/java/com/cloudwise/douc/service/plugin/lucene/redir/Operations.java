package com.cloudwise.douc.service.plugin.lucene.redir;

/**
 * @author dwq
 */
public enum Operations {
    //FILE_LENGTH=>not compress,FILE_DATA=>compress
    FILE_LENGTH, FILE_DATA
}
