package com.cloudwise.douc.service.model.role;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * @author leakey
 */
@Data
@ApiModel
public class RoleZabbixResponseObject {

    private List<RoleZabbixObject> addList;
    private List<RoleZabbixObject> updateList;
    private List<RoleZabbixObject> deleteList;
}
