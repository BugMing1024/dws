package com.cloudwise.douc.service.configuration;

import cn.hutool.core.text.StrPool;
import com.cloudwise.cwop.security.RSAUtils;
import com.cloudwise.douc.commons.config.conditions.AzureAdCondition;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.utils.JsonUtils;
import com.cloudwise.douc.metadata.activerecord.ChannelRealConfigEntity;
import com.cloudwise.douc.service.service.ChannelRealConfigService;
import com.cloudwise.douc.service.service.impl.SAMLUserDetailsServiceImpl;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.opensaml.saml2.metadata.provider.HTTPMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.parse.ParserPool;
import org.opensaml.xml.parse.StaticBasicParserPool;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLBootstrap;
import org.springframework.security.saml.SAMLDiscovery;
import org.springframework.security.saml.SAMLEntryPoint;
import org.springframework.security.saml.SAMLLogoutFilter;
import org.springframework.security.saml.SAMLLogoutProcessingFilter;
import org.springframework.security.saml.SAMLProcessingFilter;
import org.springframework.security.saml.SAMLWebSSOHoKProcessingFilter;
import org.springframework.security.saml.context.SAMLContextProviderLB;
import org.springframework.security.saml.key.JKSKeyManager;
import org.springframework.security.saml.key.KeyManager;
import org.springframework.security.saml.log.SAMLDefaultLogger;
import org.springframework.security.saml.metadata.ExtendedMetadata;
import org.springframework.security.saml.metadata.ExtendedMetadataDelegate;
import org.springframework.security.saml.metadata.MetadataDisplayFilter;
import org.springframework.security.saml.metadata.MetadataGenerator;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;
import org.springframework.security.saml.metadata.MetadataManager;
import org.springframework.security.saml.parser.ParserPoolHolder;
import org.springframework.security.saml.processor.HTTPArtifactBinding;
import org.springframework.security.saml.processor.HTTPPAOS11Binding;
import org.springframework.security.saml.processor.HTTPPostBinding;
import org.springframework.security.saml.processor.HTTPRedirectDeflateBinding;
import org.springframework.security.saml.processor.HTTPSOAP11Binding;
import org.springframework.security.saml.processor.SAMLBinding;
import org.springframework.security.saml.processor.SAMLProcessorImpl;
import org.springframework.security.saml.util.VelocityFactory;
import org.springframework.security.saml.websso.ArtifactResolutionProfile;
import org.springframework.security.saml.websso.ArtifactResolutionProfileImpl;
import org.springframework.security.saml.websso.SingleLogoutProfile;
import org.springframework.security.saml.websso.SingleLogoutProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfile;
import org.springframework.security.saml.websso.WebSSOProfileConsumer;
import org.springframework.security.saml.websso.WebSSOProfileConsumerHoKImpl;
import org.springframework.security.saml.websso.WebSSOProfileConsumerImpl;
import org.springframework.security.saml.websso.WebSSOProfileECPImpl;
import org.springframework.security.saml.websso.WebSSOProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfileOptions;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.stream.Collectors;

/**
 * @author bernie.wang
 * @description:
 * @date Created in 10:42 AM 2021/10/14.
 */
@EnableWebSecurity
@Configuration
@Slf4j
@Order(101)
@Conditional(AzureAdCondition.class)
public class AzureWebSecurityConfigurationAdapter extends WebSecurityConfigurerAdapter
        implements InitializingBean, DisposableBean {

    private List<Timer> backgroundTaskTimerList;
    private MultiThreadedHttpConnectionManager multiThreadedHttpConnectionManager;

    public void init() {
        this.backgroundTaskTimerList = Lists.newArrayList();
        this.multiThreadedHttpConnectionManager = new MultiThreadedHttpConnectionManager();
    }

    public void shutdown() {
        this.closeAllBackgroundTask();
        this.multiThreadedHttpConnectionManager.shutdown();
    }

    public void closeAllBackgroundTask() {
        if (!backgroundTaskTimerList.isEmpty()) {
            backgroundTaskTimerList.forEach(timer -> {
                timer.purge();
                timer.cancel();
            });
        }
    }

    @Autowired
    private SAMLUserDetailsServiceImpl samlUserDetailsServiceImpl;
    @Autowired
    private ChannelRealConfigService channelRealConfigService;
    @Autowired
    private Environment environment;

    @Bean
    public SAMLContextProviderLB samlContextProviderLB() {
        String domainName = this.addUrlDefaultPrefix(environment.getProperty("saml.sp.domain.name"));
        URL url = null;
        int port = 0;
        SAMLContextProviderLB samlContextProviderLB = new SAMLContextProviderLB();
        try {
            url = new URL(domainName);
            port = this.getUrlPort(url);
            samlContextProviderLB.setScheme(url.getProtocol());
            samlContextProviderLB.setServerName(this.addSuffixRedirectUrl(url.getAuthority()));
        } catch (MalformedURLException e) {
            log.error(e.getMessage(), e);
        }
        samlContextProviderLB.setServerPort(port);
        samlContextProviderLB.setIncludeServerPortInRequestURL(false);
        samlContextProviderLB.setContextPath("");
        return samlContextProviderLB;
    }

    @Bean
    public WebSSOProfileConsumer webSSOprofileConsumer() {
        WebSSOProfileConsumerImpl webSSOProfileConsumer = new WebSSOProfileConsumerImpl();
        webSSOProfileConsumer.setMaxAuthenticationAge(environment.getProperty("saml.sp.authentication.max.age", Long.class));
        webSSOProfileConsumer.setResponseSkew(120);
        return webSSOProfileConsumer;
    }

    @Bean
    public KeyManager keyManager() {
        FileSystemResourceLoader loader = new FileSystemResourceLoader();
        Resource storeFile = loader.getResource(File.separator + System.getProperty("user.dir") + File.separator + "conf" + File.separator + "saml" + File.separator + "samlKeystore.jks");
        String storePass = this.decrypt(environment.getProperty("saml.keystore.password"));
        Map<String, String> passwords = new HashMap<>();
        passwords.put(environment.getProperty("saml.private.key.alias"), this.decrypt(environment.getProperty("saml.private.key.password")));
        String defaultKey = environment.getProperty("saml.private.key.alias");
        CertificateFactory cf = null;
        try {
            //生成证书库
            KeyStore ks = KeyStore.getInstance("JKS");
            ks.load(storeFile.getInputStream(), storePass == null ? null : storePass.toCharArray());
            cf = CertificateFactory.getInstance("X.509");
            //获取AZURE渠道配置
            List<Map<String, Object>> azureConfigList = this.getAzureConfigList();
            if (!azureConfigList.isEmpty()) {
                //生成x509证书
                List<X509Certificate> certificatList = this.getCertificatList(cf, azureConfigList);
                //添加AZURE证书
                for (int i = 0; i < certificatList.size(); i++) {
                    ks.setCertificateEntry(i + "", certificatList.get(i));
                }
            } else {
                ks.setCertificateEntry("0", ks.getCertificate(environment.getProperty("saml.private.key.alias")));
            }
            //生成并返回jksKeyManager
            return new JKSKeyManager(ks, passwords, defaultKey);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    @Bean
    public MetadataGenerator metadataGenerator() {
        MetadataGenerator metadataGenerator = new MetadataGenerator();
        metadataGenerator.setEntityId(environment.getProperty("saml.sp.entity.id"));
        metadataGenerator.setRequestSigned(false);
        metadataGenerator.setExtendedMetadata(extendedMetadata());
        metadataGenerator.setIncludeDiscoveryExtension(false);
        metadataGenerator.setKeyManager(keyManager());
        metadataGenerator.setWantAssertionSigned(false);
        metadataGenerator.setEntityBaseURL(this.addUrlDefaultPrefix(environment.getProperty("saml.sp.domain.name")) + this.addPrefixRedirectUrl("/douc/api/v1/sso"));
        return metadataGenerator;
    }

    @Bean
    public SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler() {
        SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler = new SavedRequestAwareAuthenticationSuccessHandler();
        successRedirectHandler.setDefaultTargetUrl(this.addUrlDefaultPrefix(environment.getProperty("saml.sp.domain.name")) + this.addPrefixRedirectUrl("/douc/api/v1/sso/loginAzure"));
        return successRedirectHandler;
    }

    @Bean
    public SimpleUrlAuthenticationFailureHandler authenticationFailureHandler() {
        SimpleUrlAuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
        failureHandler.setDefaultFailureUrl(this.addUrlDefaultPrefix(environment.getProperty("saml.sp.domain.name")) + this.addPrefixRedirectUrl("/douc/api/v1/sso/source/error.html?errorMsg="));
        return failureHandler;
    }

    @Bean
    public VelocityEngine velocityEngine() {
        return VelocityFactory.getEngine();
    }

    @Bean(initMethod = "initialize")
    public StaticBasicParserPool parserPool() {
        return new StaticBasicParserPool();
    }

    @Bean(name = "parserPoolHolder")
    public ParserPoolHolder parserPoolHolder() {
        return new ParserPoolHolder();
    }

    @Bean
    public HttpClient httpClient() {
        return new HttpClient(this.multiThreadedHttpConnectionManager);
    }

    @Bean
    public SAMLAuthenticationProvider samlAuthenticationProvider(SAMLUserDetailsServiceImpl samlUserDetailsServiceImpl) {
        SAMLAuthenticationProvider samlAuthenticationProvider = new SAMLAuthenticationProvider();
        samlAuthenticationProvider.setUserDetails(samlUserDetailsServiceImpl);
        samlAuthenticationProvider.setForcePrincipalAsString(false);
        return samlAuthenticationProvider;
    }

    @Bean
    public static SAMLBootstrap sAMLBootstrap() {
        return new SAMLBootstrap();
    }

    @Bean
    public SAMLDefaultLogger samlLogger() {
        return new SAMLDefaultLogger();
    }

    @Bean
    public WebSSOProfileConsumerHoKImpl hokWebSSOprofileConsumer() {
        return new WebSSOProfileConsumerHoKImpl();
    }

    @Bean
    public WebSSOProfile webSSOprofile() {
        return new WebSSOProfileImpl();
    }

    @Bean
    public WebSSOProfileConsumerHoKImpl hokWebSSOProfile() {
        return new WebSSOProfileConsumerHoKImpl();
    }

    @Bean
    public WebSSOProfileECPImpl ecpprofile() {
        return new WebSSOProfileECPImpl();
    }

    @Bean
    public SingleLogoutProfile logoutprofile() {
        return new SingleLogoutProfileImpl();
    }

    @Bean
    public WebSSOProfileOptions defaultWebSSOProfileOptions() {
        WebSSOProfileOptions webSSOProfileOptions = new WebSSOProfileOptions();
        webSSOProfileOptions.setIncludeScoping(Boolean.FALSE);
        return webSSOProfileOptions;
    }

    @Bean
    public SAMLEntryPoint samlEntryPoint() {
        SAMLEntryPoint samlEntryPoint = new SAMLEntryPoint();
        samlEntryPoint.setDefaultProfileOptions(defaultWebSSOProfileOptions());
        return samlEntryPoint;
    }

    @Bean
    public ExtendedMetadata extendedMetadata() {
        ExtendedMetadata extendedMetadata = new ExtendedMetadata();
        extendedMetadata.setIdpDiscoveryEnabled(true);
        extendedMetadata.setSigningAlgorithm("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256");
        extendedMetadata.setSignMetadata(true);
        extendedMetadata.setEcpEnabled(true);
        return extendedMetadata;
    }

    @Bean
    public SAMLDiscovery samlIDPDiscovery() {
        SAMLDiscovery idpDiscovery = new SAMLDiscovery();
        idpDiscovery.setIdpSelectionPath("/douc/api/v1/sso/saml/discovery");
        return idpDiscovery;
    }

    public List<ExtendedMetadataDelegate> azureExtendedMetadataProvider() throws MetadataProviderException {
        List<ExtendedMetadataDelegate> extendedMetadataList = Lists.newArrayList();
        //关闭所有定时器
        if (backgroundTaskTimerList != null && !backgroundTaskTimerList.isEmpty()) {
            this.closeAllBackgroundTask();
        }
        //获取AZURE渠道配置
        List<Map<String, Object>> azureConfigList = this.getAzureConfigList();
        if (!azureConfigList.isEmpty()) {
            //获取元数据url
            List<String> metaDataUrlList = this.getMetaDataUrlList(azureConfigList);
            if (!metaDataUrlList.isEmpty()) {
                for (String url : metaDataUrlList) {
                    //创建新定时器
                    Timer timer = new Timer(true);
                    HTTPMetadataProvider httpMetadataProvider = new HTTPMetadataProvider(timer, httpClient(), url);
                    httpMetadataProvider.setParserPool(parserPool());
                    ExtendedMetadataDelegate extendedMetadataDelegate = new ExtendedMetadataDelegate(httpMetadataProvider, extendedMetadata());
                    extendedMetadataDelegate.setMetadataTrustCheck(true);
                    extendedMetadataDelegate.setMetadataRequireSignature(false);
                    timer.purge();
                    this.backgroundTaskTimerList.add(timer);
                    extendedMetadataList.add(extendedMetadataDelegate);
                }
            }
        }
        return extendedMetadataList;
    }

    @Bean
    @Qualifier("metadata")
    public MetadataManager metadata() throws MetadataProviderException {
        List<MetadataProvider> providers = new ArrayList<>();
        List<ExtendedMetadataDelegate> extendedMetadataDelegates = azureExtendedMetadataProvider();
        providers.addAll(extendedMetadataDelegates);
        return new MetadataManager(providers);
    }

    @Bean
    public MetadataDisplayFilter metadataDisplayFilter() {
        return new MetadataDisplayFilter();
    }

    @Bean
    public SAMLWebSSOHoKProcessingFilter samlWebSSOHoKProcessingFilter() throws Exception {
        SAMLWebSSOHoKProcessingFilter samlWebSSOHoKProcessingFilter = new SAMLWebSSOHoKProcessingFilter();
        samlWebSSOHoKProcessingFilter.setAuthenticationSuccessHandler(successRedirectHandler());
        samlWebSSOHoKProcessingFilter.setAuthenticationManager(authenticationManager());
        samlWebSSOHoKProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
        return samlWebSSOHoKProcessingFilter;
    }

    @Bean
    public SAMLProcessingFilter samlWebSSOProcessingFilter() throws Exception {
        SAMLProcessingFilter samlWebSSOProcessingFilter = new SAMLProcessingFilter();
        samlWebSSOProcessingFilter.setAuthenticationManager(authenticationManager());
        samlWebSSOProcessingFilter.setAuthenticationSuccessHandler(successRedirectHandler());
        samlWebSSOProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
        return samlWebSSOProcessingFilter;
    }

    @Bean
    public MetadataGeneratorFilter metadataGeneratorFilter() {
        return new MetadataGeneratorFilter(metadataGenerator());
    }

    @Bean
    public SimpleUrlLogoutSuccessHandler successLogoutHandler() {
        SimpleUrlLogoutSuccessHandler successLogoutHandler = new SimpleUrlLogoutSuccessHandler();
        successLogoutHandler.setDefaultTargetUrl(StrPool.SLASH);
        return successLogoutHandler;
    }

    @Bean
    public SecurityContextLogoutHandler logoutHandler() {
        SecurityContextLogoutHandler logoutHandler =
                new SecurityContextLogoutHandler();
        logoutHandler.setInvalidateHttpSession(true);
        logoutHandler.setClearAuthentication(true);
        return logoutHandler;
    }

    @Bean
    public SAMLLogoutProcessingFilter samlLogoutProcessingFilter() {
        return new SAMLLogoutProcessingFilter(successLogoutHandler(),
                logoutHandler());
    }

    @Bean
    public SAMLLogoutFilter samlLogoutFilter() {
        return new SAMLLogoutFilter(successLogoutHandler(),
                new LogoutHandler[]{logoutHandler()},
                new LogoutHandler[]{logoutHandler()});
    }

    private ArtifactResolutionProfile artifactResolutionProfile() {
        final ArtifactResolutionProfileImpl artifactResolutionProfile =
                new ArtifactResolutionProfileImpl(httpClient());
        artifactResolutionProfile.setProcessor(new SAMLProcessorImpl(soapBinding()));
        return artifactResolutionProfile;
    }

    @Bean
    public HTTPArtifactBinding artifactBinding(ParserPool parserPool, VelocityEngine velocityEngine) {
        return new HTTPArtifactBinding(parserPool, velocityEngine, artifactResolutionProfile());
    }

    @Bean
    public HTTPSOAP11Binding soapBinding() {
        return new HTTPSOAP11Binding(parserPool());
    }

    @Bean
    public HTTPPostBinding httpPostBinding() {
        return new HTTPPostBinding(parserPool(), velocityEngine());
    }

    @Bean
    public HTTPRedirectDeflateBinding httpRedirectDeflateBinding() {
        return new HTTPRedirectDeflateBinding(parserPool());
    }

    @Bean
    public HTTPSOAP11Binding httpSOAP11Binding() {
        return new HTTPSOAP11Binding(parserPool());
    }

    @Bean
    public HTTPPAOS11Binding httpPAOS11Binding() {
        return new HTTPPAOS11Binding(parserPool());
    }

    @Bean
    public SAMLProcessorImpl processor() {
        Collection<SAMLBinding> bindings = new ArrayList<>();
        bindings.add(httpRedirectDeflateBinding());
        bindings.add(httpPostBinding());
        bindings.add(artifactBinding(parserPool(), velocityEngine()));
        bindings.add(httpSOAP11Binding());
        bindings.add(httpPAOS11Binding());
        return new SAMLProcessorImpl(bindings);
    }

    @Bean
    public FilterChainProxy samlFilter() throws Exception {
        List<SecurityFilterChain> chains = new ArrayList<>();
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher(this.addPrefixRedirectUrl("/douc/api/v1/sso/saml/metadata/**")),
                metadataDisplayFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher(this.addPrefixRedirectUrl("/douc/api/v1/sso/saml/SSO/**")),
                samlWebSSOProcessingFilter()));
        return new FilterChainProxy(chains);
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        FilterChainProxy filterChainProxy = samlFilter();
        http
                .httpBasic()
                .authenticationEntryPoint(samlEntryPoint());
        http
                .addFilterBefore(metadataGeneratorFilter(), ChannelProcessingFilter.class)
                .addFilterAfter(filterChainProxy, BasicAuthenticationFilter.class)
                .addFilterBefore(filterChainProxy, CsrfFilter.class);
    }


    @Override
    protected void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(samlAuthenticationProvider(samlUserDetailsServiceImpl));
    }

    @Override
    public void afterPropertiesSet() {
        init();
    }

    @Override
    public void destroy() {
        shutdown();
    }

    public List<Map<String, Object>> getAzureConfigList() {
        List<Map<String, Object>> resultList = Lists.newArrayList();
        //私有部署使用默认租户id查询Azure配置；
        List<ChannelRealConfigEntity> azureConfigByAccountId = channelRealConfigService.getAzureConfigByAccountId(Constant.DEFAULT_ACCOUNTID);
        if (!azureConfigByAccountId.isEmpty()) {
            Map<String, Object> fields = JsonUtils.decode(azureConfigByAccountId.get(0).getFields(), Map.class);
            resultList.add(fields);
        }
        return resultList;
    }

    /**
     * 获取IDP证书列表
     *
     * @param cf
     * @param channelConfigs
     * @return java.util.List<java.security.cert.X509Certificate>
     * @description
     * @author bernie.wang
     * @date 2022/7/28
     * @time 2:32 下午
     */
    public List<X509Certificate> getCertificatList(CertificateFactory cf, List<Map<String, Object>> channelConfigs) {
        //证书数据表
        List<String> certList = Lists.newArrayList();
        //证书配置表
        List<String> certificateConfList = channelConfigs.stream().map(data -> data.get("certificate").toString()).collect(Collectors.toList());
        //x509证书数据表
        List<X509Certificate> x509CerList = Lists.newArrayList();
        //抽取配置中的证书数据
        certificateConfList.forEach(cre -> {
            if (StringUtils.isNotEmpty(cre)) {
                Map<String, String> decode = JsonUtils.decode(cre, Map.class);
                String certStr = decode.get("text");
                certList.add(certStr);
            }
        });
        //证书数据表数据不为空，生成X509证书
        if (!certList.isEmpty()) {
            //生成并返回x509证书
            x509CerList = certList.stream().map(cer -> {
                try {
                    return (X509Certificate) cf.generateCertificate(IOUtils.toInputStream(cer, StandardCharsets.UTF_8));
                } catch (CertificateException e) {
                    throw new BaseException(IBaseExceptionCode.CHANNEL_AZURE_PARSE_CERTIFICATE_EXCEPTION, e);
                }
            }).collect(Collectors.toList());
        }
        return x509CerList;
    }

    public List<String> getMetaDataUrlList(List<Map<String, Object>> channelConfigs) {
        return channelConfigs.stream().map(data -> data.get("metadataUrl").toString()).collect(Collectors.toList());
    }

    /**
     * 为url添加默认前缀
     *
     * @param url
     * @return java.lang.String
     * @description
     * @author bernie.wang
     * @date 2022/7/31
     * @time 11:08 下午
     */
    String addUrlDefaultPrefix(String url) {
        if (!url.contains("http")) {
            return "https://" + url;
        }
        return url;
    }

    /**
     * 获取url端口号
     *
     * @param url
     * @return int
     * @description
     * @author bernie.wang
     * @date 2022/7/31
     * @time 11:08 下午
     */
    int getUrlPort(URL url) {
        int port;
        if (url.getPort() < 0) {
            if ("http://".equalsIgnoreCase(url.getProtocol())) {
                port = 80;
            } else {
                port = 443;
            }
        } else {
            port = url.getPort();
        }
        return port;
    }

    private String addPrefixRedirectUrl(String url) {
        return environment.containsProperty("sso.server.default.prefix") ? environment.getProperty("sso.server.default.prefix") + url : url;
    }

    private String addSuffixRedirectUrl(String url) {
        return environment.containsProperty("sso.server.default.prefix") ? url + environment.getProperty("sso.server.default.prefix") : url;
    }


    private String decrypt(String passCode) {
        String resultData = "";
        try {
            resultData = RSAUtils.decrypt(passCode);
        } catch (Exception e) {
            log.debug("passCode parse exception: ", e);
            resultData = passCode;
        }
        return resultData;
    }
}
