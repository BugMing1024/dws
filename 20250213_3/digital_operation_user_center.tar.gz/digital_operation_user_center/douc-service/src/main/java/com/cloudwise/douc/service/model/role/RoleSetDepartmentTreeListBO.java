package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 角色配置组织机构 修改回显入参
 *
 * @author maker.wang
 * @date 2022-03-10 09:40
 **/
@Data
@ApiModel("角色配置组织机构 修改回显入参")
public class RoleSetDepartmentTreeListBO implements Serializable {
    private static final long serialVersionUID = 5843058342985432909L;

    @ApiModelProperty("角色id")
    @NotNull(message = IBaseExceptionCode.API_ROLE_ID_NULL)
    private Long roleId;

    @ApiModelProperty("上级部门id")
    private Long parentId;


}
