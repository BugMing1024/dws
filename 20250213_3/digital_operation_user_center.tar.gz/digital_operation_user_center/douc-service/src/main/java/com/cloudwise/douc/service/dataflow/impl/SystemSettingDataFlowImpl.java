package com.cloudwise.douc.service.dataflow.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.commons.model.BaseEntity;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.metadata.mapper.IMenuDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.mapper.ISystemSettingDao;
import com.cloudwise.douc.metadata.model.role.Role;
import com.cloudwise.douc.metadata.model.security.SystemSettingEntity;
import com.cloudwise.douc.service.cache.IAuthCache;
import com.cloudwise.douc.service.cache.ISystemSettingDataCache;
import com.cloudwise.douc.service.constants.data.AccountConstants;
import com.cloudwise.douc.service.dataflow.ISystemSettingDataFlow;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.util.Constant;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 系统一些配置的获取类
 *
 * @author zafir zhong
 * @version 1.0.0
 * @date created at 2022/3/17 3:29 下午 ; update at
 */
@Component
@Slf4j
public class SystemSettingDataFlowImpl implements ISystemSettingDataFlow {
    
    @Autowired
    private ISystemSettingDataCache systemSettingDataCache;
    
    @Autowired
    private ISystemSettingDao systemSettingDao;
    
    @Autowired
    private IAuthCache authCache;
    
    @Autowired
    private IRoleDao roleDao;
    
    @Autowired
    private IMenuDao menuDao;
    
    @Autowired
    private IAccountService accountService;
    
    @Override
    public boolean isChildAccountEnable() {
        Boolean childAccountEnable = systemSettingDataCache.getChildAccountEnable();
        if (Objects.isNull(childAccountEnable)) {
            List<SystemSettingEntity> systemSetting = systemSettingDao.getSystemSetting(Constant.DEFAULT_ACCOUNTID);
            for (SystemSettingEntity e : systemSetting) {
                if (Objects.equals(e.getConfigurationName(), AccountConstants.Key.CHILD_ACCOUNT_ENABLE_DB_KEY)) {
                    try {
                        childAccountEnable = Boolean.valueOf(e.getConfigurationValue());
                    } catch (Exception ex) {
                        log.warn("SystemSetting have error value: {}", e.getConfigurationValue());
                        childAccountEnable = Boolean.FALSE;
                    }
                    break;
                }
            }
            if (Objects.isNull(childAccountEnable)) {
                childAccountEnable = Boolean.FALSE;
            }
            systemSettingDataCache.saveChildAccountEnable(childAccountEnable);
        }
        return childAccountEnable;
        
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void enableChildAccount() throws BaseException {
        Map<String, String> setting = new HashMap<>();
        setting.put(AccountConstants.Key.CHILD_ACCOUNT_ENABLE_DB_KEY, String.valueOf(true));
        Integer integer = systemSettingDao.updateSpecifiedSystemSetting(Constant.DEFAULT_ACCOUNTID, setting);
        if (!Objects.equals(integer, 1)) {
            log.error("system setting save mysql fail");
            throw new BaseException();
        }
        boolean b = systemSettingDataCache.saveChildAccountEnable(true);
        if (!b) {
            log.error("system setting save redis fail");
            throw new BaseException();
        }
        List<Long> allTopAccountIdList = accountService.getAllTopAccountIdList();
        List<Role> allRole = roleDao.getAllRole(null, null);
        String appInfoByModuleCode = menuDao.getAppInfoByModuleCode("100");
        if (CollUtil.isNotEmpty(allTopAccountIdList) && CollUtil.isNotEmpty(allRole) && StrUtil.isNotBlank(appInfoByModuleCode)) {
            allTopAccountIdList.forEach(aLong -> {
                authCache.deleteViewMenuAuthedByRoleIds(aLong, Lists.newArrayList(appInfoByModuleCode),
                        allRole.stream().map(BaseEntity::getId).collect(Collectors.toList()));
            });
        }
    }
}
