package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.service.model.resource.RoleMenuChangeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;


/**
 * 添加或修改角色
 *
 * @author maker.wang
 * @date 2022-08-11 09:41
 **/
@Data
@ApiModel("添加或修改角色")
public class RoleAddOrUpdateBO implements Serializable {
    
    private static final long serialVersionUID = -4330979032760465325L;
    
    @ApiModelProperty("租户ID")
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;
    
    @ApiModelProperty("用户ID")
    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    @Range(min = 1, max = Long.MAX_VALUE, message = "userId必须是正整数")
    private Long userId;
    
    @ApiModelProperty("角色名称")
    @NotBlank(message = IBaseExceptionCode.API_ROLE_NAME_NOT_BLANK)
    @Length(max = 60, message = IBaseExceptionCode.RPC_ROLE_NAME_LENGTH_ERROR)
    private String roleName;
    
    @ApiModelProperty("角色编码")
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_DATAITEMCODE_NOT_BLANK)
    @Length(max = 64, message = IBaseExceptionCode.RPC_ROLE_CODE_LENGTH_ERROR)
    private String roleCode;
    
    @ApiModelProperty("角色标签, 空则删除所有标签")
    private List<String> roleTags;
    
    @ApiModelProperty("角色组编码")
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_DATAITEMCODE_NOT_BLANK)
    @Length(max = 64, message = IBaseExceptionCode.RPC_ROLE_GROUP_CODE_LENGTH_ERROR)
    private String roleGroupCode;
    
    @ApiModelProperty("角色组ID")
    private transient String roleGroupId;
    
    @ApiModelProperty("角色描述")
    @Length(max = 100, message = IBaseExceptionCode.RPC_USER_GROUP_DESCRIPTION_LENGTH_ERROR)
    private String roleDescription;
    
    @ApiModelProperty("是否更新角色菜单权限 默认false:不更新")
    private Boolean ifAddOrUpdateMenuRelation;
    
    @ApiModelProperty("角色在xxx模块下所拥有的菜单权限全量更新覆盖,包括null")
    private Map<String, List<RoleMenuChangeVo>> moduleMenuMap;
    
    @ApiModelProperty("配置用户-用户编码 List<String>,空则不用管")
    private List<String> addUserList;
    
    @ApiModelProperty("移除配置-用户编码 List<String>,空则不用管")
    private List<String> removeUserList;
    
    @ApiModelProperty("配置用户-用户id List<Long>,空则不用管")
    private List<Long> addUserIdList;
    
    @ApiModelProperty("移除配置-用户id List<Long>,空则不用管")
    private List<Long> removeUserIdList;
    
    public RoleAddOrUpdateBO() {
        this.ifAddOrUpdateMenuRelation = Boolean.FALSE;
        this.accountId = 0L;
        this.userId = 1L;
    }
    
}
