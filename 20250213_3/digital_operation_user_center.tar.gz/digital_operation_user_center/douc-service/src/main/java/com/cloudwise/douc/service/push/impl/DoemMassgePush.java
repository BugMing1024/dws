package com.cloudwise.douc.service.push.impl;

import com.cloudwise.douc.service.model.security.ConfigurationVO;
import com.cloudwise.douc.service.push.BaseMassagePushInterface;
import com.cloudwise.douc.service.push.model.DoemEntity;
import com.cloudwise.douc.service.service.ISystemSettingService;
import com.cloudwise.douc.service.util.Constant;
import com.cloudwise.douc.service.util.httpclient.HttpClientHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Zack.Gao
 */
@Component
@Slf4j
public class DoemMassgePush implements BaseMassagePushInterface<DoemEntity> {

    @Autowired
    private HttpClientHelper httpClientHelper;

    @Autowired
    private ISystemSettingService iSystemSettingService;

    @Override
    public Map<String, String> send(DoemEntity entity) {

        ConfigurationVO systemSetting = this.iSystemSettingService.getSystemSetting(String.valueOf(Constant.DEFAULT_ACCOUNTID));
        log.info("DoemMassgePush get systemSetting,systemSetting{}", systemSetting);
        String appkey = systemSetting.getWarnAppKey();
        String url = systemSetting.getWarnPushUrl();
        entity.setUrl(url);
        HashMap<String, Object> header = new HashMap<>();
        header.put("Content-Type", "application/json");
        header.put("appKey", appkey);

        //发送消息到事件中心
        Map<String, String> responseResult = httpClientHelper.postJson(url, entity.getBody(), header);
        //返回响应结果
        return responseResult;
    }


}
