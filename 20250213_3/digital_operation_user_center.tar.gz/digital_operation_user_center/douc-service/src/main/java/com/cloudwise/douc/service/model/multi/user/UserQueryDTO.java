package com.cloudwise.douc.service.model.multi.user;

import com.cloudwise.douc.metadata.model.department.DepartmentUserRelation;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.List;

/**
 * @author bradyliu
 * @description:
 * @date Created in 17:55 2021/8/3.
 */
@Data
public class UserQueryDTO implements Serializable {

    private String userIdDepartmentIdIsMain;
    
    private List<DepartmentUserRelation> relations;

    @JsonIgnore
    private String[] split() {
        return StringUtils.split(userIdDepartmentIdIsMain, "\\_");
    }

    @JsonIgnore
    public Long getUserId() {
        return Long.valueOf(this.split()[0]);
    }

    @JsonIgnore
    public Long getDepartmentId() {
        String departmentId = this.split()[1];
        if (departmentId == null || "null".equals(departmentId)) {
            return null;
        }
        return Long.valueOf(this.split()[1]);
    }

    @JsonIgnore
    public Integer getIsMain() {
        return Integer.valueOf(this.split()[2]);
    }
}
