package com.cloudwise.douc.service.cache;

/**
 * 语言缓存接口
 */
public interface ILanguageCache {
    /**
     * 从缓存中获取语言信息
     *
     * @param accountId
     * @param userId
     * @return
     */
    String getLanguageCacheByUserId(Long accountId, Long userId);

    /**
     * 将用户的语言放入缓存
     *
     * @param language
     * @param accountId
     * @param userId
     */
    void setLanguageToCacheWithUserId(String language, Long accountId, Long userId);
}
