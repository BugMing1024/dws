package com.cloudwise.douc.service.model.channel;

import com.cloudwise.douc.metadata.activerecord.ChannelRealConfigEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zafir.zhong
 * @description 建单的渠道修改通知
 * @date Created in 13:45 2022/5/17.
 */
@Data
@NoArgsConstructor
public class ChannelModifyNotice {

    private String type;
    private String channelConfigKey;
    private long sendTime = System.currentTimeMillis();
    private ChannelRealConfigEntity channelDetail;

    public static class ModifyType {
        public static final String ADD = "ADD";
        public static final String DELETE = "DELETE";
        public static final String UPDATE = "UPDATE";
    }

}
