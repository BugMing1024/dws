package com.cloudwise.douc.service.model.systemupgrade;

import com.cloudwise.douc.metadata.model.systemupgrade.SystemUpgrade;

import java.io.Serializable;

/**
 * @author leakey.li
 * @description:
 * @date Created in 4:51 下午 2021/8/19.
 */
public class SystemUpgradeVo extends SystemUpgrade implements Serializable {
}
