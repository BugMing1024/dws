package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.service.cache.IMenuResourceCache;
import com.cloudwise.douc.service.model.auth.MenuAuthRequest;
import com.cloudwise.douc.service.model.auth.MenuAuthResponse;
import com.cloudwise.douc.service.service.IMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import scala.collection.mutable.StringBuilder;

/**
 * description:功能资源缓存
 *
 * @date create by jasonlee at 2021/1/29 7:54 PM
 */
@Component
public class MenuResourceCacheImpl implements IMenuResourceCache {

    @Autowired
    private IMenuService menuService;


    @Override
    public void setMenuBasedAccountIdUserIdModuleCodeToCache(MenuAuthRequest menuAuthRequest, MenuAuthResponse menuAuthResponse) {
        String menuAuthCacheKey = getMenuAuthCacheKey(menuAuthRequest);
        RedisTools.setByteWithTime(menuAuthCacheKey, menuAuthResponse, this.getMenuAuthExpireTimeByDataType());
    }

    @Override
    public MenuAuthResponse getMenuAuthFromCache(MenuAuthRequest menuAuthRequest) {
        String menuAuthCacheKey = getMenuAuthCacheKey(menuAuthRequest);
        return RedisTools.getByte(menuAuthCacheKey, MenuAuthResponse.class);
    }

    @Override
    public boolean isProfessionalCache() {
        if (!ConfigUtils.getBoolean("lic.limitUser.enabled", true)) {
            return false;
        }
        Boolean isProfessional = RedisTools.getByte(CacheConstant.REDIS_CACHE_KEY_PROFESSIONAL_SIGN, Boolean.class);
        if (isProfessional != null) {
            return Boolean.TRUE.equals(isProfessional);
        }
        boolean professional = menuService.isProfessional();
        RedisTools.setByte(CacheConstant.REDIS_CACHE_KEY_PROFESSIONAL_SIGN, professional);
        return professional;
    }

    @Override
    public void clearProfessionalCache() {
        RedisTools.deleteValueByKey(CacheConstant.REDIS_CACHE_KEY_PROFESSIONAL_SIGN);
    }

    /**
     * description:生成功能缓存key
     *
     * @param menuAuthRequest 功能权限查询信息
     * @return String 功能缓存key
     * @date create by jasonlee at 2021/1/29 7:59 PM
     */
    private String getMenuAuthCacheKey(MenuAuthRequest menuAuthRequest) {
        StringBuilder menuAuthCacheKey = new StringBuilder();
        menuAuthCacheKey.append(CacheConstant.MENU_AUTH_CACHE_PRE)
                .append(menuAuthRequest.getAccountId())
                .append(StrPool.C_COLON)
                .append(menuAuthRequest.getUserId())
                .append(StrPool.C_COLON)
                .append(menuAuthRequest.getModuleCode());
        return menuAuthCacheKey.toString();
    }


    //获取数据权限对应数据类型过期时间
    private long getMenuAuthExpireTimeByDataType() {
        return ConfigUtils.getLong("auth.cache.menu-ttl", CacheConstant.MENU_AUTH_DEFAULT_TTL);
    }
}
