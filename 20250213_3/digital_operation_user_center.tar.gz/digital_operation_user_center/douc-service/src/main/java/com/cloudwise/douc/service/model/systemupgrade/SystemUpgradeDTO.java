package com.cloudwise.douc.service.model.systemupgrade;

import com.cloudwise.douc.metadata.model.systemupgrade.SystemUpgrade;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @author leakey.li
 * @description:
 * @date Created in 4:51 下午 2021/8/19.
 */
@Getter
@Setter
@ApiModel
public class SystemUpgradeDTO extends SystemUpgrade {
    @ApiModelProperty(value = "语言")
    private String language;
}
