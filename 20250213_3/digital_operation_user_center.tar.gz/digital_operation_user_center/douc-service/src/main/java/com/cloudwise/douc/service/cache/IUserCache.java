package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;

import java.util.List;
import java.util.Map;

/**
 * @description: 用户信息缓存
 * @author: ken
 * @date: 2021-01-26 19:42
 **/
public interface IUserCache {


    /**
     * description:通过用户id集合批量获取缓存中的用户信息
     *
     * @param userIds 用户id集合
     * @return 用户信息集合
     * @date create by ken at 2021/1/26 7:47 PM
     */
    List<UserBaseInfoCacheDTO> getMultiUserFromCacheByIds(Long accountId, List<Long> userIds);

    /**
     * description:通过用户名集合批量获取缓存中的用户信息
     *
     * @param userAlias 用户名集合
     * @return 用户信息集合
     * @date create by ken at 2021/1/26 7:47 PM
     */
    List<UserBaseInfoCacheDTO> getMultiUserFromCacheByUserAliass(Long accountId, List<String> userAlias);

    /**
     * description: 增加/更新基于用户单一用户信息至缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateSingleUserBasedToCache(UserBaseInfoCacheDTO userBaseInfoCacheDTO);


    /**
     * description: 增加/更新基于用户用户信息至缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateUsersBasedToCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList);


    /**
     * description: 增加/更新基于用户单一用户状态至缓存
     *
     * @param userBaseInfoCacheDTO 需要用户id,和accountid
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateSingleOnlyUserStatusBasedToCache(Boolean isStart, UserBaseInfoCacheDTO userBaseInfoCacheDTO);


    /**
     * description: 增加/更新基于用户用户状态至缓存
     *
     * @param userBaseInfoCacheDTO 需要用户id,和accountid
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void addOrUpdateOnlyUsersStatusBasedToCache(List<UserBaseInfoCacheDTO> startUserBaseInfoCacheDTOList, List<UserBaseInfoCacheDTO> stopUserBaseInfoCacheDTOList);

    /**
     * description: 删除基于用户用户信息至缓存
     *
     * @param
     * @return
     * @date create by ken at 2021/1/26 7:52 PM
     */
    void deleteUsersBasedFromCache(List<UserBaseInfoCacheDTO> userBaseInfoCacheDTOList);

    /**
     * 获取用户的数量从缓存中
     *
     * @param accountId
     * @param status
     * @return
     */
    String getUsersCountByAccountIdAndStatus(Long accountId, Integer status);

    /**
     * description: 查询用户session缓存（gateway设置、删除）
     *
     * @param
     * @return
     * @date create by ken at 2021/4/29 7:52 PM
     */
    Map<Long, String> getUserSessionByUserIds(List<Long> userIds);


    /**
     * 设置用户数量
     *
     * @param accountId
     * @param userCount
     */
    void setUsersCountByAccountId(Long accountId, Map<String, String> userCount);

    /**
     * 删除用户数量
     *
     * @param accountId
     */
    void deleteUsersCountByAccountId(Long accountId);

    /**
     * @param accountId 租户id
     * @param userId    用户id
     * @return 用户拥有的角色id列表
     * @description 获取用户拥有的角色id
     * @autor ken.liang
     * @date 2021/6/22
     * @time 3:00 PM
     */
    Map<Long, Integer> getRoleIdTypeMapByUserIdAndAccountId(Long accountId, Long userId);

    /**
     * @param accountId     租户id
     * @param userId        用户id
     * @param roleIdTypeMap 角色id:角色type
     * @description 缓存用户拥有的角色id
     * @autor ken.liang
     * @date 2021/6/22
     * @time 3:00 PM
     */
    void setRoleIdTypeMapByUserIdAndAccountId(Long accountId, Long userId, Map<Long, Integer> roleIdTypeMap);

    void deleteRoleIdTypeMapByUserIdAndAccountId(Long accountId, List<Long> userIdList);

    void clearMultiUserFromCacheByUserAliasCache(Long accountId);
    void clearMultiUserFromCacheByIdsCache(Long accountId);
}
