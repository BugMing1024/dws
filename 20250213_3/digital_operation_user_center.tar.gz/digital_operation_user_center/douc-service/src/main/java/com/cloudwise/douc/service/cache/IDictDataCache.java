package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.dicdata.DicDataInfo;
import com.cloudwise.douc.metadata.model.dicdata.DicTypePo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:59 PM 2021/4/7.
 */
public interface IDictDataCache {

    //字典数据
    List<DicDataInfo> getDictDataByTypeId(Long accountId, Long typeId);

    void setDictDataByTypeId(Long accountId, Long typeId, ArrayList<DicDataInfo> dicDataInfos);

    void deleteDictDataByTypeId(Long accountId, Long typeId);

    //字典类型
    DicTypePo getDicTypeById(Long accountId, Long typeId);

    void setDicTypeByTypeId(Long accountId, Long typeId, DicTypePo dicType);

    void deleteDicTypeByTypeId(Long accountId, Long typeId);

}
