package com.cloudwise.douc.service.util.file;

import com.google.common.collect.Lists;
import lombok.Getter;

import java.util.List;

/**
 * @author Terrell
 * @date 2023-01-10 9:15 上午
 */
@Getter
public enum FileTypeEnum {
    /**
     * 允许上传的附件类型集合
     */
    JPEG("jpeg", "FFD8FF"),
    JPG("jpg", "FFD8FF"),
    PNG("png", "89504E47"),
    BMP("bmp", "424D"),
    RTF("rtf", "7B5C727466"),
    DOC("doc", "D0CF11E0"),
    DOCX("docx", "504B0304"),
    PDF("pdf", "255044462D312E"),
    DWG("dwg", "41433130"),
    PSD("psd", "38425053"),
    XML("xml", "3C3F786D6C"),
    HTML("html", "68746D6C3E"),
    EML("eml", "44656C69766572792D646174653A"),
    XLS("xls", "D0CF11E0"),
    MDB("mdb", "5374616E64617264204A"),
    PS("ps", "252150532D41646F6265"),
    XLSX("xlsx", "504B0304"),
    RAR("rar", "52617221"),
    WAV("wav", "57415645"),
    AVI("avi", "41564920"),
    RM("rm", "2E524D46"),
    MOV("mov", "6D6F6F76"),
    ASF("asf", "3026B2758E66CF11"),
    MID("mid", "4D546864"),
    GZ("gz", "1F8B08"),
    GIF("gif", "47494638"),
    TIF("tif", "49492A00");

    /**
     * 允许上传的文件类型的文件后缀
     */
    private final String suffixName;

    /**
     * 允许上传的文件类型的文件头信息
     */
    private final String headCode;

    /**
     * 构造方法
     *
     * @param suffixName 文件后缀名
     * @param headCode   文件头信息
     */
    FileTypeEnum(String suffixName, String headCode) {
        this.suffixName = suffixName;
        this.headCode = headCode;
    }

    /**
     * 获取允许上传的文件类型集合
     *
     * @return List-String
     */
    public static List<String> getFileType() {
        List<String> fileTypeList = Lists.newArrayListWithExpectedSize(FileTypeEnum.values().length);
        for (FileTypeEnum fileTypeEnum : FileTypeEnum.values()) {
            fileTypeList.add(fileTypeEnum.getSuffixName());
        }
        return fileTypeList;
    }
}