package com.cloudwise.douc.service.common;

import io.swagger.annotations.ApiModel;

/**
 * 企业微信Api URL
 * 企业微信api: https://work.weixin.qq.com/api/doc/90000/90135/91039
 *
 * @author maker.wang
 * @date 2022-01-07 14:09
 **/
@ApiModel("企业微信Api URL")
public class WeComApiUrlConstant {


    /**
     * 获取token  【自建应用&代开发是一个url,就是corpsecret参数不一样】
     * %s占位符
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ID&corpsecret=SECRET
     **/
    public static final String GET_ACCESS_TOKEN = "/cgi-bin/gettoken?corpid=%s&corpsecret=%s";

    /**
     * 身份验证并查询企业微信的用户id 【自建应用&代开发是一个url】
     * %s占位符
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=ACCESS_TOKEN&code=CODE  【官方把这个接口改了】
     **/
    public static final String GET_USER_ID = "/cgi-bin/auth/getuserinfo?access_token=%s&code=%s";

    /**
     * 查询用户的企业微信信息 【拓展字段】
     * %s占位符
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&userid=USERID
     **/
    public static final String GET_USER_INFO = "/cgi-bin/user/get?access_token=%s&userid=%s";


    /**
     * 获取访问用户敏感信息 【邮箱、手机号】
     * %s占位符
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/auth/getuserdetail?access_token=ACCESS_TOKEN
     **/
    public static final String GET_USER_DETAIL = "/cgi-bin/auth/getuserdetail?access_token=%s";


    /**
     * 获取代开发应用模板凭证
     * POST请求
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/service/get_suite_token
     **/
    public static final String GET_SUITE_TOKEN = "/cgi-bin/service/get_suite_token";


    /**
     * 代开发授权应用secret的获取
     * POST请求
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/service/get_permanent_code?suite_access_token=SUITE_ACCESS_TOKEN
     **/
    public static final String GET_PERMANENT_CODE = "/cgi-bin/service/get_permanent_code?suite_access_token=%s";

    /**
     * 获取服务商凭证
     * POST请求
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/service/get_provider_token
     **/
    public static final String GET_PROVIDER_TOKEN = "/cgi-bin/service/get_provider_token";

    /**
     * corpid的转换
     * POST请求
     * 官方示例：https://qyapi.weixin.qq.com/cgi-bin/service/corpid_to_opencorpid?provider_access_token=ACCESS_TOKEN
     **/
    public static final String GET_AUTH_CORP_ID = "/cgi-bin/service/corpid_to_opencorpid?provider_access_token=%s";

}