package com.cloudwise.douc.service.model.dataauthorization;

import com.cloudwise.douc.metadata.model.dataauthorization.DataAndGroupRelationPo;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author liweizhi
 * @date 2020/4/9 10:42
 */
@Data
public class DataAuthUpdateParam implements Serializable {
    /**
     * 当前用户id
     */
    private Long currentUserId;
    /**
     * 租户id
     */
    private Long accountId;
    /**
     * 组id
     */
    private Long groupId;
    private List<ModuleTypeNode> moduleTypeNodes;

    @Data
    public static class ModuleTypeNode implements Serializable {
        /**
         * 模块编码
         */
        private String moduleCode;
        private List<Node> nodes;

    }

    @Data
    public static class Node implements Serializable {
        /**
         * 类型,就是查询结果的节点的type
         */
        private int type;
        /**
         * 数据类型code
         */
        private String dataTypeCode = "";
        /**
         * 数据分组code
         */
        private String dataGroupCode = "";
        /**
         * 模块code
         */
        private int includeFuture = 2;
        /**
         * 数据code
         */
        private String dataCode = "";
        /**
         * 数据是否被选中
         */
        private Boolean selected;

        public DataAndGroupRelationPo newDataAndGroupRalationPo(long accountId, long groupId, String moduleCode, long userId) {
            DataAndGroupRelationPo ret = new DataAndGroupRelationPo();
            ret.setAccountId(accountId);
            ret.setGroupId(groupId);
            ret.setType(this.type);
            ret.setIncludeFuture(this.includeFuture);
            ret.setModuleCode(moduleCode);
            ret.setDataTypeCode(this.dataTypeCode);
            ret.setDataGroupCode(this.dataGroupCode);
            ret.setDataCode(this.dataCode);

            Date now = new Date();
            ret.setCreateUserId(userId);
            ret.setCreateTime(now);
            ret.setModifyUserId(userId);
            ret.setModifTime(now);

            return ret;
        }
    }
}
