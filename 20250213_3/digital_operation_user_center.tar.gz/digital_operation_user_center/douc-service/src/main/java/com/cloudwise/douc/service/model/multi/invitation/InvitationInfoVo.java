package com.cloudwise.douc.service.model.multi.invitation;

import lombok.Data;

import java.io.Serializable;

/**
 * 邀请详情实体
 *
 * @author maker.wang
 * @date 2021-07-15 09:43
 **/
@Data
public class InvitationInfoVo implements Serializable {
    private static final long serialVersionUID = 2621335388938528939L;

    /**
     * 被邀请人邮箱
     **/
    private String inviteeEmail;

    /**
     * 被邀请人姓名
     **/
    private String inviteeName;

    /**
     * 邀请人企业名称
     **/
    private String inviterEnterpriseName;

    /**
     * 邀请人邮箱
     **/
    private String inviterEmail;

    /**
     * 邀请人姓名
     **/
    private String inviterName;

    /**
     * 邀请加入部门名称
     **/
    private String joinDepartmentName;

    /**
     * 加入部门的其实时间
     **/
    private String joinDepartmentStartTime;

    /**
     * 加入部门的终止时间
     **/
    private String joinDepartmentEndTime;

    private Integer origin;

}
