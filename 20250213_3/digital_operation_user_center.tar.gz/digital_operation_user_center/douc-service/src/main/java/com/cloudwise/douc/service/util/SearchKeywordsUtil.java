package com.cloudwise.douc.service.util;

/**
 * SearchKeywordsUtil
 * @author ethan
 */
public class SearchKeywordsUtil {
    
    //%、_、-替换
    public static String escapeKeywords(String keyword) {
        if (keyword == null) {
            return null;
        }
        return keyword.replaceAll("%", "\\\\%").replaceAll("_", "\\\\_").replaceAll("'", "\\\\'")
                .replaceAll("-", "\\\\-");
    }
}
