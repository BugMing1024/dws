package com.cloudwise.douc.service.common;

/**
 * 平台登录静态配置
 *
 * @author maker.wang
 * @date 2022-08-22 11:03
 **/

public class PlatformLoginStaticConfig {

    /**
     * 钉钉
     **/
    public interface DingDing {

        String LOGIN_EMAIL = "email";
        String LOGIN_MOBILE = "mobile";
        String LOGIN_USER_ID = "userid";

        /**
         * 获取Token
         **/
        String GET_ACCESS_TOKEN = "/gettoken?appkey=%s&appsecret=%s";

        /**
         * 查询用户信息
         **/
        String GET_USER_INFO = "/user/getuserinfo?access_token=%s&code=%s";

        /**
         * 查询用户
         **/
        String GET_USER = "/topapi/v2/user/get?access_token=%s";


    }

    /**
     * 企业微信
     **/
    public interface WeCom {

        String USER_TICKET = "user_ticket";
        String SUITE_ID = "suite_id";
        String SUITE_SECRET = "suite_secret";
        String SUITE_TICKET = "suite_ticket";
        String AUTO_CODE = "auth_code";
        String PERMANENT_CODE = "permanent_code";
        String AUTH_CORP_INFO = "auth_corp_info";
        String CORP_ID = "corpid";
        String PROVIDER_SECRET = "provider_secret";
        String PROVIDER_ACCESS_TOKEN = "provider_access_token";
        String OPEN_CORP_ID = "open_corpid";
        String CORP_NAME = "corp_name";
    }


}
