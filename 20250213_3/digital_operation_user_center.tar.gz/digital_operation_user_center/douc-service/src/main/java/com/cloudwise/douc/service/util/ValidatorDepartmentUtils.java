package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import com.cloudwise.douc.metadata.model.department.Department;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author bruce.liu
 * @date 2021/8/29 2:30 下午
 */
@Slf4j
@Component
public class ValidatorDepartmentUtils {


    //校验机构名称
    public List<String> checkDepartmentNames(String departmentName) {
        List<String> result = new ArrayList<>();
        //校验机构名称长度是否大于40个字符
        if (departmentName.length() > 60) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Department Name】：" + departmentName + " length greater than 60 characters");
            } else {
                result.add("【机构名称】：" + departmentName + "长度大于60个字符");
            }
        }
        if (departmentName.contains(StrPool.SLASH)) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Department Name】：" + departmentName + " No spaces Or No /");
            } else {
                result.add("【机构名称】：" + departmentName + "不能有/");
            }
        }
        return result;
    }

    // 手机号
    public List<String> checkPhone(String phone) {
        List<String> result = new ArrayList<>();
        if (!checkPhones(phone)) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Department phone】：" + phone + " Format error");
            } else {
                result.add("【机构电话】：" + phone + "格式错误");
            }
        }
        return result;
    }

    private static boolean checkPhones(String phone) {
        return ((phone.startsWith("1") || phone.startsWith("852")) && phone.matches("^\\d{11}$")) || phone.matches("^([6|9|5])\\d{7}$") || ((
                phone.startsWith("+852") && phone.matches("^\\d{12}$")));
    }

    public List<String> checkDepartmentNameSingle(String parentCode, String name, List<Department> parentCodeAndName) {
        List<String> result = new ArrayList<>();
        List<String> nameList = parentCodeAndName.stream().filter(e -> parentCode.equals(e.getParentCode())).map(Department::getName)
                .collect(Collectors.toList());
        if (Collections.frequency(nameList, name) > 1) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Name.】：" + name + "Duplication is not allowed at the same level");
                return result;
            } else {
                result.add("【组织结构名称】：" + name + "同级别下不允许重复");
                return result;
            }
        }
        return result;
    }

    public List<String> checkAddress(String address) {
        List<String> result = new ArrayList<>();
        log.info("{}", address.length());
        if (address.length() > 60) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Department Address】：" + address + " length greater than 60 characters");
            } else {
                result.add("【机构地址】：" + address + "长度大于60个字符");
            }
        }
        return result;
    }

    public List<String> checkType(String type, List<String> typeInDB) {
        List<String> result = new ArrayList<>();
        if (!typeInDB.contains(type)) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Department Type】：" + type + " type error");
            } else {
                result.add("【机构类型】：" + type + "不存在");
            }
        }
        return result;
    }
}