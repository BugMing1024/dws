package com.cloudwise.douc.service.model.auth;

import lombok.Data;

import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 3:47 PM 2020/4/12.
 */
@Data
public class DataAuthResponseObject {

    private List<DataAuthResponseNode> dataTypes;
    private List<DataAuthResponseDataTypeNode> dataGroups;
    private List<DataAuthResponseDataTypeNode> dataItems;

}
