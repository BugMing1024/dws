package com.cloudwise.douc.service.model.multi.invitation;

import lombok.Data;

import java.io.Serializable;

/**
 * 邀请回复入参实体
 *
 * @author maker.wang
 * @date 2021-07-15 18:58
 **/
@Data
public class InvitationParamsBo implements Serializable {
    private static final long serialVersionUID = -702361740653136632L;

    public InvitationParamsBo() {
        this.acceptInvitation = Boolean.TRUE;
    }

    /**
     * 外部链接uuid
     **/
    private String externalLinkUuid;

    /**
     * true:接受邀请 false:拒绝
     **/
    private Boolean acceptInvitation;
}
