package com.cloudwise.douc.service.model.apimanage;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: API信息实体类
 *
 * @author damon
 */
@Data
public class ApiDetailVo implements Serializable {

    private String code;
    /**
     * 模块编码
     */
    private String moduleCode;
    /**
     * API名称
     */
    private String name;
    /**
     * 资源路径
     */
    private String uri;
    /**
     * rule
     */
    private String rule;
    /**
     * 发布状态
     */
    private Integer status;
    /**
     * 限制信息
     */
    private String limitInfo;
    /**
     * 过期时间(代表应用和api之间的绑定关系的时间)
     */
    private Date expireTime;
    /**
     * 0-永久，1-短期
     **/
    private Integer bindType;
}
