package com.cloudwise.douc.service.model.sync;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * Dubbo删除用户实体
 *
 * @author maker.wang
 * @date 2021-11-08 17:30
 **/
@Data
@ApiModel("Dubbo删除用户实体")
public class DubboDeleteUser implements Serializable {
    private static final long serialVersionUID = 8586726058499572576L;

    @ApiModelProperty(value = "用户编码集合", required = true)
    private List<String> userCodes;
    @ApiModelProperty(value = "用户编码集合", required = true)
    private List<Long> ids;

    @ApiModelProperty(value = "顶级租户id", required = true)
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_TOP_ID_NULL)
    private Long accountId;


}
