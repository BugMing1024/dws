package com.cloudwise.douc.service.cache.impl;

import cn.hutool.core.text.StrPool;
import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.redis.RedisTools;
import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;
import com.cloudwise.douc.service.cache.IGroupCache;
import com.cloudwise.douc.service.cache.IUserCache;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Slf4j
@Component
public class GroupCacheImpl implements IGroupCache {
    @Autowired
    private IUserCache userCache;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public List<Long> getUserIdListFromCacheByGroupId(long groupId, String accountId) {
        ArrayList<Long> userIds = getGroupHasUserIdListFromCacheByGroupId(groupId + "", accountId);
        return userIds;
    }

    @Override
    public ArrayList<Long> getGroupHasUserIdListFromCacheByGroupId(String groupId, String accountId) {
        ArrayList<Long> userInfo = RedisTools.getByte(getGroupUserRedisKey(accountId, groupId), ArrayList.class);
        return userInfo;
    }

    @Override
    public List<UserBaseInfoCacheDTO> getGroupHasUserListFromCacheByUserIdsAndUserStatus(List<Long> userIds, String accountId) {
        List<UserBaseInfoCacheDTO> userList = userCache.getMultiUserFromCacheByIds(Long.valueOf(accountId), userIds);
        return userList;
    }


    @Override
    public void setGroupUserBasedByGroupIdToCache(String groupId, String accountId, ArrayList<Long> userIds) {
        //更新redis
        long redisOutTime = CacheConstant.ONE_MINITE_DDL * 60L;
        boolean cacheBoolean = RedisTools.setByteWithTime(getGroupUserRedisKey(accountId, groupId), userIds, redisOutTime);
        if (!cacheBoolean) {
            log.warn("===============douc-group-cache-error=================");
        }
    }

    @Override
    public boolean deleteGroupUserBasedByGroupIdToCache(String groupId, String accountId) {
        boolean cacheBoolean = RedisTools.deleteValueByKey(getGroupUserRedisKey(accountId, groupId));
        if (!cacheBoolean) {
            log.warn("=============delete==douc-group-cache-error=================");
        }
        return cacheBoolean;
    }

    @Override
    public List<GroupBaseInfo> getAllGroupByAccountId(Long accountId) {
        String result = RedisTools.getByteWithGzip(getGroupRedisKey(accountId), String.class);
        CollectionType listType = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, GroupBaseInfo.class);
        List<GroupBaseInfo> groupRespList = null;
        if (StrUtil.isBlank(result)) {
            return null;
        } else {
            try {
                groupRespList = objectMapper.readValue(result, listType);
            } catch (Exception e) {
                log.error("get all group from cache error:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR, e);
            }
        }
        return groupRespList;
    }

    @Override
    public void setAllGroupByAccountId(Long accountId, List<GroupBaseInfo> groupBaseInfos) {
        try {
            String groupBaseInfosStr = objectMapper.writeValueAsString(groupBaseInfos);
            boolean set = RedisTools.setByteWithGzip(getGroupRedisKey(accountId), groupBaseInfosStr, CacheConstant.ROLE_GROUP_CACHE_DIRECT_TTL);
            if (!set) {
                log.error("Caching all group error:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_GROUP_CACHE_ERROR);
            }
        } catch (JsonProcessingException e) {
            log.error("Caching all group error:{}", accountId);
            throw new BaseException(IBaseExceptionCode.API_GROUP_CACHE_ERROR, e);
        }
    }

    @Override
    public boolean deleteGroupByAccountId(Long accountId) {
        String key = getGroupRedisKey(accountId);
        if (RedisTools.isKeyExist(key)) {
            boolean hmset = RedisTools.deleteValueByKey(key);
            if (!hmset) {
                log.error("delete group cache error:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_GROUP_CACHE_ERROR);
            }
            return hmset;
        }
        return false;
    }

    @Override
    public Map<String, ArrayList<String>> getGroupLeaderCache(Long accountId) {

        String result = RedisTools.getByteWithGzip(getGroupLeaderRedisKey(accountId), String.class);

        Map<String, ArrayList<String>> groupRespList = null;
        if (result == null) {
            return null;
        } else {
            try {
                groupRespList = objectMapper.readValue(result, Map.class);
            } catch (Exception e) {
                log.error("Failed to get groupLeader from cache accountId:{}, exception:{}", accountId, e.getStackTrace());
                throw new BaseException(IBaseExceptionCode.API_ROLE_CACHE_ERROR, e);
            }
        }
        return groupRespList;

    }

    @Override
    public void setGroupLeaderCache(Long accountId, Map<String, ArrayList<String>> groupLeaderMap, Long time) {
        try {
            String groupBaseInfosStr = objectMapper.writeValueAsString(groupLeaderMap);
            boolean set = RedisTools.setByteWithGzip(getGroupLeaderRedisKey(accountId), groupBaseInfosStr, time);
            if (!set) {
                log.error("Failed to set groupLeader from cache accountId:{}", accountId);
                throw new BaseException(IBaseExceptionCode.API_GROUP_LEADER_CACHE_ERROR);
            }
        } catch (JsonProcessingException e) {
            log.error("Failed to set groupLeader from cache accountId:{}, exception:{}", accountId, e.getStackTrace());
            throw new BaseException(IBaseExceptionCode.API_GROUP_LEADER_CACHE_ERROR);
        }

    }

    @Override
    public void deleteGroupUserBasedByGroupIdsKeysToCache(List<String> groupUserKeys) {
        try {
            RedisTools.deleteValueByKeys(groupUserKeys);
        } catch (Exception e) {
            log.error("批量用户组用户删除缓存失败:{}", groupUserKeys);
            throw new BaseException(IBaseExceptionCode.API_GROUP_CACHE_ERROR, e);
        }
    }


    /**
     * 获取用户组领导key
     *
     * @param accountId
     * @return
     */
    private String getGroupLeaderRedisKey(Long accountId) {
        return CacheConstant.DOUC_GROUP_LEADER_CACHE_PRE + accountId;
    }

    /**
     * 获取用户组下用户key
     *
     * @param accountId
     * @param groupId
     * @return
     */
    private String getGroupUserRedisKey(String accountId, String groupId) {
        return CacheConstant.DOUC_GROUP_USER_CACHE_PRE + accountId + StrPool.C_COLON + groupId;
    }

    /**
     * 获取用户组key
     *
     * @param accountId
     * @return
     */
    private String getGroupRedisKey(Long accountId) {
        return CacheConstant.DOUC_GROUP_CACHE_PRE + accountId;
    }

    @Override
    public boolean deleteGroupListByAccountId(Long accountId, List<Long> groupIdList) {
        List<String> keys = Lists.newArrayListWithExpectedSize(groupIdList.size());
        for (Long id : groupIdList) {
            keys.add(CacheConstant.DOUC_GROUP_USER_CACHE_PRE + accountId + StrPool.C_COLON + id);
        }
        return RedisTools.deleteValueByKeys(keys);
    }
}
