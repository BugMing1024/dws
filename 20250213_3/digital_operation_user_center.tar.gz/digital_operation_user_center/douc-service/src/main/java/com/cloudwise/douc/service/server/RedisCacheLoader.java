package com.cloudwise.douc.service.server;

import com.cloudwise.douc.commons.constant.CacheConstant;
import lombok.extern.slf4j.Slf4j;

/**
 * @author KenLiang
 * @description:
 * @date Created in 2:28 PM 2020/7/22.
 */
@Slf4j
public class RedisCacheLoader {

    public static String getAccountDepartmentCacheKey(Long accountId) {
        return CacheConstant.REDIS_CACHE_KEY_DEPARTMENTNODE_HASH_KEY + accountId;
    }
}
