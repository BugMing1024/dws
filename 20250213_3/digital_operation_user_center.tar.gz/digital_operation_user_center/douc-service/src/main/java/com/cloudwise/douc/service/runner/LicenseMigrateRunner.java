package com.cloudwise.douc.service.runner;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloudwise.cwop.l.LsdkV1;
import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.metadata.activerecord.License;
import com.cloudwise.douc.metadata.mapper.ILicenseDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * @author ethan 初始化license库表 && 迁移历史license文件
 */
@ConditionalOnProperty(name = "condition.migrate.old_license", havingValue = "true")
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 1)
@Slf4j
public class LicenseMigrateRunner implements ApplicationRunner {
    
    @Autowired
    private ILicenseDao licenseDao;
    
    @Override
    public void run(ApplicationArguments args) {
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            try {
                
                // 迁移数据
                LambdaQueryWrapper<License> queryMapper = new LambdaQueryWrapper<>();
                queryMapper.orderByDesc(License::getUpdatedTime);
                Page<License> page = new Page<>(1, 1);
                Page<License> licensePage = licenseDao.selectPage(page, queryMapper);
                List<License> records = licensePage.getRecords();
                if (CollectionUtil.isEmpty(records)) {
                    return;
                }
                License license = records.get(0);
                if (Objects.nonNull(license)) {
                    String migrateResult = LsdkV1.migrate(license.getSign());
                    log.info("License migrate result: {}", migrateResult);
                } else {
                    log.info("License migrate needless");
                }
            } catch (Exception e) {
                log.error("License migrate error", e);
            }
        });
    }
}



