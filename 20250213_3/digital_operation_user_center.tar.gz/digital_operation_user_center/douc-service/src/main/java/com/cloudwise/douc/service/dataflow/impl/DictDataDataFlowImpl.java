package com.cloudwise.douc.service.dataflow.impl;

import com.cloudwise.douc.metadata.mapper.IDicDataDao;
import com.cloudwise.douc.metadata.model.dicdata.DicDataInfo;
import com.cloudwise.douc.metadata.model.dicdata.DicTypePo;
import com.cloudwise.douc.service.cache.IDictDataCache;
import com.cloudwise.douc.service.dataflow.IDictDataFlow;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:54 PM 2021/4/7.
 */
@Component
public class DictDataDataFlowImpl implements IDictDataFlow {
    @Autowired
    private IDictDataCache dictDataCache;
    @Autowired
    private IDicDataDao dictDataDao;

    @Override
    public List<DicDataInfo> getDictDataByTypeId(Long accountId, Long typeId) {
        List<DicDataInfo> dictDataByTypeId = dictDataCache.getDictDataByTypeId(accountId, typeId);
        if (CollectionUtils.isEmpty(dictDataByTypeId)) {
            dictDataByTypeId = dictDataDao.getAllDicDataInfoByTypeId(accountId, typeId);
            dictDataCache.setDictDataByTypeId(accountId, typeId, (ArrayList<DicDataInfo>) dictDataByTypeId);
        }
        return dictDataByTypeId;
    }

    @Override
    public void deleteDictDataByTypeId(Long accountId, Long typeId) {
        dictDataCache.deleteDictDataByTypeId(accountId, typeId);
    }

    @Override
    public Map<String, DicDataInfo> getDictDataMapByTypeId(Long accountId, Long typeId) {
        Map<String, DicDataInfo> dicDataInfoMap = Maps.newHashMap();
        List<DicDataInfo> dictDataByTypeId = dictDataCache.getDictDataByTypeId(accountId, typeId);
        if (CollectionUtils.isEmpty(dictDataByTypeId)) {
            dictDataByTypeId = dictDataDao.getAllDicDataInfoByTypeId(accountId, typeId);
            dictDataCache.setDictDataByTypeId(accountId, typeId, (ArrayList<DicDataInfo>) dictDataByTypeId);
        }
        dictDataByTypeId.forEach(dicDataInfo -> {
            dicDataInfoMap.put(dicDataInfo.getCode(), dicDataInfo);
        });
        return dicDataInfoMap;
    }

    @Override
    public DicTypePo getDicTypeById(Long accountId, Long typeId) {
        DicTypePo dicType = dictDataCache.getDicTypeById(accountId, typeId);
        if (dicType == null) {
            dicType = dictDataDao.getDicTypeById(accountId, typeId);
            dictDataCache.setDicTypeByTypeId(accountId, typeId, dicType);
        }
        return dicType;
    }

    @Override
    public void deleteDictTypeByTypeId(Long accountId, Long typeId) {
        dictDataCache.deleteDicTypeByTypeId(accountId, typeId);
    }
}
