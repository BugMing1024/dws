package com.cloudwise.douc.service.model.user;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * @author barney.song
 * Description: No Description
 */
public enum ExcelDepartmentEntity {
    /**
     * 用户名（必填）
     */
    NAME(0, "name", "机构名称Department", "机构名称"),
    /**
     * 机构编号
     */
    CODE(1, "code", "机构编号Department ID", "机构编号"),


    /**
     * 上级部门（必填）
     */
    PARENTNAME(2, "parentName", "上级部门 Parent Department", "上级部门"),
    /**
     * 状态
     */
    STATUS(3, "status", "状态Status", "状态"),

    /**
     * 机构类型
     */
    ORGTYPE(4, "orgTypeName", "机构类型 OrgType", "机构类型"),


    /**
     * 来源（必填）
     */
    ADDRESS(5, "address", "机构地址 Address", "机构地址"),
    /**
     * 机构人数
     */
    COUNTPERSON(6, "countPerson", "机构人数 CountPerson", "机构人数");


    private int index;
    private String fieldName;
    private String excelRowName;
    private String excelHeadName;

    ExcelDepartmentEntity(int index, String fieldName, String excelRowName, String excelHeadName) {
        this.index = index;
        this.fieldName = fieldName;
        this.excelRowName = excelRowName;
        this.excelHeadName = excelHeadName;
    }

    public static String getExcelRowNameByIndex(int index) {
        for (ExcelDepartmentEntity excelEntity : ExcelDepartmentEntity.values()) {
            if (index == excelEntity.index) {
                return excelEntity.excelRowName;
            }
        }
        return null;
    }

    public static List toExcelHeadName() {
        List list = Lists.newArrayListWithExpectedSize(ExcelDepartmentEntity.values().length);
        for (ExcelDepartmentEntity excelEntity : ExcelDepartmentEntity.values()) {
            list.add(excelEntity.getExcelHeadName());
        }
        return list;
    }

    public static List toExcelRowName() {
        List list = Lists.newArrayListWithExpectedSize(ExcelDepartmentEntity.values().length);
        for (ExcelDepartmentEntity excelEntity : ExcelDepartmentEntity.values()) {
            list.add(excelEntity.getExcelRowName());
        }
        return list;
    }

    public int getIndex() {
        return index;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getExcelRowName() {
        return excelRowName;
    }

    public String getExcelHeadName() {
        return excelHeadName;
    }
}
