package com.cloudwise.douc.service.model.dic;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@ApiModel
public class DubboDicQueryParamsDto {

    @ApiModelProperty(value = "租户id", required = true)
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;

    @ApiModelProperty(value = "字典类型编码", required = true)
    @NotBlank(message = IBaseExceptionCode.DIC_TYPE_CODE_NOT_BLANK)
    private String dicTypeCode;

    @ApiModelProperty(value = "字典数据编码")
    private List<String> dicDataCodes;

    @ApiModelProperty(value = "是否查询停用的数据选项数据 默认false:不包含停用的  true:查询结果包含停用的")
    private Boolean includeDisable;
}
