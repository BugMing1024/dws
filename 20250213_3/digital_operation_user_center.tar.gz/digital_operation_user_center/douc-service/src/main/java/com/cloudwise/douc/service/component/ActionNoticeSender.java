package com.cloudwise.douc.service.component;

import cn.hutool.core.date.SystemClock;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.commons.utils.JsonUtils;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import com.cloudwise.douc.dto.common.ActionNotice;
import com.cloudwise.douc.service.mq.MultiSender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 消息通知的发送类，是所有埋点通知的入口
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/10/15 0:36; update at 2023/10/15 0:36
 */
@Slf4j
@Component
public class ActionNoticeSender {
    
    @Resource
    private MultiSender sender;
    
    @Resource
    private ActionNoticeHandler handler;
    
    /**
     * 如果你进行了一些变更操作，应当把调用此方法进行通知
     *
     * @param actionNotice 触发的操作的具体内容
     */
    public void send(ActionNotice actionNotice) {
        try {
            actionNotice.setTime(SystemClock.now());
            if (!actionNotice.getActionNoticeTypeEnum().getCode().contains("domain")) {
                actionNotice.setAccountId(ThreadLocalUtil.getAccountId());
            }
            //异步发送 同步连接kafka可能比较耗时
            AsyncTaskPool.getTaskExecutor().execute(() -> {
                sender.send(ConfigUtils.getString("msg.topic.action-notice", ActionNotice.NOTICE_TOPIC), JsonUtils.encode(actionNotice));
            });
        } finally {
            if (actionNotice.getAsync() == null || actionNotice.getAsync()) {
                AsyncTaskPool.getTaskExecutor().execute(() -> {
                    handler(actionNotice);
                });
            } else {
                log.info("同步执行任务：{}", actionNotice);
                handler(actionNotice);
            }
            
        }
    }
    
    private void handler(ActionNotice actionNotice) {
        try {
            log.info("handle-开始处理");
            handler.handle(actionNotice);
            log.info("handle-处理成功");
        } catch (Throwable exception) {
            log.error("handle-处理失败", exception);
        } finally {
            log.info("handle-处理完成");
        }
    }
    
    
}
