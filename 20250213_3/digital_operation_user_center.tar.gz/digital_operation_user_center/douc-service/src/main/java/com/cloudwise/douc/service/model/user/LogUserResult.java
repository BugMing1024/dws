package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Anson
 * @description:
 * @Date Created in 上午11:38 2022/3/30.
 */
@Data
public class LogUserResult implements Serializable {
    private static final long serialVersionUID = 1L;

    private String status;
    private String roleName;
    private String projectName;
    private String positionName;
}
