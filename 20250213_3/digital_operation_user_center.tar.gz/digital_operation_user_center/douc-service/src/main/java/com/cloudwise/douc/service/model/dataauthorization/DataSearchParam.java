package com.cloudwise.douc.service.model.dataauthorization;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.util.Set;

/**
 * @author liweizhi
 * @date 2020/4/9 10:42
 */
@Data
public class DataSearchParam implements Serializable {
    private Integer current;
    private Integer size;
    /**
     * 租户id
     */
    private Long accountId;
    /**
     * 组id
     */
    private Long groupId;
    /**
     * 名称
     */
    private String name;
    // 普通搜索
    /**
     * 模块编码
     */
    private String moduleCode;
    // 高级搜索
    /**
     * 模块编码数组
     */
    private String[] moduleCodeArray;
    /**
     * 数据类型编码
     */
    private String dataTypeCode;
    /**
     * 去重数据类型编码
     */
    @JsonIgnore
    private Set<String> excledeDataTypeCodeSet;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
