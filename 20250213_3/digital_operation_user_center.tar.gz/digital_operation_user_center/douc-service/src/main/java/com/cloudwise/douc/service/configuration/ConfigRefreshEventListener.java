package com.cloudwise.douc.service.configuration;

import cn.hutool.core.text.StrPool;
import com.cloudwise.cwop.security.RSAUtils;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.context.environment.EnvironmentChangeEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;

import java.util.Arrays;
import java.util.Collection;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author zafir.zhong
 * @description 监听配置变化，现在nacos修改也会感知到并进行解密，不知道效果怎么样
 * @date Created in 16:17 2022/12/12.
 */
@Slf4j
public class ConfigRefreshEventListener implements ApplicationListener<EnvironmentChangeEvent> {

    private static final String DECRYPT_PROP = "props.decrypt.props";
    private static final String DECRYPT_NOPROP = "props.decrypt.noprops";
    
    private static final String DECRYPT_NAME = "props.decrypt.key";
    private static final String DECRYPT_PROPERTY_SOURCE = "cloudwise-common-decrypt";

    @Override
    public void onApplicationEvent(EnvironmentChangeEvent event) {
        if (!(event.getSource() instanceof ConfigurableApplicationContext)) {
            return;
        }
        ConfigurableEnvironment environment = ((ConfigurableApplicationContext) event.getSource()).getEnvironment();
        MutablePropertySources propertySources = environment.getPropertySources();
        //nacos账号密码解密
        Collection<String> processDecryptKeys = Arrays.stream(environment.getProperty(DECRYPT_PROP, "").split(StrPool.COMMA)).collect(Collectors.toSet());
        Collection<String> noprocessDecryptKeys = Arrays.stream(environment.getProperty(DECRYPT_NOPROP, "").split(StrPool.COMMA)).collect(Collectors.toSet());
        processDecryptKeys.removeAll(noprocessDecryptKeys);
        if (event.getKeys().stream().noneMatch(processDecryptKeys::contains)) {
            return;
        }
        log.info("preparedDecryptKeyList : {}", processDecryptKeys);
        PropertiesPropertySource propertiesPropertySource = processDecryptProperties(environment, processDecryptKeys);
        propertySources.remove(DECRYPT_PROPERTY_SOURCE);
        propertySources.addFirst(propertiesPropertySource);
        log.info("{}", event);
    }

    private PropertiesPropertySource processDecryptProperties(ConfigurableEnvironment environment,
                                                              @NonNull Collection<String> keys) {
        final Set<String> collect = keys.stream().filter(StringUtils::isNoneBlank).map(String::trim)
                .collect(Collectors.toSet());
        Properties properties = new Properties();
        collect.forEach(key -> {
            String value = environment.getProperty(key, "");
            if (StringUtils.isNoneBlank(value)) {
                String decrypt = decrypt(value, environment.getProperty(DECRYPT_NAME));
                properties.setProperty(key, decrypt);
            }
        });
        return new PropertiesPropertySource(DECRYPT_PROPERTY_SOURCE, properties);
    }

    private String decrypt(String source, String key) {
        if (StringUtils.isBlank(key)) {
            log.error("DecryptKey cannot be null or empty.");
        }
        String result = null;
        try {
            result = RSAUtils.decrypt(key, source);
            log.info(">>>processDecryptProperties--success>>>-【{}】-【{}】", key, source);
        } catch (Exception e) {
            log.warn("Decryption failed:", e);
            log.warn("Decryption failed,key:{}", key);
            result = source;
        }
        return result;
    }

}
