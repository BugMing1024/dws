package com.cloudwise.douc.service.model.channel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author zafir.zhong
 * @description 渠道一个特定的字段属性配置
 * @date Created in 15:42 2022/4/15.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelFieldConfig {
    /**
     * 传入实现类的字段值
     */
    private String key;
    /**
     * 字段的显示名称 中文
     */
    private String name;
    /**
     * 字段的显示名称 英文
     */
    private String enName;
    /**
     * 字段的类型，若为 1 则为填写类型 若为2 则为自动填充类型
     */
    private int fieldType;
    /**
     * 字段的类型，若为 1 字符串 2为选项 3为uri（需要前端填充）
     */
    private int valueType;
    /**
     * 是否变化会影响其他选项
     */
    private Boolean refreshView;

    /**
     * 是否为必填
     */
    private boolean notNull;
    /**
     * 选项设置
     */
    private Choice choice;

    private ChannelSubField subField;
    /**
     * 在填写框下面的提示
     */
    private String tipsUnderInput;

    /**
     * 在填写框中的提示
     */
    private String tipsInInput;
    /**
     * 在填写框下面的提示
     */
    private String enTipsUnderInput;

    /**
     * 在填写框中的提示
     */
    private String enTipsInInput;
    /**
     * 默认值
     */
    private String defaultValue;

    /**
     * 实际填写内容
     */
    private String value;

    @ApiModelProperty("条件表达式")
    private List<ChannelConditionConfig> condition;

    /**
     * 完全禁止修改
     */
    private boolean disabled;

    /**
     * 禁止修改 true:不能修改  false:可以修改
     **/
    private boolean modifyDisable;
    
    private String multiLanguage;

    @Data
    public static class Choice {
        /**
         * 1 为下拉 2为选项
         */
        private int type;
        /**
         * 是否多选
         */
        private boolean multipleChoice;
        /**
         * 选项单项
         */
        private List<Option> enums;
    }

}
