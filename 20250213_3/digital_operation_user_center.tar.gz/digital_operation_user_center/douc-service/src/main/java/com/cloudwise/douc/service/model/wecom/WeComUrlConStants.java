package com.cloudwise.douc.service.model.wecom;


public class WeComUrlConStants {
    public static final String WECOM_ACCESS_TOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken";

    public static final String WECOM_DEPARTMENT_LIST_URL = "https://qyapi.weixin.qq.com/cgi-bin/department/list";

    public static final String WECOM_USER_INFO_LIST_URL = "https://qyapi.weixin.qq.com/cgi-bin/user/list";
}
