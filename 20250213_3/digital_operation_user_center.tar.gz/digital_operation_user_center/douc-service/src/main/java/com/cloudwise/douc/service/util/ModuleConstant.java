package com.cloudwise.douc.service.util;

/**
 * @author elsa.yang
 * @date 2020/8/4 10:25 上午
 */
public class ModuleConstant {

    public static final String DOUC_MODULE = "用户中心";

    public static final String DOUC_MODULE_SWITCH_ACCOUNT = DOUC_MODULE + "/切换租户";

    public static final String DOUC_MODULE_ENTER_CHILD_ACCOUNT = DOUC_MODULE + "/进入子租户";

    public static final String DOUC_MODULE_DEPARTMENT = DOUC_MODULE + "/组织机构";

    public static final String DOUC_MODULE_USER = DOUC_MODULE + "/用户管理";

    public static final String DOUC_MODULE_USER_INFO = DOUC_MODULE + "/个人设置";

    public static final String DOUC_MODULE_ROLE = DOUC_MODULE + "/角色管理";

    public static final String DOUC_MODULE_USER_GROUP = DOUC_MODULE + "/用户组管理";

    public static final String DOUC_MODULE_LOGAUDIT = DOUC_MODULE + "/日志审计";

    public static final String DOUC_MODULE_LDAP = DOUC_MODULE + "/系统管理";

    public static final String DOUC_MODULE_IPRULE = DOUC_MODULE_LDAP + "/IP规则设置";

    public static final String DOUC_MODULE_LICENSE = DOUC_MODULE_LDAP + "/License管理";

    public static final String DOUC_MODULE_DICDATE = DOUC_MODULE_LDAP + "/字典管理";

    public static final String DOUC_MODULE_EXTEND = DOUC_MODULE + "/拓展属性管理";
    public static final String DOUC_MODULE_LOGO = DOUC_MODULE + "/LOGO管理";
    public static final String DOUC_MODULE_LANGUAGE = DOUC_MODULE + "/国际化切换管理";

    public static final String DOUC_MODULE_SYSTEM_MANAGE = DOUC_MODULE + "/系统管理";
    public static final String DOUC_MODULE_SYSTEAM_UPGRADE = DOUC_MODULE + "/系统升级提示设置";

    public static final String DOUC_MODULE_ACCOUNT = DOUC_MODULE + "/多租户管理";
    public static final String DOUC_MODULE_SET = DOUC_MODULE + "/设置";
    public static final String DOUC_MODULE_ACCOUNT_INVITE = DOUC_MODULE + "/多租户邀请列表管理";
    //日志审计新增module
    public static final String DOUC_MODULE_USER_UPDATETIMEZONE = DOUC_MODULE_SET + "/时区设置";
    public static final String DOUC_MODULE_LOGO_UPDATE = DOUC_MODULE + "/设置/个性化设置";
    public static final String DOUC_MODULE_IP = DOUC_MODULE + "/设置/安全设置";
    public static final String DOUC_SAAS_MODULE_IP = "设置/系统设置/安全设置";
    public static final String DOUC_MODULE_CHILDREN_ACCOUNT = DOUC_MODULE + "/子租户管理";
    public static final String DOUC_MODULE_DIC = DOUC_MODULE + "/设置/数据字典";
    public static final String DOUC_MODULE_WATERMARK = DOUC_MODULE + "/设置/安全设置/水印设置";
    public static final String DOUC_USERINFO = "个人设置/基本信息";
    public static final String DOUC_ACCOUNT = DOUC_MODULE + "/租户管理";
    public static final String DOUC_SECRET = "个人设置/密码设置";
    public static final String DOUC_EXPORT_LOG = DOUC_MODULE_LOGAUDIT + "/登录日志";
    public static final String DOUC_EXPRT_SYS_LOG = DOUC_MODULE_LOGAUDIT + "/系统操作日志";
    public static final String DOUC_EXPRT_BUSINESS_LOG = DOUC_MODULE_LOGAUDIT + "/业务操作日志";
    public static final String DOUC_ACCOUNT_CENTER = "账号中心/账号与安全";

    //身份源相关
    public static final String DOUC_IDENTITY_SOURCE = DOUC_MODULE + "/身份源管理";

    // 渠道管理的日志审计

    public static final String DOUC_CHANNEL = DOUC_MODULE + "/渠道管理";
    public static final String DOUC_SIMULATE_USER = DOUC_MODULE + "/模拟用户";
}
