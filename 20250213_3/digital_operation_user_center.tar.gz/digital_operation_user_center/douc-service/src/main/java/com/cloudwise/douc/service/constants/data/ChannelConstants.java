package com.cloudwise.douc.service.constants.data;

/**
 * @author zafir.zhong
 * @description 渠道相关的常量
 * @date Created in 15:21 2022/5/16.
 */
public class ChannelConstants {

    public static class DOUCANDMessage {
        public static final String TOPIC_CHANNEL_REAL_CONFIG_MODIFY = "TOPIC_CHANNEL_REAL_CONFIG_MODIFY";
        public static final String CONSUMER_GROUP_CHANNEL_REAL_CONFIG_MODIFY = "CONSUMER_GROUP_CHANNEL_REAL_CONFIG_MODIFY";

        public static final String TOPIC_CHANNEL_CALL_BACK_NOTICE = "TOPIC_CHANNEL_CALL_BACK_NOTICE";
        public static final String CONSUMER_GROUP_CHANNEL_CALL_BACK_NOTICE = "CONSUMER_GROUP_CHANNEL_CALL_BACK_NOTICE";
    }

    public static class RealConfigStatus {
        //启用
        public static final int STATUS_UP = 1;
        //停用
        public static final int STATUS_DOWN = 0;

        public static final int STATUS_FAIL = -1;
    }

    public static class DefaultChannelCode {
        public static final String WECOM = "WECOM";
        public static final String FEISHU = "FEISHU";
        public static final String DINGTALK = "DINGTALK";
        public static final String AZURE = "AZURE";
        public static final String EMAIL = "EMAIL";
        public static final String SMS = "SMS";
        public static final String WXPUSH = "WXPUSH";
    }

    public static class CacheKey {
        public static final String EMAIL_2_FEISHU_KEY = "MESSAGE:FEISHU_EMAIL_OPEN_ID:";
        public static final String FEISHU_GET_USER_LIMIT = "MESSAGE:FEISHU_USER_LIMIT:";
        public static final String CHANNEL_INIT_LOCK = "CHANNEL_INIT_LOCK";
        public static final String CHANNEL_SMS_INIT_LOCK = "CHANNEL_SMS_LOCK";
    }

    public static class CacheTime {
        public static final long CHANNEL_INIT_LOCK = 120L;
        public static final long CHANNEL_SMS_INIT_LOCK = 120L;
    }

    public static class HideChannel {
        public static final int HIDE = 1;
        public static final int DEFAULT = 0;
    }
}
