package com.cloudwise.douc.service.plugin.lucene.redir;

import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.constant.CacheConstant;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import org.apache.lucene.store.AlreadyClosedException;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.Lock;
import org.apache.lucene.store.LockFactory;
import org.apache.lucene.store.LockObtainFailedException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;

import java.io.IOException;
import java.util.Collections;
import java.util.UUID;

/**
 * @author dwq
 */
@Log4j2
public class RedissonFactory extends LockFactory {
    
    private RedisTemplate redisTemplate;
    
    public static final DefaultRedisScript<Boolean> LOCK = new DefaultRedisScript<>(
            "if (redis.call('exists', KEYS[1]) == 0) then " + "redis.call('set', KEYS[1], ARGV[2]); "
                    + "redis.call('expire', KEYS[1], ARGV[1]); " + "return 1; "
                    + "else if (redis.call('get', KEYS[1]) == ARGV[2]) then "
                    + "redis.call('expire', KEYS[1], ARGV[1]); " + "return 1; " + "end; " + "end; " + "return 0; ",
            Boolean.class);
    
    public static final DefaultRedisScript<Boolean> UN_LOCK_NOW = new DefaultRedisScript<>(
            "if (redis.call('exists', KEYS[1]) == 0) then " + "return 1; "
                    + "else if (redis.call('get', KEYS[1]) == ARGV[2]) then " + "redis.call('del', KEYS[1]); "
                    + "return 1; " + "end; " + "end; " + "return 0;", Boolean.class);
    
    public RedissonFactory(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }
    
    @Override
    public Lock obtainLock(@NonNull Directory dir, String lockName) throws IOException {
        String pre = CacheConstant.REDIS_CACHE_KEY_LUCENE_PRE;
        String uuid = UUID.randomUUID().toString();
        if (dir instanceof FSDirectory) {
            pre = pre + ConfigUtils.getString("cwServiceHostname") + ((FSDirectory) dir).getDirectory().toString();
        } else if (dir instanceof RedisDirectory) {
            pre = pre + ((RedisDirectory) dir).getIndex();
        } else {
            throw new LockObtainFailedException("lock support FSDirectory and RedisDirectory");
        }
        String key = pre + lockName;
        Object execute = redisTemplate.execute(LOCK, Collections.singletonList(key), 300, uuid);
        if (!Boolean.TRUE.equals(execute)) {
            throw new LockObtainFailedException("lock held by other");
        }
        return new RedissonLock(key, uuid, redisTemplate);
        
    }
    
    
    private static class RedissonLock extends Lock {
        
        private final String key;
        
        boolean closed;
        
        private final String uuid;
        
        private RedisTemplate redisTemplate;
        
        RedissonLock(String key, String uuid, RedisTemplate redisTemplate) {
            this.key = key;
            this.uuid = uuid;
            this.redisTemplate = redisTemplate;
        }
        
        @Override
        public void close() {
            Object execute = redisTemplate.execute(UN_LOCK_NOW, Collections.singletonList(key), 300, uuid);
            closed = true;
        }
        
        @Override
        public void ensureValid() {
            if (closed) {
                throw new AlreadyClosedException("Lock instance already released: " + this);
            }
            Object execute = redisTemplate.execute(LOCK, Collections.singletonList(key), 300, uuid);
            if (!Boolean.TRUE.equals(execute)) {
                throw new AlreadyClosedException("Lock instance already released: " + this);
            }
        }
        
        @Override
        public String toString() {
            return "RedissonLock{" + "key='" + key + '\'' + ", uuid='" + uuid + '\'' + '}';
        }
    }
}
