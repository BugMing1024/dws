package com.cloudwise.douc.service.model.logaudit;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 审计日志中英文
 *
 * @author maker.wang
 * @date 2022-04-28 18:30
 **/
@Data
@ApiModel("审计日志中英文")
public class InternalLog implements Serializable {
    private static final long serialVersionUID = -5443449682137157057L;

    @ApiModelProperty("英文文内容")
    private String enContent;

    @ApiModelProperty("中文内容")
    private String content;


}
