package com.cloudwise.douc.service.push;


import java.util.Map;

/**
 * @author Zack.Gao
 * @description
 */
public interface BaseMassagePushInterface<T> {

    /**
     * @param t
     */
    Map<String, String> send(T t);

}
