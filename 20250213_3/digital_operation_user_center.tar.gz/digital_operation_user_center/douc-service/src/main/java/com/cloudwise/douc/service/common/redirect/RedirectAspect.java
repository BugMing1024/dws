package com.cloudwise.douc.service.common.redirect;

import cn.hutool.core.util.StrUtil;
import com.cloudwise.douc.common.IBaseExceptionCode;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.config.I18nMessages;
import com.cloudwise.douc.commons.model.BaseException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;

/**
 * 重定向的协助注解
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024/2/6 0:13; update at 2024/2/6 0:13
 */
@Aspect
@Component
@Slf4j
public class RedirectAspect {
    
    //切入点设置设置注解
    @Pointcut("@annotation(com.cloudwise.douc.service.common.redirect.Redirect)")
    public void point() {
    
    }
    
    
    @Around("point()")
    public Object around(ProceedingJoinPoint p) throws Throwable {
        log.debug("RedirectAspect start");
        String url = ((MethodSignature) p.getSignature()).getMethod().getAnnotation(Redirect.class).url();
        String param = ((MethodSignature) p.getSignature()).getMethod().getAnnotation(Redirect.class).param();
        HttpServletResponse httpServletResponse = null;
        String redirectUrl = null;
        try {
            httpServletResponse = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
            
            Object proceed = p.proceed();
            if (!(proceed instanceof String)) {
                log.debug("RedirectAspect success");
                return proceed;
            }
        } catch (BaseException baseException) {
            log.error("RedirectAspect baseException:", baseException);
            redirectUrl = ConfigUtils.getString("routerPrefix") + url + "?" + param + "=" + I18nMessages.getMsg(
                    baseException);
        } catch (Throwable throwable) {
            log.error("RedirectAspect throwable:", throwable);
            redirectUrl = ConfigUtils.getString("routerPrefix") + url + "?" + param + "=" + I18nMessages.getMsg(
                    IBaseExceptionCode.SYSTEM_ERROR);
        }
        if (httpServletResponse != null && StrUtil.isBlank(redirectUrl)) {
            httpServletResponse.setStatus(HttpStatus.FOUND.value());
            httpServletResponse.setHeader(HttpHeaders.LOCATION, redirectUrl);
        }
        return null;
    }
    
}
