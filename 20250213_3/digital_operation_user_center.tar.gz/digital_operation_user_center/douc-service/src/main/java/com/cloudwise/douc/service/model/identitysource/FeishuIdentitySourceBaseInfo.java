package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zhangmengyang
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeishuIdentitySourceBaseInfo {

    @ApiModelProperty(value = "企业id")
    @NotBlank(message = IBaseExceptionCode.FEISHU_CORPID_NOT_EXIST)
    private String corpId;
    @ApiModelProperty(value = "应用ID")
    @NotBlank(message = IBaseExceptionCode.FEISHU_APP_ID_NOT_EXIST)
    @JsonProperty(value = "appKey")
    private String appKey;
    @ApiModelProperty(value = "应用密钥")
    @NotBlank(message = IBaseExceptionCode.FEISHU_APP_SECRET_NOT_EXIST)
    private String appSecret;
    @ApiModelProperty(value = "同步节点id")
    @NotBlank(message = IBaseExceptionCode.WECOM_SYNCNODEID_NOT_EXIST)
    private String syncNodeId;
    @ApiModelProperty(value = "事件订阅url")
    private String callBackUrl;
    @ApiModelProperty(value = "企业回调token")
    private String callBackToken;
    @ApiModelProperty(value = "企业回调encryptKey")
    @JsonProperty(value = "callBackKey")
    private String callBackKey;
}
