package com.cloudwise.douc.service.sms.constant;


/**
 * 发送验证码场景
 *
 * @author maker.wang
 * @date 2022-02-23 18:39
 **/
public enum VerificationCodeActionTypeEnum {
    DOUBLEFACTORLOGIN("doubleFactorLogin");

    public final String type;

    VerificationCodeActionTypeEnum(String type) {
        this.type = type;
    }

    public static VerificationCodeActionTypeEnum fromString(String type) {
        for (VerificationCodeActionTypeEnum e : VerificationCodeActionTypeEnum.values()) {
            if (e.type.equalsIgnoreCase(type)) {
                return e;
            }
        }
        return VerificationCodeActionTypeEnum.DOUBLEFACTORLOGIN;
    }

    public String getType() {
        return type;
    }

}
