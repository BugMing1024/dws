package com.cloudwise.douc.service.model.multi.email;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 邮件信息
 *
 * @author maker.wang
 * @date 2021-07-15 10:28
 **/
@Data
public class BatchMsgInfoBo implements Serializable {
    private static final long serialVersionUID = 322362101929331878L;

    /**
     * 消息主题
     **/
    @NotBlank(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_SUBJECT_NULL)
    private String msgTitle;

    /**
     * 消息内容
     **/
    @NotBlank(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_CONTENT_NULL)
    private String msgContent;

    /**
     * 接收人邮箱列表
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_RECEIVE_EMAIL_NULL)
    private String[] receiveEmailList;

    /**
     * 发送人用户id
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_SEND_USER_NULL)
    private Long sendUserId;

    /**
     * 发送人租户id
     **/
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_EMAIL_SEND_ACCOUNT_NULL)
    private Long sendAccountId;

}
