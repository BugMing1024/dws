package com.cloudwise.douc.service.model.app;

import com.cloudwise.douc.service.model.apimanage.ApiDetailVo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Description: 应用和API信息
 * date: 2021/8/20 19:45
 *
 * @author damon.fu
 */
@Data
public class AppAndApiInfoVo implements Serializable {
    private Long id;
    private long accountId;
    private String appKey;
    private String appSecret;
    private String appName;
    private String accessParams;
    private int status;
    private String token;
    private String rule;
    private int authType;
    private Integer isDeleted;
    private List<ApiDetailVo> apiInfoList;
}
