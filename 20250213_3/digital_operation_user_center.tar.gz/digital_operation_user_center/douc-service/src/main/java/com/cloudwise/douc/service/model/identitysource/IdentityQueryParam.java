package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author bernie.wang
 * @description:
 * @date Created in 4:07 下午 2022/4/13.
 */
@Data
public class IdentityQueryParam implements Serializable {
    @NotNull
    private Long id;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_DATATYPE_NOT_NULL)
    private Integer type;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_DATATYPE_NOT_NULL)
    private Integer identityType;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
