package com.cloudwise.douc.service.model.wecom;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComExtar implements Serializable {

    private String name;

    private String value;

}
