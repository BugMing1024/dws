package com.cloudwise.douc.service.model.app;

import lombok.Data;

import java.io.Serializable;

/**
 * Description: 查询应用和API信息请求实体
 * date: 2021/8/20 18:45
 *
 * @author damon.fu
 */
@Data
public class AppAndApiRpcRequest implements Serializable {
    /**
     * 租户id
     */
    private String accountId;
    /**
     * 应用公钥
     */
    private String appKey;
    /**
     * 应用私钥
     */
    private String appSecret;
}
