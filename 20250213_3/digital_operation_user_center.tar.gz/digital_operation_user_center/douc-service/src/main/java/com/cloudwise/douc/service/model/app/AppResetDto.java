package com.cloudwise.douc.service.model.app;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/17/2:22 下午
 * @Description:
 */
@Getter
@Setter
public class AppResetDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long appId;

}
