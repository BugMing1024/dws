package com.cloudwise.douc.service.util;

import com.cloudwise.douc.commons.config.I18nMessages;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import com.cloudwise.douc.metadata.model.dicdata.DicDataInfo;

/**
 * @author zhangmengyang
 */
public class LanguageUtil {
    
    /**
     * 获取字典多语言展示
     *
     * @param language
     * @param dicDataInfo
     * @return
     */
    public static String getDicMultiLanguageName(String language, DicDataInfo dicDataInfo) {
        if (dicDataInfo == null) {
            return " ";
        }
        if (I18nMessages.defaultLanguage().equals(language) || !dicDataInfo.isDefault()) {
            return dicDataInfo.getName();
        } else {
            String dicName = I18nMessages.getMsg(language, I18nMessages.DIC_DATA + dicDataInfo.getCode());
            return dicName == null || dicName.startsWith(I18nMessages.DIC_DATA) ? dicDataInfo.getName() : dicName;
        }
    }
    
    /**
     * 获取字典多语言展示
     *
     * @param dicDataInfo
     * @return
     */
    public static String getDicMultiLanguageName(DicDataInfo dicDataInfo) {
        String language = ThreadLocalUtil.getLanguage();
        return getDicMultiLanguageName(language, dicDataInfo);
    }
    
}
