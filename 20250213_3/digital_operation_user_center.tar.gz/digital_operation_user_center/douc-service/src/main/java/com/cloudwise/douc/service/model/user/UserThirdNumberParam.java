package com.cloudwise.douc.service.model.user;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author leakey.li
 * @description:
 * @date Created in 4:24 下午 2022/7/14.
 */
@Data
public class UserThirdNumberParam {
    private Long accountId;
    private Long userId;

    /**
     * 账号类型
     */
    @ApiModelProperty(value = "1：企业微信账号，2：钉钉账号")

    private Long thirdType;

    /**
     * 第三方账号
     */
    @ApiModelProperty(value = "第三方账号")
    private String thirdNumber;
    /**
     * 第三方账号List
     */
    @ApiModelProperty(value = "第三方账号List")
    private List<String> thirdNumberList;
}
