package com.cloudwise.douc.service.model.role;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 角色配置组织机构 回显响应
 *
 * @author maker.wang
 * @date 2022-03-10 09:40
 **/
@Data
@ApiModel("角色配置组织机构 回显响应")
public class RoleSetDepartmentTreeListVO implements Serializable {
    private static final long serialVersionUID = 5843058342985432909L;

    @ApiModelProperty("部门id")
    private Long id;

    @ApiModelProperty("上级部门id")
    private Long parentId;

    @ApiModelProperty("部门名称")
    private String name;

    @ApiModelProperty("部门是否选中 true:选中 false没勾")
    private Boolean selected;

    @ApiModelProperty("是否有下级 true没有 false有")
    private Boolean ifChildren;

    @ApiModelProperty("下级部门集合")
    private List<RoleSetDepartmentTreeListVO> childrenList;

}
