package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DingDingIdentitySourceBaseInfo {

    @ApiModelProperty(value = "企业id")
    @NotBlank(message = IBaseExceptionCode.DINGDING_CORPID_NOT_EXIST)
    private String corpId;
    @ApiModelProperty(value = "应用Key")
    @NotBlank(message = IBaseExceptionCode.DINGDING_APP_KEY_NOT_EXIST)
    @JsonProperty(value = "appKey")
    private String appKey;
    @ApiModelProperty(value = "应用密钥")
    @NotBlank(message = IBaseExceptionCode.DINGDING_APP_SECRET_NOT_EXIST)
    private String appSecret;
    @ApiModelProperty(value = "同步节点id")
    @NotBlank(message = IBaseExceptionCode.WECOM_SYNCNODEID_NOT_EXIST)
    private String syncNodeId;
    @ApiModelProperty(value = "企业回调url")
    private String callBackUrl;
    @ApiModelProperty(value = "企业回调token")
    @JsonProperty(value = "callBackToken")
    private String callBackToken;
    @ApiModelProperty(value = "企业回调EncodingAESKey")
    @JsonProperty(value = "callBackKey")
    private String callBackKey;
}
