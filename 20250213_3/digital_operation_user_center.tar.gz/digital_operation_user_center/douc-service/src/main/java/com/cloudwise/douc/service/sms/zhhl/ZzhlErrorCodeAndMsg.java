package com.cloudwise.douc.service.sms.zhhl;

import java.util.HashMap;
import java.util.Map;

public enum ZzhlErrorCodeAndMsg {

    MULTIMOBILESUCCESS("00", "多个手机号请求发送成功"),
    IPERROR("02", "IP限制"),
    SINGLEMOBILESUCCESS("03", "单个手机号请求发送成功"),
    USERNAMEERROR("04", "用户名错误"),
    PASSWORDERROR("05", "密码错误"),
    CODINGERROR("06", "编码错误"),
    PARAMERROR("08", "参数错误"),
    MOBILEERROR("09", "手机号有误"),
    EXTARMOBILEERROR("10", "扩展号码有误"),
    LACKBALANCE("11", "余额不足"),
    ERROR("-1", "服务器内部异常");


    private static Map<String, String> map = new HashMap();

    static {
        map.put(MULTIMOBILESUCCESS.getCode(), MULTIMOBILESUCCESS.getMsg());
        map.put(IPERROR.getCode(), IPERROR.getMsg());
        map.put(SINGLEMOBILESUCCESS.getCode(), SINGLEMOBILESUCCESS.getMsg());
        map.put(USERNAMEERROR.getCode(), USERNAMEERROR.getMsg());
        map.put(PASSWORDERROR.getCode(), PASSWORDERROR.getMsg());
        map.put(CODINGERROR.getCode(), CODINGERROR.getMsg());
        map.put(PARAMERROR.getCode(), PARAMERROR.getMsg());
        map.put(MOBILEERROR.getCode(), MOBILEERROR.getMsg());
        map.put(EXTARMOBILEERROR.getCode(), EXTARMOBILEERROR.getMsg());
        map.put(LACKBALANCE.getCode(), LACKBALANCE.getMsg());
        map.put(ERROR.getCode(), ERROR.getMsg());
    }

    private String code;
    private String msg;


    ZzhlErrorCodeAndMsg(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static String getMsgByCode(String code) {
        return map.get(code);
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
