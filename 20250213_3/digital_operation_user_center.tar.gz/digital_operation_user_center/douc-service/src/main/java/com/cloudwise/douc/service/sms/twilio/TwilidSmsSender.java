package com.cloudwise.douc.service.sms.twilio;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.model.ResultEntity;
import com.cloudwise.douc.service.sms.ISmsSender;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2021/8/6
 */
@Slf4j
@Component
@Configuration
@RefreshScope
public class TwilidSmsSender implements ISmsSender {

    @Value("${channel.sms.twilid.accountSid:AC6488a8b5b63e2aa59897c9340b058e5c}")
    private String accountSid;

    @Value("${channel.sms.twilid.authToken:fcd08c564b7716c8ce5f2c3d2d4b8b39}")
    private String authToken;

    @Value("${channel.sms.twilid.phoneNumber:+17812096690}")
    private String phoneNumber;

    @Override
    public String getId() {
        return "twilio";
    }

    @Override
    public ResultEntity sendMsg(String code, String phone, String content) {
        Message message = null;
        ResultEntity resultEntity = new ResultEntity();
        try {
            //初始化
            Twilio.init(accountSid, authToken);
            message = Message.creator(
                    //接收短信的手机号码
                    new PhoneNumber(phone),
                    //Twilio分配给你的手机号码
                    new PhoneNumber(phoneNumber),
                    //短信内容
                    content).create();
            resultEntity.setCode(IBaseExceptionCode.SUCCESS);
            resultEntity.setMsg(message.getSid());
            return resultEntity;
        } catch (Exception e) {
            log.error("Twilio发送短信异常 resultEntity:{}, message:{}", resultEntity, message, e);
            resultEntity.setCode(IBaseExceptionCode.SYSTEM_ERROR);
            resultEntity.setMsg("Twilio send message error: " + e.getMessage());
            return resultEntity;
        }
    }

    @Override
    public String getTemplateCode(Map<String, Object> map) {
        return null;
    }

    public static void main(String[] args) {
        Twilio.init("AC6488a8b5b63e2aa59897c9340b058e5c", "fcd08c564b7716c8ce5f2c3d2d4b8b39");
        Message message = Message.creator(
                //接收短信的手机号码
                new PhoneNumber("+8618511505010"),
                //Twilio分配给你的手机号码
                new PhoneNumber("+17812096690"),
                //短信内容
                "测试内容！abc-123456").create();
        log.info("{}", message);
    }
}
