package com.cloudwise.douc.service.component;

import cn.hutool.json.JSONUtil;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.dto.common.ActionNotice;
import com.cloudwise.douc.dto.common.ActionNoticeTypeEnum;
import com.cloudwise.douc.service.service.IDomainUserVisibleService;
import com.cloudwise.douc.service.service.IMenuService;
import com.cloudwise.douc.service.service.IProfessionUserService;
import com.cloudwise.douc.service.service.IUserGroupRelationService;
import com.cloudwise.douc.service.service.IUserRoleRelationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * douc自己的消息处理分发器
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2023/10/15 0:40; update at 2023/10/15 0:40
 */
@Component
@Slf4j
public class ActionNoticeHandler {
    
    @Resource
    private IDomainUserVisibleService domainUserVisibleService;
    
    @Resource
    private IUserGroupRelationService userGroupRelationService;
    
    @Resource
    private IUserRoleRelationService userRoleRelationService;
    
    @Resource
    private IProfessionUserService professionUserService;
    
    @Resource
    private IMenuService menuService;
    
    public void handle(ActionNotice actionNotice) {
        ActionNoticeTypeEnum action = actionNotice.getActionNoticeTypeEnum();
        Object actionData = actionNotice.getData();
        
        log.info("异步任务同步数据，accountId:{}, ActionData：{}，ActionType：{}", actionNotice.getAccountId(), actionData, action);
        try {
            switch (action) {
                case DELETE_ACCOUNT:
                    userRoleRelationService.roleAccountDeleteJob(actionNotice);
                    break;
                case CREATE_DOMAIN:
                case UPDATE_DOMAIN:
                case UPDATE_DOMAIN_LEVEL:
                    domainUserVisibleService.syncUserVisibleByDomain((Long) actionData, action);
                    break;
                case PAUSE_DOMAIN:
                case RESTART_DOMAIN:
                case DELETE_DOMAIN:
                    break;
                case DELETE_DOMAIN_VISIBLE_CONFIG:
                case CREATE_DOMAIN_VISIBLE_CONFIG:
                case UPDATE_DOMAIN_VISIBLE_CONFIG:
                    domainUserVisibleService.syncUserVisibleByConfig(JSONUtil.toList(actionData.toString(), Long.class), action);
                    break;
                case ADD_RESTRICT_DOMAIN_CONFIG:
                case DELETE_RESTRICT_DOMAIN_CONFIG:
                    domainUserVisibleService.syncUserRestrictByConfig((List<Long>) actionData, action);
                    break;
                case ADD_USER:
                    professionUserService.simpelUpdateLicUser(ConfigUtils.getString("tag.subscribe"));
                    userGroupRelationService.addUserJob(actionNotice, true);
                    break;
                case UPDATE_USER:
                    userGroupRelationService.userChangeJob(actionNotice);
                    break;
                case DELETE_USER:
                    professionUserService.simpelUpdateLicUser(ConfigUtils.getString("tag.subscribe"));
                    userGroupRelationService.deleteUserJob(actionNotice);
                    break;
                case USER_CUSTOM_GROUP_CHANGE:
                    userGroupRelationService.userCustomGroupChangeJob(actionNotice);
                    break;
                case BATCH_ADD_USER:
                    userGroupRelationService.batchAddUserJob(actionNotice);
                    break;
                case ROLE_USER_MODIFY:
                    userRoleRelationService.roleUserChangeJob(actionNotice);
                    break;
                case ROLE_DEPT_MODIFY:
                    userRoleRelationService.roleDeptChangeJob(actionNotice);
                    break;
                case ROLE_GROUP_MODIFY:
                    userRoleRelationService.roleGroupChangeJob(actionNotice);
                    break;
                case ROLE_DELETE:
                    userRoleRelationService.roleDeleteJob(actionNotice);
                    break;
                case GROUP_USER_MODIFY:
                    userGroupRelationService.groupUserChangeJob(actionNotice);
                    break;
                case GROUP_DEPT_MODIFY:
                    userGroupRelationService.groupDeptChangeJob(actionNotice);
                    break;
                case GROUP_POSITION_MODIFY:
                    userGroupRelationService.groupPositionChangeJob(actionNotice);
                    break;
                case GROUP_CUSTOM_MODIFY:
                    userGroupRelationService.groupCustomChangeJob(actionNotice);
                    break;
                case GROUP_ROLE_MODIFY:
                    userGroupRelationService.groupRoleChangeJob(actionNotice);
                    break;
                case GROUP_DELETE:
                    userGroupRelationService.groupDeleteJob(actionNotice);
                    break;
                case USER_STATUS_CHANGE:
                    log.info("用户状态变更 {}", action);
                    break;
                case DEPT_LEVEL_MODIFY:
                    userGroupRelationService.deptLevelChangeJob(actionNotice);
                    break;
                case UPDATE_LIC:
                    menuService.updateProfessionUser();
                    break;
                case UNKNOWN:
                default:
                    log.info("不支持的操作类型{}", action);
            }
        } catch (Throwable e) {
            log.error("异步任务同步数据失败，ActionData：{}，ActionType：{}", actionData, action, e);
        }
    }
    
}
