package com.cloudwise.douc.service.common;

/**
 * 自定义Topic记录
 *
 * @author maker.wang
 * @date 2021-11-16 14:11
 **/
public class RocketMqTopicRecord {

    /**
     * 同步登录日志
     **/

    public static final String LOGIN_LOG = "DOUC_%s_LOGIN_LOG";

    /**
     * 同步系统操作日志
     **/
    public static final String SYSTEM_OPERATE_LOG = "DOUC_%s_SYSTEM_OPERATE_LOG";

    /**
     * 同步企业微信待开发授权信息
     **/
    public static final String WE_COM_AUTH_INFO = "DOUC_WE_COM_AUTH_INFO";


}
