package com.cloudwise.douc.service.model.wecom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 企业微信响应对象
 *
 * @author maker.wang
 * @date 2022-01-08 11:19
 **/
@Data
@ApiModel("企业微信响应对象")
public class WeComAccessTokenResp implements Serializable {
    private static final long serialVersionUID = 7493299142130090516L;

    @ApiModelProperty("出错返回码，为0表示成功，非0表示调用失败")
    private int errcode;

    @ApiModelProperty("返回码提示语")
    private String errmsg;

    // CHECKSTYLE:OFF
    @ApiModelProperty("获取到的凭证，最长为512字节")
    private String access_token;

    @ApiModelProperty("凭证的有效时间（秒）")
    private String expires_in;
    // CHECKSTYLE:ON

    public boolean checkRequestResult() {
        return 0 == this.errcode;
    }
}
