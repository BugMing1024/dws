package com.cloudwise.douc.service.model.app;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Map;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/17/2:07 下午
 * @Description:
 */

@Data
public class AppDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = IBaseExceptionCode.APP_NAME_NOT_NULL)
    @Length(max = 100, message = IBaseExceptionCode.APP_NAME_ERROR)
    private String appName;
    private Integer hasRule;
    private String rule;
    @Length(max = 500, message = IBaseExceptionCode.APP_DESCRIPTION_ERROR)
    private String description;
    private Map<String, String> accessParams;
    private String appId;
    private Integer authType;

}
