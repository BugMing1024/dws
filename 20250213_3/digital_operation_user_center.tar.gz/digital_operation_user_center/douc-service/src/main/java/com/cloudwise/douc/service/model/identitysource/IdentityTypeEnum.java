package com.cloudwise.douc.service.model.identitysource;


/**
 * @author zhangmengyang
 */

public enum IdentityTypeEnum {

    /**
     * 企业微信
     */
    wecom(1),
    /**
     * 钉钉
     */
    dingding(2),
    /**
     * 飞书
     */
    feishu(3);

    private int code;

    IdentityTypeEnum(int code) {
        this.code = code;
    }

    public int getCode() {
        return this.code;
    }

    public static IdentityTypeEnum codeOf(int code) {
        for (IdentityTypeEnum value : IdentityTypeEnum.values()) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }
}
