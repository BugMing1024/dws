package com.cloudwise.douc.service.model.multi.tenant;

import com.google.common.collect.Lists;
import lombok.Data;

import java.util.List;

/**
 * @author ken.liang
 * @description:用户可进入子租户
 * @date Created in 2:04 PM 2021/7/20.
 */
@Data
public class UserEnableChildAccountInfoVO {

    /**
     * 租户ID
     */
    private Long id;


    /**
     * 租户名称
     */
    private String name;


    /**
     * 是否当前租户
     */
    private Boolean ifSelect = Boolean.FALSE;

    /**
     * 子租户信息
     */
    private List<UserEnableChildAccountInfoVO> children = Lists.newArrayList();


}
