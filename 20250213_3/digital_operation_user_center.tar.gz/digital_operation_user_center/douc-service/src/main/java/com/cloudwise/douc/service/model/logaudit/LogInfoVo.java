package com.cloudwise.douc.service.model.logaudit;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class LogInfoVo implements Serializable {
    private static final long serialVersionUID = 2105197180627946268L;

    /**
     * 用户名
     */
    private String userName;
    /**
     * 姓名
     */
    private String name;
    /**
     * 操作系统
     */
    private String osName;
    /**
     * 操作人所属部门--顶级/.../部门
     */
    private String department;
    /**
     * 登录者ip
     */
    private String userIp;
    /**
     * 登录状态
     */
    private boolean result;
    /**
     * 描述
     */
    private String description;
    /**
     * 登录时间
     */
    private Long timestamp;
    /**
     * 日志类型
     */
    private int logType;
    /**
     * 用户id
     */
    private long userId;

    @ApiModelProperty(value = "日志内容")
    private String content;

    @ApiModelProperty(value = "英文日志内容")
    private String enContent;
}
