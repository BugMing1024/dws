package com.cloudwise.douc.service.util;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.format.FastDateFormat;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.service.model.logaudit.TimeTrame;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.TimeZone;

/**
 * @author elsa.yang
 * @date 2020/6/11 10:57 上午
 */
@Slf4j
public class DateUtil {

    /**
     * 一秒
     */
    public static final long ONE_SECOND = 1000L;
    /**
     * 一分钟
     */
    public static final long ONE_MINUTE = ONE_SECOND * 60;
    /**
     * 一小时
     */
    public static final long ONE_HOUR = ONE_MINUTE * 60;
    /**
     * 一天
     */
    public static final long ONE_DAY = ONE_HOUR * 24;
    /**
     * 一周
     */
    public static final long ONE_WEEK = ONE_DAY * 7;
    /**
     * 一个月
     */
    public static final long ONE_MONTH = ONE_DAY * 30;

    /**
     * 一年
     */
    public static final long ONE_YEAR = ONE_MONTH * 12;

    private static final DateTimeFormatter FTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static String convertTimeToString(Long time) {
        return convertTimeToString(time, FTF);
    }

    public static String convertTimeToString(Long time, DateTimeFormatter timeFormatter) {
        if (Optional.ofNullable(time).isPresent()) {
            return timeFormatter.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(time), ZoneId.systemDefault()));
        }
        return "";
    }

    /**
     * 根据时间差获取查询的开始结束时间
     *
     * @param timeRanges
     * @return
     */
    public static TimeTrame getTimeTrame(Long stratTime, String timeRanges) {
        TimeTrame timeTrame = new TimeTrame();
        long timeTifference = timeTifference(timeRanges);
        timeTrame.setEndTime(stratTime);
        timeTrame.setStartTime(stratTime - timeTifference);
        return timeTrame;
    }

    public static Long timeTifference(String timeRanges) {
        long timeTifference = 0L;
        //获取时间差
        if (timeRanges.contains("s")) {
            timeTifference = Long.parseLong(timeRanges.replace("s", "")) * ONE_SECOND;
        } else if (timeRanges.contains("min")) {
            timeTifference = Long.parseLong(timeRanges.replace("min", "")) * ONE_MINUTE;
        } else if (timeRanges.contains("h")) {
            timeTifference = Long.parseLong(timeRanges.replace("h", "")) * ONE_HOUR;
        } else if (timeRanges.contains("d")) {
            timeTifference = Long.parseLong(timeRanges.replace("d", "")) * ONE_DAY;
        } else if (timeRanges.contains("week")) {
            timeTifference = Long.parseLong(timeRanges.replace("week", "")) * ONE_WEEK;
        } else if (timeRanges.contains("mon")) {
            timeTifference = Long.parseLong(timeRanges.replace("mon", "")) * ONE_MONTH;
        } else if (timeRanges.contains("year")) {
            timeTifference = Long.parseLong(timeRanges.replace("year", "")) * ONE_YEAR;
        }

        return timeTifference;
    }

    /**
     * String to Date
     *
     * @param date
     * @param dateFormate
     * @param timeZone
     * @return
     */
    public static Date parseStringToDateByTimeZone(String date, String dateFormate, String timeZone) {
        if (StringUtils.isEmpty(dateFormate)) {
            dateFormate = DatePattern.NORM_DATETIME_PATTERN;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormate); //注意月份是MM
        if (StringUtils.isNotEmpty(timeZone)) {
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
        }

        Date dateResult = null;
        try {
            dateResult = simpleDateFormat.parse(date);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }

        if (StringUtils.isNotEmpty(timeZone) && "GMT-8".equals(timeZone)) {
            dateResult = makeResultDate(dateResult, -1);
        }
        return dateResult;
    }

    public static Date makeResultDate(Date dateResult, int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateResult);
        calendar.add(Calendar.DATE, i);
        dateResult = calendar.getTime();
        return dateResult;
    }

    /**
     * 将字符串时间戳转化为String日期
     *
     * @param timestamp
     * @param dateFormate
     * @return
     */
    public static String parseTimestampToDateStr(String timestamp, String dateFormate) {
        if (StringUtils.isEmpty(dateFormate)) {
            dateFormate = DatePattern.NORM_DATETIME_PATTERN;
        }
        Long time = null;
        if (StringUtils.isEmpty(timestamp)) {
            return "";
        } else {
            time = Long.valueOf(timestamp);
        }
        Date d = new Date(time);
        FastDateFormat instance = FastDateFormat.getInstance(dateFormate);
        return instance.format(d);
    }


    /**
     * @param startDate 起始日期 Date类型
     * @param endDate   终止日期 Date类型
     * @return Long 天数差
     * @description 计算终止日期与起始日期的天数差值
     * @author brady.liu
     * @date 2021/7/16
     * @time 16:35
     */
    public static long daysOfDateDifference(Date startDate, Date endDate) {
        long endTime = endDate.getTime();
        long startTime = startDate.getTime();
        // 如果终止日期小于起始日期弹出异常
        if (endTime < startTime) {
            throw new BaseException(IBaseExceptionCode.END_DATE_LESS_THAN_START_DATE);
        }
        return (endDate.getTime() - startDate.getTime()) / 86400000;
    }

    public static Date getNowDate() {
        return new Date();
    }

}
