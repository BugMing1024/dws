package com.cloudwise.douc.service.configuration;

import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import com.cloudwise.douc.service.util.Constant;
import com.cloudwise.douc.service.util.RequestUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author myron
 * @ClassName : RemoteAddrFilter
 * @Description :
 * @Version 1.0
 */
@Slf4j
@Component
public class RemoteAddrFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        //校验请求request Header中是否有对应值
        try {
            String realIP = RequestUtil.getRealIP(request);
            HeaderMapRequestWrapper requestWrapper = new HeaderMapRequestWrapper(request);
            if (StringUtils.isNotBlank(realIP)) {
                //如果get请求url中带有这个参数，则request中新增一个header
                requestWrapper.addHeader(Constant.REQUEST_BASE_HEADER_CURRENT_USERIP, realIP);
            }
            log.debug("x-forwarded-for:{}", requestWrapper.getHeader(Constant.REQUEST_BASE_HEADER_CURRENT_USERIP));

            String accountId = request.getHeader(Constant.REQUEST_BASE_HEADER_ACCOUNTID_NAME);
            String topAccountId = request.getHeader(Constant.REQUEST_BASE_HEADER_TOP_ACCOUNT_ID_NAME);
            String userId = request.getHeader(Constant.REQUEST_BASE_HEADER_USERID_NAME);
            String userName = request.getHeader(Constant.REQUEST_BASE_HEADER_USER_NAME);
            String language = StringUtils.defaultIfBlank(request.getHeader(Constant.REQUEST_BASE_HEADER_LANGUAGE_NAME), request.getParameter(Constant.REQUEST_BASE_HEADER_LANGUAGE_NAME));
            ThreadLocalUtil.setAccountId(StringUtils.isBlank(accountId) ? null : NumberUtils.toLong(accountId));
            ThreadLocalUtil.setTopAccountId(StringUtils.isBlank(topAccountId) ? null : NumberUtils.toLong(topAccountId));
            ThreadLocalUtil.setUserId(StringUtils.isBlank(userId) ? null : NumberUtils.toLong(userId));
            ThreadLocalUtil.setUserName(userName);
            ThreadLocalUtil.setLanguage(language);
            ThreadLocalUtil.setUserIp(realIP);
            // Goes to default servlet.
            filterChain.doFilter(requestWrapper, response);
        } finally {
            // 清空线程变量
            ThreadLocalUtil.remove();
        }
    }

}
