package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.BaseEntity;
import lombok.Getter;
import lombok.Setter;

/**
 * @author barney.song
 * Description: No Description
 */
@Getter
@Setter
public class RoleMenuRelation extends BaseEntity {
    private static final long serialVersionUID = -1929228467426657661L;
    private Long accountId;
    private Long userId;
    private String moduleCode;
    private String menuCode;

    public RoleMenuRelation() {
    }

    public RoleMenuRelation(Long accountId, Long userId, String moduleCode) {
        this.accountId = accountId;
        this.userId = userId;
        this.moduleCode = moduleCode;
    }
}
