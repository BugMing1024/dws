package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 获取同步记录入参实体
 *
 * @author maker.wang
 * @date 2022-04-18 14:11
 **/
@Data
@ApiModel("获取同步记录入参实体")
public class IdentitySourceSyncRecordBO implements Serializable {
    private static final long serialVersionUID = -5006413922827232725L;

    public IdentitySourceSyncRecordBO() {
        this.current = 1;
        this.size = 10;
        this.id = 0L;
        this.dataSyncType = 1;
    }

    @ApiModelProperty(value = "身份源ID", required = true)
    @NotNull(message = IBaseExceptionCode.IDENTITY_SOURCE_IDENTITY_ID_NULL)
    private Long id;

    @ApiModelProperty("数据同步类型 1:手动执行 2 定时同步 ")
    @NotNull(message = IBaseExceptionCode.IDENTITY_SOURCE_SYNC_TYPE_NULL)
    private Integer dataSyncType;

    @ApiModelProperty(value = "当前页 默认1", required = true)
    private Integer current;

    @ApiModelProperty(value = "每页条数 默认10条", required = true)
    private Integer size;

    @ApiModelProperty(value = "国际化")
    private String language;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
