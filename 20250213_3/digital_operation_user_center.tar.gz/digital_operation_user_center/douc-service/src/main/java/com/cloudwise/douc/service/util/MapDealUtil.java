package com.cloudwise.douc.service.util;

import com.google.common.collect.Lists;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public class MapDealUtil {

    public static <F, T> void fillMap(Map<F, List<T>> catchMap, T indi, F module) {
        List<T> modelValue = catchMap.get(module);
        if (Objects.nonNull(modelValue)) {
            List<T> tsbList = modelValue;
            tsbList.add(indi);
        } else {
            List<T> tsbList = Lists.newArrayList();
            tsbList.add(indi);
            catchMap.put(module, tsbList);
        }
    }

}
