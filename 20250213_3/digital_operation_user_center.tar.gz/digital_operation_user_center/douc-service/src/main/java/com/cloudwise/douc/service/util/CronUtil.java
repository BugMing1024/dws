package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.constant.StrConstant;
import com.cloudwise.douc.service.model.CronExpressionModel;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Bernie
 * @date 2021-01-06 10:56
 */
@Slf4j
public class CronUtil {

    public static String createCronExpression(CronExpressionModel cronExpressionModel) {

        StringBuilder cronExp = new StringBuilder();
        if (null == cronExpressionModel.getJobType()) {
            log.error("Task execution cycle is not set for cron generation!");
        }

        //每隔几秒
        if (cronExpressionModel.getJobType() == 0) {
            cronExp.append("0/").append(cronExpressionModel.getSecond()).append(StrPool.C_SPACE);
            cronExp.append("* ");
            cronExp.append("* ");
            cronExp.append("* ");
            cronExp.append("* ");
            cronExp.append(StrConstant.C_DOUBT);
        } else

            //每隔几分钟
            if (cronExpressionModel.getJobType() == 1) {
                cronExp.append(cronExpressionModel.getSecond()).append(StrPool.C_SPACE);
                cronExp.append("0/").append(cronExpressionModel.getMinute()).append(StrPool.C_SPACE);
                cronExp.append("* ");
                cronExp.append("* ");
                cronExp.append("* ");
                cronExp.append(StrConstant.C_DOUBT);
            } else

                //每隔几小时
                if (cronExpressionModel.getJobType() == 2) {
                    cronExp.append(cronExpressionModel.getSecond()).append(StrPool.C_SPACE);
                    cronExp.append(cronExpressionModel.getMinute()).append(StrPool.C_SPACE);
                    cronExp.append("0/").append(cronExpressionModel.getHour()).append(StrPool.C_SPACE);
                    cronExp.append("* ");
                    cronExp.append("* ");
                    cronExp.append(StrConstant.C_DOUBT);
                } else

                    //每天
                    if (cronExpressionModel.getJobType() == 3) {
                        cronExp.append(cronExpressionModel.getSecond()).append(StrPool.C_SPACE);
                        cronExp.append(cronExpressionModel.getMinute()).append(StrPool.C_SPACE);
                        cronExp.append(cronExpressionModel.getHour()).append(StrPool.C_SPACE);
                        cronExp.append("1/").append(cronExpressionModel.getDay()).append(StrPool.C_SPACE);
                        cronExp.append("* "); //月
                        cronExp.append(StrConstant.C_DOUBT); //周
                    }
        return cronExp.toString();
    }

    //ldap 按照分钟，小时，天周期指定同步
    public static String parseLdapTimer(String timeStr) {
        List<Integer> dateArray = Arrays.asList(timeStr.split(StrPool.COMMA)).stream()
                        .map(x -> Integer.valueOf(x.substring(0, x.length() - 1))).collect(Collectors.toList());

        CronExpressionModel cronExpressionModel = new CronExpressionModel();

        if (dateArray.get(0) > 0) {
            cronExpressionModel.setJobType(3);
        } else if (dateArray.get(1) > 0) {
            cronExpressionModel.setJobType(2);
        } else {
            cronExpressionModel.setJobType(1);
        }

        cronExpressionModel.setDay(dateArray.get(0));
        cronExpressionModel.setHour(dateArray.get(1));
        cronExpressionModel.setMinute(dateArray.get(2));
        cronExpressionModel.setSecond(0);

        return CronUtil.createCronExpression(cronExpressionModel);
    }
}
