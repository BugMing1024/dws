package com.cloudwise.douc.service.model.mq;

import lombok.Data;

import java.io.Serializable;

/**
 * mq消息体
 *
 * @author maker.wang
 * @date 2021-09-22 16:26
 **/
@Data
public class MqBasicData<T> implements Serializable {
    private static final long serialVersionUID = -6058105572214069401L;

    /**
     * mq消息类型
     **/
    private String type;

    /**
     * 发送时间戳
     **/
    private Long sendTime;

    /**
     * mq消息body
     **/
    private T data;

}
