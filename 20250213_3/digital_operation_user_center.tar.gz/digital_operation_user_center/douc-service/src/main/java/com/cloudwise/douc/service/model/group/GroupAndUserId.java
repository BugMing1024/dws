package com.cloudwise.douc.service.model.group;

import lombok.Data;

import java.util.List;


@Data
public class GroupAndUserId {

    private Long id;
    private Long userId;
    private Long accountId;
    private List<Long> userIdList;
    private List<String> userAliasList;
    private String code;

}
