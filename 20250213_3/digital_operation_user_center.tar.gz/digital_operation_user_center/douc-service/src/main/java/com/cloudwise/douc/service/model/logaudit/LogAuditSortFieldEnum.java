package com.cloudwise.douc.service.model.logaudit;

/**
 * 日志审计排序字段
 *
 * @author KenLiang
 * @date 2021/4/29 3:58 PM
 */
public enum LogAuditSortFieldEnum {

    /**
     * 操作时间
     */
    TIMESTAMP("timestamp", "timestamp"),
    /**
     * 操作类型
     */
    OPERATE_TYPE("operateType", "operate_type"),
    /**
     * 用户名
     */
    USER_ALIAS("userAlias", "user_name"),

    /**
     * 不排序
     */
    NONE("none", "none");


    private String sortField;
    private String dbFieldName;

    LogAuditSortFieldEnum(String sortField, String dbFieldName) {
        this.sortField = sortField;
        this.dbFieldName = dbFieldName;
    }

    public String getDbFieldName() {

        return this.dbFieldName;

    }

    public static String getDbFieldNameBySortField(String sortField) {
        for (LogAuditSortFieldEnum value : LogAuditSortFieldEnum.values()) {
            if (value.sortField.equalsIgnoreCase(sortField)) {
                return value.dbFieldName;
            }
        }
        return null;
    }

}
