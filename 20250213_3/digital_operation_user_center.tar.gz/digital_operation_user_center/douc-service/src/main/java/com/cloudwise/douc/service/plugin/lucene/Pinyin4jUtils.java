package com.cloudwise.douc.service.plugin.lucene;

import lombok.extern.slf4j.Slf4j;
import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 拼音工具类
 *
 * @author zafir zhong
 * @version 1.0.0
 * @date created at 2022/2/10 5:26 下午 ; update at
 */
@Slf4j
public class Pinyin4jUtils {
    
    
    public static Set<String> pinyinTerm(String chines, int mode, int max) {
        switch (mode) {
            case 1:
                return allMix(chines, max);
            case 3:
                return mode(chines, true, false, max);
            case 4:
                return mode(chines, false, true, max);
            case 2:
            default:
                return mode(chines, true, true, max);
        }
    }
    
    public static Set<String> allMix(String chines, int max) {
        if (chines == null || chines.isEmpty()) {
            return Collections.emptySet();
        }
        log.debug("pinyin check：{}", chines);
        Map<Integer, Set<String>> pinyinMap = new HashMap<>();
        char[] nameChar = chines.toCharArray();
        HanyuPinyinOutputFormat defaultFormat = new HanyuPinyinOutputFormat();
        defaultFormat.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        defaultFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        log.debug("pinyin data length:{}", nameChar.length);
        
        // 整理出所有字的同义词
        for (int i = 0; i < nameChar.length; i++) {
            Set<String> oneOfPinyin = new HashSet<>();
            oneOfPinyin.add(String.valueOf(nameChar[i]));
            try {
                // 取得当前汉字的所有全拼
                String[] strs = PinyinHelper.toHanyuPinyinStringArray(nameChar[i], defaultFormat);
                if (strs != null) {
                    for (String str : strs) {
                        String upperCasePinyin = str.substring(0, 1).toUpperCase() + str.substring(1);
                        oneOfPinyin.add(upperCasePinyin);
                        oneOfPinyin.add(str.substring(0, 1).toUpperCase());
                    }
                    log.debug("pinyin data size :{} for :{}", oneOfPinyin.size(), nameChar[i]);
                }
            } catch (BadHanyuPinyinOutputFormatCombination e) {
                log.error("BadHanyuPinyinOutputFormatCombination", e);
            }
            pinyinMap.put(i, oneOfPinyin);
        }
        int num = 1;
        for (Set<String> value : pinyinMap.values()) {
            num = num * value.size();
        }
        num = Math.min(max + 1, num);
        // 拼接前，拼接后，一开始只有但字符的数据
        Set<String> beforeAdd = new HashSet<>(num);
        Set<String> afterAdd = new HashSet<>(num);
        beforeAdd.addAll(pinyinMap.get(0));
        // 开始符号
        for (int i = 1; i < nameChar.length; i++) {
            Set<String> tmp = beforeAdd;
            Set<String> onePinyin = pinyinMap.get(i);
            for (String f : beforeAdd) {
                for (String l : onePinyin) {
                    afterAdd.add(f + l);
                    if (beforeAdd.size() >= num) {
                        break;
                    }
                }
            }
            beforeAdd = afterAdd;
            afterAdd = tmp;
            afterAdd.clear();
        }
        if (beforeAdd.size() >= num) {
            beforeAdd.add(chines);
        }
        log.info("拼音获取结果共{}个,原始值：{}", beforeAdd.size(), chines);
        return beforeAdd;
    }
    
    public static Set<String> mode(String chines, boolean all, boolean first, int max) {
        if (chines == null || chines.isEmpty()) {
            return Collections.emptySet();
        }
        log.debug("pinyin check：{}", chines);
        Map<Integer, Set<String>> pinyinAllMap = all ? new HashMap<>() : null;
        Map<Integer, Set<String>> pinyinFirstMap = first ? new HashMap<>() : null;
        char[] nameChar = chines.toCharArray();
        HanyuPinyinOutputFormat defaultFormat = new HanyuPinyinOutputFormat();
        defaultFormat.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        defaultFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        log.debug("pinyin data length:{}", nameChar.length);
        // 整理出所有字的同义词
        for (int i = 0; i < nameChar.length; i++) {
            Set<String> oneOfPinyinAll = all ? new HashSet<>() : null;
            Set<String> oneOfPinyinFist = first ? new HashSet<>() : null;
            try {
                // 取得当前汉字的所有全拼
                String[] strs = PinyinHelper.toHanyuPinyinStringArray(nameChar[i], defaultFormat);
                if (strs != null && strs.length > 0) {
                    for (String str : strs) {
                        if (first) {
                            oneOfPinyinFist.add(str.substring(0, 1).toUpperCase());
                        }
                        if (all) {
                            oneOfPinyinAll.add(str.substring(0, 1).toUpperCase() + str.substring(1));
                        }
                    }
                } else {
                    if (first) {
                        oneOfPinyinFist.add(String.valueOf(nameChar[i]));
                    }
                    if (all) {
                        oneOfPinyinAll.add(String.valueOf(nameChar[i]));
                    }
                }
            } catch (BadHanyuPinyinOutputFormatCombination e) {
                log.error("BadHanyuPinyinOutputFormatCombination", e);
            }
            if (first) {
                pinyinFirstMap.put(i, oneOfPinyinFist);
            }
            if (all) {
                pinyinAllMap.put(i, oneOfPinyinAll);
            }
        }
        int num = 1;
        if (first) {
            for (Set<String> value : pinyinFirstMap.values()) {
                num = num * value.size();
            }
        } else if (all) {
            for (Set<String> value : pinyinAllMap.values()) {
                num = num * value.size();
            }
        }
        int size = first && all ? 2 * num + 1 : num + 1;
        size = Math.min(2 * max + 1, size);
        Set<String> result = new HashSet<>(size);
        // 原始的的
        result.add(chines);
        // 拼接前，拼接后，一开始只有但字符的数据
        Set<String> beforeAdd = new HashSet<>(num);
        Set<String> afterAdd = new HashSet<>(num);
        // 全量组合的全拼
        if (all) {
            beforeAdd.addAll(pinyinAllMap.get(0));
            for (int i = 1; i < nameChar.length; i++) {
                Set<String> tmp = beforeAdd;
                Set<String> onePinyin = pinyinAllMap.get(i);
                for (String f : beforeAdd) {
                    for (String l : onePinyin) {
                        afterAdd.add(f + l);
                        if (beforeAdd.size() >= max) {
                            break;
                        }
                    }
                }
                beforeAdd = afterAdd;
                afterAdd = tmp;
                afterAdd.clear();
            }
            result.addAll(beforeAdd);
        }
        // 全量组合的首字母
        if (first) {
            beforeAdd.clear();
            afterAdd.clear();
            beforeAdd.addAll(pinyinFirstMap.get(0));
            for (int i = 1; i < nameChar.length; i++) {
                Set<String> tmp = beforeAdd;
                Set<String> onePinyin = pinyinFirstMap.get(i);
                for (String f : beforeAdd) {
                    for (String l : onePinyin) {
                        afterAdd.add(f + l);
                        if (beforeAdd.size() >= max) {
                            break;
                        }
                    }
                }
                beforeAdd = afterAdd;
                afterAdd = tmp;
                afterAdd.clear();
            }
            result.addAll(beforeAdd);
        }
        log.debug("拼音获取结果共{}个,原始值：{}", result.size(), chines);
        return result;
    }
    
    
}
