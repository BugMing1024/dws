package com.cloudwise.douc.service.model.group;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author Bruce.liu
 * @date 2022-01-20
 */
@Data
@ApiModel
public class GroupPositionUserInfoReq {

    @ApiModelProperty(value = "职务id")
    @NotNull(message = IBaseExceptionCode.API_GROUP_POSITION_NOT_NULL)
    private Long positionId;
    @ApiModelProperty(value = "每页条数")
    private Integer size;
    @ApiModelProperty(value = "当前页")
    private Integer current;
    @ApiModelProperty(value = "租户id")
    private transient Long accountId;
    @ApiModelProperty(value = "模糊查询")
    private String aliasOrNameOrEmail;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
