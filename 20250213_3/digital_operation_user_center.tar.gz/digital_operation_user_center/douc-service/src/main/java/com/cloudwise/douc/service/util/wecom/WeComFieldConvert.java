package com.cloudwise.douc.service.util.wecom;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.mapper.IIdentitySourceDao;
import com.cloudwise.douc.metadata.model.department.DepartMentInfo;
import com.cloudwise.douc.metadata.model.department.Department;
import com.cloudwise.douc.metadata.model.department.DepartmentUserRelation;
import com.cloudwise.douc.metadata.model.identitysource.IdentityFiledMapping;
import com.cloudwise.douc.metadata.model.user.User;
import com.cloudwise.douc.service.model.identitysource.WeComInfoForCallBack;
import com.cloudwise.douc.service.model.identitysource.WeComUserUpdateField;
import com.cloudwise.douc.service.model.wecom.WeComDepartment;
import com.cloudwise.douc.service.model.wecom.WeComExtar;
import com.cloudwise.douc.service.model.wecom.WeComExternalAttr;
import com.cloudwise.douc.service.model.wecom.WeComUser;
import com.cloudwise.douc.service.util.ObjectToMapUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class WeComFieldConvert {

    private static final String DOUC_BASE_FILED_STRING = "name,user_alias,mobile,phone,email,department_user,user_leader_id,dingtalk_account,weixinwork_account,position";
    private static final String DOUC_BASE_FILED_FOR_UPDATE_STRING = "departmentUserRelations,status";
    private static final String NAME = "name";
    private static final String USER_ALIAS = "user_alias";
    private static final String MOBILE = "mobile";
    private static final String EMAIL = "email";
    private static final String PHONE = "phone";
    private static final String DINGTALK_ACCOUNT = "dingtalk_account";
    private static final String WEIXINWORK_ACCOUNT = "weixinwork_account";
    private static final String FEISHU_ACCOUNT = "feishu_account";
    private static final String WXPUSH_ACCOUNT = "wxpush_account";
    private static final String WECOM = "wecom";
    private static final String MAN = "1";
    private static final String WOMAN = "2";
    private static final String DOUCMAN = "男";
    private static final String DOUCWOMAN = "女";
    private static final String POSITION = "position";

    private static final List<String> DOUC_BASE_FILED_FOR_UPDATE_LIST = Arrays.asList(DOUC_BASE_FILED_FOR_UPDATE_STRING.split(
            StrPool.COMMA));
    
    /**
     * douc中所有的基础字段
     */
    private static final Set<String> DOUC_BASE_FILED_LIST = new HashSet<>(Arrays.asList(DOUC_BASE_FILED_STRING.split(StrPool.COMMA)));

    private static final int EXTERNAL_ATTR_TYPE = 0; //属性类型: 0-文本 1-网页 2-小程序

    @Autowired
    private IIdentitySourceDao iIdentitySourceDao;

    @Autowired
    private IDepartmentDao departmentDao;

    //组织数据转换
    public void weComDepartmentConvert(List<WeComDepartment> weComDepartmentList, List<Department> departmentList, Long identitySourceId, Integer status) {
        for (WeComDepartment weComDepartment : weComDepartmentList) {
            Department department = new Department();
            department.setCode(this.getDoucCodeByWeCom(weComDepartment.getId(), identitySourceId));
            department.setName(weComDepartment.getName());
            department.setParentCode(this.getDoucCodeByWeCom(weComDepartment.getParentId(), identitySourceId));
            department.setStatus(status);
            departmentList.add(department);
        }
    }

    //用户数据转换
    public WeComUserUpdateField weComUserConvert(List<WeComUser> weComUserList, List<User> userList, Long identitySourceId, Long accountId, Boolean isSyncDepartment, Long departmentParentId, List<String> weComDepartmentIdList, Integer status) {
        WeComUserUpdateField weComUserUpdateField = new WeComUserUpdateField();
        List<IdentityFiledMapping> identityFiledMappingList = iIdentitySourceDao
                .getOpenFiledMappingByIdentitySourceId(identitySourceId, accountId, 2);
        Map<String, String> localAndExternalFiledMap = new HashMap<>();
        try {
            localAndExternalFiledMap = identityFiledMappingList.stream()
                    .collect(Collectors.toMap(IdentityFiledMapping::getLocalAttr, IdentityFiledMapping::getExternalAttr));
        } catch (Exception e) {
            log.error("获取配置的字段异常：", e);
            return weComUserUpdateField;
        }
        List<String> identitySourceBaseFields = identityFiledMappingList.stream().map(IdentityFiledMapping::getLocalAttr)
                .collect(Collectors.toList());
        List<String> realUpdateBaseFieldList = new ArrayList<>(DOUC_BASE_FILED_FOR_UPDATE_LIST);
        for (String baseField : identitySourceBaseFields) {
            if ("name".equals(baseField)) {
                realUpdateBaseFieldList.add("name");
            }
            if ("mobile".equals(baseField)) {
                realUpdateBaseFieldList.add("mobile");
            }
            if ("phone".equals(baseField)) {
                realUpdateBaseFieldList.add("phone");
            }
            if ("user_alias".equals(baseField)) {
                realUpdateBaseFieldList.add("userAlias");
            }
            if ("dingtalk_account".equals(baseField)) {
                realUpdateBaseFieldList.add("dingtalkAccount");
            }
            if ("weixinwork_account".equals(baseField)) {
                realUpdateBaseFieldList.add("weixinworkAccount");
            }
            if ("email".equals(baseField)) {
                realUpdateBaseFieldList.add("email");
            }
            if ("position".equals(baseField)) {
                realUpdateBaseFieldList.add("position");
            }
        }
        List<String> extendFieldList = new ArrayList<>();
        for (IdentityFiledMapping identityFiledMapping : identityFiledMappingList) {
            if (!DOUC_BASE_FILED_LIST.contains(identityFiledMapping.getLocalAttr())) {
                if (!realUpdateBaseFieldList.contains("extend")) {
                    realUpdateBaseFieldList.add("extend");
                }
                if (!extendFieldList.contains(identityFiledMapping.getLocalAttr())) {
                    extendFieldList.add(identityFiledMapping.getLocalAttr());
                }
            }
        }
        List<String> externalnameList = new ArrayList<>();
        Map<String, String> weComExternalNameAndValueMap = new HashMap<>();
        //企业微信中所有自带字段-值 map
        Map<String, String> weComUserMap = new HashMap<>();
        for (WeComUser weComUser : weComUserList) {
            externalnameList.clear();
            weComExternalNameAndValueMap.clear();
            weComUserMap.clear();
            User user = new User();
            //内置的匹配字段-不能动的字段
            user.setUserLeaderCodes(weComUser.getDirectLeader());
            List<DepartmentUserRelation> departmentUserRelationList = new ArrayList<>();
            if (!isSyncDepartment) {
                List<Long> departmentIdList = new ArrayList<>();
                departmentIdList.add(departmentParentId);
                List<DepartMentInfo> departmentInfoByIds = departmentDao.getDepartmentInfoByIds(accountId, departmentIdList);
                if (CollectionUtils.isNotEmpty(departmentInfoByIds)) {
                    DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                    departmentUserRelation.setDepartmentCode(departmentInfoByIds.get(0).getCode());
                    departmentUserRelation.setDepartmentId(departmentInfoByIds.get(0).getId());
                    departmentUserRelation.setIsMain(1);
                    if (MapUtils.isNotEmpty(localAndExternalFiledMap) && localAndExternalFiledMap.containsKey(POSITION)) {
                        departmentUserRelation.setPosition(weComUser.getPosition());
                    }
                    departmentUserRelationList.add(departmentUserRelation);
                }
            } else {
                for (int i = 0; i < weComUser.getDepartment().size(); i++) {
                    if (weComDepartmentIdList.contains(weComUser.getDepartment().get(i).toString())) {
                        DepartmentUserRelation departmentUserRelation = new DepartmentUserRelation();
                        List<String> chargeDepartmentCodeList = new ArrayList<>();
                        List<Long> isLeaderInDept = weComUser.getIsLeaderInDept();
                        if (1 == isLeaderInDept.get(i)) {
                            chargeDepartmentCodeList.add(String.valueOf(weComUser.getDepartment().get(i)));
                        }
                        user.setChargeDepartmentCodeList(chargeDepartmentCodeList);
                        departmentUserRelation.setDepartmentCode(getDoucCodeByWeCom(weComUser.getDepartment().get(i).toString(), identitySourceId));
                        if (weComUser.getMainDepartment() != null && Long.valueOf(weComUser.getMainDepartment()).equals(weComUser.getDepartment().get(i))) {
                            departmentUserRelation.setIsMain(1);
                        }
                        if (MapUtils.isNotEmpty(localAndExternalFiledMap) && localAndExternalFiledMap.containsKey(POSITION)) {
                            departmentUserRelation.setPosition(weComUser.getPosition());
                        }
                        departmentUserRelation.setAccountId(accountId);
                        departmentUserRelationList.add(departmentUserRelation);
                    }
                }
            }
            user.setDepartmentUserRelations(departmentUserRelationList);
            //内置的匹配字段-可以修改的字段 可能配置企业微信中的所有字段（企业微信自带字段，拓展字段）
            //企业微信中内部拓展字段的名称-值 的map
            Map<String, String> weComExtarNameAndValueMap = weComUser.getExtattr().getSiriusWeComExtarList().stream().collect(Collectors.toMap(WeComExtar::getName, WeComExtar::getValue));
            //企业微信中所有拓展字段名称
            List<String> extarnameList = weComUser.getExtattr().getSiriusWeComExtarList().stream().map(WeComExtar::getName)
                    .collect(Collectors.toList());
            if (weComUser.getWeComExternalProfile() != null) {
                externalnameList = weComUser.getWeComExternalProfile().getWeComExternalAttrList().stream().map(WeComExternalAttr::getName)
                        .collect(Collectors.toList());
            }
            if (weComUser.getWeComExternalProfile() != null) {
                for (WeComExternalAttr weComExternalAttr : weComUser.getWeComExternalProfile().getWeComExternalAttrList()) {
                    if (weComExternalAttr.getType() == EXTERNAL_ATTR_TYPE) {
                        weComExternalNameAndValueMap.put(weComExternalAttr.getName(), weComExternalAttr.getWeComTextvalue().getValue());
                    }
                }
            }
            
            try {
                weComUserMap = ObjectToMapUtil.convert(weComUser);
                if (StringUtils.isNotBlank(weComUserMap.get("gender"))) {
                    if (MAN.equals(weComUserMap.get("gender"))) {
                        weComUserMap.put("gender", DOUCMAN);
                    } else {
                        weComUserMap.put("gender", DOUCWOMAN);
                    }
                }
            } catch (Exception e) {
                log.error("java实体转map异常:", e);
            }

            //姓名匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(NAME))) {
                user.setName(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(NAME)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(NAME))) {
                user.setName(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(NAME)));
            } else {
                user.setName(weComUserMap.get(localAndExternalFiledMap.get(NAME)));
            }
            //用户名匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(USER_ALIAS))) {
                user.setUserAlias(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(USER_ALIAS))) {
                user.setUserAlias(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            } else {
                user.setUserAlias(weComUserMap.get(localAndExternalFiledMap.get(USER_ALIAS)));
            }
            //手机号匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(MOBILE))) {
                user.setMobile(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(MOBILE)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(MOBILE))) {
                user.setMobile(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(MOBILE)));
            } else {
                user.setMobile(weComUserMap.get(localAndExternalFiledMap.get(MOBILE)));
            }
            //邮箱匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(EMAIL))) {
                user.setEmail(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(EMAIL)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(EMAIL))) {
                user.setEmail(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(EMAIL)));
            } else {
                user.setEmail(weComUserMap.get(localAndExternalFiledMap.get(EMAIL)));
            }
            //座机匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(PHONE))) {
                user.setPhone(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(PHONE)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(PHONE))) {
                user.setPhone(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(PHONE)));
            } else {
                user.setPhone(weComUserMap.get(localAndExternalFiledMap.get(PHONE)));
            }
            //钉钉账号匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(DINGTALK_ACCOUNT))) {
                user.setDingtalkAccount(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(DINGTALK_ACCOUNT)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(DINGTALK_ACCOUNT))) {
                user.setDingtalkAccount(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(DINGTALK_ACCOUNT)));
            } else {
                user.setDingtalkAccount(weComUserMap.get(localAndExternalFiledMap.get(DINGTALK_ACCOUNT)));
            }
            //企业微信账号匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT))) {
                user.setWeixinworkAccount(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT))) {
                user.setWeixinworkAccount(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT)));
            } else {
                user.setWeixinworkAccount(weComUserMap.get(localAndExternalFiledMap.get(WEIXINWORK_ACCOUNT)));
            }
            //企业微信账号匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(FEISHU_ACCOUNT))) {
                user.setFeishuAccount(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(FEISHU_ACCOUNT))) {
                user.setFeishuAccount(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            } else {
                user.setFeishuAccount(weComUserMap.get(localAndExternalFiledMap.get(FEISHU_ACCOUNT)));
            }

            //微信公众号账号匹配
            if (extarnameList.contains(localAndExternalFiledMap.get(WXPUSH_ACCOUNT))) {
                user.setWxpushAccount(weComExtarNameAndValueMap.get(localAndExternalFiledMap.get(WXPUSH_ACCOUNT)));
            } else if (externalnameList.contains(localAndExternalFiledMap.get(WXPUSH_ACCOUNT))) {
                user.setWxpushAccount(weComExternalNameAndValueMap.get(localAndExternalFiledMap.get(WXPUSH_ACCOUNT)));
            } else {
                user.setWxpushAccount(weComUserMap.get(localAndExternalFiledMap.get(WXPUSH_ACCOUNT)));
            }

            List<Map<String, Object>> extendFields = new ArrayList<>();
            for (IdentityFiledMapping identityFiledMapping : identityFiledMappingList) {
                // 用户自定义的匹配字段-douc的拓展字段
                if (!DOUC_BASE_FILED_LIST.contains(identityFiledMapping.getLocalAttr())) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("alias", identityFiledMapping.getLocalAttr());
                    if (extarnameList.contains(identityFiledMapping.getExternalAttr())) {
                        map.put("value", weComExtarNameAndValueMap.get(identityFiledMapping.getExternalAttr()));
                    } else if (externalnameList.contains(identityFiledMapping.getExternalAttr())) {
                        map.put("value", weComExternalNameAndValueMap.get(identityFiledMapping.getExternalAttr()));
                    } else {
                        map.put("value", weComUserMap.get(identityFiledMapping.getExternalAttr()));
                    }
                    extendFields.add(map);
                }
            }
            user.setExtend(extendFields);
            user.setTopAccountId(accountId);
            user.setIdentitySourceId(identitySourceId);
            user.setCode(getDoucCodeByWeCom(weComUser.getUserid(), identitySourceId));
            user.setImportType(5);
            user.setStatus(status);
            userList.add(user);
        }
        weComUserUpdateField.setBaseFieldList(realUpdateBaseFieldList);
        weComUserUpdateField.setExtendFieldList(extendFieldList);
        return weComUserUpdateField;
    }

    public void weComDepartmentCallBack(WeComInfoForCallBack weComInfoForCallBack, Department department, Long identitySourceId, Long accountId) {
        department.setCode(getDoucCodeByWeCom(weComInfoForCallBack.getId().toString(), identitySourceId));
        if (department.getParentId() != null) {
            department.setParentCode(getDoucCodeByWeCom(weComInfoForCallBack.getParentId().toString(), identitySourceId));
        }
        department.setName(weComInfoForCallBack.getName());
        department.setAccountId(accountId);
        department.setImportType(5);
        department.setIdentitySourceId(identitySourceId);
    }

    public WeComUserUpdateField weComUserCallBack(WeComInfoForCallBack weComInfoForCallBack, User user) {
        //TODO weComInfoForCallBack -> user 需要判断出有哪些字段发生了改变，然后放入到baseFieldListForUpdate中;
        return new WeComUserUpdateField();
    }

    public String getDoucCodeByWeCom(String code, Long identitySourceId) {
        return WECOM + StrPool.UNDERLINE + identitySourceId + StrPool.UNDERLINE + code;
    }
}
