package com.cloudwise.douc.service.model.mq;

import com.cloudwise.douc.metadata.model.user.UserMessageInfoAndAccount;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author maker.wang
 * @description:
 * @date Created in 12:46 下午 2021/8/17.
 */
@Data
public class UserMqMessage implements Serializable {
    private static final long serialVersionUID = 1325458217132199400L;

    public UserMqMessage() {
        this.sendTime = System.currentTimeMillis();
    }

    /**
     * 类型: ADD新增 DELETE删除
     **/
    private String type;

    /**
     * 发送时间戳
     **/
    private Long sendTime;

    /**
     * 用户详情
     */
    private List<UserMessageInfoAndAccount> userMessageInfoAndAccountList;
}
