package com.cloudwise.douc.service.util.file;

import cn.hutool.core.text.StrPool;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author leakey.li
 * @description:
 * @date Created in 10:55 上午 2023/2/17.
 */
@Slf4j
public class CheckRealFileTypeUtil {

    public static boolean checkRealFileType(MultipartFile file) {
        boolean realFlag = true;
        // 文件类型判断 - 校验文件后缀
        String fileName = file.getOriginalFilename();
        if (StringUtils.isBlank(fileName)) {
            realFlag = false;
        }
        String suffix = fileName.substring(fileName.lastIndexOf(StrPool.C_DOT) + 1);
        // 文件类型判断 - 校验文件头内容
        try (InputStream inputStream = file.getInputStream()) {
            // 获取到上传文件的文件头信息
            String fileHeader = FileUtils.getFileHeader(inputStream);
            if (StringUtils.isBlank(fileHeader)) {
                log.error("Failed to get file header content.");
                realFlag = false;
            }
            // 根据上传文件的后缀获取法定的文件头
            String validHeader = getHeaderByFileType(suffix);
            // 类型不匹配
            if (StringUtils.isNotBlank(validHeader) && !fileHeader.toUpperCase().startsWith(validHeader)) {
                realFlag = false;
            }
        } catch (IOException e) {
            log.error("Get file input stream failed.", e);
        }
        return realFlag;
    }

    /**
     * 校验文件后缀是否正确
     *
     * @param input  inputStream 流文件
     * @param suffix 后缀名
     * @return
     */
    public static boolean checkRealInputStreamType(InputStream input, String suffix) {
        boolean realFlag = true;
        // 文件类型判断 - 校验文件后缀

        if (input == null) {
            return false;
        }

        // 文件类型判断 - 校验文件头内容
        try (InputStream inputStream = input) {
            // 获取到上传文件的文件头信息
            String fileHeader = FileUtils.getFileHeader(inputStream);
            if (StringUtils.isBlank(fileHeader)) {
                log.error("Failed to get file header content.");
                realFlag = false;
            }
            log.error("==fileHeaderfileHeaderfileHeader= {}", fileHeader);
            // 根据上传文件的后缀获取法定的文件头
            String validHeader = getHeaderByFileType(suffix);
            log.error("==suffix= {}", suffix);
            log.error("==validHeader= {}", validHeader);
            // 类型不匹配
            if (StringUtils.isNotBlank(validHeader) && !fileHeader.toUpperCase().startsWith(validHeader)) {
                realFlag = false;
            }
        } catch (IOException e) {
            log.error("Get file input stream failed.", e);
        }
        return realFlag;
    }


    public static String getHeaderByFileType(String fileType) {
        if (StringUtils.isBlank(fileType)) {
            return "";
        }
        fileType = fileType.toUpperCase();
        FileTypeEnum[] fileTypes = FileTypeEnum.values();
        String fileHeader = StringUtils.EMPTY;
        for (FileTypeEnum type : fileTypes) {
            if (type.getSuffixName().equalsIgnoreCase(fileType)) {
                fileHeader = type.getHeadCode();
                break;
            }
        }
        return fileHeader;
    }
}
