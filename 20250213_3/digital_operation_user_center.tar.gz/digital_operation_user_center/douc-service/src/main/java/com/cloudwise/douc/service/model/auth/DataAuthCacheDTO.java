package com.cloudwise.douc.service.model.auth;

import com.cloudwise.douc.metadata.model.data.DataAuthentication;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ken.liang
 * @description:
 * @date Created in 11:00 AM 2021/6/24.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataAuthCacheDTO implements Serializable {

    private static final long serialVersionUID = 4562107363872040573L;
    private long createTime;
    private List<DataAuthentication> dataAuthenticationList;
}
