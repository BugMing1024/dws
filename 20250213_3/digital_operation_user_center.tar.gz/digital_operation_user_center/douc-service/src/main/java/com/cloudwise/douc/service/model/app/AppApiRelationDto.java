package com.cloudwise.douc.service.model.app;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: hulk.liu
 * @Date: 2021/08/18/11:22 上午
 * @Description:
 */
@Getter
@Setter
public class AppApiRelationDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String appKey;
    private List<String> apps;
    //apiIds
    private List<String> codes;
    private String limitInfo;
    private String apiName;
    private String moduleCode;
    private String accountId;
    /**
     * 状态[0:停用，1:启用]
     **/
    private Integer status;
    /**
     * 0-永久，1-短期
     **/
    private Integer bindType;
    private Long expireTime;
}
