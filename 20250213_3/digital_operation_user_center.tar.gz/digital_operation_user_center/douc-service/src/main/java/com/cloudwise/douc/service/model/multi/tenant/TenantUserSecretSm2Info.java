package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * 多租户-加密处理后的密码详情
 *
 * @author maker.wang
 * @date 2021-06-30 14:28
 **/
@Data
public class TenantUserSecretSm2Info implements Serializable {
    private static final long serialVersionUID = 4357811702538323910L;

    /**
     * 接口传入的原始密码 sm2(明文密码—sm3(明文密码))
     **/
    private transient String originUserSecret;

    /**
     * 明文密码
     **/
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$#_@$!%*?&]).{7,20}$", message = IBaseExceptionCode.API_USER_MODEL_SECRET_FORMAT)
    private transient String clearTextUserSecret;

    /**
     * sm3(sm3(明文密码))
     **/
    private transient String smPasswordCpd;

    /**
     * sm2(sm3(sm3(明文密码)))
     **/
    private transient String smPasswordBpd;

}
