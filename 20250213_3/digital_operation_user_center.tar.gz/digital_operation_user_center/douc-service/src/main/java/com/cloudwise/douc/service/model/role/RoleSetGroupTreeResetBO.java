package com.cloudwise.douc.service.model.role;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * 角色配置用户组 重新配置用户组入参
 *
 * @author maker.wang
 * @date 2022-03-10 09:40
 **/
@Data
@ApiModel("角色配置用户组 重新配置用户组入参")
public class RoleSetGroupTreeResetBO implements Serializable {
    private static final long serialVersionUID = 5843058342985432909L;

    @ApiModelProperty("角色id")
    @NotNull(message = IBaseExceptionCode.API_ROLE_ID_NULL)
    private Long roleId;

    @ApiModelProperty("选中用户组列表")
    private List<RoleSetGroupDTO> addUpdateList;

    @ApiModelProperty("反选用户组列表")
    private List<Long> removeList;

}
