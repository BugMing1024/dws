package com.cloudwise.douc.service.model.menu;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Data
public class DeleteViewMenuReq implements Serializable {

    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;

    @NotNull(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    private Long userId;

    @ApiModelProperty(value = "应用code")
    private String appCode;

    @ApiModelProperty(value = "菜单视图code")
    private List<String> codeList;
}
