package com.cloudwise.douc.service.model.auth;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.Set;

/**
 * @author KenLiang
 * @description:
 * @date Created in 3:54 PM 2020/4/12.
 */
@Data
public class DataAuthResponseNode {
    @JsonIgnore
    private String groupLevel;
    private String code;
    private Set<String> functionCodes;
}
