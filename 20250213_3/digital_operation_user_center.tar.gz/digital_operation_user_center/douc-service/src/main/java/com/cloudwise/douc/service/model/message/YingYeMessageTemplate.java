package com.cloudwise.douc.service.model.message;

import cn.hutool.core.text.StrPool;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

/**
 * @author leakey.li
 * @description:
 * @date Created in 3:15 下午 2022/2/21.
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class YingYeMessageTemplate extends AbstractMessageTemplate {
    private String toUser;
    private String app = "app";
    //ip 没有用，注释掉
    private String ip;

    public YingYeMessageTemplate(String toUser, String content, String ip, String typeCode, String app) {
        if (StringUtils.isNotEmpty(ip)) {
            String[] split = ip.split(StrPool.COMMA);
            this.ip = split[0];
        } else {
            this.ip = ip;
        }
        this.toUser = toUser;
        this.content = content;
        this.typeCode = typeCode;
        this.app = app;
    }

}