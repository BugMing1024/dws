package com.cloudwise.douc.service.configuration;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;


/**
 * 企业微信代开发配置
 *
 * @author maker.wang
 * @date 2022-05-23 11:57
 **/

@Component
@RefreshScope
@ConfigurationProperties(prefix = "login.wecom.service-provider")
@Data
public class LoginWeComGenerationDevelopConfig implements Serializable {

    private static final long serialVersionUID = 1265033909493056419L;

    @ApiModelProperty(value = "服务商ID")
    public String corpId;

    @ApiModelProperty(value = "服务商的secret，在服务商管理后台可见")
    public String providerSecret;

    @ApiModelProperty(value = "代开发模板token")
    private String token;

    @ApiModelProperty(value = "代开发模板加密串")
    private String encodingAESKey;


    private List<LoginWeComGenerationDevelopConfig.GenerationDevelopModelConfig> model;

    @Data
    @ApiModel(value = "代开发模板信息")
    public static class GenerationDevelopModelConfig implements Serializable {
        private static final long serialVersionUID = 5181928162115239915L;

        @ApiModelProperty(value = "代开发模板id")
        private String id;

        @ApiModelProperty(value = "代开发模秘钥")
        private String secret;

        @ApiModelProperty(value = "代开发模板对应的渠道产品类型 1:ITSM 2:IM ")
        private String type;

        @ApiModelProperty(value = "代开发模板二维码")
        private String qrcode;
    }

}
