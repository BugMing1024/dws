package com.cloudwise.douc.service.util;

// CHECKSTYLE:OFF

import java.awt.*;
import java.awt.image.BufferedImage;
import java.security.SecureRandom;
import java.util.Random;

/**
 * 生成验证码工具类
 *
 * @author: bernie
 * @date: 2020/3/5 上午10:35
 */
public class VerifyCodeUtil {

    //验证码为数字和字母的组合
    private static final String BASE_NUM_LETTER = "123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
    private static final Random RANDOM = new SecureRandom();

    /**
     * 获取指定位数的随机验证码
     *
     * @Param number 生成验证码位数
     * @Return String 验证码
     * @Auth bernie
     * @Date 2:48 PM 2021/10/19
     */
    public static String getVerifyCode(int number) {
        StringBuilder sBuffer = new StringBuilder();
        SecureRandom random = new SecureRandom();
        String ch = "";
        for (int i = 0; i < number; i++) {
            //获得随机字符
            int dot = random.nextInt(BASE_NUM_LETTER.length());
            ch = BASE_NUM_LETTER.charAt(dot) + "";
            //字符存入buffer
            sBuffer.append(ch);
        }
        return sBuffer.toString();
    }


    /**
     * 绘制验证码
     *
     * @param verifyImg
     * @return: java.lang.String
     * @author: bernie
     * @date: 2020/3/5 上午10:24
     */
    public static String drawRandomText(BufferedImage verifyImg) {

        //获得画板
        Graphics2D graphics = (Graphics2D) verifyImg.getGraphics();
        //设置画笔颜色-验证码背景色
        graphics.setColor(new Color(230, 230, 230));
        //填充背景
        graphics.fillRect(0, 0, verifyImg.getWidth(), verifyImg.getHeight());
        graphics.setFont(new Font("Default", Font.BOLD, 20));

        StringBuilder sBuffer = new StringBuilder();
        //起始 x 坐标
        int x = 23;
        String ch = "";

        for (int i = 0; i < 4; i++) {
            //设置验证码颜色
            graphics.setColor(new Color(81, 81, 81));
            //获得随机字符
            int dot = RANDOM.nextInt(BASE_NUM_LETTER.length());
            ch = BASE_NUM_LETTER.charAt(dot) + "";
            //字符存入buffer
            sBuffer.append(ch);
            //字符绘制到画布上
            graphics.drawString(ch, x, 33);
            //设置字符间隔
            x += 18;
        }
        graphics.dispose();
        return sBuffer.toString();
    }

    public static String getVerifyCodeString() {
        StringBuilder sBuffer = new StringBuilder();
        String ch = "";
        for (int i = 0; i < 4; i++) {
            //设置验证码颜色
            //获得随机字符
            int dot = RANDOM.nextInt(BASE_NUM_LETTER.length());
            ch = BASE_NUM_LETTER.charAt(dot) + "";
            //字符存入buffer
            sBuffer.append(ch);

        }
        return sBuffer.toString();
    }

    /**
     * 获取6位数的纯数字随机验证码
     *
     * @author maker.wang
     * @date 2022-02-24 11:53
     **/
    public static String getDigitVerifyCode() {
        SecureRandom random = new SecureRandom();
        return String.valueOf(random.nextInt(900000) + 100000);
    }
}
