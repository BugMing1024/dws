package com.cloudwise.douc.service.model.mq;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


/**
 * 租住删除
 *
 * @author maker.wang
 * @date 2022-07-18 13:40
 **/
@Data
@ApiModel(value = "消息中心")
public class AccountDeleteEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "租户id")
    private Long accountId;

}
