package com.cloudwise.douc.service.cache;

public interface IDepartmentDataCache {
    /**
     * 通过accountId和用户id获取用户所在部门
     *
     * @param accountId
     * @return
     */
    String getDepartmentDataByDepartmentId(Long accountId, Long departmentId);

    /**
     * 给用户设置部门缓存
     *
     * @param accountId
     * @return
     */
    void setDepartmentDataByDepartmentId(Long accountId, Long departmentId, String departmentInfo);

}
