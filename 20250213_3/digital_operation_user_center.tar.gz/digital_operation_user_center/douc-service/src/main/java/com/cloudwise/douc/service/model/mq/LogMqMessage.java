package com.cloudwise.douc.service.model.mq;

import com.cloudwise.douc.service.model.logaudit.LogInfoVo;
import lombok.Data;

import java.io.Serializable;

/**
 * @author maker.wang
 * @description:
 * @date Created in 12:46 下午 2021/8/17.
 */
@Data
public class LogMqMessage implements Serializable {
    private static final long serialVersionUID = 1325458217132199400L;

    public LogMqMessage() {
        this.sendTime = System.currentTimeMillis();
    }

    /**
     * 类型: ADD新增 DELETE删除
     **/
    private String type;

    /**
     * 发送时间戳
     **/
    private Long sendTime;

    /**
     * 同步日志信息
     */
    private LogInfoVo logInfoVo;
}
