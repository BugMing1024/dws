package com.cloudwise.douc.service.model.user;

import lombok.Data;

import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 2:36 PM 2021/4/29.
 */
@Data
public class UserOtherInfoRequestObject {
    private List<Long> userIds;
}
