package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.service.model.role.RoleGroupResp;

import java.util.List;

/**
 * 查询角色组相关信息，屏蔽底层查询，数据可能来自DB或redis
 *
 * @author Bernie
 * @date 2021-02-01 10:31
 */
public interface IRoleGroupDataFlow {
    List<RoleGroupResp> getAllRoleInfosByDataFlow(long accountId);

    void setAllRoleInfosByDataFlow(List<RoleGroupResp> roleGroupResps, long accountId);

    void deleteAllRoleInfosByDataFlow(long accountId);


    /**
     * 删除角色组缓存
     */
    void deleteAllV2RoleGroupFromCacheByAccountId(Long accountId);

    /**
     * 删除角色权限缓存
     *
     * @param accountId
     * @param roleIds
     */
    void deleteAllMenuAndDataAuthCacheByRoleIds(Long accountId, List<Long> roleIds);
}
