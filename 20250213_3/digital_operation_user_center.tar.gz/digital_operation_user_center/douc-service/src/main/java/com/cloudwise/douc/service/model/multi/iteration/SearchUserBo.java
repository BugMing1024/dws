package com.cloudwise.douc.service.model.multi.iteration;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 从顶级租户检索用户返回实体
 *
 * @author maker.wang
 * @date 2021-09-04 15:28
 **/
@Data
public class SearchUserBo implements Serializable {

    private static final long serialVersionUID = -2985599518061664713L;

    public SearchUserBo() {
        this.current = 1;
        this.size = 5;
    }

    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;

    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;

    /**
     * 用户姓名
     **/
    private String name;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }

}

