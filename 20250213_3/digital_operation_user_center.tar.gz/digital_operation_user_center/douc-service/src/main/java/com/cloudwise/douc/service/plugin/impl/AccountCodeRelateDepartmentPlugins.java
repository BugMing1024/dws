package com.cloudwise.douc.service.plugin.impl;

import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.plugin.common.AbstractDOUCPlugin;
import com.cloudwise.douc.commons.plugin.common.PluginManagerUtils;
import com.cloudwise.douc.commons.plugin.common.PluginResult;
import com.cloudwise.douc.commons.plugin.common.PluginsEndpointConstants;
import com.cloudwise.douc.metadata.mapper.IDepartmentDao;
import com.cloudwise.douc.metadata.model.department.DepartmentNode;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.service.model.multi.tenant.AccountAddBO;
import com.cloudwise.douc.service.model.multi.tenant.AccountUpdateBO;
import com.cloudwise.douc.service.service.IAccountService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Set;

/**
 * @author zafir.zhong
 * @description 一个示例埋点,给dubbo/test加了个ping pong的功能
 * @date Created in 17:08 2022/11/9.
 */
@Component
@Slf4j
@ConditionalOnProperty(name = "plugins.accountCode.enabled", havingValue = "true", matchIfMissing = false)
public class AccountCodeRelateDepartmentPlugins extends AbstractDOUCPlugin {

    private static final Set<String> END_POINTS = new HashSet<>();
    static {
        END_POINTS.add(PluginsEndpointConstants.UPDATE_ACCOUNT);
        END_POINTS.add(PluginsEndpointConstants.ADD_ACCOUNT);
    }

    @Resource
    private IDepartmentDao departmentDao;
    @Resource
    private IAccountService accountService;
    /**
     *
     * @description 一般无需通过bean注册，因为序列的默认构造方法会执行注册
     * - 无参数
     * - 无返回
     * @author zafir.zhong
     * @date 2022/11/9
     * @time 17:47
     *
     */
    //@PostConstruct
    public void init() {
        PluginManagerUtils.register(this);
    }
    /**
     *
     * @description 如果有对应的销毁逻辑可能就要自己销毁了
     * - 无参数
     * - 无返回
     * @author zafir.zhong
     * @date 2022/11/9
     * @time 17:47
     *
     */
    @PreDestroy
    public void destroy() {
        PluginManagerUtils.destroy(this);
    }

    @Override
    public Set<String> endPoints() {
        return END_POINTS;
    }

    @Override
    public PluginResult handle(String endPointKey, Object... objs) {
        PluginResult result = new PluginResult();
        result.setParams(objs);
        String code = null;
        Long pId = null;
        // 取出租户、编码等信息
        switch (endPointKey) {
            case PluginsEndpointConstants.ADD_ACCOUNT:
                code = ((AccountAddBO) objs[0]).getCode();
                pId = ((AccountAddBO) objs[0]).getParentAccountId();
                break;
            case PluginsEndpointConstants.UPDATE_ACCOUNT:
                code = ((AccountUpdateBO) objs[0]).getCode();
                pId = ((AccountUpdateBO) objs[0]).getParentAccountId();
                break;
            default:
        }
        if (pId == null) {
            return result;
        }
        AccountDetail accountDetailById = accountService.getAccountDetailById(pId);
        if (accountDetailById == null) {
            return result;
        }
        // 编码检查
        Long topAccountId = accountDetailById.getTopId();
        log.debug("now check relate code :{}", code);
        if (StringUtils.isEmpty(code)) {
            // 如果要求不是必填那就无需必填检查
            if (ConfigUtils.hasPath("front.account.code.notNull")
                    && !ConfigUtils.getBoolean("front.account.code.notNull")) {
                return result;
            }
            throw new BaseException(IBaseExceptionCode.EMPTY_ACCOUNT_CODE);
        }
        DepartmentNode departmentInfoByCode = departmentDao.getDepartmentInfoByCode(topAccountId, code);
        if (departmentInfoByCode == null) {
            throw new BaseException(IBaseExceptionCode.ERROR_ACCOUNT_CODE);
        }
        return result;
    }


    @Override
    public void clean(String endPointKey) {

    }
}
