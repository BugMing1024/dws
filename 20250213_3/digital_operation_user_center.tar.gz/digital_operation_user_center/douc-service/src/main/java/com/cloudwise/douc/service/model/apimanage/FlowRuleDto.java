package com.cloudwise.douc.service.model.apimanage;

import lombok.Data;

import java.io.Serializable;

/**
 * 流控实体类
 **/
@Data
public class FlowRuleDto implements Serializable {

    /**
     * 是否配置流控规则 0-不开启控制，1-开启控制
     **/
    private Integer hasRule;
    /**
     * 每秒的并发次数
     **/
    private Integer count;
}
