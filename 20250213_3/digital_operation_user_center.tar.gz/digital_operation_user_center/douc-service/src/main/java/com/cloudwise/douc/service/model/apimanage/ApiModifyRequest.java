package com.cloudwise.douc.service.model.apimanage;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * Description: API修改实体类
 *
 * @author damon
 */
@Data
public class ApiModifyRequest {
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private String accountId;
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_USERID_NOT_NULL)
    private String userId;
    private List<ApiInfoDTO> apiInfoList;
}
