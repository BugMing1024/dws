package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.data.DataAuthentication;

import java.util.List;

/**
 * @description: 数据资源缓存
 * @author: jasonlee
 * @date: 2021-01-29 19:29
 **/
public interface IDataResourceCache {

    /**
     * description:
     *
     * @param
     * @return
     * @date create by jasonlee at 2021/1/29 11:52 PM
     */
    List<DataAuthentication> getDataAuthByUserIdAndTypeFromCache(Long accountId, Long userId, String dataType);

    /**
     * description: 设置对应数据权限类型缓存为dirty
     *
     * @date create by ken
     */
    void setDataAuthByUserIdAndTypeCacheDirty(Long accountId, String dataType);

}
