package com.cloudwise.douc.service.runner;

import com.cloudwise.douc.commons.utils.AsyncTaskPool;
import com.cloudwise.douc.service.service.IDomainDepartmentService;
import com.cloudwise.douc.service.service.ILuceneService;
import com.cloudwise.douc.service.service.IUserGroupRelationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


/**
 * @author zafir.zhong
 * @description 渠道实现
 * @date Created in 18:38 2022/5/16.
 */
@ConditionalOnProperty(name = "sso.server.mode.isSaasLoginApi", havingValue = "false")
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 1)
@Slf4j
public class AllAsyncRunner implements ApplicationRunner {
    
    
    @Autowired
    private ILuceneService iLuceneService;
    
    @Autowired
    private IUserGroupRelationService userGroupRelationService;
    
    @Autowired
    private IDomainDepartmentService domainDepartmentService;
    
    @Override
    public void run(ApplicationArguments args) throws Exception {
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            try {
                iLuceneService.syncLuceneDoc();
            } catch (Throwable throwable) {
                log.error("iLuceneService syncLuceneDoc error", throwable);
            }
        });
    
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            try {
                userGroupRelationService.checkAllUserGroupRoleTask();
            } catch (Throwable throwable) {
                log.error("userGroupRelationService checkAllUserGroupRoleTask error", throwable);
            }
        });
    
        AsyncTaskPool.getTaskExecutor().execute(() -> {
            try {
                domainDepartmentService.checkAndSetGlobalDomain();
            } catch (Throwable throwable) {
                log.error("userGroupRelationService checkAllUserGroupRoleTask error", throwable);
            }
        });
    }
}



