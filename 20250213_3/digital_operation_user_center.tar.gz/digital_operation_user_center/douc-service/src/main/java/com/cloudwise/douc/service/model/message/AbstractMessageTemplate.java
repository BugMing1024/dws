package com.cloudwise.douc.service.model.message;

import lombok.Data;

/**
 * @author leakey.li
 * @description: 短信发送http 消息模板
 * @date Created in 3:09 下午 2022/2/21.
 */
@Data
public class AbstractMessageTemplate {
    /**
     * 短信内容
     */
    protected String content;
    /**
     * 发送的手机号
     */
    protected String mobile;
    /**
     * 手机号
     */
    protected String code;
    /**
     * 短信模板类型
     */
    protected String typeCode;
}
