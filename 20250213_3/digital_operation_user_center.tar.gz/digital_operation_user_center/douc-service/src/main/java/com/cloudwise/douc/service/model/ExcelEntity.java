package com.cloudwise.douc.service.model;

import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.model.FrontWebConfig;
import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author barney.song
 * Description: No Description
 */
public enum ExcelEntity {
    /**
     * 用户名（必填）
     */
    USER_ALIAS(0, "userAlias", "用户名（必填）\n"
            + "Username (required）", "用户名(必填)"),
    /**
     * 用户编号
     */
    CODE(1, "code", "用户编号\n"
            + "User ID", "用户编号"),

    /**
     * 用户姓名（必填）
     */
    NAME(2, "name", "姓名（必填）\n"
            + "Name (required)", "用户姓名"),
    /**
     * 部门（必填）
     */
    DEPARTMENT(3, "department", "部门（必填）\n"
            + "Department (required)", "部门"),
    /**
     * 状态
     */
    STATUS(4, "status", "状态\n"
            + "Status", "状态"),

    /**
     * 电子邮箱（必填）
     */
    EMAIL(5, "email", "邮箱\n"
            + "Email", "电子邮箱"),
    /**
     * 手机号码（必填）
     */
    MOBILE(6, "mobile", "手机号\n"
            + "Phone", "手机号码"),

    /**
     * 类型（必填）
     */
    ORIGIN(7, "origin", "类型\n"
            + "Type", "用户类型"),
    /**
     * 企业微信
     */
    WECHAT(8, "wechat", "企业微信账号\n"
            + "Wecom", "企业微信"),
    /**
     * 钉钉
     */
    DINGTALK(9, "dingtalk", "钉钉账号\n"
            + "DingTalk", "钉钉"),
    /**
     * 飞书
     */
    FEISHU(10, "feishuAccount", "飞书账号\n"
            + "Feishu", "飞书"),
    /**
     * 微信公众号
     */
    WXPUSH(11, "wxpushAccount", "微信公众号账号\n"
            + "WeChat official account", "微信公众号"),
    /**
     * 座机
     */
    PHONE(12, "phone", "固定电话\n"
            + "Tel", "固定电话"),

    /**
     * 汇报对象
     */
    USERLEADER(13, "userLeaderName", "汇报对象\n"
            + "Report to", "汇报对象"),

    /**
     * 职务
     */
    POSITION(14, "position", "职务\n"
            + "Title", "职务"),
    /**
     * 角色
     */
    ROLE(15, "role", "角色\n"
            + "Role", "角色");
    private int index;
    private String fieldName;
    private String excelRowName;
    private String excelHeadName;

    ExcelEntity(int index, String fieldName, String excelRowName, String excelHeadName) {
        this.index = index;
        this.fieldName = fieldName;
        this.excelRowName = excelRowName;
        this.excelHeadName = excelHeadName;
    }

    public static String getExcelRowNameByIndex(int index) {
        for (ExcelEntity excelEntity : ExcelEntity.values()) {
            if (index == excelEntity.index) {
                return excelEntity.excelRowName;
            }
        }
        return null;
    }

    public static List<String> toExcelHeadName() {
        List<String> list = Lists.newArrayListWithExpectedSize(ExcelEntity.values().length);
        for (ExcelEntity excelEntity : ExcelEntity.values()) {
            if (!Boolean.parseBoolean(ConfigUtils.getString("user.export.role.enable"))
                    && ExcelEntity.ROLE.equals(excelEntity)) {
                continue;
            }
            list.add(excelEntity.getExcelHeadName());
        }
        return list;
    }
    
    public static List<String> toExcelRowName() {
        List<String> list = Lists.newArrayListWithExpectedSize(ExcelEntity.values().length);
        for (ExcelEntity excelEntity : ExcelEntity.values()) {
            // 处理问题，多了个角色栏
            if (!Boolean.parseBoolean(ConfigUtils.getString("user.export.role.enable")) && excelEntity.equals(
                    ExcelEntity.ROLE)) {
                continue;
            }
            list.add(excelEntity.getExcelRowName());
        }
        return list;
    }

    public static int getMaxIndexValue() {
        List<Integer> indexCollect = Arrays.asList(ExcelEntity.values())
                .stream()
                .map(ExcelEntity::getIndex)
                .sorted()
                .collect(Collectors.toList());
        boolean isSaas = SpringUtil.getBean(FrontWebConfig.class).getMultiTopAccountEnable();
        if (isSaas) {
            return indexCollect.get(indexCollect.size() - 4);
        }
        return indexCollect.get(indexCollect.size() - 2);
    }

    public int getIndex() {
        return index;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getExcelRowName() {
        return excelRowName;
    }

    public String getExcelHeadName() {
        return excelHeadName;
    }

}
