package com.cloudwise.douc.service.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * lic的多语言覆盖支持
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-04-19 00:09; update at 2024-04-19 00:09
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "lic")
public class LicFeatureProperties {
    
    private Map<String, Map<String, String>> i18n;
    
    
}
