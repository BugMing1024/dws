package com.cloudwise.douc.service.model.statistics;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author leakey.li
 * @description:
 * @date Created in 2:11 下午 2022/9/22.
 */
@Data
public class StatisticsParam {
    private Long accountId;
    @ApiModelProperty(value = "部门code")
    private String departmentCode;
    @ApiModelProperty(value = "拓展字段编码")
    private String extendField;
    @ApiModelProperty(value = "拓展字段值")
    private String extendValue;

    private List<Long> departmentIds;
    /**
     * 页码
     */
    @ApiModelProperty(value = "页码")
    private Integer current;

    /**
     * 每页条数
     */
    @ApiModelProperty(value = "每页条数")
    private Integer size;
    @ApiModelProperty(value = "用户状态")
    private Integer userStatus;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
