package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserInfoPO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author leakey.li
 * @description:
 * @date Created in 4:56 下午 2021/10/11.
 */
@Data
public class CircleUserInfoPO extends UserInfoPO implements Serializable {
    private Boolean isCircle = Boolean.FALSE;
    private Integer circleType;
    private List<GroupBaseInfo> groupList;
}
