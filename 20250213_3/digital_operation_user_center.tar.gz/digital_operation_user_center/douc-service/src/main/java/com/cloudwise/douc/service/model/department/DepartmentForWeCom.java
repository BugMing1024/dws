package com.cloudwise.douc.service.model.department;

import lombok.Data;

import java.util.Objects;

@Data
public class DepartmentForWeCom {
    private String code;

    private String parentCode;

    private String name;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DepartmentForWeCom that = (DepartmentForWeCom) o;
        return Objects.equals(code, that.code)
                && Objects.equals(parentCode, that.parentCode)
                && Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, parentCode, name);
    }
}
