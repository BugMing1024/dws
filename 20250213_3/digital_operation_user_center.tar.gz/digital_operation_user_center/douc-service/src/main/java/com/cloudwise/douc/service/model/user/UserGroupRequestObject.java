package com.cloudwise.douc.service.model.user;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 8:36 PM 2020/2/17.
 */
@Data
public class UserGroupRequestObject implements Serializable {
    private static final long serialVersionUID = 4718479074468814905L;
    
    private String field;
    private String value;
    private Long accountId;
    private Long topAccountId;
    private Long userId;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_CURRENTPAGENO_NOT_BLANK)
    private Integer current;
    @NotNull(message = IBaseExceptionCode.API_USER_MODEL_PAGESIZE_NOT_BLANK)
    private Integer size;

    private String position;

    private String accountScope;

    private String aliasOrName;

    private List<String> enumTypes;

    public Integer getPageSize() {
        return this.size;
    }

    public void setPageSize(Integer size) {
        this.size = size;
    }

    public Integer getCurrentPageNo() {
        return this.current;
    }

    public void setCurrentPageNo(Integer current) {
        this.current = current;
    }
}
