package com.cloudwise.douc.service.model.token;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author maker.wang
 * @description: appKey、appSecret生成所需的参数
 * @date Created in 2:58 下午 2021/6/2.
 */
@Data
public class AppKeySecretGenerateParams implements Serializable {

    private static final long serialVersionUID = -1856135206664866539L;
    /**
     * 应用名称
     */
    @NotBlank(message = IBaseExceptionCode.API_HTTP_APP_KEY_SECRET_GENERATE_LACK_PARAM)
    private String appName;

    /**
     * 租户id
     */
    private Long accountId;
}
