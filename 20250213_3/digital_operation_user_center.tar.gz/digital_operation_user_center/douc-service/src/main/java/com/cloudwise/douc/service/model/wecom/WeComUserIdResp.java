package com.cloudwise.douc.service.model.wecom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 企业微信响应对象
 *
 * @author maker.wang
 * @date 2022-01-08 11:19
 **/
@ApiModel("企业微信响应对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WeComUserIdResp implements Serializable {
    private static final long serialVersionUID = -3759393847480328136L;

    public WeComUserIdResp() {
    }

    @ApiModelProperty("出错返回码，为0表示成功，非0表示调用失败")
    private int errcode;

    @ApiModelProperty("返回码提示语")
    private String errmsg;

    @ApiModelProperty("成员UserID")
    @JsonProperty("userid")
    // CHECKSTYLE:OFF
    private String UserId;
    // CHECKSTYLE:ON

    @ApiModelProperty("成员票据,后续利用该参数可以获取用户信息或敏感信息")
    @JsonProperty("user_ticket")
    private String userTicket;

    public boolean checkRequestResult() {
        return 0 == this.errcode;
    }
    
    @JsonProperty("UserId")
    public void setUserId(String userId) {
        UserId = userId;
    }
    
    @JsonProperty("userid")
    public void setuserid(String userId) {
        UserId = userId;
    }
}
