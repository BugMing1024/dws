package com.cloudwise.douc.service.plugin.lucene.redir.util;

import com.google.common.base.Strings;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * @author dwq
 */
@Log4j2
@Component
public class ConfigUtils {
    private ConfigUtils() {
    }


    private static Environment env;
    @Autowired
    public  void setEnv(Environment env) {
        ConfigUtils.env = env;
    }
    static {
        System.setProperty("DEFAULT_BUFFER_SIZE", "262144");
        System.setProperty("DEFAULT_BUFFER_SIZE_IN_MEM", "10485760");
        System.setProperty("DEFAULT_DIRECTORY_METADATA", "directory_metadata_2");
        System.setProperty("DEFAULT_FILE_DATA", "file_data_2");
        System.setProperty("LOCK_FILE_PATH", "data/lock");
        System.setProperty("COMPRESS_FILE", "false");
        System.setProperty("TIME_OUT", "10000");
    }

    /**
     * @param key key in config file
     * @return value
     */
    public static String getValue(String key) {
        boolean nullOrEmpty = Strings.isNullOrEmpty(key);
        String res = null;
        if (!nullOrEmpty) {
            res = env.getProperty(key);

            log.debug("key = " + key + ", value = " + res);
        } else {
            log.error("Key or resource bundle is null or empty!");
        }
        return res;
    }
}

