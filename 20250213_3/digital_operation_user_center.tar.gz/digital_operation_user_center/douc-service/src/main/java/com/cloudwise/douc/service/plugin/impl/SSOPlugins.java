package com.cloudwise.douc.service.plugin.impl;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.config.DomainConfig;
import com.cloudwise.douc.commons.config.I18nMessages;
import com.cloudwise.douc.commons.constant.StrConstant;
import com.cloudwise.douc.commons.model.BaseException;
import com.cloudwise.douc.commons.model.FrontWebConfig;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.model.LoginParam;
import com.cloudwise.douc.commons.model.ResultEntity;
import com.cloudwise.douc.commons.plugin.common.AbstractDOUCPlugin;
import com.cloudwise.douc.commons.plugin.common.PluginManagerUtils;
import com.cloudwise.douc.commons.plugin.common.PluginResult;
import com.cloudwise.douc.commons.plugin.common.PluginsEndpointConstants;
import com.cloudwise.douc.commons.utils.AesEncryptUtil;
import com.cloudwise.douc.commons.utils.LogUtil;
import com.cloudwise.douc.commons.utils.XssCleanRuleUtils;
import com.cloudwise.douc.commons.utils.sm2.Sm2Utils;
import com.cloudwise.douc.commons.utils.sm2.SmsecurityService;
import com.cloudwise.douc.metadata.mapper.IAccountDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserDao;
import com.cloudwise.douc.metadata.mapper.IMultiAccountUserInfoDao;
import com.cloudwise.douc.metadata.mapper.IRoleDao;
import com.cloudwise.douc.metadata.mapper.IUserDao;
import com.cloudwise.douc.metadata.model.multi.tenant.AccountDetail;
import com.cloudwise.douc.metadata.model.multi.tenant.UserEnableAccountInfoVO;
import com.cloudwise.douc.metadata.model.quota.AccountQuotaInfo;
import com.cloudwise.douc.metadata.model.role.Role;
import com.cloudwise.douc.metadata.model.role.RoleUserRelation;
import com.cloudwise.douc.metadata.model.user.User;
import com.cloudwise.douc.service.dataflow.IAccountDataFlow;
import com.cloudwise.douc.service.service.IAccountService;
import com.cloudwise.douc.service.service.IRoleService;
import com.cloudwise.douc.service.util.Constant;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * @author zafir.zhong
 * @description 一个示例埋点, 给dubbo/test加了个ping pong的功能
 * @date Created in 17:08 2022/11/9.
 */
@Component
@Slf4j
@ConditionalOnProperty(name = "plugins.sso.enabled", havingValue = "true", matchIfMissing = false)
public class SSOPlugins extends AbstractDOUCPlugin {
    
    private static final Set<String> END_POINTS = new HashSet<>();
    
    static {
        END_POINTS.add(PluginsEndpointConstants.LOGIN);
    }
    
    @Autowired
    private IAccountDao accountDao;
    
    @Autowired
    private IAccountService accountService;
    
    @Autowired
    private IAccountDataFlow accountDataFlow;
    
    @Autowired
    private IMultiAccountUserDao multiAccountUserDao;
    
    @Autowired
    private IMultiAccountUserInfoDao multiAccountUserInfoDao;
    
    @Autowired
    private IUserDao userDao;
    
    @Autowired
    private IRoleDao roleDao;
    
    @Autowired
    private IRoleService roleService;
    
    @Resource
    private FrontWebConfig frontWebConfig;
    
    public static boolean isInRange(String ip, String network) {
        String[] ips = ip.split("\\.");
        if (network.contains(StrConstant.STAR)) {
            List<String> ipList = Arrays.asList(ip.split("\\."));
            return ipInRang(ipList, network);
        }
        int ipAddr =
                (Integer.parseInt(ips[0]) << 24) | (Integer.parseInt(ips[1]) << 16) | (Integer.parseInt(ips[2]) << 8)
                        | Integer.parseInt(ips[3]);
        int type = Integer.parseInt(network.replaceAll(".{0,2048}/", ""));
        int mask = 0xFFFFFFFF << (32 - type);
        String cidrIp = network.replaceAll("/.{0,2048}", "");
        String[] cidrIps = cidrIp.split("\\.");
        int cidrIpAddr = (Integer.parseInt(cidrIps[0]) << 24) | (Integer.parseInt(cidrIps[1]) << 16) | (
                Integer.parseInt(cidrIps[2]) << 8) | Integer.parseInt(cidrIps[3]);
        
        return (ipAddr & mask) == (cidrIpAddr & mask);
    }
    
    private static boolean ipInRang(List<String> ipList, String network) {
        List<String> networkList = Arrays.asList(network.split("\\."));
        boolean result = false;
        if (ipList.size() != 4 && networkList.size() != 4) {
            return false;
        }
        for (int i = 0; i < 4; i++) {
            if (networkList.get(i).contains(StrConstant.STAR) || ipList.get(i).equals(networkList.get(i))) {
                result = true;
            } else {
                result = false;
                break;
            }
            
        }
        return result;
    }
    
    /**
     * @description 一般无需通过bean注册，因为序列的默认构造方法会执行注册 - 无参数 - 无返回
     * @author zafir.zhong
     * @date 2022/11/9
     * @time 17:47
     */
    public void init() {
        PluginManagerUtils.register(this);
    }
    
    /**
     * @description 如果有对应的销毁逻辑可能就要自己销毁了 - 无参数 - 无返回
     * @author zafir.zhong
     * @date 2022/11/9
     * @time 17:47
     */
    @PreDestroy
    public void destroy() {
        PluginManagerUtils.destroy(this);
    }
    
    @Override
    public Set<String> endPoints() {
        return END_POINTS;
    }
    
    @Override
    public PluginResult handle(String endPointKey, Object... objs) {
        PluginResult result = new PluginResult();
        result.setParams(objs);
        if (!Objects.equals(endPointKey, PluginsEndpointConstants.LOGIN)) {
            return result;
        }
        log.debug("use sso plugin do something");
        // if set something must clean
        //1.拿到需要的参数进行下一步处理
        String userIp = (String) result.getParams()[0];
        if (StringUtils.isNotBlank(userIp) && userIp.contains(StrPool.COMMA)) {
            String[] split = userIp.split(StrPool.COMMA);
            userIp = split[0];
        }
        String userAgent = (String) result.getParams()[1];
        String language = (String) result.getParams()[2];
        String username = (String) result.getParams()[3];
        String type = (String) result.getParams()[6];
        String service = (String) result.getParams()[7];
        String restapi = (String) result.getParams()[8];
        HttpServletResponse httpServletResponse = (HttpServletResponse) result.getParams()[11];
        
        ObjectMapper objectMapper = new ObjectMapper();
        String response = "";
        String location = "";
        String name = "";
        User user = new User();
        
        try {
            name = getRealName(username, type);
            user = getUserByName(name);
            
            Set<String> networkList = new HashSet<>();
            boolean ipFlag = false;
            boolean roleFlag = false;
            
            //2.对ip进行限制
            String notAllowNetworkList = ConfigUtils.getString("plugins.sso.enabledNetworkList");
            if (StringUtils.isNotEmpty(notAllowNetworkList)) {
                networkList.addAll(Arrays.asList(notAllowNetworkList.split(StrPool.COMMA)));
                for (String network : networkList) {
                    if (StringUtils.isNotEmpty(network) && isInRange(userIp, network)) {
                        ipFlag = true;
                    }
                }
            }
            
            //3.对角色进行限制
            Role adminRoleByAccountId = roleDao.getAdminRoleByAccountId(Collections.singletonList(user.getAccountId()));
            if (adminRoleByAccountId != null) {
                List<RoleUserRelation> userRelations = this.roleService.getRoleByUserIds(user.getAccountId(),
                        Collections.singletonList(user.getId()));
                for (RoleUserRelation roleUserRelation : userRelations) {
                    if (roleUserRelation.getRoleId() != null
                            && adminRoleByAccountId.getId() == roleUserRelation.getRoleId()) {
                        roleFlag = true;
                    }
                }
            }
            
            //4.判断
            if (!ipFlag && roleFlag) {
                throw new BaseException(IBaseExceptionCode.ROLE_IP_NOT_ALLOWED);
            }
            return result;
            
        } catch (BaseException e) {
            try {
                response = URLEncoder.encode(objectMapper.writeValueAsString(
                                ResultEntity.getFailResultEntity(e.getCode(), I18nMessages.getMsg(language, e))),
                        StandardCharsets.UTF_8.name());
            } catch (UnsupportedEncodingException | JsonProcessingException unsupportedEncodingException) {
                log.error("log sso Pulgins error", unsupportedEncodingException);
            }
            LogUtil.printLoginLog(name + "登录失败，原因：" + I18nMessages.getMsg(language, e), userIp, false,
                    String.valueOf(user.getId()), String.valueOf(user.getAccountId()),
                    "admin".equalsIgnoreCase(name) ? "Admin" : name, name, userAgent,
                    name + "登录失败，原因：" + I18nMessages.getMsg(Constant.DOUC_LANGUGE_TYPE_ZH_CN, e),
                    name + " login failed. Reason：" + I18nMessages.getMsg(e));
            location = getDefaultFailLocation(userAgent, service, restapi).concat("&response=").concat(response)
                    .concat("&language=").concat(language);
            result.setOverwriteResult(true);
            result.setResult(location);
            httpServletResponse.setStatus(HttpStatus.FOUND.value());
            httpServletResponse.setHeader(HttpHeaders.LOCATION, XssCleanRuleUtils.xssClean(location));
            return result;
        }
    }
    
    private User getUserByName(String name) {
        User loginUser = new User();
        Map<String, Object> userAndIfDefaultAccountEnable = this.getLoginUserInMultiOrSingleTopAccount(name);
        if (userAndIfDefaultAccountEnable.get("user") == null) {
            log.error("user is not exist");
            return loginUser;
        } else {
            loginUser = ((User) userAndIfDefaultAccountEnable.get("user"));
        }
        return loginUser;
    }
    
    private Map<String, Object> getLoginUserInMultiOrSingleTopAccount(String loginUserName) {
        Map<String, Object> userAndIfDefaultAccountEnable = null;
        LoginParam loginParam = new LoginParam();
        if (frontWebConfig.getMultiTopAccountEnable()) {
            //多个顶级租户模式下，使用邮箱登录
            
            loginParam.setEmail(loginUserName);
            userAndIfDefaultAccountEnable = this.validateUserAndAccountEnable(loginParam);
            // 配额过期时间判断，如果配额过期时间早于当前时间，不允许登录
            if (userAndIfDefaultAccountEnable.get("user") != null) {
                User loginUser = ((User) userAndIfDefaultAccountEnable.get("user"));
                
                Long accountId = loginUser.getAccountId();
                Long topId = loginUser.getTopAccountId();
                
                if (topId != null) {
                    AccountQuotaInfo accountQuotaInfoCache = this.accountDataFlow.getAccountQuotaInfo(topId);
                    if (accountQuotaInfoCache != null) {
                        accountQuotaInfoCache.comparisonQuotaEndTime(accountQuotaInfoCache);
                        
                    } else {
                        AccountQuotaInfo accountQuotaInfo = this.accountDao.getAccountQuotaInfo(topId);
                        if (accountQuotaInfo != null) {
                            accountQuotaInfo.comparisonQuotaEndTime(accountQuotaInfo);
                        }
                    }
                } else if (accountId != null) {
                    // 通过用户，查询配额是否过期
                    AccountDetail accountDetailById = this.accountService.getAccountDetailById(
                            loginUser.getAccountId());
                    if (accountDetailById != null) {
                        Date date = new Date();
                        // 从缓存中读取，如果缓存中没有从库中读取
                        AccountQuotaInfo accountQuotaInfoCache = this.accountDataFlow.getAccountQuotaInfo(
                                accountDetailById.getTopId());
                        if (accountQuotaInfoCache != null) {
                            accountQuotaInfoCache.comparisonQuotaEndTime(accountQuotaInfoCache);
                            
                        } else {
                            AccountQuotaInfo accountQuotaInfo = this.accountDao.getAccountQuotaInfo(
                                    accountDetailById.getTopId());
                            if (accountQuotaInfo != null) {
                                accountQuotaInfo.comparisonQuotaEndTime(accountQuotaInfo);
                            }
                        }
                    }
                }
            }
        } else {
            //（默认）单个顶级租户模式下，格式符合邮箱先用邮箱字段查询无对应邮箱用户当做用户名字段查询，不是邮箱格式使用用户名字段查询
            if (loginUserName.matches("[\\w\\.\\-]{1,99}@([\\w\\-]+\\.){1,99}[\\w\\-]{1,99}")) {
                loginParam.setEmail(loginUserName);
                userAndIfDefaultAccountEnable = this.validateUserAndAccountEnable(loginParam);
                String notUniqueFieldStr = ConfigUtils.getString("not.unique.field", CharSequenceUtil.EMPTY);
                List<String> notUniqueFieldList = CollUtil.newArrayList(notUniqueFieldStr.split(StrPool.COMMA));
                if (notUniqueFieldList.contains("email")) {
                    userAndIfDefaultAccountEnable.put("user", null);
                    loginParam.setEmail(null);
                }
                //如果为null 说明账号不是email，通过用户名查
                if (userAndIfDefaultAccountEnable.get("user") == null) {
                    loginParam.setUserAlias(loginUserName);
                    userAndIfDefaultAccountEnable = this.validateUserAndAccountEnable(loginParam);
                }
            } else {
                loginParam.setUserAlias(loginUserName);
                userAndIfDefaultAccountEnable = this.validateUserAndAccountEnable(loginParam);
            }
        }
        return userAndIfDefaultAccountEnable;
    }
    
    //查询用户租户可用状态
    //返回用户是否在默认租户下可用+用户在默认租户下查询结果
    private Map<String, Object> validateUserAndAccountEnable(LoginParam loginParam) {
        
        Map<String, Object> map = Maps.newHashMap();
        //根据userAlias,Email，dingDingAccount,weWorkAccount查询用户基础信息+默认租户下用户信息
        loginParam.setOpenDomain(DomainConfig.isOpenDomain());
        List<User> userInDefaultAccountList = multiAccountUserInfoDao.getUserInfoListByUserAliasOrEmailOrPhoneOrDingDingOrWeWorkInDefaultAccount(
                loginParam);
        User userInDefaultAccount = null;
        if (CollUtil.isNotEmpty(userInDefaultAccountList)) {
            userInDefaultAccount = userInDefaultAccountList.get(0);
        }
        map.put("user", userInDefaultAccount);
        //用户不存在，return false user==null
        if (userInDefaultAccount == null) {
            map.put("ifDefaultAccountEnable", Boolean.FALSE);
            return map;
        }
        
        //默认租户为空或默认租户不是启用或者用户在默认租户内不是启用 return false 默认租户不可用
        if (userInDefaultAccount.getAccountId() == null || !Constant.STATUS_UP.equals(
                userInDefaultAccount.getAccountStatus()) || !Constant.STATUS_UP.equals(
                userInDefaultAccount.getStatus())) {
            //查询用户可用租户
            List<UserEnableAccountInfoVO> enableAccountsByUserId = multiAccountUserDao.getEnableAccountsByUserId(
                    userInDefaultAccount.getId());
            //不存在可用租户 抛异常用户已停用
            if (CollectionUtils.isEmpty(enableAccountsByUserId)) {
                
                throw new BaseException(IBaseExceptionCode.SSO_AUTHENTICATION_STATUS_DOWN_ERROR);
            }
            //如果只有一个可用租户，直接进入
            if (enableAccountsByUserId.size() == 1) {
                map.put("user", userDao.getSingleUserByUserIdAndAccountId(enableAccountsByUserId.get(0).getId(),
                        userInDefaultAccount.getId()));
                map.put("ifDefaultAccountEnable", Boolean.TRUE);
            } else {
                //存在多个可用租户，return false ,user is not null
                userInDefaultAccount.setAccountId(Constant.DEFAULT_MAX_ACCOUNTID + 1);
                map.put("ifDefaultAccountEnable", Boolean.FALSE);
            }
            return map;
        } else {
            //默认租户可用（默认租户启用，用户在默认租户内启用），return true ，正常登录
            map.put("ifDefaultAccountEnable", Boolean.TRUE);
            return map;
        }
    }
    
    private String getRealName(String username, String type) {
        try {
            if (Constant.ENCRYPTION_SM2_TYPE.equals(type)) {
                //比较前端是否被篡改
                username = Sm2Utils.SMBDecrypt(username, SmsecurityService.prikey);
            } else if (Constant.ENCRYPTION_AES_TYPE.equals(type)) {
                
                username = AesEncryptUtil.desEncrypt(username);
                
            } else {
                username = Sm2Utils.SMBDecrypt(username, SmsecurityService.prikey);
            }
        } catch (Exception e) {
            log.error("login-error:{}", ExceptionUtils.getStackTrace(e));
        }
        return username;
    }
    
    private String getDefaultFailLocation(String userAgent, String service, String restapi) {
        String loginUrl = "/douc/api/v1/sso/source/index.html";
        String customLoginUrl = ConfigUtils.getString("sso.server.custom.login.url", loginUrl);
        if (ConfigUtils.hasPath("sso.server.custom.useragent") && StringUtils.isNotBlank(userAgent)
                && userAgent.toLowerCase().contains(ConfigUtils.getString("sso.server.custom.useragent"))) {
            return addPrefixRedirectUrl(
                    customLoginUrl.concat("?restapi=").concat(restapi).concat("&service=").concat(service));
        } else {
            return addPrefixRedirectUrl(
                    loginUrl.concat("?restapi=").concat(restapi).concat("&service=").concat(service));
        }
    }
    
    private String addPrefixRedirectUrl(String url) {
        return ConfigUtils.getString("sso.server.default.prefix", StringUtils.EMPTY) + url;
    }
    
    
    @Override
    public void clean(String endPointKey) {
        // if set something must clean
        if (Objects.equals(endPointKey, PluginsEndpointConstants.LOGIN)) {
            PluginManagerUtils.cleanKeys(PluginsEndpointConstants.LOGIN);
        }
    }
}
