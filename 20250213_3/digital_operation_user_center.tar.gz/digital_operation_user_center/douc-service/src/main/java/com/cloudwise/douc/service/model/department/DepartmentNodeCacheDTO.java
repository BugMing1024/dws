package com.cloudwise.douc.service.model.department;

import lombok.Data;

import java.io.Serializable;

/**
 * @author brady.liu
 * Description: department cache
 */
@Data
public class DepartmentNodeCacheDTO implements Serializable {

    private Long id;
    private Long accountId;
    private String name;
    private String code;
    private Long parentId;
    private String level;
    private Integer status;
    private Integer perNum = 0;
    private Integer perNumInUse = 0;
    private Integer importType = 1;
    private String attribute;
    private Integer sequence;
    /**
     * 身份源id
     */
    private Long identitySourceId;

}

