package com.cloudwise.douc.service.model.group;

import lombok.Data;

import java.util.List;

/**
 * @author Bernie
 * @date 2021-04-27 19:08
 */
@Data
public class GroupRelation {
    private List<Long> idList;
    private Long groupId;
    private Long userId;
    private Long accountId;
}
