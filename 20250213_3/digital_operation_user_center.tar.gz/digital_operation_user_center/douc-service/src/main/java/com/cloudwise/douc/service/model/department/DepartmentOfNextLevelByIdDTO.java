package com.cloudwise.douc.service.model.department;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author bradyliu
 * @description: 用于 {@link com.cloudwise.douc.service.service.IDepartmentV2Service#getDepartmentOfNextLevelById}传参，参数校验
 * @date Created in 10:23 上午 2021/5/25.
 */
@Data
public class DepartmentOfNextLevelByIdDTO {
    @NotNull(message = IBaseExceptionCode.RPC_DATA_ACCOUNTID_NOT_NULL)
    private Long accountId;
    @NotNull(message = IBaseExceptionCode.RPC_DATA_DEPARTMENTID_NOT_NULL)
    private Long departmentId;

    private Integer status;

    private String language;
    private Long userId;
    
    private String accountScope;
}
