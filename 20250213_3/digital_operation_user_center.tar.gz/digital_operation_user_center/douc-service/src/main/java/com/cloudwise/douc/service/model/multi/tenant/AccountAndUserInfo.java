package com.cloudwise.douc.service.model.multi.tenant;

import com.cloudwise.douc.metadata.model.user.UserInfoOfMini;
import lombok.Data;

import java.io.Serializable;

/**
 * 租户、用户信息
 *
 * @author maker.wang
 * @date 2021-06-30 11:46
 **/
@Data
public class AccountAndUserInfo extends UserInfoOfMini implements Serializable {
    
    private static final long serialVersionUID = -4859864537358038139L;
    
    /**
     * 1顶级租户，2非顶级租户 默认2
     **/
    private Integer isTop;
    
    /**
     * 1 初始化系统管理员 2普通用户
     **/
    private Integer adminType;

}
