package com.cloudwise.douc.service.configuration;

import cn.hutool.core.text.StrPool;
import com.cloudwise.cwop.security.RSAUtils;
import com.cloudwise.douc.commons.utils.SpecialCharUtil;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author KenLiang
 * @description:
 * @date Created in 11:32 AM 2020/12/4.
 */
@Slf4j
public class ConfigListener implements ApplicationListener<ApplicationPreparedEvent> {
    private static final String DECRYPT_PROP = "props.decrypt.props";
    private static final String DECRYPT_NOPROP = "props.decrypt.noprops";
    
    private static final String DECRYPT_NAME = "props.decrypt.key";
    private static final String DECRYPT_PROPERTY_SOURCE = "cloudwise-common-decrypt";

    @Override
    public void onApplicationEvent(ApplicationPreparedEvent applicationPreparedEvent) {

        ConfigurableEnvironment environment = applicationPreparedEvent
                .getApplicationContext()
                .getEnvironment();

        MutablePropertySources propertySources = environment.getPropertySources();
        //nacos账号密码解密
        Collection<String> processDecryptKeyList = Arrays.asList(environment.getProperty(DECRYPT_PROP, "").split(
                StrPool.COMMA));
        Collection<String> noprocessDecryptKeyList = Arrays.asList(environment.getProperty(DECRYPT_NOPROP, "").split(StrPool.COMMA));
        log.info("preparedDecryptKeyList : {}", processDecryptKeyList);
        log.info("noprocessDecryptKeyList : {}", noprocessDecryptKeyList);
        propertySources.remove(DECRYPT_PROPERTY_SOURCE);
        //processDecryptProperties(propertySources, environment, processDecryptKeyList, noprocessDecryptKeyList);
        //redis模式处理
        this.processRedisProperties(propertySources, environment);
        //mysql配置
        this.processMysqlProperties(propertySources, environment);
        //自监控
        this.processActuatorProperties(propertySources, environment);
        //二级域名中特殊字符处理
        this.processDomainProperties(environment);
    }

    private void processRedisProperties(MutablePropertySources propertySources, Environment environment) {
        try {
            String redisClusterType = environment.getProperty("redisClusterType", "none");
            String redisServers = environment.getProperty("redisServers");
            if (StringUtils.isBlank(redisServers)) {
                return;
            }
            String redisPassword = environment.getProperty("redisPassword");
            String redisSentinelPassword = environment.getProperty("redisSentinelPassword");
            String[] redisServerArray = redisServers.split(StrPool.COMMA);
            Properties properties = new Properties();
            if ("sentinel".equalsIgnoreCase(redisClusterType)) {
                properties.setProperty("spring.redis.sentinel.master", environment.getProperty("redisMastername"));
                properties.setProperty("spring.redis.sentinel.nodes", redisServers);
                //添加redis sentinel密码
                if (StringUtils.isNotBlank(redisSentinelPassword)) {
                    properties.setProperty("spring.redis.sentinel.password", redisSentinelPassword);
                }
            } else if ("cluster".equalsIgnoreCase(redisClusterType)) {
                properties.setProperty("spring.redis.cluster.nodes", redisServers);
            } else {
                String[] ipHost = redisServerArray[0].split(StrPool.COLON);
                //单机
                properties.setProperty("spring.redis.host", ipHost[0]);
                properties.setProperty("spring.redis.port", ipHost[1]);
            }
            //添加redis密码
            if (StringUtils.isNotBlank(redisPassword)) {
                properties.setProperty("spring.redis.password", redisPassword);
            }
            PropertiesPropertySource propertiesPropertySource = new PropertiesPropertySource("redis-properties", properties);
            propertySources.addFirst(propertiesPropertySource);
        } catch (Exception e) {
            log.error("redis-config-error:{}", ExceptionUtils.getStackTrace(e));
        }
    }


    private void processMysqlProperties(MutablePropertySources propertySources, Environment environment) {
        try {
            log.warn("now nothing for processMysqlProperties ,class:{}", this.getClass());
        } catch (Exception e) {
            log.error("mysql-config-error:{}", ExceptionUtils.getStackTrace(e));
        }
    }

    private void processActuatorProperties(MutablePropertySources propertySources, Environment environment) {
        try {
            String actuatorUsername = environment.getProperty("springActuatorUsername");
            if (StringUtils.isBlank(actuatorUsername)) {
                return;
            }
            String actuatorPassword = environment.getProperty("springActuatorPassword");
            Properties properties = new Properties();
            properties.setProperty("spring.security.user.name", actuatorUsername);
            properties.setProperty("spring.security.user.password", actuatorPassword);
            PropertiesPropertySource propertiesPropertySource = new PropertiesPropertySource("actuator-properties", properties);
            propertySources.addFirst(propertiesPropertySource);
        } catch (Exception e) {
            log.error("actuator-config-error:{}", ExceptionUtils.getStackTrace(e));
        }
    }

    private void processDecryptProperties(MutablePropertySources propertySources,
                                          ConfigurableEnvironment environment,
                                          @NonNull Collection<String> keys, Collection<String> noprocessDecryptKeyList) {
        final Set<String> collect = keys.stream().filter(StringUtils::isNoneBlank).map(String::trim)
                .collect(Collectors.toSet());
        Properties properties = new Properties();
        collect.forEach(key -> {
            String value = environment.getProperty(key, "");
            if (StringUtils.isNoneBlank(value) && !noprocessDecryptKeyList.contains(key)) {
                String decrypt = decrypt(value, environment.getProperty(DECRYPT_NAME));
                properties.setProperty(key, decrypt);

            }
        });
        PropertiesPropertySource propertiesPropertySource = new PropertiesPropertySource(DECRYPT_PROPERTY_SOURCE, properties);
        propertySources.addFirst(propertiesPropertySource);
    }
    
    private String decrypt(String source, String key) {
        if (StringUtils.isBlank(key)) {
            log.error("DecryptKey cannot be null or empty.");
        }
        String result = null;
        try {
            result = RSAUtils.decrypt(key, source);
            log.info(">>>processDecryptProperties--success>>>-【{}】-【{}】", key, source);
        } catch (Exception e) {
            log.warn("Decryption failed:", e);
            log.warn("Decryption failed,key:{}", key);
            result = source;
        }
        return result;
    }

    /**
     * 处理二级域名中的特殊字符,替换成下划线
     *
     * @author maker.wang
     * @date 2021-11-16 11:01
     **/
    private void processDomainProperties(ConfigurableEnvironment environment) {
        MutablePropertySources propertySources = environment.getPropertySources();
        String name = "server.secondLevelDomain";
        if (!environment.containsProperty(name)) {
            log.warn("secondLevelDomain config miss");
            return;
        }
        String secondLevelDomain = environment.getProperty(name);
        if (StringUtils.isBlank(secondLevelDomain)) {
            log.warn("secondLevelDomain is null");
            return;
        }
        try {
            //替换二级域名中的特殊字符
            String removeSpecialCharSecondLevelDomain = SpecialCharUtil.replaceSpecialChar(secondLevelDomain);
            Map<String, Object> params = new HashMap<>(2);
            String formatKey = "server.secondLevelDomain.format";
            params.put(formatKey, removeSpecialCharSecondLevelDomain);
            MapPropertySource mapPropertySource = new MapPropertySource("secondLevelDomain", params);
            propertySources.addFirst(mapPropertySource);
            log.info("domain:{} === {}", secondLevelDomain, removeSpecialCharSecondLevelDomain);
        } catch (Exception e) {
            log.error("process domain properties error", e);
        }
    }

}