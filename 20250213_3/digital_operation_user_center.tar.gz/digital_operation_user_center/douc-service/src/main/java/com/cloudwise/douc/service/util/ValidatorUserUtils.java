package com.cloudwise.douc.service.util;

import cn.hutool.core.text.StrPool;
import com.cloudwise.douc.commons.utils.ThreadLocalUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author elsa.yang
 * @date 2020/6/19 2:30 下午
 */
@Component
public class ValidatorUserUtils {


    //校验用户名
    public List<String> checkUserAlias(String userAlias) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于60个字符
        if (userAlias.length() > 60) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【User name】：" + userAlias + " length greater than 60 characters");
            } else {
                result.add("【用户名】：" + userAlias + "长度大于60个字符");
            }
        }
        if (userAlias.contains(Constant.SEMICOLON)) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【User name】：" + userAlias + " cannot contain ;");
            } else {
                result.add("【用户名】：" + userAlias + "不能包含;");
            }
        }
        return result;
    }

    //校验用户名
    public List<String> checkUserCode(String userCode) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于100个字符
        if (userCode.length() > 100) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【User code】：" + userCode + " length greater than 100 characters");
            } else {
                result.add("【用户编码】：" + userCode + "长度大于100个字符");
            }
        }
        return result;
    }

    // 姓名
    public List<String> checkUserName(String userName) {
        List<String> result = new ArrayList<>();
        //校验姓名长度是否大于60个字符
        if (userName.length() > 60) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【name】：" + userName + " length greater than 60 characters");
            } else {
                result.add("【用户姓名】：" + userName + "长度大于60个字符");
            }
        }
        return result;
    }

    // 手机号
    public List<String> checkMobile(String mobile, List<String> matchesStrList) {
        List<String> result = new ArrayList<>();
        if (!checkMobiles(mobile, matchesStrList)) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【phone】：" + mobile + " Format error");
            } else {
                result.add("【用户手机号】：" + mobile + "格式错误");
            }
        }
        return result;
    }

    public static boolean checkMobiles(String phone, List<String> matchesStrList) {
        String replacePhone = phone;
        if (phone.startsWith("+") && !phone.contains(StrPool.DASHED)) {
            return false;
        }
        if (phone.contains(StrPool.DASHED) && !phone.startsWith("+")) {
            return false;
        }
        if (phone.contains(StrPool.DASHED)) {
            replacePhone = phone.replace(StrPool.DASHED, "");
        }
        for (String s : matchesStrList) {
            if (replacePhone.matches(s)) {
                return true;
            }
        }
        return false;
    }

    // 邮箱
    public List<String> checkEmail(String email) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于40个字符
        if (email.length() > 64) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【email】：" + email + " length greater than 64 characters");
            } else {
                result.add("【用户邮箱】：" + email + "长度大于64个字符");
            }
        }
        if (!email.matches("[\\w\\.\\-]{1,99}@([\\w\\-]{1,99}\\.){1,99}[\\w\\-]{1,99}")) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【email】：" + email + " Format error");
            } else {
                result.add("【用户邮箱】：" + email + "格式错误");
            }
        }
        return result;
    }

    // 钉钉
    public List<String> checkDingtalk(String dingtalk) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于40个字符
        if (dingtalk.length() > 40) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【dingtalk】：" + dingtalk + " length greater than 40 characters");
            } else {
                result.add("【用户钉钉】：" + dingtalk + "长度大于40个字符");
            }
        }
        return result;
    }

    // 企业微信
    public List<String> checkWechat(String wechat) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于40个字符
        if (wechat.length() > 40) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Wecom】：" + wechat + " length greater than 40 characters");
            } else {
                result.add("【用户企业微信】：" + wechat + "长度大于40个字符");
            }
        }
        return result;
    }

    // 飞书
    public List<String> checkFeishu(String feishu) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于40个字符
        if (feishu.length() > 40) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【feishu】：" + feishu + " length greater than 40 characters");
            } else {
                result.add("【用户飞书账号】：" + feishu + "长度大于40个字符");
            }
        }
        return result;
    }

    // 微信公众号
    public List<String> checkWxPush(String wxpush) {
        List<String> result = new ArrayList<>();
        //校验用户名长度是否大于40个字符
        if (wxpush.length() > 40) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【WeChat official account】：" + wxpush + " length greater than 40 characters");
            } else {
                result.add("【用户微信公众号账号】：" + wxpush + "长度大于40个字符");
            }
        }
        return result;
    }

    private static final Pattern PATTERN_CHECK_PHONE = Pattern.compile("[0-9]*");

    //座机
    public List<String> checkPhone(String phone) {
        List<String> result = new ArrayList<>();
        String phoneReplac = phone.replaceAll(StrPool.DASHED, "");
        Matcher isNum = PATTERN_CHECK_PHONE.matcher(phoneReplac);
        //校验是否全部为数字
        if (!isNum.matches()) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Tel.】：" + phone + " Format error");
            } else {
                result.add("【固定电话】：" + phone + "格式错误");
            }
            //解决错误提示两次问题 座机示例:123Q
            return result;
        }
        //校验位数
        if (phone.contains(StrPool.DASHED)) {
            String[] strs = phone.split(StrPool.DASHED);
            if (strs[0].length() != 4 && strs[0].length() != 3) {
                if (ThreadLocalUtil.isEnglish()) {
                    result.add("【Tel.】：" + phone + " Format error");
                } else {
                    result.add("【固定电话】：" + phone + "格式错误");
                }
                return result;
            }
            if (strs[1].length() != 7 && strs[1].length() != 8) {
                if (ThreadLocalUtil.isEnglish()) {
                    result.add("【Tel.】：" + phone + " Format error");
                } else {
                    result.add("【固定电话】：" + phone + "格式错误");
                }
            }
        } else if (phone.length() != 7 && phone.length() != 8) {
            if (ThreadLocalUtil.isEnglish()) {
                result.add("【Tel.】：" + phone + " Format error");
            } else {
                result.add("【固定电话】：" + phone + "格式错误");
            }
        }

        return result;
    }
}