package com.cloudwise.douc.service.util;


import com.cloudwise.douc.metadata.model.department.DepartmentNode;
import com.cloudwise.douc.metadata.model.group.Group;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author barney.song
 * Description: 构造目录JSON树
 */
@Slf4j
public class TreeBuilder {
    private List<DepartmentNode> nodes = new ArrayList<>();

    public static List<DepartmentNode> buildTree(List<DepartmentNode> nodes) {

        TreeBuilder treeBuilder = new TreeBuilder(nodes);

        return treeBuilder.buildJSONTree();
    }

    public TreeBuilder() {
    }

    private TreeBuilder(List<DepartmentNode> nodes) {
        super();
        this.nodes = nodes;
    }

    // 构建JSON树形结构
    private List<DepartmentNode> buildJSONTree() {
        List<DepartmentNode> nodeTree = buildTree1();
        return nodeTree;
    }

    // 构建树形结构
    private List<DepartmentNode> buildTree1() {
        List<DepartmentNode> treeNodes = Lists.newArrayListWithExpectedSize(nodes.size());
        List<DepartmentNode> rootNodes = getRootNodes();
        for (DepartmentNode rootNode : rootNodes) {
            buildChildNodes(rootNode);
            treeNodes.add(rootNode);
        }
        return treeNodes;
    }

    // 递归子节点
    private void buildChildNodes(DepartmentNode node) {
        List<DepartmentNode> children = getChildNodes(node);
        if (!children.isEmpty()) {
            for (DepartmentNode child : children) {
                buildChildNodes(child);
            }
            node.setChildren(children);
        }
    }

    // 获取父节点下所有的子节点
    private List<DepartmentNode> getChildNodes(DepartmentNode pnode) {
        List<DepartmentNode> childNodes = new ArrayList<>();
        Long a = pnode.getId();
        for (DepartmentNode n : nodes) {
            Long b = n.getParentId();
            if (a.equals(b)) {
                childNodes.add(n);
            }
        }
        return childNodes;
    }

    // 判断是否为根节点
    private boolean rootNode(DepartmentNode node) {
        boolean isRootNode = true;
        Long a = node.getParentId();
        for (DepartmentNode n : nodes) {
            Long b = n.getId();
            if (a.equals(b)) {
                isRootNode = false;
                break;
            }
        }
        return isRootNode;
    }

    // 获取集合中所有的根节点
    private List<DepartmentNode> getRootNodes() {
        List<DepartmentNode> rootNodes = new ArrayList<>();
        for (DepartmentNode n : nodes) {

            if (rootNode(n)) {
                rootNodes.add(n);
            }
        }
        return rootNodes;
    }

    /**
     * 统计每个父节点的总人数
     */
    public static List<DepartmentNode> countPerNum(List<DepartmentNode> departmentNodeList) {
        //逆序排序level
        Map<Integer, Set<Long>> departmentSortMap = new HashMap();
        Map<Long, DepartmentNode> departmentNodeMap = Maps.newHashMapWithExpectedSize(departmentNodeList.size());
        for (DepartmentNode departmentChild : departmentNodeList) {
            departmentNodeMap.put(departmentChild.getId(), departmentChild);
            int levelLength = departmentChild.getLevel().split("\\.").length;
            if (departmentSortMap.get(levelLength) != null) {
                Set<Long> set = departmentSortMap.get(levelLength);
                set.add(departmentChild.getId());
            } else {
                Set<Long> set = new HashSet();
                set.add(departmentChild.getId());
                departmentSortMap.put(levelLength, set);
            }
        }
        Set set = departmentSortMap.keySet();
        Object[] levelLengthArray = set.toArray();
        Arrays.sort(levelLengthArray);
        Arrays.sort(levelLengthArray, Collections.reverseOrder());
        for (Object levelLength : levelLengthArray) {
            int levelLengthInt = Integer.parseInt(levelLength.toString());
            Set<Long> sameLevelInMapSet = departmentSortMap.get(levelLengthInt);
            for (Long id : sameLevelInMapSet) {
                if (departmentNodeMap.get(departmentNodeMap.get(id).getParentId()) != null) {
                    departmentNodeMap.get(departmentNodeMap.get(id).getParentId())
                            .setPerNum(departmentNodeMap.get(id).getPerNum()
                                    + departmentNodeMap.get(departmentNodeMap.get(id).getParentId()).getPerNum());
                    departmentNodeMap.get(departmentNodeMap.get(id).getParentId())
                            .setPerNumInUse(departmentNodeMap.get(id).getPerNumInUse()
                                    + departmentNodeMap.get(departmentNodeMap.get(id).getParentId()).getPerNumInUse());
                }
            }
        }
        return new ArrayList(departmentNodeMap.values());
    }

    /**
     * 递归获取所有父节点下的子节点
     *
     * @author: Johnson.zhou
     */
    public void getAllChild2(Long id, List<Group> list, Set<Long> deleteSet) {
        for (Group node : list) {
            if (id.equals(node.getParentId())) {
                deleteSet.add(node.getId());
                getAllChild2(node.getId(), list, deleteSet);
            }
        }
    }

}

