package com.cloudwise.douc.service.model;

import lombok.Data;

@Data
public class LoginResultEntity {

    private String code;
    private String tryNum;
    private String errMsg;
    private String lockEndTime;

}
