package com.cloudwise.douc.service.model;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * @author barney.song
 * Description: No Description
 */
public enum ExcelEntitySaaS {
    /**
     * 用户名（必填）
     */
    USER_ALIAS(0, "userAlias", "用户名（必填）\n"
            + "Username (required）", "用户名(必填)"),
    /**
     * 用户编号
     */
    CODE(1, "code", "用户编号\n"
            + "User ID", "用户编号"),

    /**
     * 用户姓名（必填）
     */
    NAME(2, "name", "姓名（必填）\n"
            + "Name (required)", "用户姓名"),
    /**
     * 部门（必填）
     */
    DEPARTMENT(3, "department", "部门（必填）\n"
            + "Department (required)", "部门"),
    /**
     * 状态
     */
    STATUS(4, "status", "状态\n"
            + "Status", "状态"),

    /**
     * 电子邮箱（必填）
     */
    EMAIL(5, "email", "邮箱\n"
            + "Email", "电子邮箱"),
    /**
     * 手机号码（必填）
     */
    MOBILE(6, "mobile", "手机号（必填）Phone(required)", "手机号码"),

    /**
     * 类型（必填）
     */
    ORIGIN(7, "origin", "类型\n"
            + "Type", "用户类型"),
    /**
     * 企业微信
     */
    WECHAT(8, "wechat", "企业微信账号\n"
            + "Wecom", "企业微信"),
    /**
     * 钉钉
     */
    DINGTALK(9, "dingtalk", "钉钉账号\n"
            + "DingTalk", "钉钉"),
    /**
     * 微信公众号
     */
    WXPUSH(10, "wxpushAccount", "微信公众号账号\n"
            + "WeChat official account", "微信公众号"),
    /**
     * 座机
     */
    PHONE(11, "phone", "座机\n" + "Tel.", "座机"),

    POSITION(12, "position", "职务\n" + "Title", "职务");

    private int index;
    private String fieldName;
    private String excelRowName;
    private String excelHeadName;

    ExcelEntitySaaS(int index, String fieldName, String excelRowName, String excelHeadName) {
        this.index = index;
        this.fieldName = fieldName;
        this.excelRowName = excelRowName;
        this.excelHeadName = excelHeadName;
    }

    public static String getExcelRowNameByIndex(int index) {
        for (ExcelEntitySaaS excelEntity : ExcelEntitySaaS.values()) {
            if (index == excelEntity.index) {
                return excelEntity.excelRowName;
            }
        }
        return null;
    }

    public static List<String> toExcelHeadName() {
        List<String> list = Lists.newArrayListWithExpectedSize(ExcelEntitySaaS.values().length);
        for (ExcelEntitySaaS excelEntity : ExcelEntitySaaS.values()) {
            list.add(excelEntity.getExcelHeadName());
        }
        return list;
    }

    public static List<String> toExcelRowName() {
        List<String> list = Lists.newArrayListWithExpectedSize(ExcelEntitySaaS.values().length);
        for (ExcelEntitySaaS excelEntity : ExcelEntitySaaS.values()) {
            list.add(excelEntity.getExcelRowName());
        }
        return list;
    }

    public int getIndex() {
        return index;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getExcelRowName() {
        return excelRowName;
    }

    public String getExcelHeadName() {
        return excelHeadName;
    }
}
