package com.cloudwise.douc.service.dataflow;

import com.cloudwise.douc.metadata.model.dicdata.DicDataInfo;
import com.cloudwise.douc.metadata.model.dicdata.DicTypePo;

import java.util.List;
import java.util.Map;

/**
 * @author KenLiang
 * @description:
 * @date Created in 10:53 PM 2021/4/7.
 */
public interface IDictDataFlow {
    List<DicDataInfo> getDictDataByTypeId(Long accountId, Long typeId);

    void deleteDictDataByTypeId(Long accountId, Long typeId);

    Map<String, DicDataInfo> getDictDataMapByTypeId(Long accountId, Long typeId);

    DicTypePo getDicTypeById(Long accountId, Long typeId);

    void deleteDictTypeByTypeId(Long accountId, Long typeId);
}
