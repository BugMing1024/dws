package com.cloudwise.douc.service.model.timezone;

import lombok.Data;

import java.io.Serializable;

/**
 * 个人时区
 *
 * @author leakey.li
 * @description:
 * @date Created in 8:19 下午 2021/10/20.
 */
@Data
public class UserTimeZoneRpc implements Serializable {
    /**
     * 个人偏好时区值 如 GMT-04:00
     */
    private String timeZone;
    /**
     * 个人偏好时区值城市code 如 America/New_York
     */
    private String countryCityCode;
    /**
     * 系统时区值 如 GMT+00:00
     */
    private String systemTimeZone;
    /**
     * 系统时区国家code 如 AEurope/London
     */
    private String systemCountryCityCode;
    /**
     * 用户使用系统时区 ，还是个人偏好时区   ；
     * true:系统  false：个人偏好
     */
    private Boolean isSystemTimeZone;
}
