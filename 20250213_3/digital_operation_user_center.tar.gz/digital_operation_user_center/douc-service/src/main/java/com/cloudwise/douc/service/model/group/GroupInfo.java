package com.cloudwise.douc.service.model.group;

import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

/**
 * 用户组信息
 */
@Data
public class GroupInfo implements Serializable {
    private Long groupId;
    private String groupName;
    private Long parentId;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GroupInfo groupInfo = (GroupInfo) o;
        return Objects.equals(groupId, groupInfo.groupId)
                && Objects.equals(groupName, groupInfo.groupName)
                && Objects.equals(parentId, groupInfo.parentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(groupId, groupName, parentId);
    }
}
