package com.cloudwise.douc.service.model.sync;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Dubbo修改部门实体
 *
 * @author maker.wang
 * @date 2021-11-08 17:30
 **/
@Data
@ApiModel("Dubbo修改部门实体")
public class DubboUpdateDepartment implements Serializable {
    private static final long serialVersionUID = 8586726058499572576L;

    @ApiModelProperty(value = "租户id", required = true)
    @NotNull(message = IBaseExceptionCode.MULTI_ACCOUNT_TOP_ID_NULL)
    private Long accountId;

    @ApiModelProperty(value = "部门名称", required = true)
    @NotBlank(message = IBaseExceptionCode.RPC_DEPARTMENT_NAME_IS_NOT_NULL)
    private String departmentName;

    @ApiModelProperty(value = "部门编码", required = true)
    @NotBlank(message = IBaseExceptionCode.RPC_DATA_DEPARTMENT_INFO_NOT_BLANK)
    private String departmentCode;

    @ApiModelProperty(value = "部门状态 1 启用 2 停用", required = true)
    @NotNull(message = IBaseExceptionCode.RPC_DATA_DEPARTMENT_STATUS_NOT_NULL)
    private Integer status;
    
    private Integer sequence;

    @ApiModelProperty(value = "上级部门编码,未传parentCode,部门挂到顶级部门下")
    private String parentDepartmentCode;

    @ApiModelProperty(value = "拓展字段")
    private List<Map<String, Object>> extendFields;
}
