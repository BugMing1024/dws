package com.cloudwise.douc.service.cache;

import com.cloudwise.douc.metadata.model.group.GroupBaseInfo;
import com.cloudwise.douc.metadata.model.user.UserBaseInfoCacheDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 用户组缓存service 接口
 */
public interface IGroupCache {

    List<Long> getUserIdListFromCacheByGroupId(long groupId, String accountId);

    /**
     * description:通过用户组id集合批量获取缓存中的用户Id信息
     *
     * @return 用户Id集合
     */
    ArrayList<Long> getGroupHasUserIdListFromCacheByGroupId(String groupId, String accountId);

    /**
     * description:通过用户id集合批量获取缓存中的用户信息
     *
     * @return 用户集合
     */
    List<UserBaseInfoCacheDTO> getGroupHasUserListFromCacheByUserIdsAndUserStatus(List<Long> userIds, String accountId);

    /**
     * description: 更新基于用户id单一用户信息至缓存
     *
     * @param
     * @return
     */
    void setGroupUserBasedByGroupIdToCache(String groupId, String accountId, ArrayList<Long> userIds);

    /**
     * 删除缓存
     *
     * @param groupId
     * @param accountId
     */
    boolean deleteGroupUserBasedByGroupIdToCache(String groupId, String accountId);


    /**
     * 获取全量的用户组
     *
     * @param accountId
     * @return
     */
    List<GroupBaseInfo> getAllGroupByAccountId(Long accountId);

    /**
     * 设置全量用户组
     *
     * @param accountId
     * @param groupBaseInfos
     */
    void setAllGroupByAccountId(Long accountId, List<GroupBaseInfo> groupBaseInfos);

    /**
     * 全量删除用户组缓存
     *
     * @param accountId
     * @return
     */
    boolean deleteGroupByAccountId(Long accountId);

    /**
     * 全量删除用户组缓存
     *
     * @param accountId
     * @return
     */
    boolean deleteGroupListByAccountId(Long accountId, List<Long> groupIdList);

    /**
     * 查询用户组领导
     *
     * @param accountId
     * @return
     */
    Map<String, ArrayList<String>> getGroupLeaderCache(Long accountId);

    /**
     * 设置用户组领导
     *
     * @param accountId
     * @param groupLeaderMap
     */
    void setGroupLeaderCache(Long accountId, Map<String, ArrayList<String>> groupLeaderMap, Long time);

    /**
     * @param groupUserKeys 用户组用户keys
     * @return
     * @description 批量删除用户组与用户关系缓存
     * @author leakey.li
     * @date 2021/12/14
     * @time 4:38 下午
     */
    void deleteGroupUserBasedByGroupIdsKeysToCache(List<String> groupUserKeys);
}
