package com.cloudwise.douc.service.util;


import cn.hutool.core.collection.CollUtil;
import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.redis.RedisTools;
import lombok.extern.slf4j.Slf4j;

import java.util.Collection;
import java.util.concurrent.TimeUnit;

/**
 * 越权操作的协助控制类
 *
 * @author <a href="mailto:zafir.zhong@cloudwise.com">zafir zhong</a>
 * @version 1.0.0
 * @date created at 2024-08-11 02:29; update at 2024-08-11 02:29
 */
@Slf4j
public class UnauthorizedCheckUtils {
    
    public static void authKeys(Collection<String> keys, Long timeOfMinute) {
        if (CollUtil.isEmpty(keys)) {
            return;
        }
        if (timeOfMinute == null) {
            timeOfMinute = ConfigUtils.getLong("unauthorized.check.timeOfMinute", 10);
        }
        for (String each : keys) {
            authKey(each, timeOfMinute);
        }
    }
    
    public static void authKey(String key, Long timeOfMinute) {
        if (!ConfigUtils.getBoolean("unauthorized.check.enabled", true)) {
            return;
        }
        log.info("auth key: {}", key);
        if (timeOfMinute == null) {
            timeOfMinute = ConfigUtils.getLong("unauthorized.check.timeOfMinute", 10);
        }
        RedisTools.setNXEX(key, "", timeOfMinute, TimeUnit.MINUTES);
    }
    
    public static boolean checkAuth(String key) {
        if (!ConfigUtils.getBoolean("unauthorized.check.enabled", true)) {
            return true;
        }
        boolean keyExist = RedisTools.isKeyExist(key);
        log.info("check auth key: {} result:{}", key, keyExist);
        return keyExist;
    }
}
