package com.cloudwise.douc.service.model.license;

import com.cloudwise.cwop.l.vo.FeatureInfo;
import com.cloudwise.cwop.l.vo.LicInfo;
import lombok.Data;

import java.util.List;

/**
 * @author ethan
 */
@Data
public class LicenseVo {
    /**
     * license是否可用
     */
    private boolean enable;
    
    /**
     * license 检查结果
     */
    private String message;
    
    /**
     * 版本
     */
    private String version;
    
    /**
     * License 公司名称
     */
    private String company;
    
    /**
     * license 的最早开始时间
     */
    private Long startDate;

    /**
     * license 的最晚结束时间
     */
    private Long endDate;
    
    /**
     * sign
     */
    private String sign;
    
    /**
     * sn 序列号
     */
    private String sn;
    
    /**
     * 类型
     */
    private LicInfo.TYPE type;
    
    /**
     * mac地址
     */
    private List<String> hostid;
    
    /**
     * Feature 列表
     */
    private List<FeatureInfo> features;
}
