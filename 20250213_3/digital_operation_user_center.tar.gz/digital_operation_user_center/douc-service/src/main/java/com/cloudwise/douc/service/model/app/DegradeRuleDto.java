package com.cloudwise.douc.service.model.app;

import lombok.Data;

/**
 * 熔断实体类
 **/
@Data
public class DegradeRuleDto {

    /**
     * 资源名
     **/
    private String resource;
    /**
     * 每秒的并发次数
     **/
    private Integer count;
    /**
     * 熔断时长
     **/
    private Integer timeWindow;
    /**
     * 每秒连续请求数
     **/
    private Integer rtSlowRequestAmount;

}
