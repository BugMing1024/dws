package com.cloudwise.douc.service.model.multi.tenant;

import lombok.Data;

/**
 * @author ken.liang
 * @description:用户租户信息
 * @date Created in 1:59 PM 2021/7/20.
 */
@Data
public class UserAccountInfoDTO {

    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 租户ID
     */

    private Long accountId;

    /**
     * 租户状态
     */
    private Long accountStatus;

    /**
     * 租户名称
     */
    private Long accountName;

    /**
     * 状态 1启用，2停用
     */
    private Integer status;

}
