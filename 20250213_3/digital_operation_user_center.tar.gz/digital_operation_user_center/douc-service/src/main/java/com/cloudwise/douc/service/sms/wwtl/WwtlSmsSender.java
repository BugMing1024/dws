package com.cloudwise.douc.service.sms.wwtl;

import com.cloudwise.douc.commons.config.ConfigUtils;
import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import com.cloudwise.douc.commons.model.ResultEntity;
import com.cloudwise.douc.commons.utils.JsonUtils;
import com.cloudwise.douc.service.sms.ISmsSender;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpHost;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author Norval.Xu
 * @since 2021/8/6
 */
@Slf4j
@Component
@Configuration
public class WwtlSmsSender implements ISmsSender {

    /**
     * MD5加密KEY
     */
    private static final String S_MMS_ENCRYPT = "SMmsEncryptKey";
    @Value("${channel.sms.wwtl.url:none}")
    private String url;
    @Value("${channel.sms.wwtl.account_id:none}")
    private String accountId;
    @Value("${channel.sms.wwtl.password:none}")
    private String password;

    public static String sha256(String rawString) {
        return DigestUtils.sha256Hex(rawString);
    }

    static String md5(String password) {
        String encodeStr = DigestUtils.md5Hex(password + S_MMS_ENCRYPT);
        return encodeStr.toUpperCase();
    }

    public static long getCurrentTime() {
        return System.currentTimeMillis() / 1000;
    }

    public static long getRandom() {
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.setSeed(getCurrentTime());
        return secureRandom.nextInt(900000) + 100000L;
    }

    public static String calcMoReportSign(String accountId, String password, long random, long timestamp) {
        StringBuilder builder = new StringBuilder("AccountId=")
                .append(accountId)
                .append("&Password=")
                .append(md5(password))
                .append("&Random=")
                .append(random)
                .append("&Timestamp=")
                .append(timestamp);

        return sha256(builder.toString());
    }

    public static String calcSendSmsSign(String accountId, String mobile, String password, long random, long timestamp) {
        StringBuilder builder = new StringBuilder("AccountId=")
                .append(accountId)
                .append("&PhoneNos=")
                .append(mobile)
                .append("&Password=")
                .append(md5(password))
                .append("&Random=")
                .append(random)
                .append("&Timestamp=")
                .append(timestamp);

        return sha256(builder.toString());
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getId() {
        return "wwtl";
    }

    @Override
    public ResultEntity sendMsg(String code, String phone, String content) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            String sengUrl = ConfigUtils.getString("channel.sms.wwtl.sendUrl", "https://api.51welink.com/EncryptionSubmit/SendSms.ashx");
            HttpPost httpPost = new HttpPost(sengUrl);
            ResponseHandler<String> responseHandler = new BasicResponseHandler();
            long random = getRandom();
            long timestamp = getCurrentTime();
            ObjectNode body = JsonUtils.getObjectNode();
            body.put("AccountId", accountId);
            body.put("ExtendNo", "");
            body.put("ProductId", ConfigUtils.getString("channel.sms.wwtl.productId", "1012808"));
            body.put("PhoneNos", phone);
            body.put("Content", content);
            body.put("AccessKey", calcSendSmsSign(accountId, phone, password, random, timestamp));
            body.put("Timestamp", timestamp);
            body.put("Random", random);
            body.put("OutId", "");
            body.put("SendTime", "");
            return sendHttpReq(httpPost, httpClient, responseHandler, body.toString());
        } catch (Exception e) {
            ResultEntity resultEntity = new ResultEntity();
            resultEntity.setCode(IBaseExceptionCode.SYSTEM_ERROR);
            resultEntity.setMsg("wwtl配置异常");
            return resultEntity;
        }
    }

    @Override
    public String getTemplateCode(Map<String, Object> map) {
        Object tempCode = map.get("TempCode");
        Integer tempStatus = (Integer) map.get("TempStatus");
        if (tempStatus == 2) {
            return "2";
        }
        if (tempStatus == 1) {
            return "1";
        }

        return tempCode + "";
    }

    private ResultEntity sendHttpReq(HttpPost httpPost, CloseableHttpClient httpClient, ResponseHandler<String> responseHandler, String body) {
        ResultEntity resultEntity = new ResultEntity();
        try {
            HttpHost proxy = getHttpHost();
            StringEntity requestEntity = new StringEntity(body, StandardCharsets.UTF_8);
            requestEntity.setContentEncoding(StandardCharsets.UTF_8.name());
            httpPost.setHeader("Content-type", "application/json");
            httpPost.setEntity(requestEntity);
            if (proxy != null) {
                //设置代理
                RequestConfig requestConfig = RequestConfig.custom()
                        .setConnectTimeout(5000)
                        .setConnectionRequestTimeout(5000)
                        .setSocketTimeout(5000)
                        .setRedirectsEnabled(true).setProxy(proxy).build();
                httpPost.setConfig(requestConfig);
            }
            String returnValue = httpClient.execute(httpPost, responseHandler);
            log.info("send message result {}", returnValue);
            JsonNode jsonNode = JsonUtils.getJsonNode(returnValue);
            String result = jsonNode.get("Result").asText();
            resultEntity.setCode("succ".equals(result) ? IBaseExceptionCode.SUCCESS : IBaseExceptionCode.SYSTEM_ERROR);
            return resultEntity;
        } catch (Exception e) {
            log.error("send message error.", e);
            resultEntity.setCode(IBaseExceptionCode.SYSTEM_ERROR);
            return resultEntity;
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                log.error("send message http client close error.", e);
            }
        }
    }

    private HttpHost getHttpHost() {
        HttpHost proxy = null;
        boolean isProxy = ConfigUtils.getBoolean("http.proxy");
        if (isProxy) {
            String proxyHost = ConfigUtils.getString("http.proxyHost", "");
            int proxyPort = ConfigUtils.getInt("http.proxyPort", 0);
            proxy = getRequestConfig(isProxy, proxyHost, proxyPort);
        }
        return proxy;
    }

    private HttpHost getRequestConfig(boolean isProxy, String proxyHost, int proxyPort) {
        log.debug("isProxy -result-- {}", isProxy);
        if (!isProxy) {
            return null;
        }
        return new HttpHost(proxyHost, proxyPort);
    }


}
