package com.cloudwise.douc.service.model.auth;

import lombok.Data;

import java.util.List;

/**
 * @author KenLiang
 * @description:
 * @date Created in 3:55 PM 2020/4/12.
 */
@Data
public class DataAuthResponseDataTypeNode {
    private String dataTypeCode;
    private List<DataAuthResponseNode> details;
}
