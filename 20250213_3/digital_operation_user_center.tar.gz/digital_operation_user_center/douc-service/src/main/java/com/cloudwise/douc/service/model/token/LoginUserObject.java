package com.cloudwise.douc.service.model.token;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author KenLiang
 * @description:
 * @date Created in 6:36 PM 2020/3/15.
 */
@Data
@NoArgsConstructor
public class LoginUserObject implements Serializable {
    private static final long serialVersionUID = -5713786305661750196L;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 租户id
     */
    private Long accountId;

    /**
     * 租户名称
     */
    private String accountName;


    /**
     * 顶级租户id
     */
    private Long topAccountId;

    /**
     * 顶级租户名称
     */
    private String topAccountName;
}
