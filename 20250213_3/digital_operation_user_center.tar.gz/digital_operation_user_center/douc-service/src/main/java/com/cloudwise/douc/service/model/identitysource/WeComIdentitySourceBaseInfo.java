package com.cloudwise.douc.service.model.identitysource;

import com.cloudwise.douc.commons.model.IBaseExceptionCode;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class WeComIdentitySourceBaseInfo {

    @ApiModelProperty(value = "企业id")
    @NotBlank(message = IBaseExceptionCode.WECOM_CORPID_NOT_EXIST)
    private String corpId;
    @ApiModelProperty(value = "企业密钥")
    @NotBlank(message = IBaseExceptionCode.WECOM_CORPSECRET_NOT_EXIST)
    private String corpSecret;
    @ApiModelProperty(value = "同步节点id")
    @NotBlank(message = IBaseExceptionCode.WECOM_SYNCNODEID_NOT_EXIST)
    private String syncNodeId;
    @ApiModelProperty(value = "企业回调url")
    private String callBackUrl;
    @ApiModelProperty(value = "企业回调token")
    private String callBackToken;
    @ApiModelProperty(value = "企业回调EncodingAESKey")
    private String callBackKey;
}
