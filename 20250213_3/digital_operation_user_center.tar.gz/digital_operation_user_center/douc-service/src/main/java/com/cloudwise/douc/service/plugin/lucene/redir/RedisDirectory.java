package com.cloudwise.douc.service.plugin.lucene.redir;

import cn.hutool.extra.spring.SpringUtil;
import com.cloudwise.douc.commons.constant.CacheConstant;
import com.cloudwise.douc.service.plugin.lucene.redir.io.InputOutputStream;
import com.cloudwise.douc.service.plugin.lucene.redir.io.LettuceStream;
import com.cloudwise.douc.service.plugin.lucene.redir.io.RedisInputStream;
import com.cloudwise.douc.service.plugin.lucene.redir.io.RedisOutputStream;
import com.cloudwise.douc.service.plugin.lucene.redir.util.FileBlocksUtils;
import com.google.common.primitives.Longs;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.apache.lucene.store.BaseDirectory;
import org.apache.lucene.store.IOContext;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.util.Accountable;
import org.apache.lucene.util.Accountables;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author dwq
 */
@Log4j2
public class RedisDirectory extends BaseDirectory implements Accountable {
    @Getter
    private InputOutputStream inputOutputStream;
    @Getter
    private static volatile Map<String, RedisFile> filesMap = new ConcurrentHashMap<>();
    @Getter
    private static final AtomicLong SIZE_IN_BYTES = new AtomicLong();
    @Getter
    private String index;
    
    private final Set<String> pendingDeletes = Collections.newSetFromMap(new ConcurrentHashMap());
    private final AtomicInteger opsSinceLastDelete = new AtomicInteger();
    private final AtomicLong nextTempFileCounter = new AtomicLong();
   
    public RedisDirectory(String index) {
        super(new RedissonFactory(SpringUtil.getApplicationContext().getBean("jacksonRedisTemplate", RedisTemplate.class)));
        this.index = index;
        this.inputOutputStream = new LettuceStream(SpringUtil.getApplicationContext().getBean(LettuceConnectionFactory.class));
    }

    /**
     * @return get all the file names lists
     */
    @Override
    public final String[] listAll() {
        ensureOpen();
        return inputOutputStream.getAllFileNames(CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index);
    }

    /**
     * Returns true iff the named file exists in this directory.
     */
    private boolean fileNameExists(String fileName) {
        return inputOutputStream.hexists((CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index).getBytes(), fileName.getBytes());
    }

    /**
     * @param name file name
     * @return Returns the length of a file in the directory.
     */
    @Override
    public final long fileLength(String name) {
        ensureOpen();
        long current = 0;
        byte[] b = inputOutputStream.hget((CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index).getBytes(), name.getBytes(), Operations.FILE_LENGTH);
        if (b != null) {
            current = Longs.fromByteArray(b);
        }
        return current;
    }

    @Override
    public void deleteFile(String name) {
        ensureOpen();
        boolean b = fileNameExists(name);
        if (b) {
            byte[] hget = inputOutputStream.hget((CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index).getBytes(), name.getBytes(), Operations.FILE_LENGTH);
            long length = Longs.fromByteArray(hget);
            long blockSize = FileBlocksUtils.getBlockSize(length);
            inputOutputStream.deleteFile(CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index, CacheConstant.REDIS_CACHE_KEY_LUCENE_FILE_METADATA + index, name, blockSize);
        } else {
            log.error("Delete file {} does not exists!", name);
        }
    }

    /**
     * Creates a new, empty file in the directory with the given name. Returns a stream writing this file.
     */
    @Override
    // TODO
    public IndexOutput createOutput(String name, IOContext context) throws IOException {
        ensureOpen();
        this.maybeDeletePendingFiles();
        if (this.pendingDeletes.remove(name)) {
            this.privateDeleteFile(name, true);
            this.pendingDeletes.remove(name);
        }
        
        return new RedisOutputStream(index, name, getInputOutputStream());
    }
    
    @Override
    public IndexOutput createTempOutput(String prefix, String suffix, IOContext ioContext) throws IOException {
        this.ensureOpen();
        this.maybeDeletePendingFiles();
     
        String name = getTempFileName(prefix, suffix, this.nextTempFileCounter.getAndIncrement());
        if (!this.pendingDeletes.contains(name)) {
            return new RedisOutputStream(index, prefix + suffix + ".tmp", getInputOutputStream());
        } else {
            return null;
        }
    }
    
    @Override
    // TODO
    public void sync(Collection<String> names) throws IOException {
        this.ensureOpen();
        
        for (String name : names) {
            this.loadRedisToFile(name);
        }
        
        this.maybeDeletePendingFiles();
    }
    
    @Override
    // TODO
    public void syncMetaData() {
    
    }
    
    @Override
    // TODO
    public void rename(String source, String dest) throws IOException {
        this.ensureOpen();
        if (this.pendingDeletes.contains(source)) {
            throw new NoSuchFileException("file \"" + source + "\" is pending delete and cannot be moved");
        } else {
            this.maybeDeletePendingFiles();
            if (this.pendingDeletes.remove(dest)) {
                this.privateDeleteFile(dest, true);
                this.pendingDeletes.remove(dest);
            }
            
            List<byte[]> values = new ArrayList<>();
            //在get的时候不需要加事务
            //在删除和添加的时候使用事务
            //Get the file length with old file name
            byte[] hget = inputOutputStream.hget((CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index).getBytes(), source.getBytes(), Operations.FILE_LENGTH);
            long length = Longs.fromByteArray(hget);
            long blockSize = FileBlocksUtils.getBlockSize(length);
            for (int i = 0; i < blockSize; i++) {
                //Get the contents with old file name
                byte[] res = inputOutputStream.hget((CacheConstant.REDIS_CACHE_KEY_LUCENE_FILE_METADATA + index).getBytes(), FileBlocksUtils.getBlockName(source, i), Operations.FILE_DATA);
                values.add(res);
            }
            inputOutputStream.rename((CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index), CacheConstant.REDIS_CACHE_KEY_LUCENE_FILE_METADATA + index, source, dest, values, length);
            log.debug("Rename file success from {} to {}", source, dest);
        }
    }

    @Override
    // TODO
    public IndexInput openInput(String name, IOContext context) throws IOException {
        ensureOpen();
        if (!fileNameExists(name)) {
            throw new FileNotFoundException(name);
        }
        //从redis中load文件到redis file对象中
        //单例Jedis有一个坑，就是在同一时刻只能被一个线程持有，在openInput方法中，Lucene会有Read操作和Merge操作，而其由不同的线程完成，所以如果在
        //loadRedisToFile中出现不同线程在瞬时同时持有Jedis对象会一直报错Socket Closed
        return new RedisInputStream(name, loadRedisToFile(name));
    }

    private RedisFile loadRedisToFile(String fileName) {
        byte[] hget = inputOutputStream.hget((CacheConstant.REDIS_CACHE_KEY_LUCENE_DIRECTORY_METADATA + index).getBytes(), fileName.getBytes(), Operations.FILE_LENGTH);
        long lenght = Longs.fromByteArray(hget);
        RedisFile redisFile = new RedisFile(fileName, lenght);
        long blockSize = FileBlocksUtils.getBlockSize(lenght);
        List<byte[]> bytes = inputOutputStream.loadFileOnce((CacheConstant.REDIS_CACHE_KEY_LUCENE_FILE_METADATA + index), fileName, blockSize);
        redisFile.setBuffers(bytes);
        return redisFile;
    }

    @Override
    public void close() throws IOException {
        isOpen = false;
        inputOutputStream.close();
        this.deletePendingFiles();
    }
    
    @Override
    public Set<String> getPendingDeletions() throws IOException {
        this.deletePendingFiles();
        return this.pendingDeletes.isEmpty() ? Collections.emptySet() : Collections.unmodifiableSet(new HashSet(this.pendingDeletes));
    }
    
    private void privateDeleteFile(String name, boolean isPendingDelete) throws IOException {
        deleteFile(name);
        this.pendingDeletes.remove(name);
    }
    
    public synchronized void deletePendingFiles() throws IOException {
        if (!this.pendingDeletes.isEmpty()) {
            Iterator var1 = (new HashSet(this.pendingDeletes)).iterator();
            
            while (var1.hasNext()) {
                String name = (String) var1.next();
                this.privateDeleteFile(name, true);
            }
        }
    }
    
    private void maybeDeletePendingFiles() throws IOException {
        if (!this.pendingDeletes.isEmpty()) {
            int count = this.opsSinceLastDelete.incrementAndGet();
            if (count >= this.pendingDeletes.size()) {
                this.opsSinceLastDelete.addAndGet(-count);
                this.deletePendingFiles();
            }
        }
        
    }
    
    /**
     * Return the memory usage of this object in bytes. Negative values are illegal.
     */
    @Override
    public long ramBytesUsed() {
        ensureOpen();
        return SIZE_IN_BYTES.get();
    }


    /**
     * Returns nested resources of this class.
     * The result should be a point-in-time snapshot (to avoid race conditions).
     *
     * @see Accountables
     */
    @Override
    public Collection<Accountable> getChildResources() {
        return Collections.emptyList();
    }
}
