package com.cloudwise.douc.service.model.token;

import com.cloudwise.douc.metadata.model.token.AppKeySecretInfo;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 读取配置文件中的配置
 * token:
 * historyappkeysecretinolist:
 * list:
 * - appKey: W8JSYWgk
 * appSecret: 732b128e61dc74f3250b21114c6b963ce1fdd139
 * appName: maker
 * - appKey: Kg2RjXEj
 * appSecret: 5f9cd8dbf6cd90903c56ecbb5dd7453be8218326
 * appName: wang
 *
 * @author maker.wang
 * @description: 已经发出去的appKey+appSecret
 * @date Created in 5:23 下午 2021/6/2.
 */
@Configuration
@ConfigurationProperties("token.historyappkeysecretinolist")
public class HistoryTokenInfo implements Serializable {
    private static final long serialVersionUID = 4548442021031157396L;
    private static List<AppKeySecretInfo> list = new ArrayList<>();


    public HistoryTokenInfo() {
        super();
    }

    public HistoryTokenInfo(List<AppKeySecretInfo> list1) {
        super();
        list = list1;
    }

    public List<AppKeySecretInfo> getList() {
        return list;
    }

    public void setList(List<AppKeySecretInfo> list1) {
        list = list1;
    }

}