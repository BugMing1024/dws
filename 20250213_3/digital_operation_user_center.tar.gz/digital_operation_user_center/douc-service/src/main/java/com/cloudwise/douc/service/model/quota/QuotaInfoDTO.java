package com.cloudwise.douc.service.model.quota;

import com.cloudwise.douc.service.util.Constant;
import lombok.Data;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author bradyliu
 * @description: 配额实体，用于解密后使用
 * @date Created in 17:24 2021/10/9.
 */
@Data
public class QuotaInfoDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;
    /**
     * 模块编码
     **/
    private String moduleCode;

    /**
     * 菜单编码
     **/
    private String menuCode;

    /**
     * 服务项编码  示例：USER_NUM_LIMIT_CODE（用户数）
     **/
    private String serviceItemCode;

    /**
     * 服务项值    示例：10000 （最多1万用户）
     **/
    private Object serviceItemValue;

    /**
     * 服务项模块编码
     */
    private String serviceModuleCode;

    public List<String> getMenuCodeArray() {
        if (menuCode.contains(Constant.COMMA)) {
            String[] menuCodeArr = menuCode.split(Constant.COMMA);
            return Arrays.asList(menuCodeArr);
        } else {
            return Collections.singletonList(menuCode);
        }
    }
}
